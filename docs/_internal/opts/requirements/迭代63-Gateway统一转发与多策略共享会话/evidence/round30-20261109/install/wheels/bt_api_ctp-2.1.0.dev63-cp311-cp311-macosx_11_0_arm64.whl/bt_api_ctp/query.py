"""Typed completion evidence for CTP multi-packet queries."""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from hashlib import sha256
from math import isfinite
from typing import Any, Generic, TypeVar

T = TypeVar("T")

QUERY_COMPLETION_ORIGINS = frozenset(
    {
        "unknown",
        "query_response",
        "response_error",
        "front_disconnected",
        "client_stop",
        "local_cancel",
        "submit_exception",
        "submit_rejected",
        "timeout",
        "deadline",
        "record_limit",
        "success",
        "local_preflight",
        "query_slot_busy",
    }
)

# These seals are intentionally module-private.  A regular ``QueryResult``
# constructed by a caller has no source provenance and cannot be promoted to
# account evidence merely because its string fields happen to match a session.
_QUERY_SOURCE_SEAL = object()
_QUERY_SCOPE_SEAL = object()
_QUERY_MONOTONIC_CLOCK_DOMAIN = "python.time.monotonic"
# Strict evidence is deliberately bounded by an issuer policy.  A caller can
# request a shorter TTL, but a later conversion cannot extend a query beyond
# this trusted maximum age by choosing new UTC and monotonic deadlines.
# Strict query provenance must survive the bounded serial seven-query
# certificate cadence. Individual position evidence keeps a shorter policy
# window in ctp_position_evidence.py.
_QUERY_EVIDENCE_MAX_TTL_SECONDS = 35.0
_QUERY_POSITION_EVIDENCE_MAX_TTL_SECONDS = 5.0
_MAX_QUERY_RECORD_LIMIT = 100_000


def _canonical_query_value(value: Any) -> Any:
    """Return a deterministic JSON value for native query snapshots.

    Query records remain mutable for legacy consumers.  The strict evidence
    boundary uses this representation only to bind a digest at terminal
    callback time and to detect later mutation; arbitrary ``__str__`` or
    ``repr`` implementations are intentionally unsupported.
    """

    # Fast path for the exact native types that make up almost every CTP row.
    # Each branch returns exactly what the general checks below would return
    # for that exact type, so digests are byte-identical; subclasses and other
    # types still go through the original ordered checks.  ``isinstance`` on
    # the ``Mapping`` ABC dominated large catalog digests (tens of seconds).
    value_type = type(value)
    if value_type is str or value_type is int or value_type is bool or value is None:
        return value
    if value_type is float:
        if not isfinite(value):
            return {"__nonfinite_float__": value.hex()}
        return value
    if value_type is dict:
        exact_items: dict[str, Any] = {}
        for key, item in value.items():
            if type(key) is not str:
                raise TypeError("query snapshot keys must be exact strings")
            item_type = type(item)
            # Inline the exact-scalar case: catalog rows are flat, so this
            # avoids one recursive call per field.
            if (
                item_type is str
                or item_type is int
                or item_type is bool
                or item is None
                or (item_type is float and isfinite(item))
            ):
                exact_items[key] = item
            else:
                exact_items[key] = _canonical_query_value(item)
        return {key: exact_items[key] for key in sorted(exact_items)}
    if value_type is tuple or value_type is list:
        return [_canonical_query_value(item) for item in value]

    if isinstance(value, Mapping):
        items: dict[str, Any] = {}
        for key, item in value.items():
            if type(key) is not str:
                raise TypeError("query snapshot keys must be exact strings")
            items[key] = _canonical_query_value(item)
        return {key: items[key] for key in sorted(items)}
    if isinstance(value, (list, tuple)):
        return [_canonical_query_value(item) for item in value]
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if type(value) is float:
        if not isfinite(value):
            # Preserve malformed native evidence as a stable typed marker so
            # the strict row parser can report the field-level reason.  It is
            # still bound by the source digest and can never become a valid
            # quantity merely because a caller mutates the later result.
            return {"__nonfinite_float__": value.hex()}
        return value
    if type(value) in (str, int, bool) or value is None:
        return value
    # Unsupported mutable/native objects are intentionally never normalized
    # via ``str`` or ``repr``.  The type marker keeps the terminal payload
    # bound while the strict parser rejects the field as non-native.
    return {"__unsupported_type__": f"{type(value).__module__}.{type(value).__qualname__}"}


def _flat_row_or_canonical(row: Any) -> Any:
    """Canonicalize one record, fast for flat rows of exact JSON scalars.

    A ``Mapping`` row (for example ``_QueryRecordSnapshot``) whose keys are
    exact ``str`` and whose values are exact finite JSON scalars canonicalizes
    to a dict with the same items; serialized with ``sort_keys=True`` it is
    byte-identical, so the per-field recursion and sorted copy are skipped.
    Any other row takes the general path unchanged (including its errors).
    """

    if isinstance(row, Mapping):
        flat: dict[str, Any] = {}
        for key, item in row.items():
            item_type = type(item)
            if type(key) is not str or not (
                item_type is str
                or item_type is int
                or item_type is bool
                or item is None
                or (item_type is float and isfinite(item))
            ):
                return _canonical_query_value(row)
            flat[key] = item
        return flat
    return _canonical_query_value(row)


def _query_records_digest(records: Iterable[Any]) -> str:
    """Hash one mutable-compatible record sequence at a point in time."""

    canonical: list[Any] = []
    for row in tuple(records):
        canonical.append(_flat_row_or_canonical(row))
    serialized = json.dumps(
        canonical,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return sha256(serialized).hexdigest()


def native_account_query_filters(
    request_type: str,
    *,
    broker_id: str,
    investor_id: str,
    instrument_id: str = "",
    exchange_id: str = "",
    order_sys_id: str = "",
) -> dict[str, str]:
    """Exact CTP query fields for the default account/position/order scope.

    The NUL business type and empty currency retain native defaults; they do
    not establish venue-wide business or currency coverage.
    """
    values = (broker_id, investor_id, instrument_id, exchange_id, order_sys_id)
    if any(type(value) is not str for value in values):
        raise TypeError("native query filters must be exact strings")
    filters = {"BrokerID": broker_id, "InvestorID": investor_id}
    if request_type == "account":
        if instrument_id or exchange_id or order_sys_id:
            raise ValueError("unexpected account query filter")
        filters.update(CurrencyID="", BizType="\x00", AccountID="")
    elif request_type == "positions":
        if order_sys_id:
            raise ValueError("unexpected position query filter")
        filters.update(ExchangeID=exchange_id, InvestUnitID="", InstrumentID=instrument_id)
    elif request_type == "orders":
        filters.update(
            ExchangeID=exchange_id, InvestUnitID="", InstrumentID=instrument_id,
            OrderSysID=order_sys_id, InsertTimeStart="", InsertTimeEnd="",
        )
    else:
        raise ValueError("unsupported account query type")
    return filters


@dataclass(frozen=True)
class _QuerySource:
    """Typed provenance issued by one live ``TraderClient`` query lane.

    ``request_intent_filters`` records the exact string values the SDK meant
    to put in the native request. ``request_filters`` records getter values
    read back from that populated native request before submission.
    """

    _seal: object
    issuer: object
    request_type: str
    request_id: int
    account_fingerprint: str
    connection_generation: int
    trading_day: str
    broker_id: str
    investor_id: str
    request_intent_filters: tuple[tuple[str, str], ...]
    request_filters: tuple[tuple[str, str], ...]
    request_intent_parameters: tuple[tuple[str, float], ...]
    request_parameters: tuple[tuple[str, float], ...]
    explicit_request_filters: tuple[str, ...]
    started_at_utc: datetime
    completed_at_utc: datetime | None
    started_monotonic: float
    completed_monotonic: float | None
    clock_domain_id: str
    records_sha256: str | None
    trusted_expires_at_utc: datetime | None
    trusted_expires_monotonic: float | None
    source_tags: tuple[str, str, str, str, int, int] | None = None
    record_limit: int | None = None
    record_limit_exceeded: bool = False


@dataclass(frozen=True)
class _QuerySessionScope:
    """Current session scope issued by the same ``TraderClient`` instance."""

    _seal: object
    issuer: object
    account_fingerprint: str
    connection_generation: int
    trading_day: str
    broker_id: str
    investor_id: str
    read_only_ready: bool
    captured_at_utc: datetime
    captured_monotonic: float
    source_tags: tuple[str, str, str, str, int, int] | None = None


def _new_query_source(
    *,
    issuer: object,
    request_type: str,
    request_id: int,
    account_fingerprint: str,
    connection_generation: int,
    trading_day: str,
    broker_id: str,
    investor_id: str,
    request_intent_filters: tuple[tuple[str, str], ...] = (),
    started_at_utc: datetime,
    completed_at_utc: datetime | None,
    started_monotonic: float,
    completed_monotonic: float | None,
    records_sha256: str | None,
    request_filters: tuple[tuple[str, str], ...] = (),
    request_intent_parameters: tuple[tuple[str, float], ...] = (),
    request_parameters: tuple[tuple[str, float], ...] = (),
    explicit_request_filters: tuple[str, ...] = (),
    source_tags: tuple[str, str, str, str, int, int] | None = None,
    record_limit: int | None = None,
    record_limit_exceeded: bool = False,
) -> _QuerySource:
    trusted_expires_at_utc = None
    trusted_expires_monotonic = None
    if completed_at_utc is not None:
        trusted_expires_at_utc = completed_at_utc + timedelta(
            seconds=_QUERY_EVIDENCE_MAX_TTL_SECONDS
        )
    if completed_monotonic is not None:
        trusted_expires_monotonic = completed_monotonic + _QUERY_EVIDENCE_MAX_TTL_SECONDS
    return _QuerySource(
        _seal=_QUERY_SOURCE_SEAL,
        issuer=issuer,
        request_type=request_type,
        request_id=request_id,
        account_fingerprint=account_fingerprint,
        connection_generation=connection_generation,
        trading_day=trading_day,
        broker_id=broker_id,
        investor_id=investor_id,
        request_intent_filters=request_intent_filters,
        request_filters=request_filters,
        request_intent_parameters=request_intent_parameters,
        request_parameters=request_parameters,
        explicit_request_filters=explicit_request_filters,
        started_at_utc=started_at_utc,
        completed_at_utc=completed_at_utc,
        started_monotonic=started_monotonic,
        completed_monotonic=completed_monotonic,
        clock_domain_id=_QUERY_MONOTONIC_CLOCK_DOMAIN,
        records_sha256=records_sha256,
        trusted_expires_at_utc=trusted_expires_at_utc,
        trusted_expires_monotonic=trusted_expires_monotonic,
        source_tags=source_tags,
        record_limit=record_limit,
        record_limit_exceeded=record_limit_exceeded,
    )


def _attach_query_source(result: QueryResult[Any], source: _QuerySource) -> QueryResult[Any]:
    if type(source) is not _QuerySource or source._seal is not _QUERY_SOURCE_SEAL:
        raise TypeError("invalid query source")
    object.__setattr__(result, "_source", source)
    return result


def _new_query_session_scope(
    *,
    issuer: object,
    account_fingerprint: str,
    connection_generation: int,
    trading_day: str,
    broker_id: str,
    investor_id: str,
    read_only_ready: bool,
    captured_at_utc: datetime,
    captured_monotonic: float,
    source_tags: tuple[str, str, str, str, int, int] | None = None,
) -> _QuerySessionScope:
    return _QuerySessionScope(
        _seal=_QUERY_SCOPE_SEAL,
        issuer=issuer,
        account_fingerprint=account_fingerprint,
        connection_generation=connection_generation,
        trading_day=trading_day,
        broker_id=broker_id,
        investor_id=investor_id,
        read_only_ready=read_only_ready,
        captured_at_utc=captured_at_utc,
        captured_monotonic=captured_monotonic,
        source_tags=source_tags,
    )


@dataclass(frozen=True)
class QueryResult(Generic[T]):
    """Immutable result for one CTP request ID and connection generation.

    ``records`` may be empty only when ``complete`` proves that the matching
    successful terminal packet was observed.  Consumers must not interpret an
    empty incomplete result as an empty account, position, order, trade, fee,
    margin, or instrument set.
    """

    request_type: str
    request_id: int
    connection_generation: int
    account_fingerprint: str
    started_at_utc: datetime
    completed_at_utc: datetime | None
    is_last_seen: bool
    error_code: int | None
    error_message: str
    timed_out: bool
    complete: bool
    records: tuple[T, ...] = field(default_factory=tuple)
    late_callback_count: int = 0
    unsupported: bool = False
    submit_code: int | None = None
    first_completion_origin: str = "unknown"
    completion_origin: str = "unknown"
    record_limit: int | None = None
    record_limit_exceeded: bool = False
    _source: _QuerySource | None = field(default=None, init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        for name in ("first_completion_origin", "completion_origin"):
            value = getattr(self, name)
            if type(value) is not str or value not in QUERY_COMPLETION_ORIGINS:
                raise ValueError(f"invalid {name}")
        if self.record_limit is not None and (
            type(self.record_limit) is not int
            or not 1 <= self.record_limit <= _MAX_QUERY_RECORD_LIMIT
        ):
            raise ValueError("record_limit must be an exact integer from 1 to 100000 or None")
        if type(self.record_limit_exceeded) is not bool:
            raise ValueError("record_limit_exceeded must be a bool")
        if self.record_limit_exceeded and self.record_limit is None:
            raise ValueError("record_limit_exceeded requires a record limit")
        if self.record_limit_exceeded and self.completion_origin != "record_limit":
            raise ValueError("record-limited result must use record_limit completion origin")
        if self.complete and self.record_limit_exceeded:
            raise ValueError("a record-limited result cannot be complete")

    @property
    def query_source(self) -> _QuerySource | None:
        """Return private typed provenance, when issued by a live query lane."""

        return self._source

    @property
    def first(self) -> T | None:
        """Return the first record only for a complete query."""
        if not self.complete or not self.records:
            return None
        return self.records[0]

    @property
    def evidence_complete(self) -> bool:
        """Alias used by fail-closed consumers of heterogeneous query envelopes."""
        return self.complete

    def as_dict(self, *, include_records: bool = False) -> dict[str, Any]:
        """Return JSON-friendly completion evidence for public envelopes."""
        data: dict[str, Any] = {
            "request_type": self.request_type,
            "request_id": self.request_id,
            "connection_generation": self.connection_generation,
            "account_fingerprint": self.account_fingerprint,
            "started_at_utc": self.started_at_utc.isoformat(),
            "completed_at_utc": (
                self.completed_at_utc.isoformat() if self.completed_at_utc is not None else None
            ),
            "is_last_seen": self.is_last_seen,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "timed_out": self.timed_out,
            "complete": self.complete,
            "evidence_complete": self.evidence_complete,
            "record_count": len(self.records),
            "late_callback_count": self.late_callback_count,
            "unsupported": self.unsupported,
            "submit_code": self.submit_code,
            "first_completion_origin": self.first_completion_origin,
            "completion_origin": self.completion_origin,
            "record_limit": self.record_limit,
            "record_limit_exceeded": self.record_limit_exceeded,
        }
        if include_records:
            data["records"] = list(self.records)
        return data

    @classmethod
    def unavailable(
        cls,
        *,
        request_type: str,
        request_id: int,
        connection_generation: int,
        account_fingerprint: str,
        started_at_utc: datetime,
        error_message: str,
        error_code: int | None = None,
        unsupported: bool = False,
        records: Iterable[T] = (),
    ) -> QueryResult[T]:
        """Build a fail-closed local result when no valid terminal packet exists."""
        return cls(
            request_type=request_type,
            request_id=request_id,
            connection_generation=connection_generation,
            account_fingerprint=account_fingerprint,
            started_at_utc=started_at_utc,
            completed_at_utc=datetime.now(started_at_utc.tzinfo),
            is_last_seen=False,
            error_code=error_code,
            error_message=error_message,
            timed_out=False,
            complete=False,
            records=tuple(records),
            unsupported=unsupported,
        )


__all__ = ["QueryResult", "QUERY_COMPLETION_ORIGINS"]
