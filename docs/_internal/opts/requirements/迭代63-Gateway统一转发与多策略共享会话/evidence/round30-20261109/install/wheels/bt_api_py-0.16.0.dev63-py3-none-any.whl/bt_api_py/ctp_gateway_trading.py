"""Trusted-code composition for one CTP Gateway trading-owner profile.

Factories are installed-code closures, never imported from a manifest. This
module creates no session or native resource while building a profile. The
account owner thread alone owns the CTP session, guard and dispatcher. The
local guard is not a cross-host fence or proof of external account state.
"""

from __future__ import annotations

import math
import os
import re
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any

from bt_api_base.account_protocol import (
    AccountKey,
    AccountResourceKey,
    account_venue_contains_instrument_venue,
)
from bt_api_base.market_protocol import MarketInstrumentKey, MarketSubscriptionKey
from bt_api_base.service_protocol import WireRole, WireScope
from bt_api_gateway.direct_command_journal import GatewayDirectCommandJournal
from bt_api_gateway.session_guard import LocalAccountSessionGuard

from bt_api_py.direct_write import DirectWriteCoordinator
from bt_api_py.gateway_direct_dispatch import (
    compose_gateway_direct_cancel_dispatcher,
    compose_gateway_direct_dispatcher,
)
from bt_api_py.gateway_direct_owner import (
    GatewayDirectOwner,
    GatewayDirectOwnerResources,
    GatewayOwnerStartupCleanupError,
)
from bt_api_py.gateway_direct_service import (
    ACCOUNT_READ_OPERATIONS,
    INSTRUMENT_OPERATIONS,
    CANCEL_OPERATIONS,
    EVENT_OPERATIONS,
    MARKET_OPERATIONS,
    GatewayDirectGrant,
    GatewayDirectServiceBinding,
)
from bt_api_py.gateway_operator import GatewayOperatorDeployment
from bt_api_py.gateway_operator_application import GatewayOperatorProfile
from bt_api_py.gateway_settlement import (
    GatewaySettlementController,
    GatewaySettlementObservationStaleError,
)
from bt_api_py.service_components import ComponentResources, ServiceResourceConstructionError
from bt_api_py.service_config import ServiceConfig
from bt_api_py.service_host import TrustedServiceAuthority
from bt_api_py.service_registry import PrincipalGrant, ResourceGrant
from bt_api_py.write_admission import WriteAdmission

ROUTE = "CTP___FUTURE"
_OPERATIONS = (
    frozenset({"direct.reserve", "direct.release", "direct.command_status", "direct.dispatch"})
    | EVENT_OPERATIONS
)
_READ_OPERATIONS = ACCOUNT_READ_OPERATIONS | INSTRUMENT_OPERATIONS
_MARKET_OPERATIONS = MARKET_OPERATIONS - {"market.history"}


class CtpGatewayTradingError(RuntimeError):
    """Finite composition/cleanup error without account, path or secret values."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _connection_transition_error(error: Exception, *, account_read: bool = False) -> bool:
    """Recognize finite errors a CTP session change can actually cause.

    Classification alone never authorizes a retry: the caller also checks the
    exact provider session and its current connection state or generation.
    """
    from bt_api_ctp.account_provider import CtpAccountSessionProviderError
    from bt_api_ctp.gateway_return_query import CtpGatewayReturnQueryError
    from bt_api_ctp.gateway_session import CtpGatewaySessionError

    if type(error) is CtpGatewaySessionError:
        return error.code in {"SESSION_CHANGED", "SESSION_NOT_CONNECTED", "SESSION_UNAVAILABLE"}
    if type(error) is CtpGatewayReturnQueryError:
        return error.code == "SESSION_CHANGED"
    if type(error) is CtpAccountSessionProviderError:
        return error.code in {"SESSION_NOT_CONNECTED", "SESSION_SCOPE_UNTRUSTED", "QUERY_SCOPE_CHANGED"} or (
            account_read and error.code in {"QUERY_FAILED", "QUERY_INCOMPLETE"}
        )
    if type(error) is CtpGatewayTradingError:
        return error.code == "CTP_SESSION_BINDING_INVALID"
    if type(error) is GatewaySettlementObservationStaleError:
        return True
    return False


def _ref(value: object) -> bool:
    return type(value) is str and bool(value) and value == value.strip() and len(value) <= 256


def _absolute(value: object) -> bool:
    try:
        return isinstance(value, (str, os.PathLike)) and os.path.isabs(os.fspath(value))
    except (TypeError, ValueError):
        return False


def _duration(value: object, *, minimum: float = 0.001, maximum: float = 3600) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and minimum <= value <= maximum


@dataclass(frozen=True, slots=True)
class CtpGatewayTradingSettings:
    account_key: AccountKey = field(repr=False)
    account_scope: str
    guard_root: str | Path
    owner_id: str
    journal_path: str | Path
    expected_journal_id: str
    minimum_revision: int
    trusted_flow_root: str | Path
    market_source_ref: str
    market_entitlement_ref: str
    write_enabled: bool = False
    startup_timeout_seconds: float = 30.0
    close_timeout_seconds: float = 5.0
    connect_timeout_seconds: float = 30.0
    session_stop_timeout_seconds: float = 3.0
    maintenance_interval_seconds: float = 1.0
    queue_size: int = 128
    max_queue_wait_seconds: float = 30.0
    busy_timeout_seconds: float = 30.0
    session_queue_capacity: int = 1024
    journal_max_records: int = 100000
    journal_timeout_seconds: float = 5.0

    def __post_init__(self) -> None:
        key = self.account_key
        if (
            type(key) is not AccountKey
            or (key.provider, key.venue, key.environment) != ("ctp", "simnow", "simnow")
            or not _ref(key.account_id)
            or not _ref(key.subaccount_id)
            or self.account_scope != key.account_key_id
            or not all(
                _ref(item)
                for item in (
                    self.account_scope,
                    self.owner_id,
                    self.expected_journal_id,
                    self.market_source_ref,
                    self.market_entitlement_ref,
                )
            )
            or not all(
                _absolute(path)
                for path in (self.guard_root, self.journal_path, self.trusted_flow_root)
            )
            or type(self.minimum_revision) is not int
            or self.minimum_revision < 0
            or type(self.write_enabled) is not bool
            or type(self.queue_size) is not int
            or not 1 <= self.queue_size <= 10000
            or type(self.session_queue_capacity) is not int
            or not 1 <= self.session_queue_capacity <= 65536
            or type(self.journal_max_records) is not int
            or not 1 <= self.journal_max_records <= 1000000
            or not all(
                _duration(item)
                for item in (
                    self.startup_timeout_seconds,
                    self.close_timeout_seconds,
                    self.maintenance_interval_seconds,
                    self.max_queue_wait_seconds,
                    self.busy_timeout_seconds,
                )
            )
            or not _duration(self.connect_timeout_seconds, minimum=0.05, maximum=300)
            or not _duration(self.session_stop_timeout_seconds, minimum=0.05, maximum=30)
            or not _duration(self.journal_timeout_seconds, maximum=60)
        ):
            raise CtpGatewayTradingError("INVALID_TRADING_SETTINGS")


@dataclass(frozen=True, slots=True)
class CtpGatewayAccountReadSettings:
    journal_path: str | Path
    state_scope: str
    required_coverage: tuple[AccountResourceKey, ...]
    observation_identity_path: str | Path
    expected_observation_issuer_id: str
    observation_instruments: tuple[MarketInstrumentKey, ...]
    refresh_interval_seconds: float = 1.0
    max_staleness_seconds: float = 5.0
    request_timeout_seconds: float = 2.0

    def __post_init__(self) -> None:
        if (
            not _absolute(self.journal_path)
            or not _absolute(self.observation_identity_path)
            or not _ref(self.state_scope)
            or not _ref(self.expected_observation_issuer_id)
            or type(self.required_coverage) is not tuple
            or not self.required_coverage
            or any(type(item) is not AccountResourceKey for item in self.required_coverage)
            or len(set(self.required_coverage)) != len(self.required_coverage)
            or type(self.observation_instruments) is not tuple
            or not 1 <= len(self.observation_instruments) <= 256
            or any(
                type(item) is not MarketInstrumentKey
                or item.provider != "ctp"
                or item.product_type != "future"
                or item.native_symbol != item.instrument_id
                for item in self.observation_instruments
            )
            or len({(item.venue, item.instrument_id) for item in self.observation_instruments})
            != len(self.observation_instruments)
            or not all(
                _duration(item, minimum=0.05, maximum=300)
                for item in (
                    self.refresh_interval_seconds,
                    self.max_staleness_seconds,
                    self.request_timeout_seconds,
                )
            )
        ):
            raise CtpGatewayTradingError("INVALID_ACCOUNT_READ_SETTINGS")


@dataclass(frozen=True, slots=True)
class CtpGatewayMarketSettings:
    key_universe: frozenset[MarketSubscriptionKey]
    principal_allowed_keys: Mapping[str, frozenset[MarketSubscriptionKey]] = field(repr=False)
    max_provider_events_per_maintain: int = 32
    call_timeout_seconds: float = 5.0
    owner_queue_size: int = 32

    def __post_init__(self) -> None:
        try:
            if (
                type(self.key_universe) is not frozenset
                or not 1 <= len(self.key_universe) <= 1024
                or any(type(key) is not MarketSubscriptionKey for key in self.key_universe)
                or not isinstance(self.principal_allowed_keys, Mapping)
                or not self.principal_allowed_keys
                or type(self.max_provider_events_per_maintain) is not int
                or not 1 <= self.max_provider_events_per_maintain <= 256
                or not _duration(self.call_timeout_seconds, maximum=30)
                or type(self.owner_queue_size) is not int
                or not 1 <= self.owner_queue_size <= 10000
            ):
                raise ValueError
            keys = frozenset(
                MarketSubscriptionKey.from_dict(k.to_dict()) for k in self.key_universe
            )
            acl = {}
            for principal, allowed in self.principal_allowed_keys.items():
                if (
                    type(principal) is not str
                    or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}", principal, re.ASCII)
                    is None
                    or type(allowed) is not frozenset
                    or not allowed
                    or any(type(k) is not MarketSubscriptionKey for k in allowed)
                    or not allowed <= self.key_universe
                ):
                    raise ValueError
                acl[principal] = frozenset(
                    MarketSubscriptionKey.from_dict(k.to_dict()) for k in allowed
                )
            object.__setattr__(self, "key_universe", keys)
            object.__setattr__(self, "principal_allowed_keys", MappingProxyType(acl))
        except Exception:
            raise CtpGatewayTradingError("INVALID_MARKET_SETTINGS") from None


@dataclass(frozen=True, slots=True)
class CtpGatewayReturnSettings:
    instruments: tuple[MarketInstrumentKey, ...]
    query_timeout_seconds: float = 0.5
    query_interval_seconds: float = 30.0
    callback_batch_limit: int = 256

    def __post_init__(self) -> None:
        if (
            type(self.instruments) is not tuple
            or not 1 <= len(self.instruments) <= 256
            or any(
                type(item) is not MarketInstrumentKey
                or item.provider != "ctp"
                or item.product_type != "future"
                or item.native_symbol != item.instrument_id
                for item in self.instruments
            )
            or len({(item.venue, item.instrument_id) for item in self.instruments})
            != len(self.instruments)
            or not _duration(self.query_timeout_seconds, minimum=0.05, maximum=5)
            or not _duration(self.query_interval_seconds, minimum=0.05, maximum=3600)
            or type(self.callback_batch_limit) is not int
            or not 1 <= self.callback_batch_limit <= 256
        ):
            raise CtpGatewayTradingError("INVALID_RETURN_SETTINGS")


def _distinct_journals(left: str | Path, right: str | Path) -> bool:
    try:
        if Path(left).resolve() == Path(right).resolve():
            return False
        return not (
            os.path.exists(left) and os.path.exists(right) and os.path.samefile(left, right)
        )
    except (OSError, RuntimeError, ValueError):
        return False


def _validate_config(
    config: ServiceConfig,
    authority: TrustedServiceAuthority,
    settings: CtpGatewayTradingSettings,
    grants: Mapping[str, GatewayDirectGrant],
    read_settings: CtpGatewayAccountReadSettings | None,
    read_principals: frozenset[str],
    market_settings: CtpGatewayMarketSettings | None,
) -> str:
    if type(config) is not ServiceConfig or type(authority) is not TrustedServiceAuthority:
        raise CtpGatewayTradingError("INVALID_TRADING_CONFIGURATION")
    try:
        config.to_public_dict()
        components = config.components
        item = components["gateway"]["settings"]
        options = item["options"]
        normalized_options = dict(options)
        normalized_options.setdefault("cancel_enabled", False)
        if market_settings is not None:
            normalized_options.setdefault("bounded_read_after", False)
        cancel_enabled = normalized_options.get("cancel_enabled")
        bounded = normalized_options.get("bounded_read_after", False)
        expected_options = {
            "role": "trading_owner",
            "dispatch_enabled": True,
            "cancel_enabled": cancel_enabled,
        }
        if market_settings is not None:
            expected_options["bounded_read_after"] = bounded
        market_principals = (
            set() if market_settings is None else set(market_settings.principal_allowed_keys)
        )
        all_principals = set(grants) | set(read_principals) | market_principals
        instance = item["instance_id"]
        if (
            set(components) != {"gateway"}
            or frozenset(item["bind_ports"])
            != (
                frozenset({"service.direct_write"})
                | ({"service.account_read"} if read_settings is not None else set())
                | ({"service.market_source"} if market_settings is not None else set())
            )
            or len(item["bind_ports"]) != len(set(item["bind_ports"]))
            or type(cancel_enabled) is not bool
            or type(bounded) is not bool
            or normalized_options != expected_options
            or not _ref(instance)
            or config.clients
            or config.service_id != authority.identity.actor_ref
            or config.scope_ref != authority.scope_ref
            or config.registration_policy_ref != authority.registration_policy_ref
            or config.service_requirements_ref != authority.service_requirements_ref
            or not isinstance(grants, Mapping)
            or not grants
            or all_principals != set(authority.principals.values())
            or all_principals != set(authority.grants)
        ):
            raise ValueError
        for principal in all_principals:
            grant = grants.get(principal)
            if not _ref(principal) or (grant is not None and type(grant) is not GatewayDirectGrant):
                raise ValueError
            entries = authority.grants[principal]
            if not entries or len({entry.identity for entry in entries}) != 1:
                raise ValueError
            for entry in entries:
                if (
                    type(entry) is not PrincipalGrant
                    or entry.identity.role
                    not in {WireRole.STRATEGY_CLIENT, WireRole.APPLICATION_CLIENT}
                    or entry.identity.principal_ref != principal
                    or entry.identity.delegate_ref is not None
                    or not entry.resources
                ):
                    raise ValueError
                for resource in entry.resources:
                    scope = resource.scope
                    if (
                        type(resource) is not ResourceGrant
                        or type(scope) is not WireScope
                        or resource.instance_id != instance
                        or resource.port
                        not in {
                            "service.direct_write",
                            "service.account_read",
                            "service.market_source",
                        }
                        or resource.scope_ref != config.scope_ref
                        or scope.execution_domain_ref != authority.scope.execution_domain_ref
                        or scope.account_ref != settings.account_scope
                        or scope.account_refs
                        or scope.portfolio_ref is not None
                        or scope.manual_book_ref is not None
                        or scope.group_id is not None
                        or scope.leg_id is not None
                    ):
                        raise ValueError
                    if resource.port == "service.direct_write":
                        if (
                            grant is None
                            or entry.identity.role is not WireRole.STRATEGY_CLIENT
                            or entry.identity.actor_ref != grant.strategy_ref
                            or scope.strategy_ref != grant.strategy_ref
                            or not resource.operations
                            <= (_OPERATIONS | CANCEL_OPERATIONS if cancel_enabled else _OPERATIONS)
                        ):
                            raise ValueError
                    elif resource.port == "service.account_read" and (
                        principal not in read_principals
                        or read_settings is None
                        or not resource.operations <= _READ_OPERATIONS
                        or (bool(resource.operations & INSTRUMENT_OPERATIONS)
                            and (not INSTRUMENT_OPERATIONS <= resource.operations
                                 or entry.identity.role is not WireRole.STRATEGY_CLIENT))
                        or scope.strategy_ref
                        != (
                            entry.identity.actor_ref
                            if entry.identity.role is WireRole.STRATEGY_CLIENT
                            else None
                        )
                    ):
                        raise ValueError
                    elif resource.port == "service.market_source" and (
                        principal not in market_principals
                        or not resource.operations
                        <= (
                            _MARKET_OPERATIONS
                            if bounded
                            else _MARKET_OPERATIONS - {"market.read_after_bounded"}
                        )
                        or scope.strategy_ref
                        != (
                            entry.identity.actor_ref
                            if entry.identity.role is WireRole.STRATEGY_CLIENT
                            else None
                        )
                    ):
                        raise ValueError
            ports = {resource.port for entry in entries for resource in entry.resources}
            if (principal in grants) != ("service.direct_write" in ports) or (
                principal in read_principals
            ) != ("service.account_read" in ports):
                raise ValueError
            if (principal in market_principals) != ("service.market_source" in ports):
                raise ValueError
            if principal in market_principals and not any(
                resource.port == "service.market_source"
                and "market.subscribe" in resource.operations
                for entry in entries
                for resource in entry.resources
            ):
                raise ValueError
        return instance
    except CtpGatewayTradingError:
        raise
    except Exception:
        raise CtpGatewayTradingError("INVALID_TRADING_CONFIGURATION") from None


def _load_ctp_types():
    """Resolve fixed provider code, only when the owner starts."""
    from bt_api_ctp.direct_write_provider import CtpDirectWriteProvider
    from bt_api_ctp.gateway_session import CtpGatewaySession

    return CtpGatewaySession, CtpDirectWriteProvider


def build_ctp_gateway_trading_profile(
    config: ServiceConfig,
    authority: TrustedServiceAuthority,
    registry_path: str | Path,
    *,
    profile_ref: str,
    settings: CtpGatewayTradingSettings,
    grants: Mapping[str, GatewayDirectGrant],
    request_feed_factory: Callable[..., object],
    market_stream_factory: Callable[..., object],
    assert_admitted: Callable[[Any], object],
    return_settings: CtpGatewayReturnSettings | None = None,
    account_read_settings: CtpGatewayAccountReadSettings | None = None,
    account_read_principals: frozenset[str] = frozenset(),
    market_settings: CtpGatewayMarketSettings | None = None,
) -> GatewayOperatorProfile:
    """Build a trusted profile; no guard, provider, native session or owner is started."""
    if type(settings) is not CtpGatewayTradingSettings or not _absolute(registry_path):
        raise CtpGatewayTradingError("INVALID_TRADING_SETTINGS")
    if not all(
        callable(item) for item in (request_feed_factory, market_stream_factory, assert_admitted)
    ):
        raise CtpGatewayTradingError("INVALID_TRUSTED_FACTORY")
    if (settings.write_enabled and return_settings is None) or (
        return_settings is not None
        and (
            type(return_settings) is not CtpGatewayReturnSettings
            or any(
                item.environment != settings.account_key.environment
                or not account_venue_contains_instrument_venue(settings.account_key, item.venue)
                for item in return_settings.instruments
            )
        )
    ):
        raise CtpGatewayTradingError("INVALID_RETURN_SETTINGS")
    if (
        type(account_read_principals) is not frozenset
        or any(not _ref(item) for item in account_read_principals)
        or (account_read_settings is None) != (not account_read_principals)
        or (
            account_read_settings is not None
            and (
                type(account_read_settings) is not CtpGatewayAccountReadSettings
                or not _distinct_journals(settings.journal_path, account_read_settings.journal_path)
                or not _distinct_journals(
                    settings.journal_path, account_read_settings.observation_identity_path
                )
                or not _distinct_journals(
                    account_read_settings.journal_path,
                    account_read_settings.observation_identity_path,
                )
                or any(
                    item.environment != settings.account_key.environment
                    or not account_venue_contains_instrument_venue(settings.account_key, item.venue)
                    for item in account_read_settings.observation_instruments
                )
            )
        )
    ):
        raise CtpGatewayTradingError("INVALID_ACCOUNT_READ_SETTINGS")
    if market_settings is not None:
        if type(market_settings) is not CtpGatewayMarketSettings:
            raise CtpGatewayTradingError("INVALID_MARKET_SETTINGS")
        try:
            from bt_api_ctp.market_key_contract import validate_ctp_market_key

            for key in market_settings.key_universe:
                validate_ctp_market_key(
                    key,
                    source_ref=settings.market_source_ref,
                    entitlement_ref=settings.market_entitlement_ref,
                )
        except Exception:
            raise CtpGatewayTradingError("INVALID_MARKET_SETTINGS") from None
        market_settings = CtpGatewayMarketSettings(
            market_settings.key_universe,
            market_settings.principal_allowed_keys,
            market_settings.max_provider_events_per_maintain,
            market_settings.call_timeout_seconds,
            market_settings.owner_queue_size,
        )
        if any(
            key.source_ref != settings.market_source_ref
            or key.entitlement_ref != settings.market_entitlement_ref
            or key.instrument.provider != "ctp"
            or key.instrument.environment != "simnow"
            or key.instrument.product_type != "future"
            or not account_venue_contains_instrument_venue(
                settings.account_key, key.instrument.venue
            )
            for key in market_settings.key_universe
        ):
            raise CtpGatewayTradingError("INVALID_MARKET_SETTINGS")
    instance = _validate_config(
        config,
        authority,
        settings,
        grants,
        account_read_settings,
        account_read_principals,
        market_settings,
    )
    cancel_enabled = config.components["gateway"]["settings"]["options"].get(
        "cancel_enabled", False
    )
    static_grants = MappingProxyType(dict(grants))

    def resources(
        component: str, instance_id: str, options: Mapping[str, object], scope: WireScope
    ):
        normalized_options = dict(options)
        normalized_options.setdefault("cancel_enabled", False)
        expected_options = {
            "role": "trading_owner",
            "dispatch_enabled": True,
            "cancel_enabled": cancel_enabled,
        }
        if market_settings is not None:
            normalized_options.setdefault("bounded_read_after", False)
            expected_options["bounded_read_after"] = config.components["gateway"]["settings"][
                "options"
            ].get("bounded_read_after", False)
        if (
            component != "gateway"
            or instance_id != instance
            or normalized_options != expected_options
            or type(scope) is not WireScope
            or scope != authority.scope
        ):
            raise CtpGatewayTradingError("INVALID_TRADING_CONFIGURATION")
        holder: dict[str, Any] = {}
        closing = threading.Event()

        def owner_factory():
            guard = session = read_model = issuer = issuer_cleanup = None
            session_closed = False
            guard_closed = False
            read_closed = False
            issuer_closed = False

            def cleanup():
                nonlocal session_closed, guard_closed, read_closed, issuer_closed
                closing.set()
                deadline = time.monotonic() + settings.close_timeout_seconds
                returns = holder.get("returns")
                if returns is not None:
                    returns.begin_close()
                stream = holder.get("execution_stream")
                if stream is not None:
                    stream.begin_close()
                if returns is not None and not returns.close(max(0.0, deadline - time.monotonic())):
                    raise CtpGatewayTradingError("TRADING_GATE_CLOSE_UNCONFIRMED")
                if stream is not None and not stream.close(max(0.0, deadline - time.monotonic())):
                    raise CtpGatewayTradingError("EXECUTION_STREAM_CLOSE_UNCONFIRMED")
                instrument_service = holder.get("instrument_service")
                if instrument_service is not None and instrument_service.cleanup_on_owner() is not True:
                    raise CtpGatewayTradingError("INSTRUMENT_CLEANUP_UNCONFIRMED")
                if read_model is not None and not read_closed:
                    read_model.close()
                    read_closed = True
                if session is not None and not session_closed:
                    if session.close() is not True:
                        raise CtpGatewayTradingError("CTP_SESSION_CLOSE_UNCONFIRMED")
                    session_closed = True
                if issuer is not None and not issuer_closed:
                    issuer.close()
                    issuer_closed = True
                if issuer_cleanup is not None and not issuer_closed:
                    issuer_cleanup.close()
                    issuer_closed = True
                if guard is not None and not guard_closed:
                    guard.release()
                    guard_closed = True

            try:
                guard = LocalAccountSessionGuard(
                    Path(settings.guard_root), settings.account_scope, settings.owner_id
                )
                generation = guard.acquire()
                if account_read_settings is not None:
                    from bt_api_py.order_correlation_issuer import (
                        DurableOrderCorrelationIssuer,
                        OrderCorrelationIssuerCleanupError,
                    )

                    if any(
                        not _distinct_journals(a, b)
                        for a, b in (
                            (settings.journal_path, account_read_settings.journal_path),
                            (
                                settings.journal_path,
                                account_read_settings.observation_identity_path,
                            ),
                            (
                                account_read_settings.journal_path,
                                account_read_settings.observation_identity_path,
                            ),
                        )
                    ):
                        raise CtpGatewayTradingError("INVALID_ACCOUNT_READ_SETTINGS")
                    try:
                        issuer = DurableOrderCorrelationIssuer.open_existing(
                            account_read_settings.observation_identity_path,
                            expected_issuer_id=account_read_settings.expected_observation_issuer_id,
                        )
                    except OrderCorrelationIssuerCleanupError as error:
                        issuer_cleanup = error
                        raise
                journal = GatewayDirectCommandJournal(
                    settings.journal_path,
                    settings.account_scope,
                    generation=generation,
                    expected_journal_id=settings.expected_journal_id,
                    minimum_revision=settings.minimum_revision,
                    max_records=settings.journal_max_records,
                    timeout_seconds=settings.journal_timeout_seconds,
                )
                session_type, provider_type = _load_ctp_types()
                observation_options = (
                    {}
                    if account_read_settings is None
                    else {
                        "observation_issuer": issuer,
                        "observation_instruments": account_read_settings.observation_instruments,
                    }
                )
                session = session_type(
                    settings.account_key,
                    request_feed_factory,
                    market_stream_factory,
                    trusted_flow_root=settings.trusted_flow_root,
                    flow_account_scope=settings.account_scope,
                    source_ref=settings.market_source_ref,
                    entitlement_ref=settings.market_entitlement_ref,
                    connect_timeout_seconds=settings.connect_timeout_seconds,
                    stop_timeout_seconds=settings.session_stop_timeout_seconds,
                    queue_capacity=settings.session_queue_capacity,
                    **observation_options,
                )
                session.connect(generation=generation, timeout=settings.connect_timeout_seconds)
                holder["session"] = session
                provider = session.direct_provider
                account_binding = session.account_binding
                if type(provider) is not provider_type or not _ref(account_binding):
                    raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                admission = WriteAdmission({ROUTE: settings.write_enabled})
                coordinator = DirectWriteCoordinator(
                    admission, lambda route: provider if route == ROUTE else None
                )
                if coordinator.provider(ROUTE) is not provider:
                    raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                state: dict[str, Any] = {}

                if return_settings is not None:
                    from bt_api_py.ctp_gateway_return_maintenance import CtpGatewayReturnMaintenance

                    state["returns"] = CtpGatewayReturnMaintenance(
                        session, provider, journal, guard, settings.account_key, return_settings
                    )
                    holder["returns"] = state["returns"]
                    holder["execution_stream"] = state["returns"].create_execution_stream(
                        journal,
                        {key: grant.strategy_ref for key, grant in static_grants.items()},
                        execution_domain_ref=authority.scope.execution_domain_ref,
                    )

                def gate(record):
                    return (
                        admission.is_enabled(ROUTE)
                        and state["controller"].ready
                        and state.get("returns") is not None
                        and state["returns"].dispatch_ready()
                        and assert_admitted(record) is True
                    )

                dispatcher = compose_gateway_direct_dispatcher(
                    coordinator,
                    ROUTE,
                    journal,
                    guard,
                    gate,
                    expected_local_provider=provider,
                    prepared_place=True,
                )
                cancel_dispatcher = None
                if cancel_enabled:

                    def cancel_gate(_record):
                        if (
                            closing.is_set()
                            or not admission.is_enabled(ROUTE)
                            or coordinator.provider(ROUTE) is not provider
                            or session.connection_status() != "ready"
                        ):
                            return False
                        provider.assert_cancel_ready(expected_account_binding=account_binding)
                        native_generation = provider.session_generation()
                        return (
                            not closing.is_set()
                            and type(native_generation) is int
                            and 0 < native_generation < 2**63
                        )

                    cancel_dispatcher = compose_gateway_direct_cancel_dispatcher(
                        coordinator,
                        ROUTE,
                        journal,
                        guard,
                        dispatcher,
                        cancel_gate,
                        expected_local_provider=provider,
                    )
                controller = GatewaySettlementController(
                    coordinator,
                    ROUTE,
                    expected_local_provider=provider,
                    expected_account_binding=session.account_binding,
                    journal=journal,
                    dispatcher=dispatcher,
                )
                state["controller"] = controller
                holder["journal"] = journal

                if account_read_settings is not None:
                    from bt_api_gateway.account_read_model import GatewayAccountReadModel
                    from bt_api_gateway.event_journal import GatewayEventJournal

                    if not _distinct_journals(
                        settings.journal_path, account_read_settings.journal_path
                    ):
                        raise CtpGatewayTradingError("INVALID_ACCOUNT_READ_SETTINGS")
                    read_journal = GatewayEventJournal(account_read_settings.journal_path)
                    native_generation = provider.session_generation()
                    read_epoch = generation

                    def assert_current_generation(candidate):
                        dispatcher.assert_owned()
                        session.refresh_session()
                        if (
                            candidate != read_epoch
                            or session.account_binding != account_binding
                            or provider.session_generation() != native_generation
                        ):
                            raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")

                    def assert_read_recoverable():
                        dispatcher.assert_owned()
                        session.refresh_session()
                        if session.account_binding != account_binding or (
                            provider.session_generation() != native_generation
                            and state.get("returns") is None
                        ):
                            raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")

                    read_model = GatewayAccountReadModel(
                        read_journal,
                        account_key=settings.account_key,
                        journal_account_scope=settings.account_scope,
                        state_scope=account_read_settings.state_scope,
                        required_coverage=account_read_settings.required_coverage,
                        assert_current_generation=assert_current_generation,
                        refresh_interval_seconds=account_read_settings.refresh_interval_seconds,
                        max_staleness_seconds=account_read_settings.max_staleness_seconds,
                        request_timeout_seconds=account_read_settings.request_timeout_seconds,
                        require_open_orders=True,
                    )
                    read_model.start_generation(read_epoch)
                    holder["read_model"] = read_model
                    holder["read_journal"] = read_journal
                next_read = 0.0
                next_choice = "returns"
                read_rebind_pending = False
                read_rebind_attempt = 0
                last_confirmed_generation = provider.session_generation()
                if (type(last_confirmed_generation) is not int
                        or not 0 < last_confirmed_generation < 2**63):
                    raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")

                def connection_sample():
                    """Classify the exact session; no provider connection or native I/O."""
                    def status_or_reject():
                        try:
                            return session.connection_status()
                        except Exception:
                            # The provider returns explicit reconnecting/busy
                            # states; its exception means the exact source or
                            # immutable binding failed, never a retry token.
                            raise CtpGatewayTradingError("CTP_CONNECTION_PROBE_INVALID") from None

                    status = status_or_reject()
                    if status in {"reconnecting", "busy"}:
                        return status, None
                    if status != "ready":
                        raise CtpGatewayTradingError("CTP_CONNECTION_PROBE_INVALID")
                    first = provider.session_generation()
                    status = status_or_reject()
                    if status in {"reconnecting", "busy"}:
                        return status, None
                    second = provider.session_generation()
                    if (status != "ready" or type(first) is not int or type(second) is not int
                            or not 0 < first <= second < 2**63):
                        raise CtpGatewayTradingError("CTP_CONNECTION_PROBE_INVALID")
                    if second != first:
                        return "changed", second
                    return "ready", second

                def pause_for_reconnect():
                    # Neither the owner, its guard, nor its exact session is
                    # released; old account and write evidence is revoked.
                    returns = state.get("returns")
                    if returns is not None:
                        returns.pause_for_reconnect()
                    controller.invalidate()
                    if read_model is not None:
                        read_model.invalidate()

                def read_failure_is_recoverable(error, before):
                    from bt_api_ctp.account_provider import CtpAccountSessionProviderError

                    if not _connection_transition_error(error, account_read=True):
                        raise error
                    status, current = connection_sample()
                    if status != "ready" or current != before:
                        raise error
                    if (type(error) is CtpAccountSessionProviderError
                            and error.code in {"QUERY_FAILED", "QUERY_INCOMPLETE"}):
                        assert_read_recoverable()
                        return
                    raise error

                def maintain_tick(before):
                    nonlocal next_read, next_choice, native_generation, read_epoch
                    nonlocal read_rebind_pending, read_rebind_attempt
                    session.refresh_session()
                    if read_model is not None:
                        current_native = provider.session_generation()
                        if current_native != native_generation or read_rebind_pending:
                            read_rebind_pending = True
                            read_rebind_attempt += 1
                            read_model.invalidate()
                            if state.get("returns") is not None:
                                state["returns"].refresh_generation()
                            native_generation = current_native
                            read_epoch = f"{generation}:native:{current_native}:attempt:{read_rebind_attempt}"
                            read_model.start_generation(read_epoch)
                            read_rebind_pending = False
                            next_read = 0.0
                        assert_current_generation(read_epoch)
                    controller.tick()
                    returns = state.get("returns")
                    if returns is not None:
                        returns.poll()
                    now = time.monotonic()
                    read_due = read_model is not None and now >= next_read
                    return_due = returns is not None and returns.due(now)
                    choose_read = next_choice == "read" if read_due and return_due else read_due
                    if choose_read:
                        next_choice = "returns"
                        state["account_read_active"] = True
                        token = read_model.begin_refresh()
                        try:
                            observation = session.read_account(
                                generation=generation,
                                timeout=account_read_settings.request_timeout_seconds,
                            )
                        except Exception as error:
                            read_model.fail_refresh(token)
                            read_failure_is_recoverable(error, before)
                        else:
                            try:
                                read_model.finish_refresh(token, observation)
                            except Exception as error:
                                read_failure_is_recoverable(error, before)
                        finally:
                            next_read = (
                                time.monotonic() + account_read_settings.refresh_interval_seconds
                            )
                        state["account_read_active"] = False
                    elif return_due:
                        next_choice = "read"
                        returns.query()

                def maintain():
                    nonlocal last_confirmed_generation
                    before = last_confirmed_generation
                    state["account_read_active"] = False
                    try:
                        status, current = connection_sample()
                        if status != "ready":
                            pause_for_reconnect()
                            if status == "changed":
                                if current <= last_confirmed_generation:
                                    raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                                last_confirmed_generation = current
                            return
                        if current < last_confirmed_generation:
                            raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                        if current > last_confirmed_generation:
                            pause_for_reconnect()
                            last_confirmed_generation = current
                            return
                        before = current
                        maintain_tick(before)
                        status, current = connection_sample()
                        if status != "ready" or current > before:
                            pause_for_reconnect()
                            if status == "changed" or (status == "ready" and current > before):
                                if current <= last_confirmed_generation:
                                    raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                                last_confirmed_generation = current
                            return
                        if current != before:
                            raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                        last_confirmed_generation = current
                    except Exception as error:
                        retry = False
                        if _connection_transition_error(
                            error, account_read=state["account_read_active"]
                        ):
                            try:
                                status, current = connection_sample()
                                retry = status in {"reconnecting", "busy", "changed"} or (
                                    status == "ready" and current > before
                                )
                            except Exception:
                                retry = False
                        if retry:
                            pause_for_reconnect()
                            if status in {"ready", "changed"}:
                                if current <= last_confirmed_generation:
                                    raise CtpGatewayTradingError("CTP_SESSION_BINDING_INVALID")
                                last_confirmed_generation = current
                            return
                        if state.get("returns") is not None:
                            state["returns"].begin_close()
                        if read_model is not None:
                            read_model.invalidate()
                        raise
                    except BaseException:
                        if state.get("returns") is not None:
                            state["returns"].begin_close()
                        if read_model is not None:
                            read_model.invalidate()
                        raise

                return GatewayDirectOwnerResources(
                    dispatcher,
                    journal,
                    cleanup,
                    maintain,
                    min(
                        settings.maintenance_interval_seconds,
                        account_read_settings.refresh_interval_seconds,
                    )
                    if account_read_settings is not None
                    else settings.maintenance_interval_seconds,
                    cancel_dispatcher=cancel_dispatcher,
                )
            except BaseException:
                raise GatewayOwnerStartupCleanupError(cleanup) from None

        owner = GatewayDirectOwner(
            owner_factory,
            queue_size=settings.queue_size,
            max_queue_wait_seconds=settings.max_queue_wait_seconds,
            busy_timeout_seconds=settings.busy_timeout_seconds,
            service_queue_size=32 if market_settings is None else market_settings.owner_queue_size,
        )

        def close_owner():
            closing.set()
            deadline = time.monotonic() + settings.close_timeout_seconds
            returns = holder.get("returns")
            if returns is not None:
                returns.begin_close()
            stream = holder.get("execution_stream")
            if stream is not None:
                stream.begin_close()
            if returns is not None and not returns.close(max(0.0, deadline - time.monotonic())):
                raise CtpGatewayTradingError("TRADING_OWNER_CLOSE_UNCONFIRMED")
            if stream is not None and not stream.close(max(0.0, deadline - time.monotonic())):
                raise CtpGatewayTradingError("TRADING_OWNER_CLOSE_UNCONFIRMED")
            remaining = deadline - time.monotonic()
            if remaining <= 0 or owner.close(remaining) is not True:
                raise CtpGatewayTradingError("TRADING_OWNER_CLOSE_UNCONFIRMED")

        def ready():
            status = owner.status()
            return status.thread_alive and owner.binding() is not None

        market_hub = market_proxy = None
        hub_closed = proxy_closed = False

        def close_resources():
            nonlocal hub_closed, proxy_closed
            closing.set()
            begin_error = None
            instrument_service = holder.get("instrument_service")
            if instrument_service is not None:
                instrument_service.begin_close()
                instrument_service.maintain_registrations(())
            if market_proxy is not None:
                try:
                    market_proxy.begin_close()
                except BaseException as exc:
                    begin_error = exc
            owner_error = None
            try:
                close_owner()
            except BaseException as exc:
                owner_error = exc
            if owner.closed:
                if market_proxy is not None and not proxy_closed:
                    try:
                        proxy_closed = market_proxy.close() is True
                    except BaseException:
                        pass
                if market_hub is not None and not hub_closed:
                    try:
                        market_hub.close()
                        hub_closed = True
                    except BaseException:
                        pass
            if (
                owner_error is not None
                or begin_error is not None
                or not owner.closed
                or (market_hub is not None and not hub_closed)
                or (market_proxy is not None and not proxy_closed)
            ):
                raise CtpGatewayTradingError("TRADING_OWNER_CLOSE_UNCONFIRMED")

        try:
            if owner.start(settings.startup_timeout_seconds) is not True:
                raise CtpGatewayTradingError("TRADING_OWNER_START_FAILED")
            journal = holder["journal"]
            returns = holder.get("returns")
            binding = GatewayDirectServiceBinding(
                journal,
                static_grants,
                owner=owner,
                reservation_fence=None if returns is None else returns.reservation_fence,
                execution_stream=holder.get("execution_stream"),
                execution_domain_ref=authority.scope.execution_domain_ref,
                cancel_enabled=cancel_enabled,
            )
            values = {"binding": binding}
            if market_settings is not None:
                from bt_api_gateway.market_hub import (
                    GatewayMarketHub,
                    MAX_TOTAL_MARKET_REPLAY_BYTES,
                )
                from bt_api_py.gateway_owner_market import GatewayOwnerMarketProvider

                market_proxy = GatewayOwnerMarketProvider(
                    owner,
                    lambda: holder["session"].market_provider,
                    call_timeout_seconds=market_settings.call_timeout_seconds,
                    max_handles=1024,
                )
                market_hub = GatewayMarketHub(
                    market_proxy,
                    key_universe=market_settings.key_universe,
                    principal_allowed_keys=market_settings.principal_allowed_keys,
                    service_identity=authority.identity,
                    service_scope=authority.scope,
                    provider_cleanup_confirmed=lambda: owner.closed,
                    max_replay_bytes=min(
                        256 * 1024,
                        MAX_TOTAL_MARKET_REPLAY_BYTES // len(market_settings.key_universe),
                    ),
                    max_provider_events_per_maintain=market_settings.max_provider_events_per_maintain,
                )
                values["hub"] = market_hub
            if account_read_settings is not None:
                from bt_api_gateway.router import GatewayCommandKind, GatewayPrincipal
                from bt_api_gateway.service_component import (
                    GatewayReadService,
                    GatewayServiceAccountScope,
                )

                principals = {}
                strategy_refs = set()
                for principal in account_read_principals:
                    identity = authority.grants[principal][0].identity
                    if identity.role is WireRole.STRATEGY_CLIENT:
                        strategy_refs.add(identity.actor_ref)
                    principals[principal] = GatewayPrincipal(
                        principal,
                        frozenset({settings.account_scope}),
                        frozenset({account_read_settings.state_scope}),
                        frozenset({GatewayCommandKind.READ}),
                    )
                account = GatewayServiceAccountScope(
                    account_ref=settings.account_scope,
                    execution_domain_ref=authority.scope.execution_domain_ref,
                    journal_account_scope=settings.account_scope,
                    account_read_strategy_scope=account_read_settings.state_scope,
                    shared_account_facts_scope=account_read_settings.state_scope
                    if strategy_refs
                    else None,
                    shared_fact_strategy_refs=frozenset(strategy_refs),
                )
                values["read_service"] = GatewayReadService(
                    holder["read_journal"],
                    accounts={settings.account_scope: account},
                    principals=principals,
                    state_worker=holder["read_model"],
                )
                from bt_api_py.gateway_instrument_service import GatewayInstrumentService

                instrument_service = GatewayInstrumentService(
                    owner, holder["session"], journal, values["read_service"],
                    account_read_settings.observation_instruments, account_read_principals,
                )
                holder["instrument_service"] = instrument_service
                values["instrument_service"] = instrument_service
            return ComponentResources.owned(values, ready=ready, close=close_resources)
        except BaseException:
            partial = ComponentResources.owned(
                {"binding": None}, ready=lambda: False, close=close_resources
            )
            raise ServiceResourceConstructionError(partial) from None

    def deployment_factory():
        try:
            return GatewayOperatorDeployment(
                config, authority, registry_path, resource_provider=resources
            )
        except Exception:
            raise CtpGatewayTradingError("TRADING_DEPLOYMENT_INVALID") from None

    try:
        return GatewayOperatorProfile(profile_ref, "trading_owner", deployment_factory)
    except Exception:
        raise CtpGatewayTradingError("INVALID_TRADING_PROFILE") from None
