"""Trusted CTP SimNow read-only account process binding.

This module is the SDK-side composition edge between the generic Gateway
account-process protocol and the CTP package.  Importing it does not load the
CTP native client; the native client is imported only by the spawned child (or
the market provider factory) after the profile reference has been accepted.

The selected deployment is deliberately narrow: one official SimNow profile,
account/position/order queries, and bounded native shutdown.  Trusted
application code selects the profile (``ctp_profile``) when it builds the
operator profile; the default stays the SimNow SET2 7x24 ``set2_7x24_4000x``
pair.  Profile names and fronts are the CTP provider's frozen facts
(``bt_api_ctp.ctp_env_selector``); this module only derives the reference
strings that bind one profile across processes.  The launch document can
select only a code-registered profile reference.  Credentials remain in the
inherited trusted process environment and never cross the child Pipe or
appear in a public status projection.

Market keys use the provider's neutral subscription channel ``"tick"``;
``"ctp.quote.v2"`` is the provider's payload schema, not a channel.
"""

from __future__ import annotations

import os
import re
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bt_api_base.account_protocol import AccountKey
from bt_api_gateway.account_process import (
    GatewayAccountSessionProcessBinding,
    GatewayAccountSessionProcessError,
    GatewayAccountSessionProcessProvider,
    GatewayAccountSessionProfileUnavailableError,
    serve_account_session_child,
)

from bt_api_py.gateway_operator_application import GatewayOperatorProfile

CTP_SIMNOW_SET2_7X24_PROFILE_REF = "ctp.simnow.set2-7x24.readonly.v1"
CTP_SIMNOW_SET2_7X24_SESSION_REF = "ctp.simnow.set2-7x24.account.v1"
CTP_SIMNOW_SET2_7X24_OPERATOR_PROFILE_REF = "ctp.simnow.set2-7x24.account-operator.v1"
CTP_SIMNOW_SET2_7X24_MARKET_OPERATOR_PROFILE_REF = "ctp.simnow.set2-7x24.market-operator.v1"
CTP_SIMNOW_SET2_7X24_MARKET_SOURCE_REF = "ctp-simnow-set2-7x24-market-v1"
CTP_SIMNOW_SET2_7X24_MARKET_ENTITLEMENT_REF = "ctp-simnow-set2-7x24-quote-v2-v1"
_CTP_SIMNOW_SET2_PROFILE = "set2_7x24_4000x"
#: Default SimNow profile of the Gateway CTP deployment (unchanged behaviour).
CTP_SIMNOW_GATEWAY_DEFAULT_PROFILE = _CTP_SIMNOW_SET2_PROFILE
#: The CTP market provider's neutral subscription channel. ``ctp.quote.v2`` is
#: the payload ``schema_version`` the provider projects, never a channel.
CTP_MARKET_TICK_CHANNEL = "tick"
#: Instrument environment of SimNow market keys: the SDK CTP route's verified
#: label for SimNow (iteration 62, I62-10). The read-only account identity keeps
#: the provider's own ``AccountKey(venue="simnow", environment="simnow")``.
CTP_SIMNOW_MARKET_ENVIRONMENT = "demo"
_PROFILE_NAME = re.compile(r"[a-z0-9]+(?:_[a-z0-9]+)*")
_PROFILE_REF = re.compile(r"ctp\.simnow\.profile\.([a-z0-9]+(?:-[a-z0-9]+)*)\.readonly\.v1")
_PROFILE_SESSION_REF = re.compile(
    r"ctp\.simnow\.profile\.([a-z0-9]+(?:-[a-z0-9]+)*)\.account\.v1"
)
_CONNECT_TIMEOUT_SECONDS = 15.0
_ACCOUNT_RESOURCE_PRODUCT = "future"
_ACCOUNT_RESOURCE_MARGIN = "futures"
_ACCOUNT_REFRESH_INTERVAL_SECONDS = 5.0
_ACCOUNT_MAX_STALENESS_SECONDS = 30.0
_ACCOUNT_REQUEST_TIMEOUT_SECONDS = 45.0


class CtpSimNowAccountProfileError(RuntimeError):
    """Finite local configuration failure; never carries account values."""

    _CODES = frozenset({"PROFILE_REF_UNAVAILABLE", "ACCOUNT_IDENTITY_UNAVAILABLE"})

    def __init__(self, code: str) -> None:
        if type(code) is not str or code not in self._CODES:
            code = "ACCOUNT_IDENTITY_UNAVAILABLE"
        self.code = code
        super().__init__(code)


@dataclass(frozen=True, slots=True)
class CtpSimNowGatewayRefs:
    """Reference strings that bind one SimNow profile across Gateway processes.

    The default profile keeps its historical ``set2-7x24`` references
    byte-for-byte. Every other provider-known profile gets the canonical
    ``ctp.simnow.profile.<name>`` family, so one reference never names two
    profiles. A reference is a binding label, not proof of reachability,
    account identity or any permission.
    """

    ctp_profile: str
    profile_ref: str
    session_ref: str
    operator_profile_ref: str
    market_operator_profile_ref: str
    market_source_ref: str
    market_entitlement_ref: str


_DEFAULT_GATEWAY_REFS = CtpSimNowGatewayRefs(
    ctp_profile=_CTP_SIMNOW_SET2_PROFILE,
    profile_ref=CTP_SIMNOW_SET2_7X24_PROFILE_REF,
    session_ref=CTP_SIMNOW_SET2_7X24_SESSION_REF,
    operator_profile_ref=CTP_SIMNOW_SET2_7X24_OPERATOR_PROFILE_REF,
    market_operator_profile_ref=CTP_SIMNOW_SET2_7X24_MARKET_OPERATOR_PROFILE_REF,
    market_source_ref=CTP_SIMNOW_SET2_7X24_MARKET_SOURCE_REF,
    market_entitlement_ref=CTP_SIMNOW_SET2_7X24_MARKET_ENTITLEMENT_REF,
)


def _official_simnow_profile_fronts(ctp_profile: str) -> tuple[str, str]:
    """Return the provider's frozen front pair of one named SimNow profile.

    Only the provider's pure-Python profile table is imported; it loads no
    native client. Unknown or malformed names fail closed without echoing.
    """

    if (
        type(ctp_profile) is not str
        or not 0 < len(ctp_profile) <= 48
        or _PROFILE_NAME.fullmatch(ctp_profile) is None
    ):
        raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE")
    try:
        from bt_api_ctp.ctp_env_selector import official_simnow_fronts

        fronts = official_simnow_fronts(ctp_profile)
    except Exception:
        raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE") from None
    if (
        type(fronts) is not tuple
        or len(fronts) != 2
        or any(type(front) is not str or not front for front in fronts)
    ):
        raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE")
    return fronts


def ctp_simnow_gateway_refs(
    ctp_profile: str = CTP_SIMNOW_GATEWAY_DEFAULT_PROFILE,
) -> CtpSimNowGatewayRefs:
    """Return the Gateway references of one provider-known SimNow profile."""

    _official_simnow_profile_fronts(ctp_profile)
    if ctp_profile == _CTP_SIMNOW_SET2_PROFILE:
        return _DEFAULT_GATEWAY_REFS
    slug = ctp_profile.replace("_", "-")
    return CtpSimNowGatewayRefs(
        ctp_profile=ctp_profile,
        profile_ref=f"ctp.simnow.profile.{slug}.readonly.v1",
        session_ref=f"ctp.simnow.profile.{slug}.account.v1",
        operator_profile_ref=f"ctp.simnow.profile.{slug}.account-operator.v1",
        market_operator_profile_ref=f"ctp.simnow.profile.{slug}.market-operator.v1",
        market_source_ref=f"ctp-simnow-profile-{slug}-market-v1",
        market_entitlement_ref=f"ctp-simnow-profile-{slug}-tick-v1",
    )


def _gateway_refs_from_ref(value: object, *, session: bool) -> CtpSimNowGatewayRefs:
    """Invert one canonical profile/session reference, or refuse it."""

    if type(value) is not str:
        raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE")
    default_ref = (
        _DEFAULT_GATEWAY_REFS.session_ref if session else _DEFAULT_GATEWAY_REFS.profile_ref
    )
    if value == default_ref:
        return _DEFAULT_GATEWAY_REFS
    match = (_PROFILE_SESSION_REF if session else _PROFILE_REF).fullmatch(value)
    if match is None:
        raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE")
    refs = ctp_simnow_gateway_refs(match.group(1).replace("-", "_"))
    # One canonical reference per profile: the default profile's derived
    # spelling is refused so it cannot alias the historical references.
    if (refs.session_ref if session else refs.profile_ref) != value:
        raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE")
    return refs


def ctp_simnow_set2_account_key_from_environment() -> AccountKey:
    """Build the local account identity from the same variables CTP uses.

    Values remain inside trusted composition code.  This function never logs,
    formats, or returns them separately from the typed ``AccountKey``.
    """

    try:
        investor_id = os.environ.get("CTP_USER_ID", "").strip()
        broker_id = os.environ.get("CTP_BROKER_ID", "").strip()
    except Exception:
        raise CtpSimNowAccountProfileError("ACCOUNT_IDENTITY_UNAVAILABLE") from None
    if not investor_id or not broker_id:
        raise CtpSimNowAccountProfileError("ACCOUNT_IDENTITY_UNAVAILABLE")
    try:
        return AccountKey(
            provider="ctp",
            venue="simnow",
            environment="simnow",
            account_id=investor_id,
            subaccount_id=broker_id,
        )
    except Exception:
        raise CtpSimNowAccountProfileError("ACCOUNT_IDENTITY_UNAVAILABLE") from None


def create_ctp_simnow_set2_account_provider(
    profile_ref: str,
) -> GatewayAccountSessionProcessBinding:
    """Resolve the exact read-only CTP provider binding inside the child."""

    try:
        refs = _gateway_refs_from_ref(profile_ref, session=False)
        td_front, md_front = _official_simnow_profile_fronts(refs.ctp_profile)
        account_key = ctp_simnow_set2_account_key_from_environment()
    except CtpSimNowAccountProfileError:
        raise GatewayAccountSessionProfileUnavailableError() from None
    ctp_profile = refs.ctp_profile

    # Keep all CTP native imports and module discovery inside the child target.
    from bt_api_ctp.account_provider import CtpReadOnlyAccountSessionProvider
    from bt_api_ctp.feeds.live_ctp_feed import CtpRequestDataFuture

    def request_feed_factory() -> object:
        return CtpRequestDataFuture(
            broker_id=account_key.subaccount_id,
            user_id=account_key.account_id,
            td_front=td_front,
            md_front=md_front,
            ctp_env_profile=ctp_profile,
            require_ctp_profile=ctp_profile,
            auto_detect_fronts=False,
            auto_settlement_confirm=False,
            connect_timeout=_CONNECT_TIMEOUT_SECONDS,
        )

    provider = CtpReadOnlyAccountSessionProvider(
        request_feed_factory,
        stop_timeout_seconds=3.0,
    )
    return GatewayAccountSessionProcessBinding(account_key=account_key, provider=provider)


def project_ctp_native_stop_receipt(
    provider: object, expected_native_generation: int
) -> dict[str, object]:
    """Project the exact, complete native receipt for its CTP generation."""

    from bt_api_ctp.account_provider import CtpReadOnlyAccountSessionProvider
    from bt_api_ctp.ctp.client import CtpNativeStopReceipt

    if type(provider) is not CtpReadOnlyAccountSessionProvider:
        raise GatewayAccountSessionProcessError("NATIVE_RECEIPT_PROVIDER_INVALID")
    try:
        owner_created = provider.native_owner_created
        native_generation = provider.native_connection_generation
        receipt = provider.last_native_stop_receipt
    except Exception:
        raise GatewayAccountSessionProcessError("NATIVE_RECEIPT_UNAVAILABLE") from None
    if (
        owner_created is not True
        or type(expected_native_generation) is not int
        or expected_native_generation <= 0
        or type(native_generation) is not int
        or native_generation <= 0
        or native_generation != expected_native_generation
        or type(receipt) is not CtpNativeStopReceipt
        or type(receipt.connection_generation) is not int
        or receipt.connection_generation <= 0
        or receipt.connection_generation != native_generation
        or receipt.complete is not True
    ):
        raise GatewayAccountSessionProcessError("NATIVE_RECEIPT_UNCONFIRMED")
    return {
        "connection_generation": receipt.connection_generation,
        "join_required": receipt.join_required,
        "join_completed": receipt.join_completed,
        "native_released": receipt.native_released,
        "thread_alive": receipt.thread_alive,
        "timed_out": receipt.timed_out,
        "complete": receipt.complete,
    }


def project_ctp_native_startup_attempt(provider: object) -> dict[str, object]:
    """Project the fixed provider's failed-start API factory phase."""

    from bt_api_ctp.account_provider import CtpReadOnlyAccountSessionProvider
    from bt_api_ctp.ctp.client import CtpNativeStartupAttempt

    if type(provider) is not CtpReadOnlyAccountSessionProvider:
        raise GatewayAccountSessionProcessError("NATIVE_STARTUP_PROVIDER_INVALID")
    try:
        attempt = provider.native_startup_attempt
    except Exception:
        raise GatewayAccountSessionProcessError("NATIVE_STARTUP_ATTEMPT_UNAVAILABLE") from None
    if (
        type(attempt) is not CtpNativeStartupAttempt
        or attempt.phase not in {"preflight_no_owner", "factory_uncertain", "api_created"}
        or attempt.phase == "preflight_no_owner" and attempt.api_attempt_id is not None
        or attempt.phase != "preflight_no_owner"
        and (
            type(attempt.api_attempt_id) is not str
            or re.fullmatch(r"[0-9a-f]{32}", attempt.api_attempt_id, re.ASCII) is None
        )
    ):
        raise GatewayAccountSessionProcessError("NATIVE_STARTUP_ATTEMPT_INVALID")
    return {"api_attempt_id": attempt.api_attempt_id, "phase": attempt.phase}


def project_ctp_native_startup_stop_receipt(
    provider: object, expected_api_attempt_id: str
) -> dict[str, object]:
    """Project only the complete receipt for this provider's failed-start API."""

    from bt_api_ctp.account_provider import CtpReadOnlyAccountSessionProvider
    from bt_api_ctp.ctp.client import (
        CtpNativeStartupAttempt,
        CtpNativeStartupStopReceipt,
    )

    if type(provider) is not CtpReadOnlyAccountSessionProvider:
        raise GatewayAccountSessionProcessError("NATIVE_STARTUP_PROVIDER_INVALID")
    try:
        attempt = provider.native_startup_attempt
        receipt = provider.last_native_startup_stop_receipt
    except Exception:
        raise GatewayAccountSessionProcessError("NATIVE_STARTUP_RECEIPT_UNAVAILABLE") from None
    if (
        type(expected_api_attempt_id) is not str
        or re.fullmatch(r"[0-9a-f]{32}", expected_api_attempt_id, re.ASCII) is None
        or type(attempt) is not CtpNativeStartupAttempt
        or attempt.phase != "api_created"
        or attempt.api_attempt_id != expected_api_attempt_id
        or type(receipt) is not CtpNativeStartupStopReceipt
        or receipt.api_attempt_id != expected_api_attempt_id
        or receipt.outcome != "api_created_released"
        or receipt.connection_generation != 0
        or receipt.complete is not True
    ):
        raise GatewayAccountSessionProcessError("NATIVE_STARTUP_RECEIPT_UNCONFIRMED")
    return {
        "api_attempt_id": receipt.api_attempt_id,
        "outcome": receipt.outcome,
        "connection_generation": receipt.connection_generation,
        "native_released": receipt.native_released,
        "join_required": receipt.join_required,
        "join_completed": receipt.join_completed,
        "thread_alive": receipt.thread_alive,
        "timed_out": receipt.timed_out,
        "complete": receipt.complete,
    }


def ctp_simnow_set2_account_process_child(connection: Any) -> None:
    """Importable spawn target registered by trusted application code."""

    serve_account_session_child(
        connection,
        provider_factory=create_ctp_simnow_set2_account_provider,
        close_receipt_projector=project_ctp_native_stop_receipt,
        startup_attempt_projector=project_ctp_native_startup_attempt,
        startup_stop_receipt_projector=project_ctp_native_startup_stop_receipt,
    )


class CtpSimNowSet2AccountProcessOwner:
    """One-shot trusted owner that creates the bounded CTP child adapter.

    ``account_session_ref`` selects the SimNow profile through its canonical
    session reference (default: the historical SET2 7x24 reference).
    """

    def __init__(self, account_session_ref: str = CTP_SIMNOW_SET2_7X24_SESSION_REF) -> None:
        self._refs = _gateway_refs_from_ref(account_session_ref, session=True)
        self._account_session_ref = account_session_ref
        self._account_key = ctp_simnow_set2_account_key_from_environment()
        self._owner_thread = threading.get_ident()
        self._claimed = False

    @property
    def account_key(self) -> AccountKey:
        """Return the trusted identity for server-side binding construction."""

        self._check_owner()
        return self._account_key

    def create_provider(self, account_session_ref: str) -> GatewayAccountSessionProcessProvider:
        """Return exactly one process provider for the fixed session reference."""

        self._check_owner()
        if type(account_session_ref) is not str or account_session_ref != self._account_session_ref:
            raise CtpSimNowAccountProfileError("PROFILE_REF_UNAVAILABLE")
        if self._claimed:
            raise GatewayAccountSessionProcessError("SESSION_ALREADY_CLAIMED")
        self._claimed = True
        return GatewayAccountSessionProcessProvider(
            account_key=self._account_key,
            profile_ref=self._refs.profile_ref,
            child_target=ctp_simnow_set2_account_process_child,
            close_timeout_seconds=5.0,
        )

    def _check_owner(self) -> None:
        if threading.get_ident() != self._owner_thread:
            raise GatewayAccountSessionProcessError("PROCESS_WRONG_THREAD")


def _reject_unexpected_service_component(
    component: str, _instance_id: str, _options: Mapping[str, object], _scope: object
) -> object:
    """Fail closed if a CTP read-only profile grows beyond its Gateway role."""

    del component, _instance_id, _options, _scope
    from bt_api_py.gateway_operator import GatewayOperatorDeploymentError

    raise GatewayOperatorDeploymentError("INVALID_DEPLOYMENT_CONFIG")


def _gateway_profile_config(
    config: object,
    *,
    role: str,
    ports: frozenset[str],
    session_ref: str = CTP_SIMNOW_SET2_7X24_SESSION_REF,
) -> None:
    """Require one parsed Gateway component with the exact read-only role."""

    from bt_api_py.service_config import ServiceConfig

    if type(config) is not ServiceConfig or set(config.components) != {"gateway"}:
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID")
    if config.clients:
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID")
    gateway = config.components.get("gateway")
    if not isinstance(gateway, Mapping):
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID")
    settings = gateway.get("settings")
    if not isinstance(settings, Mapping):
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID")
    options = settings.get("options")
    raw_ports = settings.get("bind_ports")
    if (
        not isinstance(options, Mapping)
        or options.get("role") != role
        or type(raw_ports) not in (tuple, list)
        or frozenset(raw_ports) != ports
        or len(raw_ports) != len(ports)
    ):
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID")
    if role == "account_session_worker" and options.get("account_session_ref") != session_ref:
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID")


class GatewayOperatorAccountProfileError(RuntimeError):
    """Finite, value-free error while building one trusted CTP deployment."""

    _CODES = frozenset(
        {"SERVICE_CONFIG_INVALID", "TRUSTED_BINDING_INVALID", "MARKET_UNIVERSE_INVALID"}
    )

    def __init__(self, code: str) -> None:
        self.code = code if type(code) is str and code in self._CODES else "TRUSTED_BINDING_INVALID"
        super().__init__(self.code)


def build_ctp_simnow_set2_account_operator_profile(
    config: object,
    authority: object,
    registry_path: str | Path,
    *,
    journal: object,
    account_scope: object,
    principals: Mapping[str, object],
    guard_directory: str | Path,
    state_scope: str,
    owner_ref: str,
    ctp_profile: str = CTP_SIMNOW_GATEWAY_DEFAULT_PROFILE,
) -> GatewayOperatorProfile:
    """Build the read-only CTP account Gateway profile for one SimNow profile.

    All authority, journal, account alias and scope values are supplied by
    trusted server composition code. The parsed service config may select only
    Gateway account-read and provider-session ports, and its
    ``account_session_ref`` must be the selected profile's session reference
    (``ctp_simnow_gateway_refs(ctp_profile).session_ref``). Credentials are
    never accepted here; the spawned child resolves them from its trusted
    local environment when its profile reference is selected.
    """

    from bt_api_base.account_protocol import AccountResourceKey
    from bt_api_gateway.event_journal import GatewayEventJournal
    from bt_api_gateway.router import GatewayCommandKind, GatewayPrincipal
    from bt_api_gateway.service_component import GatewayServiceAccountScope
    from bt_api_gateway.session_guard import LocalAccountSessionGuard

    from bt_api_py.gateway_operator import (
        GatewayAccountSessionBinding,
        GatewayOperatorDeployment,
        GatewayOperatorDeploymentError,
    )
    from bt_api_py.service_host import TrustedServiceAuthority

    try:
        refs = ctp_simnow_gateway_refs(ctp_profile)
    except CtpSimNowAccountProfileError:
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID") from None
    _gateway_profile_config(
        config,
        role="account_session_worker",
        ports=frozenset({"service.account_read", "service.provider_session"}),
        session_ref=refs.session_ref,
    )
    if (
        type(authority) is not TrustedServiceAuthority
        or type(journal) is not GatewayEventJournal
        or type(account_scope) is not GatewayServiceAccountScope
        or not isinstance(principals, Mapping)
        or not principals
        or any(
            type(principal_ref) is not str
            or type(value) is not GatewayPrincipal
            or value.principal_id != principal_ref
            or value.account_scopes
            != frozenset({account_scope.journal_account_scope})
            or value.strategy_scopes != frozenset({state_scope})
            or value.allowed_kinds != frozenset({GatewayCommandKind.READ})
            for principal_ref, value in principals.items()
        )
        or not isinstance(guard_directory, (str, Path))
        or type(state_scope) is not str
        or not state_scope
        or state_scope != state_scope.strip()
        or type(owner_ref) is not str
        or not owner_ref
        or owner_ref != owner_ref.strip()
    ):
        raise GatewayOperatorAccountProfileError("TRUSTED_BINDING_INVALID")

    directory = Path(guard_directory)
    coverage = (
        AccountResourceKey(
            product_type=_ACCOUNT_RESOURCE_PRODUCT,
            margin_pool=_ACCOUNT_RESOURCE_MARGIN,
        ),
    )

    def deployment_factory() -> GatewayOperatorDeployment:
        # The profile factory runs on GatewayOperatorApplication's owner
        # thread, so the guard and child adapter share the proper owner.
        session_owner = CtpSimNowSet2AccountProcessOwner(refs.session_ref)
        session_guard = LocalAccountSessionGuard(
            directory,
            session_owner.account_key.account_key_id,
            owner_ref,
        )
        binding = GatewayAccountSessionBinding(
            account_session_ref=refs.session_ref,
            journal=journal,
            account_key=session_owner.account_key,
            account_scope=account_scope,
            state_scope=state_scope,
            guard=session_guard,
            required_coverage=coverage,
            principals=principals,
            require_open_orders=True,
            refresh_interval_seconds=_ACCOUNT_REFRESH_INTERVAL_SECONDS,
            max_staleness_seconds=_ACCOUNT_MAX_STALENESS_SECONDS,
            request_timeout_seconds=_ACCOUNT_REQUEST_TIMEOUT_SECONDS,
        )
        try:
            return GatewayOperatorDeployment(
                config,
                authority,
                registry_path,
                resource_provider=_reject_unexpected_service_component,
                session_owner=session_owner,
                account_session=binding,
            )
        except GatewayOperatorDeploymentError:
            raise

    return GatewayOperatorProfile(
        profile_ref=refs.operator_profile_ref,
        role="account_session_worker",
        deployment_factory=deployment_factory,
    )


def _read_ctp_market_environment() -> tuple[str, str, str]:
    """Return local read-only MD credentials without logging or forwarding them."""

    try:
        user_id = os.environ.get("CTP_USER_ID", "").strip()
        broker_id = os.environ.get("CTP_BROKER_ID", "").strip()
        password = os.environ.get("CTP_PASSWORD", "").strip()
    except Exception:
        raise CtpSimNowAccountProfileError("ACCOUNT_IDENTITY_UNAVAILABLE") from None
    if not user_id or not broker_id or not password:
        raise CtpSimNowAccountProfileError("ACCOUNT_IDENTITY_UNAVAILABLE")
    return user_id, broker_id, password


def build_ctp_simnow_set2_market_operator_profile(
    config: object,
    authority: object,
    registry_path: str | Path,
    *,
    key_universe: tuple[object, ...],
    principal_allowed_keys: Mapping[str, frozenset[object]],
    ctp_profile: str = CTP_SIMNOW_GATEWAY_DEFAULT_PROFILE,
) -> GatewayOperatorProfile:
    """Build the existing Gateway MarketHub over the CTP quote-v2 provider.

    ``key_universe`` and its audience are server-owned configuration. Every
    key must use the selected profile's market source/entitlement references
    (``ctp_simnow_gateway_refs(ctp_profile)``), the SDK route's SimNow
    instrument environment ``"demo"`` and the provider's neutral ``"tick"``
    channel; the provider publishes ``ctp.quote.v2`` payloads on it. The provider and CTP stream are created lazily through the existing
    operator; profile resolution and deployment construction perform no
    native I/O.
    """

    from bt_api_base.market_protocol import MarketSubscriptionKey

    from bt_api_py.gateway_operator import GatewayOperatorDeployment
    from bt_api_py.gateway_operator_market import GatewayMarketBinding
    from bt_api_py.service_host import TrustedServiceAuthority

    try:
        refs = ctp_simnow_gateway_refs(ctp_profile)
    except CtpSimNowAccountProfileError:
        raise GatewayOperatorAccountProfileError("SERVICE_CONFIG_INVALID") from None
    _gateway_profile_config(
        config,
        role="market_hub",
        ports=frozenset({"service.market_source"}),
    )
    if (
        type(authority) is not TrustedServiceAuthority
        or type(key_universe) is not tuple
        or not key_universe
        or len(key_universe) > 1_024
        or any(
            type(key) is not MarketSubscriptionKey
            or key.source_ref != refs.market_source_ref
            or key.entitlement_ref != refs.market_entitlement_ref
            or key.channel != CTP_MARKET_TICK_CHANNEL
            or key.depth is not None
            or key.timeframe is not None
            or key.instrument.provider != "ctp"
            or key.instrument.environment != CTP_SIMNOW_MARKET_ENVIRONMENT
            or key.instrument.instrument_id != key.instrument.native_symbol
            for key in key_universe
        )
        or len(set(key_universe)) != len(key_universe)
        or not isinstance(principal_allowed_keys, Mapping)
        or set(principal_allowed_keys) != set(authority.principals.values())
    ):
        raise GatewayOperatorAccountProfileError("MARKET_UNIVERSE_INVALID")

    def create_provider() -> object:
        from bt_api_ctp.feeds.live_ctp_feed import CtpMarketStream
        from bt_api_ctp.market_provider import CtpQuoteV2MarketProvider

        user_id, broker_id, password = _read_ctp_market_environment()
        td_front, md_front = _official_simnow_profile_fronts(refs.ctp_profile)

        def stream_factory(key: object, quote_queue: object) -> object:
            if type(key) is not MarketSubscriptionKey:
                raise GatewayOperatorAccountProfileError("MARKET_UNIVERSE_INVALID")
            return CtpMarketStream(
                data_queue=quote_queue,
                broker_id=broker_id,
                user_id=user_id,
                password=password,
                td_front=td_front,
                md_front=md_front,
                ctp_env_profile=refs.ctp_profile,
                require_ctp_profile=refs.ctp_profile,
                auto_detect_fronts=False,
                asset_type=key.instrument.product_type.upper(),
                # Same as the direct provider: SimNow's MD login response
                # carries zero session fields (2026-11-06 SimNow: the
                # Gateway subscription timed out without this).
                allow_zero_md_login_response=True,
            )

        return CtpQuoteV2MarketProvider(
            stream_factory=stream_factory,
            source_ref=refs.market_source_ref,
            entitlement_ref=refs.market_entitlement_ref,
            queue_capacity=4_096,
            connect_timeout_seconds=30.0,
            stop_timeout_seconds=5.0,
        )

    binding = GatewayMarketBinding(
        key_universe=key_universe,
        principal_allowed_keys=principal_allowed_keys,
        provider_factory=create_provider,
        max_provider_events_per_maintain=32,
    )

    def deployment_factory() -> GatewayOperatorDeployment:
        return GatewayOperatorDeployment(
            config,
            authority,
            registry_path,
            resource_provider=_reject_unexpected_service_component,
            market_binding=binding,
        )

    return GatewayOperatorProfile(
        profile_ref=refs.market_operator_profile_ref,
        role="market_hub",
        deployment_factory=deployment_factory,
    )


__all__ = [
    "CTP_MARKET_TICK_CHANNEL",
    "CTP_SIMNOW_MARKET_ENVIRONMENT",
    "CTP_SIMNOW_GATEWAY_DEFAULT_PROFILE",
    "CtpSimNowGatewayRefs",
    "ctp_simnow_gateway_refs",
    "CTP_SIMNOW_SET2_7X24_PROFILE_REF",
    "CTP_SIMNOW_SET2_7X24_SESSION_REF",
    "CTP_SIMNOW_SET2_7X24_OPERATOR_PROFILE_REF",
    "CTP_SIMNOW_SET2_7X24_MARKET_OPERATOR_PROFILE_REF",
    "CTP_SIMNOW_SET2_7X24_MARKET_SOURCE_REF",
    "CTP_SIMNOW_SET2_7X24_MARKET_ENTITLEMENT_REF",
    "CtpSimNowAccountProfileError",
    "GatewayOperatorAccountProfileError",
    "CtpSimNowSet2AccountProcessOwner",
    "build_ctp_simnow_set2_account_operator_profile",
    "build_ctp_simnow_set2_market_operator_profile",
    "ctp_simnow_set2_account_key_from_environment",
    "ctp_simnow_set2_account_process_child",
    "create_ctp_simnow_set2_account_provider",
    "project_ctp_native_stop_receipt",
]
