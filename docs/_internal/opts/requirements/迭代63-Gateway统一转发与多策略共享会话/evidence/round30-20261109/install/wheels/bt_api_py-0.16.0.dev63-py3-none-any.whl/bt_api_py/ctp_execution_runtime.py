"""Thread-confined composition for one managed CTP execution owner.

This module is deliberately opt-in.  Constructing the provider creates no
Store, lease, account-family claim, TraderClient, or native object.  Those
resources are acquired only when ServiceHost invokes the provider on its
owner thread.
"""

from __future__ import annotations

import copy
import math
import queue
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from time import monotonic_ns
from types import MappingProxyType
from typing import Any, Protocol

from bt_api_ctp.trader_connection_config import CtpTraderConnectionConfig

from .managed_execution_mailbox import (
    ManagedOwnerThreadMailboxMixin,
    _OwnerThreadCall,
    _OWNER_THREAD_CALL_DEFAULT_TIMEOUT_S,
    _OWNER_THREAD_CALL_QUEUE_SIZE,
)


_RECONCILIATION_OUTBOX_PAGE_SIZE = 64
_RECONCILIATION_BATCH_SIZE = 8
_RECONCILIATION_INTERVAL_NS = 1_000_000_000


class CtpExecutionRuntimeError(RuntimeError):
    """Finite, non-sensitive status for a failed CTP runtime operation."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class CtpExecutionRuntimeConfigError(CtpExecutionRuntimeError, ValueError):
    """Finite configuration-time refusal of a declared CTP runtime fact."""


#: Options of the direct managed-runtime bootstrap (``ctp_managed_runtime_
#: registration``), which serves no ``orders.submit``/``orders.cancel`` wire
#: route. A ServiceHost always passes its own validated options object, never
#: this one, so every ServiceHost build is held to the typed-binding rule.
DIRECT_MANAGED_OWNER_OPTIONS: Mapping[str, object] = MappingProxyType({"role": "account_owner"})


def _ctp_command_binding_declaration(config: Any) -> dict[str, Any]:
    """Canonical typed-command declaration of one CTP runtime, or refuse.

    Iteration 60: the deployment declares the facts the runtime config lacks
    (product type, quantity unit, optional currency/mode/hedge class); the
    single SDK parser checks the typed vocabulary and the CTP provider checks
    them against the runtime's own account and native instrument binding.
    """

    from bt_api_ctp.managed_runtime_route_validation import (
        validate_ctp_managed_command_binding,
    )

    from bt_api_py.service_command_wire import (
        ServiceCommandWireError,
        parse_command_binding_declaration,
    )

    try:
        plain = parse_command_binding_declaration(config.command_binding).to_plain()
    except ServiceCommandWireError as error:
        raise CtpExecutionRuntimeConfigError(error.code) from None
    scope = config.execution_scope
    native = config.native_binding
    account_ref = getattr(scope, "account_ref", None)
    if getattr(native, "account_ref", None) != account_ref:
        raise CtpExecutionRuntimeConfigError("COMMAND_BINDING_ACCOUNT_MISMATCH")
    validate_ctp_managed_command_binding(
        plain,
        provider=getattr(scope, "provider", None),
        environment=getattr(scope, "environment", None),
        account_ref=account_ref,
        intent_instrument=getattr(native, "intent_instrument", None),
        provider_instrument=getattr(native, "provider_instrument", None),
        exchange_id=getattr(native, "exchange_id", None),
        error_type=CtpExecutionRuntimeConfigError,
    )
    return plain










@dataclass(frozen=True, slots=True)
class CtpRuntimeStatus:
    phase: str
    code: str | None
    ready: bool
    closed: bool


@dataclass(frozen=True, slots=True)
class CtpRuntimeAdmissionContext:
    """Exact owner-thread objects passed to trusted Risk composition code."""

    store: Any
    execution_scope: Any
    service_scope: Any
    writer_lease: Any
    trader: Any
    family_owner: Any
    callback_owner: Any
    session_adapter: Any
    session_generation_id: str
    reconciliation_port: Any
    submit_port: Any
    basic_admission_gate: Any
    execution_owner: Any
    native_binding: Any
    recovery_close_source_authority: Any | None = None
    owner_thread_invoker: Any | None = None


@dataclass(frozen=True, slots=True)
class CtpRuntimeOrderProviderDependencyContextV1:
    """Runtime-owned identity set supplied to a trusted provider dependency factory.

    This object binds optional CTP provider dependencies to one already-ready
    runtime, exact selected request feed, TraderClient, and session generation.
    It is composition evidence only and grants no order permission.
    """

    runtime_instance_id: str
    selected_feed: Any
    trader_client: Any
    execution_scope: Any
    session_generation_id: str
    execution_owner: Any
    store: Any
    submit_port: Any
    cancel_port: Any
    execution_facade: Any
    cancellation_facade: Any
    basic_admission_gate: Any
    order_admission_gate: Any
    cancel_admission_gate: Any
    owner_thread: threading.Thread
    owner_thread_invoker: Any
    instrument_metadata_reader: Any | None


@dataclass(frozen=True, slots=True)
class CtpRuntimeOrderProviderDependenciesV1:
    """Optional CTP-specific dependencies tied to one exact runtime context."""

    context: CtpRuntimeOrderProviderDependencyContextV1
    registered_sim_authority: Any | None = None
    request_account_validator: Any | None = None
    submit_context_resolver: Any | None = None
    cancel_authorization_validator: Any | None = None
    order_provider_authority_source: Any | None = None
    execution_economics_owner: Any | None = None
    execution_economics_issuer: Any | None = None

    def __post_init__(self) -> None:
        if (self.execution_economics_owner is None) != (
            self.execution_economics_issuer is None
        ):
            raise TypeError(
                "execution economics owner and issuer must be supplied together"
            )


class CtpRuntimeOrderProviderDependencyFactoryV1(Protocol):
    """Trusted factory and validator for selected-session provider dependencies.

    Implementations must resolve only already-existing, SDK-owned authority and
    validation objects for the supplied exact runtime context. ``validate``
    must reject dependencies that are not bound to every relevant object in
    that context, including the economics owner and its evidence issuer. An
    economics owner must independently revalidate evidence at its claim and
    dispatch boundaries; successful dependency validation is provenance
    validation, never a write grant. The Basic/Risk gates remain authoritative.
    """

    def resolve(
        self,
        context: CtpRuntimeOrderProviderDependencyContextV1,
    ) -> CtpRuntimeOrderProviderDependenciesV1: ...

    def validate(
        self,
        context: CtpRuntimeOrderProviderDependencyContextV1,
        dependencies: CtpRuntimeOrderProviderDependenciesV1,
    ) -> bool: ...


@dataclass(frozen=True, slots=True)
class CtpRuntimeCredentialBindingSetupV1:
    """Exact startup-owned capability and installed ENTRY binding."""

    capability: object
    initial_binding: Any


@dataclass(frozen=True, slots=True)
class CtpRuntimeCancelAuthorizationRequestV1:
    """Value-only scope and target facts for a trusted cancel resolver."""

    cancel_intent: Any
    prepared_target: Any
    account_key: str
    scope_key: str
    trading_day: str
    session_generation_id: str
    callback_owner_intent_id: str
    account_fingerprint: str
    connection_generation: int
    environment_profile: str
    td_front: str
    md_front: str


@dataclass(frozen=True, slots=True)
class CtpExecutionRuntimeConfig:
    """Trusted inputs for one non-restartable CTP account-owner generation.

    ``prepare_trader`` is an application-owned composition hook.  It must use
    the TraderClient's real settlement confirmation/readback and established
    owner-sealed SimNow write-binding APIs.  This runtime never creates an
    approval, credential binding, Risk gate, or cutover proof.

    The basic gate factory is called after the real submit port exists and must
    register an ``ExecutionProviderValidatorV1`` bound to that exact port.  The
    Risk factory is called after the exact execution owner exists and returns
    the service admission resources described by this module's contract.

    ``command_binding`` (iteration 60) is the deployment's typed order-command
    declaration (``service_command_wire`` plain form). It is checked here, at
    configuration time, against ``execution_scope`` and ``native_binding``; a
    ServiceHost order-entry build requires it (no generic fallback), and the
    host component options and the strategy client's ``broker.orders`` route
    carry ``command_binding_declaration`` so both peers derive one binding.
    The direct managed bootstrap serves no wire order route and may omit it.
    """

    store_path: str | Path
    execution_scope: Any
    service_scope: Any
    lease_owner_id: str
    trader: CtpTraderConnectionConfig
    native_binding: Any
    prepare_trader: Callable[[Any], object]
    basic_admission_factory: Callable[[Any, Any, Any], Any]
    risk_admission_factory: Callable[[CtpRuntimeAdmissionContext], Mapping[str, Any]]
    cancel_recovery_binding_provider: Any | None = None
    startup_timeout_s: float = 15.0
    stop_timeout_s: float = 2.0
    lease_ttl_ns: int = 30_000_000_000
    callback_pump_events: int = 32
    drain_limit: int = 4096
    order_provider_dependency_factory: CtpRuntimeOrderProviderDependencyFactoryV1 | None = None
    command_binding: Mapping[str, Any] | None = field(default=None, hash=False)
    _command_binding_plain: Mapping[str, Any] | None = field(
        default=None, init=False, repr=False, compare=False
    )

    @property
    def command_binding_declaration(self) -> dict[str, Any] | None:
        """A fresh canonical copy of the checked declaration, or ``None``."""

        plain = self._command_binding_plain
        return None if plain is None else copy.deepcopy(dict(plain))

    def __post_init__(self) -> None:
        if (
            type(self.store_path) is not str
            and not isinstance(self.store_path, Path)
        ) or not str(self.store_path).strip():
            raise ValueError("invalid CTP execution Store path")
        if type(self.lease_owner_id) is not str or not self.lease_owner_id.strip():
            raise ValueError("invalid CTP execution writer owner")
        if type(self.trader) is not CtpTraderConnectionConfig:
            raise ValueError("typed CTP TraderClient configuration is required")
        if self.trader.ctp_env_profile != "config_front_pair":
            raise ValueError("managed CTP runtime requires config_front_pair")
        for field_name in (
            "prepare_trader",
            "basic_admission_factory",
            "risk_admission_factory",
        ):
            if not callable(getattr(self, field_name)):
                raise ValueError(f"trusted CTP runtime hook is required: {field_name}")
        dependency_factory = self.order_provider_dependency_factory
        if dependency_factory is not None and (
            not callable(getattr(dependency_factory, "resolve", None))
            or not callable(getattr(dependency_factory, "validate", None))
        ):
            raise ValueError("trusted order provider dependency factory is invalid")
        if self.cancel_recovery_binding_provider is not None and not callable(
            getattr(self.cancel_recovery_binding_provider, "resolve_verified_binding", None)
        ):
            raise ValueError("trusted cancel recovery binding provider is invalid")
        for field_name in ("startup_timeout_s", "stop_timeout_s"):
            value = getattr(self, field_name)
            if (
                type(value) not in (int, float)
                or isinstance(value, bool)
                or not math.isfinite(value)
                or value <= 0
                or value > 60
            ):
                raise ValueError(f"invalid CTP runtime timeout: {field_name}")
        if type(self.lease_ttl_ns) is not int or not 1_000_000 <= self.lease_ttl_ns <= 300_000_000_000:
            raise ValueError("invalid CTP execution lease duration")
        if type(self.callback_pump_events) is not int or not 1 <= self.callback_pump_events <= 256:
            raise ValueError("invalid CTP callback pump bound")
        if type(self.drain_limit) is not int or not 1 <= self.drain_limit <= 100_000:
            raise ValueError("invalid CTP callback drain bound")
        if self.command_binding is not None:
            object.__setattr__(
                self,
                "_command_binding_plain",
                MappingProxyType(_ctp_command_binding_declaration(self)),
            )


class CtpExecutionRuntime(ManagedOwnerThreadMailboxMixin):
    """One exact TraderClient, SQLite owner, and submit/cancel port generation."""

    def __init__(self, config: CtpExecutionRuntimeConfig, instance_id: str) -> None:
        self.config = config
        self.instance_id = instance_id
        self.owner_thread_id: int | None = None
        self._owner_thread: threading.Thread | None = None
        self._owner_thread_calls: queue.Queue[_OwnerThreadCall] = queue.Queue(
            maxsize=_OWNER_THREAD_CALL_QUEUE_SIZE
        )
        self._owner_thread_calls_lock = threading.Lock()
        self._owner_thread_calls_accepting = False
        self._owner_thread_call_active = False
        self._owner_thread_dispatcher: Any | None = None
        self._session_generation_id: str | None = None
        self._phase = "CREATED"
        self._code: str | None = None
        self._ready = False
        self._closed = False
        self._lease_healthy = False
        self._lease_expires_at_ns: int | None = None
        self._next_lease_renewal_ns: int | None = None
        self._lease_renewal_interval_ns = max(1, config.lease_ttl_ns // 3)
        self._next_reconciliation_ns: int | None = None
        self._reconciliation_journal_generation: str | None = None
        self._reconciliation_after_sequence = 0
        self._reconciliation_page_pending = False
        self._reconciliation_pending_intents: list[str] = []
        self._tracked_fill_review_intent_id: str | None = None
        self._tracked_fill_review_event_sequence: int | None = None
        self._store_closed = False
        self._native_start_attempted = False
        self._native_stop_attempted = False
        self._native_stop_complete = False
        self._last_stop_receipt: Any | None = None
        self._store: Any | None = None
        self._family_owner: Any | None = None
        self._writer_lease: Any | None = None
        self._callback_owner: Any | None = None
        self._session_adapter: Any | None = None
        self._trader: Any | None = None
        self._callback_verifier: Any | None = None
        self._reconciliation_port: Any | None = None
        self._submit_port: Any | None = None
        self._basic_gate: Any | None = None
        self._reconciliation_facade: Any | None = None
        self._execution_owner: Any | None = None
        self._cancel_gate: Any | None = None
        self._cancel_port: Any | None = None
        self._order_provider_cancellation_facade: Any | None = None
        self._order_provider_runtime_context: Any | None = None
        self._order_provider_market_stream: Any | None = None
        self._registered_sim_authority: Any | None = None
        self._request_account_validator: Any | None = None
        self._submit_context_resolver: Any | None = None
        self._cancel_authorization_validator: Any | None = None
        self._order_provider_authority_source: Any | None = None
        self._execution_economics_owner: Any | None = None
        self._execution_economics_issuer: Any | None = None
        self._cancel_recovery_pending_intent_id: str | None = None
        self._cancel_recovery_pending_intent: Any | None = None
        self._cancel_recovery_binding: Any | None = None
        self._cancel_recovery_restore_failed = False
        self._order_gate: Any | None = None
        self._recovery_close_source_authority: Any | None = None
        self._recovery_close_available = False
        self._owned_risk_bridge: Any | None = None
        self._risk_bridge_closed = False
        self._cancel_quota_admission: Any | None = None
        self._credential_binding_setup: CtpRuntimeCredentialBindingSetupV1 | None = None
        self._resources: Any | None = None
        self._borrowed_request_feed: Any | None = None

    @property
    def status(self) -> CtpRuntimeStatus:
        return CtpRuntimeStatus(
            phase=self._phase,
            code=self._code,
            ready=self.is_ready(),
            closed=self._closed,
        )

    @property
    def last_stop_receipt(self) -> Any | None:
        return self._last_stop_receipt

    def _assert_owner_thread(self) -> None:
        if self.owner_thread_id is None or threading.get_ident() != self.owner_thread_id:
            raise CtpExecutionRuntimeError("OWNER_THREAD_REQUIRED")

    @property
    def owner_thread(self) -> threading.Thread | None:
        """The exact thread captured by bootstrap for this runtime generation."""

        return self._owner_thread

    @property
    def execution_owner(self) -> Any | None:
        """The exact CTP execution owner used by both managed order ports."""

        return self._execution_owner

    @property
    def owner_thread_invoker(self) -> Any:
        """Narrow SDK wrapper for the existing runtime's owner-thread mailbox."""

        with self._owner_thread_calls_lock:
            dispatcher = self._owner_thread_dispatcher
            if dispatcher is None:
                from bt_api_py.managed_execution_dispatcher import (
                    OwnerThreadExecutionDispatcher,
                )

                dispatcher = OwnerThreadExecutionDispatcher(self)
                self._owner_thread_dispatcher = dispatcher
            return dispatcher


    def bind_selected_request_feed(
        self,
        feed: Any,
        *,
        timeout_seconds: float = _OWNER_THREAD_CALL_DEFAULT_TIMEOUT_S,
    ) -> None:
        """Attach one exact selected CTP future feed to this runtime's client.

        The feed must be bound before its first ``connect``. The callback is
        executed on this runtime's existing owner thread through its bounded
        mailbox; it creates no client or native thread. This only binds session
        identity and client ownership. It does not grant order authority or
        supply instrument/account metadata.
        """

        def bind_on_owner() -> None:
            self._assert_owner_thread()
            if (
                self._borrowed_request_feed is not None
                or self._closed
                or not self.is_ready()
                or self._phase != "READY"
            ):
                raise CtpExecutionRuntimeError(
                    "REQUEST_FEED_RUNTIME_BINDING_UNAVAILABLE"
                )
            try:
                from bt_api_ctp.feeds.live_ctp_feed import (
                    _attach_runtime_owned_ctp_request_feed,
                )

                _attach_runtime_owned_ctp_request_feed(feed, self)
            except CtpExecutionRuntimeError:
                raise
            except Exception:
                raise CtpExecutionRuntimeError(
                    "REQUEST_FEED_RUNTIME_BINDING_UNAVAILABLE"
                ) from None
            self._borrowed_request_feed = feed

        self.owner_thread_invoker.call_on_owner_thread(
            bind_on_owner,
            timeout_seconds=timeout_seconds,
        )

    def build_selected_feed_order_provider_context(
        self,
        feed: Any,
        *,
        market_stream: Any | None = None,
        owner_call_timeout_seconds: float = _OWNER_THREAD_CALL_DEFAULT_TIMEOUT_S,
        instrument_metadata_timeout_seconds: float = 5.0,
    ) -> Any:
        """Build CTP provider context from this exact ready runtime.

        The selected request feed must already be bound and connected. Core
        facades, ports, Store, scope and owner-call wrapper come only from this
        runtime. A metadata reader is created only for an explicitly supplied
        canonical selected market stream. An optional trusted dependency
        factory may resolve and validate an exact selected-session dependency
        bundle. If no such factory is configured, authority, account mapping,
        submit authorization resolution, and cancel authorization validation
        remain ``None``. The economics owner and evidence issuer also remain
        absent, so the economics route and writes that require its evidence
        remain unavailable.
        """

        def build_on_owner() -> Any:
            self._assert_owner_thread()
            if (
                self._closed
                or not self.is_ready()
                or self._phase != "READY"
                or feed is not self._borrowed_request_feed
                or self._store is None
                or self._writer_lease is None
                or self._execution_owner is None
                or self._submit_port is None
                or self._cancel_port is None
                or self._basic_gate is None
                or self._order_gate is None
                or self._cancel_gate is None
                or self._reconciliation_facade is None
                or self._owner_thread is None
                or self._session_generation_id is None
            ):
                raise CtpExecutionRuntimeError(
                    "ORDER_PROVIDER_RUNTIME_CONTEXT_UNAVAILABLE"
                )
            dependency_context: CtpRuntimeOrderProviderDependencyContextV1 | None = None
            try:
                from bt_api_ctp.feeds.live_ctp_feed import (
                    CtpMarketStream,
                    CtpRequestDataFuture,
                )
                from bt_api_ctp.order_provider import CtpOrderProviderRuntimeContext

                if type(feed) is not CtpRequestDataFuture:
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_FEED_BINDING_INVALID"
                    )
                binding = feed._managed_runtime_binding
                if (
                    binding is None
                    or binding._runtime is not self
                    or feed._connected is not True
                    or feed._trader is not self._trader
                    or binding.resolve_trader(feed) is not self._trader
                ):
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_FEED_BINDING_INVALID"
                    )
                existing_context = self._order_provider_runtime_context
                if existing_context is not None:
                    if (
                        self._order_provider_market_stream is not market_stream
                        or existing_context.owner_call_timeout_seconds
                        != owner_call_timeout_seconds
                        or existing_context.instrument_metadata_timeout_seconds
                        != instrument_metadata_timeout_seconds
                    ):
                        raise CtpExecutionRuntimeError(
                            "ORDER_PROVIDER_RUNTIME_CONTEXT_ALREADY_ISSUED"
                        )
                    if binding.validate_provider_context(
                        existing_context,
                        exchange_name="CTP___FUTURE",
                        selected_feed=feed,
                        trader_client=self._trader,
                    ) is not True:
                        raise CtpExecutionRuntimeError(
                            "ORDER_PROVIDER_RUNTIME_CONTEXT_UNAVAILABLE"
                        )
                    return existing_context
                metadata_reader = None
                if market_stream is not None:
                    if type(market_stream) is not CtpMarketStream:
                        raise CtpExecutionRuntimeError(
                            "ORDER_PROVIDER_MARKET_STREAM_INVALID"
                        )
                    trader_config = self.config.trader
                    if (
                        getattr(market_stream, "ctp_env_profile", None)
                        != trader_config.ctp_env_profile
                        or getattr(market_stream, "md_front", None)
                        != trader_config.md_front
                        or getattr(market_stream, "broker_id", None)
                        != trader_config.broker_id
                        or getattr(market_stream, "user_id", None)
                        != trader_config.user_id
                    ):
                        raise CtpExecutionRuntimeError(
                            "ORDER_PROVIDER_MARKET_STREAM_BINDING_INVALID"
                        )
                    from bt_api_ctp.instrument_metadata import (
                        CtpInstrumentMetadataReader,
                    )

                    metadata_reader = CtpInstrumentMetadataReader(
                        feed,
                        market_stream,
                    )
                cancellation_facade = self._get_order_provider_cancellation_facade()
                dependency_context = CtpRuntimeOrderProviderDependencyContextV1(
                    runtime_instance_id=self.instance_id,
                    selected_feed=feed,
                    trader_client=self._trader,
                    execution_scope=self.config.execution_scope,
                    session_generation_id=self._session_generation_id,
                    execution_owner=self._execution_owner,
                    store=self._store,
                    submit_port=self._submit_port,
                    cancel_port=self._cancel_port,
                    execution_facade=self._reconciliation_facade,
                    cancellation_facade=cancellation_facade,
                    basic_admission_gate=self._basic_gate,
                    order_admission_gate=self._order_gate,
                    cancel_admission_gate=self._cancel_gate,
                    owner_thread=self._owner_thread,
                    owner_thread_invoker=self.owner_thread_invoker,
                    instrument_metadata_reader=metadata_reader,
                )
                dependencies = self._resolve_order_provider_dependencies(
                    dependency_context
                )
                context = CtpOrderProviderRuntimeContext(
                    execution_store=self._store,
                    scope=self.config.execution_scope,
                    runtime_binding=binding,
                    registered_sim_authority=dependencies.registered_sim_authority,
                    execution_facade=self._reconciliation_facade,
                    cancellation_facade=cancellation_facade,
                    submit_port=self._submit_port,
                    cancel_port=self._cancel_port,
                    owner_thread_invoker=self.owner_thread_invoker,
                    instrument_metadata_reader=metadata_reader,
                    request_account_validator=dependencies.request_account_validator,
                    submit_context_resolver=dependencies.submit_context_resolver,
                    cancel_authorization_validator=(
                        dependencies.cancel_authorization_validator
                    ),
                    order_provider_authority_source=(
                        dependencies.order_provider_authority_source
                    ),
                    execution_economics_owner=dependencies.execution_economics_owner,
                    execution_economics_issuer=dependencies.execution_economics_issuer,
                    owner_call_timeout_seconds=owner_call_timeout_seconds,
                    instrument_metadata_timeout_seconds=(
                        instrument_metadata_timeout_seconds
                    ),
                )
                self._registered_sim_authority = dependencies.registered_sim_authority
                self._request_account_validator = dependencies.request_account_validator
                self._submit_context_resolver = dependencies.submit_context_resolver
                self._cancel_authorization_validator = (
                    dependencies.cancel_authorization_validator
                )
                self._order_provider_authority_source = (
                    dependencies.order_provider_authority_source
                )
                self._execution_economics_owner = dependencies.execution_economics_owner
                self._execution_economics_issuer = dependencies.execution_economics_issuer
                self._order_provider_market_stream = market_stream
                try:
                    binding.register_provider_context(
                        context,
                        exchange_name="CTP___FUTURE",
                    )
                except Exception:
                    self._registered_sim_authority = None
                    self._request_account_validator = None
                    self._submit_context_resolver = None
                    self._cancel_authorization_validator = None
                    self._order_provider_authority_source = None
                    self._execution_economics_owner = None
                    self._execution_economics_issuer = None
                    self._order_provider_market_stream = None
                    raise
                self._order_provider_runtime_context = context
                self._order_provider_dependency_context = dependency_context
                factory = self.config.order_provider_dependency_factory
                final_context_validator = (
                    None
                    if factory is None
                    else getattr(factory, "validate_final_context", None)
                )
                if (
                    dependencies.execution_economics_issuer is not None
                    and not callable(final_context_validator)
                ):
                    binding.revoke_provider_contexts()
                    self._order_provider_runtime_context = None
                    self._order_provider_dependency_context = None
                    self._registered_sim_authority = None
                    self._request_account_validator = None
                    self._submit_context_resolver = None
                    self._cancel_authorization_validator = None
                    self._order_provider_authority_source = None
                    self._execution_economics_owner = None
                    self._execution_economics_issuer = None
                    self._order_provider_market_stream = None
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_FINAL_CONTEXT_VALIDATION_UNAVAILABLE"
                    )
                if callable(final_context_validator):
                    try:
                        final_context_valid = final_context_validator(
                            dependency_context,
                            dependencies,
                            context,
                        )
                    except Exception:
                        final_context_valid = False
                    if type(final_context_valid) is not bool or not final_context_valid:
                        binding.revoke_provider_contexts()
                        self._order_provider_runtime_context = None
                        self._order_provider_dependency_context = None
                        self._registered_sim_authority = None
                        self._request_account_validator = None
                        self._submit_context_resolver = None
                        self._cancel_authorization_validator = None
                        self._order_provider_authority_source = None
                        self._execution_economics_owner = None
                        self._execution_economics_issuer = None
                        self._order_provider_market_stream = None
                        raise CtpExecutionRuntimeError(
                            "ORDER_PROVIDER_FINAL_CONTEXT_VALIDATION_UNAVAILABLE"
                        )
                return context
            except CtpExecutionRuntimeError:
                if dependency_context is not None:
                    self._revoke_order_provider_dependencies(dependency_context)
                raise
            except Exception:
                if dependency_context is not None:
                    self._revoke_order_provider_dependencies(dependency_context)
                raise CtpExecutionRuntimeError(
                    "ORDER_PROVIDER_RUNTIME_CONTEXT_UNAVAILABLE"
                ) from None

        return self.owner_thread_invoker.call_on_owner_thread(
            build_on_owner,
            timeout_seconds=owner_call_timeout_seconds,
        )

    def _resolve_order_provider_dependencies(
        self,
        context: CtpRuntimeOrderProviderDependencyContextV1,
    ) -> CtpRuntimeOrderProviderDependenciesV1:
        """Resolve one typed dependency bundle through the configured trust hook."""

        self._assert_owner_thread()
        factory = self.config.order_provider_dependency_factory
        if factory is None:
            return CtpRuntimeOrderProviderDependenciesV1(context=context)
        try:
            dependencies = factory.resolve(context)
        except Exception:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_DEPENDENCIES_UNAVAILABLE"
            ) from None
        try:
            if (
                type(dependencies) is not CtpRuntimeOrderProviderDependenciesV1
                or dependencies.context is not context
            ):
                raise CtpExecutionRuntimeError(
                    "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                )
            authority = dependencies.registered_sim_authority
            if authority is not None:
                from bt_api_ctp.managed_order_authority import (
                    CtpRegisteredSimNativeAuthority,
                )

                if (
                    type(authority) is not CtpRegisteredSimNativeAuthority
                    or authority.is_bound_to_client(self._trader) is not True
                    or context.execution_scope.environment != "simulation"
                ):
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                    )
            for name in (
                "request_account_validator",
                "submit_context_resolver",
                "cancel_authorization_validator",
            ):
                value = getattr(dependencies, name)
                if value is not None and not callable(value):
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                    )
            authority_source = dependencies.order_provider_authority_source
            order_authority_values = (
                authority,
                dependencies.request_account_validator,
                dependencies.submit_context_resolver,
                dependencies.cancel_authorization_validator,
            )
            if authority_source is None:
                if any(value is not None for value in order_authority_values):
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                    )
            else:
                from bt_api_py.ctp_order_provider_dependencies import (
                    CtpOrderProviderAuthoritySourceV1,
                )

                if (
                    not isinstance(authority_source, CtpOrderProviderAuthoritySourceV1)
                    or any(value is None for value in order_authority_values[1:])
                    or not callable(getattr(factory, "revoke", None))
                ):
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                    )
            economics_owner = dependencies.execution_economics_owner
            economics_issuer = dependencies.execution_economics_issuer
            if (economics_owner is None) != (economics_issuer is None):
                raise CtpExecutionRuntimeError(
                    "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                )
            if economics_owner is not None:
                from bt_api_base.execution_economics_protocol import (
                    ExecutionEconomicsPort,
                )

                if not isinstance(economics_owner, ExecutionEconomicsPort):
                    raise CtpExecutionRuntimeError(
                        "ORDER_PROVIDER_DEPENDENCIES_INVALID"
                    )
        except CtpExecutionRuntimeError:
            raise
        except Exception:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_DEPENDENCIES_INVALID"
            ) from None
        try:
            validated = factory.validate(context, dependencies)
        except Exception:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_DEPENDENCIES_UNAVAILABLE"
            ) from None
        if type(validated) is not bool or validated is not True:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_DEPENDENCIES_UNAVAILABLE"
            )
        return dependencies

    def _revoke_order_provider_dependencies(
        self,
        context: CtpRuntimeOrderProviderDependencyContextV1,
    ) -> bool:
        """Revoke one provider bundle's factory-side context registration."""

        self._assert_owner_thread()
        factory = self.config.order_provider_dependency_factory
        revoke = None if factory is None else getattr(factory, "revoke", None)
        if not callable(revoke):
            return self._order_provider_authority_source is None
        try:
            result = revoke(context)
        except Exception:
            return False
        return type(result) is bool and result is True

    def validate_selected_feed_order_provider_context(
        self,
        feed: Any,
        context: Any,
        *,
        exchange_name: str = "CTP___FUTURE",
        timeout_seconds: float = _OWNER_THREAD_CALL_DEFAULT_TIMEOUT_S,
    ) -> bool:
        """Check one previously issued context against its selected runtime.

        The result proves only exact SDK composition provenance. Provider
        authorization and admission still require their separate typed
        authorities and validators.
        """

        def validate_on_owner() -> bool:
            self._assert_owner_thread()
            if (
                feed is not self._borrowed_request_feed
                or self._trader is None
                or self._execution_owner is None
            ):
                return False
            binding = getattr(feed, "_managed_runtime_binding", None)
            validate = getattr(binding, "validate_provider_context", None)
            if not callable(validate):
                return False
            result = validate(
                context,
                exchange_name=exchange_name,
                selected_feed=feed,
                trader_client=self._trader,
            )
            return type(result) is bool and result is True

        try:
            result = self.owner_thread_invoker.call_on_owner_thread(
                validate_on_owner,
                timeout_seconds=timeout_seconds,
            )
        except Exception:
            return False
        return type(result) is bool and result is True

    def _get_order_provider_cancellation_facade(self) -> Any:
        self._assert_owner_thread()
        existing = self._order_provider_cancellation_facade
        if existing is not None:
            return existing
        if (
            self._store is None
            or self._cancel_gate is None
            or self._cancel_port is None
            or self._writer_lease is None
        ):
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_CANCEL_FACADE_UNAVAILABLE"
            )
        try:
            from bt_api_execution.cancellation import ManagedCancellationFacade

            facade = ManagedCancellationFacade(
                self._store,
                self.config.execution_scope,
                acquire_writer_lease=self._acquire_order_provider_writer_lease,
                admission_gate=self._cancel_gate,
            )
        except Exception:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_CANCEL_FACADE_UNAVAILABLE"
            ) from None
        if (
            type(facade) is not ManagedCancellationFacade
            or facade.store is not self._store
            or facade.scope is not self.config.execution_scope
        ):
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_CANCEL_FACADE_UNAVAILABLE"
            )
        self._order_provider_cancellation_facade = facade
        return facade

    def _acquire_order_provider_writer_lease(self) -> Any:
        """Supply the same active lease to the correlated cancel facade."""

        self._assert_owner_thread()
        if (
            not self.is_ready()
            or self._phase != "READY"
            or self._closed
            or not self._lease_healthy
            or self._store is None
            or self._writer_lease is None
        ):
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_WRITER_LEASE_UNAVAILABLE"
            )
        self._renew_writer_lease_if_due()
        lease = self._writer_lease
        if not self._lease_healthy or lease is None:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_WRITER_LEASE_UNAVAILABLE"
            )
        try:
            self._store.assert_writer_lease(self.config.execution_scope, lease)
        except Exception:
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_WRITER_LEASE_UNAVAILABLE"
            ) from None
        return lease

    def _detach_selected_request_feed(self) -> None:
        """Clear the feed's borrowed pointer before this owner stops its client."""

        self._assert_owner_thread()
        feed = self._borrowed_request_feed
        if feed is None:
            return
        try:
            from bt_api_ctp.feeds.live_ctp_feed import (
                _detach_runtime_owned_ctp_request_feed,
            )

            detached = _detach_runtime_owned_ctp_request_feed(feed, self)
        except Exception:
            detached = False
        if detached is not True:
            self._ready = False
            self._set_phase("CLOSE_FAILED", "REQUEST_FEED_DETACH_UNCERTAIN")
            raise CtpExecutionRuntimeError(
                "REQUEST_FEED_DETACH_UNCERTAIN"
            ) from None
        dependency_context = self._order_provider_dependency_context
        if dependency_context is not None and not self._revoke_order_provider_dependencies(
            dependency_context
        ):
            self._ready = False
            self._set_phase("CLOSE_FAILED", "ORDER_PROVIDER_DEPENDENCY_REVOKE_UNCERTAIN")
            raise CtpExecutionRuntimeError(
                "ORDER_PROVIDER_DEPENDENCY_REVOKE_UNCERTAIN"
            )
        self._borrowed_request_feed = None
        self._order_provider_runtime_context = None
        self._order_provider_dependency_context = None
        self._order_provider_market_stream = None
        self._registered_sim_authority = None
        self._request_account_validator = None
        self._submit_context_resolver = None
        self._cancel_authorization_validator = None
        self._order_provider_authority_source = None
        self._execution_economics_owner = None
        self._execution_economics_issuer = None




    def is_ready(self) -> bool:
        if (
            not self._ready
            or not self._lease_healthy
            or self._closed
            or self._trader is None
            or self._lease_expires_at_ns is None
            or time.time_ns() >= self._lease_expires_at_ns
            or self._cancel_recovery_pending_intent_id is not None
            or self._cancel_recovery_restore_failed
        ):
            return False
        return self._trader_write_ready()

    def cancel_remainder_ready(self) -> bool:
        """Expose owner.cancel only for healthy runtime or one reviewed remainder.

        The degraded branch is intentionally narrower than ordinary cancel
        admission: it requires the exact ACKED_TRACKED positive-fill parent,
        its incomplete-fee review event, a complete same-session callback
        snapshot, and no other active/reviewed order or unresolved account
        cancellation. The owner-cancel handler still performs its own run
        selection, quota admission, target query, and single-use Risk claim.
        """

        try:
            self._assert_owner_thread()
            if self.is_ready():
                return True
            if (
                self._ready is not False
                or self._phase != "TRACKED_FILL_REVIEW_PENDING"
                or self._code != "CTP_TRACKED_ORDER_UPDATE_REQUIRES_REVIEW"
                or self._tracked_fill_review_intent_id is None
                or self._lease_healthy is not True
                or self._closed
                or self._native_stop_attempted
                or self._cancel_recovery_pending_intent_id is not None
                or self._cancel_recovery_restore_failed
                or self._lease_expires_at_ns is None
                or time.time_ns() >= self._lease_expires_at_ns
                or self._trader is None
                or not self._trader_write_ready()
                or self._cancel_port is None
                or self._cancel_gate is None
                or self._cancel_quota_admission is None
                or self.config.cancel_recovery_binding_provider is None
                or self._credential_binding_setup is None
            ):
                return False

            from bt_api_execution import (
                CtpOwnerCallbackObservationNotReadyV1,
                CtpOwnerCallbackObservationSnapshotV1,
                CtpOrderIdentityReservation,
                ExecutionState,
                OrderIntent,
            )
            from bt_api_execution.store import ExecutionRecoverySnapshotV1
            from bt_api_ctp.managed_dispatch_contracts import (
                stable_managed_command_id,
            )
            from bt_api_py.ctp_risk_dispatch_bridge import CtpRiskDispatchBridge
            from bt_api_ctp.managed_order_identifier import encode_ctp_provider_order_id

            store = self._store
            lease = self._writer_lease
            owner = self._execution_owner
            bridge = self._owned_risk_bridge
            scope = self.config.execution_scope
            intent_id = self._tracked_fill_review_intent_id
            if (
                store is None
                or lease is None
                or owner is None
                or type(bridge) is not CtpRiskDispatchBridge
            ):
                return False
            store.assert_writer_lease(scope, lease)
            active_binding = owner._assert_active_owner()

            record = store.get(intent_id, scope=scope)
            intent = store.get_intent(intent_id, scope=scope)
            if (
                record is None
                or type(intent) is not OrderIntent
                or intent.scope != scope
                or intent.position_effect.value != "OPEN"
                or intent.reduce_only is not False
                or record.intent_id != intent_id
                or record.scope_key != scope.key
                or record.payload_sha256 != intent.fingerprint
                or record.state is not ExecutionState.PARTIALLY_FILLED
                or record.dispatch_attempts != 1
                or record.review_required is not True
                or record.unknown_reason is not None
                or record.cumulative_commission is not None
                or record.filled_quantity <= 0
                or record.filled_quantity >= intent.quantity
                or record.provider_order_id is None
            ):
                return False
            filled_volume = record.filled_quantity.to_integral_value()
            requested_volume = intent.quantity.to_integral_value()
            if (
                filled_volume != record.filled_quantity
                or requested_volume != intent.quantity
                or filled_volume >= requested_volume
            ):
                return False

            # Bind the review event and current execution cut to the same
            # target. No second live/reviewed exposure may enter this route.
            review_event = bridge.read_tracked_update_review(
                record, writer_lease=lease
            )
            if (
                review_event.intent_id != intent_id
                or review_event.scope_key != scope.key
                or review_event.event_type != "manual_review_required"
                or review_event.state is not ExecutionState.PARTIALLY_FILLED
                or dict(review_event.payload)
                != {"reason_code": "evidenced_observation_reconciliation_failed"}
                or review_event.sequence != self._tracked_fill_review_event_sequence
            ):
                return False

            recovery = store.read_execution_recovery_snapshot((scope,))
            if type(recovery) is not ExecutionRecoverySnapshotV1:
                return False
            current = tuple(
                item for item in recovery.orders if item.record.intent_id == intent_id
            )
            if (
                len(current) != 1
                or current[0].record != record
                or current[0].intent != intent
                or current[0].latest_event != review_event
                or current[0].latest_observation_event is None
                or current[0].latest_observation_event.intent_id != intent_id
                or current[0].latest_observation_event.scope_key != scope.key
                or current[0].latest_observation_event.state
                is not ExecutionState.PARTIALLY_FILLED
                or current[0].latest_observation_event.event_type
                not in {"provider_observation", "reconciled_observation"}
            ):
                return False
            for item in recovery.orders:
                if item.record.intent_id == intent_id:
                    continue
                if item.record.state is ExecutionState.PENDING_ADMISSION:
                    # A persisted intent that has not reached admission or
                    # dispatch is not an open exposure. Permit this inert
                    # row only while it has no Risk/basic-admission grant,
                    # dispatch attempt, provider identity, fill, review, or
                    # unknown state. The degraded owner route cannot submit
                    # it, and every later write still rechecks runtime state.
                    pending = item.record
                    if (
                        pending.dispatch_attempts == 0
                        and pending.provider_order_id is None
                        and pending.filled_quantity == 0
                        and pending.permit_reference is None
                        and pending.basic_admission_reference is None
                        and pending.admission_context_sha256 is None
                        and pending.cumulative_commission is None
                        and pending.review_required is False
                        and pending.unknown_reason is None
                        and pending.group_binding is None
                    ):
                        continue
                    return False
                if (
                    item.record.state
                    in {
                        ExecutionState.PENDING_DISPATCH,
                        ExecutionState.DISPATCHING,
                        ExecutionState.UNKNOWN,
                        ExecutionState.ACKED,
                        ExecutionState.PARTIALLY_FILLED,
                        ExecutionState.FILLED,
                    }
                    or item.record.review_required
                    or item.record.unknown_reason is not None
                ):
                    return False

            if store.list_unresolved_cancellations_for_account(
                scope, writer_lease=lease
            ):
                return False

            reservation = store.read_ctp_order_identity(scope, intent_id)
            if (
                type(reservation) is not CtpOrderIdentityReservation
                or reservation.account_key != scope.account_key
                or reservation.scope_key != scope.key
                or reservation.trading_day != scope.trading_day
                or reservation.managed_intent_id != intent_id
            ):
                return False
            command_id = stable_managed_command_id(
                "submit", intent_id, reservation.runtime_order_id
            )
            command = store.read_ctp_dispatch_command(scope, command_id)
            correlation = None if command is None else command.correlation_key
            if (
                command is None
                or command.operation != "SUBMIT"
                or command.command_id != command_id
                or command.reservation_managed_intent_id != intent_id
                or command.order_ref != reservation.order_ref
                or command.status != "COMPLETED"
                or command.local_queue_receipt_queued is not True
                or correlation is None
                or correlation.operation != "SUBMIT"
                or correlation.command_id != command_id
                or correlation.reservation_managed_intent_id != intent_id
                or correlation.runtime_order_id != reservation.runtime_order_id
                or correlation.order_ref != reservation.order_ref
                or correlation.session_generation_id
                != active_binding.session_generation_id
                or correlation.session_binding_sha256
                != active_binding.session_binding_sha256
                or correlation.dispatch_front_id != active_binding.dispatch_front_id
                or correlation.dispatch_session_id != active_binding.dispatch_session_id
            ):
                return False

            callback_snapshot = store.read_ctp_owner_callback_observation_snapshot(
                scope, command_id
            )
            if (
                type(callback_snapshot) is not CtpOwnerCallbackObservationSnapshotV1
                or isinstance(
                    callback_snapshot, CtpOwnerCallbackObservationNotReadyV1
                )
                or callback_snapshot.account_key != scope.account_key
                or callback_snapshot.scope_key != scope.key
                or callback_snapshot.trading_day != scope.trading_day
                or callback_snapshot.command_id != command_id
                or callback_snapshot.owner_intent_id != active_binding.owner_intent_id
                or callback_snapshot.session_generation_id
                != active_binding.session_generation_id
                or callback_snapshot.order_ref != reservation.order_ref
                or callback_snapshot.request_id != correlation.native_request_id
                or callback_snapshot.front_id != active_binding.dispatch_front_id
                or callback_snapshot.session_id != active_binding.dispatch_session_id
                or callback_snapshot.provider_state != "PARTIALLY_FILLED"
                or callback_snapshot.volume_traded != filled_volume
                or callback_snapshot.filled_quantity != filled_volume
                or callback_snapshot.trade_fact_count <= 0
                or callback_snapshot.cumulative_commission is not None
                or callback_snapshot.commission_quality != "INCOMPLETE"
                or callback_snapshot.cancel_command_id is not None
                or callback_snapshot.cancel_action_state is not None
                or record.provider_order_id
                != encode_ctp_provider_order_id(
                    callback_snapshot.exchange_id, callback_snapshot.order_sys_id
                )
            ):
                return False
            return True
        except Exception:
            return False

    def recovery_ready(self) -> bool:
        """Allow a fresh CLOSE window during one tracked-fill review.

        This callback never restores normal readiness. It checks the exact
        already-read review latch and the active owner locally; the Store and
        Risk gate revalidate all source, permit, and position facts again at
        the recovery admission and claim boundaries.
        """

        return self._recovery_route_ready(allow_prior_attempt=False)

    def recovery_route_available(self) -> bool:
        """Allow restricted route entry for exact durable recovery replay.

        This is a Host/Registry entry-readiness predicate only. The submit port
        still requires the active server-bound review target and rejects every
        new child after the first Risk reservation attempt.
        """

        return self._recovery_route_ready(allow_prior_attempt=True)

    def _recovery_route_ready(self, *, allow_prior_attempt: bool) -> bool:
        """Read the current review latch for fresh dispatch or replay entry."""

        self._assert_owner_thread()
        if (
            self._recovery_close_available is not True
            or self._ready is not False
            or self._phase != "TRACKED_FILL_REVIEW_PENDING"
            or self._code != "CTP_TRACKED_ORDER_UPDATE_REQUIRES_REVIEW"
            or self._tracked_fill_review_intent_id is None
            or self._lease_healthy is not True
            or self._closed
            or self._native_stop_attempted
            or self._cancel_recovery_pending_intent_id is not None
            or self._cancel_recovery_restore_failed
            or self._lease_expires_at_ns is None
            or time.time_ns() >= self._lease_expires_at_ns
            or not self._trader_write_ready()
        ):
            return False
        bridge = self._owned_risk_bridge
        store = self._store
        lease = self._writer_lease
        owner = self._execution_owner
        if bridge is None or store is None or lease is None or owner is None:
            return False
        try:
            from bt_api_execution import ExecutionState

            store.assert_writer_lease(self.config.execution_scope, lease)
            owner._assert_active_owner()
            record = store.get(
                self._tracked_fill_review_intent_id,
                scope=self.config.execution_scope,
            )
            if (
                record is None
                or record.state not in {ExecutionState.CANCELLED, ExecutionState.FILLED}
            ):
                # A partially-filled parent still has live entry quantity.
                # Recovery CLOSE is enabled only after its remainder is
                # durably terminal; the Store rechecks its exact source window
                # and fill attribution at the eventual claim.
                return False
            review = bridge.read_tracked_update_review(record, writer_lease=lease)
            check = (
                bridge.recovery_route_available
                if allow_prior_attempt
                else bridge.recovery_ready
            )
            return check(
                target_intent_id=self._tracked_fill_review_intent_id,
                review_event=review,
                record=record,
                writer_lease=lease,
            ) is True
        except Exception:
            return False

    def _trader_write_ready(self) -> bool:
        """Recheck the full managed-write gate, not only login readiness."""

        if self._trader is None:
            return False
        try:
            gate_state = self._trader.get_execution_gate_state()
            if (
                self._trader.is_trading_ready is not True
                or not isinstance(gate_state, Mapping)
                or gate_state.get("managed") is not True
            ):
                return False
            if gate_state.get("sdk_write_admission") is True:
                # Iteration 62 (I62-10, D62-01/02): bt_api_py write admission
                # replaces the SimNow credential binding. The native gate keeps
                # its capability, arm and per-write revalidation: it must be
                # armed under the SDK-admitted profile for exactly this
                # runtime's instrument, and no SimNow binding may coexist.
                from bt_api_ctp.ctp.client import SDK_ADMITTED_PROFILE
                from bt_api_ctp.execution_instrument import canonical_ctp_instrument

                binding = self.config.native_binding
                expected = canonical_ctp_instrument(
                    binding.provider_instrument, binding.exchange_id
                )
                armed = gate_state.get("authorized_instruments") or [
                    gate_state.get("instrument")
                ]
                return bool(
                    expected
                    and gate_state.get("armed") is True
                    and gate_state.get("environment_profile") == SDK_ADMITTED_PROFILE
                    and expected in armed
                    and gate_state.get("runtime_simnow_credential_binding_configured")
                    is False
                )
            return (
                gate_state.get("armed") is False
                and gate_state.get("runtime_simnow_credential_binding_configured")
                is True
                and gate_state.get("runtime_simnow_write_verifier_configured")
                is True
            )
        except Exception:
            return False

    def _lease_failure(self) -> CtpExecutionRuntimeError:
        self._lease_healthy = False
        self._ready = False
        self._set_phase("LEASE_FAILED", "WRITER_LEASE_RENEWAL_FAILED")
        return CtpExecutionRuntimeError("WRITER_LEASE_RENEWAL_FAILED")

    def _renew_writer_lease_if_due(self, *, force: bool = False) -> bool:
        """Renew the existing fence without replacing its shared handle."""

        self._assert_owner_thread()
        lease = self._writer_lease
        store = self._store
        if (
            not self._lease_healthy
            or lease is None
            or store is None
            or self._family_owner is None
            or self._lease_expires_at_ns is None
            or self._next_lease_renewal_ns is None
        ):
            raise self._lease_failure()
        current_mono_ns = monotonic_ns()
        if time.time_ns() >= self._lease_expires_at_ns:
            raise self._lease_failure()
        if not force and current_mono_ns < self._next_lease_renewal_ns:
            return False

        try:
            from bt_api_execution import WriterLease

            renewed = store.acquire_or_renew_lease(
                self.config.execution_scope,
                self.config.lease_owner_id,
                ttl_ns=self.config.lease_ttl_ns,
                ctp_account_family_owner=self._family_owner,
            )
            if (
                type(renewed) is not WriterLease
                or renewed.scope_key != lease.scope_key
                or renewed.owner_id != lease.owner_id
                or renewed.fencing_token != lease.fencing_token
                or renewed.family_key != lease.family_key
                or renewed.family_owner_intent_id != lease.family_owner_intent_id
                or type(renewed.expires_at_ns) is not int
                or renewed.expires_at_ns <= time.time_ns()
            ):
                raise RuntimeError("writer lease identity changed")
            store.assert_writer_lease(self.config.execution_scope, lease)
        except Exception:
            raise self._lease_failure() from None

        # All ports and the callback owner retain `lease`; never substitute the
        # newly returned immutable snapshot. The store validates its owner and
        # fencing token against the renewed durable expiry.
        self._lease_expires_at_ns = renewed.expires_at_ns
        self._next_lease_renewal_ns = (
            monotonic_ns() + self._lease_renewal_interval_ns
        )
        return True

    def _startup_should_stop(self) -> bool:
        self._assert_owner_thread()
        if self._phase == "CLOSING":
            return True
        self._renew_writer_lease_if_due()
        return not self._lease_healthy

    def maintain(self, active_ids: frozenset[str]) -> None:
        """Renew and reconcile bounded callback-backed order state on owner thread."""

        self._assert_owner_thread()
        if type(active_ids) is not frozenset or any(
            type(item) is not str or not item for item in active_ids
        ):
            raise CtpExecutionRuntimeError("MAINTENANCE_INPUT_INVALID")
        if self._closed:
            return
        if not self._lease_healthy:
            raise CtpExecutionRuntimeError("WRITER_LEASE_RENEWAL_FAILED")
        self._renew_writer_lease_if_due()
        store = self._store
        lease = self._writer_lease
        if store is None or lease is None:
            raise self._lease_failure()
        try:
            store.assert_writer_lease(self.config.execution_scope, lease)
        except Exception:
            raise self._lease_failure() from None
        self._drain_owner_thread_calls()
        if self._cancel_recovery_pending_intent_id is not None:
            current_mono_ns = monotonic_ns()
            due_ns = self._next_reconciliation_ns
            if due_ns is not None and current_mono_ns < due_ns:
                return
            self._next_reconciliation_ns = (
                current_mono_ns + _RECONCILIATION_INTERVAL_NS
            )
            if (
                self._phase == "CANCEL_RECOVERY_PENDING"
                and not self._cancel_recovery_restore_failed
            ):
                self._reconcile_pending_cancel_recovery()
            return
        if self._tracked_fill_review_intent_id is not None:
            if self._phase != "TRACKED_FILL_REVIEW_PENDING":
                return
            current_mono_ns = monotonic_ns()
            due_ns = self._next_reconciliation_ns
            if due_ns is not None and current_mono_ns < due_ns:
                return
            self._next_reconciliation_ns = (
                current_mono_ns + _RECONCILIATION_INTERVAL_NS
            )
            try:
                owner = self._execution_owner
                if owner is None:
                    raise CtpExecutionRuntimeError(
                        "RECONCILIATION_SOURCE_UNAVAILABLE"
                    )
                owner.pump_callbacks(self.config.callback_pump_events)
                self._reconcile_tracked_fill_review()
            except CtpExecutionRuntimeError as error:
                self._ready = False
                self._set_phase("RECONCILIATION_FAILED", error.code)
                raise
            except Exception:
                self._ready = False
                self._set_phase(
                    "RECONCILIATION_FAILED", "EXECUTION_RECONCILIATION_FAILED"
                )
                raise CtpExecutionRuntimeError(
                    "EXECUTION_RECONCILIATION_FAILED"
                ) from None
            return
        if self._phase != "READY" or not self._ready:
            return
        current_mono_ns = monotonic_ns()
        due_ns = self._next_reconciliation_ns
        if (
            not self._reconciliation_page_pending
            and not self._reconciliation_pending_intents
            and due_ns is not None
            and current_mono_ns < due_ns
        ):
            return
        self._next_reconciliation_ns = (
            current_mono_ns + _RECONCILIATION_INTERVAL_NS
        )
        try:
            owner = self._execution_owner
            if owner is None:
                raise CtpExecutionRuntimeError(
                    "RECONCILIATION_SOURCE_UNAVAILABLE"
                )
            # Drain unsolicited settlement/audit ingress even when the
            # execution outbox has no active orders. Keep this bounded pump
            # after the exact writer-lease assertion above and before any
            # callback-backed order read.
            owner.pump_callbacks(self.config.callback_pump_events)
            if not self._reconciliation_pending_intents:
                self._refresh_reconciliation_candidates()
            self._reconcile_active_intents()
        except CtpExecutionRuntimeError as error:
            self._ready = False
            if (
                error.code == "EXECUTION_RECONCILIATION_REVIEW_REQUIRED"
                and self._tracked_fill_review_intent_id is not None
                and self._phase == "TRACKED_FILL_REVIEW_PENDING"
            ):
                raise
            self._set_phase("RECONCILIATION_FAILED", error.code)
            raise
        except Exception:
            self._ready = False
            self._set_phase("RECONCILIATION_FAILED", "EXECUTION_RECONCILIATION_FAILED")
            raise CtpExecutionRuntimeError("EXECUTION_RECONCILIATION_FAILED") from None

    def _reset_reconciliation_scan(self) -> None:
        self._reconciliation_after_sequence = 0
        self._reconciliation_page_pending = False
        self._reconciliation_pending_intents.clear()

    def _refresh_reconciliation_candidates(self) -> None:
        """Read one bounded outbox page and refresh only its exact-scope records."""

        from bt_api_execution import (
            ContractValidationError,
            ExecutionRecord,
            ExecutionState,
            OrderIntent,
        )
        from bt_api_execution.store import (
            ExecutionOutboxPageV1,
            ExecutionRecoveryIntentV1,
        )

        store = self._store
        scope = self.config.execution_scope
        if store is None or scope is None:
            raise CtpExecutionRuntimeError("RECONCILIATION_SOURCE_UNAVAILABLE")
        after_sequence = self._reconciliation_after_sequence
        try:
            page = store.read_execution_outbox_page(
                (scope,),
                after_sequence=after_sequence,
                limit=_RECONCILIATION_OUTBOX_PAGE_SIZE,
            )
        except ContractValidationError:
            # A replaced journal can have a lower high-water than the in-memory
            # cursor. Restart only this read-only scan from the beginning; the
            # Store still validates every row and generation at its own cut.
            if after_sequence == 0:
                raise
            self._reset_reconciliation_scan()
            page = store.read_execution_outbox_page(
                (scope,),
                after_sequence=0,
                limit=_RECONCILIATION_OUTBOX_PAGE_SIZE,
            )
        if type(page) is not ExecutionOutboxPageV1:
            raise CtpExecutionRuntimeError("RECONCILIATION_PAGE_INVALID")
        expected_generation = self._reconciliation_journal_generation
        if (
            expected_generation is not None
            and page.cut.journal_generation != expected_generation
        ):
            self._reset_reconciliation_scan()
            page = store.read_execution_outbox_page(
                (scope,),
                after_sequence=0,
                limit=_RECONCILIATION_OUTBOX_PAGE_SIZE,
            )
            if type(page) is not ExecutionOutboxPageV1:
                raise CtpExecutionRuntimeError("RECONCILIATION_PAGE_INVALID")
        self._reconciliation_journal_generation = page.cut.journal_generation
        active_states = frozenset(
            {
                ExecutionState.DISPATCHING,
                ExecutionState.UNKNOWN,
                ExecutionState.ACKED,
                ExecutionState.PARTIALLY_FILLED,
            }
        )
        pending_intents: list[str] = []
        for item in page.intents:
            if type(item) is not ExecutionRecoveryIntentV1:
                raise CtpExecutionRuntimeError("RECONCILIATION_PAGE_INVALID")
            record = item.record
            intent = item.intent
            if (
                type(record) is not ExecutionRecord
                or type(intent) is not OrderIntent
                or record.scope_key != scope.key
                or record.intent_id != intent.intent_id
                or intent.scope != scope
            ):
                raise CtpExecutionRuntimeError("RECONCILIATION_SCOPE_MISMATCH")
            if record.state in active_states:
                pending_intents.append(record.intent_id)
        self._reconciliation_pending_intents = pending_intents
        self._reconciliation_after_sequence = page.scanned_through
        self._reconciliation_page_pending = page.has_more
        if not page.has_more:
            # The next periodic sweep starts from the beginning so long-lived
            # active orders continue to be revisited without an unbounded cache.
            self._reconciliation_after_sequence = 0

    def _reconcile_active_intents(self) -> None:
        """Poll a finite round-robin batch through the existing callback-only port."""

        from bt_api_execution import (
            ExecutionRecord,
            ExecutionState,
            OrderIntent,
            ProviderObservation,
        )

        store = self._store
        scope = self.config.execution_scope
        facade = self._reconciliation_facade
        port = self._submit_port
        if store is None or facade is None or port is None:
            raise CtpExecutionRuntimeError("RECONCILIATION_SOURCE_UNAVAILABLE")
        if not self._reconciliation_pending_intents:
            return
        selected = tuple(
            self._reconciliation_pending_intents[:_RECONCILIATION_BATCH_SIZE]
        )
        del self._reconciliation_pending_intents[: len(selected)]
        active_states = frozenset(
            {
                ExecutionState.DISPATCHING,
                ExecutionState.UNKNOWN,
                ExecutionState.ACKED,
                ExecutionState.PARTIALLY_FILLED,
            }
        )
        for intent_id in selected:
            record = store.get(intent_id, scope=scope)
            if type(record) is not ExecutionRecord or record.scope_key != scope.key:
                raise CtpExecutionRuntimeError("RECONCILIATION_RECORD_UNAVAILABLE")
            if record.state not in active_states:
                continue
            intent = store.get_intent(intent_id, scope=scope)
            if type(intent) is not OrderIntent or intent.intent_id != intent_id:
                raise CtpExecutionRuntimeError("RECONCILIATION_INTENT_UNAVAILABLE")
            # CtpManagedSubmitPort.query reads the exact durable command and
            # callback snapshot on the owner thread. It never issues native
            # query/submit calls; None means there is no new trusted evidence.
            observation = port.query(intent)
            if observation is None:
                continue
            if (
                type(observation) is not ProviderObservation
                or observation.intent_id != intent_id
            ):
                raise CtpExecutionRuntimeError("RECONCILIATION_OBSERVATION_INVALID")
            updated = facade.record_provider_observation(observation)
            if type(updated) is not ExecutionRecord:
                raise CtpExecutionRuntimeError("RECONCILIATION_RECORD_INVALID")
            if updated.review_required:
                self._enter_tracked_fill_review(updated)
                raise CtpExecutionRuntimeError(
                    "EXECUTION_RECONCILIATION_REVIEW_REQUIRED"
                )

    def _read_tracked_fill_review_event(
        self,
        record: Any,
        *,
        expected_sequence: int | None = None,
    ) -> Any:
        """Accept only this bridge's exact durable ACKED_TRACKED review latch."""

        from bt_api_execution import ExecutionEvent, ExecutionRecord

        from bt_api_py.ctp_risk_dispatch_bridge import CtpRiskDispatchBridge

        bridge = self._owned_risk_bridge
        lease = self._writer_lease
        if (
            type(bridge) is not CtpRiskDispatchBridge
            or type(record) is not ExecutionRecord
            or lease is None
            or record.intent_id != self._tracked_fill_review_intent_id
            and self._tracked_fill_review_intent_id is not None
        ):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_CAPABILITY_INVALID")
        try:
            review_event = bridge.read_tracked_update_review(
                record, writer_lease=lease
            )
        except Exception:
            raise CtpExecutionRuntimeError(
                "TRACKED_FILL_REVIEW_CAPABILITY_INVALID"
            ) from None
        previous_sequence = self._tracked_fill_review_event_sequence
        if (
            type(review_event) is not ExecutionEvent
            or review_event.intent_id != record.intent_id
            or review_event.scope_key != record.scope_key
            or review_event.event_type != "manual_review_required"
            or (
                expected_sequence is not None
                and review_event.sequence != expected_sequence
            )
            or (
                previous_sequence is not None
                and review_event.sequence < previous_sequence
            )
        ):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_EVENT_INVALID")
        self._tracked_fill_review_intent_id = record.intent_id
        self._tracked_fill_review_event_sequence = review_event.sequence
        self._ready = False
        self._set_phase(
            "TRACKED_FILL_REVIEW_PENDING",
            "CTP_TRACKED_ORDER_UPDATE_REQUIRES_REVIEW",
        )
        return review_event

    def _enter_tracked_fill_review(self, record: Any) -> None:
        if self._tracked_fill_review_intent_id not in (None, record.intent_id):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_INTENT_MISMATCH")
        self._read_tracked_fill_review_event(record)

    def _reconcile_tracked_fill_review(self) -> None:
        """Maintain one tracked positive-fill order without dispatch or Risk release."""

        from bt_api_execution import (
            ExecutionRecord,
            ExecutionState,
            OrderIntent,
            ProviderObservation,
        )

        intent_id = self._tracked_fill_review_intent_id
        store = self._store
        scope = self.config.execution_scope
        facade = self._reconciliation_facade
        port = self._submit_port
        if intent_id is None or store is None or facade is None or port is None:
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_SOURCE_UNAVAILABLE")
        record = store.get(intent_id, scope=scope)
        if (
            type(record) is not ExecutionRecord
            or record.scope_key != scope.key
            or record.intent_id != intent_id
            or record.review_required is not True
            or record.state
            not in {
                ExecutionState.PARTIALLY_FILLED,
                ExecutionState.FILLED,
                ExecutionState.CANCELLED,
            }
            or record.filled_quantity <= 0
        ):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_RECORD_INVALID")
        self._read_tracked_fill_review_event(
            record, expected_sequence=self._tracked_fill_review_event_sequence
        )
        intent = store.get_intent(intent_id, scope=scope)
        if (
            type(intent) is not OrderIntent
            or intent.intent_id != intent_id
            or intent.scope != scope
            or record.payload_sha256 != intent.fingerprint
        ):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_INTENT_INVALID")

        observation = port.query(intent)
        if observation is None:
            return
        if (
            type(observation) is not ProviderObservation
            or observation.intent_id != intent_id
        ):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_OBSERVATION_INVALID")
        updated = facade.record_provider_observation(observation)
        if (
            type(updated) is not ExecutionRecord
            or updated.intent_id != intent_id
            or updated.scope_key != scope.key
            or updated.review_required is not True
            or updated.state
            not in {
                ExecutionState.PARTIALLY_FILLED,
                ExecutionState.FILLED,
                ExecutionState.CANCELLED,
            }
            or updated.filled_quantity <= 0
        ):
            raise CtpExecutionRuntimeError("TRACKED_FILL_REVIEW_UPDATE_INVALID")
        self._read_tracked_fill_review_event(updated)

    def next_maintenance_delay(self) -> float | None:
        """Seconds until bounded owner-thread lease/order maintenance is due."""

        self._assert_owner_thread()
        if not self._owner_thread_calls.empty():
            return 0.0
        pending_cancel_recovery = (
            self._cancel_recovery_pending_intent_id is not None
            or self._cancel_recovery_restore_failed
        )
        tracked_fill_review_pending = (
            self._tracked_fill_review_intent_id is not None
            and self._phase == "TRACKED_FILL_REVIEW_PENDING"
            and not self._ready
        )
        if (
            self._closed
            or (
                self._phase != "READY"
                and not pending_cancel_recovery
                and not tracked_fill_review_pending
            )
            or (
                not self._ready
                and not pending_cancel_recovery
                and not tracked_fill_review_pending
            )
            or not self._lease_healthy
            or self._next_lease_renewal_ns is None
        ):
            return None
        if (
            self._lease_expires_at_ns is not None
            and time.time_ns() >= self._lease_expires_at_ns
        ):
            return 0.0
        now_ns = monotonic_ns()
        next_due_ns = self._next_lease_renewal_ns
        if self._next_reconciliation_ns is not None:
            next_due_ns = min(next_due_ns, self._next_reconciliation_ns)
        return max(0, next_due_ns - now_ns) / 1_000_000_000

    def _validate_scope(self) -> None:
        from bt_api_base.service_protocol import WireScope
        from bt_api_execution import ExecutionScope

        from bt_api_py.ctp_admission_authority import CtpNativeDispatchBindingV1

        scope = self.config.execution_scope
        wire = self.config.service_scope
        binding = self.config.native_binding
        if (
            type(scope) is not ExecutionScope
            or scope.provider != "ctp"
            or scope.environment != "simulation"
            or not scope.trading_day
            or type(wire) is not WireScope
            or wire.run_id is not None
            or wire.account_refs
            or wire.manual_book_ref is not None
            or wire.group_id is not None
            or wire.leg_id is not None
            or wire.account_ref != scope.account_ref
            or wire.strategy_ref != scope.strategy_id
            or type(binding) is not CtpNativeDispatchBindingV1
            or binding.account_ref != scope.account_ref
            or binding.scope_key != scope.key
        ):
            raise CtpExecutionRuntimeError("TRUSTED_SCOPE_INVALID")

    def _set_phase(self, phase: str, code: str | None = None) -> None:
        self._phase = phase
        self._code = code

    def bootstrap(self) -> Any:
        """Create and return the owned component resources on the owner thread."""

        if self.owner_thread_id is not None:
            raise CtpExecutionRuntimeError("RUNTIME_ALREADY_STARTED")
        self.owner_thread_id = threading.get_ident()
        self._owner_thread = threading.current_thread()
        try:
            self._validate_scope()
            self._bootstrap_owned()
            self._renew_writer_lease_if_due(force=True)
            self._resources = self._make_resources(complete=True)
            self._next_reconciliation_ns = (
                monotonic_ns() + _RECONCILIATION_INTERVAL_NS
            )
            self._ready = True
            with self._owner_thread_calls_lock:
                self._owner_thread_calls_accepting = True
            self._set_phase("READY")
            return self._resources
        except Exception as exc:
            # Keep only a finite code; never place a native exception, credential,
            # callback field, or operator-provided string in the public error.
            if self._code is None:
                self._code = (
                    exc.code
                    if type(exc) is CtpExecutionRuntimeError
                    else "BOOTSTRAP_FAILED"
                )
            self._ready = False
            self._set_phase("BOOTSTRAP_FAILED", self._code)
            if self._has_owned_state():
                resources = self._make_resources(complete=False)
                self._resources = resources
                from bt_api_py.service_components import ServiceResourceConstructionError

                raise ServiceResourceConstructionError(resources) from None
            if isinstance(exc, CtpExecutionRuntimeError):
                raise exc
            raise CtpExecutionRuntimeError(self._code) from None

    def _bootstrap_owned(self) -> None:
        from bt_api_ctp.ctp.callback_ingress import (
            CtpTraderCallbackIngressAckV2,
            CtpTraderCallbackIngressRecordV2,
        )
        from bt_api_ctp.ctp.client import TraderClient
        from bt_api_execution import SqliteExecutionStore
        from bt_api_ctp.ctp_callback_session import CtpCallbackSessionStoreAdapter

        from bt_api_py.ctp_callback_evidence import CtpSessionIngressEvidenceVerifierV1
        from bt_api_py.ctp_managed_cancel_port import CtpManagedCancelPort
        from bt_api_py.ctp_managed_submit_port import CtpManagedSubmitPort
        from bt_api_py.ctp_service_execution import CtpOwnerCallbackReconciliationPort

        self._set_phase("STORE_OPEN")
        self._store = SqliteExecutionStore(self.config.store_path)
        self._set_phase("ACCOUNT_FAMILY_OWNER")
        self._family_owner = self._store.acquire_ctp_account_family_owner(
            self.config.execution_scope
        )
        self._set_phase("WRITER_LEASE")
        self._writer_lease = self._store.acquire_or_renew_lease(
            self.config.execution_scope,
            self.config.lease_owner_id,
            ttl_ns=self.config.lease_ttl_ns,
            ctp_account_family_owner=self._family_owner,
        )
        self._lease_expires_at_ns = self._writer_lease.expires_at_ns
        self._next_lease_renewal_ns = (
            monotonic_ns() + self._lease_renewal_interval_ns
        )
        self._lease_healthy = True
        self._set_phase("CALLBACK_OWNER")
        self._callback_owner = self._store.create_ctp_callback_session_owner(
            self.config.execution_scope,
            writer_lease=self._writer_lease,
            authorized_scopes=(self.config.execution_scope,),
        )
        self._session_adapter = CtpCallbackSessionStoreAdapter(
            self._store,
            self.config.execution_scope,
            self._callback_owner,
            self._writer_lease,
            CtpTraderCallbackIngressAckV2,
            CtpTraderCallbackIngressRecordV2,
        )

        self._set_phase("TRADER_CREATE")
        trader_config = self.config.trader
        self._trader = TraderClient(
            trader_config.front,
            trader_config.broker_id,
            trader_config.user_id,
            trader_config.password,
            app_id=trader_config.app_id,
            auth_code=trader_config.auth_code,
            auto_settlement_confirm=False,
            md_front=trader_config.md_front,
            ctp_env_profile=trader_config.ctp_env_profile,
        )
        self._trader.install_callback_ingress_sink(
            self._callback_owner,
            self._session_adapter.sink,
            self._session_adapter.bind_session,
            self._session_adapter.verify_native_call,
        )
        self._set_phase("TRADER_START")
        self._native_start_attempted = True
        # No Join observer: the vendor Join() returns only after Release(), so
        # an observed generation's stop_and_wait could never complete. A no-Join
        # generation releases once its callback/request leases drain; one that
        # fails or stops before Init releases at once (bt_api_ctp, I62-11).
        self._trader.start(block=False, join_observer=False)
        self._set_phase("LOGIN_WAIT")
        if not self._trader.wait_ready(
            self.config.startup_timeout_s,
            should_stop=self._startup_should_stop,
        ):
            raise self._fail("TRADER_LOGIN_TIMEOUT")

        facts = self._store.read_ctp_callback_session_context_facts(
            self._callback_owner
        )
        if type(facts) is not tuple or len(facts) != 3:
            raise self._fail("CALLBACK_SESSION_READBACK_FAILED")
        binding, broker_id, user_id = facts
        from bt_api_execution import CtpCallbackSessionBindingV1

        scope = self.config.execution_scope
        if (
            type(binding) is not CtpCallbackSessionBindingV1
            or binding.owner_intent_id != self._callback_owner.owner_intent_id
            or binding.account_key != scope.account_key
            or binding.scope_key != scope.key
            or binding.trading_day != scope.trading_day
            or not binding.session_generation_id
            or broker_id != trader_config.broker_id
            or user_id != trader_config.user_id
            or self.config.native_binding.investor_id != user_id
        ):
            raise self._fail("CALLBACK_SESSION_BINDING_MISMATCH")
        session_generation_id = binding.session_generation_id
        self._session_generation_id = session_generation_id

        self._callback_verifier = CtpSessionIngressEvidenceVerifierV1(
            self._store,
            scope,
            self._writer_lease,
            self._session_adapter,
            self._trader,
            session_generation_id=session_generation_id,
        )
        self._reconciliation_port = CtpOwnerCallbackReconciliationPort(
            self._store,
            scope,
            self._writer_lease,
            self._session_adapter,
            session_generation_id=session_generation_id,
            callback_verifier=self._callback_verifier,
            trade_fact_verifier=self._callback_verifier,
        )

        self._set_phase("TRADER_PREPARE")
        try:
            self._renew_writer_lease_if_due(force=True)
            binding_setup = self.config.prepare_trader(self._trader)
            if self.config.cancel_recovery_binding_provider is not None:
                from bt_api_ctp.ctp.client import CtpRuntimeSimNowCredentialBinding

                if (
                    type(binding_setup) is not CtpRuntimeCredentialBindingSetupV1
                    or binding_setup.capability is None
                    or type(binding_setup.initial_binding)
                    is not CtpRuntimeSimNowCredentialBinding
                ):
                    raise ValueError("managed cancel credential setup is unavailable")
                self._credential_binding_setup = binding_setup
            self._renew_writer_lease_if_due(force=True)
        except Exception:
            if not self._lease_healthy:
                raise self._lease_failure() from None
            raise self._fail("TRADER_PREPARATION_FAILED") from None
        if not self._trader_write_ready():
            raise self._fail("TRADER_WRITE_READINESS_UNPROVEN")

        self._set_phase("SUBMIT_PORT")
        self._submit_port = CtpManagedSubmitPort(
            self._store,
            scope,
            self._writer_lease,
            self._trader,
            self._session_adapter,
            self._reconciliation_port,
            self.config.native_binding,
            session_generation_id=session_generation_id,
            recovery_target_intent_id_provider=lambda: self._tracked_fill_review_intent_id,
            callback_pump_events=self.config.callback_pump_events,
        )
        self._set_phase("BASIC_ADMISSION")
        self._basic_gate = self.config.basic_admission_factory(
            self._store, scope, self._submit_port
        )
        from bt_api_execution import ExecutionBasicAdmissionGate

        if type(self._basic_gate) is not ExecutionBasicAdmissionGate:
            raise self._fail("BASIC_ADMISSION_GATE_INVALID")
        self._submit_port.bind_basic_admission(self._basic_gate)
        self._execution_owner = self._submit_port.execution_owner

        context = CtpRuntimeAdmissionContext(
            store=self._store,
            execution_scope=scope,
            service_scope=self.config.service_scope,
            writer_lease=self._writer_lease,
            trader=self._trader,
            family_owner=self._family_owner,
            callback_owner=self._callback_owner,
            session_adapter=self._session_adapter,
            session_generation_id=session_generation_id,
            reconciliation_port=self._reconciliation_port,
            submit_port=self._submit_port,
            basic_admission_gate=self._basic_gate,
            execution_owner=self._execution_owner,
            native_binding=self.config.native_binding,
            recovery_close_source_authority=self._bind_recovery_close_source_authority(
                scope
            ),
            owner_thread_invoker=self.owner_thread_invoker,
        )
        self._recovery_close_source_authority = (
            context.recovery_close_source_authority
        )
        self._set_phase("RISK_ADMISSION")
        try:
            admission = self.config.risk_admission_factory(context)
        except Exception:
            raise self._fail("RISK_ADMISSION_FACTORY_FAILED") from None
        from bt_api_py.ctp_risk_dispatch_bridge import CtpRiskDispatchBridge

        if isinstance(admission, Mapping):
            candidate_order_gate = admission.get("order_gate")
            if type(candidate_order_gate) is CtpRiskDispatchBridge:
                # Retain its owned journal fence even if later composition
                # validation fails; close follows native stop and inbox drain.
                self._owned_risk_bridge = candidate_order_gate
        if not isinstance(admission, Mapping) or set(admission) - {
            "order_gate",
            "cancel_gate",
            "cancel_quota_admission",
        }:
            raise self._fail("RISK_ADMISSION_RESOURCES_INVALID")
        self._order_gate = admission.get("order_gate")
        self._cancel_gate = admission.get("cancel_gate")
        self._cancel_quota_admission = admission.get("cancel_quota_admission")
        if self._order_gate is None or self._cancel_gate is None:
            raise self._fail("RISK_ADMISSION_RESOURCES_INCOMPLETE")
        if self._cancel_quota_admission is not None and not callable(
            self._cancel_quota_admission
        ):
            raise self._fail("CANCEL_QUOTA_ADMISSION_INVALID")

        from bt_api_py.service_execution_risk_cancel import RiskExecutionCancelAdmissionGate

        if (
            type(self._cancel_gate) is not RiskExecutionCancelAdmissionGate
            or self._cancel_gate._store is not self._store
            or self._cancel_gate._execution_scope != scope
        ):
            raise self._fail("RISK_CANCEL_GATE_BINDING_INVALID")
        if type(self._order_gate) is not CtpRiskDispatchBridge:
            raise self._fail("RISK_DISPATCH_BRIDGE_REQUIRED")
        cancel_risk_gate = self._cancel_gate._gate
        if (
            self._order_gate.is_bound_to(cancel_risk_gate) is not True
            or self._order_gate._journal is not self._cancel_gate._journal
        ):
            raise self._fail("RISK_ORDER_CANCEL_AUTHORITY_MISMATCH")
        try:
            self._submit_port.bind_risk_dispatch_bridge(self._order_gate)
        except Exception:
            raise self._fail("RISK_DISPATCH_BRIDGE_BINDING_FAILED") from None
        risk_gate = getattr(self._order_gate, "_gate", None)
        self._recovery_close_available = bool(
            self._recovery_close_source_authority is not None
            and getattr(risk_gate, "_recovery_close_source_authority", None)
            is self._recovery_close_source_authority
            and callable(getattr(risk_gate, "reserve_recovery_reduction", None))
            and callable(
                getattr(risk_gate, "verify_recovery_reduction_allocation", None)
            )
            and callable(
                getattr(self._store, "read_ctp_recovery_close_source_facts", None)
            )
            and callable(
                getattr(self._store, "issue_ctp_recovery_close_source_proof", None)
            )
            and callable(
                getattr(self._store, "authorize_ctp_recovery_close_dispatch", None)
            )
        )
        from bt_api_execution import ManagedExecutionFacade

        self._reconciliation_facade = ManagedExecutionFacade(
            self._store,
            scope,
            writer_id=self._writer_lease.owner_id,
            admission_gate=self._order_gate,
            basic_admission_gate=self._basic_gate,
            borrowed_writer_lease=self._writer_lease,
        )
        self._cancel_port = CtpManagedCancelPort(
            self._execution_owner,
            self._cancel_gate,
            callback_pump_events=self.config.callback_pump_events,
            after_cancel_observation=self._after_cancel_observation,
        )

        # Preparation can emit settlement/query audit callbacks after login.
        # Apply them through this exact owner before publishing READY; the
        # Store's dispatch-time unapplied-ingress fence remains authoritative.
        self._set_phase("CALLBACK_READY_DRAIN")
        drained = 0
        try:
            while not self._callback_ingress_is_drained():
                remaining = self.config.drain_limit - drained
                if remaining <= 0:
                    raise self._fail("STARTUP_CALLBACK_DRAIN_LIMIT")
                self._renew_writer_lease_if_due()
                applied = self._execution_owner.pump_callbacks(
                    min(self.config.callback_pump_events, remaining)
                )
                if not applied:
                    raise self._fail("STARTUP_CALLBACK_DRAIN_INCOMPLETE")
                drained += len(applied)
        except CtpExecutionRuntimeError:
            raise
        except Exception:
            raise self._fail("STARTUP_CALLBACK_DRAIN_FAILED") from None

    def _fail(self, code: str) -> CtpExecutionRuntimeError:
        self._code = code
        return CtpExecutionRuntimeError(code)

    def _has_owned_state(self) -> bool:
        return any(
            value is not None
            for value in (
                self._store,
                self._trader,
                self._family_owner,
                self._writer_lease,
                self._callback_owner,
            )
        )

    def _callback_ingress_is_drained(self) -> bool:
        store = self._store
        owner = self._callback_owner
        lease = self._writer_lease
        if store is None or owner is None or lease is None:
            self._set_phase("CLOSE_FAILED", "CALLBACK_DRAIN_STATUS_UNAVAILABLE")
            raise CtpExecutionRuntimeError("CALLBACK_DRAIN_STATUS_UNAVAILABLE")
        try:
            from bt_api_execution import CtpCallbackIngressDrainStatus

            status = store.read_ctp_callback_ingress_drain_status(
                owner,
                writer_lease=lease,
            )
        except Exception:
            self._set_phase("CLOSE_FAILED", "CALLBACK_DRAIN_STATUS_UNAVAILABLE")
            raise CtpExecutionRuntimeError(
                "CALLBACK_DRAIN_STATUS_UNAVAILABLE"
            ) from None
        if type(status) is not CtpCallbackIngressDrainStatus:
            self._set_phase("CLOSE_FAILED", "CALLBACK_DRAIN_STATUS_INVALID")
            raise CtpExecutionRuntimeError("CALLBACK_DRAIN_STATUS_INVALID")
        live_owner = status.owner_state in {"PREPARED", "ACTIVE"} and status.poison_code is None
        normal_stop_owner = (
            self._native_stop_complete is True
            and status.owner_state == "POISONED"
            and status.poison_code == "owner_stop"
        )
        if (
            status.owner_handle is not owner
            or not (live_owner or normal_stop_owner)
            or type(status.last_source_sequence) is not int
            or type(status.applied_source_sequence) is not int
            or type(status.pending_count) is not int
            or type(status.drained) is not bool
        ):
            self._set_phase("CLOSE_FAILED", "CALLBACK_DRAIN_STATUS_INVALID")
            raise CtpExecutionRuntimeError("CALLBACK_DRAIN_STATUS_INVALID")
        return status.drained

    def _cancel_authorization_request(
        self, intent: Any, prepared_target: Any
    ) -> CtpRuntimeCancelAuthorizationRequestV1:
        from bt_api_execution import CtpCallbackSessionBindingV1

        store = self._store
        owner = self._callback_owner
        trader = self._trader
        execution_owner = self._execution_owner
        lease = self._writer_lease
        if (
            store is None
            or owner is None
            or trader is None
            or execution_owner is None
            or lease is None
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_RUNTIME_UNAVAILABLE")

        scope = self.config.execution_scope
        store.assert_writer_lease(scope, lease)
        session_facts = store.read_ctp_callback_session_context_facts(owner)
        if type(session_facts) is not tuple or len(session_facts) != 3:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SESSION_UNAVAILABLE")
        binding, broker_id, user_id = session_facts
        if (
            type(binding) is not CtpCallbackSessionBindingV1
            or binding.owner_intent_id != owner.owner_intent_id
            or binding.account_key != scope.account_key
            or binding.scope_key != scope.key
            or binding.trading_day != scope.trading_day
            or binding.session_generation_id
            != execution_owner._session_generation_id
            or broker_id != self.config.trader.broker_id
            or user_id != self.config.trader.user_id
            or self.config.native_binding.investor_id != user_id
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SESSION_MISMATCH")

        state = trader.get_session_state()
        if not isinstance(state, Mapping):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SESSION_UNAVAILABLE")
        account_fingerprint = state.get("account_fingerprint")
        trading_day = state.get("trading_day")
        connection_generation = state.get("connection_generation")
        if (
            type(account_fingerprint) is not str
            or not account_fingerprint
            or trading_day != scope.trading_day
            or type(connection_generation) is not int
            or connection_generation != binding.connection_generation
            or state.get("trading_ready") is not True
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SESSION_MISMATCH")

        from bt_api_py.ctp_managed_cancel_port import (
            CtpPreparedCancelAuthorizationFactsV1,
        )

        if (
            type(prepared_target) is not CtpPreparedCancelAuthorizationFactsV1
            or prepared_target.cancel_id != intent.cancel_id
            or prepared_target.target_intent_id != intent.target_intent_id
            or prepared_target.provider_order_id != intent.provider_order_id
            or prepared_target.account_key != scope.account_key
            or prepared_target.scope_key != scope.key
            or prepared_target.trading_day != scope.trading_day
            or prepared_target.session_generation_id != binding.session_generation_id
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_TARGET_MISMATCH")

        return CtpRuntimeCancelAuthorizationRequestV1(
            cancel_intent=intent,
            prepared_target=prepared_target,
            account_key=scope.account_key,
            scope_key=scope.key,
            trading_day=scope.trading_day,
            session_generation_id=binding.session_generation_id,
            callback_owner_intent_id=owner.owner_intent_id,
            account_fingerprint=f"acct_{account_fingerprint}",
            connection_generation=connection_generation,
            environment_profile=self.config.trader.ctp_env_profile,
            td_front=self.config.trader.front,
            md_front=self.config.trader.md_front,
        )

    def _validate_cancel_recovery_binding(
        self,
        binding: Any,
        *,
        request: CtpRuntimeCancelAuthorizationRequestV1,
    ) -> None:
        from bt_api_ctp.ctp.client import CtpRuntimeSimNowCredentialBinding
        from bt_api_py._ctp_execution_authorization import (
            RECOVERY_APPROVAL_PURPOSE,
            SIMNOW_RECOVERY_APPROVAL_SCHEMA_VERSION,
        )

        setup = self._credential_binding_setup
        if (
            type(setup) is not CtpRuntimeCredentialBindingSetupV1
            or type(binding) is not CtpRuntimeSimNowCredentialBinding
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_BINDING_MISMATCH")
        initial = setup.initial_binding
        if (
            binding.owner is not initial.owner
            or binding.credential_binding_verifier
            is not initial.credential_binding_verifier
            or (binding.td_front, binding.md_front, binding.environment_profile)
            != (initial.td_front, initial.md_front, initial.environment_profile)
            or (binding.td_front, binding.md_front, binding.environment_profile)
            != (request.td_front, request.md_front, request.environment_profile)
            or not callable(binding.write_intent_verifier)
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_BINDING_MISMATCH")

        initial_payload = initial.approval.payload
        payload = binding.approval.payload
        if not isinstance(initial_payload, Mapping) or not isinstance(payload, Mapping):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_BINDING_MISMATCH")
        mutable_fields = {
            "purpose",
            "schema_version",
            "recovery_actions",
            "approval_id",
            "nonce",
            "issued_at",
            "not_before",
            "expires_at",
            "revocation_snapshot_version",
            "authorized_instruments",
            "primary_instrument",
        }
        if any(
            payload.get(key) != value
            for key, value in initial_payload.items()
            if key not in mutable_fields
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SCOPE_MISMATCH")
        if (
            payload.get("purpose") != RECOVERY_APPROVAL_PURPOSE
            or payload.get("schema_version")
            != SIMNOW_RECOVERY_APPROVAL_SCHEMA_VERSION
            or payload.get("account_fingerprint") != request.account_fingerprint
            or payload.get("trading_day") != request.trading_day
            or payload.get("connection_generation") != request.connection_generation
            or payload.get("environment_profile") != request.environment_profile
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SCOPE_MISMATCH")

        actions = payload.get("recovery_actions")
        if type(actions) is not list or len(actions) != 1 or not isinstance(actions[0], Mapping):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_ACTION_MISMATCH")
        action = actions[0]
        target = request.prepared_target
        expected = {
            "action_id": request.cancel_intent.cancel_id,
            "action_kind": "cancel",
            "instrument_id": target.instrument_id,
            "exchange_id": target.exchange_id,
            "account_fingerprint": request.account_fingerprint,
            "trading_day": request.trading_day,
            "connection_generation": request.connection_generation,
            "environment_profile": request.environment_profile,
        }
        if any(action.get(key) != value for key, value in expected.items()):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_ACTION_MISMATCH")

    def _prepare_cancel_recovery_binding(self, intent: Any) -> None:
        self._assert_owner_thread()
        if self._cancel_port is None or self._trader is None:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_RUNTIME_UNAVAILABLE")
        self._renew_writer_lease_if_due(force=True)
        prepared = self._cancel_port.prepare_target(intent)
        provider = self.config.cancel_recovery_binding_provider
        if provider is None:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_PROVIDER_UNAVAILABLE")
        if self._credential_binding_setup is None:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_SETUP_UNAVAILABLE")

        request = self._cancel_authorization_request(intent, prepared)
        try:
            binding = provider.resolve_verified_binding(request)
        except Exception:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_PROVIDER_FAILED") from None

        # Provider work may take time. Re-read the same persisted intent,
        # session and target through the existing preparation path before the
        # public client API installs the returned binding.
        self._renew_writer_lease_if_due(force=True)
        current = self._cancel_port.refresh_target(intent)
        if current != prepared or self._cancel_authorization_request(intent, current) != request:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_CONTEXT_CHANGED")
        self._validate_cancel_recovery_binding(binding, request=request)
        # Recovery authority is operation-specific. Withdraw runtime readiness
        # before the client installs it; the facade may still complete this
        # already-authorized cancel on the owner thread, but no later request
        # can treat the recovery binding as normal entry authority.
        self._cancel_recovery_pending_intent_id = intent.cancel_id
        self._cancel_recovery_pending_intent = intent
        self._cancel_recovery_binding = binding
        self._cancel_recovery_restore_failed = False
        self._ready = False
        self._next_reconciliation_ns = monotonic_ns()
        self._set_phase("CANCEL_RECOVERY_PENDING")
        try:
            configured = self._trader.configure_runtime_simnow_credential_binding(
                self._credential_binding_setup.capability,
                binding,
            )
        except Exception:
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_BINDING_REJECTED") from None
        if (
            not isinstance(configured, Mapping)
            or configured.get("configured") is not True
            or configured.get("connection_generation") != request.connection_generation
        ):
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_BINDING_REJECTED")

    def _after_cancel_observation(
        self,
        intent: Any,
        observation: Any | None,
        dispatch_started: bool,
    ) -> None:
        """Restore startup ENTRY authority only after safe cancel evidence."""

        self._assert_owner_thread()
        from bt_api_execution import CancelIntent, CancelObservation, ExecutionState

        if type(intent) is not CancelIntent or type(dispatch_started) is not bool:
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase(
                "CANCEL_RECOVERY_RESTORE_FAILED", "CANCEL_RECOVERY_CONTEXT_MISMATCH"
            )
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_CONTEXT_MISMATCH")

        # Reconciliation also reports already-terminal durable cancels. When
        # no recovery binding is pending, that ordinary read-only replay must
        # not try to restore an ENTRY binding a second time.
        if self._cancel_recovery_pending_intent_id is None:
            if (
                self._cancel_recovery_restore_failed
                or self._cancel_recovery_binding is not None
            ):
                self._ready = False
                self._cancel_recovery_restore_failed = True
                self._set_phase(
                    "CANCEL_RECOVERY_RESTORE_FAILED", "CANCEL_RECOVERY_CONTEXT_MISMATCH"
                )
                raise CtpExecutionRuntimeError("CANCEL_RECOVERY_CONTEXT_MISMATCH")
            return

        if (
            self._cancel_recovery_pending_intent_id != intent.cancel_id
            or self._cancel_recovery_pending_intent != intent
            or self._cancel_recovery_binding is None
            or self._trader is None
            or self._credential_binding_setup is None
        ):
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase("CANCEL_RECOVERY_RESTORE_FAILED", "CANCEL_RECOVERY_CONTEXT_MISMATCH")
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_CONTEXT_MISMATCH")

        terminal_observation = (
            type(observation) is CancelObservation
            and observation.cancel_id == intent.cancel_id
            and observation.target_intent_id == intent.target_intent_id
            and observation.provider_order_id == intent.provider_order_id
            and observation.state in {ExecutionState.CANCELLED, ExecutionState.REJECTED}
        )
        known_not_dispatched = observation is None and dispatch_started is False
        if not terminal_observation and not known_not_dispatched:
            self._ready = False
            self._set_phase("CANCEL_RECOVERY_PENDING", "CANCEL_OUTCOME_UNRESOLVED")
            return

        try:
            self._renew_writer_lease_if_due(force=True)
            configured = self._trader.configure_runtime_simnow_credential_binding(
                self._credential_binding_setup.capability,
                self._credential_binding_setup.initial_binding,
            )
            current_session = self._trader.get_session_state()
            if (
                not isinstance(configured, Mapping)
                or configured.get("configured") is not True
                or not isinstance(current_session, Mapping)
                or type(current_session.get("connection_generation")) is not int
                or configured.get("connection_generation")
                != current_session.get("connection_generation")
                or not self._trader_write_ready()
            ):
                raise CtpExecutionRuntimeError("CANCEL_RECOVERY_RESTORE_REJECTED")
        except Exception:
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase(
                "CANCEL_RECOVERY_RESTORE_FAILED", "CANCEL_RECOVERY_RESTORE_REJECTED"
            )
            raise CtpExecutionRuntimeError("CANCEL_RECOVERY_RESTORE_REJECTED") from None

        self._cancel_recovery_pending_intent_id = None
        self._cancel_recovery_pending_intent = None
        self._cancel_recovery_binding = None
        self._cancel_recovery_restore_failed = False
        if self._tracked_fill_review_intent_id is not None:
            try:
                self._restore_tracked_fill_review_after_cancel(intent, observation)
            except Exception:
                self._ready = False
                self._cancel_recovery_restore_failed = True
                self._set_phase(
                    "CANCEL_RECOVERY_RESTORE_FAILED",
                    "CANCEL_REVIEW_READBACK_FAILED",
                )
                raise CtpExecutionRuntimeError(
                    "CANCEL_REVIEW_READBACK_FAILED"
                ) from None
            return
        self._ready = True
        self._set_phase("READY")

    def _restore_tracked_fill_review_after_cancel(
        self, cancel_intent: Any, cancel_observation: Any | None
    ) -> None:
        """Keep an unknown-fee positive fill degraded after canceling its remainder."""

        from bt_api_execution import (
            CancelIntent,
            CancelObservation,
            ExecutionRecord,
            ExecutionState,
            OrderIntent,
            ProviderObservation,
        )
        from bt_api_py.ctp_risk_dispatch_bridge import CtpRiskDispatchBridge

        intent_id = self._tracked_fill_review_intent_id
        store = self._store
        facade = self._reconciliation_facade
        port = self._submit_port
        bridge = self._owned_risk_bridge
        lease = self._writer_lease
        scope = self.config.execution_scope
        if (
            type(cancel_intent) is not CancelIntent
            or intent_id != cancel_intent.target_intent_id
            or store is None
            or facade is None
            or port is None
            or type(bridge) is not CtpRiskDispatchBridge
            or lease is None
        ):
            raise CtpExecutionRuntimeError("CANCEL_REVIEW_BINDING_INVALID")
        store.assert_writer_lease(scope, lease)
        record = store.get(intent_id, scope=scope)
        if (
            type(record) is not ExecutionRecord
            or record.scope_key != scope.key
            or record.intent_id != intent_id
            or record.review_required is not True
            or record.filled_quantity <= 0
            or record.cumulative_commission is not None
            or record.state
            not in {
                ExecutionState.PARTIALLY_FILLED,
                ExecutionState.FILLED,
                ExecutionState.CANCELLED,
            }
        ):
            raise CtpExecutionRuntimeError("CANCEL_REVIEW_RECORD_INVALID")

        if (
            type(cancel_observation) is CancelObservation
            and cancel_observation.state is ExecutionState.CANCELLED
            and record.state is not ExecutionState.CANCELLED
        ):
            intent = store.get_intent(intent_id, scope=scope)
            if type(intent) is not OrderIntent or intent.scope != scope:
                raise CtpExecutionRuntimeError("CANCEL_REVIEW_INTENT_INVALID")
            observation = port.query(intent)
            if (
                type(observation) is not ProviderObservation
                or observation.intent_id != intent_id
                or observation.state is not ExecutionState.CANCELLED
                or observation.filled_quantity != record.filled_quantity
                or observation.cumulative_commission is not None
            ):
                raise CtpExecutionRuntimeError("CANCEL_REVIEW_PROVIDER_STATE_INVALID")
            # The exact terminal QueryOrder projection flows through the same
            # execution facade and Risk bridge as an ordinary reconciliation.
            # Its positive fill stays review-latched because CTP supplies no fee.
            record = facade.record_provider_observation(observation)
            if (
                type(record) is not ExecutionRecord
                or record.state is not ExecutionState.CANCELLED
                or record.review_required is not True
                or record.filled_quantity <= 0
                or record.cumulative_commission is not None
            ):
                raise CtpExecutionRuntimeError("CANCEL_REVIEW_TERMINAL_READBACK_INVALID")

        review_event = bridge.read_tracked_update_review(
            record, writer_lease=lease
        )
        if (
            review_event.intent_id != intent_id
            or review_event.scope_key != scope.key
            or review_event.event_type != "manual_review_required"
        ):
            raise CtpExecutionRuntimeError("CANCEL_REVIEW_EVENT_INVALID")
        self._tracked_fill_review_event_sequence = review_event.sequence
        self._ready = False
        self._set_phase(
            "TRACKED_FILL_REVIEW_PENDING",
            "CTP_TRACKED_ORDER_UPDATE_REQUIRES_REVIEW",
        )

    def _reconcile_pending_cancel_recovery(self) -> None:
        """Read and apply one bounded terminal callback for the pending cancel."""

        self._assert_owner_thread()
        from bt_api_execution import (
            CancelIntent,
            CancelObservation,
            CancelRecord,
            ExecutionState,
            ManagedCancellationFacade,
        )

        intent = self._cancel_recovery_pending_intent
        store = self._store
        lease = self._writer_lease
        scope = self.config.execution_scope
        port = self._cancel_port
        gate = self._cancel_gate
        if (
            type(intent) is not CancelIntent
            or intent.cancel_id != self._cancel_recovery_pending_intent_id
            or intent.scope != scope
            or store is None
            or lease is None
            or port is None
            or gate is None
        ):
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase(
                "CANCEL_RECOVERY_RESTORE_FAILED", "CANCEL_RECOVERY_CONTEXT_MISMATCH"
            )
            return

        try:
            stored_intent = store.get_cancel_intent(intent.cancel_id, scope=scope)
            record = store.get_cancel(intent.cancel_id, scope=scope)
        except Exception:
            self._set_phase(
                "CANCEL_RECOVERY_PENDING", "CANCEL_RECOVERY_READBACK_UNAVAILABLE"
            )
            return
        normal_pending_record = (
            type(record) is CancelRecord
            and record.state
            in {ExecutionState.DISPATCHING, ExecutionState.ACKED}
            and record.unknown_reason is None
            and record.review_required is False
        )
        unresolved_dispatch_record = (
            type(record) is CancelRecord
            and record.state is ExecutionState.UNKNOWN
            and record.unknown_reason == "cancel_outcome_unknown"
            and record.review_required is True
        )
        if (
            type(stored_intent) is not CancelIntent
            or stored_intent != intent
            or type(record) is not CancelRecord
            or record.cancel_id != intent.cancel_id
            or record.scope_key != scope.key
            or record.target_intent_id != intent.target_intent_id
            or record.provider_order_id != intent.provider_order_id
            or record.payload_sha256 != intent.fingerprint
            or record.dispatch_attempts != 1
            or not (normal_pending_record or unresolved_dispatch_record)
        ):
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase(
                "CANCEL_RECOVERY_RESTORE_FAILED", "CANCEL_RECOVERY_RECORD_MISMATCH"
            )
            return

        try:
            # This exact port method pumps/reconciles existing callback and
            # Store state only; it cannot issue another native cancel.
            observation = port.reconcile_cancel(intent)
        except Exception:
            self._set_phase(
                "CANCEL_RECOVERY_PENDING", "CANCEL_RECOVERY_READBACK_UNAVAILABLE"
            )
            return
        if (
            type(observation) is not CancelObservation
            or observation.cancel_id != intent.cancel_id
            or observation.target_intent_id != intent.target_intent_id
            or observation.provider_order_id != intent.provider_order_id
            or observation.state
            not in {ExecutionState.CANCELLED, ExecutionState.REJECTED}
        ):
            self._set_phase("CANCEL_RECOVERY_PENDING", "CANCEL_OUTCOME_UNRESOLVED")
            return

        try:
            facade = ManagedCancellationFacade(
                store,
                scope,
                acquire_writer_lease=lambda: lease,
                admission_gate=gate,
                allow_unprotected=False,
            )
            reconciled = facade.reconcile(observation)
        except Exception:
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase(
                "CANCEL_RECOVERY_RESTORE_FAILED",
                "CANCEL_RISK_RECONCILIATION_FAILED",
            )
            return
        if (
            type(reconciled) is not CancelRecord
            or reconciled.cancel_id != intent.cancel_id
            or reconciled.scope_key != scope.key
            or reconciled.target_intent_id != intent.target_intent_id
            or reconciled.provider_order_id != intent.provider_order_id
            or reconciled.state is not observation.state
            or reconciled.dispatch_attempts != 1
            or reconciled.review_required is not False
            or self._cancel_recovery_pending_intent_id is not None
            or self._cancel_recovery_pending_intent is not None
            or self._cancel_recovery_restore_failed
        ):
            self._ready = False
            self._cancel_recovery_restore_failed = True
            self._set_phase(
                "CANCEL_RECOVERY_RESTORE_FAILED",
                "CANCEL_RISK_RECONCILIATION_FAILED",
            )

    def _make_resources(self, *, complete: bool) -> Any:
        from bt_api_py.service_components import ComponentResources

        values: dict[str, object] = {}
        if complete:
            if any(
                value is None
                for value in (
                    self._store,
                    self._submit_port,
                    self._basic_gate,
                    self._order_gate,
                    self._cancel_gate,
                    self._cancel_port,
                )
            ):
                raise CtpExecutionRuntimeError("RUNTIME_RESOURCES_INCOMPLETE")
            admission: dict[str, object] = {
                "order_gate": self._order_gate,
                "cancel_gate": self._cancel_gate,
                "basic_admission_gate": self._basic_gate,
                "position_baseline_authorizer": (
                    self._submit_port.authorize_position_baseline_submit
                ),
            }
            operation_readiness: dict[str, Callable[[], bool]] = {
                "owner.cancel": self.cancel_remainder_ready,
            }
            if self._recovery_close_available:
                admission["recovery_close_authorizer"] = (
                    self._submit_port.authorize_recovery_close_dispatch
                )
                operation_readiness["orders.submit_recovery_close"] = (
                    self.recovery_route_available
                )
            if self._cancel_quota_admission is not None:
                admission["cancel_quota_admission"] = self._cancel_quota_admission
            values = {
                "store": self._store,
                "borrowed_writer_lease": self._writer_lease,
                "targets": MappingProxyType(
                    {self.config.service_scope: self.config.execution_scope}
                ),
                "dispatch": self._submit_port,
                "admission": MappingProxyType(admission),
                "cancel_dispatch": self._cancel_port,
                "cancel_before_dispatch": self._prepare_cancel_recovery_binding,
            }
        return ComponentResources.owned(
            values,
            ready=self.is_ready,
            maintain=self.maintain,
            next_maintenance_delay=self.next_maintenance_delay,
            close=self.close,
            internal_ports={},
            operation_readiness=(
                operation_readiness if complete else {}
            ),
        )

    def _bind_recovery_close_source_authority(self, scope: Any) -> Any | None:
        store = self._store
        owner = self._callback_owner
        lease = self._writer_lease
        bind = getattr(store, "bind_ctp_recovery_close_source_authority", None)
        if (
            store is None
            or owner is None
            or lease is None
            or not callable(bind)
        ):
            return None
        try:
            authority = bind(
                scope,
                owner_handle=owner,
                writer_lease=lease,
            )
        except Exception:
            return None
        if not callable(getattr(authority, "recovery_close_source_guard", None)):
            return None
        return authority

    def close(self) -> None:
        """Pump available callbacks, confirm native stop, then close the Store."""

        self._assert_owner_thread()
        if self._closed:
            return
        with self._owner_thread_calls_lock:
            self._owner_thread_calls_accepting = False
        self._reject_pending_owner_thread_calls("OWNER_THREAD_CALL_CLOSED")
        self._detach_selected_request_feed()
        self._ready = False
        self._set_phase("CLOSING")
        callback_drain_failed = False
        if (
            self._store is not None
            and self._callback_owner is not None
            and self._execution_owner is not None
            and not self._native_stop_attempted
        ):
            drained = 0
            try:
                while drained < self.config.drain_limit:
                    remaining = self.config.drain_limit - drained
                    results = self._execution_owner.pump_callbacks(
                        min(self.config.callback_pump_events, remaining)
                    )
                    if not results:
                        break
                    drained += len(results)
            except Exception:
                callback_drain_failed = True
        if self._native_start_attempted and not self._native_stop_complete:
            if self._trader is None:
                self._set_phase("CLOSE_FAILED", "TRADER_REFERENCE_MISSING")
                raise CtpExecutionRuntimeError("TRADER_REFERENCE_MISSING")
            self._native_stop_attempted = True
            try:
                receipt = self._trader.stop_and_wait(self.config.stop_timeout_s)
            except Exception:
                self._set_phase("CLOSE_FAILED", "NATIVE_STOP_UNCERTAIN")
                raise CtpExecutionRuntimeError("NATIVE_STOP_UNCERTAIN") from None
            self._last_stop_receipt = receipt
            from bt_api_ctp.ctp.client import CtpNativeStopReceipt

            if (
                type(receipt) is not CtpNativeStopReceipt
                or type(receipt.connection_generation) is not int
                or receipt.connection_generation < 0
                or type(receipt.join_required) is not bool
                or type(receipt.join_completed) is not bool
                or type(receipt.native_released) is not bool
                or (receipt.thread_alive is not None and type(receipt.thread_alive) is not bool)
                or type(receipt.timed_out) is not bool
                or receipt.complete is not True
            ):
                self._set_phase("CLOSE_FAILED", "NATIVE_STOP_UNCERTAIN")
                raise CtpExecutionRuntimeError("NATIVE_STOP_UNCERTAIN")
            self._native_stop_complete = True

        if self._store is not None and not self._store_closed:
            if self._callback_owner is not None:
                if callback_drain_failed:
                    self._set_phase("CLOSE_FAILED", "CALLBACK_DRAIN_FAILED")
                    raise CtpExecutionRuntimeError("CALLBACK_DRAIN_FAILED")
                if not self._callback_ingress_is_drained():
                    self._set_phase("CLOSE_FAILED", "CALLBACK_DRAIN_INCOMPLETE")
                    raise CtpExecutionRuntimeError("CALLBACK_DRAIN_INCOMPLETE")
            if self._owned_risk_bridge is not None and not self._risk_bridge_closed:
                try:
                    self._owned_risk_bridge.close()
                except Exception:
                    self._set_phase("CLOSE_FAILED", "RISK_BRIDGE_CLOSE_UNCERTAIN")
                    raise CtpExecutionRuntimeError("RISK_BRIDGE_CLOSE_UNCERTAIN") from None
                self._risk_bridge_closed = True
            try:
                self._store.close()
            except Exception:
                self._set_phase("CLOSE_FAILED", "STORE_CLOSE_UNCERTAIN")
                raise CtpExecutionRuntimeError("STORE_CLOSE_UNCERTAIN") from None
            self._store_closed = True
        self._closed = True
        self._set_phase("CLOSED")


class CtpExecutionResourceProvider:
    """Build a single ``execution/account_owner`` resource set on Host start."""

    def __init__(self, config: CtpExecutionRuntimeConfig) -> None:
        if type(config) is not CtpExecutionRuntimeConfig:
            raise TypeError("exact CTP execution runtime config is required")
        self.config = config
        self.last_runtime: CtpExecutionRuntime | None = None
        self._used = False
        self._lock = threading.Lock()

    def __call__(
        self,
        component: str,
        instance_id: str,
        options: Mapping[str, object],
        scope: Any,
    ) -> Any:
        from bt_api_py.service_components import ServiceResourceConstructionError

        if (
            component != "execution"
            or not isinstance(options, Mapping)
            or options.get("role") != "account_owner"
            or type(instance_id) is not str
            or not instance_id
            or scope != self.config.service_scope
        ):
            raise CtpExecutionRuntimeError("RUNTIME_COMPONENT_BINDING_INVALID")
        if options is not DIRECT_MANAGED_OWNER_OPTIONS:
            # A ServiceHost order-entry build (iteration 60): the host must
            # derive typed command bindings from exactly this runtime's
            # checked declaration; a binding-less (generic) host is refused
            # before any Store, lease or native resource exists.
            declaration = self.config.command_binding_declaration
            if declaration is None:
                raise CtpExecutionRuntimeError("COMMAND_BINDING_REQUIRED")
            declared = options.get("command_bindings")
            if declared is None:
                raise CtpExecutionRuntimeError("COMMAND_BINDING_HOST_UNDECLARED")
            if (
                not isinstance(declared, (list, tuple))
                or len(declared) != 1
                or not isinstance(declared[0], Mapping)
                or dict(declared[0]) != declaration
            ):
                raise CtpExecutionRuntimeError("COMMAND_BINDING_CONFIG_MISMATCH")
        with self._lock:
            if self._used:
                raise CtpExecutionRuntimeError("RUNTIME_PROVIDER_ONE_SHOT")
            self._used = True
        runtime = CtpExecutionRuntime(self.config, instance_id)
        self.last_runtime = runtime
        try:
            return runtime.bootstrap()
        except ServiceResourceConstructionError:
            raise
        except CtpExecutionRuntimeError:
            raise
        except Exception:
            if runtime._has_owned_state():
                resources = runtime._make_resources(complete=False)
                runtime._resources = resources
                raise ServiceResourceConstructionError(resources) from None
            raise CtpExecutionRuntimeError("RUNTIME_BOOTSTRAP_FAILED") from None

