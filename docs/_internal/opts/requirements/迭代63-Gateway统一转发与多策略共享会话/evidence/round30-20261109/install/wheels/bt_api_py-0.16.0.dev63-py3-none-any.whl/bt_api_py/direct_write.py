"""Direct (no execution session) write workflow owned by the SDK (iteration 62).

Order of every account-mutating call (D62-03/14, §5.3a item 4):

1. write admission must be enabled for the route (otherwise nothing happens);
2. the provider reserves the native identity (CTP: 12-digit OrderRef bound to
   FrontID/SessionID/TradingDay) without sending;
3. the host-injected :class:`PreDispatchCommitPort` durably records the
   reservation; no durable marker, no send;
4. the session generation is re-checked and a one-shot grant is issued;
5. the provider consumes the grant and sends exactly once.

The SDK never writes host files.  Returns are correlated to host markers by the
original venue identity and de-duplicated; unmatched returns are reported as
unmatched, never as verified facts.

De-duplication scope (iteration 62 review, §4 item 5): a provider whose venue
execution ids (order refs, session ids, venue order ids, trade ids) are unique
only within one venue trading day declares the class or instance attribute
``execution_ids_trading_day_scoped = True`` (bt_api_ctp: CTP reuses
``OrderSysID``/``TradeID`` every trading day).  On such a route the
de-duplication key of a return also holds its trading day, so an equal return
of another trading day is delivered, not dropped as a replay.  A return of such
a route without one readable trading day is never de-duplicated by the SDK (it
is delivered every time it is drained; the host keeps its own fill keys).
Without the declaration (``False`` or absent: OKX, Binance) the key is
unchanged and a return replayed on a later day (e.g. a GTC order's) is still
dropped.  Any other declared value fails closed when the provider is created.

The same declaration scopes correlation (INV63-14): on such a route the strong
session key (FrontID, SessionID, OrderRef) and venue key (ExchangeID,
OrderSysID) also hold the trading day, read and validated like the
de-duplication day, when they are registered (orders placed, restored
identities, venue ids learned from returns) and when a return is looked up.
A return of another trading day that reuses those ids is not attributed to an
earlier day's order; a return without one readable trading day is never
attributed on such a route.  An order or restored identity without a readable
trading day is refused there (``direct_identity_trading_day_unreadable``)
rather than registered under a key that no return could reach.
"""

from __future__ import annotations

import json
import threading
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Mapping, Optional

from bt_api_base.direct_cancel_protocol import PreparedCancelRequest
from bt_api_base.gateway_direct_protocol import canonical_gateway_payload, validate_gateway_native_identity
from bt_api_base.direct_write_protocol import (
    DirectExecutionEvent,
    DirectExecutionEventKind,
    DirectSubmitResult,
    DirectWriteError,
    DirectWriteErrorPolicy,
    NativeOrderIdentity,
    PreDispatchCommitPort,
    PreDispatchRecord,
    SettlementObservation,
    SettlementStatus,
    SettlementWriteBinding,
    WriteAdmissionDenied,
    WriteGrant,
    WriteOperation,
)

from .write_admission import WriteAdmission

__all__ = (
    "CorrelatedDirectEvent",
    "DIRECT_WRITE_PROVIDER_GROUP",
    "DirectWriteCoordinator",
    "DirectWriteOutcome",
    "project_direct_strong_identity_keys",
)

DIRECT_WRITE_PROVIDER_GROUP = "bt_api.direct_write_providers"
_DEDUP_CAPACITY = 100_000
# Optional provider declaration read once when the provider is created; only
# ``True`` scopes de-duplication by trading day (see the module docstring).
_DAY_SCOPED_IDS_ATTRIBUTE = "execution_ids_trading_day_scoped"

# An identity on a trading-day scoped route without one readable trading day.
_TRADING_DAY_UNREADABLE = "direct_identity_trading_day_unreadable"


def _utc_now_text() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _declares_day_scoped_ids(provider: Any, exchange_name: str) -> bool:
    """The provider's ``execution_ids_trading_day_scoped`` declaration.

    Absent means ``False``.  A value other than the bools ``True``/``False``
    (or an unreadable attribute) is refused: guessing either way could drop a
    fill or change another route's replay semantics.
    """

    try:
        value = getattr(provider, _DAY_SCOPED_IDS_ATTRIBUTE, False)
    except Exception:
        value = None
    if value is True or value is False:
        return value
    raise DirectWriteError(
        "direct_write_provider_declaration_invalid",
        f"{exchange_name}: {_DAY_SCOPED_IDS_ATTRIBUTE} must be True or False",
    )


def _one_trading_day(*named: Any) -> Optional[str]:
    """The one ``YYYYMMDD`` trading day ``named`` agree on, else ``None``.

    ``None`` entries name nothing.  ``None`` when no day is named, when one is
    not an 8-digit ASCII text (checked before comparing, so an unhashable
    value is refused, not raised), or when two differ.
    """

    days: set[str] = set()
    for day in named:
        if day is None:
            continue
        if type(day) is not str or len(day) != 8 or not (day.isascii() and day.isdigit()):
            return None
        days.add(day)
    if len(days) != 1:
        return None
    (day,) = days
    return day


def _event_trading_day(event: DirectExecutionEvent) -> Optional[str]:
    """The one ``YYYYMMDD`` trading day a return names, else ``None``.

    Read from the identity fields and the event field; ``None`` when neither
    carries one, when one is not an 8-digit ASCII text, or when the two differ.
    """

    identity = event.identity
    if identity is None:
        return _one_trading_day(event.trading_day)
    return _one_trading_day(event.trading_day, identity.fields.get("trading_day"))


def _identity_trading_day(identity: NativeOrderIdentity) -> Optional[str]:
    """The ``YYYYMMDD`` trading day of a registered identity, else ``None``."""

    return _one_trading_day(identity.fields.get("trading_day"))


@dataclass(frozen=True)
class DirectWriteOutcome:
    """Result of one coordinated write.

    ``sent`` is ``True`` when the native call returned success, ``False`` when
    the request was definitely not sent, and ``None`` when the outcome is
    unknown (the host must keep its marker UNKNOWN and recover by identity).
    """

    sent: Optional[bool]
    identity: Optional[NativeOrderIdentity]
    marker_id: Optional[str]
    error_code: Optional[str] = None
    detail: Optional[str] = None


@dataclass(frozen=True)
class CorrelatedDirectEvent:
    """A provider return plus the SDK correlation verdict.

    ``evidence`` is ``direct_identity_match`` (``matched``), or for an
    unattributed return ``weak_key_candidate`` (it shares only a weak trading
    day and client order id key with an own order, e.g. another CTP session's
    equal ``OrderRef``) or ``unmatched``.
    """

    event: DirectExecutionEvent
    matched: bool
    evidence: str
    marker_id: Optional[str]
    host_scope: Optional[str]


class _Correlator:
    """Maps venue identities to host markers and de-duplicates returns.

    Strong keys attribute a return: the session triple (``FrontID``,
    ``SessionID``, ``OrderRef``), the venue order id (``ExchangeID``,
    ``OrderSysID``) and the (trading day, client order id) key of an identity
    without session fields (OKX/Binance: client order ids are unique per
    account).  The (trading day, client order id) key of a session-scoped
    identity is weak: CTP ``OrderRef`` is unique only within one
    ``FrontID``/``SessionID``, so another session or terminal of the same
    account may use the same value on the same day.  A weak key never
    attributes a return; a hit is only reported as a candidate (INV63-14).

    ``day_scoped_ids`` is the route provider's declaration: its returns are
    de-duplicated per trading day (:meth:`seen_key`), and its strong session
    and venue keys also hold the trading day, because CTP restarts OrderRef
    and OrderSysID (and may repeat SessionID) every trading day (INV63-14:
    (trading day, FrontID, SessionID, OrderRef) and (trading day, ExchangeID,
    OrderSysID)).  Such a route attributes nothing without a readable day.
    Elsewhere the ``day`` arguments are ignored and the keys are unchanged.
    """

    def __init__(self, *, day_scoped_ids: bool = False) -> None:
        self._lock = threading.Lock()
        self._day_scoped_ids = day_scoped_ids
        self._by_key: dict[tuple[Any, ...], tuple[Optional[str], Optional[str]]] = {}
        self._weak_keys: dict[tuple[Any, ...], tuple[Optional[str], Optional[str]]] = {}
        self._seen: OrderedDict[tuple[Any, ...], None] = OrderedDict()

    @property
    def day_scoped_ids(self) -> bool:
        return self._day_scoped_ids

    def _keys(
        self, identity: NativeOrderIdentity, day: Optional[str]
    ) -> list[tuple[tuple[Any, ...], bool]]:
        """``(key, strong)`` pairs of ``identity``.

        On a trading-day scoped route the session and venue keys hold ``day``;
        :meth:`register` and :meth:`lookup` refuse such a route without a
        validated day, so no day-less strong key is ever stored or probed
        (:meth:`weak_candidate` reads only the weak keys, which never hold
        it).  The (trading day, client order id) key is the same on every
        route.
        """
        fields = identity.fields
        exchange = identity.exchange_name
        keys: list[tuple[tuple[Any, ...], bool]] = []
        ref = fields.get("order_ref") or identity.client_order_id
        # Session-scoped as soon as the identity names either session field,
        # even an unreadable one: its client id is then not account-unique.
        session_scoped = "front_id" in fields or "session_id" in fields
        dated: tuple[Optional[str], ...] = (day,) if self._day_scoped_ids else ()
        front_id, session_id = fields.get("front_id"), fields.get("session_id")
        if ref and front_id is not None and session_id is not None:
            keys.append((("session", exchange, *dated, front_id, session_id, ref), True))
        if ref and fields.get("trading_day"):
            keys.append((("day", exchange, fields.get("trading_day"), ref), not session_scoped))
        exchange_id, order_sys_id = fields.get("exchange_id"), fields.get("order_sys_id")
        if order_sys_id and exchange_id:
            keys.append((("venue", exchange, *dated, exchange_id, order_sys_id), True))
        return keys

    def register(
        self,
        identity: NativeOrderIdentity,
        marker_id: Optional[str],
        host_scope: Optional[str],
        day: Optional[str],
    ) -> None:
        """Register ``identity`` of trading day ``day`` (validated by the caller).

        On a trading-day scoped route an identity without a day is refused
        (``direct_identity_trading_day_unreadable``); nothing is registered.
        """
        if self._day_scoped_ids and day is None:
            raise DirectWriteError(_TRADING_DAY_UNREADABLE, identity.exchange_name)
        with self._lock:
            for key, strong in self._keys(identity, day):
                if strong:
                    self._by_key[key] = (marker_id, host_scope)
                else:
                    self._weak_keys[key] = (marker_id, host_scope)

    def lookup(
        self, identity: Optional[NativeOrderIdentity], day: Optional[str]
    ) -> Optional[tuple[Optional[str], Optional[str]]]:
        """The host marker of ``identity`` through a strong key only.

        ``day`` is the return's validated trading day; on a trading-day scoped
        route a return without one is never attributed.
        """
        if identity is None:
            return None
        if self._day_scoped_ids and day is None:
            return None
        with self._lock:
            for key, _strong in self._keys(identity, day):
                found = self._by_key.get(key)
                if found is not None:
                    return found
        return None

    def weak_candidate(self, identity: Optional[NativeOrderIdentity]) -> bool:
        """``True`` when ``identity`` hits only a weak key (never an attribution).

        Only (trading day, client order id) keys are ever weak, and they do not
        depend on the route's trading-day scope.
        """
        if identity is None:
            return False
        with self._lock:
            return any(key in self._weak_keys for key, _strong in self._keys(identity, None))

    def seen_key(self, event: DirectExecutionEvent) -> Optional[tuple[Any, ...]]:
        """The de-duplication key of ``event``; ``None`` when it is never de-duplicated.

        On a route declaring trading-day scoped ids the key holds the return's
        trading day; a return without one readable day gets ``None`` so it is
        never dropped as a replay of another day's return.
        """

        key = event.dedup_key()
        if not self._day_scoped_ids:
            return key
        day = _event_trading_day(event)
        if day is None:
            return None
        return ("trading_day", day, key)

    def first_seen(self, key: tuple[Any, ...]) -> bool:
        with self._lock:
            if key in self._seen:
                return False
            self._seen[key] = None
            if len(self._seen) > _DEDUP_CAPACITY:
                self._seen.popitem(last=False)
            return True


def project_direct_strong_identity_keys(
    identity: NativeOrderIdentity, *, day_scoped_ids: bool
) -> tuple[str, ...]:
    """Project strong keys without a provider, registration or network access.

    ``day_scoped_ids`` must be an explicit bool; the caller chooses the
    candidate scope and this function does not establish which scope is true.
    Keys are sorted, unique ASCII JSON arrays of at most 256 characters. Only
    exact strings and integers are safe key components: booleans and floats
    compare equal to integers in the correlator but encode differently in JSON.
    This projection proves neither provider provenance nor account authority.
    """
    if not isinstance(identity, NativeOrderIdentity) or type(day_scoped_ids) is not bool:
        raise DirectWriteError("direct_identity_strong_key_invalid")
    try:
        def check_component(part: Any) -> None:
            if type(part) is str:
                if len(part) > 256:
                    raise ValueError("key component too long")
                part.encode("utf-8", errors="strict")
            elif type(part) is int:
                if part.bit_length() > 850:
                    raise ValueError("key component too long")
            else:
                raise ValueError("invalid key component")

        # Validate even incomplete candidate identities. None is absent; a
        # malformed partial component is not evidence of a merely weak key.
        if (
            type(identity.exchange_name) is not str
            or not identity.exchange_name
            or identity.exchange_name != identity.exchange_name.strip()
        ):
            raise ValueError("invalid exchange name")
        check_component(identity.exchange_name)
        if identity.client_order_id is not None:
            if (
                type(identity.client_order_id) is not str
                or not identity.client_order_id
                or identity.client_order_id != identity.client_order_id.strip()
            ):
                raise ValueError("invalid client order id")
            check_component(identity.client_order_id)
        for name in (
            "trading_day", "order_ref", "front_id", "session_id", "exchange_id", "order_sys_id"
        ):
            value = identity.fields.get(name)
            if value is not None:
                check_component(value)
        day = _identity_trading_day(identity)
        if day_scoped_ids and day is None:
            raise DirectWriteError(_TRADING_DAY_UNREADABLE, identity.exchange_name)
        keys = _Correlator(day_scoped_ids=day_scoped_ids)._keys(identity, day)
        projected: set[str] = set()
        for key, strong in keys:
            if not strong:
                continue
            for part in key:
                check_component(part)
            encoded = json.dumps(key, ensure_ascii=True, separators=(",", ":"), allow_nan=False)
            if len(encoded) > 256:
                raise ValueError("key too long")
            projected.add(encoded)
        if not projected:
            raise DirectWriteError("direct_identity_strong_key_unavailable")
        return tuple(sorted(projected))
    except DirectWriteError:
        raise
    except Exception:
        raise DirectWriteError("direct_identity_strong_key_invalid") from None


class DirectWriteCoordinator:
    """SDK coordinator for direct writes and their returns on all routes."""

    def __init__(
        self,
        admission: WriteAdmission,
        provider_factory: Callable[[str], Any],
    ) -> None:
        self._admission = admission
        self._provider_factory = provider_factory
        self._providers: dict[str, Any] = {}
        self._lock = threading.RLock()
        self._correlators: dict[str, _Correlator] = {}
        self._error_policies: dict[str, DirectWriteErrorPolicy] = {}

    @property
    def admission(self) -> WriteAdmission:
        return self._admission

    def provider(self, exchange_name: str) -> Any:
        # A provider, once created, is never replaced or removed, so a created
        # one is returned without the write lock: polling returns and events
        # must not wait behind a write that holds the lock (a settlement
        # confirmation can hold it for seconds on CTP).  Its correlator is
        # stored first, so a visible provider always has one.
        provider = self._providers.get(exchange_name)
        if provider is not None:
            return provider
        with self._lock:
            provider = self._providers.get(exchange_name)
            if provider is None:
                provider = self._provider_factory(exchange_name)
                if provider is None:
                    raise DirectWriteError("direct_write_provider_unavailable", exchange_name)
                # An invalid declaration raises here: the provider is never
                # registered, so nothing is placed or polled on that route.
                day_scoped_ids = _declares_day_scoped_ids(provider, exchange_name)
                self._correlators[exchange_name] = _Correlator(day_scoped_ids=day_scoped_ids)
                self._providers[exchange_name] = provider
            return provider

    def close(self) -> None:
        """Close every created provider that owns resources (e.g. a monitor thread).

        Providers stay registered (a closed provider refuses or degrades on its
        own); a close failure of one provider never skips the others.
        """
        for exchange_name, provider in tuple(self._providers.items()):
            close = getattr(provider, "close", None)
            if not callable(close):
                continue
            try:
                close()
            except Exception as exc:
                from bt_api_base.logging_factory import get_logger

                get_logger("api").warning(
                    f"direct write provider close failed for {exchange_name}: {type(exc).__name__}"
                )

    def _correlator(self, exchange_name: str) -> _Correlator:
        self.provider(exchange_name)
        return self._correlators[exchange_name]

    def strong_identity_keys(
        self, exchange_name: str, identity: NativeOrderIdentity
    ) -> tuple[str, ...]:
        """Project this route's strong correlation keys without registering them.

        Keys are sorted, unique ASCII JSON arrays of at most 256 characters.
        Only exact strings and integers are accepted: booleans and floats have
        ambiguous equality with integers in the correlator and cannot safely
        be serialized as distinct JSON values. This projection proves neither
        provider provenance nor account authority.
        """
        if not isinstance(identity, NativeOrderIdentity):
            raise DirectWriteError("direct_identity_strong_key_invalid")
        if identity.exchange_name != exchange_name:
            raise DirectWriteError("direct_identity_route_mismatch")
        correlator = self._correlator(exchange_name)
        return project_direct_strong_identity_keys(
            identity, day_scoped_ids=correlator.day_scoped_ids
        )

    def _error_policy(self, exchange_name: str, provider: Any) -> DirectWriteErrorPolicy:
        # Called under the write lock, so the declaration is loaded once per route.
        policy = self._error_policies.get(exchange_name)
        if policy is not None:
            return policy
        try:
            declaration = provider.direct_write_error_policy
            if type(declaration) is not DirectWriteErrorPolicy:
                raise ValueError("wrong policy type")
            # Validate again in case a frozen object was constructed or mutated
            # without its normal initializer; retain a validated immutable copy.
            policy = DirectWriteErrorPolicy(
                declaration.place_unknown_codes, declaration.cancel_unknown_codes
            )
        except Exception:
            raise DirectWriteError(
                "direct_write_provider_declaration_invalid", exchange_name
            ) from None
        self._error_policies[exchange_name] = policy
        return policy

    # ------------------------------------------------------------------
    @staticmethod
    def _commit(port: PreDispatchCommitPort, record: PreDispatchRecord) -> Optional[str]:
        if port is None or not callable(getattr(port, "commit", None)):
            return None
        try:
            marker = port.commit(record)
        except Exception:
            return None
        return marker if type(marker) is str and marker else None

    def place(
        self,
        exchange_name: str,
        request: Any,
        *,
        commit_port: PreDispatchCommitPort,
        host_scope: str,
        request_summary: Optional[Mapping[str, Any]] = None,
    ) -> DirectWriteOutcome:
        if not self._admission.is_enabled(exchange_name):
            raise WriteAdmissionDenied("write_admission_disabled", exchange_name)
        provider = self.provider(exchange_name)
        correlator = self._correlator(exchange_name)
        with self._lock:
            policy = self._error_policy(exchange_name, provider)
            reservation = provider.reserve_order(request)
            identity = reservation.identity
            day = _identity_trading_day(identity)
            if correlator.day_scoped_ids and day is None:
                # Its returns could never be attributed (INV63-14): refused
                # before any host marker exists, nothing is sent.
                provider.release_reservation(reservation)
                return DirectWriteOutcome(
                    sent=False,
                    identity=identity,
                    marker_id=None,
                    error_code=_TRADING_DAY_UNREADABLE,
                )
            record = PreDispatchRecord(
                operation=WriteOperation.PLACE,
                host_scope=host_scope,
                exchange_name=exchange_name,
                symbol=reservation.symbol,
                identity=identity,
                target_identity=None,
                request_summary=dict(request_summary or {}),
                trading_day=identity.fields.get("trading_day"),
                session_generation=identity.session_generation,
                created_at_utc=_utc_now_text(),
            )
            marker = self._commit(commit_port, record)
            if marker is None:
                provider.release_reservation(reservation)
                return DirectWriteOutcome(
                    sent=False,
                    identity=identity,
                    marker_id=None,
                    error_code="pre_dispatch_commit_failed",
                )
            generation = provider.session_generation()
            if generation != identity.session_generation:
                provider.release_reservation(reservation)
                return DirectWriteOutcome(
                    sent=False,
                    identity=identity,
                    marker_id=marker,
                    error_code="session_changed_before_dispatch",
                )
            try:
                grant = self._admission.issue(exchange_name, WriteOperation.PLACE, generation)
            except WriteAdmissionDenied as exc:
                provider.release_reservation(reservation)
                return DirectWriteOutcome(False, identity, marker, exc.code, exc.detail)
            correlator.register(identity, marker, host_scope, day)
            try:
                result = provider.submit_order(reservation, request, grant, self._admission)
            except WriteAdmissionDenied as exc:
                return DirectWriteOutcome(False, identity, marker, exc.code, exc.detail)
            except DirectWriteError as exc:
                if exc.code in policy.place_unknown_codes:
                    return DirectWriteOutcome(None, identity, marker, exc.code, exc.detail)
                return DirectWriteOutcome(False, identity, marker, exc.code, exc.detail)
            except Exception as exc:  # the native call may have happened
                return DirectWriteOutcome(
                    None, identity, marker, "direct_submit_outcome_unknown", type(exc).__name__
                )
            return DirectWriteOutcome(
                sent=result.sent,
                identity=result.identity or identity,
                marker_id=marker,
                error_code=result.error_code,
                detail=result.detail,
            )

    def place_prepared(
        self,
        exchange_name: str,
        request: Any,
        *,
        commit_port: PreDispatchCommitPort,
        host_scope: str,
        request_summary: Optional[Mapping[str, Any]] = None,
    ) -> DirectWriteOutcome:
        """Commit an exact provider-prepared order before its single native send."""
        from bt_api_base.direct_place_protocol import PreparedPlaceRequest

        if not self._admission.is_enabled(exchange_name):
            raise WriteAdmissionDenied("write_admission_disabled", exchange_name)
        provider = self.provider(exchange_name)
        correlator = self._correlator(exchange_name)
        with self._lock:
            prepare = getattr(provider, "prepare_order", None)
            submit = getattr(provider, "submit_prepared_order", None)
            release = getattr(provider, "release_prepared_order", None)
            if not all(callable(method) for method in (prepare, submit, release)):
                raise DirectWriteError("direct_prepared_place_unavailable")
            try:
                request_json = canonical_gateway_payload(request.to_dict())
                summary = dict(request_summary or {})
                summary_json = canonical_gateway_payload(summary)
                symbol = request.symbol
                if type(symbol) is not str or not symbol or symbol != symbol.strip():
                    raise ValueError
            except Exception:
                raise DirectWriteError("direct_place_request_invalid") from None
            try:
                prepared = prepare(request)
            except Exception as exc:
                return DirectWriteOutcome(False, None, None, "place_prepare_failed", type(exc).__name__)

            identity = prepared.identity if type(prepared) is PreparedPlaceRequest else None

            def release_unsent(code: str, marker: Optional[str] = None,
                               detail: Optional[str] = None) -> DirectWriteOutcome:
                try:
                    release(prepared)
                except Exception:
                    return DirectWriteOutcome(False, identity, marker, "place_reservation_release_failed")
                return DirectWriteOutcome(False, identity, marker, code, detail)

            def valid_prepared(expected_digest: Optional[str] = None) -> bool:
                try:
                    if type(prepared) is not PreparedPlaceRequest:
                        return False
                    raw = prepared.to_mapping()
                    checked = PreparedPlaceRequest.from_mapping(raw)
                    digest = prepared.digest()
                    return bool(
                        checked.digest() == digest
                        and (expected_digest is None or digest == expected_digest)
                        and prepared.symbol == symbol
                        and request.symbol == symbol
                        and prepared.identity.exchange_name == exchange_name
                        and canonical_gateway_payload(request.to_dict()) == request_json
                        and canonical_gateway_payload(summary) == summary_json
                        and self._providers.get(exchange_name) is provider
                    )
                except Exception:
                    return False

            def source_current(generation: int) -> bool:
                current = provider.session_generation()
                return (type(current) is int and current == generation
                        and provider.trading_day() == prepared.trading_day)

            if not valid_prepared():
                return release_unsent("place_preparation_invalid")
            digest = prepared.digest()
            day = _identity_trading_day(identity)
            if correlator.day_scoped_ids and day is None:
                return release_unsent(_TRADING_DAY_UNREADABLE)
            try:
                generation = provider.session_generation()
                if (type(generation) is not int or generation != prepared.session_generation
                        or not source_current(generation) or not valid_prepared(digest)):
                    return release_unsent("session_changed_before_dispatch")
                record = PreDispatchRecord(
                    operation=WriteOperation.PLACE, host_scope=host_scope,
                    exchange_name=exchange_name, symbol=symbol, identity=identity,
                    target_identity=None, request_summary=summary, trading_day=prepared.trading_day,
                    session_generation=generation, created_at_utc=_utc_now_text(),
                    prepared_place=prepared,
                )
                record_json = canonical_gateway_payload(record.to_dict())
            except Exception:
                return release_unsent("place_preparation_invalid")
            marker = self._commit(commit_port, record)
            if marker is None:
                return release_unsent("pre_dispatch_commit_failed")
            grant = None
            try:
                if (not valid_prepared(digest)
                        or canonical_gateway_payload(record.to_dict()) != record_json
                        or not source_current(generation)):
                    return release_unsent("session_changed_before_dispatch", marker)
                try:
                    grant = self._admission.issue(exchange_name, WriteOperation.PLACE, generation)
                except WriteAdmissionDenied as exc:
                    return release_unsent(exc.code, marker, exc.detail)
                if (type(grant) is not WriteGrant or grant.exchange_name != exchange_name
                        or grant.operation is not WriteOperation.PLACE
                        or grant.settlement_binding is not None
                        or type(grant.session_generation) is not int
                        or grant.session_generation != generation or not valid_prepared(digest)
                        or canonical_gateway_payload(record.to_dict()) != record_json
                        or not source_current(generation)
                        or not self._admission.is_enabled(exchange_name)):
                    return release_unsent("session_changed_before_dispatch", marker)
                correlator.register(identity, marker, host_scope, day)
                if (not valid_prepared(digest)
                        or canonical_gateway_payload(record.to_dict()) != record_json
                        or not source_current(generation)
                        or not self._admission.is_enabled(exchange_name)):
                    return release_unsent("session_changed_before_dispatch", marker)
                try:
                    result = submit(prepared, grant, self._admission)
                except Exception as exc:
                    return DirectWriteOutcome(None, identity, marker, "direct_submit_outcome_unknown", type(exc).__name__)
                try:
                    if (type(result) is not DirectSubmitResult
                            or result.sent is not None and type(result.sent) is not bool
                            or type(result.identity) is not NativeOrderIdentity
                            or canonical_gateway_payload(result.identity.to_dict()) != canonical_gateway_payload(identity.to_dict())
                            or result.error_code is not None and type(result.error_code) is not str
                            or result.detail is not None and type(result.detail) is not str
                            or not valid_prepared(digest)):
                        raise ValueError
                except Exception:
                    return DirectWriteOutcome(None, identity, marker, "direct_submit_outcome_unknown")
                return DirectWriteOutcome(result.sent, identity, marker, result.error_code, result.detail)
            except Exception:
                return release_unsent("session_changed_before_dispatch", marker)
            finally:
                if type(grant) is WriteGrant:
                    self._admission.revoke_grant(grant)

    def cancel(
        self,
        exchange_name: str,
        target: NativeOrderIdentity,
        symbol: str,
        *,
        commit_port: PreDispatchCommitPort,
        host_scope: str,
    ) -> DirectWriteOutcome:
        if not self._admission.is_enabled(exchange_name):
            raise WriteAdmissionDenied("write_admission_disabled", exchange_name)
        provider = self.provider(exchange_name)
        with self._lock:
            policy = self._error_policy(exchange_name, provider)
            generation = provider.session_generation()
            record = PreDispatchRecord(
                operation=WriteOperation.CANCEL,
                host_scope=host_scope,
                exchange_name=exchange_name,
                symbol=symbol,
                identity=None,
                target_identity=target,
                request_summary={},
                trading_day=target.fields.get("trading_day"),
                session_generation=generation,
                created_at_utc=_utc_now_text(),
            )
            marker = self._commit(commit_port, record)
            if marker is None:
                return DirectWriteOutcome(False, target, None, "pre_dispatch_commit_failed")
            try:
                grant = self._admission.issue(exchange_name, WriteOperation.CANCEL, generation)
                result = provider.cancel_order(target, symbol, grant, self._admission)
            except WriteAdmissionDenied as exc:
                return DirectWriteOutcome(False, target, marker, exc.code, exc.detail)
            except DirectWriteError as exc:
                sent = None if exc.code in policy.cancel_unknown_codes else False
                return DirectWriteOutcome(sent, target, marker, exc.code, exc.detail)
            except Exception as exc:
                return DirectWriteOutcome(
                    None, target, marker, "direct_cancel_outcome_unknown", type(exc).__name__
                )
            return DirectWriteOutcome(result.sent, target, marker, result.error_code, result.detail)

    def cancel_prepared(
        self,
        exchange_name: str,
        target: NativeOrderIdentity,
        symbol: str,
        *,
        commit_port: PreDispatchCommitPort,
        host_scope: str,
    ) -> DirectWriteOutcome:
        """Persist an exact prepared cancel before authorizing its one send."""
        if not self._admission.is_enabled(exchange_name):
            raise WriteAdmissionDenied("write_admission_disabled", exchange_name)
        try:
            if type(target) is not NativeOrderIdentity or target.exchange_name != exchange_name:
                raise ValueError
            validate_gateway_native_identity(target)
            target_json = canonical_gateway_payload(target.to_dict())
            if type(symbol) is not str or not symbol or symbol != symbol.strip():
                raise ValueError
        except Exception:
            raise DirectWriteError("direct_cancel_target_invalid") from None
        provider = self.provider(exchange_name)
        with self._lock:
            prepare = getattr(provider, "prepare_cancel_order", None)
            submit = getattr(provider, "submit_prepared_cancel", None)
            release = getattr(provider, "release_cancel_reservation", None)
            if not all(callable(method) for method in (prepare, submit, release)):
                raise DirectWriteError("direct_prepared_cancel_unavailable")
            try:
                prepared = prepare(target, symbol)
            except Exception as exc:
                return DirectWriteOutcome(False, target, None, "cancel_prepare_failed", type(exc).__name__)

            def release_unsent(code: str, marker: Optional[str] = None,
                               detail: Optional[str] = None) -> DirectWriteOutcome:
                try:
                    release(prepared)
                except Exception:
                    return DirectWriteOutcome(False, target, marker, "cancel_reservation_release_failed")
                return DirectWriteOutcome(False, target, marker, code, detail)

            def valid_prepared(expected_digest: Optional[str] = None) -> bool:
                try:
                    if type(prepared) is not PreparedCancelRequest:
                        return False
                    raw = prepared.to_mapping()
                    checked = PreparedCancelRequest.from_mapping(raw)
                    digest = prepared.digest()
                    return bool(
                        checked.digest() == digest
                        and (expected_digest is None or digest == expected_digest)
                        and prepared.symbol == symbol
                        and prepared.target_identity.exchange_name == exchange_name
                        and canonical_gateway_payload(prepared.target_identity.to_dict()) == target_json
                        and canonical_gateway_payload(target.to_dict()) == target_json
                        and self._providers.get(exchange_name) is provider
                    )
                except Exception:
                    return False

            def source_current(generation: int) -> bool:
                current = provider.session_generation()
                day = provider.trading_day()
                return type(current) is int and current == generation and day == prepared.trading_day

            if not valid_prepared():
                return release_unsent("cancel_preparation_invalid")
            digest = prepared.digest()
            try:
                generation = provider.session_generation()
                if (type(generation) is not int or generation != prepared.session_generation
                        or provider.trading_day() != prepared.trading_day
                        or not valid_prepared(digest)):
                    return release_unsent("session_changed_before_dispatch")
                record = PreDispatchRecord(
                    operation=WriteOperation.CANCEL, host_scope=host_scope,
                    exchange_name=exchange_name, symbol=symbol, identity=None,
                    target_identity=target, request_summary={}, trading_day=prepared.trading_day,
                    session_generation=generation, created_at_utc=_utc_now_text(),
                    prepared_cancel=prepared,
                )
                record_json = canonical_gateway_payload(record.to_dict())
            except Exception:
                return release_unsent("cancel_preparation_invalid")
            marker = self._commit(commit_port, record)
            if marker is None:
                return release_unsent("pre_dispatch_commit_failed")
            grant = None
            try:
                if (not valid_prepared(digest)
                        or canonical_gateway_payload(record.to_dict()) != record_json
                        or not source_current(generation)):
                    return release_unsent("session_changed_before_dispatch", marker)
                try:
                    grant = self._admission.issue(exchange_name, WriteOperation.CANCEL, generation)
                except WriteAdmissionDenied as exc:
                    return release_unsent(exc.code, marker, exc.detail)
                if (type(grant) is not WriteGrant or grant.exchange_name != exchange_name
                        or grant.operation is not WriteOperation.CANCEL
                        or grant.settlement_binding is not None
                        or type(grant.session_generation) is not int
                        or grant.session_generation != generation or not valid_prepared(digest)
                        or canonical_gateway_payload(record.to_dict()) != record_json
                        or not source_current(generation)
                        or not self._admission.is_enabled(exchange_name)
                        or not valid_prepared(digest)
                        or canonical_gateway_payload(record.to_dict()) != record_json):
                    return release_unsent("session_changed_before_dispatch", marker)
                try:
                    result = submit(prepared, grant, self._admission)
                except Exception as exc:
                    return DirectWriteOutcome(None, target, marker, "direct_cancel_outcome_unknown", type(exc).__name__)
                try:
                    if (type(result) is not DirectSubmitResult
                            or result.sent is not None and type(result.sent) is not bool
                            or type(result.identity) is not NativeOrderIdentity
                            or canonical_gateway_payload(result.identity.to_dict()) != target_json
                            or result.error_code is not None and type(result.error_code) is not str
                            or result.detail is not None and type(result.detail) is not str
                            or not valid_prepared(digest)):
                        raise ValueError
                except Exception:
                    return DirectWriteOutcome(None, target, marker, "direct_cancel_outcome_unknown")
                return DirectWriteOutcome(result.sent, target, marker, result.error_code, result.detail)
            except Exception:
                return release_unsent("session_changed_before_dispatch", marker)
            finally:
                if type(grant) is WriteGrant:
                    self._admission.revoke_grant(grant)

    def _valid_settlement_observation(
        self, exchange_name: str, provider: Any, observation: Any
    ) -> bool:
        try:
            if type(observation) is not SettlementObservation:
                return False
            # Re-run the exact DTO contract even for a forged frozen object.
            checked = SettlementObservation(
                observation.exchange_name, observation.account_binding,
                observation.trading_day, observation.session_generation,
                observation.status, observation.observation_id,
            )
            if checked != observation or observation.exchange_name != exchange_name:
                return False
            if self._providers.get(exchange_name) is not provider:
                return False
            if (getattr(provider, "settlement_required", None) is not True
                    or self._providers.get(exchange_name) is not provider):
                return False
            validate = getattr(provider, "validate_settlement_observation", None)
            if not callable(validate) or validate(observation) is not True:
                return False
            return (
                getattr(provider, "settlement_required", None) is True
                and self._providers.get(exchange_name) is provider
            )
        except Exception:
            return False

    def observe_settlement(self, exchange_name: str) -> Optional[SettlementObservation]:
        """Read one current provider observation without granting write authority."""
        provider = self.provider(exchange_name)
        with self._lock:
            try:
                if getattr(provider, "settlement_required", None) is not True:
                    return None
                reader = getattr(provider, "observe_settlement", None)
                observation = reader() if callable(reader) else None
                return observation if self._valid_settlement_observation(
                    exchange_name, provider, observation
                ) else None
            except Exception:
                return None

    def ensure_settlement(
        self,
        exchange_name: str,
        *,
        commit_port: PreDispatchCommitPort,
        host_scope: str,
        observation: Optional[SettlementObservation] = None,
    ) -> SettlementStatus:
        """Confirm today's settlement when needed (D62-20; D62-29 exception)."""

        provider = self.provider(exchange_name)
        with self._lock:
            try:
                if self._providers.get(exchange_name) is not provider:
                    return SettlementStatus.UNKNOWN
                required = getattr(provider, "settlement_required", None)
                if type(required) is not bool:
                    return SettlementStatus.UNKNOWN
                if not required:
                    return (SettlementStatus.CONFIRMED
                            if self._providers.get(exchange_name) is provider
                            else SettlementStatus.UNKNOWN)
                if observation is None:
                    reader = getattr(provider, "observe_settlement", None)
                    observation = reader() if callable(reader) else None
                if not self._valid_settlement_observation(exchange_name, provider, observation):
                    return SettlementStatus.UNKNOWN
                if observation.status is SettlementStatus.CONFIRMED:
                    return SettlementStatus.CONFIRMED
                if observation.status is not SettlementStatus.UNCONFIRMED:
                    return SettlementStatus.UNKNOWN
            except Exception:
                return SettlementStatus.UNKNOWN
            if not self._admission.is_enabled(exchange_name):
                raise WriteAdmissionDenied("write_admission_disabled", exchange_name)
            record = PreDispatchRecord(
                operation=WriteOperation.SETTLEMENT_CONFIRM,
                host_scope=host_scope,
                exchange_name=exchange_name,
                symbol=None,
                identity=None,
                target_identity=None,
                request_summary={"account_binding": observation.account_binding,
                                 "observation_id": observation.observation_id},
                trading_day=observation.trading_day,
                session_generation=observation.session_generation,
                created_at_utc=_utc_now_text(),
            )
            if not self._valid_settlement_observation(exchange_name, provider, observation):
                return SettlementStatus.UNKNOWN
            marker = self._commit(commit_port, record)
            if marker is None:
                return SettlementStatus.UNKNOWN
            grant = None
            result = SettlementStatus.UNKNOWN
            try:
                if not self._valid_settlement_observation(exchange_name, provider, observation):
                    raise ValueError("settlement observation changed")
                binding = SettlementWriteBinding(observation, marker)
                grant = self._admission.issue(
                    exchange_name, WriteOperation.SETTLEMENT_CONFIRM,
                    observation.session_generation, settlement_binding=binding,
                )
                if (type(grant) is not WriteGrant or grant.settlement_binding is not binding
                        or grant.exchange_name != exchange_name
                        or grant.operation is not WriteOperation.SETTLEMENT_CONFIRM
                        or grant.session_generation != observation.session_generation
                        or not self._valid_settlement_observation(
                            exchange_name, provider, observation
                        )):
                    raise ValueError("settlement grant changed")
                confirmed = provider.confirm_settlement(
                    grant, self._admission, observation=observation
                )
                if (confirmed is SettlementStatus.CONFIRMED
                        and getattr(provider, "settlement_required", None) is True
                        and self._providers.get(exchange_name) is provider):
                    result = confirmed
            except Exception:
                result = SettlementStatus.UNKNOWN
            finally:
                if type(grant) is WriteGrant:
                    try:
                        self._admission.revoke_grant(grant)
                    except Exception:
                        result = SettlementStatus.UNKNOWN
            return result

    # ------------------------------------------------------------------
    def register_restored_identity(
        self,
        exchange_name: str,
        identity: NativeOrderIdentity,
        marker_id: Optional[str],
        host_scope: Optional[str],
    ) -> None:
        """Re-attach a persisted host marker after a restart (D62-14/16).

        Pass the identity as reserved: a session-scoped (CTP) identity keeps
        its ``front_id``/``session_id`` so that its (trading day, OrderRef)
        key stays weak; without them that key is taken as account-unique.
        On a trading-day scoped route it also keeps its ``trading_day``: it
        then matches only returns of that day, and without one readable day
        it raises ``DirectWriteError("direct_identity_trading_day_unreadable")``
        and nothing is registered.
        """

        correlator = self._correlator(exchange_name)
        correlator.register(identity, marker_id, host_scope, _identity_trading_day(identity))

    def poll_events(self, exchange_name: str, max_events: int = 256) -> tuple[CorrelatedDirectEvent, ...]:
        """Drain the route's returns, drop replays and correlate the rest.

        Replays are dropped per the route's de-duplication scope (module
        docstring): per trading day on a provider declaring trading-day scoped
        ids, where a return without a readable trading day is always delivered
        and never attributed.
        """

        provider = self.provider(exchange_name)
        correlator = self._correlator(exchange_name)
        out: list[CorrelatedDirectEvent] = []
        for event in provider.drain_execution_events(max_events):
            seen_key = correlator.seen_key(event)
            if seen_key is not None and not correlator.first_seen(seen_key):
                continue
            day = _event_trading_day(event) if correlator.day_scoped_ids else None
            found = correlator.lookup(event.identity, day)
            if found is None and event.exchange_order_id and event.identity is not None:
                venue_key_identity = NativeOrderIdentity(
                    exchange_name=event.exchange_name,
                    client_order_id=None,
                    fields={
                        "exchange_id": event.identity.fields.get("exchange_id"),
                        "order_sys_id": event.exchange_order_id,
                    },
                )
                found = correlator.lookup(venue_key_identity, day)
            if (
                found is not None
                and event.kind is DirectExecutionEventKind.ORDER
                and event.identity is not None
                and event.exchange_order_id
            ):
                # Learn the venue identity so later trades (no FrontID/SessionID)
                # correlate by ExchangeID + OrderSysID.  Only a strong match
                # teaches it: a weak (trading day, OrderRef) hit may be another
                # session's order, whose fills must stay unattributed.  On a
                # trading-day scoped route the learned keys hold the day of
                # the return (a strong match implies one readable day).
                correlator.register(event.identity, found[0], found[1], day)
            if found is not None:
                evidence = "direct_identity_match"
            elif correlator.weak_candidate(event.identity):
                evidence = "weak_key_candidate"
            else:
                evidence = "unmatched"
            out.append(
                CorrelatedDirectEvent(
                    event=event,
                    matched=found is not None,
                    evidence=evidence,
                    marker_id=None if found is None else found[0],
                    host_scope=None if found is None else found[1],
                )
            )
        return tuple(out)

    def dropped_events(self, exchange_name: str) -> Optional[int]:
        """Cumulative count of returns the route's provider lost before any poll.

        The provider's own ``dropped_events`` (queue overflow, projection
        failures).  ``None`` when no provider was created for the route yet or
        its counter is missing, not a non-negative ``int``, or unreadable: an
        unknown count is never reported as zero.  Reading creates nothing.
        """

        provider = self._providers.get(exchange_name)
        if provider is None:
            return None
        try:
            value = getattr(provider, "dropped_events", None)
        except Exception:
            return None
        if type(value) is not int or value < 0:
            return None
        return value
