"""CTP native order and cancel normalization choices."""

from types import MappingProxyType

from bt_api_base.normalization_policy import LegacyNormalizationPolicy
from bt_api_base.order_identity_fields import NEUTRAL_ORDER_IDENTITY_FIELDS
from bt_api_base.provider_order_source_aliases import build_provider_order_source_aliases
from bt_api_base.order_provenance_fields import (
    NEUTRAL_ORDER_SOURCE_FIELDS,
    PROVIDER_SCOPED_ORDER_PROVENANCE_SCHEMAS,
)

from .quote_v2_time import project_quote_v2_timestamps
from .risk_source_position_projection import ctp_source_position_dimensions_error


def _ctp_cancel_metadata(result, request):
    """Project only bounded native action identity/evidence into the SDK row."""
    getter = getattr(result, "get_extra_data", None)
    if not callable(getter):
        return {}
    try:
        extra = getter()
    except Exception:
        return {}
    if not isinstance(extra, dict):
        return {}
    envelope = extra.get("ctp_cancel")
    if not isinstance(envelope, dict):
        return {}
    evidence = envelope.get("evidence")
    if not isinstance(evidence, dict):
        as_dict = getattr(evidence, "as_dict", None)
        if callable(as_dict):
            try:
                evidence = as_dict()
            except Exception:
                evidence = None
    safe_fields = (
        "request_id",
        "order_action_ref",
        "status",
        "account_fingerprint",
        "trading_day",
        "connection_generation",
        "order_ref",
        "order_sys_id",
        "front_id",
        "session_id",
        "instrument_id",
        "exchange_id",
        "action_flag",
        "evidence_source",
        "evidence_received",
        "callback_received",
        "error_code",
        "reason",
        "observed_at_utc",
    )
    projected = (
        {key: evidence[key] for key in safe_fields if key in evidence}
        if isinstance(evidence, dict)
        else {}
    )
    # CtpRequestData exposes a redacted dictionary, not the immutable native
    # evidence object. Without the raw account binding this cannot be promoted
    # into matching callback evidence at the public normalization boundary.
    status = "unknown"
    if projected:
        projected["status"] = status
    return {
        "cancel_action_id": getattr(request, "idempotency_key", "") or "",
        "native_request_id": envelope.get("request_id"),
        "order_action_ref": envelope.get("order_action_ref"),
        "cancel_status": status,
        "cancel_evidence": projected,
    }


class CtpNormalizationPolicy(LegacyNormalizationPolicy):
    trade_id_fields = ("trade_id", "fill_id", "deal_id", "TradeID")
    risk_position_dimensions_require_projection = True
    risk_position_dimensions_projector = staticmethod(ctp_source_position_dimensions_error)
    # Preserve the prior acknowledgement contract pending venue review.
    position_mode_ack_code = "200"
    position_mode_placement_guard_required = False
    tick_trading_day_fields = ("trading_day", "TradingDay")
    tick_action_day_fields = ("action_day", "ActionDay")
    # Preserve the previous common aliases until venue-specific coverage is reviewed.
    order_status_fields = ("status", "order_status", "state")
    trade_fee_fields = ("fee_amount", "fee", "trade_fee", "commission")
    identity_fields = NEUTRAL_ORDER_IDENTITY_FIELDS
    order_provenance_schemas = PROVIDER_SCOPED_ORDER_PROVENANCE_SCHEMAS
    order_provenance_source_fields = NEUTRAL_ORDER_SOURCE_FIELDS | frozenset({
        'AccountID',
        'InstrumentID',
        'InvestorID',
        'OrderRef',
        'OrderSysID',
        'Price',
        'TradeID',
        'Volume',
        'VolumeTotalOriginal',
        'VolumeTraded',
        'ctp_direction_code',
        'ctp_offset_code',
    })
    (
        risk_order_source_aliases,
        group_order_source_aliases,
        group_fill_source_aliases,
    ) = build_provider_order_source_aliases(
        order_provenance_source_fields,
        risk_order_native_aliases={
            "provider_order_id": ("OrderSysID",),
            "client_order_id": ("OrderRef",),
            "status": (),
            "filled_quantity": ("VolumeTraded",),
            "quantity": ("VolumeTotalOriginal",),
            "account_id": ("AccountID", "InvestorID"),
            "instrument": ("InstrumentID",),
            "side": (),
            "price": (),
            "position_side": (),
            "offset": (),
        },
        group_order_native_aliases={
            "order_id": ("OrderSysID",),
            "client_order_id": ("OrderRef",),
            "status": (),
            "filled": ("VolumeTraded",),
            "quantity": ("VolumeTotalOriginal",),
            "account_id": ("AccountID", "InvestorID"),
            "instrument": ("InstrumentID",),
            "side": (),
            "price": (),
        },
        group_fill_native_aliases={
            "trade_id": ("TradeID",),
            "order_id": ("OrderSysID",),
            "client_order_id": ("OrderRef",),
            "account_id": ("AccountID", "InvestorID"),
            "instrument": ("InstrumentID",),
            "side": (),
            "quantity": ("Volume",),
            "price": ("Price",),
        },
    )
    quote_v2_schema = "ctp.quote.v2"
    quote_v2_timestamps = staticmethod(project_quote_v2_timestamps)
    # Preserve the former shared response alias pending venue-specific review.
    response_error_item_fields = ("sCode",)
    # CTP/OKX source uses the neutral data collection.
    result_collection_fields = ("data",)
    base_symbol_fields = (
        "symbol", "symbol_name", "instrument", "instrument_id", "data_name", "InstrumentID",
        "trade_symbol",
    )
    quantity_unit = "contracts"
    permission_fields = ("trading_permissions",)
    can_trade_fields = ("can_trade",)
    trade_authority = True
    order_statuses = MappingProxyType({
        "open": "accepted", "working": "accepted", "submitted": "submitted",
        "accepted": "accepted", "pending": "submitted", "partial": "partial",
        "partially_filled": "partial", "partial_filled": "partial", "filled": "completed",
        "completed": "completed", "all_traded": "completed", "cancelled": "canceled",
        "canceled": "canceled", "expired": "expired", "rejected": "rejected",
        "unknown": "unknown", "local_pending": "submitted",
    })
    position_mode_boolean_field = None
    position_mode_fields = ("position_mode",)
    position_mode_aliases = MappingProxyType({})
    order_fields = MappingProxyType({
        "order_id": ("order_id", "external_order_id", "order_sys_id", "OrderSysID"),
        "client_id": ("client_order_id", "order_ref", "OrderRef"),
        "filled": ("filled", "filled_quantity", "executed_qty", "VolumeTraded"),
        "average": ("avg_price", "average_price", "order_avg_price"),
        "cum_quote": ("cum_quote",), "size": ("quantity", "size", "order_size", "VolumeTotalOriginal"),
        "order_ref": ("order_ref", "OrderRef"), "exchange_id": ("exchange_id", "ExchangeID"),
        "front_id": ("front_id", "FrontID"), "session_id": ("session_id", "SessionID"),
        "account_id": ("account_id", "AccountID", "InvestorID"),
        "trading_day": ("trading_day", "TradingDay"), "fee_currency": ("fee_currency",),
        "commission_currency": ("commission_currency", "fee_currency"),
    })
    trade_fields = MappingProxyType({
        "order_id": ("order_id", "external_order_id", "OrderSysID"),
        "client_id": ("client_order_id", "OrderRef"),
        "size": ("quantity", "size", "trade_volume", "volume", "Volume"),
        "price": ("trade_price", "price", "Price"), "exchange_id": ("exchange_id", "ExchangeID"),
        "account_id": ("account_id", "AccountID", "InvestorID"),
        "trading_day": ("trading_day", "TradingDay"),
        "fee_currency": ("fee_currency", "trade_fee_symbol"),
    })
    signed_fee_currency_field = None
    position_fields = MappingProxyType({
        "quantity": (
            "quantity", "position_volume", "volume", "size", "Position", "trade_volume",
        ),
        "side": ("position_side", "direction", "position_direction", "side"),
        "position_id": ("position_id",),
        "price": ("average_price", "avg_price", "price"),
        "today": ("today", "today_position", "today_volume", "TodayPosition"),
        "yesterday": ("yesterday", "yesterday_position", "yd_position", "YdPosition"),
        "multiplier": ("multiplier", "contract_size", "volume_multiple", "VolumeMultiple"),
        "exchange_id": ("exchange_id", "ExchangeID"),
    })
    balance_nested_fields = ("balances",)
    balance_fields = MappingProxyType({
        "currency": ("CurrencyID", "currency", "account_type", "symbol_name", "symbol"),
        "cash": (
            "available_cash", "available", "cash", "available_margin", "Available",
            "margin_free", "free_margin", "free",
        ),
        "value": ("Balance", "equity", "value"),
        "wallet": ("balance", "margin", "total_wallet_balance"),
        "unrealized": ("unrealized_profit",),
        "margin_used": ("margin_used", "used_margin", "CurrMargin"),
        "account_id": ("account_id", "AccountID"),
    })
    instrument_spec_fields = MappingProxyType({
        "symbol": ("symbol", "symbol_name"),
        "base_currency": ("base_currency",),
        "quote_currency": ("quote_currency",),
        "asset_type": ("asset_type",),
        "contract_type": ("contract_type",),
    })
    instrument_spec_linear_type_field = None
    instrument_fields = MappingProxyType({
        "multiplier": ("multiplier", "contract_size", "VolumeMultiple"),
        "step": ("lot_size", "order_size_step", "volume_step"),
        "min_size": ("min_size", "volume_min", "MinLimitOrderVolume"),
        "max_size": ("max_size", "volume_max", "MaxLimitOrderVolume"),
        "tick_size": ("tick_size", "price_tick", "PriceTick"),
        "settlement_currency": ("settlement_currency", "currency"),
        "base_currency": ("base_currency",),
        "margin_rate": ("margin_rate", "LongMarginRatio", "long_margin_rate"),
        "commission_rate": ("commission_rate", "taker_commission_rate"),
        "exchange_id": ("exchange_id", "ExchangeID"),
    })
    instrument_contract_value_field = None
    instrument_contract_multiplier_field = None
    instrument_linear_type_field = None
    instrument_perpetual_type_field = None
    event_id_fields = ("event_id", "trade_id", "fill_id", "order_id")
    event_audit_fields = ("sequence", "sequence_id", "previous_sequence")
    tick_bid_fields = ("bid_price", "bid", "BidPrice1")
    tick_ask_fields = ("ask_price", "ask", "AskPrice1")
    tick_price_fields = ("price", "last_price", "last", "LastPrice")
    tick_volume_fields = ("volume", "last_volume", "Volume")
    tick_cumulative_fields = ("cum_volume", "cumulative_volume", "Volume")
    orderbook_sequence_fields = ("sequence", "sequence_id", "update_id")
    orderbook_previous_fields = ("previous_sequence", "prev_sequence")
    orderbook_delta_predecessor_fields = ()

    def order_average(self, row, average, *, pick, number):
        # CTP order reports contain limit price, not an execution VWAP.
        return number(pick(row, "execution_avg_price"))

    def apply_cancel_result(self, normalized, result, request):
        normalized.update(_ctp_cancel_metadata(result, request))
        # An action callback never proves the resting order's final state.
        normalized.update(
            status="submitted",
            execution_unknown=True,
            terminal_confirmed=False,
            definite_reject=False,
        )


def normalization_policy(exchange_name):
    return CtpNormalizationPolicy()


__all__ = ("normalization_policy",)
