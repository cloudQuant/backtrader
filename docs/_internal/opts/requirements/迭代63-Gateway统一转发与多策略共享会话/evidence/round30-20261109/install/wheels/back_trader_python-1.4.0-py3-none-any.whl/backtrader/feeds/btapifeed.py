#!/usr/bin/env python
"""Unified bt_api_py-backed live data feed."""

from __future__ import annotations

import collections
from collections.abc import Mapping
import copy
from dataclasses import dataclass
import datetime as _dt
import math
import time as _time
from types import MappingProxyType, SimpleNamespace
from typing import Optional, Tuple

from ..channel import Event, EventPriority
from ..dataseries import TimeFrame
from ..events import BarEvent
from ..utils.bar_projection import normalize_bar as _normalize_bar
from ..utils.redaction import redact_diagnostic as _redact_diagnostic
from ..utils import date2num
from ..utils.log_message import get_logger, throttled_warning
from .barrier import BarEvidence
from .livefeed import LiveFeedBase
from .market_tick_adapter import (
    MARKET_TICK_QUALIFICATION_REASONS,
    MarketTickAdapterError,
    adapt_market_tick_event,
    ingest_market_tick_event,
    qualify_market_tick_event,
)
from ._btapi_cohort import (
    LiveBarCohortFeedMixin,
    _COHORT_MISSING,
    _LIVE_COHORT_EXTRA_LINES,
    _tick_value,
)

logger = get_logger(__name__)
_LOGGING_HEALTH: "collections.Counter[str]" = collections.Counter()


def _safe_log(level, message, *args):
    """Keep a failing log sink outside feed control flow."""
    try:
        getattr(logger, level)(_redact_diagnostic(message), *map(_redact_diagnostic, args))
    except Exception:
        # The sink itself failed. Calling it again would escape this guard
        # before its health counter is incremented and disrupt feed callbacks.
        _LOGGING_HEALTH["logging_errors"] += 1


_UTC = _dt.timezone.utc
_TICK_PRICE_FIELDS = ("price", "last_price")
_MAX_DIAGNOSTIC_TEXT = 128

# Tick quality flags that only concern live-order use of a typed SDK tick
# admitted by ``ingest_market_tick_event`` (iteration 62, D62-27): clock and
# freshness evidence, the SDK's execution verdict and the two age limits.
# They keep such a tick ``execution_eligible=False`` and ``quality="INVALID"``
# but do not stop its data from entering bars, lines and indicators, and do
# not by themselves degrade the feed's continuity status.
_TRADE_ONLY_TICK_FLAGS = frozenset(
    {
        "UPSTREAM_EXECUTION_INELIGIBLE",
        "SOURCE_CLOCK_UNVERIFIED",
        "RECEIVE_CLOCK_UNVERIFIED",
        "FRESHNESS_UNVERIFIED",
        "STREAM_UNREADY",
        "EVENT_TIME_STALE",
        "RECEIVE_TIME_STALE",
    }
) | MARKET_TICK_QUALIFICATION_REASONS

# Iteration 62, D62-38 (user decision 2026-11-06): feed health (LIVE/DELAYED)
# and live-order use gate only on price freshness, the current connection
# without local message loss, quote validity and the trading phase. The flag
# families below describe other dimensions; on an ordinary (non-cohort) feed
# they never degrade the feed by themselves.
#
# Continuity values with which a provider attests the current connection and
# no local message loss (the same values that restore LIVE).
_ATTESTED_CONTINUITY = frozenset({"ok", "continuous", "recovered", "snapshot"})
# Volume accounting (CTP baseline/reset, OKX/Binance trade-id jumps): only
# marks the tick's bar when the continuity is attested; it never blocks orders.
_VOLUME_ACCOUNTING_TICK_FLAGS = frozenset({"VOLUME_INCOMPLETE", "VOLUME_DISCONTINUITY"})
# Quote-shape warnings: a locked book, an empty side, or a one-sided book at
# the snapshot's own limit price is a valid quote. Kept on the tick and as the
# bar's ``quality_warnings``; never a data defect.
_QUOTE_WARNING_TICK_FLAGS = frozenset(
    {
        "LOCKED_BOOK",
        "ZERO_DEPTH",
        "BID_DEPTH_ZERO",
        "ASK_DEPTH_ZERO",
        "LIMIT_LOCKED_UP",
        "LIMIT_LOCKED_DOWN",
    }
)
# Bar construction: the tick cannot enter its bar (bucket already closed or
# behind the event-time watermark, or the first tick of a newer connection or
# subscription scope, whose open bars were invalidated). Not a feed defect.
_BAR_CONSTRUCTION_TICK_FLAGS = frozenset(
    {
        "BUCKET_ALREADY_CLOSED",
        "LATE_AFTER_WATERMARK",
        "CONNECTION_GENERATION_CHANGED",
        "SUBSCRIPTION_EPOCH_CHANGED",
    }
)

# Provider continuity values that leave the feed's healthy LIVE state.
_UNHEALTHY_CONTINUITY = frozenset(
    {"gap", "stale", "disconnected", "checksum_failed", "out_of_order", "invalid"}
)

# Iteration 62 decision 2: the only flags of a bar that is volume-incomplete
# rather than invalid (its prices come from healthy ticks).
_VOLUME_INCOMPLETE_BAR_FLAGS = frozenset(
    {"VOLUME_INCOMPLETE", "VOLUME_BASELINE", "VOLUME_DISCONTINUITY", "ORDERING_VOLUME_GAP"}
)
_INCOMPLETE_VOLUME_BAR_MODES = ("lines", "notify_only")


def _separates_trade_qualification(tick):
    """Whether the tick came from the qualification-separating SDK ingest path."""
    return type(getattr(tick, "trade_qualified_at_receipt", None)) is bool


def _data_quality_flags(tick):
    """Tick quality flags that describe its data (all flags on other paths).

    Quote-shape warnings are never data defects of a bar (D62-38).
    """
    flags = _tick_value(tick, "quality_flags", default=()) or ()
    if not _separates_trade_qualification(tick):
        return tuple(flag for flag in flags if flag not in _QUOTE_WARNING_TICK_FLAGS)
    return tuple(
        flag
        for flag in flags
        if flag not in _TRADE_ONLY_TICK_FLAGS and flag not in _QUOTE_WARNING_TICK_FLAGS
    )


def _quote_warning_flags(tick):
    """Quote-shape warnings of one tick (D62-38); they never make a bar incomplete."""
    flags = _tick_value(tick, "quality_flags", default=()) or ()
    return tuple(flag for flag in flags if flag in _QUOTE_WARNING_TICK_FLAGS)


def _limit_locked_side(tick, price, bid, ask, bid_size, ask_size):
    """``"UP"``/``"DOWN"`` for a one-sided book at the snapshot's own limit (D62-38).

    Limit up: no ask (missing or non-positive price, zero size) and the bid
    exactly equal to this snapshot's upper limit price; limit down mirrors it.
    The last price must be positive and inside the limits. Anything else (an
    unknown limit, a near miss, both sides missing) is not a limit lock, so
    the missing side's price stays an invalid quote (fail closed).
    """
    if price is None or price <= 0:
        return None
    upper = _finite_market_number(
        _tick_value(tick, "upper_limit_price", "upper_limit", default=None)
    )
    lower = _finite_market_number(
        _tick_value(tick, "lower_limit_price", "lower_limit", default=None)
    )
    bid_missing = bid is None or bid <= 0
    ask_missing = ask is None or ask <= 0
    if (
        ask_missing
        and not bid_missing
        and ask_size == 0
        and upper is not None
        and upper > 0
        and bid == upper
        and price <= upper
        and (lower is None or price >= lower)
    ):
        return "UP"
    if (
        bid_missing
        and not ask_missing
        and bid_size == 0
        and lower is not None
        and lower > 0
        and ask == lower
        and price >= lower
        and (upper is None or price <= upper)
    ):
        return "DOWN"
    return None


def _tick_continuity(tick):
    """Lower-case provider continuity status of one tick; ``"unknown"`` when absent."""
    return str(
        _tick_value(tick, "continuity_status", "continuity", default="unknown") or "unknown"
    ).lower()


def _trade_only_flags(tick):
    """Trade-only flags of an ingest-path tick (none on other paths)."""
    if not _separates_trade_qualification(tick):
        return ()
    flags = _tick_value(tick, "quality_flags", default=()) or ()
    return tuple(flag for flag in flags if flag in _TRADE_ONLY_TICK_FLAGS)


@dataclass(frozen=True)
class FeedLineBarQuality:
    """Quality of the bar at ``[0]`` on a :class:`BtApiFeed`'s lines (iteration 62).

    ``complete`` is False only for a bar that entered the lines with
    incomplete volume (``incomplete_volume_bars="lines"``); its
    ``quality_flags`` then name the volume defect(s). ``volume_complete`` is
    ``None`` when the source did not say (e.g. a provider or history bar).
    ``source`` is the line source label (see ``valuation_mark_sources``).
    """

    complete: bool
    volume_complete: Optional[bool]
    quality_flags: Tuple[str, ...]
    source: str


@dataclass(frozen=True)
class FeedTradeQualification:
    """Whether a :class:`BtApiFeed` may back a live order right now (D62-21).

    ``ok`` holds only when the feed is in LIVE status, its last real-time
    tick was trade-qualified at receipt (source and receive clocks VERIFIED,
    freshness FRESH, SDK execution eligible, event-to-receive latency within
    ``event_time_max_age``), no later tick failed ingestion, and the time
    since that tick's local receipt is within ``receive_time_max_age``.
    ``reasons`` lists finite codes for every failed condition; LIVE status is
    reported separately in ``live`` (D62-15b). Times are timezone-aware UTC.
    """

    ok: bool
    reasons: Tuple[str, ...]
    live: bool
    last_event_time_utc: Optional[_dt.datetime]
    last_received_at_utc: Optional[_dt.datetime]
    receive_age_seconds: Optional[float]


def _bounded_context_value(value):
    """Keep diagnostic identifiers finite without retaining arbitrary objects."""
    if type(value) is str:
        return value[:_MAX_DIAGNOSTIC_TEXT]
    if type(value) is int and -(2**63) <= value < 2**63:
        return value
    return None


def _set_tick_value(tick, name, value):
    """Set one normalized field on mapping and object event shapes."""
    if isinstance(tick, dict):
        tick[name] = value
    else:
        setattr(tick, name, value)


def _finite_market_number(value):
    """Delegate neutral number normalization to the SDK market contract."""
    from bt_api_py.market_tick_contracts import finite_market_number

    return finite_market_number(value)


def _normalize_bar_with_finality(bar):
    """Project a bar without discarding an explicitly supplied completion state."""
    source = dict(bar) if isinstance(bar, Mapping) else bar
    normalized = _normalize_bar(source)
    if isinstance(source, dict) and "bar_final" in source:
        normalized["bar_final"] = source["bar_final"]
    return normalized


def _as_utc_datetime(value):
    """Parse an event-time field without silently replacing invalid source time."""
    from bt_api_py.market_tick_contracts import parse_market_event_datetime

    return parse_market_event_datetime(value)


def _tick_timestamp(tick):
    from bt_api_py.market_tick_contracts import market_event_timestamp

    return market_event_timestamp(tick, on_invalid_datetime=_log_invalid_market_datetime)


def _tick_mark_source(tick):
    """Valuation source of one Tick-timeframe line value (iteration 60, F6).

    Only a typed SDK tick that passed this feed's source and quality gates
    (``quality == "GOOD"``, no ``LEGACY_SCHEMA``) is a ``market_tick``. A
    typed tick admitted with valid data but without trade qualification is
    ``market_tick_unqualified`` (not a trusted valuation source).
    """
    flags = _tick_value(tick, "quality_flags", default=()) or ()
    if _tick_value(tick, "quality", default=None) == "GOOD" and "LEGACY_SCHEMA" not in flags:
        return "market_tick"
    if (
        _separates_trade_qualification(tick)
        and _tick_value(tick, "data_quality", default=None) == "GOOD"
    ):
        return "market_tick_unqualified"
    return "legacy_tick"


def _local_bar_source(bar_event):
    """Valuation source of a bar this feed closed locally (iteration 60, F6)."""
    if getattr(bar_event, "replay_bar_status", None) is not None:
        return "replay"
    flags = getattr(bar_event, "quality_flags", None) or ()
    if "LEGACY_SCHEMA" in flags or getattr(bar_event, "quality", None) != "GOOD":
        return "local_aggregation_legacy"
    if getattr(bar_event, "trade_qualification_flags", None):
        # Complete data, but at least one tick was not trade-qualified.
        return "local_aggregation_unqualified"
    return "local_aggregation"


def _tick_datetime(tick):
    from bt_api_py.market_tick_contracts import market_event_utc_naive_datetime

    return market_event_utc_naive_datetime(tick, on_invalid_datetime=_log_invalid_market_datetime)


def _log_invalid_market_datetime(reason):
    messages = {
        "timestamp_datetime": "btapifeed:132 ignored ValueError",
        "datetime_timestamp": "btapifeed:147 ignored TypeError,ValueError",
        "datetime_datetime": "btapifeed:159 ignored ValueError",
    }
    _safe_log("debug", messages[reason])


def _causal_event_kwargs(event):
    """Copy standard timing and identity fields into derived events."""
    return {
        key: _tick_value(event, key, default=None)
        for key in (
            "exchange_time",
            "received_wall_time",
            "received_monotonic_ns",
            "clock_domain_id",
            "sequence",
            "previous_sequence",
            "snapshot_or_delta",
            "continuity_status",
            "stale",
            "stale_reason",
            "source",
            "event_id",
            "coalesced_count",
        )
        if _tick_value(event, key, default=None) is not None
    }


class BtApiFeed(LiveBarCohortFeedMixin, LiveFeedBase):
    """Data feed that backfills and streams bars through BtApiStore.

    ``orderbook_as_ticks=True`` exposes each depth snapshot as a zero-volume
    midpoint tick bar before calling ``notify_orderbook``. This gives native
    broker orders a valid feed price and clock even without trade/bar streams.
    It requires ``timeframe=TimeFrame.Ticks`` for legacy non-SDK adapters.
    SDK order-book events retain their unknown clock/freshness and are delivered
    only to notification callbacks; they never create midpoint bars.
    """

    # These fixed numeric slots are used by the opt-in research cohort path.
    # They remain NaN unless the exact registered member maps each field to a
    # validated raw numeric field. Ordinary feeds keep their historical loader.
    lines = _LIVE_COHORT_EXTRA_LINES

    params = (
        ("store", None),
        ("provider", "btapi"),
        ("replay_market_tick_port", None),
        ("historical_bars", None),
        ("live_bars", None),
        # Explicit cohort mode keeps saved source events raw until the cohort
        # validates them. Ordinary feeds retain their historical tolerant
        # normalization path.
        ("cohort_source_mode", False),
        # Optional SDK-resolved factor source binding. Kept out of ordinary
        # imports and behavior unless the caller explicitly supplies it.
        ("market_factor_source_binding", None),
        # Adapter-authored origin claim; cohort matching does not prove exchange completeness.
        ("cohort_source_origin", None),
        ("backfill_start", True),
        ("dispatch_ticks", True),
        ("dispatch_orderbooks", True),
        ("dispatch_bars", True),
        ("orderbook_as_ticks", False),
        ("market_channels", None),
        ("orderbook_depth", None),
        ("bar_watermark_ms", 500),
        ("event_time_max_age", 2.0),
        ("receive_time_max_age", 2.0),
        # D62-38: consecutive real-time ticks whose exchange time went
        # backwards before the feed degrades; fewer are dropped and counted.
        ("event_time_regression_limit", 3),
        # Iteration 62 decision 2 (2026-11-06): a closed bar whose only defects
        # are volume accounting (VOLUME_INCOMPLETE, VOLUME_BASELINE,
        # VOLUME_DISCONTINUITY, ORDERING_VOLUME_GAP) enters the data lines
        # ("lines", default) or is only sent to notify_bar ("notify_only").
        # Its BarEvent keeps complete=False and the flags either way; the line
        # bar's quality is readable through line_bar_quality().
        ("incomplete_volume_bars", "lines"),
        # D62-38 decision 3 (user 2026-11-06): opt-in strict volume continuity
        # per strategy/feed. When True, volume-accounting defects
        # (VOLUME_INCOMPLETE, VOLUME_DISCONTINUITY and a VOLUME_BASELINE tick)
        # block like data defects again, as before D62-38: the feed degrades
        # and the tick is not tradable. Default False (bar-only flags).
        ("strict_volume_continuity", False),
        ("price_tick", None),
        ("clock", None),
        # Optional bounded per-bucket quote capture for the strict options
        # adapters: each prepared tick inside a bucket is frozen (with its
        # stamped provenance) onto the sealed bar event's ``quote_events`` so
        # examples can build minute quote windows without inventing them.
        # Default off; overflow drops the oldest record and flags the bucket.
        ("closed_bar_quote_capture", False),
        ("closed_bar_quote_limit", 240),
        # A caller-owned, calibrated provider invoked at the synchronous
        # strategy-dispatch boundary for SDK-qualified market ticks. It must
        # return MarketCohortNow in the event's exact monotonic clock domain.
        # There is deliberately no process-clock fallback here.
        ("market_decision_now_provider", None),
        # A caller-owned adapter from a Feed-owned, immutable closed BarEvent
        # to the public BarEvidence hand-off.  The Feed only attaches a
        # successfully validated object; it never invents a clock mapping or
        # candidate scope from process-local state.
        ("closed_bar_evidence_provider", None),
    )

    def __init__(self, *args, **kwargs):
        """Initialize the feed, normalize inputs, and prepare internal state.

        The constructor performs three pieces of work:

        1. Resolves the :class:`BtApiStore` instance and the data provider
           tag from the parsed parameters and stashes them on the instance
           for quick access during :meth:`start` / :meth:`_load`.
        2. Normalizes the optional pre-supplied ``historical_bars`` and
           ``live_bars`` parameters into :class:`collections.deque`
           instances so that :meth:`_load` can ``popleft`` from them in O(1).
        3. Initializes the runtime flags that govern backfill behavior
           (``_history_backfilled``) and bar aggregation
           (``_bar_builder``).

        Args:
            *args: Positional arguments forwarded to the
                :class:`backtrader.feed.DataBase` constructor. Typically
                this is just the ``dataname`` (symbol/contract identifier).
            **kwargs: Parameter overrides. Any key matching a name in
                :attr:`params` overrides the corresponding default; unknown
                keys are forwarded to the base class unchanged.
        """
        super().__init__(*args, **kwargs)
        regression_limit = self.p.event_time_regression_limit
        if type(regression_limit) is not int or regression_limit < 1:
            raise ValueError("event_time_regression_limit must be an int >= 1")
        self._event_time_regression_limit = regression_limit
        self._event_time_regression_run = 0
        incomplete_volume_bars = self.p.incomplete_volume_bars
        if type(incomplete_volume_bars) is not str or incomplete_volume_bars not in (
            _INCOMPLETE_VOLUME_BAR_MODES
        ):
            raise ValueError("incomplete_volume_bars must be 'lines' or 'notify_only'")
        self._incomplete_volume_bars = incomplete_volume_bars
        if type(self.p.strict_volume_continuity) is not bool:
            raise ValueError("strict_volume_continuity must be a bool")
        self._strict_volume_continuity = self.p.strict_volume_continuity
        self._line_bar_quality = None
        if self.p.closed_bar_evidence_provider is not None and not callable(
            self.p.closed_bar_evidence_provider
        ):
            raise ValueError("closed_bar_evidence_provider must be callable")
        self.store = self.p.store
        self.provider = self.p.provider
        self._replay_tick_adapter = None
        replay_port = self.p.replay_market_tick_port
        if replay_port is not None or self.provider == "local_replay":
            if (
                replay_port is None
                or self.provider != "local_replay"
                or self.store is not None
            ):
                raise ValueError(
                    "local_replay requires replay_market_tick_port and store=None"
                )
            if (
                self.p.cohort_source_mode is True
                or self.p.market_factor_source_binding is not None
                or self.p.closed_bar_evidence_provider is not None
                or self.p.market_decision_now_provider is not None
                or bool(self.p.closed_bar_quote_capture)
                or bool(self.p.orderbook_as_ticks)
            ):
                raise ValueError("replay market input cannot use live-only feed bindings")
            if self.p.backfill_start is not False:
                raise ValueError("replay market input requires backfill_start=False")
            for name, rows in (
                ("historical_bars", self.p.historical_bars),
                ("live_bars", self.p.live_bars),
            ):
                if rows is not None and (
                    type(rows) not in (tuple, list, collections.deque) or rows
                ):
                    raise ValueError(f"replay market input rejects preloaded {name}")
            from .replay_market_adapter import ReplayMarketTickAdapter

            self._replay_tick_adapter = ReplayMarketTickAdapter(replay_port, self._dataname)
        history_source = self.p.historical_bars
        live_source = self.p.live_bars
        if history_source is None:
            history_source = ()
        if live_source is None:
            live_source = ()
        cohort_source_mode = self.p.cohort_source_mode
        if type(cohort_source_mode) is not bool:
            raise ValueError("cohort_source_mode must be an exact bool")
        source_binding = self.p.market_factor_source_binding
        if source_binding is None:
            self._market_factor_source_binding = None
            self._market_factor_source_projector = None
            self._market_factor_source_error_type = None
        else:
            # Import only for this explicit live-source mode so a normal
            # BtApiFeed import remains compatible with Python 3.8 and does
            # not load the futures-session implementation.
            from .market_factor_source import (
                MarketFactorSourceBinding,
                MarketFactorSourceError,
                project_market_factor_tick,
            )

            if not isinstance(source_binding, MarketFactorSourceBinding):
                raise ValueError("market_factor_source_binding has an unsupported type")
            if not cohort_source_mode:
                raise ValueError("market factor source binding requires cohort_source_mode=True")
            self._market_factor_source_binding = source_binding
            self._market_factor_source_projector = project_market_factor_tick
            self._market_factor_source_error_type = MarketFactorSourceError
        self._market_factor_source_last_cursor_sequence = 0
        if cohort_source_mode:
            if type(history_source) is not tuple or type(live_source) is not tuple:
                raise ValueError("cohort_source_mode requires immutable tuple bar sources")
            if self.p.backfill_start:
                raise ValueError(
                    "cohort_source_mode requires backfill_start=False and explicit source tuples"
                )
        # Keep the caller's raw event objects available for the opt-in cohort
        # path without materializing an arbitrary iterator. Cohort mode accepts
        # replayable finite sequences here; live stores remain polled directly.
        self._cohort_history_source = (
            history_source if isinstance(history_source, (tuple, list)) else None
        )
        self._cohort_live_source = live_source if isinstance(live_source, (tuple, list)) else None
        self._live_bar_cohort = None
        self._cohort_clock = None
        self._cohort_history_iter = None
        self._cohort_live_iter = None
        self._cohort_history_exhausted = False
        self._cohort_live_exhausted = False
        self._cohort_history_lookahead = _COHORT_MISSING
        self._cohort_live_lookahead = _COHORT_MISSING
        self._cohort_store_lookahead = _COHORT_MISSING
        self._cohort_completed_lookahead = _COHORT_MISSING
        self._cohort_slot_index_by_close = {}
        self._cohort_last_delivered_slot_index = -1
        self._cohort_armed_envelope = None
        self._cohort_staged_delivery = None
        self._cohort_delivery_failed = False
        self._cohort_stream_health_baseline = None
        if cohort_source_mode:
            # The sealed cohort owns the strict validation boundary. Preserve
            # exact raw tuples and leave the legacy normalized queues empty so
            # malformed numbers cannot be silently coerced before capture.
            self._history = collections.deque()
            self._live = collections.deque()
        else:
            self._history = collections.deque(
                _normalize_bar_with_finality(bar)
                for bar in history_source
            )
            self._live = collections.deque(
                _normalize_bar_with_finality(bar)
                for bar in live_source
            )
        self._live_notified = False
        self._bar_builder = None
        self._bar_builders = collections.OrderedDict()
        self._initial_volume_baseline_scope = None
        self._initial_volume_baseline_start = None
        self._bar_quality_overrides = collections.defaultdict(set)
        self._max_event_timestamp = None
        self._last_ingest_monotonic_ns = None
        self._replay_started = False
        self._last_closed_bucket_end = None
        self._last_connection_generation = None
        self._last_market_scope = None
        self._highest_market_scope = None
        self._last_published_bar = None
        self._bar_integrity = {
            "duplicates": 0,
            "late": 0,
            "revisions_refused": 0,
            "unfinished": 0,
            "unknown_finality": 0,
        }
        self._bar_sequence = 0
        # Per-feed opaque marker proves that a strategy callback received the
        # sealed event from this exact Feed instance, rather than a caller
        # constructing a look-alike object around a BarEvidence value.
        self._closed_bar_evidence_dispatch_token = object()
        # This short-lived identity binding is populated immediately before
        # synchronous strategy dispatch and cleared immediately afterward.
        # It prevents a callback hook from retaining the event marker while
        # replacing the immutable evidence object with a different one.
        self._sealed_closed_bar_evidence_by_event_id = {}
        self._tick_consumer_claimed = False
        self._history_backfilled = bool(self._cohort_history_source) or bool(self._history)
        self._continuity_degraded = False
        self._stream_recovery_reader = None
        self._session_active = False
        # (last admitted real-time tick's MarketTickQualification or None,
        #  ingestion error code seen after it or None). Replaced as one
        # immutable tuple so a reader on another thread sees a whole pair.
        self._tick_trade_state = (None, None)
        self._tick_ingest_errors = collections.Counter()

    @property
    def live_bar_cohort(self):
        """Return the exact cohort installed by Cerebro for this feed, if any."""
        return self._live_bar_cohort

    def start(self):
        """Start the feed, register it, and backfill if configured."""
        new_session = not self._session_active
        if new_session:
            self._live_notified = False
            self._continuity_degraded = False
            self._tick_trade_state = (None, None)
        # D62-38 point 7: the Store's reason why its tick channel delivers
        # nothing (absent on stores without an SDK market stream).
        self._stream_recovery_reader = getattr(self.store, "tick_stream_recovery_reason", None)
        claimed_this_start = False
        try:
            super().start()
            if self.p.cohort_source_mode and self._live_bar_cohort is None:
                raise ValueError("cohort_source_mode requires Cerebro live cohort activation")
            if self.p.orderbook_as_ticks and self._timeframe != TimeFrame.Ticks:
                raise ValueError("orderbook_as_ticks requires timeframe=TimeFrame.Ticks")

            if self._replay_tick_adapter is not None:
                if self.store is not None or getattr(self, "_store", None) is not None:
                    raise ValueError("replay feed cannot bind a Store")
                if self._history or self._live or self.p.backfill_start:
                    raise ValueError("replay feed cannot mix Store or preloaded bar sources")
                self._replay_tick_adapter.start()
                self._replay_started = True
                self._session_active = True
                return

            if self.store is None:
                self.store = getattr(self, "_store", None)

            if self.p.cohort_source_mode:
                self._validate_cohort_store_raw_mode(self.store)

            if self.store is None:
                self._session_active = True
                return

            self.store.start(data=self)
            if self._live_bar_cohort is not None:
                try:
                    baseline = self._read_cohort_stream_health()
                except Exception:
                    self._freeze_cohort_source(
                        "store_stream_health_invalid",
                        "cohort Store stream health is invalid at startup",
                    )
                if baseline is not None and (
                    baseline[1] not in (None, 0) or baseline[2] not in (None, 0) or baseline[3]
                ):
                    self._freeze_cohort_source(
                        "store_stream_degraded_before_cohort_start",
                        "cohort Store stream was already degraded at startup",
                    )
                self._cohort_stream_health_baseline = baseline
            self.store.register(self)

            service_read_only = bool(getattr(self.store, "_service_read_only", False))
            if service_read_only:
                # Establish the bounded live cursor before history so bars
                # published during backfill can be replayed and deduplicated.
                self.store.subscribe(
                    self._dataname,
                    channels=self.p.market_channels,
                    orderbook_depth=self.p.orderbook_depth,
                )

            if self.p.backfill_start and not self._history and not self._history_backfilled:
                if service_read_only:
                    bars = self.store.fetch_history(
                        self._dataname,
                        timeframe=self._timeframe,
                        compression=self._compression,
                    )
                    if self._live_bar_cohort is not None:
                        self._cohort_history_iter = iter(bars)
                        self._cohort_history_exhausted = False
                    else:
                        self._history.extend(bars)
                    self._history_backfilled = True
                else:
                    try:
                        bars = self.store.fetch_history(
                            self._dataname,
                            timeframe=self._timeframe,
                            compression=self._compression,
                        )
                        if self._live_bar_cohort is not None:
                            self._cohort_history_iter = iter(bars)
                            self._cohort_history_exhausted = False
                        else:
                            self._history.extend(bars)
                        self._history_backfilled = True
                    except Exception as e:
                        _safe_log("warning", "btapifeed:312 fallback on Exception")
                        _safe_log("debug", "Failed to backfill history: %s", e)

            if not service_read_only:
                if self._uses_sdk_market_streams():
                    self.store.subscribe(
                        self._dataname,
                        channels=self.p.market_channels,
                        orderbook_depth=self.p.orderbook_depth,
                    )
                    claim = getattr(self.store, "claim_tick_consumer", None)
                    supports_ticks = getattr(self.store, "supports_live_ticks", None)
                    if (
                        callable(claim)
                        and callable(supports_ticks)
                        and supports_ticks(self._dataname)
                        and not self._tick_consumer_claimed
                    ):
                        claim(self._dataname, self)
                        self._tick_consumer_claimed = True
                        claimed_this_start = True
                else:
                    claim = getattr(self.store, "claim_tick_consumer", None)
                    if (
                        callable(claim)
                        and not self.p.orderbook_as_ticks
                        and not self._tick_consumer_claimed
                    ):
                        claim(self._dataname, self)
                        self._tick_consumer_claimed = True
                        claimed_this_start = True
                    self.store.subscribe(
                        self._dataname,
                        channels=self.p.market_channels,
                        orderbook_depth=self.p.orderbook_depth,
                    )
            self._session_active = True
        except Exception:
            _safe_log("error", "btapifeed:326 exception before re-raise (Exception)")
            if claimed_this_start and self.store is not None:
                release = getattr(self.store, "release_tick_consumer", None)
                if callable(release):
                    release(self._dataname, self)
                self._tick_consumer_claimed = False
            if new_session:
                self._session_active = False
            raise

    def stop(self):
        """Stop the feed."""
        try:
            super().stop()
        finally:
            if self._tick_consumer_claimed and self.store is not None:
                release = getattr(self.store, "release_tick_consumer", None)
                if callable(release):
                    release(self._dataname, self)
            # A live partial bucket is not a completed market bar.  Clear it
            # during teardown without dispatching a synthetic notify_bar after
            # Cerebro has already stopped the strategy.
            self._bar_builders.clear()
            self._bar_builder = None
            self._bar_quality_overrides.clear()
            self._max_event_timestamp = None
            self._last_ingest_monotonic_ns = None
            self._last_closed_bucket_end = None
            self._last_connection_generation = None
            self._initial_volume_baseline_scope = None
            self._initial_volume_baseline_start = None
            self._last_market_scope = None
            self._highest_market_scope = None
            self._event_time_regression_run = 0
            self._tick_consumer_claimed = False
            self._session_active = False
            self._tick_trade_state = (None, None)
            if self._replay_started:
                self._replay_tick_adapter.close()
                self._replay_started = False

    def islive(self) -> bool:
        """Return whether this feed has a configured live data source."""
        if self._replay_tick_adapter is not None:
            # Cerebro must poll this finite source, but replay never emits a
            # LIVE readiness notification or a live market-clock assertion.
            return True
        if self._live_bar_cohort is not None:
            return True
        dataname = getattr(self, "_dataname", None)

        if self._live:
            return True

        store = self.store or getattr(self, "_store", None)
        if store is None:
            return bool(self.p.live_bars)

        # Cerebro queries islive before Store.start. A public BtApi event
        # source is live without the legacy supports_live_* duck protocol.
        if getattr(store, "_sdk_mode", False):
            return True

        has_pending_live_bar = getattr(store, "has_pending_live_bar", None)
        if dataname is not None and callable(has_pending_live_bar) and has_pending_live_bar(dataname):
            return True

        api = getattr(store, "_api", None)
        if api is not None and dataname is not None:
            api_live = self._api_indicates_live(api, dataname)
            if api_live is not None:
                return api_live

        if getattr(store, "_api_cls", None) is not None:
            return True

        if api is None:
            return True

        return False

    @staticmethod
    def _api_indicates_live(api, dataname):
        """Whether the store API reports a live source for ``dataname``.

        Returns True/False when the API gives a definitive answer, or None when
        it has no opinion (caller falls through to other heuristics). Extracted
        from islive() to flatten the repeated supports_live_* probes.
        """
        for capability in (
            "supports_live_streaming",
            "supports_live_ticks",
            "supports_live_orderbook",
        ):
            if hasattr(api, capability):
                try:
                    if bool(getattr(api, capability)(dataname)):
                        return True
                except Exception as e:
                    _safe_log("warning", "btapifeed:411 fallback on Exception")
                    _safe_log("debug", "%s check failed: %s", capability, e)

        live_ticks = getattr(api, "live_ticks", None)
        if live_ticks is not None:
            return dataname in live_ticks

        live_orderbooks = getattr(api, "live_orderbooks", None)
        if live_orderbooks is not None:
            return dataname in live_orderbooks

        live_bars = getattr(api, "live", None)
        if live_bars is not None:
            return dataname in live_bars

        return None

    def haslivedata(self) -> bool:
        """Return whether a completed live bar is immediately available.

        Pending raw ticks/orderbooks are realtime traffic, but they do not
        advance the strategy clock until they aggregate into a completed bar.
        Treating them as live data here makes Cerebro skip qcheck and spin while
        repeatedly draining ticks that produce no bar.
        """
        if self._live_bar_cohort is not None:
            return False
        if self._live:
            return True

        store = self.store or getattr(self, "_store", None)
        if store is None:
            return False

        has_pending_live_bar = getattr(store, "has_pending_live_bar", None)
        return bool(has_pending_live_bar(self._dataname)) if callable(has_pending_live_bar) else False

    def _load_history(self) -> bool:
        """Load the next publishable historical bar, if any."""
        while self._history:
            if self._publish_bar(self._history.popleft()):
                return True
        return False

    # -- published-bar integrity (iteration 60, acceptance report P1-6) -------
    #
    # Provider bars are closed intervals (Base ``MarketBar``) whose identity is
    # the feed plus the bar's open time. Once a bar is published to the line
    # buffers it is never rewritten: a later bar with an earlier time is late,
    # one with the same time and identical OHLCV is a duplicate (for example
    # the history/live overlap), and one with the same time but different
    # values is a refused revision. All three are dropped, counted and logged;
    # Tick-timeframe feeds (many events per timestamp) are not checked.

    def bar_integrity_counts(self):
        """Counts of dropped bars, including unknown and unfinished finality."""
        return dict(self._bar_integrity)

    def tick_ingest_error_counts(self):
        """Counts of real-time SDK ticks dropped per finite ingestion error code.

        ``OUT_OF_ORDER_EVENT_TIME`` counts ticks dropped because their exchange
        time went backwards (D62-38).
        """
        return dict(self._tick_ingest_errors)

    def historical_warmup_active(self):
        """Whether historical bars are still being replayed (D62-15a).

        True while backfilled historical bars are still queued for delivery to
        the strategy.  A live feed that is merely quiet (closed market, no
        ticks) is not warming up.
        """
        return bool(self._history)

    def trade_qualification(self, now_monotonic_ns=None):
        """Whether this feed's data may back a live order now (D62-21/27/28).

        Separate from LIVE status (D62-15b) and computed afresh on every call:
        a quiet market makes the last tick expire. ``now_monotonic_ns``
        defaults to this feed's monotonic clock (the ``clock`` param when
        injected, otherwise ``time.monotonic_ns()``); it must be in the same
        monotonic domain as the ticks' ``received_monotonic_ns``. Never raises
        for an unusable input: it is reported as a finite reason.

        Returns:
            FeedTradeQualification: ``ok`` and the finite failure ``reasons``.
        """
        qualification, ingest_error = self._tick_trade_state
        live = bool(
            self._replay_tick_adapter is None
            and self._session_active
            and self._live_notified
            and not self._continuity_degraded
        )
        reasons = []
        if not live:
            reasons.append("FEED_NOT_LIVE")
        if ingest_error is not None:
            reasons.append(ingest_error)
        receive_age = None
        if qualification is None:
            reasons.append("REALTIME_TICK_UNAVAILABLE")
        else:
            reasons.extend(qualification.qualification_reasons)
            if now_monotonic_ns is None:
                now_monotonic_ns = self._now_monotonic_ns()
            if type(now_monotonic_ns) is not int:
                reasons.append("NOW_MONOTONIC_INVALID")
            else:
                age_ns = now_monotonic_ns - qualification.received_monotonic_ns
                if age_ns < 0:
                    # ``now`` precedes the receipt: not the same clock domain.
                    reasons.append("RECEIVE_AGE_INVALID")
                else:
                    receive_age = age_ns / 1_000_000_000.0
                    limit = self.p.receive_time_max_age
                    try:
                        limit = None if type(limit) is bool else float(limit)
                    except (TypeError, ValueError, OverflowError):
                        limit = None
                    if limit is None or not math.isfinite(limit) or limit < 0:
                        reasons.append("RECEIVE_TIME_MAX_AGE_INVALID")
                    elif receive_age > limit:
                        reasons.append("RECEIVE_TIME_STALE")
        return FeedTradeQualification(
            ok=not reasons,
            reasons=tuple(reasons),
            live=live,
            last_event_time_utc=(
                qualification.event_time_utc if qualification is not None else None
            ),
            last_received_at_utc=(
                qualification.received_at_utc if qualification is not None else None
            ),
            receive_age_seconds=receive_age,
        )

    def _record_tick_ingest_error(self, event, code):
        """Drop one SDK tick that cannot enter data lines (D62-27).

        The tick is never projected with a substituted time. The feed stays
        non-tradable until a later tick is admitted; the drop is counted,
        closed in Store accounting, and logged through the throttled logger
        (full message once per code, repeats summarized).
        """
        self._tick_ingest_errors[code] += 1
        self._tick_trade_state = (self._tick_trade_state[0], code)
        instrument = event.key.instrument
        self._mark_event_dropped(
            SimpleNamespace(
                symbol=instrument.instrument_id, key=event.key, cursor=event.cursor
            ),
            code.lower(),
        )
        try:
            throttled_warning(
                logger,
                "btapifeed.tick_ingest_error." + code,
                "btapifeed: dropped real-time tick for %s: %s",
                _redact_diagnostic(self._dataname),
                code,
                exc_info=False,
            )
        except Exception:
            _LOGGING_HEALTH["logging_errors"] += 1

    def _drop_regressed_tick(self, tick):
        """Drop one real-time tick whose exchange time went backwards (D62-38).

        Counted under ``OUT_OF_ORDER_EVENT_TIME`` in
        :meth:`tick_ingest_error_counts`, closed in Store accounting and logged
        through the throttled logger. It is not dispatched, does not enter a
        bar, does not move the event-time watermark and does not replace the
        last admitted tick's trade qualification.
        """
        code = "OUT_OF_ORDER_EVENT_TIME"
        self._tick_ingest_errors[code] += 1
        self._mark_event_dropped(tick, code.lower())
        try:
            throttled_warning(
                logger,
                "btapifeed.tick_ingest_error." + code,
                "btapifeed: dropped real-time tick for %s: %s",
                _redact_diagnostic(self._dataname),
                code,
                exc_info=False,
            )
        except Exception:
            _LOGGING_HEALTH["logging_errors"] += 1

    def _publish_bar(self, bar) -> bool:
        final = bar.get("bar_final") if isinstance(bar, Mapping) else getattr(bar, "bar_final", None)
        if final is False:
            # D60-15: a provider bar still forming is never published.
            return self._drop_bar("unfinished")
        if final is not True:
            # No completion claim, or a non-boolean claim, is not a closed bar.
            return self._drop_bar("unknown_finality")
        if isinstance(bar, Mapping):
            source = bar.get("bar_source")
        else:
            source = getattr(bar, "bar_source", None)
        source = source if type(source) is str and source else "provider_bar"
        if self._timeframe == TimeFrame.Ticks:
            normalized = _normalize_bar(bar)
            when = normalized["datetime"]
            # A tick's mark time is its own event time, not a bucket end.
            self._valuation_bar = (date2num(when), normalized["close"], when, source)
            self._record_line_bar_quality(bar, date2num(when), source)
            return self._load_bar(normalized)
        normalized = _normalize_bar(bar)
        when = normalized["datetime"]
        values = tuple(
            normalized[name] for name in ("open", "high", "low", "close", "volume", "openinterest")
        )
        last = self._last_published_bar
        if last is not None:
            last_when, last_values = last
            if when < last_when:
                return self._drop_bar("late")
            if when == last_when:
                return self._drop_bar("duplicates" if values == last_values else "revisions_refused")
        self._last_published_bar = (when, values)
        self._valuation_bar = (
            date2num(when), normalized["close"], self._get_bucket_end(when), source
        )
        self._record_line_bar_quality(bar, date2num(when), source)
        return self._load_bar(normalized)

    def _record_line_bar_quality(self, bar, line_time, source):
        """Remember the quality of the bar about to be written to the lines."""
        if isinstance(bar, Mapping):
            complete = bar.get("bar_complete")
            volume_complete = bar.get("volume_complete")
            flags = bar.get("quality_flags") or ()
        else:
            complete = getattr(bar, "bar_complete", None)
            volume_complete = getattr(bar, "volume_complete", None)
            flags = getattr(bar, "quality_flags", None) or ()
        flags = tuple(flag for flag in flags if type(flag) is str)
        self._line_bar_quality = (
            line_time,
            FeedLineBarQuality(
                complete=complete if type(complete) is bool else not flags,
                volume_complete=volume_complete if type(volume_complete) is bool else None,
                quality_flags=flags,
                source=source,
            ),
        )

    def line_bar_quality(self):
        """Quality of the bar now at ``[0]`` on this feed's lines (iteration 62).

        Returns a :class:`FeedLineBarQuality`, or ``None`` when no bar was
        published by this feed or the lines no longer hold the bar it
        published last. A bar that entered the lines with incomplete volume
        (``incomplete_volume_bars="lines"``) has ``complete=False``,
        ``volume_complete=False`` and its volume flags in ``quality_flags``;
        the same facts are on its BarEvent in ``notify_bar``.
        """
        record = self._line_bar_quality
        if record is None or len(self) == 0:
            return None
        try:
            on_lines = float(self.lines.datetime[0])
        except (IndexError, TypeError, ValueError):
            return None
        line_time, quality = record
        return quality if on_lines == line_time else None

    #: Upper bound in seconds on how old the close of the current bar may be
    #: for :meth:`valuation_mark`; ``None`` means one bar period plus
    #: ``receive_time_max_age``. A caller may only tighten it.
    valuation_mark_max_age = None

    #: Line sources :meth:`valuation_mark` accepts: a provider bar that the
    #: provider declared final (``bar_final=True``), a bar this feed closed
    #: from typed, quality-checked ticks by the event-time watermark, and,
    #: on a Tick timeframe, one typed tick whose own source and quality made
    #: it bar-eligible. Replayed bars and anything built from legacy
    #: (untyped) ticks are never a live mark.
    valuation_mark_sources = frozenset({"provider_bar", "local_aggregation", "market_tick"})

    def valuation_mark(self, max_age=None):
        """Price on this feed's lines for strategy valuation (iteration 60, 60.11-A5/F6).

        Returns ``(price: Decimal, as_of_utc: datetime, source: str)``.
        ``as_of_utc`` is the provider/exchange event time the price belongs
        to: a bar's close time, or a tick's own event time. Eligible only
        when the value on the lines is the one this feed itself published
        from an accepted source (:attr:`valuation_mark_sources`), its price
        is finite and positive, and ``now - as_of_utc`` (``now`` from this
        feed's injected ``clock`` param, the wall clock otherwise) is neither
        negative beyond ``receive_time_max_age`` nor greater than the
        tighter of :attr:`valuation_mark_max_age` and ``max_age`` seconds.
        Otherwise raises ``ValueError`` whose ``code`` attribute is a finite
        reason; never guesses.
        """
        from decimal import Decimal

        def refuse(code):
            error = ValueError(f"valuation mark unavailable ({code})")
            error.code = code
            raise error

        record = getattr(self, "_valuation_bar", None)
        if record is None or len(self) == 0:
            refuse("MARK_NOT_PUBLISHED")
        line_time, close, close_time, source = record
        try:
            on_lines = float(self.lines.datetime[0])
            line_close = float(self.lines.close[0])
        except (IndexError, TypeError, ValueError):
            refuse("MARK_NOT_PUBLISHED")
        if on_lines != line_time or line_close != close:
            refuse("MARK_NOT_PUBLISHED")  # the lines do not hold the published value
        if source not in self.valuation_mark_sources:
            refuse("MARK_SOURCE_UNTRUSTED")
        price = Decimal(str(close))
        if not price.is_finite() or price <= 0:
            refuse("MARK_PRICE_INVALID")
        if not isinstance(close_time, _dt.datetime):
            refuse("MARK_TIME_UNKNOWN")
        as_of = close_time if close_time.tzinfo else close_time.replace(tzinfo=_UTC)
        limit = self.valuation_mark_max_age
        if limit is None:
            if self._timeframe == TimeFrame.Ticks:
                limit = float(self.p.receive_time_max_age or 0.0)
            else:
                period = (self._get_bucket_end(close_time) - close_time).total_seconds()
                limit = period + float(self.p.receive_time_max_age or 0.0)
        bounds = [limit] if max_age is None else [limit, max_age]
        try:
            bounds = [float(item) for item in bounds]
        except (TypeError, ValueError, OverflowError):
            refuse("MARK_AGE_INVALID")
        if any(type(item) is bool for item in (limit, max_age)) or not all(
            math.isfinite(item) and item >= 0 for item in bounds
        ):
            refuse("MARK_AGE_INVALID")
        now = self._now_wall_ns() / 1_000_000_000
        age = now - as_of.timestamp()
        if age < -float(self.p.receive_time_max_age or 0.0):
            refuse("MARK_FROM_FUTURE")
        if age > min(bounds):
            refuse("MARK_STALE")
        return price, as_of, source

    def _now_wall_ns(self):
        clock = self.p.clock
        for name in ("time_ns", "wall_time_ns"):
            method = getattr(clock, name, None) if clock is not None else None
            if callable(method):
                return int(method())
        for name in ("time", "wall_time"):
            method = getattr(clock, name, None) if clock is not None else None
            if callable(method):
                return int(float(method()) * 1_000_000_000)
        return _time.time_ns()

    def _drop_bar(self, kind) -> bool:
        self._bar_integrity[kind] += 1
        _safe_log("warning", "btapifeed: dropped %s bar for %s", kind, self._dataname)
        return False

    def _load(self) -> bool:
        """Load the next historical or live bar."""
        if self._live_bar_cohort is not None:
            # Only Cerebro may arm the exact envelope after every member has
            # passed preflight.  In particular, do not consume a side queue or
            # sleep from this path while another cohort member is pending.
            return self._load_live_bar_cohort_envelope()

        if self._history and self._load_history():
            return True

        # Preserve the causal pair between a completed bar callback and the
        # matching data-line advance.  Do not consume newer ticks while an
        # already completed bar is waiting for Strategy.next().
        while self._live:
            self._mark_live()
            if self._publish_bar(self._live.popleft()):
                return True

        if self.p.orderbook_as_ticks and not self._uses_sdk_market_streams():
            if self._load_orderbook_tick():
                return True
            if self._qcheck > 0:
                _time.sleep(self._qcheck)
            return None

        drained_ticks = self._drain_live_ticks()
        drained_orderbooks = self._drain_live_orderbooks()
        self._flush_ready_bars(reason="load")
        # If this turn already produced a line bar, deliver it before an EOF
        # watermark is allowed to close the following bucket.
        source_exhausted = False if self._live else self._handle_source_exhaustion()

        if self._live:
            bar = self._live.popleft()
        elif self.store is not None:
            bar = self.store.poll_live(self._dataname)
        else:
            bar = None

        if bar is None:
            if source_exhausted and not self._bar_builders:
                return False
            if drained_ticks or drained_orderbooks:
                self._mark_live()
            if self._qcheck > 0:
                _time.sleep(self._qcheck)
            return None

        self._mark_live()

        return True if self._publish_bar(bar) else None

    def _check(self, forcedata=None):
        """Drain live ticks while waiting for the next completed bar."""
        if self._live_bar_cohort is not None:
            # The cohort runner owns bounded collection and the one shared
            # wait.  Feed._check must not consume events or sleep per member.
            return
        super()._check(forcedata=forcedata)
        if self.p.orderbook_as_ticks and not self._uses_sdk_market_streams():
            return  # _load must establish the feed clock before the callback.
        if self._live:
            return  # _load must pair the queued callback with its line bar.
        # The historical Tick-timeframe check path drains every available tick.
        stop_after_queued_bar = self._timeframe != TimeFrame.Ticks
        drained_ticks = self._drain_live_ticks(stop_after_queued_bar=stop_after_queued_bar)
        drained_orderbooks = self._drain_live_orderbooks()
        self._flush_ready_bars(reason="idle")
        self._handle_source_exhaustion()
        if not self._history and (drained_ticks or drained_orderbooks):
            self._mark_live()

    def _load_orderbook_tick(self):
        """Load one snapshot per turn so neither another venue nor the broker starves."""
        if self.store is None:
            return False
        orderbook = self.store.poll_orderbook(
            self._dataname, depth=self.p.orderbook_depth
        )
        if orderbook is None:
            return False
        if getattr(orderbook, "execution_eligible", None) is False:
            self._handle_event_health(orderbook)
            if self.p.dispatch_orderbooks:
                self._dispatch_event("orderbook", EventPriority.ORDERBOOK, orderbook)
            else:
                self._mark_event_dropped(orderbook, "orderbook_dispatch_disabled")
            return False
        if self._handle_event_health(orderbook):
            if self.p.dispatch_orderbooks:
                self._dispatch_event("orderbook", EventPriority.ORDERBOOK, orderbook)
            else:
                self._mark_event_dropped(orderbook, "orderbook_dispatch_disabled")
            return False
        bids = _tick_value(orderbook, "bids", default=[]) or []
        asks = _tick_value(orderbook, "asks", default=[]) or []
        from bt_api_py.market_stream_contracts import orderbook_midpoint

        midpoint, error = orderbook_midpoint(bids, asks)
        if error is not None:
            self._mark_event_dropped(orderbook, f"orderbook_{error}")
            return False
        stamp = _tick_timestamp(orderbook)
        bar = BarEvent(
            timestamp=stamp,
            symbol=self._dataname,
            exchange=_tick_value(orderbook, "exchange", default=""),
            asset_type=_tick_value(orderbook, "asset_type", default="futures"),
            local_time=_tick_value(orderbook, "local_time", default=stamp),
            **_causal_event_kwargs(orderbook),
            open=midpoint,
            high=midpoint,
            low=midpoint,
            close=midpoint,
            volume=0.0,
        )
        self._load_bar(
            {
                "datetime": _tick_datetime(orderbook),
                "open": midpoint,
                "high": midpoint,
                "low": midpoint,
                "close": midpoint,
                "volume": 0.0,
                "openinterest": 0.0,
            }
        )
        self._mark_live()
        if self.p.dispatch_orderbooks:
            self._dispatch_event("orderbook", EventPriority.ORDERBOOK, orderbook)
        else:
            self._mark_event_dropped(orderbook, "orderbook_dispatch_disabled")
        if self.p.dispatch_bars:
            self._dispatch_event("bar", EventPriority.BAR, bar)
        return True

    def _uses_sdk_market_streams(self) -> bool:
        """Read the Store's explicit stream-mode contract without API probing."""
        return getattr(self.store, "uses_sdk_market_streams", False) is True

    def _load_bar(self, bar) -> bool:
        """Write a normalized bar into line buffers."""
        bar = _normalize_bar(bar)
        self.lines.datetime[0] = date2num(bar["datetime"])
        self.lines.open[0] = bar["open"]
        self.lines.high[0] = bar["high"]
        self.lines.low[0] = bar["low"]
        self.lines.close[0] = bar["close"]
        self.lines.volume[0] = bar["volume"]
        self.lines.openinterest[0] = bar["openinterest"]
        for name in _LIVE_COHORT_EXTRA_LINES:
            getattr(self.lines, name)[0] = math.nan
        return True

    def _drain_live_ticks(
        self,
        limit=None,
        *,
        stop_after_queued_bar=True,
        deadline_ns=None,
        quote_only=False,
    ):
        """Drain available ticks subject to the caller's count and bar bounds.

        Normal load and cohort collection stop after the next queued bar so
        its callback stays paired with the matching line turn.  The legacy
        Tick-timeframe ``_check`` path may opt out of that queued-bar stop.
        Completed aggregate bars still end a drain on every path.  The private
        quote-only mode is reserved for a bounded, already-armed cohort
        winddown: it uses the same source validation and tick dispatch but
        never mutates or closes a bar builder.  Its integer return is the
        number of source ticks consumed; the ordinary path keeps its historic
        boolean return contract.
        """
        if quote_only and self._live_bar_cohort is None:
            raise RuntimeError("quote-only tick drain requires an active live bar cohort")
        if self._replay_tick_adapter is None and (
            self.store is None or not hasattr(self.store, "poll_tick")
        ):
            return 0 if quote_only else False

        drained = False

        drained_count = 0
        while limit is None or drained_count < limit:
            if self._cohort_prepare_deadline_expired(deadline_ns):
                break
            bar_sequence_before = self._bar_sequence
            queued_bars_before = len(self._live)
            try:
                if self._replay_tick_adapter is not None:
                    tick = self._replay_tick_adapter.poll()
                else:
                    tick = self.store.poll_tick(self._dataname)
            except Exception:
                if quote_only:
                    # The cohort cannot be trusted after its bounded quote
                    # source failed. Mark it frozen while preserving the
                    # provider exception and traceback for the caller.
                    self._freeze_cohort_source_state("winddown_quote_poll_failed")
                raise
            self._check_cohort_stream_health()
            if tick is None:
                if self._live_notified and not self._continuity_degraded:
                    self._note_stream_recovery()
                break
            previous_trade_state = self._tick_trade_state
            if self._replay_tick_adapter is None:
                event = tick
                try:
                    if self._live_bar_cohort is not None:
                        # The research cohort keeps its strict source boundary:
                        # an unqualified clock still freezes the epoch.
                        tick = adapt_market_tick_event(event)
                        ingest = qualify_market_tick_event(
                            event, event_time_max_age=self.p.event_time_max_age
                        )
                    else:
                        ingest = ingest_market_tick_event(
                            event, event_time_max_age=self.p.event_time_max_age
                        )
                        tick = ingest.tick
                except MarketTickAdapterError as error:
                    self._freeze_cohort_source_state(error.code)
                    raise
                if ingest.error_code is None:
                    self._tick_trade_state = (ingest.qualification, None)
                elif self._live_bar_cohort is None:
                    # D62-27: no substituted time; drop, count, stay non-tradable.
                    drained_count += 1
                    self._record_tick_ingest_error(event, ingest.error_code)
                    continue
                else:
                    # The cohort's own gates still decide this strict tick.
                    self._tick_trade_state = (self._tick_trade_state[0], ingest.error_code)
            expired_after_poll = self._cohort_prepare_deadline_expired(deadline_ns)
            drained = True
            drained_count += 1
            market_factor_planned_minute = True

            if self._market_factor_source_binding is not None:
                try:
                    projection = self._market_factor_source_projector(
                        self._market_factor_source_binding, tick
                    )
                    cursor_sequence = projection.cursor_sequence
                    if (
                        type(cursor_sequence) is not int
                        or cursor_sequence <= self._market_factor_source_last_cursor_sequence
                    ):
                        raise self._market_factor_source_error_type(
                            "MARKET_FACTOR_SOURCE_SEQUENCE_INVALID"
                        )
                    self._market_factor_source_last_cursor_sequence = cursor_sequence
                except self._market_factor_source_error_type:
                    self._freeze_cohort_source_state("market_factor_source_invalid")
                    raise
                market_factor_planned_minute = projection.planned_close_time is not None
                tick.event_time_utc = projection.event_time_utc
                tick.clock_domain_id = projection.clock_domain_id
                tick.market_factor_calendar_digest = projection.calendar_digest
                tick.market_factor_target_id = self._market_factor_source_binding.target_id
                tick.market_factor_product = (
                    self._market_factor_source_binding.product.exchange_id,
                    self._market_factor_source_binding.product.product_id,
                )
                tick.market_factor_trading_date = projection.trading_date.isoformat()
                tick.market_factor_session_date = projection.session_date.isoformat()
                tick.market_factor_event_session_date = projection.event_session_date.isoformat()
                tick.exchange_id = projection.venue
                tick.exchange_id_source = projection.identity_source
                tick.session_segment = projection.session_segment

            if self._validate_raw_cohort_tick_price(tick) is False:
                self._mark_event_dropped(tick, "invalid_market_tick")
                continue
            self._prepare_tick(
                tick,
                quote_only=quote_only or not market_factor_planned_minute,
            )
            if _tick_value(tick, "event_time_regressed", default=False) is True:
                # D62-38: dropped; the last admitted tick keeps deciding trade
                # qualification (its receipt age keeps growing).
                self._tick_trade_state = previous_trade_state
                self._drop_regressed_tick(tick)
                continue
            expired_after_normalize = self._cohort_prepare_deadline_expired(deadline_ns)

            if self._handle_event_health(tick):
                if self._live_bar_cohort is not None:
                    self._freeze_cohort_source(
                        "unhealthy_source_tick", "unhealthy tick cannot continue a live cohort"
                    )
                if self.p.dispatch_ticks:
                    self._dispatch_event(
                        channel_type="tick",
                        priority=EventPriority.TICK,
                        event_data=tick,
                    )
                else:
                    self._mark_event_dropped(tick, "tick_dispatch_disabled")
                if (
                    expired_after_poll
                    or expired_after_normalize
                    or self._cohort_prepare_deadline_expired(deadline_ns)
                ):
                    break
                continue

            if not quote_only:
                self._record_initial_volume_baseline(tick)

            if self.p.dispatch_ticks:
                self._dispatch_event(
                    channel_type="tick",
                    priority=EventPriority.TICK,
                    event_data=tick,
                )
            else:
                self._mark_event_dropped(tick, "tick_dispatch_disabled")
            if quote_only or not market_factor_planned_minute:
                if (
                    expired_after_poll
                    or expired_after_normalize
                    or self._cohort_prepare_deadline_expired(deadline_ns)
                ):
                    break
                continue
            self._ingest_tick(tick)
            self._flush_ready_bars(reason="tick")
            # _bar_sequence tracks completed aggregate bars. Tick-timeframe
            # bars instead use the queue length; only ordinary _check may
            # preserve its historical all-available-ticks behavior.
            if (
                expired_after_poll
                or expired_after_normalize
                or self._cohort_prepare_deadline_expired(deadline_ns)
            ):
                break
            if self._bar_sequence != bar_sequence_before or (
                stop_after_queued_bar and len(self._live) > queued_bars_before
            ):
                break
        return drained_count if quote_only else drained

    def _record_initial_volume_baseline(self, tick):
        """Handle the bucket of a healthy volume-baseline tick (delta 0, incomplete).

        Such a tick (first after subscribe, reconnect or a trading-day change,
        or a volume reset) carries no volume of its own, so its bucket was only
        partially observed. An ordinary feed builds that bucket and marks it
        ``VOLUME_BASELINE`` (iteration 62 decision 2: it then follows
        ``incomplete_volume_bars``). The live bar cohort keeps skipping the
        first such bucket of a scope (cold start).
        """
        event = getattr(tick, "market_tick_event", None)
        if event is None or self._timeframe == TimeFrame.Ticks:
            return False
        data = event.data
        if data.volume_complete:
            return False
        cohort = self._live_bar_cohort is not None
        continuity = _tick_continuity(tick)
        attested = continuity == "continuous" if cohort else continuity in _ATTESTED_CONTINUITY
        if attested and (data.delta_volume or 0) > 0:
            # Bar-only incomplete volume on an attested stream (2026-11-06,
            # D62-38) is not a cold-start baseline: its bucket is built and marked.
            return False
        moment = getattr(tick, "event_time_utc", None)
        if not isinstance(moment, _dt.datetime) or moment.tzinfo is None:
            return False
        bucket_start = self._get_bucket_start(moment.astimezone(_UTC).replace(tzinfo=None))
        if not cohort:
            self._add_bar_quality_override(bucket_start, "VOLUME_BASELINE")
            return True
        if data.cumulative_volume is None:
            return False
        trading_date = data.trading_date
        if type(trading_date) is not str or not trading_date:
            return False
        scope = (
            data.provider_connection_generation,
            data.provider_subscription_epoch,
            trading_date,
        )
        if self._initial_volume_baseline_scope != scope:
            self._initial_volume_baseline_scope = scope
            self._initial_volume_baseline_start = bucket_start
        elif self._initial_volume_baseline_start is None:
            self._initial_volume_baseline_start = bucket_start
        return True

    def _cohort_drain_winddown_quotes(self, *, limit, deadline_ns):
        """Consume a bounded source-backed quote prefix without bar work."""
        if self._live_bar_cohort is None:
            return 0
        if self._live_bar_cohort.frozen or self._cohort_delivery_failed:
            return 0
        return self._drain_live_ticks(
            limit=limit,
            stop_after_queued_bar=False,
            deadline_ns=deadline_ns,
            quote_only=True,
        )

    def _validate_raw_cohort_tick_price(self, tick):
        """Reject an invalid neutral quote before tolerant line conversion."""
        cohort = self._live_bar_cohort
        if cohort is None:
            return True

        raw_price = _tick_value(tick, "price", "last_price", default=None)
        price = _finite_market_number(raw_price)
        if price is not None and price > 0:
            return True

        member = cohort.member_for_feed(self)
        instrument = member.instrument if member is not None else self._dataname
        report = {
            "source": "BtApiFeed.tick",
            "instrument": _bounded_context_value(instrument),
            "field": "price",
            "category": "missing_or_invalid",
            "generation": _bounded_context_value(
                _tick_value(tick, "connection_generation", default=None)
            ),
            "sequence": _bounded_context_value(
                _tick_value(tick, "sequence", default=None)
            ),
            "reason": "LAST_PRICE_INVALID",
        }
        cohort._freeze("invalid_source_tick_price")
        self._cohort_delivery_failed = True
        from ..research.live_cohort import LiveCohortValidationError

        error = LiveCohortValidationError("tick price rejected: LAST_PRICE_INVALID")
        error.code = "LAST_PRICE_INVALID"
        error.report = MappingProxyType(report)
        raise error

    def _handle_source_exhaustion(self):
        """Finalize an explicitly finite source and report natural EOF.

        Live transports do not expose this contract and therefore continue to
        return ``None`` while idle.  Deterministic replay sources may declare
        both exhaustion and their final event-time watermark.  A missing or
        insufficient watermark invalidates any residual bucket rather than
        promoting a partial bar to executable data.
        """

        store = self.store
        if self._replay_tick_adapter is not None:
            if not self._replay_tick_adapter.exhausted:
                return False
            watermark_dt = self._replay_tick_adapter.final_event_time_watermark_utc
        else:
            exhausted = getattr(store, "is_source_exhausted", None) if store is not None else None
            if not callable(exhausted) or not exhausted(self._dataname):
                return False

            watermark_reader = (
                getattr(store, "get_source_event_time_watermark", None)
                if store is not None
                else None
            )
            watermark = watermark_reader(self._dataname) if callable(watermark_reader) else None
            watermark_dt = _as_utc_datetime(watermark)
        if watermark_dt is not None:
            watermark_ts = watermark_dt.timestamp()
            if self._max_event_timestamp is None or watermark_ts > self._max_event_timestamp:
                self._max_event_timestamp = watermark_ts
                if self._replay_tick_adapter is None:
                    self._last_ingest_monotonic_ns = self._now_monotonic_ns()
            self._flush_ready_bars(reason="source_exhausted")

        if self._bar_builders:
            self._flush_ready_bars(reason="source_exhausted_incomplete", force_invalid=True)
        return True

    def _drain_live_orderbooks(self, limit=None, *, deadline_ns=None):
        if self.store is None or not hasattr(self.store, "poll_orderbook"):
            return False

        drained = False

        drained_count = 0
        while limit is None or drained_count < limit:
            if self._cohort_prepare_deadline_expired(deadline_ns):
                break
            orderbook = self.store.poll_orderbook(
                self._dataname, depth=self.p.orderbook_depth
            )
            if orderbook is None:
                break
            expired_after_poll = self._cohort_prepare_deadline_expired(deadline_ns)
            observer_only = getattr(orderbook, "execution_eligible", None) is False
            drained = drained or not observer_only
            drained_count += 1

            self._handle_event_health(orderbook)

            if self.p.dispatch_orderbooks:
                self._dispatch_event(
                    channel_type="orderbook",
                    priority=EventPriority.ORDERBOOK,
                    event_data=orderbook,
                )
            else:
                self._mark_event_dropped(orderbook, "orderbook_dispatch_disabled")
            if expired_after_poll or self._cohort_prepare_deadline_expired(deadline_ns):
                break
        return drained

    def _ingest_tick(self, tick):
        """Update the current bar builder from a live tick."""
        tick_dt = _tick_datetime(tick)
        tick_ts = _tick_timestamp(tick)

        bucket_start = None
        market_tick_event = getattr(tick, "market_tick_event", None)
        if market_tick_event is not None and self._timeframe != TimeFrame.Ticks:
            data = market_tick_event.data
            scope = (
                data.provider_connection_generation,
                data.provider_subscription_epoch,
                data.trading_date,
            )
            bucket_start = self._get_bucket_start(tick_dt)
            if (
                scope == self._initial_volume_baseline_scope
                and bucket_start == self._initial_volume_baseline_start
            ):
                # The SDK's neutral volume contract marks an incomplete
                # baseline explicitly. Skip only that partially observed
                # bucket; do not re-difference cumulative volume in Backtrader.
                cohort = self._live_bar_cohort
                if cohort is not None:
                    bucket_end = self._get_bucket_end(bucket_start)
                    if isinstance(bucket_end, _dt.datetime):
                        cohort.note_cold_start_skipped_slot(
                            bucket_end.replace(tzinfo=_UTC)
                        )
                return

        price = _finite_market_number(
            _tick_value(tick, "price", "last_price", default=None)
        )
        if price is None or price <= 0 or not bool(_tick_value(tick, "bar_eligible", default=False)):
            return

        volume = _finite_market_number(
            _tick_value(tick, "delta_volume", "volume", default=0.0)
        )
        if volume is None or volume <= 0:
            return
        openinterest = _finite_market_number(
            _tick_value(tick, "openinterest", "open_interest", default=0.0)
        )
        openinterest = max(openinterest or 0.0, 0.0)

        if self._timeframe == TimeFrame.Ticks:
            tick_bar = BarEvent(
                timestamp=tick_ts,
                symbol=self._dataname,
                exchange=_tick_value(tick, "exchange", "exchange_id", default=""),
                asset_type=_tick_value(tick, "asset_type", default="futures"),
                local_time=_tick_value(tick, "local_time", default=None),
                **_causal_event_kwargs(tick),
                open=price,
                high=price,
                low=price,
                close=price,
                volume=volume,
                openinterest=openinterest,
            )
            trade_flags = _trade_only_flags(tick)
            if trade_flags:
                tick_bar.trade_qualification_flags = tuple(sorted(trade_flags))
            warnings = _quote_warning_flags(tick)
            if warnings:
                tick_bar.quality_warnings = tuple(sorted(warnings))
            self._enqueue_bar_event(tick_bar, tick_dt, bar_source=_tick_mark_source(tick))
            return

        if bucket_start is None:  # same tick_dt: computed above for SDK ticks
            bucket_start = self._get_bucket_start(tick_dt)
        current = self._bar_builders.get(bucket_start)
        if current is None:
            current = self._new_bar_builder(bucket_start, tick, price, volume, openinterest)
            self._capture_quote(current, tick)
            self._bar_builders[bucket_start] = current
            self._bar_builders.move_to_end(bucket_start)
            self._bar_builder = current
            return

        if bucket_start == current["bucket_start"]:
            current["high"] = max(current["high"], price)
            current["low"] = min(current["low"], price)
            current["close"] = price
            current["volume"] += volume
            current["openinterest"] = openinterest
            current["last_timestamp"] = tick_ts
            current["last_ingest_seq"] = _tick_value(
                tick, "ingest_seq", "sequence", default=current["last_ingest_seq"]
            )
            if current.get("source_mode") in {"replay", "synthetic"}:
                current["last_replay_sequence"] = _tick_value(
                    tick, "replay_sequence", default=current["last_replay_sequence"]
                )
            current["trade_count"] += 1
            for field, aliases, mismatch_flag in (
                ("rules_hash", ("rules_hash",), "RULES_HASH_CHANGED"),
                ("session_segment", ("session_segment",), "SESSION_SEGMENT_CHANGED"),
                ("trading_day", ("trading_day", "trading_date"), "TRADING_DAY_CHANGED"),
            ):
                value = _tick_value(tick, *aliases, default=current[field])
                if value != current[field]:
                    current["quality_flags"].add(mismatch_flag)
            resolved_event_session_date = _tick_value(
                tick, "market_factor_event_session_date", default=None
            )
            if (
                current["event_session_date"] is not None
                and resolved_event_session_date != current["event_session_date"]
            ):
                # A bar spanning distinct or unresolved event dates has no
                # single resolver-backed session date.
                current["event_session_date"] = None
                current["market_factor_event_session_date"] = None
                current["quality_flags"].add("EVENT_SESSION_DATE_NOT_UNIFORM")
            current["quality_flags"].update(_data_quality_flags(tick))
            current["trade_qualification_flags"].update(_trade_only_flags(tick))
            current["quality_warnings"].update(_quote_warning_flags(tick))
            self._capture_quote(current, tick)
            return

    def _new_bar_builder(self, bucket_start, tick, price, volume, openinterest):
        """Create the mutable state for an in-progress aggregated bar."""
        ingest_seq = _tick_value(tick, "ingest_seq", "sequence", default=0)
        replay_mode = _tick_value(tick, "source_mode", default=None)
        replay_sequence = _tick_value(tick, "replay_sequence", default=None)
        replay = replay_mode in {"replay", "synthetic"}
        builder = {
            "bucket_start": bucket_start,
            "bucket_end": self._get_bucket_end(bucket_start),
            "open": price,
            "high": price,
            "low": price,
            "close": price,
            "volume": volume,
            "openinterest": openinterest,
            "last_timestamp": _tick_timestamp(tick),
            "causal": _causal_event_kwargs(tick),
            "exchange": _tick_value(tick, "exchange", "exchange_id", default=""),
            "asset_type": _tick_value(tick, "asset_type", default="futures"),
            "trading_day": _tick_value(tick, "trading_day", "trading_date", default=""),
            "quote_events": [],
            "action_day": _tick_value(tick, "action_day", "event_session_date", default=""),
            # This is populated only by the exact-event SDK session resolver
            # projection above; provider event-date claims alone are not enough.
            "event_session_date": _tick_value(
                tick, "market_factor_event_session_date", default=None
            ),
            "rules_hash": _tick_value(tick, "quality_contract_ref", default=None),
            "session_segment": _tick_value(tick, "session_segment", default=None),
            "clock_domain_id": _tick_value(tick, "clock_domain_id", default=None),
            "market_factor_calendar_digest": _tick_value(
                tick, "market_factor_calendar_digest", default=None
            ),
            "market_factor_target_id": _tick_value(
                tick, "market_factor_target_id", default=None
            ),
            "market_factor_product": _tick_value(
                tick, "market_factor_product", default=None
            ),
            "market_factor_trading_date": _tick_value(
                tick, "market_factor_trading_date", default=None
            ),
            "market_factor_session_date": _tick_value(
                tick, "market_factor_session_date", default=None
            ),
            "market_factor_event_session_date": _tick_value(
                tick, "market_factor_event_session_date", default=None
            ),
            "exchange_id_source": _tick_value(tick, "exchange_id_source", default=None),
            "connection_generation": _tick_value(
                tick, "connection_generation", default=None
            ),
            "first_ingest_seq": ingest_seq,
            "last_ingest_seq": ingest_seq,
            "trade_count": 1,
            "volume_complete": bool(_tick_value(tick, "volume_complete", default=False)),
            "quality_flags": set(_data_quality_flags(tick)),
            # Trade-only flags never make a bar incomplete; they mark it as
            # built from at least one tick that was not trade-qualified.
            "trade_qualification_flags": set(_trade_only_flags(tick)),
            # Quote-shape warnings (D62-38) never make a bar incomplete.
            "quality_warnings": set(_quote_warning_flags(tick)),
        }
        if replay:
            # Replay-local identity is intentionally disjoint from live stream
            # generation and provider ingress sequence fields.
            builder.update(
                {
                    "source_mode": replay_mode,
                    "replay_source_ref": _tick_value(tick, "replay_source_ref", default=""),
                    "replay_epoch": _tick_value(tick, "replay_epoch", default=""),
                    "first_replay_sequence": replay_sequence,
                    "last_replay_sequence": replay_sequence,
                    "connection_generation": None,
                    "first_ingest_seq": None,
                    "last_ingest_seq": None,
                }
            )
        return builder

    def _capture_quote(self, builder, tick):
        """Freeze one prepared tick into the bucket's bounded quote window."""
        if not bool(self.p.closed_bar_quote_capture):
            return
        mapping = self._quote_capture_mapping(tick)
        if mapping is None:
            return
        events = builder.get("quote_events")
        if events is None:
            events = builder["quote_events"] = []
        limit = int(self.p.closed_bar_quote_limit or 0)
        if limit > 0 and len(events) >= limit:
            builder["quality_flags"].add("QUOTE_CAPTURE_OVERFLOW")
            events.pop(0)
        events.append(mapping)

    def _evidence_symbol(self):
        """Return the display identity used by legacy bars and quote evidence.

        ``dataname`` remains the provider subscription key.  Cerebro's
        explicit feed name is preserved for ordinary display and quote-window
        records when present.  Cohort bars use the exact source route instead.
        """
        name = getattr(self, "_name", None)
        return name if isinstance(name, str) and name else self._dataname

    def _completed_bar_symbol(self):
        """Use the exact provider route for cohort bars, display name otherwise."""
        if self._live_bar_cohort is not None:
            return self._dataname
        return self._evidence_symbol()

    def _quote_capture_mapping(self, tick):
        """Project the tick with this Feed's configured display identity."""
        from bt_api_py.market_tick_contracts import quote_capture_mapping

        return quote_capture_mapping(tick, symbol=self._evidence_symbol())

    def _attach_closed_bar_evidence(self, bar_event):
        """Attach only a scope-consistent caller-produced BarEvidence object.

        The adapter receives a detached snapshot after the Feed has frozen
        its closed-bar metadata but before the channel callback.  Validation
        remains against the Feed-owned event, so a provider cannot mutate its
        input and make a forged result appear scope-consistent.  The hand-off
        stays narrow: unlike a strategy it cannot reconstruct evidence from
        mutable line buffers, and unlike the Feed it cannot invent a clock
        mapping or candidate identity.
        """

        provider = self.p.closed_bar_evidence_provider
        if provider is None:
            return
        provider_input = SimpleNamespace(**copy.deepcopy(vars(bar_event)))
        evidence = provider(provider_input)
        if not isinstance(evidence, BarEvidence):
            raise ValueError("closed_bar_evidence_provider must return BarEvidence")
        if evidence.symbol != bar_event.symbol or evidence.exchange != bar_event.exchange:
            raise ValueError("closed BarEvidence identity does not match BarEvent")
        for name in (
            "bucket_start",
            "bucket_end",
            "available_at",
            "trading_day",
            "connection_generation",
            "rules_hash",
            "session_segment",
            "first_ingest_seq",
            "last_ingest_seq",
            "quote_cutoff_seq",
            "bar_id",
            "bar_sequence",
            "complete",
        ):
            event_name = "generation" if name == "connection_generation" else name
            if getattr(evidence, event_name) != getattr(bar_event, name):
                raise ValueError(f"closed BarEvidence {event_name} does not match BarEvent")
        for name in ("quality", "volume_complete", "closure_reason", "trade_count", "watermark"):
            if getattr(evidence, name) != getattr(bar_event, name):
                raise ValueError(f"closed BarEvidence {name} does not match BarEvent")
        if evidence.max_event_time != getattr(bar_event, "max_event_time"):
            raise ValueError("closed BarEvidence max_event_time does not match BarEvent")
        for name in ("open", "high", "low", "close", "volume", "openinterest"):
            if getattr(evidence, name) != float(getattr(bar_event, name)):
                raise ValueError(f"closed BarEvidence {name} does not match BarEvent")
        if evidence.clock_domain != getattr(bar_event, "clock_domain_id", None):
            raise ValueError("closed BarEvidence clock domain does not match BarEvent")
        setattr(bar_event, "closed_bar_evidence", evidence)

    def _has_sealed_closed_bar_evidence(self, bar_event, evidence):
        """Return whether this exact event/evidence pair is still in dispatch."""

        return self._sealed_closed_bar_evidence_by_event_id.get(id(bar_event)) is evidence

    def _enqueue_bar_event(self, bar_event, bar_datetime, *, deliver_lines=True, bar_source=None):
        """Queue a completed bar for both notify_bar and line delivery.

        ``bar_source`` names where the line value came from, for
        :meth:`valuation_mark`; by default it is derived from the event:
        replayed bars are ``replay``, local bars built from any legacy
        (untyped) tick are ``local_aggregation_legacy``, otherwise
        ``local_aggregation``.
        """
        if bar_source is None:
            bar_source = _local_bar_source(bar_event)
        if self._live_bar_cohort is not None:
            if self._cohort_completed_lookahead is not _COHORT_MISSING:
                self._live_bar_cohort._freeze("feed_completed_bar_queue_overflow")
                self._cohort_delivery_failed = True
                raise RuntimeError("BtApiFeed completed-bar lookahead is full")
            # Preserve the provider/feed-produced event intact.  Validation,
            # line delivery, and notify_bar are deferred to the batch barrier.
            self._cohort_completed_lookahead = bar_event
            return
        bar_event.datetime = bar_datetime
        if self.p.dispatch_bars:
            self._dispatch_event(
                channel_type="bar",
                priority=EventPriority.BAR,
                event_data=bar_event,
            )
        if deliver_lines:
            self._live.append(
                {
                    "datetime": bar_datetime,
                    "open": bar_event.open,
                    "high": bar_event.high,
                    "low": bar_event.low,
                    "close": bar_event.close,
                    "volume": bar_event.volume,
                    "openinterest": bar_event.openinterest,
                    # This path receives only the local aggregation's line-
                    # eligible closure (or an individual tick event).
                    "bar_final": True,
                    "bar_source": bar_source,
                    # Read back by line_bar_quality() once on the lines.
                    "bar_complete": getattr(bar_event, "complete", None),
                    "volume_complete": getattr(bar_event, "volume_complete", None),
                    "quality_flags": tuple(getattr(bar_event, "quality_flags", None) or ()),
                }
            )

    def _now_monotonic_ns(self):
        clock = self.p.clock
        if clock is None:
            return _time.monotonic_ns()
        method = getattr(clock, "monotonic_ns", None) if clock is not None else None
        if callable(method):
            return int(method())
        method = getattr(clock, "monotonic_now", None) if clock is not None else None
        if callable(method):
            return int(float(method()) * 1_000_000_000)
        method = getattr(clock, "monotonic", None) if clock is not None else None
        if callable(method):
            return int(float(method()) * 1_000_000_000)
        return _time.monotonic_ns()

    def _event_time_watermark(self):
        if self._max_event_timestamp is None:
            return None
        if self._replay_tick_adapter is not None:
            # Replay advances only from the next recorded event or the source's
            # explicit final watermark. Host idle time must not move its clock.
            return self._max_event_timestamp
        elapsed = 0.0
        if self._last_ingest_monotonic_ns is not None:
            elapsed = (
                max(
                    self._now_monotonic_ns() - self._last_ingest_monotonic_ns,
                    0,
                )
                / 1_000_000_000.0
            )
        return self._max_event_timestamp + elapsed

    def _cached_price_tick(self):
        configured = _finite_market_number(self.p.price_tick)
        if configured is not None and configured > 0:
            return configured
        store = self.store
        metadata = getattr(store, "contract_metadata", {}) if store is not None else {}
        from bt_api_py.instrument_metadata_aliases import configured_metadata_price_tick

        return configured_metadata_price_tick(
            metadata, self._dataname, finite_number=_finite_market_number,
        )

    @staticmethod
    def _on_price_grid(value, price_tick):
        if value is None or price_tick is None:
            return True
        scaled = value / price_tick
        return math.isfinite(scaled) and abs(scaled - round(scaled)) <= 1e-8

    def _add_bar_quality_override(self, bucket_start, *flags):
        """Retain blocking evidence only while its minute can still be built."""
        if bucket_start is None:
            return
        bucket_end = self._get_bucket_end(bucket_start)
        if self._last_closed_bucket_end is not None and bucket_end <= self._last_closed_bucket_end:
            return
        self._bar_quality_overrides[bucket_start].update(flag for flag in flags if flag)

    def _prune_bar_quality_overrides(self, watermark=None):
        """Discard override-only buckets after their watermark can no longer admit data."""
        if not self._bar_quality_overrides:
            return
        watermark = self._event_time_watermark() if watermark is None else watermark
        watermark_delay = max(float(self.p.bar_watermark_ms or 0.0), 0.0) / 1000.0
        for bucket_start in list(self._bar_quality_overrides):
            if bucket_start in self._bar_builders:
                continue
            bucket_end = self._get_bucket_end(bucket_start)
            already_closed = (
                self._last_closed_bucket_end is not None
                and bucket_end <= self._last_closed_bucket_end
            )
            deadline = bucket_end.replace(tzinfo=_UTC).timestamp() + watermark_delay
            if already_closed or (watermark is not None and deadline <= watermark):
                self._bar_quality_overrides.pop(bucket_start, None)

    def _prepare_tick(self, tick, *, quote_only=False):
        """Normalize one tick's schema, quality, ordering and volume semantics."""
        from bt_api_py.market_tick_contracts import (
            classify_market_scope,
            prepare_market_tick_fields,
            prepare_market_tick_timing,
        )

        (
            typed_market_tick, replay_market_tick, replay_binding_invalid, flags, delta,
            price, bid, ask, bid_size, ask_size,
        ) = prepare_market_tick_fields(
            tick, replay_adapter_available=self._replay_tick_adapter is not None,
            legacy_schema="backtrader.tick.v1",
        )
        # The research cohort keeps its strict source boundary: every flag
        # that blocked before D62-38 still blocks there.
        relaxed = self._live_bar_cohort is None
        locked = None
        if typed_market_tick and relaxed:
            locked = _limit_locked_side(tick, price, bid, ask, bid_size, ask_size)
            if locked is not None:
                # D62-38 (decision 6b): a one-sided book at this snapshot's own
                # limit price is a valid quote; the empty side is not invalid.
                # A crossed-book flag there compares against the empty side's
                # transported 0.0 (CTP's DBL_MAX sentinel), not a real price.
                flags.discard("ASK_PRICE_INVALID" if locked == "UP" else "BID_PRICE_INVALID")
                flags.discard("CROSSED_BOOK")
                flags.add("LIMIT_LOCKED_" + locked)

        price_tick = self._cached_price_tick()
        if typed_market_tick and price_tick is None:
            flags.add("PRICE_TICK_UNKNOWN")
        elif price_tick is not None:
            for name, value in (("LAST", price), ("BID", bid), ("ASK", ask)):
                if value is not None and value > 0 and not self._on_price_grid(value, price_tick):
                    flags.add(f"{name}_PRICE_OFF_GRID")

        upstream_execution_eligible = _tick_value(
            tick,
            "execution_eligible",
            default=None,
        )
        separate_trade_qualification = typed_market_tick and _separates_trade_qualification(tick)
        if separate_trade_qualification:
            # Receipt-time trade qualification stays visible on the tick and
            # keeps it non-executable; it is not a data-integrity defect.
            flags.update(_tick_value(tick, "qualification_reasons", default=()) or ())
        if typed_market_tick:
            # ``BtApiFeed`` is a consumer-side quality boundary, not an
            # authority that may promote a hand-built or incomplete V2 quote.
            # The SDK/Store must explicitly attest the upstream decision; this
            # Feed only keeps it false when any local gate also fails.
            from bt_api_py.market_tick_contracts import market_execution_evidence_flags

            flags.update(market_execution_evidence_flags(
                execution_eligible=upstream_execution_eligible,
                source_clock_quality=_tick_value(tick, "source_clock_quality", default=""),
                receive_clock_quality=_tick_value(tick, "receive_clock_quality", default=""),
                freshness_verified=_tick_value(tick, "freshness_verified", default=False),
                stale=_tick_value(tick, "stale", default=None),
                stale_reason=_tick_value(tick, "stale_reason", default=None),
            ))
        event_dt, tick_ts, timing_flags = prepare_market_tick_timing(
            tick,
            typed_market_tick=typed_market_tick,
            now_monotonic_ns=self._now_monotonic_ns,
            event_time_max_age=lambda: self.p.event_time_max_age,
            receive_time_max_age=lambda: self.p.receive_time_max_age,
        )
        flags.update(timing_flags)
        prior_watermark = self._event_time_watermark()
        bucket_start = (
            self._get_bucket_start(event_dt.replace(tzinfo=None)) if event_dt is not None else None
        )
        bucket_end = self._get_bucket_end(bucket_start) if bucket_start is not None else None
        bucket_end_ts = (
            bucket_end.replace(tzinfo=_UTC).timestamp() if bucket_end is not None else None
        )
        watermark_delay = max(float(self.p.bar_watermark_ms or 0.0), 0.0) / 1000.0
        # The exchange event time went backwards (also when the tick is late).
        regressed = (
            self._max_event_timestamp is not None
            and tick_ts is not None
            and tick_ts < self._max_event_timestamp
        )
        if (
            self._timeframe != TimeFrame.Ticks
            and prior_watermark is not None
            and bucket_end_ts is not None
            and bucket_end_ts + watermark_delay <= prior_watermark
        ):
            flags.add("LATE_AFTER_WATERMARK")
        elif (
            self._max_event_timestamp is not None
            and tick_ts is not None
            and tick_ts < self._max_event_timestamp
        ):
            flags.add("OUT_OF_ORDER_EVENT_TIME")
            if delta > 0:
                flags.add("ORDERING_VOLUME_GAP")
                if bucket_start is not None and not quote_only:
                    self._add_bar_quality_override(bucket_start, "ORDERING_VOLUME_GAP")
                current_start = self._get_bucket_start(
                    _dt.datetime.fromtimestamp(self._max_event_timestamp, _UTC).replace(tzinfo=None)
                )
                if not quote_only:
                    self._add_bar_quality_override(current_start, "ORDERING_VOLUME_GAP")

        generation = _tick_value(tick, "connection_generation", default=None)
        subscription_epoch = _tick_value(tick, "subscription_epoch", default=None)
        scope, retired_market_scope, scope_flag, advance_generation = classify_market_scope(
            typed_market_tick=typed_market_tick,
            generation=generation,
            subscription_epoch=subscription_epoch,
            highest_scope=self._highest_market_scope,
            last_generation=self._last_connection_generation,
        )
        if scope_flag in {"MARKET_SCOPE_INVALID", "RETIRED_CONNECTION_SCOPE"}:
            flags.add(scope_flag)
        elif scope_flag is not None:
            if not quote_only:
                for builder in self._bar_builders.values():
                    builder["quality_flags"].add(scope_flag)
                self._flush_ready_bars(
                    reason=(
                        "generation"
                        if scope_flag == "CONNECTION_GENERATION_CHANGED"
                        else "subscription_epoch"
                    ),
                    force_invalid=True,
                )
            self._max_event_timestamp = None
            flags.add(scope_flag)
            if not quote_only:
                self._add_bar_quality_override(bucket_start, scope_flag)
        if advance_generation:
            if typed_market_tick:
                self._highest_market_scope = scope
                self._last_market_scope = scope
            self._last_connection_generation = generation

        if (
            self._timeframe != TimeFrame.Ticks
            and bucket_end is not None
            and self._last_closed_bucket_end is not None
            and bucket_end <= self._last_closed_bucket_end
        ):
            flags.add("BUCKET_ALREADY_CLOSED")

        # D62-38 (user decision 2026-11-06): one tick whose exchange time went
        # backwards (e.g. a front re-delivering an older snapshot) is dropped
        # by the caller without degrading the feed. ``event_time_regression_
        # limit`` consecutive ones are a sustained clock problem: from then on
        # each degrades the feed as before, until a tick that is not behind.
        # Live Store ticks only; the cohort and replay keep the old handling.
        drop_regressed = False
        if scope_flag is not None and scope_flag not in {
            "MARKET_SCOPE_INVALID",
            "RETIRED_CONNECTION_SCOPE",
        }:
            self._event_time_regression_run = 0  # a newer scope starts a new timeline
        if regressed and relaxed and self._replay_tick_adapter is None:
            self._event_time_regression_run += 1
            if self._event_time_regression_run < self._event_time_regression_limit:
                drop_regressed = True
            else:
                flags.add("OUT_OF_ORDER_EVENT_TIME")
        elif tick_ts is not None and not regressed:
            self._event_time_regression_run = 0

        if (
            tick_ts is not None
            and "EVENT_TIME_CONFLICT" not in flags
            and not retired_market_scope
            and not drop_regressed
        ):
            if self._max_event_timestamp is None or tick_ts >= self._max_event_timestamp:
                self._max_event_timestamp = tick_ts
            if not replay_market_tick:
                self._last_ingest_monotonic_ns = self._now_monotonic_ns()

        blocking = {
            flag
            for flag in flags
            if flag
            not in {
                "LEGACY_SCHEMA",
                "NO_TRADE",
                "VOLUME_BASELINE",
            }
        }
        volume_complete = bool(_tick_value(tick, "volume_complete", default=False))
        if typed_market_tick and not volume_complete and delta == 0:
            flags.add("VOLUME_BASELINE")
        if typed_market_tick and not volume_complete and delta > 0:
            flags.add("VOLUME_INCOMPLETE")
            blocking.add("VOLUME_INCOMPLETE")
        # D62-38 (user decisions 2026-11-06): volume accounting is a bar-only
        # flag whenever the provider attests the current connection without
        # local loss (an OKX/Binance trade-id jump, a CTP baseline or volume
        # reset): the tick stays healthy and tradable, enters its bar with its
        # own size, and that bar is marked. Gap/unknown continuity still blocks.
        # The cohort keeps the narrower 2026-11-06 rule (``continuous`` only).
        continuity = _tick_continuity(tick)
        strict_volume = getattr(self, "_strict_volume_continuity", False)
        if strict_volume and typed_market_tick and not volume_complete and delta == 0:
            # Strict mode (decision 3): the volume baseline blocks too.
            blocking.add("VOLUME_BASELINE")
        volume_flags = blocking & _VOLUME_ACCOUNTING_TICK_FLAGS
        if volume_flags and not strict_volume and (
            continuity in _ATTESTED_CONTINUITY if relaxed else continuity == "continuous"
        ):
            blocking -= volume_flags
            if bucket_start is not None and not quote_only:
                self._add_bar_quality_override(bucket_start, *sorted(volume_flags))
        # Bar-construction flags keep the tick out of its bar only.
        bar_only = blocking & _BAR_CONSTRUCTION_TICK_FLAGS if relaxed else frozenset()
        if relaxed:
            # Quote-shape warnings never block (D62-38 decision 6b).
            blocking -= _QUOTE_WARNING_TICK_FLAGS
            blocking -= bar_only
        # D62-27: on the qualification-separating path only data-integrity
        # flags stop bar building; every blocking flag still stops execution.
        data_blocking = (
            blocking - _TRADE_ONLY_TICK_FLAGS if separate_trade_qualification else blocking
        )
        # A rejected snapshot can still prove that an already-open bucket is
        # incomplete. Preserve that evidence before _ingest_tick declines to
        # mutate OHLCV. Otherwise a later watermark could publish the earlier
        # trades as a deceptively complete bar after a volume/order/time gap.
        if (
            bucket_start is not None
            and (data_blocking or bar_only)
            and not quote_only
            and not drop_regressed  # its lost volume is marked ORDERING_VOLUME_GAP
        ):
            already_closed = (
                self._last_closed_bucket_end is not None
                and bucket_end is not None
                and bucket_end <= self._last_closed_bucket_end
            )
            if not already_closed:
                self._add_bar_quality_override(bucket_start, *data_blocking, *bar_only)
        execution_eligible = (
            (
                not replay_market_tick
                and (not typed_market_tick or upstream_execution_eligible is True)
            )
            and not blocking
            and all(
                value is not None and value > 0
                for value in (
                    # A verified limit lock needs only its quoting side (D62-38).
                    (bid, bid_size)
                    if locked == "UP"
                    else (ask, ask_size) if locked == "DOWN" else (bid, ask, bid_size, ask_size)
                )
            )
        )
        bar_eligible = (
            not data_blocking and not bar_only and price is not None and price > 0 and delta > 0
        )
        _set_tick_value(tick, "quality_flags", tuple(sorted(flags)))
        _set_tick_value(
            tick,
            "quality",
            "REPLAY_ONLY" if replay_market_tick else ("GOOD" if not blocking else "INVALID"),
        )
        if separate_trade_qualification:
            _set_tick_value(tick, "data_quality", "GOOD" if not data_blocking else "INVALID")
        _set_tick_value(tick, "execution_eligible", execution_eligible)
        _set_tick_value(tick, "bar_eligible", bar_eligible and not replay_binding_invalid)
        if drop_regressed:
            _set_tick_value(tick, "event_time_regressed", True)
            _set_tick_value(tick, "bar_eligible", False)
        if not quote_only:
            self._prune_bar_quality_overrides()

    def _flush_ready_bars(self, *, reason, force_invalid=False):
        """Close trade-backed buckets once the event-time watermark has passed."""
        watermark = self._event_time_watermark()
        if not self._bar_builders:
            self._prune_bar_quality_overrides(watermark)
            return 0
        watermark_delay = max(float(self.p.bar_watermark_ms or 0.0), 0.0) / 1000.0
        closed = 0
        for bucket_start in sorted(self._bar_builders):
            current = self._bar_builders[bucket_start]
            bucket_end = current["bucket_end"]
            deadline = bucket_end.replace(tzinfo=_UTC).timestamp() + watermark_delay
            if not force_invalid and (watermark is None or watermark < deadline):
                continue
            flags = set(current["quality_flags"])
            flags.update(self._bar_quality_overrides.pop(bucket_start, set()))
            if force_invalid:
                flags.add("FORCED_INVALIDATION")
            complete = bool(current["volume_complete"] and not flags.difference({"LEGACY_SCHEMA"}))
            # Decision 2: volume accounting is the only defect (explicitly
            # flagged; a forced invalidation adds FORCED_INVALIDATION).
            volume_only = bool(not complete and flags and flags <= _VOLUME_INCOMPLETE_BAR_FLAGS)
            available_ts = max(deadline, watermark or deadline)
            available_at = _dt.datetime.fromtimestamp(available_ts, _UTC)
            self._bar_sequence += 1
            first_seq = current["first_ingest_seq"]
            last_seq = current["last_ingest_seq"]
            generation = current["connection_generation"]
            replay = current.get("source_mode") in {"replay", "synthetic"}
            if replay:
                from .replay_market_adapter import ReplayBarEvent

                replay_first = current["first_replay_sequence"]
                replay_last = current["last_replay_sequence"]
                replay_source_ref = current["replay_source_ref"]
                replay_epoch = current["replay_epoch"]
                completed = ReplayBarEvent(
                    timestamp=bucket_end.replace(tzinfo=_UTC).timestamp(),
                    symbol=self._completed_bar_symbol(),
                    exchange=current["exchange"],
                    venue=current["exchange"],
                    asset_type=current["asset_type"],
                    source_mode=current["source_mode"],
                    replay_source_ref=replay_source_ref,
                    replay_epoch=replay_epoch,
                    replay_bar_sequence=self._bar_sequence,
                    first_replay_sequence=replay_first,
                    last_replay_sequence=replay_last,
                    replay_bucket_start=bucket_start.replace(tzinfo=_UTC),
                    replay_bucket_end=bucket_end.replace(tzinfo=_UTC),
                    replay_available_at=available_at,
                    replay_bar_status=(
                        "fixture_projection" if complete else "incomplete_projection"
                    ),
                    replay_close_reason=(
                        "event_time_watermark" if reason in {"tick", "load", "idle"} else reason
                    ),
                    trading_day=str(current["trading_day"] or ""),
                    event_session_date=str(current["action_day"] or ""),
                    open=current["open"],
                    high=current["high"],
                    low=current["low"],
                    close=current["close"],
                    volume=current["volume"],
                    openinterest=current["openinterest"],
                    replay_volume_complete=bool(current["volume_complete"]),
                    replay_quality_flags=tuple(sorted(flags)),
                    replay_bar_id=(
                        f"{replay_source_ref}:{replay_epoch}:{self._dataname}:"
                        f"{bucket_start.isoformat()}:{replay_first}-{replay_last}"
                    ),
                )
            else:
                bar_id = (
                    f"{self._dataname}:{bucket_start.isoformat()}:{generation}:"
                    f"{first_seq}-{last_seq}"
                )
                completed = BarEvent(
                    timestamp=bucket_end.replace(tzinfo=_UTC).timestamp(),
                    symbol=self._completed_bar_symbol(),
                    exchange=current["exchange"],
                    asset_type=current["asset_type"],
                    local_time=available_ts,
                    **current["causal"],
                    open=current["open"],
                    high=current["high"],
                    low=current["low"],
                    close=current["close"],
                    volume=current["volume"],
                    openinterest=current["openinterest"],
                )
                extensions = {
                    "bucket_start": bucket_start.replace(tzinfo=_UTC),
                    "bucket_end": bucket_end.replace(tzinfo=_UTC),
                    "closed_at": available_at,
                    "available_at": available_at,
                    "bar_available_at": available_at,
                    "complete": complete,
                    "quality": "GOOD" if complete else "INVALID",
                    "quality_flags": tuple(sorted(flags)),
                    # False also when a later tick or override flagged volume.
                    "volume_complete": bool(
                        current["volume_complete"] and not flags & _VOLUME_INCOMPLETE_BAR_FLAGS
                    ),
                    "first_ingest_seq": first_seq,
                    "last_ingest_seq": last_seq,
                    "quote_cutoff_seq": last_seq,
                    "trading_day": current["trading_day"],
                    "action_day": current["action_day"],
                    "event_session_date": current["event_session_date"],
                    "rules_hash": current["rules_hash"],
                    "session_segment": current["session_segment"],
                    "connection_generation": generation,
                    "bar_id": bar_id,
                    "decision_version": bar_id,
                    "closure_reason": reason,
                    "bar_sequence": self._bar_sequence,
                    "trade_count": current["trade_count"],
                    "watermark": _dt.datetime.fromtimestamp(watermark or available_ts, _UTC),
                    "max_event_time": _dt.datetime.fromtimestamp(current["last_timestamp"], _UTC),
                }
                if bool(self.p.closed_bar_quote_capture):
                    extensions["quote_events"] = tuple(current.get("quote_events") or ())
                trade_flags = current.get("trade_qualification_flags")
                if trade_flags:
                    # Present only when some tick in the bucket was not
                    # trade-qualified; the bar's data quality is unaffected.
                    extensions["trade_qualification_flags"] = tuple(sorted(trade_flags))
                warnings = current.get("quality_warnings")
                if warnings:
                    # Present only when some tick in the bucket had a valid but
                    # unusual quote shape (D62-38); the bar stays complete.
                    extensions["quality_warnings"] = tuple(sorted(warnings))
                for name in (
                    "clock_domain_id",
                    "market_factor_calendar_digest",
                    "market_factor_target_id",
                    "market_factor_product",
                    "market_factor_trading_date",
                    "market_factor_session_date",
                    "market_factor_event_session_date",
                    "exchange_id_source",
                ):
                    value = current.get(name)
                    if value is not None:
                        extensions[name] = value
                for name, value in extensions.items():
                    setattr(completed, name, value)
                self._attach_closed_bar_evidence(completed)
                if getattr(completed, "closed_bar_evidence", None) is not None:
                    setattr(
                        completed,
                        "_closed_bar_evidence_dispatch_token",
                        self._closed_bar_evidence_dispatch_token,
                    )
            if not replay and volume_only and self._incomplete_volume_bars == "lines":
                self._enqueue_bar_event(
                    completed,
                    bucket_start,
                    deliver_lines=True,
                    bar_source="local_aggregation_volume_incomplete",
                )
            else:
                self._enqueue_bar_event(completed, bucket_start, deliver_lines=complete)
            del self._bar_builders[bucket_start]
            self._last_closed_bucket_end = bucket_end
            closed += 1
        self._bar_builder = next(reversed(self._bar_builders.values()), None)
        self._prune_bar_quality_overrides(watermark)
        return closed

    def _dispatch_event(self, channel_type, priority, event_data):
        """Dispatch a tick/bar event into Cerebro's channel callback surface."""
        env = getattr(self, "_env", None)
        if env is None or not hasattr(env, "dispatch_channel_event"):
            self._mark_event_dropped(event_data, "strategy_dispatch_unavailable")
            return False

        if channel_type == "tick":
            self._attach_market_decision_now(event_data)

        event_timestamp = _tick_timestamp(event_data)
        if (
            getattr(event_data, "execution_eligible", None) is False
            and getattr(event_data, "event_time_utc", None) is None
        ):
            event_timestamp = None
        event = Event(
            timestamp=event_timestamp,
            priority=priority,
            channel_type=channel_type,
            channel_name=self._dataname,
            data=event_data,
        )
        # Only feed-origin events carry this private reference. Channel queues
        # already drive the matching broker in their own event loop.
        event._source_feed = (
            None
            if getattr(event_data, "execution_eligible", None) is False
            else self
        )
        sealed_evidence = (
            getattr(event_data, "closed_bar_evidence", None) if channel_type == "bar" else None
        )
        if sealed_evidence is not None:
            self._sealed_closed_bar_evidence_by_event_id[id(event_data)] = sealed_evidence
        try:
            env.dispatch_channel_event(event)
        except Exception:
            _safe_log("error", "btapifeed:1390 exception before re-raise (Exception)")
            self._mark_event_dropped(event_data, "strategy_dispatch_failed")
            raise
        finally:
            # Native callbacks are synchronous.  Do not retain evidence
            # identity after their dispatch window has closed.
            self._sealed_closed_bar_evidence_by_event_id.pop(id(event_data), None)
        if self.store is not None and hasattr(self.store, "mark_strategy_delivered"):
            self.store.mark_strategy_delivered(event_data)
        return True

    def _attach_market_decision_now(self, tick):
        """Attach caller-owned decision-boundary time to a qualified SDK tick.

        Parent receipt time is useful evidence but cannot measure time spent
        in the Store/Feed path.  A live caller must explicitly provide a
        calibrated same-domain provider; raw tick fields never supply this
        boundary.  Replay code can provide its own deterministic evidence
        without involving this Feed.
        """

        from bt_api_py.market_tick_contracts import TYPED_MARKET_TICK_SCHEMA_VERSIONS

        schema_version = _tick_value(tick, "schema_version", default=None)
        if schema_version not in TYPED_MARKET_TICK_SCHEMA_VERSIONS:
            return
        decision_fields = (
            "cohort_decision_now_monotonic_ns",
            "cohort_decision_now_epoch",
            "cohort_decision_now_clock_domain_id",
            "cohort_decision_now_receive_clock_error_ms",
            "cohort_decision_now_receive_clock_quality",
            "cohort_decision_now_freshness_verified",
        )
        # These fields belong to this dispatch boundary.  A raw transport
        # payload must never pre-populate them and masquerade as a later local
        # decision timestamp.
        for name in decision_fields:
            _set_tick_value(tick, name, None)
        provider = self.p.market_decision_now_provider
        if not callable(provider):
            return
        try:
            now = provider(tick)
        except Exception:
            _safe_log("warning", "btapifeed:1431 fallback on Exception")
            return
        from bt_api_py.market_cohort import MarketCohortNow

        if not isinstance(now, MarketCohortNow):
            return
        if now.clock_domain_id != _tick_value(tick, "clock_domain_id", default=None):
            return
        for name, value in (
            ("cohort_decision_now_monotonic_ns", now.now_monotonic_ns),
            ("cohort_decision_now_epoch", now.now_epoch),
            ("cohort_decision_now_clock_domain_id", now.clock_domain_id),
            ("cohort_decision_now_receive_clock_error_ms", now.receive_clock_error_ms),
            ("cohort_decision_now_receive_clock_quality", now.receive_clock_quality),
            ("cohort_decision_now_freshness_verified", now.freshness_verified),
        ):
            _set_tick_value(tick, name, value)

    def _mark_event_dropped(self, event_data, reason):
        """Close Store conservation accounting for an undispatched feed event."""
        marker = getattr(self.store, "mark_feed_dropped", None)
        if callable(marker):
            marker(event_data, reason)

    def _handle_event_health(self, event_data):
        """Emit feed status transitions and tell callers whether data is unsafe."""
        continuity = _tick_continuity(event_data)
        if _separates_trade_qualification(event_data):
            # D62-27: an unverified clock, unavailable or stale freshness, or
            # an SDK execution verdict only withholds trade qualification
            # (see trade_qualification()). Data defects and provider
            # continuity problems still degrade the feed as before.
            stale = False
            execution_unavailable = (
                _tick_value(event_data, "data_quality", default=None) != "GOOD"
            )
        else:
            stale = bool(_tick_value(event_data, "stale", default=False))
            execution_unavailable = getattr(event_data, "execution_eligible", None) is False
        observer_only_orderbook = execution_unavailable and (
            getattr(event_data, "event_type", None) == "orderbook"
            or getattr(getattr(event_data, "key", None), "channel", None) == "orderbook"
        )
        if observer_only_orderbook:
            # Keep unknown book clock/freshness on this event without
            # degrading the Feed's independent tick/bar continuity state.
            return True
        unhealthy = execution_unavailable or stale or continuity in _UNHEALTHY_CONTINUITY
        if unhealthy:
            if not self._continuity_degraded:
                self.put_notification(
                    self.DELAYED,
                    stale_reason=_tick_value(
                        event_data, "stale_reason", default=continuity or "stale"
                    ),
                    event_id=_tick_value(event_data, "event_id", default=""),
                )
                # A later verified recovery is a fresh LIVE transition.
                self._live_notified = False
                self._log_degraded(event_data, continuity, stale)
            self._continuity_degraded = True
            return True
        if self._continuity_degraded and continuity in {
            "ok",
            "continuous",
            "recovered",
            "snapshot",
        }:
            self._continuity_degraded = False
            self._mark_live()
            _safe_log("info", "btapifeed: %s LIVE again", self._dataname)
        return False

    def _note_stream_recovery(self):
        """Leave LIVE while the Store's tick channel is in recovery (D62-38 point 7).

        A disconnected source delivers no tick, so no tick can degrade this
        feed: SimNow 2026-11-07 showed a feed staying LIVE through a front
        disconnect. When a poll returns nothing and the Store reports its
        channel in recovery (e.g. a lost CTP source being replaced), the feed
        turns DELAYED; the next healthy tick of the resynced channel makes it
        LIVE again (see ``_handle_event_health``). Called only while LIVE.
        """
        reader = self._stream_recovery_reader
        if reader is None:
            return
        try:
            reason = reader(self._dataname)
        except Exception:
            _safe_log("warning", "btapifeed: stream recovery reason unavailable")
            return
        if not reason:
            return
        stale_reason = "sdk_market_stream_recovery:" + str(reason)
        self.put_notification(self.DELAYED, stale_reason=stale_reason, event_id="")
        self._live_notified = False
        self._continuity_degraded = True
        try:
            self._warn_delayed("stream_recovery", stale_reason, ())
        except Exception:
            _LOGGING_HEALTH["logging_errors"] += 1

    def _log_degraded(self, event_data, continuity, stale):
        """Log at a LIVE -> DELAYED transition why the feed left LIVE.

        The DELAYED status alone does not say whether the provider's continuity,
        a stale clock or this feed's own data checks stopped it; e.g. every
        price off the configured ``price_tick`` grid (a contract configured
        with the wrong tick) keeps a feed DELAYED with no order ever tried.
        Throttled per feed: repeated transitions of a flapping source within
        the throttle window are summarized, not logged one by one.
        """
        try:
            if continuity in _UNHEALTHY_CONTINUITY:
                cause = "continuity_" + str(continuity)
            elif stale:
                cause = "stale"
            else:
                cause = "data_not_executable"
            flags = _tick_value(event_data, "quality_flags", default=()) or ()
            self._warn_delayed(
                cause, _tick_value(event_data, "stale_reason", default="") or "-", flags
            )
        except Exception:
            _LOGGING_HEALTH["logging_errors"] += 1

    def _warn_delayed(self, cause, stale_reason, flags):
        """One throttled DELAYED line per feed: cause, reason, quality flags, tick."""
        throttled_warning(
            logger,
            "btapifeed.feed_delayed." + str(self._dataname),
            "btapifeed: %s DELAYED (cause=%s, stale_reason=%s, flags=%s, price_tick=%s)",
            _redact_diagnostic(self._dataname),
            cause,
            _redact_diagnostic(stale_reason),
            ",".join(str(flag) for flag in flags) or "-",
            self._cached_price_tick(),
            exc_info=False,
        )

    def get_logging_health(self):
        """Return the number of feed log-sink failures observed in this process."""
        return dict(_LOGGING_HEALTH)

    def _mark_live(self):
        """Emit the LIVE status exactly once when real-time traffic begins."""
        if self._replay_tick_adapter is not None or self._continuity_degraded:
            return
        if not self._live_notified:
            self.put_notification(self.LIVE)
            self._live_notified = True

    def _get_bucket_start(self, dt_value):
        """Round a tick timestamp down to the current feed timeframe bucket."""
        dt_value = dt_value.replace(microsecond=0)

        if self._timeframe == TimeFrame.Seconds:
            second = (dt_value.second // self._compression) * self._compression
            return dt_value.replace(second=second)

        if self._timeframe == TimeFrame.Minutes:
            minute = (dt_value.minute // self._compression) * self._compression
            return dt_value.replace(minute=minute, second=0)

        if self._timeframe == TimeFrame.Days:
            return dt_value.replace(hour=0, minute=0, second=0)

        # Fall back to minute-style bucketing for other sub-day frames.
        return dt_value.replace(second=0)

    def _get_bucket_end(self, bucket_start):
        """Return the exclusive right edge for a feed bucket."""
        if self._timeframe == TimeFrame.Ticks:
            return bucket_start
        if self._timeframe == TimeFrame.Seconds:
            return bucket_start + _dt.timedelta(seconds=self._compression)
        if self._timeframe == TimeFrame.Minutes:
            return bucket_start + _dt.timedelta(minutes=self._compression)
        if self._timeframe == TimeFrame.Days:
            return bucket_start + _dt.timedelta(days=self._compression)
        return bucket_start + _dt.timedelta(minutes=self._compression)
