## 27. R25：真实框架对象快照与恢复

状态：2026-11-09，IN_PROGRESS。本节在已批准的 Broker/pending 接线范围内实现真实 BT 对象的编码和恢复，不修改核心 Order、Position、Trade 算法。Strategy 通知前后的新钩子另见[限定调整申请](Backtrader-Gateway通知持久化钩子调整申请-2026-11-09.md)，批准前不实施。快照编解码本身不等于完整事件消费者或 E023 已关闭。

### 27.1 显式对象集合与稳定关联

Broker 私有模块提供 capture_framework_state，输入为稳定 key 到真实 Order、Position、Trade 的映射，以及受信 data_by_ref、owner、broker；输出有精确 schema 版本的有限 JSON。restore_framework_state 接收快照及新进程的受信 data_by_ref、owner、broker、commission_for_data，返回 GatewayFrameworkObjects（orders、positions、trades、order_refs、trade_refs）。它不加载 provider、不执行网络、不推进游标/ACK，也不直接修改 Strategy 的交易集合。

所有框架对象引用须显式包含在集合中。Trade 历史中的 Order 可能是某次通知副本，与当前原订单同 ref 但具有不同状态及执行片段窗口；不能按 ref 偷换成当前原订单。缺失引用拒绝，调用方须把该准确副本以独立稳定 key 纳入集合。

同一业务 Order 或 Trade 的原对象与通知副本保持同组 ref，彼此仍是不同对象；恢复时为每组分配新的运行时 ref，并返回旧→新映射，不重置全局计数器。组内数据、方向、owner、tradeid 等不可变绑定必须一致。原框架 p、info、created、执行片段 deque 及 Trade history 的受限共享关系需显式保存并重建，不能以数值相等代替引用一致。

### 27.2 复用真实对象，避免重放旧成交

Order 保留参数、生命周期状态、created、executed、完整 OrderExecutionBit 及 p1/p2。捕获不能调用 clone 改变 pending 边界；恢复不能调用 execute、addbit 重新累计旧成交。BuyOrder/SellOrder 由已绑定且有 bar 的 Feed 正常构造，再按已验证字段恢复；owner、data、broker 和 commission 对象只从受信参数取得。parent/oco 通过同集合稳定引用解析，不从 JSON 反序列化任意对象。

Position 保留数量、价格、原价、adjbase、开平变化、datetime/updt 等实际状态，不调用 update 重算。Trade 保留开闭状态、方向、数量、价格、价值、费用、盈亏、开闭 bar/时间、复合 tradeid、historyon 和完整 TradeHistory；历史 event.order 指向正确恢复对象。不能限制为 managed paper 的单 FOK 开仓，也不能复用其 receipt 作为 Gateway 来源证明。所有 provider/费用/时间真实性仍由上游合同负责。

TradeHistory 时区取自相应受信 Feed，校验保存描述；Position datetime/updt 支持 naive、标准 datetime.timezone 固定偏移，或恰为受信 Feed 所持有的时区对象。后者保存 data 引用并核对偏移/fold；其他无法无损恢复的时区明确拒绝，不默默降为固定偏移。整数、bool、float、None 区分，有限 float 精确往返；不重算或修正已经保存的经济字段。

info 与其他允许扩展只保存明确支持的有限数据，非法对象或敏感键拒绝，不能静默忽略后声称完整恢复。无 pickle、动态类名导入或任意属性字典恢复。schema、对象/引用/共享组、枚举、数值和容量先验证，再返回完整新对象集合；失败不安装部分恢复状态。总 JSON 上限 16 MiB、节点 100000、深度 16，清单亦有有限上界；R24 外层投影限制继续生效。

### 27.3 验证与尚未交付的调用链

使用实际 Feed、Order、Position、Strategy/Trade 的原执行与通知方法生成部分成交、追加成交、平仓与终态，验证捕获不修改对象、持久后重开、旧成交不再执行、恢复后可继续新成交，以及历史和通知副本引用、净仓/双腿、损坏/非有限/外来绑定/容量拒绝。集成把该真实对象快照放入 R24 同一 pending 投影并注入原子替换前后故障；不能只比较合成字典来代表框架恢复。

当前 Gateway trade_time 仅原生时间文本，没有足以证明夜盘自然日期的字段，执行流也没有单笔实际费用；本节只保存已经存在的框架值，不从这些缺失字段伪造实际成交 UTC 或零费用。真实 Broker 事件适配、生命周期安装、通知耐久确认、SDK facade 与账户经济视图继续按完整迭代推进。
