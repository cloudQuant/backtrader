10 fixed-500 runs, 3 full-output verifiers, source QA and compact Alpha101 matrix receipts.
