G10a six raw fixed-500 runs, logs, summaries, one full verifier and diagnostic files. cProfile is diagnostic only, not formal performance evidence.
