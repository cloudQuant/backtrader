# Iteration 49 G11: bounded positions active-window reduction

G11 replaces the per-timestamp `pd.concat` reduction for ordinary float64
weights with a bounded active-window matrix. The active rows remain in the
same chronological order, and the existing single-expiry-pop rule is kept.
The implementation is enabled only on pandas 2.2.3, whose float64 reduction
layout was source-audited: concat's
homogeneous block is active-row by asset in C order; `DataFrame.sum(axis=1)`
reduces its transposed asset-by-active view, and pandas copies that view in C
order only when NaNs are present. Gross and normalization remain the original
pandas Series operations. Every other pandas version keeps the original
implementation until its reduction layout is independently audited.

The fast path is limited to an exact base Series, a unique datetime index,
unique exact-string asset labels, one float64 NumPy block, and a zero-copy
frame view. Other pandas versions, extension arrays, subclasses, other
labels/dtypes/layouts, and an active matrix above the 8 MiB scratch bound use
the legacy-compatible path.
The returned DataFrame is built once from a float64 output array; NaN results
are zeroed to match the previous final `fillna(0.0)`.

`tests/factor_analysis/test_positions_active_window.py` keeps an independent
copy of the pre-G11 algorithm as a bitwise oracle. It covers a 500-asset
cancellation panel, NaN/infinity behavior, timezone-aware intraday timestamps,
colliding weekend expiries, budget and public-type fallbacks, and duplicate
date/asset errors. No performance result is claimed here; the bounded
fast-path's real-payload gain and process-tree memory remain for the Root's
serial performance round.
