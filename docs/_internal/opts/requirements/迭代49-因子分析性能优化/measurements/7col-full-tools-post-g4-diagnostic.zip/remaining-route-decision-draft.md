# Iteration 49 remaining-route decision (draft)

Status: read-only decision support, not a formal acceptance record. This note uses the 500-asset G1f p1-B phase results, one Root-reported preliminary G4 pair, installed pandas 2.2.3 source, and current public implementation. No source edits, tests, or benchmarks were run for this note. The 500-asset measurements are not extrapolated to 5,471 assets.

## G5: do not select general report parallelism

The G5 plan says to keep reports serial unless the memory budget permits bounded workers; only example 026 has multiple independent factor reports. The 025 and 027 runners each call `write_factor_report` once (`examples/backtest/025_factor_single/run.py:418-429`, `examples/backtest/026_factor_multi/run.py:425-447`, `examples/backtest/027_alpha003_panel_acceptance/run.py:276-290`). The formal memory target and reserve are in `五倍加速目标与实施路线.md:13,138-146`.

In the 500-asset p1-B results, 026 took 50.612s wall and its three HTML reports took 13.536s total. Even with three equal tasks and zero dispatch/copy/merge overhead, three workers could save at most 9.024s (17.8% of that run); two workers could save at most 4.512s. Treating the entire 5.682s CSV phase as free as well—although all output files are required—still gives an impossible combined ceiling of about 29% for those two routes. The 025 HTML phase is one report (4.590s); 027 is one report (5.073s), so report-task parallelism does not help either.

The preliminary G4 pair reported by Root reduced 026 HTML time from 13.562s to 11.888s, while whole-run wall moved from 48.227s to 47.381s and collection/export increased. This is one pair, not a stable end-to-end result. Latest available physical RAM was 2,424,964 KiB (2.483 GB), below the plan's 4 GiB reserve. Do not add workers under this state; process workers also risk duplicating pandas/report inputs, while thread scaling and GIL behavior are unmeasured.

The source/result inputs read were `D:/temp/iteration49-g1f-market-500-p1-b-025/result.json`, `...-026/result.json`, and `...-027/result.json`; values above use each result's `example_main_wall_ns`, `example_main_process_cpu_ns`, `phase_timers[*].wall_exclusive_ns`, and `resource_samples`. The p1-B minimum available-memory samples were 3.182 GB, 3.022 GB, and 2.878 GB respectively, all below 4 GiB. Do not add inclusive parent timers to child timers.

## G6: reject generic chunking/writer parallelism; retain one narrow screen

FinCore's `ResearchEvaluationResult.export` writes each result frame sequentially using `to_csv(index=False, encoding="utf-8")` and then writes charts (`D:/source_code/fincore/fincore/factor_analysis/research.py:240-274`). The frames remain the public result tables. This call does not specify `chunksize`, but the measured environment is pandas 2.2.3 and its CSV formatter already bounds conversion blocks: `_DEFAULT_CHUNKSIZE_CELLS = 100_000` and default rows per chunk are `100_000 // column_count` (`C:/anaconda3/Lib/site-packages/pandas/io/formats/csvs.py:53,174-177`); `_save_body` slices rows and `_save_chunk` converts/writes each slice (`csvs.py:305-329`). A generic chunking change would duplicate existing memory control.

A narrower candidate is worth one 500-asset screen if 026's post-G4 CSV phase remains material. FinCore constructs the long `labels` and `signals` tables by repeating the same grid-time values across period/factor blocks (`research.py:1871-1927`). Pandas converts datetime chunks through `DatetimeArray._format_native_types` and `tslib.format_array_from_datetime` (`C:/anaconda3/Lib/site-packages/pandas/core/arrays/datetimes.py:744-753`). An export-only fast path could format each unique, standard naive `datetime64[ns]` grid timestamp once, then reuse those exact strings in bounded chunks through a temporary shallow view. The public result frames must retain their original datetime dtype, contents, and identity.

This is a hypothesis, not a measured speedup. Keep it narrowly guarded and fall back for timezone-aware values, NaT, non-nanosecond or custom dtypes, and any unrecognized formatting case. A screen must compare complete CSV bytes, preserve column/row order, UTF-8, `index=False`, NA and timestamp rendering, and verify public frames stay unchanged; it must also measure tree RSS. In p1-B, CSV serialization was 3.497s for 025, 5.682s for 026, and 0.470s for 027. Those are upper bounds for each example's whole CSV phase, not expected savings. Reuse the existing pandas block behavior; do not add writer workers absent separate evidence.

## Remaining high-leverage route: profile 027 before choosing a kernel

The 027 p1-B run took 32.731s wall; exclusive `engine_runnext` was 19.435s (59.4% of the whole run), while its single report plus CSV totalled 5.543s (16.9%). Even deleting both output phases, which would violate the full-output contract, cannot approach the 80% goal. The profile therefore points to the native runnext/indicator path as the next area to inspect; it does not prove a compiled kernel will help. Preserve exact floating-point, NaN/reason, membership, and full output semantics.

After the current G4/G1e comparisons finish, a single 500-asset 027 diagnostic can use the existing profiler without running it as part of this note:

```powershell
python scripts/profile_factor_examples.py --example 027 --fincore-root D:/source_code/fincore --fincore-revision G4+G1e-743e45c --output D:/temp/iteration49-post-G4-profile-027-500 --max-symbols 500
```

The output directory must be new. `scripts/profile_factor_examples.py:42-50,174-185` confirms the CLI; absent `--no-report`, it runs the native example with `--report`. This is a single instrumented diagnostic with approximate Python stack samples, not an accepted benchmark. Use its current engine samples to decide whether a same-semantics operator/kernel prototype is justified. Do not infer a full-universe gain from the 500-asset results.
