"""Fresh G10c 027 compute-profile pairs; deliberately not full-output verification."""
import hashlib
import json
import runpy
import statistics
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
CONFIG = ROOT / ".codex-tmp/iteration49-g10c-027-compute-config.json"
CONFIG_SHA = "c56cd47e73f1c7ccfebf40b5cce9e54e3a0433968244fe3a5d9ecbbd7003543b"
BASE_CONFIG_SHA = "e2efe1ffa90a8837a76f5b60e8d779e24ad81621430edbf68502b23c17885232"
PAIR_HELPER_SHA = "64182c2d2dd426dc6a6d6c49415df421f50b0dd9bbccfc1dba1e945ad1d98a4c"
BASE_HELPER_SHA = "541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb"
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
ENGINES = {"a": "runnext", "b": "runonce"}


def raw(path):
    return Path(path).read_bytes()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(data):
    return {"sha256": digest(data), "size_bytes": len(data)}


def canonical_sha(value):
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return digest(encoded)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def check_pins(cfg):
    assert digest(raw(CONFIG)) == CONFIG_SHA
    assert digest(raw(ROOT / cfg["base_config_path"])) == BASE_CONFIG_SHA
    assert digest(raw(ROOT / cfg["pair_launcher_path"])) == PAIR_HELPER_SHA
    assert digest(raw(ROOT / cfg["base_helper_path"])) == BASE_HELPER_SHA


def verify_run(path, arm, cfg, base, state, data):
    r = read(path / "result.json")
    assert (r.get("status"), r.get("profile"), r.get("example"), r.get("input_universe"),
            r.get("runner_exit_code"), r.get("example_exit_code")) == (
                "COMPLETED", "compute", "027", "fixed500", 0, 0)
    assert not r.get("source_or_input_changes") and not r.get("summary_check_errors")
    assert r.get("runner_sha256") == base["tool_pins"][RUNNER]
    assert r.get("backtrader_source_before") == r.get("backtrader_source_after")
    assert r.get("fincore_source_before") == r.get("fincore_source_after")
    assert r.get("data_identity_before") == r.get("data_identity_after") == data[2]
    assert r.get("data_files_before") == data[3]
    assert (Path(r["data_root"]).resolve(), Path(r["selection_path"]).resolve()) == data[:2]

    if arm == "a":
        source = r["backtrader_source_before"]
        assert (source.get("kind"), source.get("commit"), source.get("manifest_sha256")) == (
            "verified_snapshot_manifest_v1", base["backtrader_snapshot"]["commit"],
            base["backtrader_snapshot"]["manifest_sha256"])
        expected_files = state[2]["files"]
    else:
        source = r["backtrader_source_before"]
        cand = base["backtrader_candidate"]
        assert (source.get("kind"), source.get("commit"), source.get("branch")) == (
            "git_worktree", cand["commit"], cand["branch"])
        assert sorted(source.get("source_status", [])) == sorted(cand["result_source_status"])
        expected_files = state[4]
    assert r.get("backtrader_files_before") == expected_files
    fc = r["fincore_source_before"]
    assert (fc.get("kind"), fc.get("commit"), fc.get("manifest_sha256")) == (
        "verified_snapshot_manifest_v1", base["fincore_snapshot"]["commit"],
        base["fincore_snapshot"]["manifest_sha256"])
    assert r.get("fincore_files_before") == state[6]["files"]

    engine = ENGINES[arm]
    assert (r.get("expected_engine"), r.get("observed_engine")) == (engine, engine)
    timers = r["phase_timers"]
    active = [name for name in ("runonce", "runnext")
              if timers.get("engine_" + name, {}).get("calls", 0) > 0]
    assert active == [engine]
    collection = timers["collection"]
    engine_timer = timers["engine_" + engine]
    assert collection["calls"] == engine_timer["calls"] == 1
    assert collection["wall_exclusive_ns"] > 0 and engine_timer["wall_exclusive_ns"] > 0
    assert timers["dataframe_to_csv"]["calls"] == 1
    assert timers.get("html_report", {}).get("calls", 0) == 0

    summary = r["summary"]
    assert (summary.get("status"), summary.get("factor"), summary.get("factor_mode"),
            summary.get("factor_calculation"), summary.get("operator_profile"),
            summary.get("symbols"), summary.get("dates"), summary.get("cells"),
            summary.get("output"), summary.get("broker"), summary.get("report")) == (
                "COMPLETED", "alpha003", "native", "RAN", "alpha101-v2", 500, 243,
                121500, "factor_values.csv", {"submit": 0, "cancel": 0}, None)
    assert isinstance(summary.get("indicator"), str) and "Alpha003" in summary["indicator"]
    cli = r.get("example_cli_arguments", [])
    assert "--report" not in cli
    assert cli.count("--output-dir") == 1
    assert Path(cli[cli.index("--output-dir") + 1]).resolve() == (path / "example").resolve()
    for flag, value in (("--data-dir", str(data[0])), ("--max-symbols", "500"),
                        ("--factor-mode", "native")):
        assert cli.count(flag) == 1 and cli[cli.index(flag) + 1] == value

    example = path / "example"
    csv_path = example / "factor_values.csv"
    csv_bytes = raw(csv_path)
    full_reference = Path(base["output_root"]) / (base["output_prefix"] + "-p1-a-027")
    assert csv_bytes == raw(full_reference / "example/factor_values.csv")
    header = csv_bytes.splitlines()[0].lower()
    assert b"engine" not in header
    assert not (example / "factor_report_alpha003.html").exists()
    return {
        "path": str(path), "result": pin(raw(path / "result.json")),
        "expected_engine": r["expected_engine"], "observed_engine": r["observed_engine"],
        "backtrader_source": r["backtrader_source_before"],
        "fincore_source": r["fincore_source_before"],
        "source_inventory_sha256": {
            "backtrader": canonical_sha(r["backtrader_files_before"]),
            "fincore": canonical_sha(r["fincore_files_before"]),
        },
        "data_identity": r["data_identity_before"],
        "summary_normalized": {k: v for k, v in summary.items()
                               if k not in ("elapsed_seconds", "report")},
        "factor_csv": {**pin(csv_bytes), "header": header.decode("utf-8")},
        "main_wall_s": r["example_main_wall_ns"] / 1e9,
        "main_cpu_s": r["example_main_process_cpu_ns"] / 1e9,
        "collection_wall_inclusive_s": collection["wall_inclusive_ns"] / 1e9,
        "collection_wall_exclusive_s": collection["wall_exclusive_ns"] / 1e9,
        "engine_wall_inclusive_s": engine_timer["wall_inclusive_ns"] / 1e9,
        "engine_wall_exclusive_s": engine_timer["wall_exclusive_ns"] / 1e9,
        "peak_bytes": max(r["main_peak_working_set_bytes"], r["resource_peak_tree_rss_bytes"]),
        "csv_wall_s": timers["dataframe_to_csv"]["wall_exclusive_ns"] / 1e9,
        "cli_total_wall_s": r["cli_total_wall_ns"] / 1e9,
    }


def ratios(rows, key):
    values = [row["b"][key] / row["a"][key] for row in rows]
    median = statistics.median(values)
    dispersion = (max(values) - min(values)) / median
    return {"candidate_over_baseline_b_over_a": values, "median_b_over_a": median,
            "relative_dispersion": dispersion, "within_5_percent": dispersion <= 0.05}


def main():
    assert digest(raw(CONFIG)) == CONFIG_SHA
    cfg = read(CONFIG)
    base = read(ROOT / cfg["base_config_path"])
    check_pins(cfg)
    assert base["pairs"] == [1] and base["output_prefix"] == "iteration49-g10c-panel-once-500"
    assert base["expected_engines"]["a"]["027"] == ENGINES["a"]
    assert base["expected_engines"]["b"]["027"] == ENGINES["b"]
    assert set(base["tool_pins"]) == {RUNNER, VERIFIER}
    pair_api = runpy.run_path(str(ROOT / cfg["pair_launcher_path"]),
                              run_name="g10c_compute_pair_api")
    helper = runpy.run_path(str(ROOT / cfg["base_helper_path"]),
                            run_name="g10c_compute_base_api")
    state = pair_api["source_state"](base, helper)
    data = helper["data_state"](base)
    helper["check_data"](data)
    out_root = Path(base["output_root"]).resolve(strict=True)
    prefix = cfg["output_prefix"]
    destination = Path(cfg["summary_path"])
    assert not destination.exists()
    records, pairs = [], []
    for pair in cfg["pairs"]:
        sides = {}
        for arm in cfg["order"][str(pair)]:
            pair_api["check_state"](base, helper, state, data)
            check_pins(cfg)
            out = pair_api["output"](out_root, prefix, pair, arm, "027")
            assert not out.exists() and not out.with_suffix(".log").exists()
            source = state[1] if arm == "a" else state[3]
            command = [ROOT / RUNNER, "--source-root", source, "--fincore-root", state[5],
                       "--data-root", data[0], "--selection", data[1], "--universe", "fixed500",
                       "--example", "027", "--profile", "compute", "--expected-engine",
                       ENGINES[arm], "--output", out]
            helper["check_tools"](ROOT, base)
            pair_api["execute"](command, out.with_suffix(".log"), ROOT)
            record = verify_run(out, arm, cfg, base, state, data)
            pair_api["check_state"](base, helper, state, data)
            check_pins(cfg)
            records.append({"pair": pair, "arm": arm, **record})
            sides[arm] = record
        assert sides["a"]["factor_csv"]["sha256"] == sides["b"]["factor_csv"]["sha256"]
        assert sides["a"]["factor_csv"]["size_bytes"] == sides["b"]["factor_csv"]["size_bytes"]
        assert raw(Path(sides["a"]["path"]) / "example" / "factor_values.csv") == raw(
            Path(sides["b"]["path"]) / "example" / "factor_values.csv")
        assert sides["a"]["summary_normalized"] == sides["b"]["summary_normalized"]
        pairs.append({"pair": pair, "factor_csv_exact_bytes_equal": True,
                      "summary_equal_after_only_report_and_elapsed_time_removal": True,
                      "baseline_csv": sides["a"]["factor_csv"],
                      "candidate_csv": sides["b"]["factor_csv"]})

    keys = ("main_wall_s", "main_cpu_s", "collection_wall_inclusive_s",
            "collection_wall_exclusive_s", "engine_wall_inclusive_s", "engine_wall_exclusive_s",
            "csv_wall_s", "cli_total_wall_s", "peak_bytes")
    metric_rows = [{arm: next(row for row in records if row["pair"] == pair and row["arm"] == arm)
                    for arm in ("a", "b")} for pair in (1, 2, 3)]
    result = {
        "schema": "iteration49.g10c.027.compute-profile.v1",
        "status": "PASS_COMPUTE_PROFILE_FACTOR_CSV_EQUIVALENCE_ONLY",
        "measurement_profile": "compute", "pairs": pairs, "runs": records,
        "counts": {"new_actual_runs": len(records), "independent_pairs": len(pairs)},
        "verification_scope": {
            "factor_csv": "raw bytes exactly equal within each A/B pair",
            "summary": "all fields exactly equal after removing only report path and elapsed_seconds",
            "canonical_full_output_verifier": "not run; it requires full-profile HTML and report semantics",
            "html_report": "not produced or semantically verified in compute profile",
        },
        "fixed_500": {"symbols": 500, "dates": 243,
                      "selection_sha256": base["data"]["selection_sha256"]},
        "sources": {"backtrader_snapshot": base["backtrader_snapshot"],
                    "backtrader_candidate": base["backtrader_candidate"],
                    "fincore_snapshot": base["fincore_snapshot"]},
        "tool_pins": base["tool_pins"],
        "timing_ratios_b_over_a": {key: ratios(metric_rows, key) for key in keys},
        "stability_rule": "For each metric, stable iff (max(B/A)-min(B/A))/median(B/A) <= 0.05.",
        "claim_limit": "Compute-profile CSV and normalized-summary check only; no HTML/report semantic verification or full-profile claim. Three prior full-profile 027 comparisons remain separate evidence.",
    }
    assert digest(raw(CONFIG)) == CONFIG_SHA
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"summary": str(destination), "runs": len(records),
                      "pairs": len(pairs), "profile": "compute"}), flush=True)


if __name__ == "__main__":
    main()
