G2d measured source slice. The preserved run_daily.py is archived for provenance only; the pair helper executes run.py, not run_daily.py.
