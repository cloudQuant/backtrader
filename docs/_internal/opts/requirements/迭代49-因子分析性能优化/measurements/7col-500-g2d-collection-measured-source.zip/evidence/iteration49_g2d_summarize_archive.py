"""Summarize completed G2d fixed-500 runs; never launches examples or tests."""
from __future__ import annotations

import hashlib
import io
import json
import runpy
import statistics
import zipfile
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
TEMP = Path("D:/temp")
MEASUREMENTS = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements"
FORMAL = ROOT / ".codex-tmp/iteration49_g2d_pairs.py"
FORMAL_SHA256 = "f66659b63c66ae3f4aee26d8f4be3d7ba9237df6a36c4138a7b7b984e1085a95"
SOURCE_QA = ROOT / ".codex-tmp/iteration49-g2d-source-qa.json"
SOURCE_QA_SHA256 = "421ca2958742a5a4ab101285cfaf1961ab44f17601afdeadf942db395d0330d2"
SUMMARY = MEASUREMENTS / "7col-500-g2d-collection-pairs.json"
RAW_ZIP = MEASUREMENTS / "7col-500-g2d-collection-raw.zip"
SOURCE_ZIP = MEASUREMENTS / "7col-500-g2d-collection-measured-source.zip"
EXAMPLES = ("025", "026", "027")
METRICS = ("wall_s", "cpu_s", "peak_bytes")
PHASE_FIELDS = (
    "wall_inclusive_ns", "wall_exclusive_ns",
    "process_cpu_inclusive_ns", "process_cpu_exclusive_ns",
)
FOCUS_PHASES = ("load_daily_panel", "feed_preload", "evaluate_frames",
                "fincore_evaluate", "evaluation_export")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_sha(path: Path) -> str:
    return sha(path.read_bytes())


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def metric(result: dict) -> dict:
    values = {
        "wall_s": result["example_main_wall_ns"] / 1e9,
        "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
        "peak_bytes": max(result["main_peak_working_set_bytes"],
                           result["resource_peak_tree_rss_bytes"]),
    }
    assert all(value > 0 for value in values.values()), values
    return values


def paired(a: list[float], b: list[float]) -> dict:
    ratios = [right / left for left, right in zip(a, b, strict=True)]
    middle = statistics.median(ratios)
    return {
        "a_median": statistics.median(a), "b_median": statistics.median(b),
        "paired_b_over_a": ratios, "paired_b_over_a_median": middle,
        "paired_b_over_a_min": min(ratios), "paired_b_over_a_max": max(ratios),
        "relative_dispersion_over_median": (max(ratios) - min(ratios)) / middle,
        "b_reduction_percent": (1.0 - middle) * 100.0,
    }


def make_zip(files: dict[str, bytes], note: str) -> tuple[bytes, dict]:
    rows = [{"path": name, "size_bytes": len(data), "sha256": sha(data)}
            for name, data in sorted(files.items())]
    manifest = json.dumps({"schema_version": 1, "note": note, "files": rows},
                          sort_keys=True, indent=2).encode("utf-8") + b"\n"
    members = {**files, "README.txt": (note + "\n").encode("utf-8"),
               "MANIFEST.json": manifest}
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    packed = buffer.getvalue()
    return packed, {"path": "", "size_bytes": len(packed), "sha256": sha(packed),
                    "member_count": len(members), "manifest_sha256": sha(manifest)}


def phase_summary(by_example: dict) -> dict:
    result = {}
    for example in EXAMPLES:
        result[example] = {}
        for arm in ("a", "b"):
            observed: dict[str, list[dict]] = {}
            for run in by_example[example][arm]:
                for label, row in (run.get("phase_timers") or {}).items():
                    observed.setdefault(label, []).append(row)
            labels = sorted(set(FOCUS_PHASES) | set(observed))
            result[example][arm] = {}
            for label in labels:
                rows = observed.get(label, [])
                result[example][arm][label] = {
                    "runs_present": len(rows),
                    "calls_total": sum(row.get("calls", 0) for row in rows),
                    "parent_labels": sorted({parent for row in rows
                                              for parent in row.get("parent_labels", [])}),
                    "median_ns": {
                        field: statistics.median(row[field] for row in rows
                                                 if isinstance(row.get(field), int))
                        if any(isinstance(row.get(field), int) for row in rows) else None
                        for field in PHASE_FIELDS
                    },
                }
    return result


def main() -> None:
    outputs = (SUMMARY, RAW_ZIP, SOURCE_ZIP)
    assert all(not path.exists() for path in outputs), "refusing to overwrite G2d deliverables"
    assert file_sha(FORMAL) == FORMAL_SHA256, "frozen G2d pair helper changed"
    assert file_sha(SOURCE_QA) == SOURCE_QA_SHA256, "G2d source-QA receipt changed"
    formal = runpy.run_path(str(FORMAL), run_name="iteration49_g2d_frozen_helpers")
    bt_manifest = formal["check_sources"]()
    source_qa = read(SOURCE_QA)
    assert source_qa.get("status") == "ROOT_FOCUSED_SOURCE_QA_PASS_PERFORMANCE_PENDING"
    assert (source_qa.get("passed"), source_qa.get("warnings"), source_qa.get("exit_code")) == (94, 1, 0)

    records, raw_files = [], {}
    by_example = {name: {arm: [] for arm in ("a", "b")} for name in EXAMPLES}
    identities = {"bt": {"a": None, "b": None}, "fincore": None, "data": None}
    for pair in (1, 2, 3):
        order = ("a", "b") if pair % 2 else ("b", "a")
        for example in EXAMPLES:
            for arm in order:
                folder = formal["output"](pair, arm, example)
                result_path, log_path = folder / "result.json", folder.with_suffix(".log")
                result = formal["validate"](folder, arm, example, bt_manifest)
                assert log_path.is_file(), log_path
                values = metric(result)
                bt = result["backtrader_source_before"]
                fc = result["fincore_source_before"]
                data = result["data_identity_before"]
                assert bt == result["backtrader_source_after"]
                assert fc == result["fincore_source_after"]
                assert data == result["data_identity_after"]
                assert identities["bt"][arm] in (None, bt)
                identities["bt"][arm] = bt
                assert identities["fincore"] in (None, fc)
                identities["fincore"] = fc
                assert identities["data"] in (None, data)
                identities["data"] = data
                assert data.get("symbols") == 500 and data.get("dates") == 243
                assert data.get("selection_sha256") == formal["SELECTION_SHA256"]
                by_example[example][arm].append(result)
                raw_files[f"results/p{pair}/{arm}-{example}/result.json"] = result_path.read_bytes()
                raw_files[f"logs/{log_path.name}"] = log_path.read_bytes()
                records.append({"pair": pair, "arm": arm, "example": example,
                                "result": str(result_path), "result_sha256": file_sha(result_path),
                                "log": str(log_path), "log_sha256": file_sha(log_path), **values})

    assert len(records) == 18 and all(len(by_example[name][arm]) == 3
                                      for name in EXAMPLES for arm in ("a", "b"))
    assert identities["bt"]["a"]["source_content_sha256"] != identities["bt"]["b"]["source_content_sha256"]
    assert identities["fincore"]["kind"] == "verified_snapshot_manifest_v1"
    data_identity = identities["data"]

    verifiers = []
    for pair in (1, 2, 3):
        path = TEMP / f"iteration49-g2d-collection-p{pair}-verification.json"
        log = path.with_suffix(".log")
        verified = read(path)
        assert (verified.get("status"), verified.get("mode"), verified.get("valid"),
                verified.get("scope_complete")) == ("PASS", "ab-pair", True, True)
        assert set(verified.get("comparisons", {})) == set(EXAMPLES)
        assert all(verified["comparisons"][name].get("valid") is True for name in EXAMPLES)
        assert (verified.get("fixed_input", {}).get("symbol_count"),
                verified.get("fixed_input", {}).get("date_count")) == (500, 243)
        assert verified["fixed_input"].get("selection_sha256") == formal["SELECTION_SHA256"]
        assert verified["fixed_input"].get("ordered_symbols_sha256") == data_identity.get("ordered_symbols_sha256")
        for side, arm in (("baseline", "a"), ("candidate", "b")):
            for example in EXAMPLES:
                run = verified["runs"][side][example]
                expected = formal["output"](pair, arm, example) / "example"
                assert run.get("valid") is True and Path(run["directory"]).resolve() == expected.resolve()
        assert log.is_file(), log
        raw_files[f"verifiers/p{pair}/verification.json"] = path.read_bytes()
        raw_files[f"verifiers/p{pair}/verification.log"] = log.read_bytes()
        verifiers.append({"pair": pair, "path": str(path), "sha256": file_sha(path),
                          "log": str(log), "log_sha256": file_sha(log),
                          "status": verified["status"], "scope_complete": True,
                          "comparisons": {name: verified["comparisons"][name]["valid"]
                                          for name in EXAMPLES}})
    assert len(raw_files) == 42

    examples = {}
    for example in EXAMPLES:
        values = {pair: {arm: metric(by_example[example][arm][pair - 1])
                         for arm in ("a", "b")} for pair in (1, 2, 3)}
        examples[example] = {
            "pair_count": 3,
            "pairs": {str(pair): values[pair] for pair in (1, 2, 3)},
            "metrics": {name: paired([values[p]["a"][name] for p in (1, 2, 3)],
                                     [values[p]["b"][name] for p in (1, 2, 3)])
                        for name in METRICS},
        }

    source_files = {}
    for name in formal["CANDIDATE_PINS"]:
        source_files[f"backtrader/baseline-35c1/{name}"] = (formal["BASE"] / name).read_bytes()
        source_files[f"backtrader/measured-g2d/{name}"] = (ROOT / name).read_bytes()
    daily = formal["DAILY"]
    source_files[f"preserved-unrelated-not-executed-quick/{daily}"] = (ROOT / daily).read_bytes()
    source_files["backtrader/baseline-35c1/.iteration49-source.json"] = (
        formal["BASE"] / ".iteration49-source.json").read_bytes()
    test = "tests/unit/test_factor_research_contracts.py"
    source_files[f"qa-input/{test}"] = (ROOT / test).read_bytes()
    selection = formal["SELECTION"]
    for label, path in (("selection/benchmark-500-7col.json", selection),
                        ("scripts/benchmark_factor_examples.py", ROOT / formal["RUNNER"]),
                        ("scripts/verify_factor_examples_benchmark.py", ROOT / formal["VERIFIER"]),
                        ("evidence/iteration49_g2d_pairs.py", FORMAL),
                        ("evidence/iteration49_g2d_summarize_archive.py", Path(__file__)),
                        ("evidence/iteration49-g2d-source-qa.json", SOURCE_QA)):
        source_files[label] = path.read_bytes()

    raw_bytes, raw_info = make_zip(raw_files,
        "G2d raw 18 full example runs and three complete output verifiers; 500 symbols x 243 dates.")
    source_bytes, source_info = make_zip(source_files,
        "G2d measured source slice. The preserved run_daily.py is archived for provenance only; "
        "the pair helper executes run.py, not run_daily.py.")
    raw_info["path"] = RAW_ZIP.name
    source_info["path"] = SOURCE_ZIP.name
    summary = {
        "schema": "iteration49.g2d.paired-measurement.v1",
        "status": "PASS_G2D_PAIRED_OUTPUT_VERIFICATION_MEASUREMENT_ONLY",
        "measurement_scope": "fixed 500-symbol, 243-date, seven-column 025/026/027 full examples",
        "performance_acceptance": "NOT_ASSESSED_BY_ARCHIVER",
        "counts": {"measured_processes": len(records), "complete_output_verifier_runs": len(verifiers),
                    "verified_comparisons": 9, "archived_raw_results_and_logs": 36,
                    "archived_verifiers_and_logs": 6},
        "pair_order": {str(pair): "AB" if pair % 2 else "BA" for pair in (1, 2, 3)},
        "sources": {"backtrader_baseline": identities["bt"]["a"],
                    "backtrader_candidate": identities["bt"]["b"],
                    "fincore_both_arms": identities["fincore"]},
        "fixed_data_identity": data_identity,
        "source_qa": {"path": str(SOURCE_QA), "sha256": file_sha(SOURCE_QA),
                      "passed": 94, "warnings": 1, "warning_category": source_qa["warning_category"],
                      "seconds": 78.64, "exit_code": 0},
        "examples": examples, "phase_timer_medians": phase_summary(by_example),
        "phase_timer_note": "Per-phase medians only; nested inclusive timers overlap and are not summed.",
        "actual_runs": records, "verifiers": verifiers,
        "helper_pins": {"formal": {"path": str(FORMAL), "sha256": file_sha(FORMAL)},
                        "summary_script": {"path": str(Path(__file__)), "sha256": file_sha(Path(__file__))}},
        "raw_archive": raw_info, "measured_source_archive": source_info,
        "limitations": [
            "This archive establishes paired 500-symbol output equivalence and records timings; it does not accept 5,471-symbol performance.",
            "A fixed-500 result cannot establish scaling at the full universe or rule out a full-size-only quadratic hotspot.",
            "Peak bytes are max(main-process OS peak working set, sampled process-tree RSS peak); the 0.5-second tree sampler can miss brief child peaks.",
            "Source-level object/array size estimates are not process RSS measurements.",
        ],
    }
    summary_bytes = json.dumps(summary, sort_keys=True, indent=2, ensure_ascii=False).encode("utf-8") + b"\n"
    for path, data in ((RAW_ZIP, raw_bytes), (SOURCE_ZIP, source_bytes), (SUMMARY, summary_bytes)):
        with path.open("xb") as stream:
            stream.write(data)
    print(json.dumps({"status": summary["status"], "summary": str(SUMMARY),
                      "raw_zip_sha256": raw_info["sha256"],
                      "source_zip_sha256": source_info["sha256"]}))


if __name__ == "__main__":
    main()
