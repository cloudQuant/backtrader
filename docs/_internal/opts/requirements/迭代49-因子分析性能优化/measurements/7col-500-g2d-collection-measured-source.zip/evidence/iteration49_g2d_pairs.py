"""Serial full-output fixed-500 pairs for the G2d collection-memory candidate."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('D:/source_code/backtrader')
TEMP = Path('D:/temp')
BASE = TEMP / 'iteration49-alpha003-backtrader-35c1dabe5'
FC = TEMP / 'iteration49-g1d-fincore-d403015'
BT_BASE_COMMIT = '35c1dabe52764e56631d8f636e69caf467f386d5'
BT_HEAD = '35c1dabe52764e56631d8f636e69caf467f386d5'
FC_COMMIT = 'd40301518259501eb166e19657f23ea0e583a5e8'
BT_MANIFEST = 'dd518701cac96be0185100d15c8d540dc2c1bf8150a2fc79bcb77489f01598ba'
FC_MANIFEST = '4716b173f70b07c98fc4eda4076ccc6c7a6d4f383a5b5346e4270d6d0f58c22e'
EXAMPLES = {
    '025': '025_factor_single',
    '026': '026_factor_multi',
    '027': '027_alpha003_panel_acceptance',
}
EXAMPLE_DIRS = tuple('examples/backtest/' + name for name in EXAMPLES.values())
RUNNER = 'scripts/benchmark_factor_examples.py'
VERIFIER = 'scripts/verify_factor_examples_benchmark.py'
DAILY = 'examples/backtest/027_alpha003_panel_acceptance/run_daily.py'
SELECTION = ROOT / 'docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json'
DATA = ROOT / 'tests/datas/a_stocks'
SELECTION_SHA256 = '14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc'
DAILY_SHA256 = '206f13a98d7e153bd0cd6f5d42d38470fb7566788104b957af87614be5999220'
# The pinned run_daily.py is an unrelated preserved dirty input; this helper invokes run.py only.
PRESERVED_UNRELATED = {DAILY: DAILY_SHA256}
CANDIDATE_PINS = {'backtrader/feeds/pandafeed.py': '35f4e7c82c1dba30d3c346c170c6545ce1bcf58297857077d61cc613de015748', 'backtrader/research/align.py': 'aaeb22cdb7a033d47b253ed365c91c0072e63203fcc815a61b3222259ce69333', 'backtrader/research/factor_strategy.py': 'f2d83395045aa8a2a15d52ea65403aad48aa46178c14beac76c490ce817f322d', 'backtrader/research/specs.py': '793583f59980f74e81546e5f026f1d661513a859e726b72d025a7b5d2372bd2b'}

PINS = {
    **CANDIDATE_PINS,
    'tests/unit/test_factor_research_contracts.py': '35965e560baf5999e632a0f89149585e5cd0a6f6a560fd52555308b78c3ca4fd',
    RUNNER: 'a971ca097236c6ffbaf85f5291bf58e47022d1f452c861e810bc3b8190a2ea0a',
    VERIFIER: '10f27eda6f24ecca88142cbd978d9b1eb9cfedfad604bd96d289008cf59a23e7',
    'examples/backtest/025_factor_single/run.py': '7a513386be0d452aa1738db322d606bb92ac43cd139e08b31552a81faf633104',
    'examples/backtest/026_factor_multi/run.py': 'd7d9532a35ccf4a29cd6e3136f00d4ccd2836f1f77455a956efe068c853ecf8f',
    'examples/backtest/027_alpha003_panel_acceptance/run.py': '22ca22f504674c823b9cf98a54e6269dd8b01bd196d4c3c6985ac90140f8fa93',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def snapshot(root, expected_manifest, expected_commit):
    manifest_path = root / '.iteration49-source.json'
    assert digest(manifest_path) == expected_manifest
    manifest = read(manifest_path)
    assert manifest.get('schema_version') == 1 and manifest.get('commit') == expected_commit
    files = manifest.get('files')
    assert isinstance(files, dict) and files
    for name, item in files.items():
        path = root / name
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item['sha256'] and len(raw) == item['size_bytes'], name
    return manifest

def current_source_names():
    scopes = ['backtrader', *EXAMPLE_DIRS, RUNNER]
    raw = subprocess.check_output(
        ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard', '--', *scopes],
        cwd=ROOT,
    )
    names = {item.decode('utf-8') for item in raw.split(b'\0') if item}
    suffixes = {'.py', '.md', '.yaml', '.yml', '.json', '.pem'}
    return {
        name for name in names
        if name.startswith('backtrader/') or name == RUNNER
        or any((name == folder or name.startswith(folder + '/')) and Path(name).suffix.lower() in suffixes
               for folder in EXAMPLE_DIRS)
    }

def check_sources():
    bt_manifest = snapshot(BASE, BT_MANIFEST, BT_BASE_COMMIT)
    snapshot(FC, FC_MANIFEST, FC_COMMIT)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    assert head == BT_HEAD and branch == 'dev'
    assert digest(SELECTION) == SELECTION_SHA256 and digest(ROOT / DAILY) == DAILY_SHA256
    for name, pin in PINS.items():
        assert digest(ROOT / name) == pin, name
    base_names = set(bt_manifest['files'])
    assert current_source_names() == base_names | {RUNNER}
    changed = set()
    for name in base_names:
        before = (BASE / name).read_bytes().replace(b'\r\n', b'\n')
        after = (ROOT / name).read_bytes().replace(b'\r\n', b'\n')
        if before != after:
            changed.add(name)
    assert changed == set(CANDIDATE_PINS) | {DAILY}, sorted(changed)
    scopes = ['backtrader', *EXAMPLE_DIRS, RUNNER]
    status = subprocess.check_output(
        ['git', 'status', '--porcelain=v1', '--untracked-files=no', '--', *scopes],
        cwd=ROOT, text=True, encoding='utf-8',
    ).splitlines()
    assert {line[3:] for line in status} == set(CANDIDATE_PINS) | set(PRESERVED_UNRELATED), status
    assert all(line[:2] == ' M' for line in status), status
    staged = subprocess.check_output(
        ['git', 'diff', '--cached', '--name-only', '--', *scopes], cwd=ROOT, text=True
    ).splitlines()
    assert not staged, staged
    return bt_manifest

def output(pair, arm, example):
    return TEMP / f'iteration49-g2d-collection-p{pair}-{arm}-{example}'

def execute(args, log):
    with log.open('xb') as stream:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))

def validate(path, arm, example, bt_manifest):
    result = read(path / 'result.json')
    assert result['status'] == 'COMPLETED'
    assert result['runner_exit_code'] == result['example_exit_code'] == 0
    assert result['example'] == example and result['profile'] == 'full'
    assert not result['source_or_input_changes'] and not result['summary_check_errors']
    for key in ('backtrader_source', 'fincore_source', 'data_identity'):
        assert result[key + '_before'] == result[key + '_after'], key
    bt = result['backtrader_source_before']
    if arm == 'a':
        assert bt['kind'] == 'verified_snapshot_manifest_v1'
        assert bt['commit'] == BT_BASE_COMMIT and bt['manifest_sha256'] == BT_MANIFEST
    else:
        assert bt['kind'] == 'git_worktree' and bt['commit'] == BT_HEAD and bt['branch'] == 'dev'
        assert {line[3:] for line in bt['source_status']} == set(CANDIDATE_PINS) | set(PRESERVED_UNRELATED)
    assert result['fincore_source_before']['kind'] == 'verified_snapshot_manifest_v1'
    assert result['fincore_source_before']['commit'] == FC_COMMIT
    assert result['fincore_source_before']['manifest_sha256'] == FC_MANIFEST
    for name in (*CANDIDATE_PINS, DAILY):
        expected = bt_manifest['files'][name]['sha256'] if arm == 'a' else PINS.get(name, DAILY_SHA256)
        assert result['backtrader_files_before'][name]['sha256'] == expected, name
    summary = result['summary']
    assert (summary['symbols'], summary['dates'], summary['factor_mode'], summary['factor_calculation']) == (
        500, 243, 'native', 'RAN'
    )
    return result

def main():
    pairs = tuple(map(int, sys.argv[1:]))
    assert pairs and len(pairs) == len(set(pairs)) and all(pair in (1, 2, 3) for pair in pairs)
    bt_manifest = check_sources()
    print(f'UNRELATED_PRESERVED_NOT_EXECUTED_QUICK: {DAILY} sha256={DAILY_SHA256}', flush=True)
    print('PLAN: 18 runs, 9 unique comparisons, 3 verifiers, 9 verifier slots', flush=True)
    for pair in pairs:
        if pair > 1:
            first = TEMP / 'iteration49-g2d-collection-p1-verification.json'
            assert first.is_file(), 'run pair 1 before pairs 2/3'
            prior = read(first)
            assert prior['status'] == 'PASS' and prior['scope_complete']
        examples = ('025', '026', '027')
        for example in examples:
            for arm in (('a', 'b') if pair % 2 else ('b', 'a')):
                check_sources()
                destination = output(pair, arm, example)
                assert not destination.exists()
                print(f'START G2d-collection pair={pair} arm={arm} example={example}', flush=True)
                execute([
                    RUNNER, '--source-root', str(BASE if arm == 'a' else ROOT),
                    '--fincore-root', str(FC), '--data-root', str(DATA),
                    '--selection', str(SELECTION), '--example', example, '--profile', 'full',
                    '--output', str(destination),
                ], destination.with_suffix('.log'))
                result = validate(destination, arm, example, bt_manifest)
                peak = max(result['main_peak_working_set_bytes'], result['resource_peak_tree_rss_bytes'])
                print(json.dumps({
                    'pair': pair, 'arm': arm, 'example': example,
                    'wall_s': result['example_main_wall_ns'] / 1e9,
                    'cpu_s': result['example_main_process_cpu_ns'] / 1e9,
                    'peak_bytes': peak,
                }), flush=True)
                check_sources()
        verification = TEMP / f'iteration49-g2d-collection-p{pair}-verification.json'
        assert not verification.exists()
        args = [VERIFIER, '--output', str(verification)]
        for arm, flag in (('a', '--baseline'), ('b', '--candidate')):
            for example in ('025', '026', '027'):
                control_pair = pair
                result_path = output(control_pair, arm, example)
                validate(result_path, arm, example, bt_manifest)
                args.extend((flag, f'{example}={result_path}'))
        check_sources()
        execute(args, verification.with_suffix('.log'))
        verified = read(verification)
        assert verified['status'] == 'PASS' and verified['scope_complete']
        print(f'G2d-collection pair {pair} COMPLETE OUTPUT PASS', flush=True)

if __name__ == '__main__':
    main()
