from __future__ import annotations
import cProfile, hashlib, importlib.util, io, json, pstats, sys, time, subprocess
from pathlib import Path
ROOT = Path(r'D:\source_code\backtrader')
EXAMPLE_PATH = ROOT / 'examples/backtest/027_alpha003_panel_acceptance/run.py'
SELECTION_PATH = ROOT / 'docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json'
DATA_ROOT = ROOT / 'tests/datas/a_stocks'
OUT = Path(r'D:\temp\iteration49-g10-027-runonce-cprofile-500-r1.txt')
PSTAT = Path(r'D:\temp\iteration49-g10-027-runonce-cprofile-500-r1.pstats')
if OUT.exists() or PSTAT.exists():
    raise SystemExit('diagnostic output path already exists')
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()
selection_sha = '14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc'
if sha(SELECTION_PATH) != selection_sha:
    raise SystemExit('fixed selection pin mismatch')
tracked = [ROOT / p for p in (
    'backtrader/research/operators.py',
    'backtrader/research/factor_indicator.py',
    'backtrader/research/factor_strategy.py',
    'examples/backtest/027_alpha003_panel_acceptance/run.py',
    'scripts/benchmark_factor_examples.py',
)]
source_before = {str(path.relative_to(ROOT)): sha(path) for path in tracked}
spec = importlib.util.spec_from_file_location('_iteration49_g10_027_profile', EXAMPLE_PATH)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
config = module._load_config()
config['factor_mode'] = 'native'
config['data']['directory'] = str(DATA_ROOT)
config['data']['max_symbols'] = 500
selection = json.loads(SELECTION_PATH.read_text(encoding='utf-8'))
expected_symbols = tuple(row['symbol'] for row in selection['entries'])
panel = module.load_daily_panel(config['data'])
if tuple(panel['assets']) != expected_symbols or len(panel['grid']) != 243 or len(panel['feeds']) != 500:
    raise SystemExit('loaded panel does not match the exact pinned 500 x 243 selection')
import psutil
proc = psutil.Process()
mem_loaded = proc.memory_info()
profile = cProfile.Profile()
wall0, cpu0 = time.perf_counter(), time.process_time()
profile.enable()
strategy, collected, indicator = module._run_factor(config, panel, runonce=True)
profile.disable()
wall, cpu = time.perf_counter() - wall0, time.process_time() - cpu0
mem_finished = proc.memory_info()
PSTAT.parent.mkdir(parents=True, exist_ok=True)
profile.dump_stats(str(PSTAT))
from backtrader.research.operators import CrossSectionalRank, _RollingCorrelationPanel, _MultiplyPanel
panel_types = (CrossSectionalRank, _RollingCorrelationPanel, _MultiplyPanel)
rows = []
for instances in strategy._factor_instances_by_name.values():
    for root in instances:
        for node in strategy._factor_tree(root):
            if isinstance(node, panel_types):
                diag = node.lifecycle_diagnostics
                rows.append({
                    'class': type(node).__bases__[0].__name__ if type(node).__bases__ else type(node).__name__,
                    'next_count': diag['next_count'], 'once_ranges': diag['once_ranges'],
                    'once_count': diag['once_count'], 'coverage_matches': diag['coverage_matches'],
                })
if len(collected.grid) != 243 or len(collected.target_order) != 500:
    raise SystemExit('returned panel dimensions mismatch')
stats_out = io.StringIO()
stats = pstats.Stats(profile, stream=stats_out)
stats.strip_dirs().sort_stats('cumulative').print_stats(55)
stats_out.write('\n--- TOP 55 BY SELF TIME ---\n')
stats.sort_stats('tottime').print_stats(55)
stats_out.write('\n--- CALLERS OF TARGET HOT FUNCTIONS ---\n')
for pattern in ('_panel_once_advance_feeds', '_run_panel_once', 'once_via_next', '_oncepost'):
    stats.print_callers(pattern)
source_after = {str(path.relative_to(ROOT)): sha(path) for path in tracked}
if source_before != source_after:
    raise SystemExit('tracked source changed during diagnostic')
bench_spec = importlib.util.spec_from_file_location('_iteration49_benchmark_factor_examples', ROOT / 'scripts/benchmark_factor_examples.py')
bench = importlib.util.module_from_spec(bench_spec)
bench_spec.loader.exec_module(bench)
data_identity, data_pins = bench._data_state_fixed500(DATA_ROOT, SELECTION_PATH)
report = {
    'diagnostic_only': True,
    'source_commit': subprocess.run(['git','rev-parse','HEAD'],cwd=ROOT,check=True,capture_output=True,text=True).stdout.strip(),
    'python': sys.version,
    'selection_sha256': sha(SELECTION_PATH), 'data_root': str(DATA_ROOT),
    'symbols': len(panel['assets']), 'dates': len(panel['grid']),
    'result_shape': list(collected.factors.shape),
    'runonce_wall_seconds_cprofiled': wall, 'runonce_process_cpu_seconds_cprofiled': cpu,
    'rss_after_input_load_bytes': mem_loaded.rss, 'rss_after_run_bytes': mem_finished.rss,
    'peak_wset_after_run_bytes': getattr(mem_finished, 'peak_wset', None),
    'panel_kernel_lifecycle': rows,
    'source_sha256_before_after': source_before,
    'data_pin_check_after': {'identity': data_identity, 'pinned_file_count': len(data_pins), 'verified': True},
    'profile_path': str(PSTAT),
}
OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n\n' + stats_out.getvalue(), encoding='utf-8')
print(json.dumps(report, indent=2, sort_keys=True))
print('\n' + stats_out.getvalue())
