G10a source evidence and the exact six-file frozen candidate snapshot; no current live candidate bytes are used.
