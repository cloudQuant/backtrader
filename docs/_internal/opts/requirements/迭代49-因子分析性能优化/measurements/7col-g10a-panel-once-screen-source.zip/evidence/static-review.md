# Iteration 49 panel once static review

**Verdict: GO_STATIC_REVIEW_ONLY.** I found no source-level blocker to Root's fixed-500 screen. This review checks the frozen Alpha003 path and CLI selection; it does not establish performance or full-101 acceptance.

Reviewed pins:

- `backtrader/research/operators.py`: 88,759 bytes, SHA-256 `ebb85d212d162b7631279cc91845ebea6a339f0e0fc12e5df5c5fb6d5a58500f`
- `tests/unit/test_factor_research_panel_once.py`: 8,174 bytes, SHA-256 `1c221bd9eeb74e7097811cfc899513fe7c5f7a9ed8f8f69a39217d58db0232d8`
- `backtrader/research/factor_indicator.py`: SHA-256 `2aa5e813de354a9ecd8c8589d7d89e5215661f9dd9dc062e6966767d99083fd8`
- `examples/backtest/027_alpha003_panel_acceptance/run.py`: 13,218 bytes, SHA-256 `78e29dadf258bf8ed0821a34e7cb5bee5f13452d04a68e2517236d0218ab4e63`
- `tests/unit/test_alpha003_quick_engine.py`: 2,370 bytes, SHA-256 `be12c347029383271bf7f0681996d7446e7fbf9b0c878e23712fc487f367e5f0`
- Focused QA receipt: 954 bytes, SHA-256 `adc55c5618d000bb264bf2d554497b9a3f0389ab02f277d82cb70417252c0e45`; records 6 passed and one existing pytest configuration warning.

The fast path is restricted to bound native panel nodes on the exact aligned `PandasData` shape. It checks the alignment marker and index identity, no feed filters, standard line-reader implementations, unbounded standard feed/input/output buffers, the target-feed relation, and the ordinary feed advance/tick hooks. Recursive readiness checks cover the panel's actual `instance.lines` and indicator descendants. For normally bound factors, `outputs[target]` proxies are references to those instance lines. Writes still use `line[0]`, so normal `LineBuffer` setter and binding propagation remain in the path.

The runonce callback preserves the same absolute grid order, windows, operator kernels, NaN/reason classifications, and infinity failures as the ordinary panel evaluator. Rolling windows begin at `index - period + 1`; rank keeps the original typed static-group partitioning and average-rank implementation. Paired strict failures are attributed to the current target with `once_via_next`; the focused regression asserts the third asset, date, phase, and original cause. Feed cursor/tick updates mirror standard `AbstractDataBase.advance` for the guarded unbounded feeds. The custom reader and per-feed `buflen` regressions both require fallback; the latter rejects an instance-shadowed method before the optimization makes its additional probe.

The 027 CLI explicitly defaults to `runonce=True` and `--runnext` selects `False`, while `_run_factor` retains its prior `False` default for direct callers. The CLI parity test exercises both modes and compares the emitted CSV bytes and summary fields.

No tests, imports, lint, or benchmarks were run during this review. The author QA receipt is focused synthetic evidence only; it does not establish the 500-asset performance target or the full-101 matrix.
