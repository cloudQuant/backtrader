"""Archive the completed G10a single-pair screen; never runs or imports examples."""
import hashlib
import json
import runpy
import sys
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
LIBRARY = ROOT / ".codex-tmp/iteration49_g10_panel_once_archive.py"
HELPERS = runpy.run_path(str(LIBRARY), run_name="iteration49_g10_archive_library")
DEST = HELPERS["DEST"]
RUNNER = HELPERS["RUNNER"]
VERIFIER = HELPERS["VERIFIER"]
EXAMPLES = HELPERS["EXAMPLES"]
ORDERS = HELPERS["ORDERS"]
EXPECTED_ENGINES = HELPERS["EXPECTED_ENGINES"]
SCREEN_STEM = "7col-g10a-panel-once-screen"
CONFIG_SHA256 = "44e6f5066160efd0301b75ebedcd0b2038f2625f94b6e7572a43029163d334a6"
CANDIDATE_MANIFEST_PIN = {
    "size_bytes": 1266,
    "sha256": "6cdfda7081ef4f15381254b9411a3430dea6b3c391ed2eda1faee1ba842335da",
}
EXECUTION_PINS = {
    ".codex-tmp/iteration49_g10_panel_once_pairs.py": {
        "size_bytes": 14662,
        "sha256": "64182c2d2dd426dc6a6d6c49415df421f50b0dd9bbccfc1dba1e945ad1d98a4c",
    },
    ".codex-tmp/iteration49_next_pairs.py": {
        "size_bytes": 12797,
        "sha256": "541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb",
    },
}
EVIDENCE_PINS = {
    ".codex-tmp/iteration49-panel-once-focused-qa-20261024.json": {
        "size_bytes": 954,
        "sha256": "adc55c5618d000bb264bf2d554497b9a3f0389ab02f277d82cb70417252c0e45",
    },
    ".codex-tmp/iteration49-panel-once-static-review.md": {
        "size_bytes": 2933,
        "sha256": "3394995bbfe42330e073b6830de0243b8e6879bfcdcb3e929f73febd7c604ff1",
    },
    "D:/temp/iteration49-g10-benchmark-engine-qa.log": {
        "size_bytes": 551,
        "sha256": "cac79022b1bc27119b05ae6c888fac5440f129632a8f716b2d4881a5a21180bf",
    },
    "D:/temp/iteration49-g10-027-runonce-cprofile-500-r1.py": {
        "size_bytes": 5438,
        "sha256": "ba0a4918897b1ba37d0fedead889c2879f1aa9100cecac9f7a3109031d104946",
    },
    "D:/temp/iteration49-g10-027-runonce-cprofile-500-r1.txt": {
        "size_bytes": 13726,
        "sha256": "e5b10956c65e3d2eac8fc0aaa5f7d55b2805df205903bab7b25b846d3053022e",
    },
    "D:/temp/iteration49-g10-027-runonce-cprofile-500-r1.pstats": {
        "size_bytes": 1025741,
        "sha256": "d8557e76e28715b70fb2893cbac9196c42e80e7342a12feb083b819ae16bae14",
    },
}

pin = HELPERS["pin"]
read = HELPERS["read"]
json_file = HELPERS["json_file"]
output = HELPERS["output"]
check_run = HELPERS["check_run"]
verify_one = HELPERS["verify_one"]
metric_summary = HELPERS["metric_summary"]
archive = HELPERS["archive"]


def norm(row):
    return {"sha256": row["sha256"].lower(), "size_bytes": row["size_bytes"]}


def load_frozen_candidate(root, cfg):
    manifest_raw = read(root / "MANIFEST.json")
    assert pin(manifest_raw) == CANDIDATE_MANIFEST_PIN
    manifest = json.loads(manifest_raw.decode("utf-8"))
    assert manifest.get("schema_version") == 1
    assert manifest.get("evidence") == "G10a frozen source copies for low-yield screen; diagnostic only"
    rows = {row["path"]: row for row in manifest["files"]}
    assert len(rows) == 6
    candidate = cfg["backtrader_candidate"]
    source_paths = set(candidate["allowed_delta"]) - set(candidate.get("preserved_unrelated", {}))
    test_paths = set(candidate["test_pins"]) & set(rows)
    assert set(rows) == source_paths | test_paths | {RUNNER}
    contents = {}
    for name, row in rows.items():
        rel = Path(*name.split("/"))
        assert not rel.is_absolute() and ".." not in rel.parts
        path = (root / rel).resolve(strict=True)
        path.relative_to(root.resolve(strict=True))
        raw = read(path)
        assert pin(raw) == {"size_bytes": row["size_bytes"], "sha256": row["sha256"].lower()}
        expected = (candidate["allowed_delta"].get(name) if name in source_paths else
                    candidate["test_pins"].get(name) if name in test_paths else
                    cfg["tool_pins"].get(RUNNER))
        assert expected and pin(raw) == norm(expected), name
        contents[name] = raw
    return manifest_raw, contents


def candidate_map(cfg, baseline_files):
    candidate = cfg["backtrader_candidate"]
    result = dict(baseline_files)
    overrides, deltas = candidate.get("checkout_raw_overrides", {}), candidate["allowed_delta"]
    assert not (set(overrides) & set(deltas))
    result.update({name: norm(row) for name, row in overrides.items()})
    result.update({name: norm(row) for name, row in deltas.items()})
    result[RUNNER] = norm(cfg["tool_pins"][RUNNER])
    assert len(result) == candidate["expected_file_count"] + 1
    return result


def single_pair_metric_summary(measurements, examples):
    """Summarize one paired sample without inventing a dispersion estimate."""
    result = {}
    for example in examples:
        assert sorted(measurements[example]) == [1]
        sample = measurements[example][1]
        row = {"actual_pairs": [1], "per_pair": measurements[example], "metrics": {}}
        for key in ("wall_s", "cpu_s", "peak_bytes"):
            a_value, b_value = sample["a"][key], sample["b"][key]
            ratio = b_value / a_value
            row["metrics"][key] = {
                "a_median": a_value,
                "b_median": b_value,
                "paired_b_over_a": [ratio],
                "median_b_over_a": ratio,
                "reduction_percent": 100.0 * (1.0 - ratio),
                "relative_dispersion_of_a_over_b": None,
                "dispersion_limit": 0.05 if example == "027" else None,
                "within_5pct_dispersion": None,
            }
        result[example] = row
    return result


def check_run_source(path, arm, example, cfg, bt_manifest, candidate_files, fc_manifest,
                     data_identity):
    result, metrics = check_run(path / "result.json", arm, example, cfg)
    assert result.get("runner_sha256") == norm(cfg["tool_pins"][RUNNER])
    assert result.get("data_identity_before") == result.get("data_identity_after")
    identity = result["data_identity_before"]
    assert (identity["universe"], identity["symbols"], identity["dates"], identity["grid_cells"]) == (
        "fixed500", 500, 243, 121500)
    assert identity["selection_sha256"] == cfg["data"]["selection_sha256"]
    assert identity["ordered_symbols_sha256"] and identity["files_sha256"]
    cli = result.get("example_cli_arguments") or []
    for flag, value in (("--data-dir", str(Path(cfg["data"]["root"]).resolve())),
                        ("--max-symbols", "500"), ("--factor-mode", "native")):
        assert cli.count(flag) == 1
        actual = cli[cli.index(flag) + 1]
        assert (str(Path(actual).resolve()) if flag == "--data-dir" else actual) == value
    if data_identity is not None:
        assert identity == data_identity
    if arm == "a":
        source = result["backtrader_source_before"]
        assert (source["kind"], source["commit"], source["manifest_sha256"]) == (
            "verified_snapshot_manifest_v1", cfg["backtrader_snapshot"]["commit"],
            cfg["backtrader_snapshot"]["manifest_sha256"])
        assert result["backtrader_files_before"] == bt_manifest["files"]
    else:
        source = result["backtrader_source_before"]
        candidate = cfg["backtrader_candidate"]
        assert (source["kind"], source["commit"], source["branch"]) == (
            "git_worktree", candidate["commit"], candidate["branch"])
        assert sorted(source["source_status"]) == sorted(candidate["result_source_status"])
        assert result["backtrader_files_before"] == candidate_files
    fincore = result["fincore_source_before"]
    assert (fincore["kind"], fincore["commit"], fincore["manifest_sha256"]) == (
        "verified_snapshot_manifest_v1", cfg["fincore_snapshot"]["commit"],
        cfg["fincore_snapshot"]["manifest_sha256"])
    assert result["fincore_files_before"] == fc_manifest["files"]
    return result, metrics, identity


def screen(config_path, frozen_root):
    config_path, frozen_root = config_path.resolve(strict=True), frozen_root.resolve(strict=True)
    assert pin(read(config_path))["sha256"] == CONFIG_SHA256
    cfg = json_file(config_path)
    assert cfg.get("schema_version") == 1 and cfg.get("workspace_root") == str(ROOT)
    assert cfg.get("pairs") == [1] and cfg.get("expected_engines") == EXPECTED_ENGINES
    assert cfg["output_prefix"] == "iteration49-g10-panel-once-500"
    for name, expected in cfg["tool_pins"].items():
        assert pin(read(ROOT / name)) == norm(expected), name
    for name, expected in EXECUTION_PINS.items():
        assert pin(read(ROOT / name)) == expected, name

    candidate_manifest_raw, frozen_files = load_frozen_candidate(frozen_root, cfg)
    bt_root = Path(cfg["backtrader_snapshot"]["root"]).resolve(strict=True)
    fc_root = Path(cfg["fincore_snapshot"]["root"]).resolve(strict=True)
    bt_manifest_raw, fc_manifest_raw = (read(bt_root / ".iteration49-source.json"),
                                        read(fc_root / ".iteration49-source.json"))
    assert hashlib.sha256(bt_manifest_raw).hexdigest() == cfg["backtrader_snapshot"]["manifest_sha256"]
    assert hashlib.sha256(fc_manifest_raw).hexdigest() == cfg["fincore_snapshot"]["manifest_sha256"]
    bt_manifest, fc_manifest = json.loads(bt_manifest_raw), json.loads(fc_manifest_raw)
    assert len(bt_manifest["files"]) == cfg["backtrader_candidate"]["expected_file_count"] == 621
    expected_candidate = candidate_map(cfg, bt_manifest["files"])

    qa_path = ROOT / ".codex-tmp/iteration49-panel-once-focused-qa-20261024.json"
    review_path = ROOT / ".codex-tmp/iteration49-panel-once-static-review.md"
    qa_raw, review_raw = read(qa_path), read(review_path)
    assert pin(qa_raw) == EVIDENCE_PINS[str(qa_path.relative_to(ROOT)).replace("\\", "/")]
    assert pin(review_raw) == EVIDENCE_PINS[str(review_path.relative_to(ROOT)).replace("\\", "/")]
    qa = json.loads(qa_raw)
    assert qa.get("exit_code") == 0 and "6 passed" in qa.get("result", "")
    for name, sha256 in qa.get("sha256", {}).items():
        assert hashlib.sha256(frozen_files[name]).hexdigest() == sha256
    selection = Path(cfg["data"]["selection"]).resolve(strict=True)
    assert hashlib.sha256(read(selection)).hexdigest() == cfg["data"]["selection_sha256"]

    root, prefix = Path(cfg["output_root"]).resolve(strict=True), cfg["output_prefix"]
    measurements, records, rawfiles, identity, data_files = (
        {name: {} for name in EXAMPLES}, [], {}, None, None)
    for example in EXAMPLES:
        for arm in ORDERS[1]:
            out = output(root, prefix, 1, arm, example)
            result, metrics, observed_identity = check_run_source(
                out, arm, example, cfg, bt_manifest, expected_candidate, fc_manifest, identity)
            identity = observed_identity if identity is None else identity
            current_data_files = result.get("data_files_before")
            assert current_data_files
            if data_files is not None:
                assert current_data_files == data_files
            data_files = current_data_files
            measurements[example].setdefault(1, {})[arm] = metrics
            records.append({"pair": 1, "arm": arm, "example": example, **metrics,
                            "expected_engine": result["expected_engine"],
                            "observed_engine": result["observed_engine"],
                            "phase_timers": result["phase_timers"],
                            "cli_arguments": result.get("example_cli_arguments", [])})
            rawfiles[f"raw/p1/{arm}-{example}/result.json"] = read(out / "result.json")
            rawfiles[f"raw/p1/{arm}-{example}/run.log"] = read(out.with_suffix(".log"))
            rawfiles[f"raw/p1/{arm}-{example}/summary.json"] = read(out / "example/summary.json")
    assert all(record["expected_engine"] == record["observed_engine"] for record in records)
    verification_path = root / f"{prefix}-p1-verification.json"
    _, verifier, _, _ = verify_one(1, root, prefix)
    rawfiles["raw/p1/verification.json"] = read(verification_path)
    rawfiles["raw/p1/verification.log"] = read(verification_path.with_suffix(".log"))

    external_evidence = {}
    for name, expected in EVIDENCE_PINS.items():
        if name.startswith("D:/temp/"):
            raw = read(name)
            assert pin(raw) == expected, name
            external_evidence[name] = raw
            member = Path(name).name
            rawfiles[f"diagnostics/{member}"] = raw

    sourcefiles = {
        "evidence/screen-archive-helper.py": read(__file__),
        "evidence/full-archive-helper.py": read(LIBRARY),
        "evidence/pair-launcher.py": read(ROOT / ".codex-tmp/iteration49_g10_panel_once_pairs.py"),
        "evidence/next-pairs.py": read(ROOT / ".codex-tmp/iteration49_next_pairs.py"),
        "evidence/pair1-config.json": read(config_path),
        "evidence/focused-qa.json": qa_raw,
        "evidence/static-review.md": review_raw,
        "evidence/root-benchmark-engine-qa.log": external_evidence[
            "D:/temp/iteration49-g10-benchmark-engine-qa.log"],
        "evidence/frozen-candidate/MANIFEST.json": candidate_manifest_raw,
        "baseline/backtrader/.iteration49-source.json": bt_manifest_raw,
        "baseline/fincore/.iteration49-source.json": fc_manifest_raw,
        "tools/verify_factor_examples_benchmark.py": read(ROOT / VERIFIER),
    }
    for name in set(cfg["backtrader_candidate"]["allowed_delta"]) - set(
            cfg["backtrader_candidate"].get("preserved_unrelated", {})):
        raw = read(bt_root / Path(*name.split("/")))
        assert pin(raw) == norm(bt_manifest["files"][name]), name
        sourcefiles[f"baseline/backtrader/{name}"] = raw
    sourcefiles.update({f"frozen-candidate/{name}": raw for name, raw in frozen_files.items()})
    sourcefiles["diagnostics/cprofile.py"] = external_evidence[
        "D:/temp/iteration49-g10-027-runonce-cprofile-500-r1.py"]
    assert not any(Path(name).suffix.lower() in {".csv", ".png", ".html"}
                   for name in (*sourcefiles, *rawfiles))

    metrics = single_pair_metric_summary(measurements, EXAMPLES)
    assert all(metrics[name]["actual_pairs"] == [1] for name in EXAMPLES)
    assert all(row["relative_dispersion_of_a_over_b"] is None
               for name in EXAMPLES for row in metrics[name]["metrics"].values())
    raw_blob, raw_meta = archive(rawfiles,
        "G10a six raw fixed-500 runs, logs, summaries, one full verifier and diagnostic files. "
        "cProfile is diagnostic only, not formal performance evidence.")
    source_blob, source_meta = archive(sourcefiles,
        "G10a source evidence and the exact six-file frozen candidate snapshot; no current live candidate bytes are used.")
    raw_meta["path"], source_meta["path"] = SCREEN_STEM + "-raw.zip", SCREEN_STEM + "-source.zip"
    summary = {
        "schema": "iteration49.g10a-panel-once-screen.v1",
        "status": "PASS_OUTPUT_EQUIVALENCE_SCREEN_ONLY",
        "counts": {"actual_processes": 6, "unique_comparisons": 3,
                   "complete_verifiers": 1, "partial_verifiers": 0},
        "config": {"path": str(config_path), **pin(read(config_path))},
        "fixed_500_data": {"root": cfg["data"]["root"], "selection": cfg["data"]["selection"],
                            "selection_sha256": cfg["data"]["selection_sha256"],
                            "identity": identity, "symbols": 500, "dates": 243},
        "candidate_snapshot": {"root": str(frozen_root),
                               "manifest": {"path": str(frozen_root / "MANIFEST.json"),
                                            **pin(candidate_manifest_raw)},
                               "files": [{"path": name, **pin(raw)}
                                         for name, raw in sorted(frozen_files.items())],
                               "unrelated_daily": cfg["backtrader_candidate"]["preserved_unrelated"],
                               "unrelated_daily_note": "the run identity records it as preserved and not executed; it is outside this six-file candidate copy"},
        "runs": records,
        "verifier": {"path": str(verification_path), **pin(read(verification_path)),
                     "status": verifier["status"], "valid": verifier["valid"],
                     "scope_complete": verifier["scope_complete"]},
        "metrics": metrics,
        "diagnostic_files": {name: pin(raw) for name, raw in external_evidence.items()},
        "raw_archive": raw_meta,
        "source_archive": source_meta,
        "limitations": [
            "One paired sample per example: dispersion/stability cannot be estimated and no stable speed gain is claimed.",
            "All three complete output comparisons passed; this is output equivalence evidence only.",
            "The included cProfile run is diagnostic and excluded from paired performance metrics.",
            "This screen does not establish the 80% speed target, <=1 GB full-universe memory target, or 5471-symbol acceptance.",
        ],
    }
    outputs = {raw_meta["path"]: raw_blob, source_meta["path"]: source_blob,
               SCREEN_STEM + "-pairs.json": json.dumps(
                   summary, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"}
    assert all(not (DEST / name).exists() for name in outputs)
    for name, content in outputs.items():
        with (DEST / name).open("xb") as stream:
            stream.write(content)
    print(json.dumps({"counts": summary["counts"], "metrics": metrics,
                      "archives": [raw_meta, source_meta]}, ensure_ascii=False, indent=2))


def main():
    assert len(sys.argv) == 4 and sys.argv[1] == "--screen-only", (
        "usage: script.py --screen-only PAIR1_CONFIG.json FROZEN_CANDIDATE_DIR")
    screen(Path(sys.argv[2]), Path(sys.argv[3]))


if __name__ == "__main__":
    main()
