G10c fixed-500 actual runs, logs, summaries and verifier receipts; pair-2/3 controls are reused, not recounted as runs.
