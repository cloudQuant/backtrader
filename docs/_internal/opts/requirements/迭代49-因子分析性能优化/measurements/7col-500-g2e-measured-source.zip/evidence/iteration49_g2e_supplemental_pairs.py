"""G2e pairs 4-5 for 025/026; reuse the frozen formal runner helpers."""
import hashlib, json, runpy
from pathlib import Path, PurePosixPath
ROOT = Path("D:/source_code/backtrader")
FORMAL = ROOT / ".codex-tmp/iteration49_g2e_formal.py"
FORMAL_SHA = "D582BF5B0F857F1FF87F94381E9DA3B795326087F482847390CFCD4CA2A2F8F3"
SELECTION = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(FORMAL).upper() == FORMAL_SHA
f = runpy.run_path(str(FORMAL), run_name="iteration49_g2e_reused")
check_sources, run_result, execute = f["check_sources"], f["run_result"], f["execute"]
TEMP, DATA, BT, FC_A, FC_B = (f[k] for k in ("TEMP", "DATA", "BT", "FC_A", "FC_B"))
def check():
    assert sha(FORMAL).upper() == FORMAL_SHA
    manifest = check_sources()
    assert sha(FORMAL).upper() == FORMAL_SHA
    return manifest
manifest = check()
control = {}
for arm in ("a", "b"):
    check()
    r = run_result(TEMP / f"iteration49-7col-g2e-p3-{arm}-027" / "result.json", arm, "027", manifest)
    assert r["data_identity_before"] == r["data_identity_after"]
    assert Path(r["data_root"]).resolve() == DATA.resolve()
    assert Path(r["selection_path"]).resolve() == SELECTION.resolve()
    control[arm] = r
reference = control["a"]
assert control["b"]["data_identity_before"] == reference["data_identity_before"]
assert control["b"]["data_files_before"] == reference["data_files_before"]
data_files = reference["data_files_before"]
def check_data():
    for name, pin in data_files.items():
        if name.startswith("selection:"):
            assert name == "selection:" + SELECTION.name
            path = SELECTION
        else:
            rel = PurePosixPath(name)
            assert not rel.is_absolute() and ".." not in rel.parts
            path = DATA.joinpath(*rel.parts)
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == pin["sha256"] and len(raw) == pin["size_bytes"]
for pair in (4, 5):
    order = ("b", "a") if pair == 4 else ("a", "b")
    for example in ("025", "026"):
        sources = {}
        for arm in order:
            check(); check_data()
            out = TEMP / f"iteration49-7col-g2e-p{pair}-{arm}-{example}"
            assert not out.exists(), out
            fc = FC_A if arm == "a" else FC_B
            print(f"START G2e supplemental pair={pair} arm={arm} example={example}", flush=True)
            execute(["scripts/benchmark_factor_examples.py", "--source-root", str(BT), "--fincore-root", str(fc),
                     "--data-root", str(DATA), "--example", example, "--profile", "full", "--output", str(out)],
                    out.with_suffix(".log"))
            r = run_result(out / "result.json", arm, example, manifest)
            assert r["data_identity_before"] == reference["data_identity_before"]
            assert r["data_identity_before"] == r["data_identity_after"] and r["data_files_before"] == data_files
            sources[arm] = r["fincore_source_before"]
            print(json.dumps({"pair": pair, "arm": arm, "example": example,
                              "wall_s": r["example_main_wall_ns"] / 1e9,
                              "cpu_s": r["example_main_process_cpu_ns"] / 1e9,
                              "peak_bytes": max(r["main_peak_working_set_bytes"], r["resource_peak_tree_rss_bytes"])}),
                  flush=True)
            check_data(); check()
        assert sources["a"]["source_content_sha256"] != sources["b"]["source_content_sha256"]
    verification = TEMP / f"iteration49-7col-g2e-p{pair}-verification.json"
    assert not verification.exists(), verification
    args = ["scripts/verify_factor_examples_benchmark.py", "--output", str(verification)]
    for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
        for ex in f["EXAMPLES"]:
            src_pair = 3 if ex == "027" else pair
            args.extend((flag, f"{ex}={TEMP}/iteration49-7col-g2e-p{src_pair}-{arm}-{ex}"))
    check(); check_data()
    execute(args, verification.with_suffix(".log"))
    verified = json.loads(verification.read_text(encoding="utf-8"))
    assert verified.get("status") == "PASS" and verified.get("scope_complete") is True
    check(); check_data()
    print(f"G2e supplemental pair {pair} COMPLETE OUTPUT PASS", flush=True)
