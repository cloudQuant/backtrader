#!/usr/bin/env python3
"""Archive one completed R3 stage and its compact public evidence; never an acceptance gate."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path, help="fixed500-stage.json or full-stage.json")
    parser.add_argument("analysis", type=Path)
    parser.add_argument("config", type=Path)
    parser.add_argument("launcher", type=Path, help="the exact R3 launcher")
    parser.add_argument("--output", required=True, type=Path, help="new ZIP under measurements/")
    args = parser.parse_args()

    receipt_path = args.receipt.resolve(strict=True)
    analysis_path, config_path = args.analysis.resolve(strict=True), args.config.resolve(strict=True)
    launcher_path = args.launcher.resolve(strict=True)
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if receipt.get("schema") not in ("iteration49.final-fixed500.v1", "iteration49.final-all.v1"):
        raise ValueError("unsupported R3 receipt")
    if digest(launcher_path.read_bytes()).lower() != str(config.get("launcher_sha256", "")).lower():
        raise ValueError("launcher bytes differ from config pin")
    workspace = Path(config["workspace_root"]).resolve(strict=True)
    archive_script = Path(__file__).resolve(strict=True)
    analysis_script = archive_script.with_name("iteration49_final_analysis.py").resolve(strict=True)
    members = {}

    def add(member, source):
        source = Path(source).resolve(strict=True)
        if member in members:
            if members[member] == source:
                return
            raise ValueError("conflicting ZIP member: " + member)
        members[member] = source

    def add_stage_file(source):
        source = Path(source).resolve(strict=True)
        relative = source.relative_to(receipt_path.parent).as_posix()
        add("stage/" + relative, source)

    def add_pinned_stage_file(source, expected_sha256):
        source = Path(source).resolve(strict=True)
        if digest(source.read_bytes()).lower() != str(expected_sha256).lower():
            raise ValueError("stage member differs from receipt hash: " + str(source))
        add_stage_file(source)

    add_stage_file(receipt_path)
    for row in receipt.get("runs", []):
        result_path = Path(row["result"]).resolve(strict=True)
        add_pinned_stage_file(result_path, row["sha256"])
        add_stage_file(result_path.parent.with_suffix(".log"))
    for row in receipt.get("verifications", []):
        verification = Path(row["path"]).resolve(strict=True)
        add_pinned_stage_file(verification, row["sha256"])
        add_stage_file(verification.with_suffix(".log"))

    def add_workspace_file(label, source):
        source = Path(source).resolve(strict=True)
        relative = source.relative_to(workspace).as_posix()
        add("workspace/" + relative, source)

    add_workspace_file("launcher", launcher_path)
    add_workspace_file("analysis", analysis_path)
    add_workspace_file("analysis-script", analysis_script)
    add_workspace_file("archive-script", archive_script)
    add_workspace_file("config", config_path)
    for name, expected in config.get("tool_pins", {}).items():
        tool = workspace.joinpath(*Path(name).parts).resolve(strict=True)
        raw = tool.read_bytes()
        if digest(raw).lower() != str(expected["sha256"]).lower() or len(raw) != expected["size_bytes"]:
            raise ValueError("pinned benchmark tool changed: " + name)
        add_workspace_file("tool", tool)

    manifest = {"schema": "iteration49.final-archive.v1",
                "members": [{"path": name, "size_bytes": source.stat().st_size,
                             "sha256": digest(source.read_bytes())}
                            for name, source in sorted(members.items())]}
    output = args.output.resolve()
    if output.parent.name != "measurements" or not output.parent.is_dir():
        raise ValueError("output parent must be the existing Iteration 49 measurements directory")
    with zipfile.ZipFile(output, mode="x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, source in sorted(members.items()):
            archive.write(source, arcname=name)
        archive.writestr("archive-manifest.json",
                         json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n")

    with zipfile.ZipFile(output, mode="r") as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC/readback failed")
        for row in manifest["members"]:
            raw = archive.read(row["path"])
            if len(raw) != row["size_bytes"] or digest(raw) != row["sha256"]:
                raise ValueError("ZIP member verification failed: " + row["path"])
        if "archive-manifest.json" not in archive.namelist():
            raise ValueError("archive manifest is missing")
    print("archive verified: %s (%d members)" % (output, len(manifest["members"]) + 1))


if __name__ == "__main__":
    main()
