#!/usr/bin/env python3
"""Serial Iteration 49 final pairs; config schema ``iteration49.final-pairs.v1``.

Stages are ``fixed500`` (AB/BA/AB, eighteen fresh processes) and ``all``
(AB, six fresh processes). The all stage requires the PASS receipt emitted by
the same-contract fixed500 stage. That receipt records source and output
integrity only; Root adjudicates runtime and memory performance separately.
``--preflight`` hashes inputs and snapshots without launching benchmark or
verifier. Config fields: workspace_root,
python_executable, launcher_sha256, tool_pins, snapshots (baseline and
candidate, each with backtrader/fincore root+commit+manifest_sha256), data_root,
selection (path+sha256), output_root, run_id, and stage; optional
``engine_027`` pins the baseline/candidate 027 engines (omission defaults both
to runnext); ``all`` also supplies fixed500_receipt (path+sha256).
"""
import argparse
import hashlib
import json
import re
import runpy
import subprocess
import sys
from pathlib import Path, PurePosixPath

EXAMPLES = ("025", "026", "027")
ORDERS = (("baseline", "candidate"), ("candidate", "baseline"), ("baseline", "candidate"))
ALL_MANIFEST = "7ac8fea0ceb547e010a139f4a17820f6207f38ab08c762cf19257a0f39ec2cfb"
ALL_CALENDAR = "ebffd7c7a5626a43ea54f5135c86fb0c8c554255e85ee09ba9bfc5e9da324ba1"
SELECTION = "14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc"
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"


def pin(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}


def fingerprint(value):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def within(path, root):
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def snapshot(spec, package, source_state, example_dirs):
    root = Path(spec["root"]).resolve(strict=True)
    if pin(root / ".iteration49-source.json")["sha256"] != spec["manifest_sha256"].lower():
        raise ValueError("snapshot manifest pin mismatch: " + str(root))
    scopes = tuple("examples/backtest/" + name for name in example_dirs) if package == "backtrader" else ()
    identity, files = source_state(root, package, scopes)
    if (identity.get("manifest_sha256"), identity.get("commit")) != (
            spec["manifest_sha256"].lower(), spec["commit"].lower()):
        raise ValueError("runner snapshot fingerprint mismatch: " + str(root))
    return {"root": root, "identity": identity, "files": files}


def snapshots(cfg, source_state, example_dirs):
    return {arm: {pkg: snapshot(cfg["snapshots"][arm][pkg], pkg, source_state, example_dirs)
                  for pkg in ("backtrader", "fincore")}
            for arm in ("baseline", "candidate")}


def tools(cfg):
    workspace = Path(cfg["workspace_root"]).resolve(strict=True)
    pins = cfg["tool_pins"]
    if set(pins) != {RUNNER, VERIFIER}:
        raise ValueError("pin exactly the runner and verifier")
    paths = {}
    for name, expected in pins.items():
        path = workspace.joinpath(*PurePosixPath(name).parts).resolve(strict=True)
        if not within(path, workspace):
            raise ValueError("runner/verifier must be in the workspace")
        paths[name] = path
    recheck_tools(cfg, paths)
    return paths


def recheck_tools(cfg, paths):
    for name, path in paths.items():
        expected = cfg["tool_pins"][name]
        if pin(path) != {"sha256": expected["sha256"].lower(), "size_bytes": expected["size_bytes"]}:
            raise ValueError("tool changed: " + name)


def check_launcher(cfg):
    if pin(Path(__file__).resolve(strict=True))["sha256"] != cfg["launcher_sha256"].lower():
        raise ValueError("launcher pin mismatch")


def data_state(cfg, helper, universe):
    if not callable(helper):
        raise ValueError("pinned runner has no _data_state helper")
    root, selection = Path(cfg["data_root"]).resolve(strict=True), None
    if universe == "fixed500":
        selection = Path(cfg["selection"]["path"]).resolve(strict=True)
        if pin(selection)["sha256"] != SELECTION or cfg["selection"]["sha256"].lower() != SELECTION:
            raise ValueError("fixed500 selection pin mismatch")
    identity, files = helper(root, selection, universe)
    n = 5471 if universe == "all" else 500
    csvs = sum(not name.startswith(("_metadata/", "selection:")) for name in files)
    if (identity.get("files_sha256") != fingerprint(files)
            or files.get("_metadata/manifest.json", {}).get("sha256") != ALL_MANIFEST
            or files.get("_metadata/observed_calendar.csv", {}).get("sha256") != ALL_CALENDAR
            or (identity.get("universe"), identity.get("symbols"), identity.get("dates"), identity.get("grid_cells"))
            != (universe, n, 243, n * 243) or (csvs, len(files)) != (n, n + (2 if universe == "all" else 3))):
        raise ValueError("input universe, metadata, or CSV pin set is invalid")
    return identity, files


def configured_027_engines(cfg):
    value = cfg.get("engine_027")
    if value is None:
        return {"baseline": "runnext", "candidate": "runnext"}
    if not isinstance(value, dict) or set(value) != {"baseline", "candidate"}:
        raise ValueError("engine_027 must contain exactly baseline and candidate")
    if value["baseline"] != "runnext" or value["candidate"] not in ("runnext", "runonce"):
        raise ValueError("027 baseline is fixed to runnext; candidate must be runnext or runonce")
    return {"baseline": "runnext", "candidate": value["candidate"]}


def contract(cfg, snaps, engine_027):
    return {"snapshots": {a: {p: s["identity"] for p, s in row.items()} for a, row in snaps.items()},
            "tool_pins": cfg["tool_pins"], "launcher_sha256": cfg["launcher_sha256"].lower(),
            "workspace_root": str(Path(cfg["workspace_root"]).resolve()),
            "data_root": str(Path(cfg["data_root"]).resolve()), "selection": cfg["selection"],
            "all_manifest": ALL_MANIFEST, "all_calendar": ALL_CALENDAR, "examples": EXAMPLES,
            "engine_027": engine_027}


def check_origins(r, arm, example, snaps):
    bt, fc = snaps[arm]["backtrader"], snaps[arm]["fincore"]
    env = r.get("environment") or {}
    for name, snap, rel in (("backtrader_origin", bt, "backtrader/__init__.py"),
                            ("fincore_origin", fc, "fincore/__init__.py")):
        if Path(env.get(name, "")).resolve(strict=True) != (snap["root"] / rel).resolve() or rel not in snap["files"]:
            raise ValueError("loaded package origin differs from assigned snapshot: " + name)
    found = set()
    for key in ("loaded_module_origins_before_main", "loaded_module_origins_after_main"):
        for name, value in (r.get(key) or {}).items():
            source = kind = None
            if name == "backtrader" or name.startswith("backtrader."):
                source, root, kind = bt, bt["root"] / "backtrader", "backtrader"
            elif name == "fincore" or name.startswith("fincore."):
                source, root, kind = fc, fc["root"] / "fincore", "fincore"
            elif name.startswith("_iteration49_example_"):
                source, root, kind = bt, bt["root"] / "examples/backtest", "example"
            if source is not None:
                path = Path(value).resolve(strict=True)
                if not within(path, root) or path.relative_to(source["root"]).as_posix() not in source["files"]:
                    raise ValueError("loaded module escaped assigned snapshot: " + name)
                found.add(kind)
    if found != {"backtrader", "fincore", "example"}:
        raise ValueError("result omitted a source origin")


def validate_run(path, arm, ex, cfg, snaps, data, universe, runner_pin, expected_engine):
    r = json.loads(path.read_text(encoding="utf-8"))
    n = 5471 if universe == "all" else 500
    schema = "iteration49.benchmark-run.v2" if universe == "all" else "iteration49.benchmark-run.v1"
    if (r.get("schema"), r.get("input_universe"), r.get("status"), r.get("profile"), r.get("example"),
            r.get("runner_exit_code"), r.get("example_exit_code")) != (schema, universe, "COMPLETED", "full", ex, 0, 0):
        raise ValueError("benchmark result did not complete: " + str(path))
    if (r.get("runner_sha256"), r.get("source_or_input_changes"), r.get("summary_check_errors")) != (runner_pin, [], []):
        raise ValueError("runner source/input postcheck failed: " + str(path))
    summary = r.get("summary") or {}
    if (r.get("expected_engine"), summary.get("status"), summary.get("symbols"), summary.get("dates"),
            summary.get("factor_mode"), summary.get("factor_calculation")) != (
            expected_engine, "COMPLETED", n, 243, "native", "RAN"):
        raise ValueError("unexpected engine or dimensions: " + str(path))
    if ex == "027" and "engine" in summary and summary.get("engine") != expected_engine:
        raise ValueError("027 summary engine differs from its selected arm engine: " + str(path))
    installed = r.get("phase_targets_installed")
    if not isinstance(installed, dict) or any(
            installed.get("engine_" + name) is not True for name in ("runnext", "runonce")):
        raise ValueError("both Cerebro engine timers must be installed: " + str(path))
    timers = r.get("phase_timers")
    if not isinstance(timers, dict):
        raise ValueError("engine phase timers are missing: " + str(path))
    engine_calls = {}
    for name in ("runnext", "runonce"):
        row = timers.get("engine_" + name)
        calls = 0 if row is None else row.get("calls") if isinstance(row, dict) else None
        if type(calls) is not int or calls < 0:
            raise ValueError("engine timer call count is malformed: " + str(path))
        engine_calls[name] = calls
    if [name for name, calls in engine_calls.items() if calls > 0] != [expected_engine]:
        raise ValueError("observed engine timer does not match the selected arm engine: " + str(path))
    if (ex == "027" and summary.get("cells") != n * 243) or any((summary.get("broker") or {}).get(k) != 0
                                                                  for k in ("submit", "cancel")):
        raise ValueError("027 cells or broker counters invalid")
    identity, files = data
    if (r.get("data_identity_before"), r.get("data_identity_after"), r.get("data_files_before")) != (identity, identity, files):
        raise ValueError("run data fingerprint differs from preflight")
    selection = str(Path(cfg["selection"]["path"]).resolve()) if universe == "fixed500" else None
    if (Path(r["data_root"]).resolve(), r.get("selection_path")) != (Path(cfg["data_root"]).resolve(), selection):
        raise ValueError("run used a different data root or selection")
    for pkg in ("backtrader", "fincore"):
        s = snaps[arm][pkg]
        if r.get(pkg + "_files_before") != s["files"] or r.get(pkg + "_source_before") != s["identity"] \
                or r.get(pkg + "_source_after") != s["identity"]:
            raise ValueError("source map/fingerprint differs from assigned snapshot: " + pkg)
    args = r.get("example_cli_arguments") or []
    for flag, value in (("--data-dir", str(Path(cfg["data_root"]).resolve())),
                        ("--max-symbols", str(n)), ("--factor-mode", "native")):
        if args.count(flag) != 1 or args[args.index(flag) + 1] != value:
            raise ValueError("example arguments differ from the requested run")
    expected_engine_args = ["runonce"] if ex == "027" and arm == "candidate" \
        and expected_engine == "runonce" else []
    engine_arg_positions = [i for i, item in enumerate(args) if item == "--engine"]
    if len(engine_arg_positions) != len(expected_engine_args) or any(
            i + 1 >= len(args) for i in engine_arg_positions):
        raise ValueError("027 engine CLI argument differs from the selected arm engine")
    if [args[i + 1] for i in engine_arg_positions] != expected_engine_args:
        raise ValueError("027 engine CLI argument differs from the selected arm engine")
    if "--report" not in args:
        raise ValueError("full report output was not requested")
    metrics = (r.get("example_main_wall_ns"), r.get("example_main_process_cpu_ns"),
               r.get("main_peak_working_set_bytes"), r.get("resource_peak_tree_rss_bytes"))
    if any(type(value) is not int or value <= 0 for value in metrics):
        raise ValueError("benchmark timing or memory metrics are invalid")
    check_origins(r, arm, ex, snaps)
    return r


def invoke(argv, log, workspace):
    with log.open("xb") as out:
        proc = subprocess.run([sys.executable, *map(str, argv)], cwd=workspace, stdout=out,
                              stderr=subprocess.STDOUT)
    if proc.returncode:
        raise RuntimeError("child exit %d; inspect %s" % (proc.returncode, log))


def emit(path, value):
    with path.open("xb") as out:
        out.write((json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode())


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", required=True, type=Path)
    ap.add_argument("--preflight", action="store_true")
    args = ap.parse_args()
    config_path, cfg = args.config.resolve(strict=True), None
    config_pin = pin(config_path)
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    if cfg.get("schema") != "iteration49.final-pairs.v1" or cfg.get("stage") not in ("fixed500", "all"):
        raise ValueError("unsupported config")
    engine_027 = configured_027_engines(cfg)
    if Path(sys.executable).resolve() != Path(cfg["python_executable"]).resolve():
        raise ValueError("interpreter differs from config")
    check_launcher(cfg)
    workspace = Path(cfg["workspace_root"]).resolve(strict=True)
    if not within(Path(__file__).resolve(strict=True), workspace):
        raise ValueError("launcher must be in the pinned workspace")
    tool_files = tools(cfg)
    recheck_tools(cfg, tool_files)
    helpers = runpy.run_path(str(tool_files[RUNNER]), run_name="iteration49_final_readonly_helpers")
    source_state, data_helper = helpers.get("_source_state"), helpers.get("_data_state")
    if not callable(source_state) or not callable(data_helper):
        raise ValueError("pinned runner lacks read-only source/data helpers")
    example_dirs = tuple(helpers["EXAMPLES"].values())
    snaps = snapshots(cfg, source_state, example_dirs)
    if any(within(path, s["root"]) for path in tool_files.values()
           for arm in snaps.values() for s in arm.values()):
        raise ValueError("runner/verifier must be outside every source snapshot")
    selection = Path(cfg["selection"]["path"]).resolve(strict=True)
    if pin(selection)["sha256"] != SELECTION or cfg["selection"]["sha256"].lower() != SELECTION:
        raise ValueError("selection pin mismatch")
    universe = "fixed500" if cfg["stage"] == "fixed500" else "all"
    data = data_state(cfg, data_helper, universe)
    contract_sha = fingerprint(contract(cfg, snaps, engine_027))
    output_root = Path(cfg["output_root"]).resolve(strict=True)
    run_id = cfg["run_id"]
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", run_id):
        raise ValueError("run_id must be unique safe path text")
    run_dir = output_root / run_id
    protected = [workspace, Path(cfg["data_root"]).resolve(), *(s["root"] for a in snaps.values() for s in a.values())]
    if any(within(output_root, root) for root in protected) or run_dir.exists():
        raise ValueError("output root is protected or run_id already exists")
    if universe == "all":
        gate = cfg["fixed500_receipt"]
        receipt = Path(gate["path"]).resolve(strict=True)
        if (pin(receipt)["sha256"] != gate["sha256"].lower() or not within(receipt, output_root)
                or receipt.name != "fixed500-stage.json" or receipt.parent.parent != output_root):
            raise ValueError("fixed500 receipt pin/location mismatch")
        prior = json.loads(receipt.read_text(encoding="utf-8"))
        if (prior.get("schema"), prior.get("status"), prior.get("contract_sha256"), prior.get("verified_pairs"),
                prior.get("acceptance_scope"), len(prior.get("runs", [])), len(prior.get("verifications", []))) != (
                "iteration49.final-fixed500.v1", "PASS", contract_sha, [1, 2, 3],
                "SOURCE_AND_OUTPUT_INTEGRITY_ONLY; PERFORMANCE_ADJUDICATED_BY_ROOT", 18, 3):
            raise ValueError("full stage requires a same-contract passing 500 receipt")
        if any(row.get("pair") != i for i, row in enumerate(prior["verifications"], 1)):
            raise ValueError("500 receipt pair order invalid")
        expected_rows = [(p, a, e) for p in (1, 2, 3) for e in EXAMPLES for a in ORDERS[p - 1]]
        if [(r.get("pair"), r.get("arm"), r.get("example")) for r in prior["runs"]] != expected_rows:
            raise ValueError("500 receipt run order incomplete")
        if any(v.get("status") != "PASS" for v in prior["verifications"]):
            raise ValueError("500 receipt contains an unverified pair")
        d = prior.get("data_identity", {})
        if (d.get("universe"), d.get("symbols"), d.get("dates"), d.get("grid_cells"),
                d.get("selection_sha256")) != ("fixed500", 500, 243, 121500, SELECTION):
            raise ValueError("500 receipt data identity invalid")
        prior_files = prior.get("data_files")
        selection_key = "selection:" + selection.name
        if (not isinstance(prior_files, dict) or len(prior_files) != 503
                or prior_files.get(selection_key) != pin(selection)
                or d.get("files_sha256") != fingerprint(prior_files)):
            raise ValueError("500 receipt does not bind its input file map")
        selected_files = {name: value for name, value in prior_files.items() if not name.startswith("selection:")}
        if (len(selected_files) != 502
                or sum(not name.startswith("_metadata/") for name in selected_files) != 500
                or any(data[1].get(name) != value for name, value in selected_files.items())):
            raise ValueError("500 receipt inputs differ from the current full-universe data")
    else:
        receipt = run_dir / "fixed500-stage.json"
    if args.preflight:
        check_launcher(cfg); recheck_tools(cfg, tool_files)
        if pin(config_path) != config_pin:
            raise ValueError("config changed during preflight")
        print("PREFLIGHT PASS %s %s" % (universe, contract_sha))
        return
    run_dir.mkdir()
    pair_ids = (1, 2, 3) if universe == "fixed500" else (1,)
    all_rows, verifications = [], []
    for pair in pair_ids:
        order = ORDERS[pair - 1] if universe == "fixed500" else ("baseline", "candidate")
        for ex in EXAMPLES:
            for arm in order:
                check_launcher(cfg); recheck_tools(cfg, tool_files)
                if pin(config_path) != config_pin:
                    raise ValueError("config changed during the run")
                selected = snaps[arm]
                out = run_dir / ("%s-p%d-%s-%s" % (universe, pair, arm, ex))
                engine = "runonce" if ex != "027" else engine_027[arm]
                invoke([tool_files[RUNNER], "--source-root", selected["backtrader"]["root"],
                        "--fincore-root", selected["fincore"]["root"], "--data-root", cfg["data_root"],
                        "--universe", universe, "--example", ex, "--profile", "full", "--output", out,
                        *( ("--selection", cfg["selection"]["path"]) if universe == "fixed500" else () ),
                        *( ("--engine", "runonce") if ex == "027" and arm == "candidate"
                           and engine_027["candidate"] == "runonce" else () )],
                       out.with_suffix(".log"), workspace)
                check_launcher(cfg); recheck_tools(cfg, tool_files)
                if pin(config_path) != config_pin:
                    raise ValueError("config changed during the run")
                runner_pin = {"sha256": cfg["tool_pins"][RUNNER]["sha256"].lower(),
                              "size_bytes": cfg["tool_pins"][RUNNER]["size_bytes"]}
                r = validate_run(out / "result.json", arm, ex, cfg, snaps, data, universe, runner_pin, engine)
                all_rows.append({"pair": pair, "arm": arm, "example": ex,
                                 "result": str(out / "result.json"), "sha256": pin(out / "result.json")["sha256"],
                                 "wall_ns": r["example_main_wall_ns"], "cpu_ns": r["example_main_process_cpu_ns"],
                                 "peak_rss_bytes": max(r["main_peak_working_set_bytes"], r["resource_peak_tree_rss_bytes"])})
                print(json.dumps({"event": "run_validated", "universe": universe, "pair": pair,
                                  "arm": arm, "example": ex,
                                  "wall_s": r["example_main_wall_ns"] / 1e9,
                                  "cpu_s": r["example_main_process_cpu_ns"] / 1e9,
                                  "peak_bytes": all_rows[-1]["peak_rss_bytes"]}, sort_keys=True), flush=True)
        verify = run_dir / ("%s-p%d-verification.json" % (universe, pair))
        command = [tool_files[VERIFIER], "--universe", universe, "--data-root", cfg["data_root"], "--output", verify]
        if universe == "fixed500":
            command.extend(("--selection", cfg["selection"]["path"]))
        if engine_027["candidate"] == "runonce":
            command.append("--allow-027-engine-change")
        for arm, flag in (("baseline", "--baseline"), ("candidate", "--candidate")):
            for ex in EXAMPLES:
                command.extend((flag, "%s=%s" % (ex, run_dir / ("%s-p%d-%s-%s" % (universe, pair, arm, ex)))))
        check_launcher(cfg); recheck_tools(cfg, tool_files)
        invoke(command, verify.with_suffix(".log"), workspace)
        check_launcher(cfg); recheck_tools(cfg, tool_files)
        v = json.loads(verify.read_text(encoding="utf-8"))
        expected_schema = "iteration49.fixed500_output_verification.v1" if universe == "fixed500" else "iteration49.all_output_verification.v1"
        if (v.get("schema"), v.get("status"), v.get("valid"), v.get("scope_complete")) != (expected_schema, "PASS", True, True):
            raise ValueError("full-output verifier failed: " + str(verify))
        if any(set(v["runs"][arm]) != set(EXAMPLES) or any(not v["runs"][arm][e]["valid"] for e in EXAMPLES)
               for arm in ("baseline", "candidate")):
            raise ValueError("verifier did not pass all three examples")
        verifications.append({"pair": pair, "status": "PASS", "path": str(verify), "sha256": pin(verify)["sha256"]})
        if snapshots(cfg, source_state, example_dirs) != snaps or data_state(cfg, data_helper, universe) != data:
            raise ValueError("source snapshots or full CSV input pins changed")
        print(json.dumps({"event": "pair_verified", "universe": universe, "pair": pair,
                          "status": "PASS", "verification_sha256": verifications[-1]["sha256"],
                          "source_data_postcheck": "PASS"}, sort_keys=True), flush=True)
    result = {"status": "PASS", "acceptance_scope": "SOURCE_AND_OUTPUT_INTEGRITY_ONLY; PERFORMANCE_ADJUDICATED_BY_ROOT",
              "contract_sha256": contract_sha, "runs": all_rows, "data_files": data[1],
              "verifications": verifications, "data_identity": data[0]}
    if universe == "fixed500":
        result.update({"schema": "iteration49.final-fixed500.v1", "verified_pairs": [1, 2, 3]})
        emit(receipt, result)
    else:
        result["schema"] = "iteration49.final-all.v1"
        emit(run_dir / "full-stage.json", result)
    print("STAGE PASS universe=%s runs=%d verifications=%d" % (universe, len(all_rows), len(verifications)))


if __name__ == "__main__":
    main()
