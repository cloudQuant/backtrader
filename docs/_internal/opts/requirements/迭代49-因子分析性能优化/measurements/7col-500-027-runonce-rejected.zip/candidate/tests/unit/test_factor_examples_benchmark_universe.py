"""Small contract tests for the optional full-universe benchmark mode."""

import csv
import hashlib
import importlib.util
import json
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[2]


def _load_script(name, relative):
    path = ROOT / relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _write_inputs(root, runner, verifier, monkeypatch):
    metadata = root / "_metadata"
    metadata.mkdir(parents=True)
    rows = []
    for symbol, filename in (("zeta", "zeta.csv"), ("alpha", "alpha.csv")):
        content = ("trade_time,open,high,low,close,volume,amount\n"
                   "2025-01-02 15:00:00,1,2,1,2,3,4\n").encode("utf-8")
        (root / filename).write_bytes(content)
        rows.append({"symbol": symbol, "file": filename,
                     "sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)})
    dates = ["2025-01-02", "2025-01-03"]
    calendar_path = metadata / "observed_calendar.csv"
    with calendar_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("trade_date", "last_trade_time"))
        writer.writeheader()
        for date in dates:
            writer.writerow({"trade_date": date, "last_trade_time": date + " 15:00:00"})
    manifest = {
        "status": "complete",
        "output": {"symbols": rows, "symbol_count": 2, "csv_file_count": 2,
                   "observed_dates": 2, "date_range": {"first": dates[0], "last": dates[-1]}},
    }
    manifest_path = metadata / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, separators=(",", ":")), encoding="utf-8")
    manifest_sha = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    calendar_sha = hashlib.sha256(calendar_path.read_bytes()).hexdigest()
    monkeypatch.setattr(runner, "ALL_SYMBOLS", 2)
    monkeypatch.setattr(runner, "DATES", 2)
    monkeypatch.setattr(runner, "ALL_MANIFEST_SHA256", manifest_sha)
    monkeypatch.setattr(runner, "ALL_CALENDAR_SHA256", calendar_sha)
    monkeypatch.setattr(verifier, "EXPECTED_ALL_SYMBOL_COUNT", 2)
    monkeypatch.setattr(verifier, "EXPECTED_ALL_DATE_COUNT", 2)
    monkeypatch.setattr(verifier, "EXPECTED_ALL_MANIFEST_SHA256", manifest_sha)
    monkeypatch.setattr(verifier, "EXPECTED_ALL_CALENDAR_SHA256", calendar_sha)
    return rows


def test_universe_cli_preserves_fixed500_default_and_has_full_opt_in():
    runner = _load_script("factor_benchmark_universe_runner", "scripts/benchmark_factor_examples.py")
    verifier = _load_script("factor_benchmark_universe_verifier", "scripts/verify_factor_examples_benchmark.py")
    runner_default = runner._parser().parse_args([
        "--fincore-root", "fincore", "--data-root", "data", "--example", "025", "--output", "out"
    ])
    verifier_default = verifier._parser().parse_args(["--run", "025=out"])
    assert runner_default.universe == "fixed500"
    assert verifier_default.universe == "fixed500"
    assert runner._parser().parse_args([
        "--fincore-root", "fincore", "--data-root", "data", "--example", "025", "--output", "out",
        "--universe", "all",
    ]).universe == "all"
    assert verifier._parser().parse_args(["--run", "025=out", "--universe", "all"]).universe == "all"


def test_full_universe_loads_manifest_order_and_validates_each_csv(tmp_path, monkeypatch):
    runner = _load_script("factor_benchmark_universe_runner_data", "scripts/benchmark_factor_examples.py")
    verifier = _load_script("factor_benchmark_universe_verifier_data", "scripts/verify_factor_examples_benchmark.py")
    _write_inputs(tmp_path, runner, verifier, monkeypatch)

    runner_identity, runner_pins = runner._data_state(tmp_path, None, "all")
    verified = verifier._load_all_inputs(tmp_path)
    assert runner_identity["universe"] == verified["universe"] == "all"
    assert runner_identity["symbols"] == verified["source_symbol_count"] == 2
    assert runner_identity["dates"] == len(verified["dates"]) == 2
    assert runner_identity["grid_cells"] == verified["grid_cells"] == 4
    assert verified["symbols"] == ["zeta", "alpha"]
    assert set(runner_pins) == {
        "_metadata/manifest.json", "_metadata/observed_calendar.csv", "zeta.csv", "alpha.csv"
    }

    (tmp_path / "alpha.csv").write_text("changed\n", encoding="utf-8")
    with pytest.raises(ValueError, match="CSV pin mismatch"):
        runner._data_state(tmp_path, None, "all")
    with pytest.raises(verifier.VerificationError, match="full-manifest pin"):
        verifier._load_all_inputs(tmp_path)


def test_dynamic_evaluation_counts_match_selected_grid_size():
    verifier = _load_script("factor_benchmark_universe_counts", "scripts/verify_factor_examples_benchmark.py")
    fixed = {"symbols": [None] * 500, "dates": [None] * 243}
    full = {"symbols": [None] * 5471, "dates": [None] * 243}
    assert verifier._grid_cell_count(fixed) == 121500
    assert verifier._grid_cell_count(full) == 1329453
    assert verifier._expected_evaluation_counts("025", fixed) == {
        "targets": 500, "study_dates": 243, "panel_cells": 121500,
        "factors": 1, "signal_rows": 121500, "label_rows": 364500,
    }
    assert verifier._expected_evaluation_counts("026", full) == {
        "targets": 5471, "study_dates": 243, "panel_cells": 1329453,
        "factors": 3, "signal_rows": 3988359, "label_rows": 3988359,
    }
    runner = _load_script("factor_benchmark_universe_command", "scripts/benchmark_factor_examples.py")
    command = runner._example_cli_arguments("027", "full", Path("out"), Path("data"), 5471)
    assert command[command.index("--max-symbols") + 1] == "5471"

def test_027_engine_screen_is_opt_in_and_verifier_change_is_narrow():
    runner = _load_script("factor_runonce_screen_runner", "scripts/benchmark_factor_examples.py")
    verifier = _load_script("factor_runonce_screen_verifier", "scripts/verify_factor_examples_benchmark.py")
    default_args = runner._parser().parse_args([
        "--fincore-root", "fincore", "--data-root", "data",
        "--example", "027", "--output", "out",
    ])
    once_args = runner._parser().parse_args([
        "--fincore-root", "fincore", "--data-root", "data",
        "--example", "027", "--output", "out", "--engine", "runonce",
    ])
    assert default_args.engine is None
    assert runner._expected_engine("027", default_args.engine) == "runnext"
    assert runner._expected_engine("027", once_args.engine) == "runonce"
    with pytest.raises(ValueError, match="only supported for --example 027"):
        runner._expected_engine("025", "runonce")
    default_command = runner._example_cli_arguments(
        "027", "full", Path("out"), Path("data"), 500
    )
    once_command = runner._example_cli_arguments(
        "027", "full", Path("out"), Path("data"), 500, "runonce"
    )
    assert "--engine" not in default_command
    assert once_command[once_command.index("--engine") + 1] == "runonce"
    assert verifier._parser().parse_args([
        "--baseline", "025=a", "--baseline", "026=b", "--baseline", "027=c",
        "--candidate", "025=d", "--candidate", "026=e", "--candidate", "027=f",
        "--allow-027-engine-change",
    ]).allow_027_engine_change is True


def test_027_cross_engine_verification_changes_no_values_ids_or_reports():
    verifier = _load_script("factor_runonce_screen_pair_verifier", "scripts/verify_factor_examples_benchmark.py")

    def side(engine, *, value=1.25, evaluation_id="stable", report_payload="same"):
        return {
            "valid": True,
            "internal": {
                "engine_provenance": "legacy_timer" if engine == "runnext" else "summary",
                "normalized_summary": {
                    "status": "COMPLETED", "factor_mode": "native", "engine": engine,
                },
                "evaluation": {
                    "evaluation_id": evaluation_id, "result_fingerprint": "fingerprint-v1",
                },
                "factor": {
                    "columns": ["time", "asset", "alpha003"],
                    "timestamps": ["2025-01-02T00:00:00Z|bj000001"],
                    "rows": 1, "values": {"alpha003": [value]},
                },
                "report_semantics": {
                    "models": {"alpha003": {
                        "payload_json": report_payload, "semantic_digest": "digest-v1",
                    }},
                    "html": {"alpha003": {
                        "chart_data_json": "chart-v1", "tables": [],
                    }},
                },
            },
        }

    baseline, candidate = side("runnext"), side("runonce")
    assert not verifier._compare_pair("027", baseline, candidate)["valid"]
    allowed = verifier._compare_pair(
        "027", baseline, candidate, allow_027_engine_change=True
    )
    assert allowed["valid"] and allowed["engine_change_allowed"]
    assert allowed["engines"] == {"baseline": "runnext", "candidate": "runonce"}
    assert allowed["engine_provenance"] == {
        "baseline": "legacy_timer", "candidate": "summary"
    }

    changed_value = verifier._compare_pair(
        "027", baseline, side("runonce", value=1.5), allow_027_engine_change=True
    )
    assert not changed_value["valid"]
    changed_id = verifier._compare_pair(
        "027", baseline, side("runonce", evaluation_id="changed"),
        allow_027_engine_change=True,
    )
    assert not changed_id["valid"]
    changed_report = verifier._compare_pair(
        "027", baseline, side("runonce", report_payload="changed"),
        allow_027_engine_change=True,
    )
    assert not changed_report["valid"]




def _load_027_benchmark_result_fixture():
    # Trimmed from the public G6 500x243 result to preserve the real producer schema.
    fixture = ROOT / "tests" / "fixtures" / "research" / "iteration49_g6_027_result_engine.json"
    return json.loads(fixture.read_text(encoding="utf-8"))


def _write_027_benchmark_result(verifier, root, summary, inputs, *, engine="runnext", timer_calls=None, cli_engine=None):
    root.mkdir(parents=True)
    result = _load_027_benchmark_result_fixture()
    result["input_universe"] = inputs["universe"]
    result["expected_engine"] = engine
    result["summary"] = summary
    observed_rows = timer_calls or {
        "runonce": 1 if engine == "runonce" else 0,
        "runnext": 1 if engine == "runnext" else 0,
    }
    timer_template = next(iter(result["phase_timers"].values()))
    result["phase_timers"] = {
        "engine_" + name: {**timer_template, "calls": count}
        for name, count in observed_rows.items()
        if count > 0
    }
    arguments = list(result["example_cli_arguments"])
    for index, item in enumerate(arguments[:-1]):
        if item == "--output-dir":
            arguments[index + 1] = str(root)
        elif item == "--data-dir":
            arguments[index + 1] = "data"
    if cli_engine is not None:
        arguments.extend(("--engine", cli_engine))
    result["example_cli_arguments"] = arguments
    benchmark_root = root.parent
    (benchmark_root / "result.json").write_text(json.dumps(result), encoding="utf-8")
    return result


def _027_fixed_inputs():
    result = _load_027_benchmark_result_fixture()
    data = result["data_identity_before"]
    return {
        "universe": result["input_universe"],
        "symbols": [None] * data["symbols"],
        "dates": [None] * data["dates"],
        "ordered_symbols_sha256": data["ordered_symbols_sha256"],
        "selection_sha256": data["selection_sha256"],
    }

def test_027_legacy_summary_engine_uses_a_single_timer_receipt(tmp_path):
    verifier = _load_script("factor_027_legacy_timer_verifier", "scripts/verify_factor_examples_benchmark.py")
    summary = {"status": "COMPLETED"}
    root = tmp_path / "benchmark" / "example"
    _write_027_benchmark_result(verifier, root, summary, _027_fixed_inputs())

    evidence = verifier._legacy_027_benchmark_evidence(root, summary, _027_fixed_inputs())
    engine, provenance = verifier._resolve_027_engine(summary, evidence)
    assert engine == "runnext"
    assert provenance == "legacy_timer"


def test_027_legacy_summary_rejects_missing_or_contradictory_timer(tmp_path):
    verifier = _load_script("factor_027_legacy_timer_reject", "scripts/verify_factor_examples_benchmark.py")
    summary = {"status": "COMPLETED"}
    inputs = _027_fixed_inputs()
    root = tmp_path / "missing" / "example"
    root.mkdir(parents=True)
    assert verifier._legacy_027_benchmark_evidence(root, summary, inputs) is None
    with pytest.raises(verifier.VerificationError, match="no benchmark timer evidence"):
        verifier._resolve_027_engine(summary, None)
    with pytest.raises(verifier.VerificationError, match="no benchmark timer evidence"):
        verifier._resolve_027_engine({"status": "COMPLETED", "engine": "runnext"}, None)

    missing_timer_root = tmp_path / "missing_timer" / "example"
    missing_timer_result = _write_027_benchmark_result(
        verifier, missing_timer_root, summary, inputs
    )
    missing_timer_result["phase_timers"] = {}
    (missing_timer_root.parent / "result.json").write_text(
        json.dumps(missing_timer_result), encoding="utf-8"
    )
    with pytest.raises(verifier.VerificationError, match="exactly one Cerebro engine timer"):
        verifier._legacy_027_benchmark_evidence(missing_timer_root, summary, inputs)

    contradictory_root = tmp_path / "contradictory" / "example"
    result = _write_027_benchmark_result(
        verifier, contradictory_root, summary, inputs, timer_calls={"runonce": 1, "runnext": 1}
    )
    with pytest.raises(verifier.VerificationError, match="exactly one Cerebro engine timer"):
        verifier._legacy_027_benchmark_evidence(contradictory_root, summary, inputs)

    cli_root = tmp_path / "cli" / "example"
    _write_027_benchmark_result(
        verifier, cli_root, summary, inputs, engine="runnext", cli_engine="runonce"
    )
    with pytest.raises(verifier.VerificationError, match="CLI/expected engine contradicts"):
        verifier._legacy_027_benchmark_evidence(cli_root, summary, inputs)


def test_027_present_summary_engine_must_match_observed_timer(tmp_path):
    verifier = _load_script("factor_027_summary_timer_mismatch", "scripts/verify_factor_examples_benchmark.py")
    summary = {"status": "COMPLETED", "engine": "runnext"}
    root = tmp_path / "mismatch" / "example"
    _write_027_benchmark_result(
        verifier, root, summary, _027_fixed_inputs(), engine="runonce", cli_engine="runonce"
    )
    evidence = verifier._legacy_027_benchmark_evidence(root, summary, _027_fixed_inputs())
    with pytest.raises(verifier.VerificationError, match="differs from the observed benchmark timer"):
        verifier._resolve_027_engine(summary, evidence)
