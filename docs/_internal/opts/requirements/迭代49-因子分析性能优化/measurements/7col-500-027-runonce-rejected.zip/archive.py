"""Archive a rejected engine experiment; no tests or benchmark reruns."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT=Path('D:/source_code/backtrader')
DOC=ROOT/'docs/_internal/opts/requirements/迭代49-因子分析性能优化'
TEMP=Path('D:/temp')
PARENT='2e94937132c65487d65208cf17cbd5f2046fd420'
paths=['examples/backtest/027_alpha003_panel_acceptance/run.py',
       'examples/backtest/027_alpha003_panel_acceptance/README.md',
       'scripts/benchmark_factor_examples.py','scripts/verify_factor_examples_benchmark.py',
       'tests/unit/test_factor_example_modes.py','tests/unit/test_factor_memory_lifecycle.py',
       'tests/unit/test_factor_examples_benchmark_universe.py',
       'tests/fixtures/research/iteration49_g6_027_result_engine.json']
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PARENT
vpath=TEMP/'iteration49-027-runonce-screen-verification.json'
v=read(vpath)
assert v['status']=='PASS' and v['valid'] and v['scope_complete']
assert all(v['comparisons'][e]['valid'] for e in ('025','026','027'))
entries={}
r={}
for arm in ('a','b'):
    out=TEMP/f'iteration49-027-runonce-screen-{arm}'
    r[arm]=read(out/'result.json')
    assert r[arm]['status']=='COMPLETED' and not r[arm]['source_or_input_changes']
    assert not r[arm]['summary_check_errors']
    for kind in ('backtrader_source','fincore_source','data_identity'):
        assert r[arm][kind+'_before']==r[arm][kind+'_after']
    entries[f'{arm}/result.json']=(out/'result.json').read_bytes()
    entries[f'{arm}/run.log']=out.with_suffix('.log').read_bytes()
assert r['a']['data_files_before']==r['b']['data_files_before']
assert r['a']['fincore_files_before']==r['b']['fincore_files_before']
assert r['a']['expected_engine']=='runnext' and r['b']['expected_engine']=='runonce'
metrics={}
for key in ('example_main_wall_ns','example_main_process_cpu_ns'):
    metrics[key]={'a':r['a'][key],'b':r['b'][key], 'change_percent':100*(r['b'][key]/r['a'][key]-1)}
for arm in r:
    metrics[arm+'_peak_bytes']=max(r[arm]['main_peak_working_set_bytes'],r[arm]['resource_peak_tree_rss_bytes'])
assert metrics['example_main_wall_ns']['change_percent']>0
entries['verification.json']=vpath.read_bytes()
entries['verification.log']=vpath.with_suffix('.log').read_bytes()
for name in paths: entries['candidate/'+name]=(ROOT/name).read_bytes()
for name in ('iteration49-027-runonce-focus.log','iteration49-027-runonce-focus-repair.log'):
    entries['qa/'+name]=(TEMP/name).read_bytes()
entries['patch/r3.patch']=(ROOT/'.codex-tmp/iteration49-027-runonce-screen-r3.patch').read_bytes()
entries['archive.py']=Path(__file__).read_bytes()
manifest={name:{'sha256':sha(raw),'size_bytes':len(raw)} for name,raw in entries.items()}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=DOC/'measurements/7col-500-027-runonce-rejected.zip'
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in entries.items(): z.writestr(name,raw)
with zipfile.ZipFile(dest) as z:
    for name,pin in manifest.items():
        raw=z.read(name); assert sha(raw)==pin['sha256'] and len(raw)==pin['size_bytes']
summary={'status':'REJECTED_SLOWER_COMPLETE_FLOW','metrics':metrics,
         'counts':{'actual_027_runs':2,'unique_comparisons':1,'full_verifiers':1,'reused_025_026_controls':2},
         'qa':'22 tests passed before a new fixture row-count assertion failed; corrected fixture then four remaining tests passed. 26 unique passes, known config warning in both runs.',
         'output':'Complete verifier PASS; only explicit 027 engine difference allowed. Reused 025/026 controls are not new runs.',
         'decision':'Remove this unaccepted experiment from live source; retain runnext for final500/full. One pair rejects the candidate; it does not establish stable slowdown.',
         'source_validation_scope':'Verifier checks output/engine receipt consistency. Exact source maps/origins are separately checked by the benchmark and final paired launcher; no standalone source-attestation claim.',
         'archive':{'path':dest.name,'sha256':sha(dest.read_bytes()),'members':len(entries)}}
jpath=DOC/'measurements/7col-500-027-runonce-rejected.json'
with jpath.open('x',encoding='utf-8') as f: json.dump(summary,f,ensure_ascii=False,indent=2)
record=DOC/'开发与验收记录.md'
text=record.read_text(encoding='utf-8').rstrip()
marker='## 027显式runonce筛选：撤下较慢候选'
assert marker not in text
text+=f'''\n\n{marker}\n\n
在已接受G3 Presence与FinCore G6的相同7列500×243数据上，显式runonce完整流程为31.696秒，runnext为27.659秒；本对观察慢{metrics['example_main_wall_ns']['change_percent']:.3f}%，故不选用该候选，不再扩展三对。对应CPU为30.703/26.859秒，峰值为304.243/308.756MB。单对只用于筛选，不宣称稳定退化倍率。

两个实际027运行的完整产物比较PASS，仅显式允许engine字段变化；025/026复用同一G6控制，不能计为新运行。源码测试先通过22项，新测试的固定3股配置却误写4股行数，修正该测试后剩余4项通过，共26项唯一通过；两次各有已知pytest配置警告。原失败日志保留，未修改引擎计算来迎合测试。

实验补丁、候选源码、实际结果与测试日志均保留在[筛选证据](measurements/7col-500-027-runonce-rejected.zip)，详见[摘要](measurements/7col-500-027-runonce-rejected.json)。本轮实验源文件撤下，正式最终验收继续使用runnext。最终选定生产版本为Backtrader `{PARENT}` 与FinCore `4e01ac9f6f081f13acd60b45559119e1a5ed4a4f`；下一步是相对7列B0的500三对，随后5471全量裁决80%/1GB，当前尚未宣称达标。
'''
record.write_text(text.rstrip()+'\n',encoding='utf-8')
files=[p.relative_to(ROOT).as_posix() for p in (dest,jpath,record)]
config={'repository':str(ROOT),'parent':PARENT,'receipt':str(ROOT/'.codex-tmp/iteration49-runonce-rejected-delivery.json'),
        'message':'docs(research): record rejected runonce performance screen','files':files,
        'expected_sha256':{name:sha((ROOT/name).read_bytes()) for name in files},
        'acceptance':'Completed output-equivalent 500 screen; reject slower engine candidate, preserve runnext. No stable slowdown or full-universe acceptance claim.'}
with (ROOT/'.codex-tmp/iteration49-runonce-rejected-commit.json').open('x',encoding='utf-8') as f:
    json.dump(config,f,ensure_ascii=False,indent=2)
print(json.dumps(summary,ensure_ascii=False))
