"""Prepared G1c 025-only pair extension; run only after explicit Root approval.

Pairs 4 and 5 use the frozen G1c screen's source checks, benchmark launcher,
and result validator. The already-completed pair-1 026/027 outputs are reused
as controls for each complete-output verification; they are never rerun here.
This file is intentionally separate from the frozen screening helper.
"""

import json
import runpy
from pathlib import Path


ROOT = Path("D:/source_code/backtrader")
SCREEN = ROOT / ".codex-tmp/iteration49_g1c_screen.py"
SCREEN_SHA256 = "fbf1ce0c8fce53ad610c410c9e2e9a891dc45be4a0861ef2c8364702e7322217"
TEMP = Path("D:/temp")
EXAMPLES = ("025", "026", "027")


def _sha256(path: Path) -> str:
    import hashlib

    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_frozen_screen() -> dict:
    assert _sha256(SCREEN) == SCREEN_SHA256, "frozen G1c screen changed"
    return runpy.run_path(str(SCREEN), run_name="iteration49_g1c_screen_helpers")


def _verify_completed_controls(screen: dict) -> None:
    prior = TEMP / "iteration49-7col-g1c-p1-verification.json"
    assert prior.is_file(), prior
    prior_result = json.loads(prior.read_text(encoding="utf-8"))
    assert prior_result.get("status") == "PASS"
    assert prior_result.get("scope_complete") is True

    # Revalidate only the small control metadata through the frozen checker;
    # the full result artifacts themselves remain untouched and are not rerun.
    for arm in ("a", "b"):
        for example in ("026", "027"):
            path = TEMP / f"iteration49-7col-g1c-p1-{arm}-{example}" / "result.json"
            screen["run_result"](path, arm, example)


def _run_pair(screen: dict, pair: int) -> None:
    assert pair in (4, 5)
    order = ("b", "a") if pair % 2 == 0 else ("a", "b")
    sources = {}

    for arm in order:
        screen["check_sources"]()
        output = TEMP / f"iteration49-7col-g1c-p{pair}-{arm}-025"
        assert not output.exists(), output
        fc_root = screen["FC_A"] if arm == "a" else screen["FC_B"]
        print(f"START G1c 025-only pair={pair} arm={arm}", flush=True)
        screen["execute"](
            [
                "scripts/benchmark_factor_examples.py",
                "--source-root",
                str(screen["BT"]),
                "--fincore-root",
                str(fc_root),
                "--data-root",
                str(screen["DATA"]),
                "--example",
                "025",
                "--profile",
                "full",
                "--output",
                str(output),
            ],
            output.with_suffix(".log"),
        )
        result = screen["run_result"](output / "result.json", arm, "025")
        sources[arm] = result["fincore_source_before"]
        print(
            json.dumps(
                {
                    "pair": pair,
                    "example": "025",
                    "arm": arm,
                    "wall_s": result["example_main_wall_ns"] / 1e9,
                    "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                    "peak_bytes": max(
                        result["main_peak_working_set_bytes"],
                        result["resource_peak_tree_rss_bytes"],
                    ),
                }
            ),
            flush=True,
        )
        screen["check_sources"]()

    assert sources["a"].get("source_content_sha256") != sources["b"].get(
        "source_content_sha256"
    )

    verification = TEMP / f"iteration49-7col-g1c-p{pair}-verification.json"
    assert not verification.exists(), verification
    verify_args = [
        "scripts/verify_factor_examples_benchmark.py",
        "--output",
        str(verification),
    ]
    for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
        for example in EXAMPLES:
            control_pair = pair if example == "025" else 1
            verify_args.extend(
                (
                    flag,
                    f"{example}={TEMP}/iteration49-7col-g1c-p{control_pair}-{arm}-{example}",
                )
            )
    screen["execute"](verify_args, verification.with_suffix(".log"))
    verified = json.loads(verification.read_text(encoding="utf-8"))
    assert verified.get("status") == "PASS" and verified.get("scope_complete") is True
    print(f"G1c 025-only PAIR {pair} COMPLETE OUTPUT PASS", flush=True)


def main() -> None:
    screen = _load_frozen_screen()
    screen["check_sources"]()
    _verify_completed_controls(screen)
    for pair in (4, 5):
        for arm in ("a", "b"):
            output = TEMP / f"iteration49-7col-g1c-p{pair}-{arm}-025"
            assert not output.exists(), output
            assert not output.with_suffix(".log").exists(), output.with_suffix(".log")
        verification = TEMP / f"iteration49-7col-g1c-p{pair}-verification.json"
        assert not verification.exists(), verification
        assert not verification.with_suffix(".log").exists(), verification.with_suffix(".log")
    for pair in (4, 5):
        _run_pair(screen, pair)
    screen["check_sources"]()


if __name__ == "__main__":
    main()
