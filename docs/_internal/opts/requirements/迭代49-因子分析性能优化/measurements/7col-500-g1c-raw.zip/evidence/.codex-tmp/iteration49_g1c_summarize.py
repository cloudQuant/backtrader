"""Summarize completed G1c fixed-500 runs; does not launch benchmarks."""

import hashlib
import json
import runpy
import statistics
from pathlib import Path


ROOT = Path("D:/source_code/backtrader")
SCREEN = ROOT / ".codex-tmp/iteration49_g1c_screen.py"
SCREEN_SHA256 = "fbf1ce0c8fce53ad610c410c9e2e9a891dc45be4a0861ef2c8364702e7322217"
TEMP = Path("D:/temp")
OUTPUT = TEMP / "iteration49-7col-g1c-paired-summary.json"
EXAMPLES = ("025", "026", "027")
METRICS = ("wall_s", "cpu_s", "peak_bytes")
PAIR_COUNTS = {"025": 5, "026": 3, "027": 3}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_screen() -> dict:
    assert sha256(SCREEN) == SCREEN_SHA256, "frozen G1c screen changed"
    return runpy.run_path(str(SCREEN), run_name="iteration49_g1c_screen_helpers")


def run_path(pair: int, arm: str, example: str) -> Path:
    return TEMP / f"iteration49-7col-g1c-p{pair}-{arm}-{example}" / "result.json"


def peak_bytes(result: dict) -> int:
    return max(
        result["main_peak_working_set_bytes"],
        result["resource_peak_tree_rss_bytes"],
    )


def measurements(result: dict) -> dict:
    return {
        "wall_s": result["example_main_wall_ns"] / 1e9,
        "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
        "peak_bytes": peak_bytes(result),
    }


def median(values: list[float]) -> float:
    return statistics.median(values)


def summarize_metric(a: list[float], b: list[float]) -> dict:
    ratios = [right / left for left, right in zip(a, b, strict=True)]
    ratio_median = median(ratios)
    return {
        "a_median": median(a),
        "b_median": median(b),
        "paired_b_over_a": ratios,
        "paired_b_over_a_median": ratio_median,
        "paired_b_over_a_min": min(ratios),
        "paired_b_over_a_max": max(ratios),
        "relative_dispersion_over_median": (max(ratios) - min(ratios)) / ratio_median,
        "b_reduction_percent": (1.0 - ratio_median) * 100.0,
    }


def load_runs(screen: dict) -> tuple[dict, list[dict]]:
    by_example: dict[str, dict[int, dict[str, dict]]] = {}
    run_records: list[dict] = []
    for example, pair_count in PAIR_COUNTS.items():
        by_example[example] = {}
        for pair in range(1, pair_count + 1):
            by_example[example][pair] = {}
            for arm in ("a", "b"):
                path = run_path(pair, arm, example)
                result = screen["run_result"](path, arm, example)
                measured = measurements(result)
                by_example[example][pair][arm] = measured
                run_records.append(
                    {
                        "pair": pair,
                        "arm": arm,
                        "example": example,
                        "result_json": str(path),
                        "result_json_bytes": path.stat().st_size,
                        "result_json_sha256": sha256(path),
                        **measured,
                    }
                )
    return by_example, run_records


def verify_reports() -> list[dict]:
    reports = []
    for pair in range(1, 6):
        path = TEMP / f"iteration49-7col-g1c-p{pair}-verification.json"
        result = json.loads(path.read_text(encoding="utf-8"))
        assert result.get("status") == "PASS" and result.get("scope_complete") is True, path
        assert result.get("valid") is True and result.get("mode") == "ab-pair", path
        assert set(result.get("comparisons", {})) == set(EXAMPLES), path
        for example in EXAMPLES:
            assert result["comparisons"][example].get("valid") is True, (path, example)

        controls = {}
        for side, arm in (("baseline", "a"), ("candidate", "b")):
            controls[side] = {}
            for example in EXAMPLES:
                control_pair = pair if pair <= 3 or example == "025" else 1
                expected = (
                    TEMP
                    / f"iteration49-7col-g1c-p{control_pair}-{arm}-{example}"
                    / "example"
                )
                actual = Path(result["runs"][side][example]["directory"])
                assert actual.resolve() == expected.resolve(), (path, side, example, actual)
                assert result["runs"][side][example].get("valid") is True, (
                    path,
                    side,
                    example,
                )
                controls[side][example] = str(actual)
        reports.append(
            {
                "pair": pair,
                "path": str(path),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                "status": result["status"],
                "scope_complete": result["scope_complete"],
                "new_unique_comparisons": 3 if pair <= 3 else 1,
                "reused_control_comparisons": 0 if pair <= 3 else 2,
                "controls": controls,
            }
        )
    return reports


def main() -> None:
    assert not OUTPUT.exists(), OUTPUT
    assert sha256(SCREEN) == SCREEN_SHA256
    screen = load_screen()
    screen["check_sources"]()
    by_example, run_records = load_runs(screen)
    verifiers = verify_reports()
    screen["check_sources"]()

    example_summaries = {}
    for example, pair_count in PAIR_COUNTS.items():
        paired = {
            metric: summarize_metric(
                [by_example[example][pair]["a"][metric] for pair in range(1, pair_count + 1)],
                [by_example[example][pair]["b"][metric] for pair in range(1, pair_count + 1)],
            )
            for metric in METRICS
        }
        initial_wall_ratios = paired["wall_s"]["paired_b_over_a"][:3]
        initial_dispersion = (max(initial_wall_ratios) - min(initial_wall_ratios)) / median(
            initial_wall_ratios
        )
        final_wall_ratio = paired["wall_s"]["paired_b_over_a_median"]
        final_dispersion = paired["wall_s"]["relative_dispersion_over_median"]
        if example == "027":
            wall_claim = "no speed gain claimed for 027"
        elif final_wall_ratio < 1.0 and final_dispersion > 0.05:
            wall_claim = (
                "observed wall reduction; paired ratio spread exceeds 5%, treat as unstable"
            )
        elif final_wall_ratio < 1.0:
            wall_claim = "paired wall reduction with dispersion at or below 5%"
        else:
            wall_claim = "no paired wall reduction established"
        example_summaries[example] = {
            "pair_count": pair_count,
            "pairs": {
                str(pair): {
                    arm: by_example[example][pair][arm]
                    for arm in ("a", "b")
                }
                for pair in range(1, pair_count + 1)
            },
            "metrics": paired,
            "initial_three_pair_wall_relative_dispersion_over_median": initial_dispersion,
            "five_percent_extension_threshold_exceeded_initially": initial_dispersion > 0.05,
            "final_wall_relative_dispersion_over_median": final_dispersion,
            "wall_claim": wall_claim,
        }

    summary = {
        "schema_version": 1,
        "status": "PASS_G1C_PAIRED_MEASUREMENT_ONLY",
        "measurement_scope": "fixed 500-symbol, 243-date, seven-column 025/026/027 full examples",
        "claims": {
            "whole_5471_symbol_peak_at_or_below_1gb_established": False,
            "overall_80_percent_runtime_reduction_established": False,
            "installed_wheel_or_release_acceptance": False,
        },
        "counts": {
            "measured_processes": len(run_records),
            "unique_measured_comparisons": sum(PAIR_COUNTS.values()),
            "complete_output_verifier_runs": len(verifiers),
            "comparison_checks_across_verifiers_including_reused_controls": 3 * len(verifiers),
            "reused_p1_control_examples_in_p4_p5": ["026", "027"],
        },
        "pair_order": {str(pair): "BA" if pair % 2 == 0 else "AB" for pair in range(1, 6)},
        "sources": {
            "backtrader_snapshot": str(screen["BT"]),
            "backtrader_commit": screen["BT_COMMIT"],
            "backtrader_manifest_sha256": screen["BT_MANIFEST_SHA256"],
            "fincore_a_snapshot": str(screen["FC_A"]),
            "fincore_a_commit": screen["FC_COMMIT"],
            "fincore_a_manifest_sha256": screen["FC_A_MANIFEST_SHA256"],
            "fincore_a_models_sha256": screen["FC_A_MODELS_SHA256"],
            "fincore_b_worktree": str(screen["FC_B"]),
            "fincore_b_head_commit": screen["FC_COMMIT"],
            "fincore_b_models_sha256": screen["FC_B_MODELS_SHA256"],
            "fincore_b_test_sha256": screen["FC_B_TEST_SHA256"],
        },
        "examples": example_summaries,
        "runs": run_records,
        "verifiers": verifiers,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(summary, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(f"WROTE {OUTPUT}")


if __name__ == "__main__":
    main()
