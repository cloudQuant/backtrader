"""Run serial G1c fixed-500 screening pairs with complete-output verification."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path("D:/source_code/backtrader")
BT = Path("D:/temp/iteration49-g2a-backtrader-02ee098a9")
FC_A = Path("D:/temp/iteration49-g1b-fincore-2ec366c")
FC_B = Path("D:/source_code/fincore")
TEMP = Path("D:/temp")
DATA = ROOT / "tests/datas/a_stocks"
BT_COMMIT = "02ee098a972164f3d49d087713f3efc52729992a"
BT_MANIFEST_SHA256 = "c53c3b883eaa6d2e8a23a8cd45c94596100f9cc0f19a949c1ce9a7f7dcf83910"
FC_COMMIT = "2ec366c033bb6b4c47fe1880d5a3f4ec5e407d64"
FC_A_MANIFEST_SHA256 = "c424ba06a26b9db8c5481424fc096912eb22c01a1f103823cbbdf8ecf0f6389e"
FC_A_MODELS_SHA256 = "8f4aa2e676612beb10bf9c9e42aa6780c0f11101fd1169fa9ddb0a9f426676ea"
FC_B_MODELS_SHA256 = "78c9cc243cc5ee163c4231b365bad11f2d835427a49c5c4ded65ec69f9420404"
FC_B_TEST_SHA256 = "94549d3cfc4231e3fea57fc90f7ba11a64abba3f48e8a4cba685aafc210c670b"
EXAMPLES = ("025", "026", "027")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_manifest(root: Path, commit: str, manifest_sha256: str) -> dict:
    path = root / ".iteration49-source.json"
    assert path.is_file() and sha256(path) == manifest_sha256, path
    manifest = json.loads(path.read_text(encoding="utf-8"))
    assert manifest.get("schema_version") == 1
    assert manifest.get("commit") == commit
    return manifest


def check_sources() -> None:
    bt_manifest = check_manifest(BT, BT_COMMIT, BT_MANIFEST_SHA256)
    assert Path(bt_manifest["source_repository"]).resolve() == ROOT.resolve()

    fc_a_manifest = check_manifest(FC_A, FC_COMMIT, FC_A_MANIFEST_SHA256)
    assert Path(fc_a_manifest["source_repository"]).resolve() == FC_B.resolve()
    expected_a = fc_a_manifest["files"]["fincore/factor_analysis/models.py"]
    assert expected_a["sha256"] == FC_A_MODELS_SHA256
    assert sha256(FC_A / "fincore/factor_analysis/models.py") == FC_A_MODELS_SHA256

    head = subprocess.run(
        ["git", "-C", str(FC_B), "rev-parse", "--verify", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    branch = subprocess.run(
        ["git", "-C", str(FC_B), "branch", "--show-current"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert head == FC_COMMIT and branch == "dev", (head, branch)
    assert sha256(FC_B / "fincore/factor_analysis/models.py") == FC_B_MODELS_SHA256
    assert sha256(FC_B / "tests/factor_analysis/test_fingerprint_streaming.py") == FC_B_TEST_SHA256


def execute(args: list[str], log: Path) -> None:
    assert not log.exists(), log
    with log.open("xb") as stream:
        result = subprocess.run(
            [sys.executable, *args],
            cwd=ROOT,
            stdout=stream,
            stderr=subprocess.STDOUT,
        )
    assert result.returncode == 0, (result.returncode, str(log))


def run_result(path: Path, arm: str, example: str) -> dict:
    result = json.loads(path.read_text(encoding="utf-8"))
    assert result.get("status") == "COMPLETED", path
    assert result.get("runner_exit_code") == 0 and result.get("example_exit_code") == 0
    assert result.get("example") == example and result.get("profile") == "full"
    assert not result.get("source_or_input_changes") and not result.get("summary_check_errors")
    summary = result.get("summary") or {}
    assert summary.get("status") == "COMPLETED" and summary.get("symbols") == 500
    assert summary.get("dates") == 243 and summary.get("factor_mode") == "native"
    assert summary.get("factor_calculation") == "RAN"

    bt_source = result.get("backtrader_source_before")
    fc_source = result.get("fincore_source_before")
    assert bt_source == result.get("backtrader_source_after")
    assert fc_source == result.get("fincore_source_after")
    assert bt_source and bt_source.get("commit") == BT_COMMIT
    assert fc_source and fc_source.get("commit") == FC_COMMIT
    if arm == "a":
        assert fc_source.get("kind") == "verified_snapshot_manifest_v1"
        assert fc_source.get("manifest_sha256") == FC_A_MANIFEST_SHA256
    else:
        assert fc_source.get("kind") == "git_worktree" and fc_source.get("branch") == "dev"

    args = result.get("example_cli_arguments") or []
    assert args.count("--max-symbols") == 1 and args[args.index("--max-symbols") + 1] == "500"
    assert args.count("--factor-mode") == 1 and args[args.index("--factor-mode") + 1] == "native"
    assert args.count("--data-dir") == 1
    assert Path(args[args.index("--data-dir") + 1]).resolve() == DATA.resolve()
    data_identity = result.get("data_identity_before")
    assert data_identity and data_identity == result.get("data_identity_after")
    assert data_identity.get("symbols") == 500 and data_identity.get("dates") == 243
    return result


def main() -> None:
    pairs = tuple(map(int, sys.argv[1:])) if len(sys.argv) > 1 else (1, 2, 3)
    assert pairs and len(set(pairs)) == len(pairs) and all(pair in (1, 2, 3) for pair in pairs)
    check_sources()

    for pair in pairs:
        order = ("a", "b") if pair % 2 else ("b", "a")
        for example in EXAMPLES:
            sources = {}
            for arm in order:
                check_sources()
                output = TEMP / f"iteration49-7col-g1c-p{pair}-{arm}-{example}"
                assert not output.exists(), output
                fc_root = FC_A if arm == "a" else FC_B
                print(f"START G1c pair={pair} arm={arm} example={example}", flush=True)
                execute(
                    [
                        "scripts/benchmark_factor_examples.py",
                        "--source-root",
                        str(BT),
                        "--fincore-root",
                        str(fc_root),
                        "--data-root",
                        str(DATA),
                        "--example",
                        example,
                        "--profile",
                        "full",
                        "--output",
                        str(output),
                    ],
                    output.with_suffix(".log"),
                )
                result = run_result(output / "result.json", arm, example)
                sources[arm] = result["fincore_source_before"]
                print(
                    json.dumps(
                        {
                            "pair": pair,
                            "arm": arm,
                            "example": example,
                            "wall_s": result["example_main_wall_ns"] / 1e9,
                            "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                            "peak_bytes": max(
                                result["main_peak_working_set_bytes"],
                                result["resource_peak_tree_rss_bytes"],
                            ),
                        }
                    ),
                    flush=True,
                )
                check_sources()
            assert sources["a"].get("source_content_sha256") != sources["b"].get(
                "source_content_sha256"
            )

        verification = TEMP / f"iteration49-7col-g1c-p{pair}-verification.json"
        assert not verification.exists(), verification
        verify_args = ["scripts/verify_factor_examples_benchmark.py", "--output", str(verification)]
        for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
            for example in EXAMPLES:
                verify_args.extend(
                    (
                        flag,
                        f"{example}={TEMP}/iteration49-7col-g1c-p{pair}-{arm}-{example}",
                    )
                )
        execute(verify_args, verification.with_suffix(".log"))
        verified = json.loads(verification.read_text(encoding="utf-8"))
        assert verified.get("status") == "PASS" and verified.get("scope_complete") is True
        print(f"G1c PAIR {pair} COMPLETE OUTPUT PASS", flush=True)


if __name__ == "__main__":
    main()
