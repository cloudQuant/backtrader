G1d raw 18-run and three full-verifier evidence; 500 x 243 only.
