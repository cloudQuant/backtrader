G10b before-hook-guard measured source pins, focused QA, review, tools and run configs; no full-matrix acceptance claim.
