"""Archive the measured G10b candidate before its later hook guard; never runs work."""
import hashlib
import io
import json
import re
import statistics
import sys
import zipfile
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
DEST = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements"
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
LAUNCHER = ROOT / ".codex-tmp/iteration49_g10_panel_once_pairs.py"
PAIR_HELPER = ROOT / ".codex-tmp/iteration49_next_pairs.py"
FROZEN_TESTED_ROOT = ROOT / ".codex-tmp/iteration49-g10b-before-hook-guard"
FROZEN_TESTED_FILES = {
    "backtrader/research/operators.py": "operators.py",
    "tests/unit/test_factor_research_panel_once.py": "test_factor_research_panel_once.py",
}
FROZEN_TESTED_PINS = {
    "backtrader/research/operators.py": {
        "sha256": "409c777e45ba56d02b8c083c443c1828b6af44fd33e9fd5e2579599aaa8e4c0a",
        "size_bytes": 91005,
    },
    "tests/unit/test_factor_research_panel_once.py": {
        "sha256": "055f78b0bb39c3d9d039e88778f90b2b36f409851812990b29bab619d5f1b135",
        "size_bytes": 12819,
    },
}
EXAMPLES = ("025", "026", "027")
ORDERS = {1: ("a", "b"), 2: ("b", "a"), 3: ("a", "b")}
EXPECTED_ENGINES = {
    "a": {"025": "runonce", "026": "runonce", "027": "runnext"},
    "b": {"025": "runonce", "026": "runonce", "027": "runonce"},
}
STEM = "7col-500-g10b-before-hook-guard"


def pin(raw):
    return {"size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def read(path):
    return Path(path).read_bytes()


def json_file(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def shared_config(config):
    return {key: value for key, value in config.items() if key != "pairs"}


def output(root, prefix, pair, arm, example):
    return root / f"{prefix}-p{pair}-{arm}-{example}"


def expected_backtrader_files(cfg, arm, baseline_files):
    if arm == "a":
        return baseline_files
    candidate = cfg["backtrader_candidate"]
    files = dict(baseline_files)
    for name, pin_value in {**candidate.get("allowed_delta", {}),
                            **candidate.get("checkout_raw_overrides", {})}.items():
        files[name] = {"sha256": pin_value["sha256"].lower(),
                       "size_bytes": pin_value["size_bytes"]}
    files[RUNNER] = {"sha256": cfg["tool_pins"][RUNNER]["sha256"].lower(),
                     "size_bytes": cfg["tool_pins"][RUNNER]["size_bytes"]}
    return files


def check_run(run_path, arm, example, cfg):
    result = json_file(run_path)
    expected = EXPECTED_ENGINES[arm][example]
    assert (result.get("status"), result.get("profile"), result.get("example"),
            result.get("input_universe"), result.get("runner_exit_code"),
            result.get("example_exit_code")) == ("COMPLETED", "full", example, "fixed500", 0, 0)
    assert (result.get("expected_engine"), result.get("observed_engine")) == (expected, expected)
    assert result.get("runner_sha256") == cfg["tool_pins"][RUNNER]
    assert not result.get("source_or_input_changes") and not result.get("summary_check_errors")
    for key in ("backtrader_source", "fincore_source", "data_identity"):
        assert result.get(key + "_before") == result.get(key + "_after"), key
    data = result.get("data_identity_before") or {}
    data_cfg = cfg["data"]
    summary = result.get("summary") or {}
    assert (data.get("symbols"), data.get("dates"), summary.get("symbols"), summary.get("dates")) == (
        500, 243, 500, 243)
    assert data.get("selection_sha256") == data_cfg["selection_sha256"]
    assert Path(result["data_root"]).resolve() == Path(data_cfg["root"]).resolve()
    assert Path(result["selection_path"]).resolve() == Path(data_cfg["selection"]).resolve()
    assert (summary.get("factor_mode"), summary.get("factor_calculation")) == ("native", "RAN")
    summary_path = run_path.parent / "example" / "summary.json"
    assert result.get("phase_timers") and json_file(summary_path) == summary
    metrics = {
        "wall_s": result["example_main_wall_ns"] / 1e9,
        "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
        "peak_bytes": max(result["main_peak_working_set_bytes"],
                          result["resource_peak_tree_rss_bytes"]),
    }
    assert all(value > 0 for value in metrics.values())
    return result, metrics


def verify_one(pair, root, prefix):
    suffix = "verification.json" if pair == 1 else "control-inclusive-verification.json"
    path = root / f"{prefix}-p{pair}-{suffix}"
    verifier = json_file(path)
    assert (verifier.get("status"), verifier.get("valid"),
            verifier.get("scope_complete")) == ("PASS", True, True)
    assert set(verifier.get("comparisons", {})) == set(EXAMPLES)
    assert all(row.get("valid") is True for row in verifier["comparisons"].values())
    for side, arm in (("baseline", "a"), ("candidate", "b")):
        for example in EXAMPLES:
            actual_pair = 1 if pair > 1 and example != "027" else pair
            expected = output(root, prefix, actual_pair, arm, example) / "example"
            actual = Path(verifier["runs"][side][example]["directory"])
            assert actual.resolve() == expected.resolve()
    partial = None
    if pair > 1:
        partial_path = root / f"{prefix}-p{pair}-partial-scope.json"
        partial = json_file(partial_path)
        assert (partial.get("status"), partial.get("valid"), partial.get("scope_complete")) == (
            "PASS", True, False)
        assert partial.get("independent_examples") == ["027"]
        assert partial.get("independent_scope_complete") is True
        assert set(partial.get("comparisons", {})) == {"027"}
        assert partial["comparisons"]["027"].get("valid") is True
        assert set(partial.get("reused_controls", {})) == {"025", "026"}
        assert all(row.get("source_pair") == 1 and row.get("comparison_valid") is True
                   for row in partial["reused_controls"].values())
        assert partial.get("canonical_control_inclusive_verifier", {}).get("sha256") == pin(read(path))["sha256"]
        for arm in ("a", "b"):
            expected = output(root, prefix, pair, arm, "027")
            assert Path(partial["current_pair_027"]["baseline" if arm == "a" else "candidate"]).resolve() == expected.resolve()
        return path, verifier, partial_path, partial
    return path, verifier, None, None


def metric_summary(measurements, examples):
    result = {}
    for example in examples:
        pairs = sorted(measurements[example])
        row = {"actual_pairs": pairs, "per_pair": measurements[example], "metrics": {}}
        for key in ("wall_s", "cpu_s", "peak_bytes"):
            ratios = [measurements[example][pair]["b"][key] /
                      measurements[example][pair]["a"][key] for pair in pairs]
            median = statistics.median(ratios)
            dispersion = ((max(ratios) - min(ratios)) / median
                          if len(ratios) > 1 else None)
            row["metrics"][key] = {
                "a_median": statistics.median(measurements[example][p]["a"][key] for p in pairs),
                "b_median": statistics.median(measurements[example][p]["b"][key] for p in pairs),
                "paired_b_over_a": ratios,
                "median_b_over_a": median,
                "reduction_percent": 100.0 * (1.0 - median),
                "relative_dispersion_of_b_over_a": dispersion,
                "dispersion_limit": 0.05 if example == "027" else None,
                "within_5pct_dispersion": (dispersion <= 0.05 if example == "027" else None),
            }
        result[example] = row
    return result


def archive(files, note):
    rows = [{"path": name, **pin(raw)} for name, raw in sorted(files.items())]
    manifest = json.dumps({"schema_version": 1, "note": note, "files": rows},
                          indent=2, ensure_ascii=False).encode("utf-8") + b"\n"
    members = {**files, "MANIFEST.json": manifest,
               "README.txt": note.encode("utf-8") + b"\n"}
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    blob = out.getvalue()
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        assert set(z.namelist()) == set(members)
        for name, raw in members.items():
            assert z.read(name) == raw
    return blob, {**pin(blob), "payload_count": len(rows),
                  "manifest_sha256": pin(manifest)["sha256"]}


def main():
    assert len(sys.argv) in (6, 7), (
        "usage: script.py PAIR1.json PAIR23.json FOCUSED_QA.json FOCUSED_QA.log "
        "REVIEW.md [stem]"
    )
    pair1_path, pair23_path, qa_path, qa_log_path, review_path = map(
        lambda value: Path(value).resolve(strict=True), sys.argv[1:6])
    pair1, pair23 = json_file(pair1_path), json_file(pair23_path)
    assert pair1.get("pairs") == [1] and pair23.get("pairs") == [2, 3]
    assert shared_config(pair1) == shared_config(pair23)
    cfg = pair1
    assert cfg.get("schema_version") == 1 and cfg.get("workspace_root") == str(ROOT)
    assert cfg.get("output_prefix") == "iteration49-g10b-panel-once-500"
    assert cfg.get("expected_engines") == EXPECTED_ENGINES
    for name, row in cfg["tool_pins"].items():
        assert pin(read(ROOT / name)) == {"size_bytes": row["size_bytes"],
                                          "sha256": row["sha256"].lower()}

    qa, review, qa_log = json_file(qa_path), read(review_path), read(qa_log_path)
    candidate = cfg["backtrader_candidate"]
    focus_context = cfg["qa_context"]["fresh_g10b_focus"]
    assert qa_path == Path(focus_context["receipt"]).resolve(strict=True)
    assert pin(read(qa_path))["sha256"] == focus_context["receipt_sha256"]
    assert pin(qa_log) == {"size_bytes": cfg["qa_context"]["focused_log_size_bytes"],
                           "sha256": focus_context["log_sha256"]}
    assert (qa.get("status"), qa.get("exit_code"), qa.get("collected"), qa.get("passed"),
            qa.get("failed")) == ("PASS_FOCUSED_SOURCE_QA_ONLY", 0, 8, 8, 0)
    assert hashlib.sha256(qa_log).hexdigest() == qa.get("log_sha256")
    assert qa.get("source_pins") == {
        "backtrader/research/operators.py": FROZEN_TESTED_PINS[
            "backtrader/research/operators.py"]["sha256"],
        "tests/unit/test_factor_research_panel_once.py": FROZEN_TESTED_PINS[
            "tests/unit/test_factor_research_panel_once.py"]["sha256"],
    }
    review_context = cfg["qa_context"]["static_review"]
    review_path_cfg = Path(qa["static_review"])
    if not review_path_cfg.is_absolute():
        review_path_cfg = ROOT / review_path_cfg
    assert review_path_cfg.resolve(strict=True) == Path(review_context["path"]).resolve(strict=True)
    assert hashlib.sha256(review).hexdigest() == review_context["sha256"]
    assert qa.get("scope_note") == "No benchmark, profile, CLI/runner suite, or full-101 matrix was run."
    for name, expected in FROZEN_TESTED_PINS.items():
        cfg_pin = candidate["allowed_delta"].get(name, candidate["test_pins"].get(name))
        assert cfg_pin == expected, name
    frozen_bytes = {}
    for name, frozen_name in FROZEN_TESTED_FILES.items():
        raw = read(FROZEN_TESTED_ROOT / frozen_name)
        assert pin(raw) == FROZEN_TESTED_PINS[name], name
        frozen_bytes[name] = raw

    root, prefix = Path(cfg["output_root"]).resolve(strict=True), cfg["output_prefix"]
    assert re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", prefix), prefix
    data = cfg["data"]
    baseline_root = Path(cfg["backtrader_snapshot"]["root"])
    baseline_manifest_raw = read(baseline_root / ".iteration49-source.json")
    baseline_manifest = json.loads(baseline_manifest_raw)
    assert hashlib.sha256(baseline_manifest_raw).hexdigest() == cfg["backtrader_snapshot"][
        "manifest_sha256"]
    fc_root = Path(cfg["fincore_snapshot"]["root"])
    fc_manifest_raw = read(fc_root / ".iteration49-source.json")
    fc_manifest = json.loads(fc_manifest_raw)
    assert hashlib.sha256(fc_manifest_raw).hexdigest() == cfg["fincore_snapshot"]["manifest_sha256"]
    expected_bt_files = {
        arm: expected_backtrader_files(cfg, arm, baseline_manifest["files"])
        for arm in ("a", "b")
    }
    run_specs = ([(1, example, arm) for example in EXAMPLES for arm in ORDERS[1]] +
                 [(pair, "027", arm) for pair in (2, 3) for arm in ORDERS[pair]])
    assert len(run_specs) == 10
    records, rawfiles, measurements, verifiers = [], {}, {example: {} for example in EXAMPLES}, []
    for pair, example, arm in run_specs:
        out = output(root, prefix, pair, arm, example)
        result_path, log_path = out / "result.json", out.with_suffix(".log")
        result, values = check_run(result_path, arm, example, cfg)
        assert result["backtrader_files_before"] == expected_bt_files[arm]
        assert result["fincore_files_before"] == fc_manifest["files"]
        bt_source = result["backtrader_source_before"]
        if arm == "a":
            desc = cfg["backtrader_snapshot"]
            assert (bt_source.get("kind"), bt_source.get("commit"), bt_source.get("manifest_sha256")) == (
                "verified_snapshot_manifest_v1", desc["commit"], desc["manifest_sha256"])
        else:
            desc = cfg["backtrader_candidate"]
            assert (bt_source.get("kind"), bt_source.get("commit"), bt_source.get("branch")) == (
                "git_worktree", desc["commit"], desc["branch"])
            assert sorted(bt_source.get("source_status", [])) == sorted(desc["result_source_status"])
        fc_source = result["fincore_source_before"]
        fc_desc = cfg["fincore_snapshot"]
        assert (fc_source.get("kind"), fc_source.get("commit"), fc_source.get("manifest_sha256")) == (
            "verified_snapshot_manifest_v1", fc_desc["commit"], fc_desc["manifest_sha256"])
        summary_path = out / "example" / "summary.json"
        phase_profile = {"kind": "runner_phase_timers_projection_not_cProfile",
                         "pair": pair, "arm": arm, "example": example,
                         "phase_timers": result["phase_timers"], "metrics": values}
        measurements[example][pair] = measurements[example].get(pair, {})
        measurements[example][pair][arm] = values
        records.append({"pair": pair, "arm": arm, "example": example, **values,
                        "expected_engine": result["expected_engine"],
                        "observed_engine": result["observed_engine"],
                        "phase_timers": result["phase_timers"]})
        rawfiles[f"raw/p{pair}/{arm}-{example}/result.json"] = read(result_path)
        rawfiles[f"raw/p{pair}/{arm}-{example}/run.log"] = read(log_path)
        rawfiles[f"raw/p{pair}/{arm}-{example}/summary.json"] = read(summary_path)
        rawfiles[f"raw/p{pair}/{arm}-{example}/phase-profile.json"] = json.dumps(
            phase_profile, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"

    for pair in (1, 2, 3):
        path, verifier, partial_path, partial = verify_one(pair, root, prefix)
        rawfiles[f"raw/p{pair}/verification.json"] = read(path)
        rawfiles[f"raw/p{pair}/verification.log"] = read(path.with_suffix(".log"))
        verifier_row = {"pair": pair, "canonical_status": verifier["status"],
                        "canonical_scope_complete": verifier["scope_complete"],
                        "path": str(path), **pin(read(path))}
        if partial_path:
            rawfiles[f"raw/p{pair}/partial-scope.json"] = read(partial_path)
            verifier_row["partial_027"] = {"path": str(partial_path), **pin(read(partial_path)),
                                            "scope_complete": False, "independent_scope_complete": True}
        verifiers.append(verifier_row)

    metrics = metric_summary(measurements, EXAMPLES)
    assert sum(len(pairs) for pairs in measurements.values()) == 5
    stem = sys.argv[6] if len(sys.argv) == 7 else STEM
    assert re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", stem), stem
    raw_blob, raw_meta = archive(rawfiles,
        "G10b before-hook-guard fixed-500 raw results, logs, summaries, phase-timer projections and verifier receipts; no large output tables.")

    sourcefiles = {
        "evidence/archive-helper.py": read(__file__),
        "evidence/pair-launcher.py": read(LAUNCHER),
        "evidence/next-pairs.py": read(PAIR_HELPER),
        "evidence/focused-source-qa.json": read(qa_path),
        "evidence/focused-source-qa.log": qa_log,
        "evidence/static-review.md": review,
        "evidence/config-pair1.json": read(pair1_path),
        "evidence/config-pair23.json": read(pair23_path),
        "baseline/backtrader/.iteration49-source.json": baseline_manifest_raw,
        "baseline/fincore/.iteration49-source.json": fc_manifest_raw,
    }
    sourcefiles.update({f"source/candidate/{name}": raw
                        for name, raw in frozen_bytes.items()
                        if name in candidate["allowed_delta"]})
    sourcefiles["evidence/measured-candidate-pins.json"] = (
        json.dumps({name: {"frozen_path": str(FROZEN_TESTED_ROOT / frozen_name),
                           **pin(frozen_bytes[name])}
                    for name, frozen_name in FROZEN_TESTED_FILES.items()},
                   ensure_ascii=False, indent=2).encode("utf-8") + b"\n")
    candidate_root = Path(candidate["root"])
    base_manifest = baseline_manifest["files"]
    preserved = candidate.get("preserved_unrelated", {})
    assert len(set(candidate.get("allowed_delta", {})) - set(preserved)) == 3
    assert len(candidate.get("test_pins", {})) == 4
    for name, expected in candidate.get("allowed_delta", {}).items():
        current = frozen_bytes[name] if name in frozen_bytes else read(candidate_root / name)
        assert pin(current) == {"sha256": expected["sha256"].lower(), "size_bytes": expected["size_bytes"]}
        if name in preserved:
            assert pin(current) == {"sha256": preserved[name]["sha256"].lower(),
                                    "size_bytes": preserved[name]["size_bytes"]}
            sourcefiles[f"preserved-unrelated/{name}"] = current
        else:
            baseline = read(baseline_root / name)
            assert pin(baseline) == base_manifest[name]
            sourcefiles[f"source/baseline/{name}"] = baseline
            sourcefiles[f"source/candidate/{name}"] = current
    for name, expected in candidate.get("test_pins", {}).items():
        raw = frozen_bytes[name] if name in frozen_bytes else read(candidate_root / name)
        assert pin(raw) == {"sha256": expected["sha256"].lower(), "size_bytes": expected["size_bytes"]}
        sourcefiles[f"tests/{name}"] = raw
    for name in cfg["tool_pins"]:
        sourcefiles[f"tools/{name}"] = read(ROOT / name)
    source_blob, source_meta = archive(sourcefiles,
        "G10b before-hook-guard measured source pins, focused QA, review, tools and run configs; no full-matrix acceptance claim.")
    raw_meta["path"], source_meta["path"] = stem + "-raw.zip", stem + "-source.zip"
    summary = {
        "schema": "iteration49.g10b-before-hook-guard-measurement.v1",
        "status": "PASS_OUTPUT_EQUIVALENCE_MEASUREMENT_ONLY",
        "counts": {"actual_processes": 10, "unique_new_comparisons": 5,
                    "canonical_verifier_documents": 3, "complete_independent_verifiers": 1,
                    "partial_027_independent_verifiers": 2},
        "execution_configs": {"pair1": {"path": str(pair1_path), **pin(read(pair1_path))},
                              "pair23": {"path": str(pair23_path), **pin(read(pair23_path))}},
        "measured_candidate_sources": {
            "variant": "G10b before the later 3-hook eligibility guard",
            "frozen_source_root": str(FROZEN_TESTED_ROOT),
            "pinned_files": {name: {"frozen_path": str(FROZEN_TESTED_ROOT / frozen_name),
                                    **pin(frozen_bytes[name])}
                              for name, frozen_name in FROZEN_TESTED_FILES.items()},
            "other_candidate_inputs": "Read from the workspace and checked against the original pair configs.",
        },
        "source_qa": {
            "focused_g10b": {"status": qa["status"], "collected": qa["collected"],
                              "passed": qa["passed"], "failed": qa["failed"],
                              "receipt": {"path": str(qa_path), **pin(read(qa_path))},
                              "log": {"path": str(qa_log_path), **pin(qa_log)}},
            "unchanged_inherited_groups_not_newly_run": cfg["qa_context"][
                "inherited_unchanged_groups"],
            "claim_limit": cfg["qa_context"]["claim_limit"],
            "full101_matrix": "Not included in this pre-hook-guard measurement record.",
        },
        "fixed_500_data": {"root": data["root"], "selection": data["selection"],
                            "selection_sha256": data["selection_sha256"], "symbols": 500, "dates": 243},
        "actual_runs": records, "verifiers": verifiers, "metrics": metrics,
        "raw_archive": raw_meta, "measured_source_archive": source_meta,
        "limitations": [
            "Pairs 2/3 independently compare only 027; 025/026 are pair-1 reused controls.",
            "025/026 each have one fresh pair only; no multi-pair performance stability claim is made.",
            "027 dispersion is reported against the 5% line for wall, CPU and peak; it is descriptive, not a speed acceptance gate.",
            "The observed 027 wall-gain dispersion is over 5%; no stable speed-gain claim is made.",
            "Peak is max(main working-set high-water, sampled process-tree RSS); phase profiles are runner timer projections, not cProfile.",
            "This record does not establish full-universe 80% speed or <=1 GB memory targets; 5471-symbol acceptance is separate.",
        ],
    }
    outputs = {raw_meta["path"]: raw_blob, source_meta["path"]: source_blob,
               stem + "-pairs.json": json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"}
    assert all(not (DEST / name).exists() for name in outputs)
    for name, content in outputs.items():
        with (DEST / name).open("xb") as stream:
            stream.write(content)
    print(json.dumps({"metrics": metrics, "counts": summary["counts"],
                      "archives": [raw_meta, source_meta]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
