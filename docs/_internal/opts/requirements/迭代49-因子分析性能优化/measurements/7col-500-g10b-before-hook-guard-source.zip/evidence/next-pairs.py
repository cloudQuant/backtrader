"""Run selected serial full-output fixed-500 A/B pairs from frozen inputs."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path, PurePosixPath

EXAMPLES = ("025", "026", "027")
ORDERS = (("a", "b"), ("b", "a"), ("a", "b"))
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def pin(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}


def under(path, root):
    try:
        path.resolve(strict=True).relative_to(root.resolve(strict=True))
        return True
    except ValueError:
        return False


def checked(root, name):
    rel = PurePosixPath(name)
    assert not rel.is_absolute() and ".." not in rel.parts, name
    path = root.joinpath(*rel.parts)
    assert under(path, root) and path.is_file(), path
    return path


def snapshot(desc):
    root = Path(desc["root"]).resolve(strict=True)
    manifest_path = root / ".iteration49-source.json"
    assert pin(manifest_path)["sha256"] == desc["manifest_sha256"].lower()
    manifest = read_json(manifest_path)
    assert manifest.get("schema_version") == 1 and manifest.get("commit") == desc["commit"]
    files = manifest.get("files")
    assert isinstance(files, dict) and files
    normalized = {name: {"sha256": row["sha256"].lower(), "size_bytes": row["size_bytes"]}
                  for name, row in files.items()}
    for name, expected in normalized.items(): assert pin(checked(root, name)) == expected, name
    manifest["files"] = normalized
    return root, manifest


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True,
                                   encoding="utf-8").rstrip("\r\n")


def candidate_worktree(desc, baseline_root, base_files):
    root = Path(desc["root"]).resolve(strict=True)
    assert git(root, "rev-parse", "--verify", "HEAD") == desc["commit"]
    assert git(root, "branch", "--show-current") == desc["branch"] == "dev"
    assert not (root / ".iteration49-source.json").exists()
    scopes = desc["source_scopes"]
    expected_names = {name for name in base_files if any(name == scope or
                      name.startswith(scope.rstrip("/") + "/") for scope in scopes)}
    assert len(expected_names) == desc["expected_file_count"]
    raw = subprocess.check_output(["git", "-C", str(root), "ls-files", "-z", "--cached", "--others",
                                   "--exclude-standard", "--", *scopes])
    actual_names = {item.decode("utf-8") for item in raw.split(b"\0") if item}
    assert actual_names == expected_names, (len(actual_names), len(expected_names))
    delta, overrides = desc.get("allowed_delta", {}), desc.get("checkout_raw_overrides", {})
    assert not (set(delta) & set(overrides))
    assert (set(delta) | set(overrides)) <= expected_names
    expected_files, changed = dict(base_files), set()
    for name in expected_names:
        path, baseline = checked(root, name), checked(baseline_root, name)
        expected = delta.get(name, overrides.get(name, base_files[name]))
        assert pin(path) == {"sha256": expected["sha256"].lower(), "size_bytes": expected["size_bytes"]}, name
        if path.read_bytes().replace(b"\r\n", b"\n") != baseline.read_bytes().replace(b"\r\n", b"\n"):
            changed.add(name)
        if name in delta or name in overrides:
            expected_files[name] = {"sha256": expected["sha256"].lower(), "size_bytes": expected["size_bytes"]}
    assert changed == set(delta), (sorted(changed), sorted(delta))
    for name, expected in desc.get("test_pins", {}).items():
        assert pin(checked(root, name)) == {"sha256": expected["sha256"].lower(), "size_bytes": expected["size_bytes"]}, name
    actual_status = git(root, "status", "--porcelain=v1", "--untracked-files=all", "--",
                        *desc["status_scopes"]).splitlines()
    assert sorted(actual_status) == sorted(desc["expected_status"]), actual_status
    assert not git(root, "diff", "--cached", "--name-only", "--", *desc["status_scopes"])
    return root, expected_files


def sources(cfg):
    bt_root, bt = snapshot(cfg["backtrader_snapshot"])
    fa_root, fa = snapshot(cfg["fincore_baseline"])
    candidate = cfg["fincore_candidate"]
    if candidate["mode"] == "snapshot":
        fb_root, fb = snapshot(candidate)
        fb_files = fb["files"]
    else:
        assert candidate["mode"] == "worktree"
        fb_root, fb_files = candidate_worktree(candidate, fa_root, fa["files"])
        fb = None
    return bt_root, bt, fa_root, fa, fb_root, fb, fb_files


def check_tools(workspace, cfg):
    expected = cfg["tool_pins"]
    assert set(expected) == {RUNNER, VERIFIER}
    for name, row in expected.items():
        assert pin(checked(workspace, name)) == {"sha256": row["sha256"].lower(),
                                                 "size_bytes": row["size_bytes"]}, name


def verified_sources(workspace, cfg):
    check_tools(workspace, cfg)
    state = sources(cfg)
    check_tools(workspace, cfg)
    return state


def data_state(cfg):
    data = cfg["data"]
    root, selection = (Path(data[k]).resolve(strict=True) for k in ("root", "selection"))
    assert pin(selection)["sha256"] == data["selection_sha256"].lower()
    ref_path = Path(data["reference_result"]).resolve(strict=True)
    assert pin(ref_path)["sha256"] == data["reference_result_sha256"].lower()
    ref = read_json(ref_path)
    identity, files = ref.get("data_identity_before"), ref.get("data_files_before")
    assert (ref.get("status"), ref.get("profile")) == ("COMPLETED", "full")
    assert ref.get("example") in EXAMPLES and identity and identity == ref.get("data_identity_after")
    assert (identity.get("symbols"), identity.get("dates"), identity.get("selection_sha256")) == (
        500, 243, data["selection_sha256"].lower())
    assert (Path(ref["data_root"]).resolve(), Path(ref["selection_path"]).resolve()) == (root, selection)
    assert isinstance(files, dict) and len(files) == 503
    assert {k for k in files if k.startswith("selection:")} == {"selection:" + selection.name}
    assert sum(not k.startswith(("selection:", "_metadata/")) for k in files) == 500
    assert sum(k.startswith("_metadata/") for k in files) == 2
    return root, selection, identity, files


def check_data(data):
    root, selection, _, files = data
    for name, expected in files.items():
        path = selection if name.startswith("selection:") else checked(root, name)
        assert pin(path) == expected, name


def invoke(args, log, cwd):
    assert not log.exists(), log
    with log.open("xb") as stream:
        result = subprocess.run([sys.executable, *args], cwd=cwd, stdout=stream,
                                stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))


def validate_run(path, arm, example, cfg, state, data):
    r = read_json(path)
    bt, fa, fb_files = state[1], state[3], state[6]
    assert (r.get("status"), r.get("profile"), r.get("example"), r.get("runner_exit_code"),
            r.get("example_exit_code")) == ("COMPLETED", "full", example, 0, 0)
    assert not r.get("source_or_input_changes") and not r.get("summary_check_errors")
    s = r.get("summary") or {}
    assert (s.get("symbols"), s.get("dates"), s.get("factor_mode"), s.get("factor_calculation")) == (500, 243, "native", "RAN")
    for key in ("backtrader_source", "fincore_source", "data_identity"): assert r.get(key + "_before") == r.get(key + "_after"), key
    assert (Path(r["data_root"]).resolve(), Path(r["selection_path"]).resolve()) == data[:2]
    assert (r["data_identity_before"], r["data_files_before"]) == data[2:]
    assert r.get("backtrader_files_before") == bt["files"]
    b, bd = r.get("backtrader_source_before", {}), cfg["backtrader_snapshot"]
    assert (b.get("kind"), b.get("commit"), b.get("manifest_sha256")) == (
        "verified_snapshot_manifest_v1", bd["commit"], bd["manifest_sha256"])
    fd = cfg["fincore_baseline"] if arm == "a" else cfg["fincore_candidate"]
    ff, f = (fa["files"] if arm == "a" else fb_files), r.get("fincore_source_before", {})
    assert (r.get("fincore_files_before"), f.get("commit")) == (ff, fd["commit"])
    expected = (("verified_snapshot_manifest_v1", fd["manifest_sha256"]) if fd["mode"] == "snapshot"
                else ("git_worktree", fd["branch"], fd["result_source_status"]))
    actual = ((f.get("kind"), f.get("manifest_sha256")) if fd["mode"] == "snapshot"
              else (f.get("kind"), f.get("branch"), f.get("source_status")))
    assert actual == expected
    cli = r.get("example_cli_arguments") or []
    for flag, value in (("--factor-mode", "native"), ("--max-symbols", "500"), ("--data-dir", str(data[0]))):
        assert cli.count(flag) == 1
        actual = cli[cli.index(flag) + 1]
        assert (str(Path(actual).resolve()) if flag == "--data-dir" else actual) == value
    return r


def main():
    assert len(sys.argv) == 2
    config_path = Path(sys.argv[1]).resolve(strict=True)
    config_sha = pin(config_path)["sha256"]
    cfg = read_json(config_path)
    assert pin(config_path)["sha256"] == config_sha and cfg.get("schema_version") == 1
    workspace = Path(cfg["workspace_root"]).resolve(strict=True)
    output_root = Path(cfg["output_root"]).resolve(strict=True)
    prefix = cfg["output_prefix"]
    assert re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", prefix)
    assert not under(output_root, workspace)
    pairs = cfg.get("pairs", [1, 2, 3])
    assert pairs and all(type(p) is int and p in (1, 2, 3) for p in pairs) and pairs == sorted(set(pairs))
    state, data = verified_sources(workspace, cfg), data_state(cfg)
    bt_root = state[0]
    check_data(data)
    assert all(not under(output_root, protected) for protected in (state[0], state[2], state[4], data[0]))
    outputs = [output_root / f"{prefix}-p{p}-{arm}-{ex}" for p in pairs
               for ex in EXAMPLES for arm in ORDERS[p - 1]]
    receipts = [output_root / f"{prefix}-p{p}-verification.json" for p in pairs]
    assert all(not path.exists() and not path.with_suffix(".log").exists()
               for path in (*outputs, *receipts))
    print(f"CONFIG sha256={config_sha}; pairs={pairs}; examples=025,026,027; full/native", flush=True)
    for pair in pairs:
        for example in EXAMPLES:
            for arm in ORDERS[pair - 1]:
                state = verified_sources(workspace, cfg)
                check_data(data)
                output = output_root / f"{prefix}-p{pair}-{arm}-{example}"
                fc_root = state[2] if arm == "a" else state[4]
                assert pin(config_path)["sha256"] == config_sha
                check_tools(workspace, cfg)
                invoke([str(workspace / RUNNER), "--source-root", str(bt_root), "--fincore-root", str(fc_root),
                        "--data-root", str(data[0]), "--selection", str(data[1]), "--example", example,
                        "--profile", "full", "--output", str(output)], output.with_suffix(".log"), workspace)
                check_tools(workspace, cfg)
                result = validate_run(output / "result.json", arm, example, cfg, state, data)
                print(json.dumps({"pair": pair, "arm": arm, "example": example,
                                  "wall_s": result["example_main_wall_ns"] / 1e9,
                                  "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                                  "peak_bytes": max(result["main_peak_working_set_bytes"],
                                                    result["resource_peak_tree_rss_bytes"])}), flush=True)
                check_data(data)
                assert verified_sources(workspace, cfg) == state and pin(config_path)["sha256"] == config_sha
        verification = output_root / f"{prefix}-p{pair}-verification.json"
        assert pin(config_path)["sha256"] == config_sha
        args = [str(workspace / VERIFIER), "--output", str(verification)]
        for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
            for example in EXAMPLES:
                args.extend((flag, f"{example}={output_root / f'{prefix}-p{pair}-{arm}-{example}'}"))
        check_tools(workspace, cfg)
        invoke(args, verification.with_suffix(".log"), workspace)
        check_tools(workspace, cfg)
        result = read_json(verification)
        assert result.get("status") == "PASS" and result.get("scope_complete") is True
        check_data(data)
        assert verified_sources(workspace, cfg) == state and pin(config_path)["sha256"] == config_sha
        print(f"PAIR {pair} COMPLETE OUTPUT PASS", flush=True)


if __name__ == "__main__":
    main()
