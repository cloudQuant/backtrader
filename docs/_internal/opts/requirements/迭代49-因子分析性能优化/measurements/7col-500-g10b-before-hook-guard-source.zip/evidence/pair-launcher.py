"""Serial fixed-500 G10 A/B screen; pair 1 is full, pairs 2/3 independently compare 027 only.

Usage: python .codex-tmp/iteration49_g10_panel_once_pairs.py CONFIG.json
The JSON config supplies pinned BT snapshot/live candidate, one shared FC snapshot,
tool/data pins, exact candidate status/deltas, pair list, output root and prefix.
For pairs 2/3, canonical verifier controls 025/026 are reused from pair 1 and an
additional receipt explicitly reports scope_complete=false for the new 027-only pair.
"""
import hashlib
import json
import re
import runpy
import subprocess
import sys
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
PAIR_HELPER = ROOT / ".codex-tmp/iteration49_next_pairs.py"
PAIR_HELPER_SHA256 = "541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb"
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
EXAMPLES = ("025", "026", "027")
ORDERS = {1: ("a", "b"), 2: ("b", "a"), 3: ("a", "b")}
EXPECTED_ENGINES = {
    "a": {"025": "runonce", "026": "runonce", "027": "runnext"},
    "b": {"025": "runonce", "026": "runonce", "027": "runonce"},
}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def pin(path):
    raw = Path(path).read_bytes()
    return {"size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def execute(args, log, cwd):
    assert not log.exists(), log
    with log.open("xb") as stream:
        result = subprocess.run([sys.executable, *map(str, args)], cwd=cwd,
                                stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))


def source_state(cfg, helper):
    workspace = Path(cfg["workspace_root"]).resolve(strict=True)
    helper["check_tools"](workspace, cfg)
    base_root, base_manifest = helper["snapshot"](cfg["backtrader_snapshot"])
    fc_root, fc_manifest = helper["snapshot"](cfg["fincore_snapshot"])
    assert len(base_manifest["files"]) == 621 and RUNNER not in base_manifest["files"]
    candidate_root, candidate_files = helper["candidate_worktree"](
        cfg["backtrader_candidate"], base_root, base_manifest["files"])
    assert candidate_root == workspace
    candidate = cfg["backtrader_candidate"]
    assert candidate["expected_file_count"] == 621
    scopes = candidate["source_scopes"]
    assert not any(RUNNER == scope or RUNNER.startswith(scope.rstrip("/") + "/")
                   for scope in scopes), scopes
    assert RUNNER in candidate["status_scopes"]
    runner_pin = cfg["tool_pins"][RUNNER]
    assert RUNNER not in candidate_files
    candidate_files[RUNNER] = {"sha256": runner_pin["sha256"].lower(),
                               "size_bytes": runner_pin["size_bytes"]}
    assert pin(workspace / RUNNER) == candidate_files[RUNNER]
    assert len(candidate_files) == 622
    assert _has_modified_path(candidate["expected_status"], RUNNER)
    assert _has_modified_path(candidate["result_source_status"], RUNNER)
    helper["check_tools"](workspace, cfg)
    return (workspace, base_root, base_manifest, candidate_root, candidate_files,
            fc_root, fc_manifest)


def _has_modified_path(status_rows, path):
    return any(len(row) >= 4 and row[3:] == path and "M" in row[:2]
               for row in status_rows)


def check_state(cfg, helper, state, data):
    assert source_state(cfg, helper) == state
    helper["check_data"](data)


def validate_run(out, arm, example, cfg, helper, state, data):
    result = read(out / "result.json")
    workspace, base_root, base_manifest, candidate_root, candidate_files, fc_root, fc_manifest = state
    assert (result.get("status"), result.get("profile"), result.get("example"),
            result.get("input_universe"), result.get("runner_exit_code"),
            result.get("example_exit_code")) == ("COMPLETED", "full", example, "fixed500", 0, 0)
    assert not result.get("source_or_input_changes") and not result.get("summary_check_errors")
    assert result.get("runner_sha256") == cfg["tool_pins"][RUNNER]
    for key in ("backtrader_source", "fincore_source", "data_identity"):
        assert result.get(key + "_before") == result.get(key + "_after"), key
    assert (Path(result["data_root"]).resolve(), Path(result["selection_path"]).resolve()) == data[:2]
    assert (result.get("data_identity_before"), result.get("data_files_before")) == data[2:]
    if arm == "a":
        expected_root, expected_manifest = base_root, base_manifest
        source = result.get("backtrader_source_before", {})
        assert (source.get("kind"), source.get("commit"), source.get("manifest_sha256")) == (
            "verified_snapshot_manifest_v1", cfg["backtrader_snapshot"]["commit"],
            cfg["backtrader_snapshot"]["manifest_sha256"])
        expected_files = expected_manifest["files"]
    else:
        expected_root, expected_manifest = candidate_root, None
        source = result.get("backtrader_source_before", {})
        candidate = cfg["backtrader_candidate"]
        assert (source.get("kind"), source.get("commit"), source.get("branch")) == (
            "git_worktree", candidate["commit"], candidate["branch"])
        assert sorted(source.get("source_status", [])) == sorted(candidate["result_source_status"])
        assert _has_modified_path(source.get("source_status", []), RUNNER)
        expected_files = candidate_files
    assert result.get("backtrader_files_before") == expected_files
    fc_source = result.get("fincore_source_before", {})
    assert (fc_source.get("kind"), fc_source.get("commit"), fc_source.get("manifest_sha256")) == (
        "verified_snapshot_manifest_v1", cfg["fincore_snapshot"]["commit"],
        cfg["fincore_snapshot"]["manifest_sha256"])
    assert result.get("fincore_files_before") == fc_manifest["files"]
    summary = result.get("summary") or {}
    assert (summary.get("symbols"), summary.get("dates"), summary.get("factor_mode"),
            summary.get("factor_calculation")) == (500, 243, "native", "RAN")
    expected_engine = cfg["expected_engines"][arm][example]
    assert (result.get("expected_engine"), result.get("observed_engine")) == (
        expected_engine, expected_engine)
    cli = result.get("example_cli_arguments") or []
    for flag, value in (("--data-dir", str(data[0])), ("--max-symbols", "500"),
                        ("--factor-mode", "native")):
        assert cli.count(flag) == 1
        actual = cli[cli.index(flag) + 1]
        assert (str(Path(actual).resolve()) if flag == "--data-dir" else actual) == value
    return result


def output(root, prefix, pair, arm, example):
    return root / f"{prefix}-p{pair}-{arm}-{example}"


def check_pair1_controls(root, prefix, cfg, helper, state, data):
    receipt = root / f"{prefix}-p1-verification.json"
    verified = read(receipt)
    assert verified.get("status") == "PASS" and verified.get("valid") is True
    assert verified.get("scope_complete") is True
    assert set(verified.get("comparisons", {})) == set(EXAMPLES)
    assert all(row.get("valid") is True for row in verified["comparisons"].values())
    for arm in ("a", "b"):
        for example in EXAMPLES:
            validate_run(output(root, prefix, 1, arm, example), arm, example,
                         cfg, helper, state, data)
    return verified


def verify_pair(pair, root, prefix, workspace, cfg, helper, state, data):
    if pair == 1:
        canonical_path = root / f"{prefix}-p1-verification.json"
        assignment_pair = 1
        partial = False
    else:
        canonical_path = root / f"{prefix}-p{pair}-control-inclusive-verification.json"
        assignment_pair = pair
        partial = True
        check_pair1_controls(root, prefix, cfg, helper, state, data)
    assert not canonical_path.exists()
    args = [workspace / VERIFIER, "--data-root", data[0], "--selection", data[1],
            "--universe", "fixed500", "--output", canonical_path]
    for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
        for example in EXAMPLES:
            run_pair = 1 if partial and example != "027" else assignment_pair
            path = output(root, prefix, run_pair, arm, example)
            validate_run(path, arm, example, cfg, helper, state, data)
            args.extend((flag, f"{example}={path}"))
    check_state(cfg, helper, state, data)
    execute(args, canonical_path.with_suffix(".log"), workspace)
    check_state(cfg, helper, state, data)
    verified = read(canonical_path)
    assert verified.get("status") == "PASS" and verified.get("valid") is True
    assert verified.get("scope_complete") is True
    assert set(verified.get("comparisons", {})) == set(EXAMPLES)
    assert all(row.get("valid") is True for row in verified["comparisons"].values())
    if partial:
        partial_path = root / f"{prefix}-p{pair}-partial-scope.json"
        receipt = {
            "schema": "iteration49.g10-panel-once.partial-fixed500-verification.v1",
            "status": "PASS" if verified["comparisons"]["027"]["valid"] else "FAIL",
            "mode": "ab-pair-partial-independent-scope",
            "valid": bool(verified["comparisons"]["027"]["valid"]),
            "scope_complete": False,
            "independent_examples": ["027"],
            "independent_scope_complete": True,
            "comparisons": {"027": verified["comparisons"]["027"]},
            "reused_controls": {
                example: {"source_pair": 1, "comparison_valid": verified["comparisons"][example]["valid"],
                          "baseline": str(output(root, prefix, 1, "a", example)),
                          "candidate": str(output(root, prefix, 1, "b", example))}
                for example in ("025", "026")
            },
            "canonical_control_inclusive_verifier": {
                "path": str(canonical_path), "sha256": pin(canonical_path)["sha256"],
                "status": verified["status"], "scope_complete": verified["scope_complete"]},
            "current_pair_027": {
                "baseline": str(output(root, prefix, pair, "a", "027")),
                "candidate": str(output(root, prefix, pair, "b", "027"))},
            "note": "The canonical verifier requires all three examples for A/B. It checked pair-1 025/026 as reused controls and this pair's full 027 output; only 027 is a new independent comparison.",
        }
        assert not partial_path.exists()
        with partial_path.open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        print(f"PAIR {pair} PARTIAL INDEPENDENT OUTPUT PASS: 027 only; 025/026 reused pair-1 controls", flush=True)
    else:
        print("PAIR 1 COMPLETE THREE-EXAMPLE OUTPUT PASS", flush=True)


def main():
    assert len(sys.argv) == 2, "usage: script.py CONFIG.json"
    cfg_path = Path(sys.argv[1]).resolve(strict=True)
    config_sha = pin(cfg_path)["sha256"]
    cfg = read(cfg_path)
    assert cfg.get("schema_version") == 1 and pin(cfg_path)["sha256"] == config_sha
    assert cfg.get("workspace_root") == str(ROOT)
    pairs = cfg.get("pairs")
    assert pairs in ([1], [2, 3], [1, 2, 3]), pairs
    assert cfg["expected_engines"] == EXPECTED_ENGINES
    helper_path = PAIR_HELPER
    assert hashlib.sha256(helper_path.read_bytes()).hexdigest() == PAIR_HELPER_SHA256
    helper = runpy.run_path(str(helper_path), run_name="paired_summary_helpers")
    state = source_state(cfg, helper)
    data = helper["data_state"](cfg)
    helper["check_data"](data)
    root, prefix = Path(cfg["output_root"]).resolve(strict=True), cfg["output_prefix"]
    assert re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", prefix), prefix
    protected = (state[1], state[3], state[5], data[0])
    assert all(not helper["under"](root, item) for item in protected)
    assert not helper["under"](root, Path(cfg["workspace_root"]))
    if any(pair > 1 for pair in pairs):
        check_pair1_controls(root, prefix, cfg, helper, state, data)
    for pair in pairs:
        examples = EXAMPLES if pair == 1 else ("027",)
        for example in examples:
            for arm in ORDERS[pair]:
                out = output(root, prefix, pair, arm, example)
                assert not out.exists() and not out.with_suffix(".log").exists(), out
        verifier = (root / f"{prefix}-p1-verification.json" if pair == 1 else
                    root / f"{prefix}-p{pair}-control-inclusive-verification.json")
        assert not verifier.exists() and not verifier.with_suffix(".log").exists(), verifier
        if pair > 1:
            assert not (root / f"{prefix}-p{pair}-partial-scope.json").exists()
    print(f"G10 config sha256={config_sha}; pairs={pairs}; serial; fixed500x243; native", flush=True)
    unrelated = cfg["backtrader_candidate"].get("preserved_unrelated", {})
    for name, expected in unrelated.items():
        actual = pin(Path(cfg["workspace_root"]) / name)
        assert actual["sha256"] == expected["sha256"] and actual["size_bytes"] == expected["size_bytes"]
        print(f"UNRELATED_PRESERVED_NOT_EXECUTED: {name} {actual['sha256']}", flush=True)
    for pair in pairs:
        examples = EXAMPLES if pair == 1 else ("027",)
        for example in examples:
            for arm in ORDERS[pair]:
                check_state(cfg, helper, state, data)
                out = output(root, prefix, pair, arm, example)
                source_root = state[1] if arm == "a" else state[3]
                args = [ROOT / RUNNER, "--source-root", source_root, "--fincore-root", state[5],
                        "--data-root", data[0], "--selection", data[1], "--universe", "fixed500",
                        "--example", example, "--profile", "full", "--expected-engine",
                        cfg["expected_engines"][arm][example], "--output", out]
                helper["check_tools"](ROOT, cfg)
                execute(args, out.with_suffix(".log"), ROOT)
                result = validate_run(out, arm, example, cfg, helper, state, data)
                print(json.dumps({"pair": pair, "arm": arm, "example": example,
                                  "wall_s": result["example_main_wall_ns"] / 1e9,
                                  "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                                  "peak_bytes": max(result["main_peak_working_set_bytes"],
                                                    result["resource_peak_tree_rss_bytes"])}), flush=True)
                check_state(cfg, helper, state, data)
        verify_pair(pair, root, prefix, ROOT, cfg, helper, state, data)
    assert pin(cfg_path)["sha256"] == config_sha


if __name__ == "__main__":
    main()
