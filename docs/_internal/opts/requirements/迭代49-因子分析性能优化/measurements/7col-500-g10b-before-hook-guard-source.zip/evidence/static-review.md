# Iteration 49 panel once G10b static review

**Verdict: GO_STATIC_REVIEW_ONLY.** The first G10b review was HOLD because the optimized multiply kernel could call a replaced `Multiply._apply` while feed cursors were deferred. The frozen successor adds the narrow identity guard and fallback regression described below; that blocker is resolved in the current pins.

Reviewed successor pins:

- `backtrader/research/operators.py`: 91,005 bytes, SHA-256 `409c777e45ba56d02b8c083c443c1828b6af44fd33e9fd5e2579599aaa8e4c0a`
- `tests/unit/test_factor_research_panel_once.py`: 12,819 bytes, SHA-256 `055f78b0bb39c3d9d039e88778f90b2b36f409851812990b29bab619d5f1b135`

`_panel_once_plan` now rejects the optimized `_MultiplyPanel` path unless `Multiply._apply` is identical to the import-time captured function, and the optimized kernel calls that captured function. A replacement hook therefore returns to the ordinary per-index callback, where the current feed clock is available. The added Alpha003 regression installs a replacement hook, verifies it is called and the multiply kernel is not entered, checks ordinary lifecycle coverage, and compares all node values/reasons against the runnext reference.

The rest of the reviewed G10b synchronization remains sound for the guarded standard path: empty ranges do not advance feeds; successful ranges finish at `end - 1` with `lencount == end` and final-bar tick-fill behavior preserved; failures synchronize at the failing index before strict wrapping. The strict regression checks target, date, phase and original cause. Exact standard feed/output line types, setter identity and empty binding lists preserve fallback for custom observers.

No tests, imports, lint, or benchmarks were run during this review. The author reports no QA for these successor pins yet; this is static source review only and establishes neither focused-test acceptance nor performance results.
