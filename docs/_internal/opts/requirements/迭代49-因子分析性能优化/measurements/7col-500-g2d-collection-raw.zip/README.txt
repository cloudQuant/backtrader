G2d raw 18 full example runs and three complete output verifiers; 500 symbols x 243 dates.
