"""Run G3 full-output pairs, reusing pair-1 025/026 controls for later 027 pairs."""

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
TEMP = Path("D:/temp")
BASELINE_BT = Path("D:/temp/iteration49-g2a-backtrader-02ee098a9")
BASELINE_COMMIT = "02ee098a972164f3d49d087713f3efc52729992a"
BASELINE_ARCHIVE_SHA256 = "1f623792493195d3d2545aa4b93a8ccdfd83a7cc3ce7b5adaf52d806c737f678"
FINCORE_COMMIT = "2ec366c033bb6b4c47fe1880d5a3f4ec5e407d64"
FINCORE_ARCHIVE_SHA256 = "6912e92b44f8ae9f9693d699364e07e42da74b5ff17ef86696dea5ffefbeaafa"
DATA = ROOT / "tests/datas/a_stocks"
SELECTION = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json"
EXAMPLES = ("025", "026", "027")
PINS = {
    "backtrader/research/operators.py": "bb44e4a6d595eb54b22beac721b10f2f48f7ff6159e9d4a62568f051d9394182",
    "tests/unit/test_factor_operator_window_read.py": "3085280009af48ca293244cc09df72e2db800ddb53a04e2559414a95ff722ca4",
    "scripts/benchmark_factor_examples.py": "a971ca097236c6ffbaf85f5291bf58e47022d1f452c861e810bc3b8190a2ea0a",
    "scripts/verify_factor_examples_benchmark.py": "10f27eda6f24ecca88142cbd978d9b1eb9cfedfad604bd96d289008cf59a23e7",
}
RUN_DAILY = "examples/backtest/027_alpha003_panel_acceptance/run_daily.py"
RUN_DAILY_BASELINE_SHA256 = "c522fde180c91d2d1c163460b1e17bb0770efd000f756f595ebb9083aa55940f"
RUN_DAILY_CANDIDATE_SHA256 = "206f13a98d7e153bd0cd6f5d42d38470fb7566788104b957af87614be5999220"


def check_pins():
    for name, expected in PINS.items():
        assert len(expected) == 64 and expected == expected.lower(), f"invalid sha256 pin: {name}"
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        assert actual == expected, f"source pin changed: {name}"


def run_path(pair, arm, example):
    return TEMP / f"iteration49-g3-window-p{pair}-{arm}-{example}"


def result_at(pair, arm, example):
    return json.loads((run_path(pair, arm, example) / "result.json").read_text(encoding="utf-8"))


def check_pair1_controls(fincore_manifest):
    verification = TEMP / "iteration49-g3-window-p1-verification.json"
    assert verification.is_file(), "pair 1 must pass before 027 extension pairs"
    prior = json.loads(verification.read_text(encoding="utf-8"))
    assert prior.get("status") == "PASS" and prior.get("scope_complete") is True

    fincore_identity = result_at(1, "a", "025")["fincore_source_before"]
    assert fincore_identity.get("kind") == "verified_snapshot_manifest_v1"
    assert fincore_identity.get("manifest_sha256") == hashlib.sha256(fincore_manifest.read_bytes()).hexdigest()
    backtrader_identity = {}
    for arm in ("a", "b"):
        backtrader_identity[arm] = check_result(
            result_at(1, arm, "025"), "025", arm, fincore_identity=fincore_identity
        )[0]
        for example in EXAMPLES:
            check_result(
                result_at(1, arm, example),
                example,
                arm,
                fincore_identity=fincore_identity,
                backtrader_identity=backtrader_identity[arm],
            )
    return fincore_identity, backtrader_identity


def check_only_window_source_change():
    baseline = result_at(1, "a", "025")["backtrader_files_before"]
    candidate = result_at(1, "b", "025")["backtrader_files_before"]
    changed = sorted(
        name for name in set(baseline) | set(candidate) if baseline.get(name) != candidate.get(name)
    )
    assert changed == ["backtrader/research/operators.py", RUN_DAILY], changed
    assert baseline[RUN_DAILY]["sha256"] == RUN_DAILY_BASELINE_SHA256
    assert candidate[RUN_DAILY]["sha256"] == RUN_DAILY_CANDIDATE_SHA256
    print(json.dumps({
        "source_delta": changed,
        "g3_candidate": "backtrader/research/operators.py",
        "run_daily": {
            "baseline_sha256": RUN_DAILY_BASELINE_SHA256,
            "candidate_sha256": RUN_DAILY_CANDIDATE_SHA256,
            "note": "027 sibling source; run.py is the selected entry and does not import run_daily.py",
        },
    }), flush=True)


def execute(args, log):
    assert not log.exists(), log
    with log.open("xb") as stream:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))


def check_result(result, example, arm, fincore_identity=None, backtrader_identity=None):
    assert result["status"] == "COMPLETED" and result["runner_exit_code"] == 0
    assert result["example"] == example and result["profile"] == "full"
    assert not result["source_or_input_changes"] and not result["summary_check_errors"]
    assert result["backtrader_source_before"] == result["backtrader_source_after"]
    assert result["fincore_source_before"] == result["fincore_source_after"]
    assert result["data_identity_before"] == result["data_identity_after"]
    assert result["runner_sha256"]["sha256"] == PINS["scripts/benchmark_factor_examples.py"]

    backtrader_identity_now = result["backtrader_source_before"]
    fincore_identity_now = result["fincore_source_before"]
    if arm == "a":
        assert backtrader_identity_now["kind"] == "verified_snapshot_manifest_v1"
        assert backtrader_identity_now["commit"] == BASELINE_COMMIT
    else:
        assert backtrader_identity_now["kind"] == "git_worktree"
        assert backtrader_identity_now["branch"] == "dev"
    assert fincore_identity_now["kind"] == "verified_snapshot_manifest_v1"
    if fincore_identity is not None:
        assert fincore_identity_now == fincore_identity, "accepted fincore snapshot changed across pairs"
    if backtrader_identity is not None:
        assert backtrader_identity_now == backtrader_identity, "Backtrader source changed across pairs"
    return backtrader_identity_now, fincore_identity_now


def verify_pair(pair, fincore_identity, pair1_backtrader):
    verification = TEMP / f"iteration49-g3-window-p{pair}-verification.json"
    assert not verification.exists(), verification
    args = [
        "scripts/verify_factor_examples_benchmark.py",
        "--data-root", str(DATA),
        "--selection", str(SELECTION),
        "--output", str(verification),
    ]
    for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
        for example in EXAMPLES:
            source_pair = 1 if pair > 1 and example in ("025", "026") else pair
            result = result_at(source_pair, arm, example)
            check_result(
                result,
                example,
                arm,
                fincore_identity=fincore_identity,
                backtrader_identity=pair1_backtrader[arm] if source_pair == 1 else None,
            )
            args.extend((flag, f"{example}={run_path(source_pair, arm, example)}"))
    execute(args, verification.with_suffix(".log"))
    verified = json.loads(verification.read_text(encoding="utf-8"))
    assert verified["status"] == "PASS" and verified["scope_complete"] is True
    print(json.dumps({
        "pair": pair,
        "verification": str(verification),
        "status": "PASS",
        "new_full_runs": ["025", "026", "027"] if pair == 1 else ["027"],
        "reused_pair1_controls": [] if pair == 1 else ["025", "026"],
        "note": "Repeated 027 verifications reuse pair-1 025/026 controls; they are not new full three-example pairs.",
    }), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fincore-snapshot", type=Path, required=True)
    parser.add_argument("--pair", type=int, action="append", choices=(1, 2, 3), required=True)
    args = parser.parse_args()
    pairs = args.pair
    assert pairs == sorted(set(pairs)), "request unique pairs in ascending order"
    fincore_root = args.fincore_snapshot.resolve(strict=True)
    fincore_manifest = fincore_root / ".iteration49-source.json"
    assert fincore_manifest.is_file(), "accepted G1b fincore snapshot manifest is required"
    fincore_metadata = json.loads(fincore_manifest.read_text(encoding="utf-8"))
    assert fincore_metadata.get("commit") == FINCORE_COMMIT
    assert fincore_metadata.get("archive_sha256") == FINCORE_ARCHIVE_SHA256
    assert BASELINE_BT.is_dir() and (BASELINE_BT / ".iteration49-source.json").is_file()
    baseline_manifest = json.loads((BASELINE_BT / ".iteration49-source.json").read_text(encoding="utf-8"))
    assert baseline_manifest.get("commit") == BASELINE_COMMIT
    assert baseline_manifest.get("archive_sha256") == BASELINE_ARCHIVE_SHA256
    check_pins()

    pair1_verification = TEMP / "iteration49-g3-window-p1-verification.json"
    pair1_backtrader = None
    fincore_identity = None
    for pair in pairs:
        if pair > 1:
            if pair1_backtrader is None:
                fincore_identity, pair1_backtrader = check_pair1_controls(fincore_manifest)
            assert pair1_backtrader is not None and fincore_identity is not None
            expected_examples = ("027",)
        else:
            expected_examples = EXAMPLES
        order = ("a", "b") if pair % 2 else ("b", "a")
        for example in expected_examples:
            for arm in order:
                check_pins()
                destination = run_path(pair, arm, example)
                assert not destination.exists(), destination
                source_root = BASELINE_BT if arm == "a" else ROOT
                print(f"START G3 pair={pair} arm={arm} example={example}", flush=True)
                execute([
                    "scripts/benchmark_factor_examples.py",
                    "--source-root", str(source_root),
                    "--fincore-root", str(fincore_root),
                    "--data-root", str(DATA),
                    "--selection", str(SELECTION),
                    "--example", example,
                    "--profile", "full",
                    "--output", str(destination),
                ], destination.with_suffix(".log"))
                result = json.loads((destination / "result.json").read_text(encoding="utf-8"))
                bt_identity, current_fincore_identity = check_result(
                    result,
                    example,
                    arm,
                    fincore_identity=fincore_identity,
                    backtrader_identity=pair1_backtrader[arm] if pair > 1 else None,
                )
                if fincore_identity is None:
                    fincore_identity = current_fincore_identity
                if pair == 1:
                    pair1_backtrader = pair1_backtrader or {}
                    pair1_backtrader[arm] = bt_identity
                print(json.dumps({
                    "pair": pair,
                    "arm": arm,
                    "example": example,
                    "wall_s": result["example_main_wall_ns"] / 1e9,
                    "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                    "peak_bytes": max(result["main_peak_working_set_bytes"], result["resource_peak_tree_rss_bytes"]),
                }), flush=True)
                check_pins()
        if pair == 1:
            check_only_window_source_change()
            pair1_backtrader = {
                arm: check_result(result_at(1, arm, "025"), "025", arm, fincore_identity=fincore_identity)[0]
                for arm in ("a", "b")
            }
        verify_pair(pair, fincore_identity, pair1_backtrader)


if __name__ == "__main__":
    main()
