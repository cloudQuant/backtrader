"""Archive the frozen G3 pair evidence and measured public source files."""

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
TEMP = Path("D:/temp")
MEASUREMENTS = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements"
SUMMARY = ROOT / ".codex-tmp/iteration49_g3_window_summary.json"
PAIR_JSON = MEASUREMENTS / "7col-500-g3-window-pairs.json"
RAW_ZIP = MEASUREMENTS / "7col-500-g3-window-raw.zip"
SOURCE_ZIP = MEASUREMENTS / "7col-500-g3-window-measured-source.zip"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, expected=None):
    raw = path.read_bytes()
    if expected:
        assert digest(raw) == expected, f"pin mismatch: {path}"
    return raw


def archive(path, entries, readme):
    assert not path.exists(), f"refusing to overwrite {path}"
    material = {name: data for name, data in entries.items()}
    material["README.md"] = readme.encode("utf-8")
    manifest = {
        "schema_version": 1,
        "members": [{"path": n, "size_bytes": len(b), "sha256": digest(b)}
                    for n, b in sorted(material.items())],
    }
    material["MANIFEST.json"] = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode("utf-8")
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted(material.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def main():
    assert not PAIR_JSON.exists() and not RAW_ZIP.exists() and not SOURCE_ZIP.exists()
    summary_raw = read(SUMMARY, "8ee751a28cb38fa1d8fefc712c042768a6de08faf260c86ea184d5b33d272841")
    summary = json.loads(summary_raw.decode("utf-8"))
    assert summary["status"] == "SUMMARY_ONLY_FULL101_MATRIX_PENDING"
    PAIR_JSON.write_bytes(summary_raw)

    raw_entries = {}
    for run in summary["actual_runs"]:
        pair, arm, example = run["pair"], run["arm"], run["example"]
        stem = f"iteration49-g3-window-p{pair}-{arm}-{example}"
        result_path = TEMP / stem / "result.json"
        result_bytes = read(result_path, run["sha256"])
        raw_entries[f"results/p{pair}/{arm}-{example}/result.json"] = result_bytes
        raw_entries[f"logs/{stem}.log"] = read(TEMP / f"{stem}.log")
    for verifier in summary["verifiers"]:
        pair = verifier["pair"]
        vp = TEMP / f"iteration49-g3-window-p{pair}-verification.json"
        raw_entries[f"verifiers/p{pair}.json"] = read(vp, verifier["sha256"])
        log = vp.with_suffix(".log")
        if log.exists():
            raw_entries[f"verifiers/p{pair}.log"] = read(log)
    for rel in (
        ".codex-tmp/iteration49_g3_window_p1_reconciliation.json",
        ".codex-tmp/iteration49_g3_window_summary.json",
        ".codex-tmp/iteration49_g3_window_summary.py",
        ".codex-tmp/iteration49_g3_window_formal.py",
        ".codex-tmp/iteration49_g3_window_archive_builder.py",
        ".codex-tmp/iteration49-g3-window-functional.json",
    ):
        raw_entries["evidence/" + rel.replace("\\", "/")] = read(ROOT / rel)
    raw_entries["history/pair1-orchestration-note.txt"] = (
        "Pair 1's six actual runs completed; the original orchestration helper then failed its "
        "source-set assertion because it expected only the operator and run_daily sibling paths. "
        "The source delta was independently reconciled: twelve service paths are LF/CRLF-only, "
        "operators.py is the G3 candidate, run_daily.py is an unrelated sibling change, and the "
        "same benchmark runner was used by both arms although its path is outside the baseline "
        "snapshot map. No pair-1 benchmark was repeated. The existing pair-1 verifier subsequently "
        "passed. This is orchestration/source-map accounting history, not a benchmark failure.\n"
    ).encode("utf-8")
    archive(
        RAW_ZIP,
        raw_entries,
        "G3 fixed-500 evidence only. Contains ten actual result JSONs and their runner logs, "
        "three PASS verifier outputs (and logs where present), finite reconciliation/summary "
        "records, and the frozen helper sources. Pair 1 has 025/026/027; pairs 2 and 3 add 027 "
        "only. Their verifiers reuse pair-1 025/026 controls, yielding five unique comparisons. "
        "The full-101 matrix is pending and is not included.",
    )

    baseline = Path("D:/temp/iteration49-g2a-backtrader-02ee098a9")
    fincore = Path("D:/temp/iteration49-g1b-fincore-2ec366c")
    sources = {
        "baseline/backtrader/research/operators.py": baseline / "backtrader/research/operators.py",
        "candidate/backtrader/research/operators.py": ROOT / "backtrader/research/operators.py",
        "candidate/tests/unit/test_factor_operator_window_read.py": ROOT / "tests/unit/test_factor_operator_window_read.py",
        "shared/scripts/benchmark_factor_examples.py": ROOT / "scripts/benchmark_factor_examples.py",
        "shared/scripts/verify_factor_examples_benchmark.py": ROOT / "scripts/verify_factor_examples_benchmark.py",
        "shared/docs/benchmark-500-7col.json": ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json",
        "baseline/.iteration49-source.json": baseline / ".iteration49-source.json",
        "fincore/.iteration49-source.json": fincore / ".iteration49-source.json",
        "dependency/7col-500-g1b-measured-source.zip": MEASUREMENTS / "7col-500-g1b-measured-source.zip",
    }
    source_entries = {name: read(path) for name, path in sources.items()}
    expected_source_hashes = {
        "baseline/backtrader/research/operators.py": "2efd932cdf345f03f73a8d8c8b544e16dddd465fba9d4e5d64ede1089f0f50fb",
        "candidate/backtrader/research/operators.py": "bb44e4a6d595eb54b22beac721b10f2f48f7ff6159e9d4a62568f051d9394182",
        "candidate/tests/unit/test_factor_operator_window_read.py": "3085280009af48ca293244cc09df72e2db800ddb53a04e2559414a95ff722ca4",
        "shared/scripts/benchmark_factor_examples.py": "a971ca097236c6ffbaf85f5291bf58e47022d1f452c861e810bc3b8190a2ea0a",
        "shared/scripts/verify_factor_examples_benchmark.py": "10f27eda6f24ecca88142cbd978d9b1eb9cfedfad604bd96d289008cf59a23e7",
        "baseline/.iteration49-source.json": "c53c3b883eaa6d2e8a23a8cd45c94596100f9cc0f19a949c1ce9a7f7dcf83910",
        "fincore/.iteration49-source.json": "c424ba06a26b9db8c5481424fc096912eb22c01a1f103823cbbdf8ecf0f6389e",
        "dependency/7col-500-g1b-measured-source.zip": "567de50e58b605aba80a600d59dec06b08d9871a2956ba1034768c8c071c62f9",
    }
    assert {name: digest(data) for name, data in source_entries.items() if name in expected_source_hashes} == expected_source_hashes
    base_manifest = json.loads(source_entries["baseline/.iteration49-source.json"].decode("utf-8"))
    fincore_manifest = json.loads(source_entries["fincore/.iteration49-source.json"].decode("utf-8"))
    assert base_manifest["commit"] == "02ee098a972164f3d49d087713f3efc52729992a"
    assert fincore_manifest["commit"] == "2ec366c033bb6b4c47fe1880d5a3f4ec5e407d64"
    expected_run_hashes = {
        "examples/backtest/025_factor_single/run.py": "7a513386be0d452aa1738db322d606bb92ac43cd139e08b31552a81faf633104",
        "examples/backtest/026_factor_multi/run.py": "d7d9532a35ccf4a29cd6e3136f00d4ccd2836f1f77455a956efe068c853ecf8f",
        "examples/backtest/027_alpha003_panel_acceptance/run.py": "22ca22f504674c823b9cf98a54e6269dd8b01bd196d4c3c6985ac90140f8fa93",
    }
    for example, rel in (
        ("025", "examples/backtest/025_factor_single/run.py"),
        ("026", "examples/backtest/026_factor_multi/run.py"),
        ("027", "examples/backtest/027_alpha003_panel_acceptance/run.py"),
    ):
        base_bytes, candidate_bytes = read(baseline / rel), read(ROOT / rel)
        assert base_bytes == candidate_bytes, f"unexpected example entry delta: {rel}"
        assert digest(candidate_bytes) == expected_run_hashes[rel], f"run pin mismatch: {rel}"
        source_entries[f"shared/{rel}"] = candidate_bytes
    archive(
        SOURCE_ZIP,
        source_entries,
        "Measured public sources and dependency manifests for the fixed-500 G3 window candidate. "
        "The only production source difference between baseline and candidate is research/operators.py; "
        "the focused test and same runner/verifier are included. The 025/026/027 run.py files are "
        "byte-identical across the two Backtrader roots. run_daily.py is an unrelated, unselected "
        "user-edited sibling and is deliberately excluded. The paired result/source-map records "
        "carry the exact snapshot and runner pins; this is not a full-runtime source checkout.",
    )

    print(json.dumps({
        "status": "ARCHIVES_CREATED_FULL101_PENDING",
        "pairs_json": str(PAIR_JSON), "raw_zip": str(RAW_ZIP), "source_zip": str(SOURCE_ZIP),
        "raw_members": len(raw_entries) + 2, "source_members": len(source_entries) + 2,
    }))


if __name__ == "__main__":
    main()
