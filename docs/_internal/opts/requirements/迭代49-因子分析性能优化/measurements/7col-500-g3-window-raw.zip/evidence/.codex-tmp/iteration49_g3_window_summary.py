"""Summarize frozen G3 results; this helper does not run benchmarks or verifiers."""

import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
TEMP = Path("D:/temp")
OUTPUT = ROOT / ".codex-tmp/iteration49_g3_window_summary.json"
RUNNER_SHA = "a971ca097236c6ffbaf85f5291bf58e47022d1f452c861e810bc3b8190a2ea0a"
RECON = ROOT / ".codex-tmp/iteration49_g3_window_p1_reconciliation.json"
RECON_SHA = "9783056a12a37d234f34a4d3fb3d752b95dc4b263d1b0ff46912d98ed7362464"
FUNCTIONAL = ROOT / ".codex-tmp/iteration49-g3-window-functional.json"
FUNCTIONAL_SHA = "7ca413f5e98e109a2fec0a7c3c6307427deff109b8c312db8a8e15933fb1efad"
RESULT_PINS = {
    (1, "a", "025"): "2a070df7b80a838f2634236988cdce69ec466a33ed573281c7eb4b2dbb9eac2f",
    (1, "a", "026"): "9aded5fe09574c47692d1e5aee8b746fcdad1b4ab58c3a0004f5d69850e5ce8a",
    (1, "a", "027"): "c3a76dd118292bebdfc29359560678624eeb4eea31253f8062b889b1c0e22ee4",
    (1, "b", "025"): "1f31c0c21c15077474f81526b6b080d4432cf353d12fee3a1f4fd2e20b1496d9",
    (1, "b", "026"): "523a3f00afd20ad89dea0841af02ddf9fed8ccd93679e66828f4443a4855b33e",
    (1, "b", "027"): "de32429bb01da6663371cadef4729c0b48df4f7c601fc674b21dffbabf8039ec",
    (2, "a", "027"): "06353173c53c31735259be6c485fdb70109fd8fc57b7be38be08838ed7c4a3b9",
    (2, "b", "027"): "951d806560cc027aa7a589f8671b3dbeaf0f444595aa6dd95e52643b5485b3e6",
    (3, "a", "027"): "2e09ab29f053c5885463c3d0896906a05ac23cfae7d41abca3fc18221984d151",
    (3, "b", "027"): "8b7519ce05eefd931829e41756a4a4a719bb91b8e60e9b6967ad7c60b8beb35e",
}
VERIFIER_PINS = {
    1: "084a6b12472228f38349333f2524764982aa8b213006cd8467b8455c9da9184b",
    2: "cbca20e0040e2b2507a4efd1ed41d23deeee287fe95df23b44d4d62f1de98a58",
    3: "413d645f16137a74768f0b6de5f6f5c16e84809ed584730e98625a7c54472523",
}
SPECS = [(p, a, e) for p, es in ((1, ("025", "026", "027")), (2, ("027",)), (3, ("027",)))
         for e in es for a in ("a", "b")]


def read_pinned(path, expected):
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected, f"pin mismatch: {path}"
    return json.loads(raw.decode("utf-8"))


def main():
    assert not OUTPUT.exists(), f"refusing to overwrite {OUTPUT}"
    recon = read_pinned(RECON, RECON_SHA)
    functional = read_pinned(FUNCTIONAL, FUNCTIONAL_SHA)
    assert recon["status"] == "PASS_PAIR1_EVIDENCE_RECONCILED"
    assert functional["focused"]["passed"] == 11
    stable = recon["stable_identities"]
    results, actual = {}, []
    for pair, arm, example in SPECS:
        path = TEMP / f"iteration49-g3-window-p{pair}-{arm}-{example}" / "result.json"
        result = read_pinned(path, RESULT_PINS[(pair, arm, example)])
        assert result["status"] == "COMPLETED" and result["runner_exit_code"] == 0
        assert result["example"] == example and result["profile"] == "full"
        assert result["source_or_input_changes"] == [] and result["summary_check_errors"] == []
        assert result["backtrader_source_before"] == result["backtrader_source_after"]
        assert result["fincore_source_before"] == result["fincore_source_after"]
        assert result["data_identity_before"] == result["data_identity_after"]
        assert result["backtrader_source_before"] == stable["backtrader_by_arm"][arm]
        assert result["fincore_source_before"] == stable["fincore"]
        assert result["data_identity_before"] == stable["data"]
        assert result["runner_sha256"]["sha256"] == RUNNER_SHA
        results[(pair, arm, example)] = result
        actual.append({"pair": pair, "arm": arm, "example": example,
                       "result_path": str(path), "sha256": RESULT_PINS[(pair, arm, example)],
                       "wall_s": result["example_main_wall_ns"] / 1e9,
                       "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                       "peak_bytes": max(result["main_peak_working_set_bytes"],
                                          result["resource_peak_tree_rss_bytes"])})

    verifiers = []
    for pair, expected in VERIFIER_PINS.items():
        path = TEMP / f"iteration49-g3-window-p{pair}-verification.json"
        result = read_pinned(path, expected)
        assert result["status"] == "PASS" and result["scope_complete"] is True
        verifiers.append({"pair": pair, "path": str(path), "sha256": expected, "status": "PASS"})

    metric = {
        "wall_s": lambda r: r["example_main_wall_ns"] / 1e9,
        "cpu_s": lambda r: r["example_main_process_cpu_ns"] / 1e9,
        "peak_bytes": lambda r: max(r["main_peak_working_set_bytes"], r["resource_peak_tree_rss_bytes"]),
    }
    pairs = []
    for pair in (1, 2, 3):
        a, b = results[(pair, "a", "027")], results[(pair, "b", "027")]
        pairs.append({"pair": pair, "metrics": {
            name: {"baseline": get(a), "candidate": get(b),
                   "candidate_vs_baseline_pct": (get(b) / get(a) - 1) * 100}
            for name, get in metric.items()}})
    medians = {}
    for name in metric:
        effects = [p["metrics"][name]["candidate_vs_baseline_pct"] for p in pairs]
        spread = max(effects) - min(effects)
        medians[name] = {"median_paired_change_pct": statistics.median(effects),
                         "spread_percentage_points": spread,
                         "dispersion_over_5pp": spread > 5.0}

    document = {
        "schema_version": 1,
        "status": "SUMMARY_ONLY_FULL101_MATRIX_PENDING",
        "actual_runs": actual,
        "actual_run_count": len(actual),
        "verifiers": verifiers,
        "unique_comparison_count": 5,
        "unique_comparisons": ["p1/025", "p1/026", "p1/027", "p2/027", "p3/027"],
        "comparison_note": "Three verifiers have nine comparison slots; pair1 025/026 are reused in pairs2/3, so there are five unique comparisons (3+1+1).",
        "compatibility_controls": "025/026 each have one actual A/B pair only; reused as verifier controls, not represented as three pairs.",
        "paired_027": {"pairs": pairs, "median": medians,
                       "dispersion_policy": "flag spread >5 percentage points; do not autoextend runs"},
        "finite_records": {
            "pair1_reconciliation": {"path": str(RECON), "sha256": RECON_SHA},
            "functional_record": {"path": str(FUNCTIONAL), "sha256": FUNCTIONAL_SHA},
        },
        "limitation": "Summary only; full-101 matrix remains pending; no benchmark/verifier is run by this helper.",
    }
    OUTPUT.write_text(json.dumps(document, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": document["status"], "output": str(OUTPUT), "runs": 10, "unique_comparisons": 5}))


if __name__ == "__main__":
    main()
