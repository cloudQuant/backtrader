"""Aggregate completed G2a fixed-500 pairs; reads runs and writes one new summary."""
import hashlib
import json
import statistics
from pathlib import Path

TEMP = Path("D:/temp")
PAIRS, EXAMPLES = (1, 2, 3), ("025", "026", "027")
BASELINE_BT = "3832c442ae349c875cb23573e9665a84cd3e051e"
FINCORE = "4c8e375be6b5889686882dd753b3180182e58f78"
SELECTION = "14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc"
SYMBOLS = "dda661efc19e42770028a61d4b43a4160a0bf08b3adf4dae353e8234d7ad5dbe"
DATA = Path("D:/source_code/backtrader/tests/datas/a_stocks")
OUTPUT = TEMP / "iteration49-7col-g2a-fcg1-paired-summary.json"
WALL_CPU_MAX, PEAK_MAX, WALL_DISPERSION_MAX = 1.03, 0.90, 0.05

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run_path(pair, arm, example):
    return TEMP / f"iteration49-7col-g2a-fcg1-p{pair}-{arm}-{example}" / "result.json"

def verify_path(pair):
    return TEMP / f"iteration49-7col-g2a-fcg1-p{pair}-verification.json"

def run(path, arm, example):
    v, label = read(path), f"{path.parent.name}"
    need(v.get("status") == "COMPLETED" and v.get("runner_exit_code") == 0 and v.get("example_exit_code") == 0, f"{label}: run incomplete")
    need(v.get("example") == example and v.get("profile") == "full", f"{label}: example/profile mismatch")
    need(not v.get("source_or_input_changes") and not v.get("summary_check_errors"), f"{label}: source/summary check failure")
    s = v.get("summary") or {}
    need(s.get("status") == "COMPLETED" and s.get("symbols") == 500 and s.get("dates") == 243, f"{label}: output shape")
    need(s.get("factor_mode") == "native" and s.get("factor_calculation") == "RAN", f"{label}: factor config")
    args = v.get("example_cli_arguments") or []
    def arg(flag):
        hits = [i for i, item in enumerate(args) if item == flag]
        need(len(hits) == 1 and hits[0] + 1 < len(args), f"{label}: missing/duplicate {flag}")
        return args[hits[0] + 1]
    need(arg("--max-symbols") == "500" and arg("--factor-mode") == "native", f"{label}: CLI config")
    need(Path(arg("--data-dir")).resolve() == DATA.resolve() and "--report" in args, f"{label}: CLI data/report")
    identity = v.get("data_identity_before")
    need(identity is not None and identity == v.get("data_identity_after"), f"{label}: input identity changed")
    need(identity.get("selection_sha256") == SELECTION and identity.get("ordered_symbols_sha256") == SYMBOLS, f"{label}: selection hash")
    bt, bt_after = v.get("backtrader_source_before"), v.get("backtrader_source_after")
    fc, fc_after = v.get("fincore_source_before"), v.get("fincore_source_after")
    need(bt is not None and bt == bt_after and fc is not None and fc == fc_after and fc.get("commit") == FINCORE, f"{label}: source identity")
    if arm == "a":
        need(bt.get("commit") == BASELINE_BT and bt.get("kind") == "verified_snapshot_manifest_v1", f"{label}: A snapshot")
    else:
        need(bt.get("kind") == "git_worktree" and bt.get("branch") == "dev" and bt.get("commit") != BASELINE_BT, f"{label}: B G2a dev source")
    phases, samples = v.get("phase_timers"), v.get("resource_samples") or []
    wall, cpu = v.get("example_main_wall_ns"), v.get("example_main_process_cpu_ns")
    main_peak, tree_peak = v.get("main_peak_working_set_bytes"), v.get("resource_peak_tree_rss_bytes")
    need(isinstance(phases, dict) and samples, f"{label}: missing timers/resource samples")
    need(all(isinstance(x, (int, float)) and x > 0 for x in (wall, cpu, main_peak, tree_peak)), f"{label}: invalid metrics")
    return {"path": str(path), "sha256": sha(path), "started_utc": v.get("started_utc"), "finished_utc": v.get("finished_utc"),
            "engine": v.get("expected_engine"), "wall_seconds": wall / 1e9, "cpu_seconds": cpu / 1e9,
            "cli_wall_seconds": v["cli_total_wall_ns"] / 1e9, "peak_bytes": max(main_peak, tree_peak),
            "main_peak_bytes": main_peak, "tree_peak_bytes": tree_peak, "memory": v.get("memory"),
            "max_sampled_processes": max(len(x.get("processes") or []) for x in samples), "phases": phases,
            "backtrader": bt, "fincore": fc, "runner": v.get("runner_sha256"),
            "environment": v.get("environment"), "data_identity": identity, "summary": s}

def stages(rows):
    fields = ("wall_exclusive_ns", "wall_inclusive_ns", "process_cpu_exclusive_ns", "process_cpu_inclusive_ns")
    names = sorted({n for r in rows for arm in ("a", "b") for n in (r[arm]["phases"] or {})})
    out = {}
    for name in names:
        data = [{"pair": r["pair"], "a": r["a"]["phases"].get(name), "b": r["b"]["phases"].get(name)} for r in rows]
        arms, ratios = {}, {}
        for arm in ("a", "b"):
            timers = [x[arm] for x in data if x[arm] is not None]
            arms[arm] = {"observations": len(timers), "median_calls": statistics.median(x["calls"] for x in timers) if timers else None}
            for f in fields:
                values = [x[f] / 1e9 for x in timers if x.get(f) is not None]
                arms[arm][f.replace("_ns", "_seconds")] = statistics.median(values) if values else None
        for f in fields:
            values = [x["b"][f] / x["a"][f] for x in data if x["a"] and x["b"] and x["a"].get(f, 0) and x["b"].get(f) is not None]
            ratios[f.replace("_ns", "_seconds")] = statistics.median(values) if values else None
        out[name] = {"median_by_arm": arms, "median_b_over_a": ratios, "per_pair": data,
                     "note": "Inclusive/nested stage timers are not additive."}
    return out

def main():
    paths = [run_path(p, a, e) for p in PAIRS for a in ("a", "b") for e in EXAMPLES] + [verify_path(p) for p in PAIRS]
    missing = [str(p) for p in paths if not p.is_file()]
    need(not missing, "Wait for all G2a inputs:\n" + "\n".join(missing))
    need(not OUTPUT.exists(), f"Refusing to overwrite {OUTPUT}")
    pairs, identities, sources, fcs, runners, fixed_inputs = [], [], {"a": [], "b": []}, [], [], []
    for p in PAIRS:
        vp, verifier = verify_path(p), read(verify_path(p))
        need(verifier.get("schema") == "iteration49.fixed500_output_verification.v1", f"p{p}: verifier schema")
        need(verifier.get("status") == "PASS" and verifier.get("valid") is True and verifier.get("scope_complete") is True, f"p{p}: verifier not PASS")
        fixed = verifier["fixed_input"]
        need(fixed["symbol_count"] == 500 and fixed["date_count"] == 243 and fixed["selection_sha256"] == SELECTION and fixed["ordered_symbols_sha256"] == SYMBOLS, f"p{p}: verifier input")
        fixed_inputs.append(fixed)
        examples = {}
        for e in EXAMPLES:
            a, b = run(run_path(p, "a", e), "a", e), run(run_path(p, "b", e), "b", e)
            need(a["data_identity"] == b["data_identity"] and a["runner"] == b["runner"], f"p{p}-{e}: A/B input/runner mismatch")
            identities.extend((a["data_identity"], b["data_identity"]))
            sources["a"].append(a["backtrader"]); sources["b"].append(b["backtrader"])
            fcs.extend((a["fincore"], b["fincore"])); runners.extend((a["runner"], b["runner"]))
            examples[e] = {"a": a, "b": b, "run_order": "AB" if (a["started_utc"] or "") < (b["started_utc"] or "") else "BA"}
        pairs.append({"pair": p, "verification": {"path": str(vp), "sha256": sha(vp), "document": verifier}, "examples": examples})
    same = lambda xs: len({json.dumps(x, sort_keys=True) for x in xs}) == 1
    need(all(same(sources[a]) for a in ("a", "b")) and same(fcs) and same(runners), "Source/runner pins vary")
    need(same(identities) and same(fixed_inputs) and sources["a"][0]["commit"] == BASELINE_BT and fcs[0]["commit"] == FINCORE, "Source/input snapshot mismatch")
    results = {}
    for e in EXAMPLES:
        rows = []
        for pair in pairs:
            r, a, b = pair["examples"][e], pair["examples"][e]["a"], pair["examples"][e]["b"]
            rows.append({"pair": pair["pair"], **r, "ratios_b_over_a": {"wall": b["wall_seconds"] / a["wall_seconds"],
                "cpu": b["cpu_seconds"] / a["cpu_seconds"], "peak": b["peak_bytes"] / a["peak_bytes"]}})
        wr, cr, pr = ([x["ratios_b_over_a"][k] for x in rows] for k in ("wall", "cpu", "peak"))
        mw, mc, mp = statistics.median(wr), statistics.median(cr), statistics.median(pr)
        dispersion = (max(wr) - min(wr)) / mw
        pending = dispersion > WALL_DISPERSION_MAX
        status = "FAIL_PERFORMANCE_THRESHOLDS" if mw > WALL_CPU_MAX or mc > WALL_CPU_MAX or mp > PEAK_MAX else (
            "PENDING_EXTEND_UP_TO_5_PAIRS" if pending else "PASS_G2A_THREE_PAIR_MEASUREMENT_ONLY")
        metrics = ("wall_seconds", "cpu_seconds", "cli_wall_seconds", "peak_bytes", "main_peak_bytes", "tree_peak_bytes")
        results[e] = {"pairs": rows, "stage_breakdown": stages(rows), "median_ratios_b_over_a": {"wall": mw, "cpu": mc, "peak": mp},
            "wall_ratio_dispersion_range_over_median": dispersion,
            "median_absolute_values": {m: {a: statistics.median(x[a][m] for x in rows) for a in ("a", "b")} for m in metrics},
            "extension": {"required": pending, "max_pairs": 5, "additional_pairs": [4, 5] if pending else [], "acceptance_pending": pending}, "status": status}
    states = {x["status"] for x in results.values()}
    status = "FAIL_PERFORMANCE_THRESHOLDS" if "FAIL_PERFORMANCE_THRESHOLDS" in states else (
        "PENDING_EXTEND_UP_TO_5_PAIRS" if "PENDING_EXTEND_UP_TO_5_PAIRS" in states else "PASS_G2A_THREE_PAIR_MEASUREMENT_ONLY")
    summary = {"schema": "iteration49.g2a.fixed500.paired_summary.v1", "status": status,
        "scope": "500-symbol G2a measurement only; not 5,471-symbol or final Iteration 49 acceptance.",
        "thresholds": {"median_wall_cpu_ratio_max": WALL_CPU_MAX, "median_peak_ratio_max": PEAK_MAX,
            "wall_ratio_dispersion_range_over_median_max": WALL_DISPERSION_MAX,
            "dispersion_action": "If wall dispersion exceeds 5%, keep pending and add pairs 4/5."},
        "sources": {"a_backtrader": sources["a"][0], "b_backtrader": sources["b"][0], "fincore": fcs[0], "runner": runners[0]},
        "fixed_input": fixed_inputs[0], "pair_order_by_example": {e: [p["examples"][e]["run_order"] for p in pairs] for e in EXAMPLES},
        "verifications": [p["verification"] for p in pairs], "examples": results,
        "archive_note": "Retain each raw result and full verifier with SHA-256. Archive this summary/helper separately. If wall dispersion exceeds 5%, keep pending and add pairs 4/5."}
    with OUTPUT.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + "\n"); f.flush()
    print(json.dumps({"output": str(OUTPUT), "status": status}, ensure_ascii=False))

if __name__ == "__main__":
    main()
