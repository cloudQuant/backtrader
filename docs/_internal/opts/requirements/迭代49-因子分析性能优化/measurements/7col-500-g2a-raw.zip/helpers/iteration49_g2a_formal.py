"""Serial complete G2a pairs with the same accepted fincore snapshot."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('D:/source_code/backtrader')
TEMP = Path('D:/temp')
FC = Path(sys.argv[1])
assert FC.is_dir() and (FC / '.iteration49-source.json').is_file()
PINS = {
    'backtrader/research/sink.py': '4a766b73b3e86cce2e7aa3d8ea66f7b80a6bfdd63249fa2bafc8ac27387df542',
    'tests/unit/test_factor_sink.py': '0ac45a57f4e8b8a991f144d6e54d920bab7d6b633a480e6e7d57c3d01a046205',
    'tests/unit/test_factor_memory_lifecycle.py': 'd98036b93bfd827bd39f3c0c347f58465175bc67e7bd511ac37a20c979ccc427',
    'examples/backtest/025_factor_single/run.py': '7a513386be0d452aa1738db322d606bb92ac43cd139e08b31552a81faf633104',
    'examples/backtest/026_factor_multi/run.py': 'd7d9532a35ccf4a29cd6e3136f00d4ccd2836f1f77455a956efe068c853ecf8f',
    'examples/backtest/027_alpha003_panel_acceptance/run.py': '22ca22f504674c823b9cf98a54e6269dd8b01bd196d4c3c6985ac90140f8fa93',
}
def check_pins():
    for path, digest in PINS.items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, path

def execute(args, log):
    with log.open('xb') as stream:
        done = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert done.returncode == 0, (done.returncode, str(log))

for pair in map(int, sys.argv[2:]):
    order = ('a', 'b') if pair % 2 else ('b', 'a')
    for example in ('025', '026', '027'):
        for arm in order:
            check_pins()
            out = TEMP / f'iteration49-7col-g2a-fcg1-p{pair}-{arm}-{example}'
            assert not out.exists()
            bt = Path('D:/temp/iteration49-g0-backtrader-3832c442') if arm == 'a' else ROOT
            print(f'START G2a pair={pair} arm={arm} example={example}', flush=True)
            execute(['scripts/benchmark_factor_examples.py', '--source-root', str(bt), '--fincore-root', str(FC),
                     '--data-root', str(ROOT / 'tests/datas/a_stocks'), '--example', example, '--profile', 'full',
                     '--output', str(out)], out.with_suffix('.log'))
            result = json.loads((out / 'result.json').read_text(encoding='utf-8'))
            assert result['status'] == 'COMPLETED' and result['runner_exit_code'] == 0
            assert not result['source_or_input_changes'] and not result['summary_check_errors']
            print(json.dumps({'pair': pair, 'arm': arm, 'example': example,
                              'wall_s': result['example_main_wall_ns']/1e9,
                              'cpu_s': result['example_main_process_cpu_ns']/1e9,
                              'peak_bytes': max(result['main_peak_working_set_bytes'], result['resource_peak_tree_rss_bytes'])}), flush=True)
            check_pins()
    verification = TEMP / f'iteration49-7col-g2a-fcg1-p{pair}-verification.json'
    args = ['scripts/verify_factor_examples_benchmark.py', '--output', str(verification)]
    for arm, flag in (('a', '--baseline'), ('b', '--candidate')):
        for example in ('025', '026', '027'):
            args.extend((flag, f'{example}={TEMP}/iteration49-7col-g2a-fcg1-p{pair}-{arm}-{example}'))
    execute(args, verification.with_suffix('.log'))
    verified = json.loads(verification.read_text(encoding='utf-8'))
    assert verified['status'] == 'PASS' and verified['scope_complete']
    print(f'G2a PAIR {pair} COMPLETE OUTPUT PASS', flush=True)
