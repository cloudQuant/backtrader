"""Aggregate completed G1b fixed-500 pairs; run only after all inputs exist."""
import hashlib
import json
import statistics
from pathlib import Path

TEMP = Path("D:/temp")
PAIRS, EXAMPLES = (1, 2, 3), ("025", "026", "027")
BT = "02ee098a972164f3d49d087713f3efc52729992a"
FC = "4c8e375be6b5889686882dd753b3180182e58f78"
SELECTION = "14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc"
SYMBOLS = "dda661efc19e42770028a61d4b43a4160a0bf08b3adf4dae353e8234d7ad5dbe"
DATA = Path("D:/source_code/backtrader/tests/datas/a_stocks")
OUTPUT = TEMP / "iteration49-7col-g1b-paired-summary.json"
CPU_MAX, MEMORY_MAX, WALL_DISPERSION_MAX = 1.03, 1.05, 0.05

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run_path(pair, arm, example):
    return TEMP / f"iteration49-7col-g1b-p{pair}-{arm}-{example}" / "result.json"

def verify_path(pair):
    return TEMP / f"iteration49-7col-g1b-p{pair}-verification.json"

def run(path, arm, example):
    v, label = load(path), path.parent.name
    need(v.get("status") == "COMPLETED" and v.get("runner_exit_code") == 0 and v.get("example_exit_code") == 0, f"{label}: run incomplete")
    need(v.get("example") == example and not v.get("source_or_input_changes") and not v.get("summary_check_errors"), f"{label}: result checks")
    s = v.get("summary") or {}
    need(s.get("status") == "COMPLETED" and s.get("symbols") == 500 and s.get("dates") == 243, f"{label}: expected 500x243")
    need(s.get("factor_mode") == "native" and s.get("factor_calculation") == "RAN", f"{label}: factor mode")
    args = v.get("example_cli_arguments") or []
    def arg(flag):
        ix = [i for i, item in enumerate(args) if item == flag]
        need(len(ix) == 1 and ix[0] + 1 < len(args), f"{label}: missing/duplicate {flag}")
        return args[ix[0] + 1]
    need(arg("--max-symbols") == "500" and arg("--factor-mode") == "native", f"{label}: CLI settings")
    need(Path(arg("--data-dir")).resolve() == DATA.resolve(), f"{label}: data directory")
    identity = v.get("data_identity_before")
    need(identity is not None and identity == v.get("data_identity_after"), f"{label}: input identity changed")
    need(identity.get("symbols") == 500 and identity.get("dates") == 243, f"{label}: input shape")
    need(identity.get("selection_sha256") == SELECTION and identity.get("ordered_symbols_sha256") == SYMBOLS, f"{label}: selection hash")
    bt0, bt1 = v.get("backtrader_source_before"), v.get("backtrader_source_after")
    fc0, fc1 = v.get("fincore_source_before"), v.get("fincore_source_after")
    need(bt0 is not None and bt0 == bt1 and bt0.get("commit") == BT, f"{label}: Backtrader source")
    need(fc0 is not None and fc0 == fc1 and fc0.get("commit") == FC, f"{label}: fincore source")
    if arm == "a":
        need(fc0.get("kind") == "verified_snapshot_manifest_v1", f"{label}: A fincore snapshot")
    else:
        need(fc0.get("kind") == "git_worktree" and fc0.get("branch") == "dev", f"{label}: B fincore dev source")
    wall, cpu = v.get("example_main_wall_ns"), v.get("example_main_process_cpu_ns")
    main_peak, tree_peak = v.get("main_peak_working_set_bytes"), v.get("resource_peak_tree_rss_bytes")
    need(all(isinstance(x, (int, float)) and x > 0 for x in (wall, cpu, main_peak, tree_peak)), f"{label}: invalid metrics")
    need(isinstance(v.get("phase_timers"), dict), f"{label}: phase timers missing")
    return {"path": str(path), "sha256": sha(path), "started_utc": v.get("started_utc"), "finished_utc": v.get("finished_utc"),
        "engine": v.get("expected_engine"), "wall_seconds": wall / 1e9, "cpu_seconds": cpu / 1e9,
        "peak_bytes": max(main_peak, tree_peak), "main_peak_bytes": main_peak, "tree_peak_bytes": tree_peak,
        "phases": v["phase_timers"], "backtrader": bt0, "fincore": fc0, "runner": v.get("runner_sha256"),
        "environment": v.get("environment"), "data_identity": identity, "summary": s}

def main():
    paths = [run_path(p, a, e) for p in PAIRS for a in ("a", "b") for e in EXAMPLES] + [verify_path(p) for p in PAIRS]
    missing = [str(p) for p in paths if not p.is_file()]
    need(not missing, "Wait for all G1b inputs:\n" + "\n".join(missing))
    need(not OUTPUT.exists(), f"Refusing to overwrite {OUTPUT}")
    pairs, identities, bt_sources, fc_sources, runners, verifications, fixed_inputs = [], [], [], {"a": [], "b": []}, [], [], []
    for p in PAIRS:
        vp, verifier = verify_path(p), load(verify_path(p))
        need(verifier.get("status") == "PASS" and verifier.get("valid") is True and verifier.get("scope_complete") is True, f"p{p}: verifier not PASS")
        fixed = verifier.get("fixed_input") or {}
        need(fixed.get("symbol_count") == 500 and fixed.get("date_count") == 243
            and fixed.get("selection_sha256") == SELECTION and fixed.get("ordered_symbols_sha256") == SYMBOLS,
            f"p{p}: verifier input identity")
        fixed_inputs.append(fixed)
        verifications.append({"path": str(vp), "sha256": sha(vp), "document": verifier})
        examples = {}
        for e in EXAMPLES:
            a, b = run(run_path(p, "a", e), "a", e), run(run_path(p, "b", e), "b", e)
            need(a["data_identity"] == b["data_identity"] and a["runner"] == b["runner"], f"p{p}-{e}: A/B identity/runner")
            need(a["engine"] == b["engine"], f"p{p}-{e}: A/B engine differs")
            identities.extend((a["data_identity"], b["data_identity"]))
            bt_sources.extend((a["backtrader"], b["backtrader"]))
            fc_sources["a"].append(a["fincore"]); fc_sources["b"].append(b["fincore"])
            runners.extend((a["runner"], b["runner"]))
            examples[e] = {"a": a, "b": b, "run_order": "AB" if (a["started_utc"] or "") < (b["started_utc"] or "") else "BA"}
        pairs.append({"pair": p, "examples": examples})
    same = lambda xs: len({json.dumps(x, sort_keys=True) for x in xs}) == 1
    need(same(bt_sources) and same(identities) and same(runners) and same(fixed_inputs), "Backtrader/input/runner identity varies")
    need(all(same(fc_sources[a]) for a in ("a", "b")) and fc_sources["a"][0] != fc_sources["b"][0], "Fincore A/B source identity mismatch")

    results = {}
    for e in EXAMPLES:
        rows = []
        for pair in pairs:
            a, b = pair["examples"][e]["a"], pair["examples"][e]["b"]
            rows.append({"pair": pair["pair"], **pair["examples"][e], "ratios_b_over_a": {
                "wall": b["wall_seconds"] / a["wall_seconds"], "cpu": b["cpu_seconds"] / a["cpu_seconds"],
                "peak": b["peak_bytes"] / a["peak_bytes"]}})
        ratios = {m: [x["ratios_b_over_a"][m] for x in rows] for m in ("wall", "cpu", "peak")}
        med = {m: statistics.median(values) for m, values in ratios.items()}
        dispersion = (max(ratios["wall"]) - min(ratios["wall"])) / med["wall"]
        extend = dispersion > WALL_DISPERSION_MAX
        passed = med["wall"] < 1.0 and med["cpu"] <= CPU_MAX and med["peak"] <= MEMORY_MAX
        status = "FAIL_THRESHOLDS" if not passed else "PENDING_EXTEND_PAIRS_4_5" if extend else "PASS_G1B_3PAIR_MEASUREMENT_ONLY"
        results[e] = {"pairs": rows, "median_ratios_b_over_a": med,
            "wall_ratio_range_over_median": dispersion,
            "median_absolute": {m: {a: statistics.median(x[a][m] for x in rows) for a in ("a", "b")}
                for m in ("wall_seconds", "cpu_seconds", "peak_bytes")},
            "thresholds": {"positive_wall_gain": med["wall"] < 1.0, "cpu_ratio_max": CPU_MAX,
                "memory_ratio_max": MEMORY_MAX, "wall_dispersion_max": WALL_DISPERSION_MAX},
            "extension": {"required": extend, "affected_example": e if extend else None,
                "additional_pairs": [4, 5] if extend else [], "acceptance_pending": extend}, "status": status}
    states = {v["status"] for v in results.values()}
    status = "FAIL_THRESHOLDS" if "FAIL_THRESHOLDS" in states else "PENDING_EXTEND_PAIRS_4_5" if "PENDING_EXTEND_PAIRS_4_5" in states else "PASS_G1B_3PAIR_MEASUREMENT_ONLY"
    summary = {"schema": "iteration49.g1b.fixed500.paired_summary.v1", "status": status,
        "scope": "G1b paired 500-symbol measurement only; not full-market or final Iteration 49 acceptance.",
        "sources": {"backtrader_snapshot": bt_sources[0], "fincore_a_snapshot": fc_sources["a"][0], "fincore_b_dev": fc_sources["b"][0], "runner": runners[0]},
        "fixed_data_identity": identities[0], "pair_order_by_example": {e: [p["examples"][e]["run_order"] for p in pairs] for e in EXAMPLES},
        "verifications": verifications, "examples": results,
        "archive_note": "Retain each result and full PASS verifier with SHA-256. If an example has wall-ratio dispersion above 5%, leave it pending and append its pairs 4/5."}
    with OUTPUT.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + "\n"); f.flush()

if __name__ == "__main__":
    main()
