"""Serial G1b full-output pairs with fixed accepted Backtrader and fail-fast comparison."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path('D:/source_code/backtrader')
FC = Path('D:/source_code/fincore')
TEMP = Path('D:/temp')
BT = Path(sys.argv[1])
assert BT.is_dir() and (BT / '.iteration49-source.json').is_file()
PINS = {
    'fincore/factor_analysis/models.py': '8f4aa2e676612beb10bf9c9e42aa6780c0f11101fd1169fa9ddb0a9f426676ea',
    'tests/factor_analysis/test_fingerprint_streaming.py': '36d8b7920dc187fe07900098a8f18096a8024003923ab159ad9ca6b8c508c449',
}

def check_pins():
    for path, digest in PINS.items():
        assert hashlib.sha256((FC / path).read_bytes()).hexdigest() == digest, path

def execute(args, log):
    assert not log.exists(), log
    with log.open('xb') as stream:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))

check_pins()
archive = TEMP / 'iteration49-g1b-source.zip'
if not archive.exists():
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
        for path in PINS:
            output.write(FC / path, path)
else:
    with zipfile.ZipFile(archive) as source:
        for path, digest in PINS.items():
            assert hashlib.sha256(source.read(path)).hexdigest() == digest

for pair in map(int, sys.argv[2:]):
    assert pair in (1, 2, 3, 4, 5)
    order = ('a', 'b') if pair % 2 else ('b', 'a')
    for example in ('025', '026', '027'):
        for arm in order:
            check_pins()
            destination = TEMP / f'iteration49-7col-g1b-p{pair}-{arm}-{example}'
            assert not destination.exists(), destination
            fc_root = 'D:/temp/iteration49-g1-fincore-4c8e375' if arm == 'a' else str(FC)
            print(f'START pair={pair} arm={arm} example={example}', flush=True)
            execute([
                'scripts/benchmark_factor_examples.py',
                '--source-root', str(BT),
                '--fincore-root', fc_root, '--data-root', str(ROOT / 'tests/datas/a_stocks'),
                '--example', example, '--profile', 'full', '--output', str(destination),
            ], destination.with_suffix('.log'))
            result = json.loads((destination / 'result.json').read_text(encoding='utf-8'))
            assert result['status'] == 'COMPLETED' and result['runner_exit_code'] == 0
            assert not result['source_or_input_changes'] and not result['summary_check_errors']
            print(json.dumps({'pair': pair, 'arm': arm, 'example': example,
                              'wall_s': result['example_main_wall_ns'] / 1e9,
                              'cpu_s': result['example_main_process_cpu_ns'] / 1e9,
                              'peak_bytes': max(result['main_peak_working_set_bytes'], result['resource_peak_tree_rss_bytes'])}), flush=True)
            check_pins()
    verification = TEMP / f'iteration49-7col-g1b-p{pair}-verification.json'
    args = ['scripts/verify_factor_examples_benchmark.py', '--output', str(verification)]
    for arm, flag in (('a', '--baseline'), ('b', '--candidate')):
        for example in ('025', '026', '027'):
            args.extend((flag, f'{example}={TEMP}/iteration49-7col-g1b-p{pair}-{arm}-{example}'))
    execute(args, verification.with_suffix('.log'))
    verified = json.loads(verification.read_text(encoding='utf-8'))
    assert verified['status'] == 'PASS' and verified['scope_complete'] is True
    print(f'PAIR {pair} COMPLETE OUTPUT PASS', flush=True)
