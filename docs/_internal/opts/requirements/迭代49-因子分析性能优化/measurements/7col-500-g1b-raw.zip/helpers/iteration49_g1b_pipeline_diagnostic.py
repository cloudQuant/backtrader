"""One full diagnostic run with streaming coverage and nested report/research timing."""
import gc
import hashlib
import importlib.util
import json
import sys
import time
import tracemalloc
from functools import wraps
from pathlib import Path

BT = Path('D:/temp/iteration49-g2a-backtrader-02ee098a9')
FC = Path('D:/source_code/fincore')
REPO = Path('D:/source_code/backtrader')
OUTPUT = Path(sys.argv[1])
assert not OUTPUT.exists()
SELF_SHA = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert hashlib.sha256((FC / 'fincore/factor_analysis/models.py').read_bytes()).hexdigest() == '8f4aa2e676612beb10bf9c9e42aa6780c0f11101fd1169fa9ddb0a9f426676ea'
sys.path[:0] = [str(BT), str(FC)]
from fincore.factor_analysis import models

original_stream = models._stream_fingerprint
original_fingerprint = models.fingerprint_value
observations = []
held = []

def observe_stream(value, writer):
    row = {'value_type': type(value).__name__, 'streamed': False}
    observations.append(row)
    if type(value) is dict and 'result_schema_version' in value and 'tables' in value:
        assert not held
        held.append(value)
        row['actual_research_result_payload'] = True
    try:
        length = original_stream(value, writer)
    except models._FingerprintNotStreamable:
        row['fallback'] = True
        import traceback
        row['fallback_trace'] = [{'name': frame.name, 'line': frame.lineno} for frame in traceback.extract_tb(sys.exc_info()[2]) if frame.filename.endswith('models.py')]
        raise
    row.update(streamed=True, encoded_length=length)
    return length

models._stream_fingerprint = observe_stream
runner_path = REPO / 'scripts/benchmark_factor_examples.py'
spec = importlib.util.spec_from_file_location('iteration49_g1_benchmark_diagnostic', runner_path)
runner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = runner
spec.loader.exec_module(runner)
# Separate diagnostic-only report attribution, never part of formal pairs.
fc_html = __import__('fincore.report.factor.html', fromlist=['html'])
fc_analysis = __import__('fincore.factor_analysis.analysis', fromlist=['analysis'])
fc_data = __import__('fincore.factor_analysis.data', fromlist=['data'])
fc_research = __import__('fincore.factor_analysis.research', fromlist=['research'])
fc_performance = __import__('fincore.factor_analysis.performance', fromlist=['performance'])
report_depth = 0
report_timers = {}
targets = [
    (fc_html, 'write_factor_report', 'report_total'),
    (fc_data, 'prepare_factor_data', 'report_prepare'),
    (fc_analysis, 'analyze_factor', 'report_analysis'),
    (fc_html, 'build_factor_report', 'report_build_document'),
    (fc_html, 'render_factor_html', 'report_render'),
    (fc_data, 'compute_forward_returns', 'report_forward_returns'),
    (fc_analysis, '_quantile_turnover_tables', 'report_turnover'),
    (fc_analysis, '_rank_autocorrelation_table', 'report_rank_autocorrelation'),
    (models, 'snapshot_pandas', 'all_pandas_snapshot'),
    (fc_research, 'evaluate_factor_research', 'research_total'),
    (fc_research, '_evaluate_period', 'research_evaluate_period'),
    (fc_research, '_stability_rows', 'research_stability_rows'),
    (fc_research, '_correlation_rows', 'research_correlation_rows'),
    (fc_research, '_combination_values', 'research_combination_values'),
    (fc_research, '_preprocess_matrix', 'research_preprocess_matrix'),
    (fc_data, 'prepare_factor_data_from_forward_returns', 'all_prepare_from_returns'),
    (fc_performance, 'factor_information_coefficient', 'all_ic'),
    (fc_performance, 'mean_return_by_quantile', 'all_quantile_returns'),
    (fc_performance, 'quantile_turnover', 'all_quantile_turnover'),
]
def report_wrapper(function, label):
    @wraps(function)
    def wrapped(*args, **kwargs):
        global report_depth
        is_root = label in ('report_total', 'research_total')
        if not is_root and not report_depth:
            return function(*args, **kwargs)
        if is_root:
            report_depth += 1
        wall = time.perf_counter_ns()
        cpu = time.process_time_ns()
        try:
            return function(*args, **kwargs)
        finally:
            row = report_timers.setdefault(label, {'calls': 0, 'wall_inclusive_ns': 0, 'cpu_inclusive_ns': 0})
            row['calls'] += 1
            row['wall_inclusive_ns'] += time.perf_counter_ns() - wall
            row['cpu_inclusive_ns'] += time.process_time_ns() - cpu
            if is_root:
                report_depth -= 1
    return wrapped
for module, name, label in targets:
    function = getattr(module, name)
    wrapper = report_wrapper(function, label)
    for loaded in list(sys.modules.values()):
        if getattr(loaded, '__name__', '').startswith('fincore.'):
            for alias, value in list(vars(loaded).items()):
                if value is function:
                    setattr(loaded, alias, wrapper)
exit_code = runner.main([
    '--source-root', str(BT), '--fincore-root', str(FC),
    '--data-root', str(REPO / 'tests/datas/a_stocks'), '--example', '026',
    '--profile', 'full', '--diagnostic', '--output', str(OUTPUT),
])
models._stream_fingerprint = original_stream
assert exit_code == 0 and len(held) == 1
payload = held[0]

result = {
    'status': 'PIPELINE_AND_STREAM_COVERAGE_DIAGNOSTIC_ONLY', 'observations': observations,
    'report_timers': report_timers,
    'source_sha256_before': SELF_SHA,
    'source_sha256_after': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'models_sha256': hashlib.sha256(Path(models.__file__).read_bytes()).hexdigest(),
}
assert result['source_sha256_before'] == result['source_sha256_after']
(OUTPUT / 'pipeline-diagnostic.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result), flush=True)
