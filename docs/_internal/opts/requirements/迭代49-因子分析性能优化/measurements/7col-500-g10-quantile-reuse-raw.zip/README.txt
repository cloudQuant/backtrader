G10 fixed-500 raw run results, logs and complete output verifiers.
