# FinCore G11 static review — final candidate

**Decision: GO.** This is a read-only review of the final candidate pins below. Root reports its final focused QA passed 12/12 with exit 0; I did not rerun tests or performance work.

- `D:\source_code\fincore\fincore\factor_analysis\portfolio.py` — SHA-256 `700dd78dbb0cad7f8e510c0aa57632f574e80398cad4df7f65d5183aa752db66` (17,899 bytes)
- `D:\source_code\fincore\tests\factor_analysis\test_positions_active_window.py` — SHA-256 `257419217fbba0a9c7c700fde70f44e87126a41051c2c6c13cf591ef862a6425` (11,841 bytes)
- `D:\source_code\fincore\docs\plans\iteration49-g11-positions-active-window.md` — SHA-256 `c1779b5659a39924ce2efe4dbe6e372cc0554a36384ff724adc86001486d01a5` (1,710 bytes)

The fast path is gated to exact pandas 2.2.3 and exact base input/frame types, a unique datetime index, unique exact-string assets, and a single float64 NumPy block exposed through a verified zero-copy view. Other versions, subclasses, unsupported layouts, and over-budget active windows stay on the existing path. It reads source rows into a bounded scratch matrix and writes a fresh float64 result buffer, so it does not mutate or share the caller’s weights. Gross and normalization retain the existing pandas Series operations. The 8 MiB scratch guard accounts for the active matrix, NaN mask/reduction copy, and per-asset temporary vectors.

The duplicate-expiry guard is necessary. Positional writes cannot reproduce the legacy `.loc[timestamp, total.index]` behavior when `position_index` contains duplicate labels. The Friday/Saturday `BDay()` fixture makes both expiries collide on Monday; its independent pre-G11 oracle and explicit assertions preserve the legacy zero values for both Monday rows (the duplicate-label Series alignment is then converted by the final `fillna(0.0)`). The production fast path requires `position_index.is_unique`, so this case uses that oracle path. The one-expiry-pop lifecycle remains unchanged.

Static source review found no blocker in dtype/order, NaN handling, fallback, input ownership, or the duplicate-index case. Performance and process-tree memory claims remain unmeasured by this review.
