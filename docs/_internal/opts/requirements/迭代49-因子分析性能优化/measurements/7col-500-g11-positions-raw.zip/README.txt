Actual fixed500 complete example runs and full output verifiers; no replayed runs.
