# G3 full Alpha101 partitioned matrix supplement

This additive archive preserves the six completed, disjoint functional-test batches, their 18 partial JSON outputs and six pytest logs, the original launcher receipt, and the later read-only reconciliation. It does not replace or rewrite either launcher output.

Each of the six batches recorded 3 passed tests and one known pytest configuration warning. Across T320, T640 and T1280, reconciliation verified the disjoint union Alpha001–Alpha101, with 404 oracle, finite-witness and lifecycle checks per period, 202 same-engine build pairs and 202 cross-engine graph pairs per period. Every individual partial remains `INCOMPLETE`; the original launcher remains `BLOCKED_OUTPUT_VALIDATION` because its post-run schema-1 string-mode predicate did not accept schema-2 nested mode witnesses. The additive validator first checked those nested root/instance witnesses, then projected only validated root modes in memory into the frozen original partial checker. It did not rerun tests or mutate source, launcher, or partial outputs.

The G1c scheduling receipts record pauses of these functional jobs during separate serial performance slots. Therefore the pytest elapsed times in the logs include those pauses and are not performance measurements.

The G3 500-stock performance evidence remains separate: A is the G2a fixed public source snapshot and B is the frozen G3 candidate from Backtrader dev at c3d5178; fincore is pinned to G1b in both arms. See the paired summary and measured-source ZIP under `references/`. The earlier 500-run raw ZIP is referenced by SHA-256 `0d1b954ca60c48964315df9b6cabedb08d16cb2489c0ee7f301f0578dc0c275e`; its functional record is member `evidence/.codex-tmp/iteration49-g3-window-functional.json`.
