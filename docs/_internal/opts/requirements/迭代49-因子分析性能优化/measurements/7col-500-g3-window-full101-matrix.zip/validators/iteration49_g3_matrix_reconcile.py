"""Read-only reconciliation of completed matrix outputs with schema-2 mode witnesses."""
import copy
import hashlib
import json
import runpy
from pathlib import Path

ROOT = Path('D:/source_code/backtrader')
EVIDENCE = Path('D:/temp/iteration49-g3-window-alpha101-full-checked')
LAUNCHER = ROOT / '.codex-tmp/iteration49_alpha101_g3_partitioned.py'
OUTPUT = EVIDENCE / 'reconciliation.json'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert not OUTPUT.exists()
    module = runpy.run_path(str(LAUNCHER))
    launch = json.loads((EVIDENCE / 'launcher.json').read_text(encoding='utf-8'))
    assert launch['status'] == 'BLOCKED_OUTPUT_VALIDATION'
    assert len(launch['processes']) == 6 and all(p['exit_code'] == 0 for p in launch['processes'])
    assert launch['source_pins_before'] == launch['source_pins_after'] == module['source_pins']()
    inputs, unions = [], []
    for period in module['PERIODS']:
        seen = []
        for batch in module['BATCHES']:
            path = EVIDENCE / batch / f'alpha101-build-pair-T{period}.json'
            record = json.loads(path.read_text(encoding='utf-8'))
            projected = copy.deepcopy(record)
            for run, target in zip(record['engine_runs'], projected['engine_runs']):
                expected = run['factor_mode']
                for alpha, witness in run['factor_instance_modes'].items():
                    assert witness['root_mode'] == expected
                    instances = witness['bound_instances']
                    assert len(instances) == witness['bound_instance_count'] > 0
                    assert witness['build_context_count'] == sum(i['has_expression_context'] for i in instances)
                    assert witness['build_node_count'] == sum(i['expression_node_count'] for i in instances)
                    for instance in instances:
                        assert instance['factor_mode'] == expected
                        assert instance['has_expression_context'] is (expected == 'build')
                        if expected == 'native':
                            assert instance['expression_node_count'] == 0
                        else:
                            assert instance['expression_node_count'] > 0
                        for child in instance['descendants']:
                            mode = child['factor_mode']
                            assert mode in ('native', 'build') and child['runtime_mode'] == mode
                            assert child['has_expression_context'] is (mode == 'build')
                            assert child['expression_node_count'] >= 0
                    target['factor_instance_modes'][alpha] = expected
            # All other original checks remain unchanged; only the schema-2
            # witness is projected after validating its actual nested fields.
            seen.extend(module['check_partial'](projected, batch, period))
            inputs.append({'path': str(path), 'sha256': digest(path)})
        assert sorted(seen) == list(range(1, 102)) and len(seen) == len(set(seen))
        unions.append({'periods': period, 'alpha_ids': sorted(seen), 'alpha_count': 101,
                       'oracle_pass_count': 404, 'finite_witness_count': 404,
                       'lifecycle_pass_count': 404, 'same_engine_build_pair_count': 202,
                       'cross_engine_graph_pair_count': 202})
    assert launch['source_pins_after'] == module['source_pins']()
    result = {'schema_version': 1, 'status': 'PASS_FULL_REGISTRY_PARTITIONED',
              'acceptance_profile': 'iteration49-single-class-modes', 'unions': unions,
              'partial_results_remain_incomplete': True, 'inputs': inputs,
              'launcher_result_sha256': digest(EVIDENCE / 'launcher.json'),
              'launcher_source_sha256': digest(LAUNCHER), 'validator_sha256': digest(Path(__file__)),
              'source_pins_before': launch['source_pins_before'],
              'source_pins_after': launch['source_pins_after'],
              'note': 'Six disjoint executions; no test repeated. Original launcher result preserved. '
                      'Its string-mode assertion was incompatible with schema-2 nested witnesses. '
                      'Functional elapsed times include explicitly recorded performance pauses.'}
    OUTPUT.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'path': str(OUTPUT), 'sha256': digest(OUTPUT)}))

if __name__ == '__main__':
    main()
