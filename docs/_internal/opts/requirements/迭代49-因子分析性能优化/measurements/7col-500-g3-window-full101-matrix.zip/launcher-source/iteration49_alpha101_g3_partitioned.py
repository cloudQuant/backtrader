"""Run the existing Alpha101 build-pair matrix in six disjoint pytest jobs (functional only)."""
from __future__ import annotations

import argparse, hashlib, json, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
PERIODS = (320, 640, 1280)
BATCHES = {
    "promoted_20": (1, 2, 3, 4, 7, 9, 13, 29, 48, 56, 58, 62, 63, 67, 81, 84, 92, 96, 100, 101),
    "a": tuple(x for x in range(5, 21) if x not in (7, 9, 13)),
    "b": tuple(x for x in range(21, 41) if x != 29),
    "c": tuple(x for x in range(41, 62) if x not in (48, 56, 58)),
    "d": tuple(x for x in range(64, 81) if x != 67),
    "e": tuple(x for x in range(82, 100) if x not in (84, 92, 96)),
}
SOURCES = (
    "backtrader/research/operators.py", "backtrader/research/factor_indicator.py",
    "backtrader/research/_expression.py",
    "tests/integration/test_alpha101_native_matrix.py",
    "tests/test_utils/alpha101_native_harness.py",
    "tests/test_utils/alpha101_full_reference.py",
    "tests/test_utils/alpha101_trace_validation.py",
    "tests/unit/test_factor_research_representatives.py",
)
NODE = "tests/integration/test_alpha101_native_matrix.py::test_alpha101_native_build_pair_graph_matrix"
LANES = {(m, e) for m in ("native", "build") for e in ("runnext", "runonce")}

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_pins() -> dict[str, str]:
    paths = [ROOT / name for name in SOURCES]
    paths += sorted((ROOT / "backtrader/research/alpha101").glob("*.py"))
    paths.append(Path(__file__).resolve())
    return {path.relative_to(ROOT).as_posix(): digest(path) for path in paths}


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def check_partial(record: dict, batch: str, period: int) -> list[int]:
    ids, expected = record["alpha_ids"], list(BATCHES[batch])
    n = len(ids)
    need(ids == expected and len(set(ids)) == n, f"{batch}: selected IDs differ from pinned batch")
    need((record["schema_version"], record["acceptance_profile"], record["periods"]) ==
         (2, "iteration49-single-class-modes", period), f"{batch}: schema/profile/period mismatch")
    need((record["status"], record["complete_registry_coverage"], record["aggregate"]["all_pass"]) ==
         ("INCOMPLETE", False, False), f"{batch}: partial result must remain INCOMPLETE")
    runs = record["engine_runs"]
    need(len(runs) == 4 and {(r["factor_mode"], r["engine"]) for r in runs} == LANES,
         f"{batch}: expected four mode/engine lanes")
    for run in runs:
        need(run["alpha_ids"] == ids and all(run[k] == n for k in
             ("oracle_pass_count", "finite_witness_count", "lifecycle_pass_count")),
             f"{batch}: lane coverage/count mismatch")
        need(run["runonce"] == (run["engine"] == "runonce") and run["broker"] == {"submit": 0, "cancel": 0}
             and set(run["factor_instance_modes"]) == {str(x) for x in ids}
             and all(v == run["factor_mode"] for v in run["factor_instance_modes"].values()),
             f"{batch}: engine, mode, or broker contract mismatch")
    agg = record["aggregate"]
    need((agg["alpha_count"], agg["engine_run_count"]) == (n, 4) and all(agg[k] == 4*n for k in
         ("oracle_pass_count", "finite_witness_count", "lifecycle_pass_count")),
         f"{batch}: aggregate validation count mismatch")
    need(agg["same_engine_build_pair_count"] == agg["cross_engine_graph_pair_count"] == 2*n,
         f"{batch}: expected two build and two cross-engine comparisons per Alpha")
    need(set(record["per_alpha"]) == {str(x) for x in ids}, f"{batch}: per-Alpha coverage mismatch")
    for alpha_id in ids:
        item = record["per_alpha"][str(alpha_id)]
        need(all(item[k] is True for k in ("oracle_pass", "finite_witness", "lifecycle_pass")),
             f"{batch}: Alpha{alpha_id} oracle/witness/lifecycle failed")
        same, cross = item["same_engine_build_pair"], item["cross_engine"]
        need(set(same) == {"runnext", "runonce"} and set(cross) == {"native", "build"}
             and all(p.get("equal") is True for p in (*same.values(), *cross.values())),
             f"{batch}: Alpha{alpha_id} graph/panel comparisons incomplete")
    return ids

def run_one(batch: str, evidence: Path) -> dict:
    env = os.environ.copy()
    env.pop("BT_ALPHA101_NATIVE_IDS", None)
    env.update(BT_ALPHA101_NATIVE_BATCHES=batch, BT_ALPHA101_BUILD_PAIR="1",
               BT_ALPHA101_BUILD_PAIR_EVIDENCE=str(evidence / batch), PYTEST_ADDOPTS="")
    command = [sys.executable, "-m", "pytest", "-p", "no:asyncio", "-q", NODE]
    try:
        with (evidence / batch / "pytest.log").open("w", encoding="utf-8") as log:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        return {"batch": batch, "command": command, "exit_code": result.returncode}
    except Exception as exc:
        return {"batch": batch, "command": command, "error": type(exc).__name__}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence-root", required=True, type=Path)
    evidence = parser.parse_args().evidence_root.resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    before = source_pins()
    for batch in BATCHES: (evidence / batch).mkdir()
    with ThreadPoolExecutor(max_workers=6) as pool:
        processes = [f.result() for f in as_completed(
            [pool.submit(run_one, batch, evidence) for batch in BATCHES])]
    after = source_pins()
    receipt = {"schema_version": 1, "periods": PERIODS, "batch_order": list(BATCHES),
        "processes": sorted(processes, key=lambda p: list(BATCHES).index(p["batch"])),
        "max_workers": 6, "logical_cpu_count": os.cpu_count(), "pytest_node": NODE,
        "source_pins_before": before, "source_pins_after": after}
    if before != after or any(p.get("exit_code") != 0 for p in processes):
        receipt["status"] = "BLOCKED_PROCESS_OR_SOURCE_CHANGE"; write_json(evidence / "launcher.json", receipt)
        return 2
    unions = []
    try:
        for period in PERIODS:
            seen, inputs = [], []
            for batch in BATCHES:
                path = evidence / batch / f"alpha101-build-pair-T{period}.json"
                raw = path.read_bytes(); record = json.loads(raw)
                seen.extend(check_partial(record, batch, period))
                inputs.append({"batch": batch, "path": str(path), "sha256": hashlib.sha256(raw).hexdigest()})
            need(sorted(seen) == list(range(1, 102)) and len(seen) == len(set(seen)),
                 f"T{period}: union is not exactly Alpha1..Alpha101")
            unions.append({"schema_version": 1, "status": "PASS_FULL_REGISTRY_PARTITIONED",
                "acceptance_profile": "iteration49-single-class-modes", "periods": period,
                "alpha_ids": sorted(seen), "alpha_count": 101, "partial_results_remain_incomplete": True,
                "oracle_pass_count": 404, "finite_witness_count": 404, "lifecycle_pass_count": 404,
                "same_engine_build_pair_count": 202, "cross_engine_graph_pair_count": 202,
                "batch_inputs": inputs, "source_pins_before": before, "source_pins_after": after,
                "note": "Six disjoint executions of the existing test body; not one all-registry pytest item."})
    except Exception as exc:
        receipt.update(status="BLOCKED_OUTPUT_VALIDATION", error=type(exc).__name__); write_json(evidence / "launcher.json", receipt)
        return 2
    receipt.update(status="PASS_FULL_REGISTRY_PARTITIONED", union_files=[f"union-T{x['periods']}.json" for x in unions])
    write_json(evidence / "launcher.json", receipt)
    for item in unions: write_json(evidence / f"union-T{item['periods']}.json", item)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
