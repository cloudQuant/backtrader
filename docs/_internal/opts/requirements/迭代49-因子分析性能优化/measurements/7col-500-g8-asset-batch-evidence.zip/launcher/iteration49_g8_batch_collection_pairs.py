"""Serial fixed-500 full-output pairs for the 025/026 asset-batch candidate."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path("D:/source_code/backtrader")
TEMP = Path("D:/temp")
BASE = TEMP / "iteration49-g7-backtrader-fa7a34843"
FC = TEMP / "iteration49-g6-fincore-4e01ac9"
BT_BASE_COMMIT = "fa7a34843add94c06bb514630787d65956939124"
FC_COMMIT = "4e01ac9f6f081f13acd60b45559119e1a5ed4a4f"
BT_MANIFEST = "6077de3a720ad809b02171c720d35f17aa75a559703a2ce7219b9c8cd3c58e30"
FC_MANIFEST = "dd302498270cf278766dca2dbb3c9494abe54c908f84b8c7f97b1493efa7af3c"
EXAMPLES = {
    "025": "025_factor_single",
    "026": "026_factor_multi",
    "027": "027_alpha003_panel_acceptance",
}
EXAMPLE_DIRS = tuple("examples/backtest/" + name for name in EXAMPLES.values())
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
DAILY = "examples/backtest/027_alpha003_panel_acceptance/run_daily.py"
HELPER = "examples/backtest/025_factor_single/_iteration49_factor_asset_batch.py"
TEST = "tests/unit/test_factor_research_examples.py"
SELECTION = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json"
DATA = ROOT / "tests/datas/a_stocks"
SELECTION_SHA256 = "14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc"
DAILY_SHA256 = "206f13a98d7e153bd0cd6f5d42d38470fb7566788104b957af87614be5999220"
# This dirty daily entry is preserved and never executed by this launcher.
PRESERVED_UNRELATED = {DAILY: DAILY_SHA256}
TRACKED_CANDIDATE_PINS = {
    "examples/backtest/025_factor_single/README.md": "726c9cdbdb179b2bfc72ea1bab263334cf15e8cc9a729a8490766f52a86f06cd",
    "examples/backtest/025_factor_single/run.py": "07f32cdf6a51718227d19e779873818d58117c370d159b3dec2966321539d879",
    "examples/backtest/026_factor_multi/README.md": "023718304927f3f8e1ad4835ff3d5556d67086d31da736015832c2925fd28a9b",
    "examples/backtest/026_factor_multi/run.py": "b0cc3a63c0193754dd66860419a861e1323b13df29a12b1a13cdb14850b55d7b",
}
NEW_SOURCE_PINS = {
    HELPER: "867e5dbd00bfe910dcac865ceb21907edbead75e66c3a9e1cc18dbc68088268f",
}
TEST_PINS = {
    TEST: "015922abfb3648d1aa8f123a0dc53b0f521be8ab613f851823e67e064b987786",
}
TOOL_PINS = {
    RUNNER: "63233d4cdfae9fc3f79813f88b96840a9019ea6fcb09d0cb80b667e62c1a8dd2",
    VERIFIER: "5818795349d7856a3dcac897ffbd0687a6c60cde7552e8aa67570a534768c921",
}
SOURCE_CANDIDATE_PINS = {**TRACKED_CANDIDATE_PINS, **NEW_SOURCE_PINS}
PINS = {**SOURCE_CANDIDATE_PINS, **TEST_PINS, **TOOL_PINS}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def snapshot(root, expected_manifest, expected_commit):
    manifest_path = root / ".iteration49-source.json"
    assert digest(manifest_path) == expected_manifest
    manifest = read(manifest_path)
    assert manifest.get("schema_version") == 1 and manifest.get("commit") == expected_commit
    files = manifest.get("files")
    assert isinstance(files, dict) and files
    for name, item in files.items():
        path = root / name
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item["sha256"] and len(raw) == item["size_bytes"], name
    return manifest


def current_source_names():
    scopes = ["backtrader", *EXAMPLE_DIRS, RUNNER]
    raw = subprocess.check_output(
        ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--", *scopes],
        cwd=ROOT,
    )
    names = {item.decode("utf-8") for item in raw.split(b"\0") if item}
    suffixes = {".py", ".md", ".yaml", ".yml", ".json", ".pem"}
    return {
        name
        for name in names
        if name.startswith("backtrader/")
        or name == RUNNER
        or any(
            (name == folder or name.startswith(folder + "/"))
            and Path(name).suffix.lower() in suffixes
            for folder in EXAMPLE_DIRS
        )
    }


def check_sources(expected_head):
    bt_manifest = snapshot(BASE, BT_MANIFEST, BT_BASE_COMMIT)
    snapshot(FC, FC_MANIFEST, FC_COMMIT)
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=ROOT, text=True).strip()
    assert head == expected_head and branch == "dev"
    assert digest(SELECTION) == SELECTION_SHA256 and digest(ROOT / DAILY) == DAILY_SHA256
    for name, pin in PINS.items():
        assert digest(ROOT / name) == pin, name
    base_names = set(bt_manifest["files"])
    assert current_source_names() == base_names | {RUNNER, HELPER}
    changed = set()
    for name in base_names:
        before = (BASE / name).read_bytes().replace(b"\r\n", b"\n")
        after = (ROOT / name).read_bytes().replace(b"\r\n", b"\n")
        if before != after:
            changed.add(name)
    assert changed == set(TRACKED_CANDIDATE_PINS) | {DAILY}, sorted(changed)
    scopes = ["backtrader", *EXAMPLE_DIRS, RUNNER]
    status = subprocess.check_output(
        ["git", "status", "--porcelain=v1", "--untracked-files=no", "--", *scopes],
        cwd=ROOT,
        text=True,
        encoding="utf-8",
    ).splitlines()
    expected_tracked = set(TRACKED_CANDIDATE_PINS) | set(PRESERVED_UNRELATED)
    assert {line[3:] for line in status} == expected_tracked, status
    assert all(line[:2] == " M" for line in status), status
    helper_status = subprocess.check_output(
        ["git", "status", "--porcelain=v1", "--untracked-files=all", "--", HELPER],
        cwd=ROOT,
        text=True,
        encoding="utf-8",
    ).splitlines()
    assert helper_status == ["?? " + HELPER], helper_status
    test_status = subprocess.check_output(
        ["git", "status", "--porcelain=v1", "--untracked-files=all", "--", TEST],
        cwd=ROOT,
        text=True,
        encoding="utf-8",
    ).splitlines()
    assert test_status == [" M " + TEST], test_status
    staged = subprocess.check_output(
        ["git", "diff", "--cached", "--name-only", "--", *scopes, *TEST_PINS],
        cwd=ROOT,
        text=True,
    ).splitlines()
    assert not staged, staged
    return bt_manifest


def output(pair, arm, example):
    return TEMP / f"iteration49-g8-batch-500-p{pair}-{arm}-{example}"


def execute(args, log):
    with log.open("xb") as stream:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))


def validate(path, arm, example, bt_manifest, expected_head):
    result = read(path / "result.json")
    assert result["status"] == "COMPLETED"
    assert result["runner_exit_code"] == result["example_exit_code"] == 0
    assert result["input_universe"] == "fixed500"
    assert result["example"] == example and result["profile"] == "full"
    assert not result["source_or_input_changes"] and not result["summary_check_errors"]
    for key in ("backtrader_source", "fincore_source", "data_identity"):
        assert result[key + "_before"] == result[key + "_after"], key
    bt = result["backtrader_source_before"]
    if arm == "a":
        assert bt["kind"] == "verified_snapshot_manifest_v1"
        assert bt["commit"] == BT_BASE_COMMIT and bt["manifest_sha256"] == BT_MANIFEST
        assert HELPER not in result["backtrader_files_before"]
    else:
        assert bt["kind"] == "git_worktree" and bt["commit"] == expected_head and bt["branch"] == "dev"
        statuses = {line[3:]: line[:2] for line in bt["source_status"]}
        expected_statuses = {
            **{name: " M" for name in TRACKED_CANDIDATE_PINS},
            HELPER: "??",
            DAILY: " M",
        }
        assert statuses == expected_statuses, statuses
    assert result["fincore_source_before"]["kind"] == "verified_snapshot_manifest_v1"
    assert result["fincore_source_before"]["commit"] == FC_COMMIT
    assert result["fincore_source_before"]["manifest_sha256"] == FC_MANIFEST
    for name in (*TRACKED_CANDIDATE_PINS, DAILY):
        expected = bt_manifest["files"][name]["sha256"] if arm == "a" else PINS.get(name, DAILY_SHA256)
        assert result["backtrader_files_before"][name]["sha256"] == expected, name
    if arm == "b":
        assert result["backtrader_files_before"][HELPER]["sha256"] == NEW_SOURCE_PINS[HELPER]
    summary = result["summary"]
    assert (summary["symbols"], summary["dates"], summary["factor_mode"], summary["factor_calculation"]) == (
        500,
        243,
        "native",
        "RAN",
    )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("pairs", nargs="+", type=int)
    args = parser.parse_args()
    expected_head = args.expected_head
    assert len(expected_head) == 40 and all(char in "0123456789abcdef" for char in expected_head)
    pairs = tuple(args.pairs)
    assert pairs and len(pairs) == len(set(pairs)) and all(pair in (1, 2, 3) for pair in pairs)
    bt_manifest = check_sources(expected_head)
    print(f"UNRELATED_PRESERVED_NOT_EXECUTED_QUICK: {DAILY} sha256={DAILY_SHA256}", flush=True)
    print("G8 plan: 18 actual runs, 9 unique comparisons, 3 complete verifiers", flush=True)
    for pair in pairs:
        if pair > 1:
            first = TEMP / "iteration49-g8-batch-500-p1-verification.json"
            assert first.is_file(), "run and pass pair 1 before pairs 2/3"
            prior = read(first)
            assert prior["status"] == "PASS" and prior["scope_complete"]
        for example in ("025", "026", "027"):
            for arm in (("a", "b") if pair % 2 else ("b", "a")):
                check_sources(expected_head)
                destination = output(pair, arm, example)
                assert not destination.exists()
                print(f"START G8-batch pair={pair} arm={arm} example={example}", flush=True)
                execute(
                    [
                        RUNNER,
                        "--source-root",
                        str(BASE if arm == "a" else ROOT),
                        "--fincore-root",
                        str(FC),
                        "--data-root",
                        str(DATA),
                        "--selection",
                        str(SELECTION),
                        "--universe",
                        "fixed500",
                        "--example",
                        example,
                        "--profile",
                        "full",
                        "--output",
                        str(destination),
                    ],
                    destination.with_suffix(".log"),
                )
                result = validate(destination, arm, example, bt_manifest, expected_head)
                peak = max(result["main_peak_working_set_bytes"], result["resource_peak_tree_rss_bytes"])
                print(
                    json.dumps(
                        {
                            "pair": pair,
                            "arm": arm,
                            "example": example,
                            "wall_s": result["example_main_wall_ns"] / 1e9,
                            "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                            "peak_bytes": peak,
                        }
                    ),
                    flush=True,
                )
                check_sources(expected_head)
        verification = TEMP / f"iteration49-g8-batch-500-p{pair}-verification.json"
        assert not verification.exists()
        verify_args = [
            VERIFIER,
            "--data-root",
            str(DATA),
            "--selection",
            str(SELECTION),
            "--universe",
            "fixed500",
            "--output",
            str(verification),
        ]
        for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
            for example in ("025", "026", "027"):
                result_path = output(pair, arm, example)
                validate(result_path, arm, example, bt_manifest, expected_head)
                verify_args.extend((flag, f"{example}={result_path}"))
        check_sources(expected_head)
        execute(verify_args, verification.with_suffix(".log"))
        verified = read(verification)
        assert verified["input_universe"] == "fixed500"
        assert verified["status"] == "PASS" and verified["scope_complete"]
        print(f"G8 batch pair {pair} COMPLETE OUTPUT PASS", flush=True)


if __name__ == "__main__":
    main()
