#!/usr/bin/env python3
"""Prepare G8 fixed-500 evidence and a scoped commit config after pair 3.

This is a read/validate/archive/document preparation helper. It does not run
examples, tests, or the canonical benchmark/verifier, and it never stages or
commits. Root may run it only after all three G8 pairs and verifiers finish.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import statistics
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(r"D:\source_code\backtrader")
TEMP = Path(r"D:\temp")
DOCS = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化"
MEASUREMENTS = DOCS / "measurements"
EXPECTED_HEAD = "4ac862a2146f4dbd6f3390f8bd119de00f8a4e6b"
PAIR_CANDIDATE_HEADS = {1: EXPECTED_HEAD, 2: EXPECTED_HEAD, 3: EXPECTED_HEAD}

BASE = TEMP / "iteration49-g7-backtrader-fa7a34843"
FC = TEMP / "iteration49-g6-fincore-4e01ac9"
BT_BASE_COMMIT = "fa7a34843add94c06bb514630787d65956939124"
FC_COMMIT = "4e01ac9f6f081f13acd60b45559119e1a5ed4a4f"
BT_MANIFEST_SHA256 = "6077de3a720ad809b02171c720d35f17aa75a559703a2ce7219b9c8cd3c58e30"
FC_MANIFEST_SHA256 = "dd302498270cf278766dca2dbb3c9494abe54c908f84b8c7f97b1493efa7af3c"

EXAMPLES = ("025", "026", "027")
ARMS = ("a", "b")  # a = G7 accepted snapshot; b = G8 asset-batch candidate.
PAIRS = (1, 2, 3)
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
LAUNCHER = ROOT / ".codex-tmp/iteration49_g8_batch_collection_pairs.py"
LAUNCHER_SHA256 = "d70bc34e91b7c62f7fe4293ca3f393a38f1ca6ca7082ca3acbbb2df1ecbf8fa4"
RUNNER_SHA256 = "63233d4cdfae9fc3f79813f88b96840a9019ea6fcb09d0cb80b667e62c1a8dd2"
VERIFIER_SHA256 = "5818795349d7856a3dcac897ffbd0687a6c60cde7552e8aa67570a534768c921"

HELPER = "examples/backtest/025_factor_single/_iteration49_factor_asset_batch.py"
TEST = "tests/unit/test_factor_research_examples.py"
DAILY = "examples/backtest/027_alpha003_panel_acceptance/run_daily.py"
DAILY_SHA256 = "206f13a98d7e153bd0cd6f5d42d38470fb7566788104b957af87614be5999220"
TRACKED_SOURCE_PINS = {
    "examples/backtest/025_factor_single/README.md": "726c9cdbdb179b2bfc72ea1bab263334cf15e8cc9a729a8490766f52a86f06cd",
    "examples/backtest/025_factor_single/run.py": "07f32cdf6a51718227d19e779873818d58117c370d159b3dec2966321539d879",
    "examples/backtest/026_factor_multi/README.md": "023718304927f3f8e1ad4835ff3d5556d67086d31da736015832c2925fd28a9b",
    "examples/backtest/026_factor_multi/run.py": "b0cc3a63c0193754dd66860419a861e1323b13df29a12b1a13cdb14850b55d7b",
}
SOURCE_PINS = {
    **TRACKED_SOURCE_PINS,
    HELPER: "867e5dbd00bfe910dcac865ceb21907edbead75e66c3a9e1cc18dbc68088268f",
    TEST: "015922abfb3648d1aa8f123a0dc53b0f521be8ab613f851823e67e064b987786",
}
TOOL_PINS = {
    RUNNER: "63233d4cdfae9fc3f79813f88b96840a9019ea6fcb09d0cb80b667e62c1a8dd2",
    VERIFIER: "5818795349d7856a3dcac897ffbd0687a6c60cde7552e8aa67570a534768c921",
}
QA_JSON = ROOT / ".codex-tmp/iteration49_g8_batch_functional_qa.json"
QA_JSON_SHA256 = "f561e453f0156bfb7521ad6b0f0c193682320f30bd8c3e5eda7681f234dee989"
REVIEW = ROOT / ".codex-tmp/iteration49-asset-batch-review.md"
REVIEW_SHA256 = "e7f92c8f583d736a203b8ffd0b9748c40a4138b057fb2270314bfe8059811a26"
QA_LOGS = (
    TEMP / "iteration49-asset-batch-focused-20261024.log",
    TEMP / "iteration49-asset-batch-release-focused-20261024.log",
)
QA_LOG_SHA256 = (
    "320256a0ac5a83e3575c7b85a5dd3107b0c5e16d356a5bda0199a0d757ff79ff",
    "3ab4110400b30eb8152c985f97918edaa81c79eb50c944c33a7f9128325a3063",
)
SELECTION = DOCS / "benchmark-500-7col.json"
SELECTION_SHA256 = "14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc"
DATA_ROOT = ROOT / "tests/datas/a_stocks"

DOC_RECORD = DOCS / "开发与验收记录.md"
DOC_ROUTE = DOCS / "五倍加速目标与实施路线.md"
ANALYSIS_PATH = MEASUREMENTS / "7col-500-g8-asset-batch-analysis.json"
EVIDENCE_PATH = MEASUREMENTS / "7col-500-g8-asset-batch-evidence.zip"
COMMIT_CONFIG = ROOT / ".codex-tmp/iteration49-g8-asset-batch-commit-config.json"
COMMIT_RECEIPT = ROOT / ".codex-tmp/iteration49-g8-asset-batch-dev-delivery.json"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def file_sha(path: Path) -> str:
    return sha(path.read_bytes())


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=ROOT)


def snapshot(root: Path, expected_manifest_sha: str, expected_commit: str) -> dict:
    manifest_path = root / ".iteration49-source.json"
    assert file_sha(manifest_path) == expected_manifest_sha
    manifest = read_json(manifest_path)
    assert manifest.get("schema_version") == 1 and manifest.get("commit") == expected_commit
    files = manifest.get("files")
    assert isinstance(files, dict) and files
    for name, record in files.items():
        raw = (root / name).read_bytes()
        assert sha(raw) == record["sha256"] and len(raw) == record["size_bytes"], name
    return manifest


def check_qa() -> dict:
    qa = read_json(QA_JSON)
    assert qa.get("schema") == "iteration49.asset_batch_focused_qa.v1"
    assert qa.get("status") == "PASS_CURRENT_RELEASE_CHECK_FOCUSED_ONLY"
    assert qa.get("current_candidate_pins") == {**SOURCE_PINS, **TOOL_PINS}
    repair = qa["release_check_repair"]
    assert repair.get("current_helper_sha256") == SOURCE_PINS[HELPER]
    assert repair.get("retest_status") == "PASS"
    retest = repair["retest_result"]
    assert (retest.get("exit_code"), retest.get("passed"), retest.get("failed")) == (0, 8, 0)
    startup = qa["benchmark_startup_preflight"]
    assert startup.get("status") == "STARTUP_METADATA_FAILURE_CORRECTED_BEFORE_EXAMPLE_LAUNCH"
    assert startup.get("example_launched") is False and startup.get("candidate_failure") is False
    assert startup.get("observed_file_sha256") == TRACKED_SOURCE_PINS[
        "examples/backtest/025_factor_single/README.md"
    ]
    assert qa["previous_result"].get("passed") == 34
    assert qa["previous_result"].get("candidate_helper_sha256") != SOURCE_PINS[HELPER]
    for path, expected in zip(QA_LOGS, QA_LOG_SHA256):
        assert file_sha(path) == expected
    assert file_sha(QA_JSON) == QA_JSON_SHA256 and file_sha(REVIEW) == REVIEW_SHA256
    return qa


def check_static_pins() -> dict:
    assert git("rev-parse", "HEAD").decode().strip() == EXPECTED_HEAD
    assert git("branch", "--show-current").decode().strip() == "dev"
    assert not git("diff", "--cached", "--name-only").strip()
    assert file_sha(LAUNCHER) == LAUNCHER_SHA256
    assert file_sha(ROOT / RUNNER) == RUNNER_SHA256
    assert file_sha(ROOT / VERIFIER) == VERIFIER_SHA256
    assert file_sha(SELECTION) == SELECTION_SHA256
    bt_manifest = snapshot(BASE, BT_MANIFEST_SHA256, BT_BASE_COMMIT)
    fc_manifest = snapshot(FC, FC_MANIFEST_SHA256, FC_COMMIT)
    assert HELPER not in bt_manifest["files"]
    for name, expected in SOURCE_PINS.items():
        assert file_sha(ROOT / name) == expected, name
    assert file_sha(ROOT / DAILY) == DAILY_SHA256

    status = git(
        "-c", "core.quotepath=false", "status", "--porcelain=v1", "--untracked-files=all",
        "--", *SOURCE_PINS, DAILY,
    ).decode("utf-8").splitlines()
    expected_status = {name: " M" for name in TRACKED_SOURCE_PINS}
    expected_status.update({TEST: " M", DAILY: " M", HELPER: "??"})
    assert {line[3:]: line[:2] for line in status} == expected_status, status

    # Match the G8 launcher's source-only diff boundary while retaining unrelated edits.
    changed = set()
    for name in bt_manifest["files"]:
        old = (BASE / name).read_bytes().replace(b"\r\n", b"\n")
        new = (ROOT / name).read_bytes().replace(b"\r\n", b"\n")
        if old != new:
            changed.add(name)
    assert changed == set(TRACKED_SOURCE_PINS) | {DAILY}, sorted(changed)
    qa = check_qa()
    return {"backtrader": bt_manifest, "fincore": fc_manifest, "qa": qa}


def run_path(pair: int, arm: str, example: str) -> Path:
    return TEMP / f"iteration49-g8-batch-500-p{pair}-{arm}-{example}"


def run_log(path: Path) -> Path:
    return path.with_suffix(".log")


def verifier_path(pair: int) -> Path:
    return TEMP / f"iteration49-g8-batch-500-p{pair}-verification.json"


def verifier_log(pair: int) -> Path:
    return verifier_path(pair).with_suffix(".log")


def is_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def check_result(path: Path, pair: int, arm: str, example: str, bt_manifest: dict) -> dict:
    result = read_json(path / "result.json")
    assert result.get("schema") == "iteration49.benchmark-run.v1"
    assert result.get("status") == "COMPLETED"
    assert result.get("runner_exit_code") == result.get("example_exit_code") == 0
    assert result.get("input_universe") == "fixed500"
    assert result.get("example") == example and result.get("profile") == "full"
    assert result.get("source_or_input_changes") == []
    assert result.get("summary_check_errors") == []
    for identity in ("backtrader_source", "fincore_source", "data_identity"):
        assert result.get(identity + "_before") == result.get(identity + "_after"), identity

    bt_identity = result["backtrader_source_before"]
    if arm == "a":
        assert (bt_identity.get("kind"), bt_identity.get("commit"), bt_identity.get("manifest_sha256")) == (
            "verified_snapshot_manifest_v1", BT_BASE_COMMIT, BT_MANIFEST_SHA256
        )
        assert HELPER not in result["backtrader_files_before"]
        expected_files = bt_manifest["files"]
    else:
        assert (bt_identity.get("kind"), bt_identity.get("commit"), bt_identity.get("branch")) == (
            "git_worktree", PAIR_CANDIDATE_HEADS[pair], "dev"
        )
        expected_status = {
            **{name: " M" for name in TRACKED_SOURCE_PINS},
            HELPER: "??",
            DAILY: " M",
        }
        actual_status = {line[3:]: line[:2] for line in bt_identity.get("source_status", [])}
        assert actual_status == expected_status, actual_status
        expected_files = None

    fc_identity = result["fincore_source_before"]
    assert (fc_identity.get("kind"), fc_identity.get("commit"), fc_identity.get("manifest_sha256")) == (
        "verified_snapshot_manifest_v1", FC_COMMIT, FC_MANIFEST_SHA256
    )
    data = result["data_identity_before"]
    assert (data.get("symbols"), data.get("dates"), data.get("grid_cells")) == (500, 243, 121500)
    summary = result.get("summary") or {}
    assert (summary.get("symbols"), summary.get("dates"), summary.get("factor_mode"), summary.get("factor_calculation")) == (
        500, 243, "native", "RAN"
    )
    for name in TRACKED_SOURCE_PINS:
        row = result["backtrader_files_before"].get(name)
        expected = TRACKED_SOURCE_PINS[name] if arm == "b" else expected_files[name]["sha256"]
        assert row and row.get("sha256") == expected, (arm, name)
    daily_row = result["backtrader_files_before"].get(DAILY)
    daily_expected = DAILY_SHA256 if arm == "b" else expected_files[DAILY]["sha256"]
    assert daily_row and daily_row.get("sha256") == daily_expected
    if arm == "b":
        helper_row = result["backtrader_files_before"].get(HELPER)
        assert helper_row and helper_row.get("sha256") == SOURCE_PINS[HELPER]
    else:
        assert HELPER not in result["backtrader_files_before"]

    metrics = (
        "example_main_wall_ns", "example_main_process_cpu_ns", "cli_total_wall_ns",
        "cli_total_process_cpu_ns", "main_peak_working_set_bytes", "resource_peak_tree_rss_bytes",
    )
    assert all(is_number(result.get(key)) and result[key] > 0 for key in metrics), metrics
    result["_conservative_peak_bytes"] = max(
        result["main_peak_working_set_bytes"], result["resource_peak_tree_rss_bytes"]
    )
    result.update({"_pair": pair, "_arm": arm, "_example": example, "_path": str(path)})
    return result


def check_verifier(pair: int) -> dict:
    result = read_json(verifier_path(pair))
    assert result.get("schema") == "iteration49.fixed500_output_verification.v1"
    assert result.get("input_universe") == "fixed500"
    assert result.get("mode") == "ab-pair"
    assert result.get("status") == "PASS" and result.get("valid") is True
    assert result.get("scope_complete") is True
    runs = result.get("runs", {})
    assert set(runs.get("baseline", {})) == set(EXAMPLES)
    assert set(runs.get("candidate", {})) == set(EXAMPLES)
    assert all(item.get("valid") is True for side in runs.values() for item in side.values())
    comparisons = result.get("comparisons", {})
    assert set(comparisons) == set(EXAMPLES)
    for example, comparison in comparisons.items():
        assert comparison.get("valid") is True, (pair, example)
        assert all(comparison.get(key) is True for key in (
            "summary_metadata_equal", "evaluation_id_equal", "result_fingerprint_equal",
            "evaluation_manifest_equal",
        ))
        factors = comparison.get("factor_values") or {}
        assert all(factors.get(key) is True for key in ("columns_equal", "row_order_equal", "values_equal"))
        tables = comparison.get("evaluation_tables") or {}
        if example in ("025", "026"):
            assert tables and all(
                row.get("columns_equal") is True and row.get("row_order_equal") is True
                for row in tables.values()
            )
        else:
            assert tables == {}
        reports = comparison.get("reports") or {}
        assert reports
        report_fields = (
            "model_tables_and_series_equal", "semantic_digest_equal", "embedded_plot_data_equal",
            "rendered_table_cells_equal",
        )
        assert all(all(report.get(key) is True for key in report_fields) for report in reports.values())
    return result


def ratio_summary(pairs: list[dict], metric: str) -> dict:
    ratios = [row["baseline"] / row["candidate"] for row in pairs]
    reductions = [1.0 - row["candidate"] / row["baseline"] for row in pairs]
    median_ratio = statistics.median(ratios)
    dispersion = (max(ratios) - min(ratios)) / median_ratio
    median_reduction = statistics.median(reductions)
    if dispersion > 0.05:
        conclusion = "unstable_over_5_percent_pair_dispersion"
    elif median_reduction <= 0:
        conclusion = "no_positive_median_reduction"
    elif median_reduction <= dispersion:
        conclusion = "gain_within_observed_pair_dispersion"
    else:
        conclusion = "stable_positive_reduction_beyond_pair_dispersion"
    return {
        "metric": metric,
        "baseline_median": statistics.median(row["baseline"] for row in pairs),
        "candidate_median": statistics.median(row["candidate"] for row in pairs),
        "baseline_over_candidate_by_pair": ratios,
        "candidate_reduction_by_pair": reductions,
        "median_reduction_fraction": median_reduction,
        "ratio_range_over_median": dispersion,
        "dispersion_limit_fraction": 0.05,
        "within_dispersion_limit": dispersion <= 0.05,
        "conclusion": conclusion,
    }


def phase_summaries(rows: list[dict], metric: str) -> dict:
    phase_sets = [set((row.get("phase_timers") or {}).keys()) for row in rows]
    phases = sorted(set.intersection(*phase_sets)) if phase_sets else []
    answer = {}
    for phase in phases:
        pairs = []
        valid = True
        for pair in PAIRS:
            a = next(row for row in rows if row["_pair"] == pair and row["_arm"] == "a")
            b = next(row for row in rows if row["_pair"] == pair and row["_arm"] == "b")
            av = (a.get("phase_timers", {}).get(phase) or {}).get(metric)
            bv = (b.get("phase_timers", {}).get(phase) or {}).get(metric)
            if not (is_number(av) and is_number(bv) and av > 0 and bv > 0):
                valid = False
                break
            pairs.append({"baseline": av, "candidate": bv})
        answer[phase] = ratio_summary(pairs, metric) if valid else {"status": "not_available_for_all_pairs"}
    return answer


def collect_members(rows: list[dict], verifiers: dict) -> dict[str, bytes]:
    members: dict[str, bytes] = {}
    for row in rows:
        pair, arm, example = row["_pair"], row["_arm"], row["_example"]
        output = Path(row["_path"])
        members[f"runs/p{pair}/{arm}/{example}/result.json"] = (output / "result.json").read_bytes()
        members[f"runs/p{pair}/{arm}/{example}.log"] = run_log(output).read_bytes()
    for pair in PAIRS:
        members[f"verifiers/p{pair}/verification.json"] = verifier_path(pair).read_bytes()
        members[f"verifiers/p{pair}/verification.log"] = verifier_log(pair).read_bytes()
    for name in SOURCE_PINS:
        members[f"candidate-source/{name}"] = (ROOT / name).read_bytes()
    for name, expected in ((RUNNER, RUNNER_SHA256), (VERIFIER, VERIFIER_SHA256)):
        path = ROOT / name
        assert file_sha(path) == expected
        members[f"canonical-tools/{Path(name).name}"] = path.read_bytes()
    members[f"launcher/{LAUNCHER.name}"] = LAUNCHER.read_bytes()
    members[f"functional-qa/{QA_JSON.name}"] = QA_JSON.read_bytes()
    members[f"independent-review/{REVIEW.name}"] = REVIEW.read_bytes()
    for path in QA_LOGS:
        members[f"functional-qa/{path.name}"] = path.read_bytes()
    members["selection/benchmark-500-7col.json"] = SELECTION.read_bytes()
    members["snapshot-manifests/g7-backtrader/.iteration49-source.json"] = (
        BASE / ".iteration49-source.json"
    ).read_bytes()
    members["snapshot-manifests/g6-fincore/.iteration49-source.json"] = (
        FC / ".iteration49-source.json"
    ).read_bytes()
    helper_path = Path(__file__).resolve()
    members[f"closeout-helper/{helper_path.name}"] = helper_path.read_bytes()
    assert sum(name.startswith("runs/") and name.endswith("/result.json") for name in members) == 18
    assert sum(name.startswith("runs/") and name.endswith(".log") for name in members) == 18
    assert sum(name.startswith("verifiers/") and name.endswith(".json") for name in members) == 3
    assert sum(name.startswith("verifiers/") and name.endswith(".log") for name in members) == 3
    return members


def make_zip(members: dict[str, bytes]) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, raw)
    payload = stream.getvalue()
    with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(members)
        for name, expected in members.items():
            assert archive.read(name) == expected, name
    return payload


def fmt_seconds(ns: float) -> str:
    return f"{ns / 1e9:.3f}"


def pct(value: float) -> str:
    return f"{value * 100:+.2f}%"


def docs_additions(analysis: dict, analysis_sha: str, evidence_sha: str) -> dict[Path, bytes]:
    table = [
        "| 示例 | G7基线main中位数s | G8分批候选main中位数s | 配对降时中位数 | 比率离散度 | CPU配对降幅 | CLI总墙钟降幅 | 候选峰值中位数/最大值MB |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for example in EXAMPLES:
        row = analysis["per_example"][example]
        wall, cpu, cli, peak = row["main_wall"], row["main_cpu"], row["cli_wall"], row["conservative_peak_bytes"]
        table.append(
            f"| {example} | {fmt_seconds(wall['baseline_median'])} | {fmt_seconds(wall['candidate_median'])} "
            f"| {pct(wall['median_reduction_fraction'])} | {pct(wall['ratio_range_over_median'])} "
            f"| {pct(cpu['median_reduction_fraction'])} | {pct(cli['median_reduction_fraction'])} "
            f"| {peak['candidate_median']/1e6:.1f}/{peak['candidate_max']/1e6:.1f} |"
        )
    body = "\n".join(table)
    scope = (
        "A臂为已接受G7源码快照 `fa7a3484`，B臂为Backtrader `dev` 的G8资产分批候选；FinCore两臂均为"
        "G6快照 `4e01ac9f`。输入为相同7列500股×243日期。18次完整示例运行按AB/BA/AB串行配对，"
        "三份完整输出verifier均PASS且scope complete，共9个唯一比较。027没有改动资产rank路径，作为未分批对照。"
    )
    qa_text = (
        "当前源码状态由6个精确源码/测试pin绑定。历史34项QA属于弱引用释放修复前的helper；"
        "本轮又对当前helper的释放检查执行8个025/026×native/build×runnext/runonce参数组合，8项通过。"
        "两次QA各有1条已知pytest配置warning；这不是完整回归重跑，也不能代替实际配对验收。"
    )
    design = (
        "025/026的默认路径以每批最多256个资产执行真实普通Cerebro，保留每资产完整日期轴；"
        "将因子和开收盘价格复制到预分配的完整float64数组，逐批释放策略、全部feed和因子实例后再合并"
        "完整FactorPanel，最后只做一次全量评价与报告。输入由现有单次面板加载提供；不构造伪Strategy，"
        "也不改变默认采集API返回真实策略的契约。完整输出、NaN、列/行顺序与数学等价由verifier检查。"
    )
    boundaries = (
        "此处只表征固定500股，不证明5471股全流程进程树峰值≤1GB，也不证明任一例达到80%降时或"
        "最终五倍目标；不得把500耗时或峰值线性外推到全市场。分批限制同时存活的Cerebro图规模，"
        "但最终完整输出数组、评价和报告仍然存在。027的横截面rank必须看见全市场截面，继续使用未分批控制路径。"
    )
    timing_readout = "；".join(
        f"{example} main墙钟中位数降幅{pct(analysis['per_example'][example]['main_wall']['median_reduction_fraction'])}，"
        f"配对比率离散度{pct(analysis['per_example'][example]['main_wall']['ratio_range_over_median'])}"
        for example in EXAMPLES
    )
    links = f"分析JSON SHA-256 `{analysis_sha}`；原始证据ZIP SHA-256 `{evidence_sha}`。"
    return {
        DOC_RECORD: (
            "\n\n## G8：025/026按资产分批采集（固定500）\n\n"
            + scope + "\n\n" + design + "\n\n" + body + "\n\n"
            + qa_text + "\n\n" + boundaries + "\n\n" + links + "\n"
        ).encode("utf-8"),
        DOC_ROUTE: (
            "\n\n## G8：025/026资产分批实测后的路线更新\n\n"
            + "本节补充G7全量R1后的静态路线判断：资产分批现已完成固定500输出等价与配对表征，"
            + scope + "\n\n" + design + "\n\n" + body + "\n\n"
            + "实际三对结果：" + timing_readout + "。这轮只接受固定500完整输出等价并记录分批架构的性能表征，"
            + "不称作80%提速通过；有界Cerebro图不等于全进程已达内存目标。全量阶段仍须等其它优化收敛后再测。\n\n"
            + boundaries + "\n\n" + links + "\n"
        ).encode("utf-8"),
    }


def main() -> None:
    assert not ANALYSIS_PATH.exists() and not EVIDENCE_PATH.exists()
    assert not COMMIT_CONFIG.exists() and not COMMIT_RECEIPT.exists()
    assert all(path.is_file() for path in QA_LOGS)
    manifests = check_static_pins()

    rows = []
    index = {}
    for pair in PAIRS:
        for example in EXAMPLES:
            for arm in ARMS:
                path = run_path(pair, arm, example)
                log = run_log(path)
                assert (path / "result.json").is_file() and log.is_file(), (path, log)
                result = check_result(path, pair, arm, example, manifests["backtrader"])
                assert file_sha(path / "result.json")
                rows.append(result)
                index[(pair, arm, example)] = result
    assert len(rows) == 18
    verifiers = {pair: check_verifier(pair) for pair in PAIRS}

    per_example = {}
    for example in EXAMPLES:
        pairs = []
        for pair in PAIRS:
            a, b = index[(pair, "a", example)], index[(pair, "b", example)]
            pairs.append({
                "pair": pair,
                "baseline_main_wall_ns": a["example_main_wall_ns"],
                "candidate_main_wall_ns": b["example_main_wall_ns"],
                "baseline_main_cpu_ns": a["example_main_process_cpu_ns"],
                "candidate_main_cpu_ns": b["example_main_process_cpu_ns"],
                "baseline_cli_wall_ns": a["cli_total_wall_ns"],
                "candidate_cli_wall_ns": b["cli_total_wall_ns"],
                "baseline_cli_cpu_ns": a["cli_total_process_cpu_ns"],
                "candidate_cli_cpu_ns": b["cli_total_process_cpu_ns"],
                "baseline_peak_bytes": a["_conservative_peak_bytes"],
                "candidate_peak_bytes": b["_conservative_peak_bytes"],
            })
        def metric(name: str, baseline: str, candidate: str) -> dict:
            return ratio_summary(
                [{"baseline": pair[baseline], "candidate": pair[candidate]} for pair in pairs], name
            )
        six = [index[(pair, arm, example)] for pair in PAIRS for arm in ARMS]
        peak_pairs = [{"baseline": p["baseline_peak_bytes"], "candidate": p["candidate_peak_bytes"]} for p in pairs]
        per_example[example] = {
            "pairs": pairs,
            "main_wall": metric("example_main_wall_ns", "baseline_main_wall_ns", "candidate_main_wall_ns"),
            "main_cpu": metric("example_main_process_cpu_ns", "baseline_main_cpu_ns", "candidate_main_cpu_ns"),
            "cli_wall": metric("cli_total_wall_ns", "baseline_cli_wall_ns", "candidate_cli_wall_ns"),
            "cli_cpu": metric("cli_total_process_cpu_ns", "baseline_cli_cpu_ns", "candidate_cli_cpu_ns"),
            "conservative_peak_bytes": {
                "baseline_median": statistics.median(p["baseline"] for p in peak_pairs),
                "candidate_median": statistics.median(p["candidate"] for p in peak_pairs),
                "baseline_max": max(p["baseline"] for p in peak_pairs),
                "candidate_max": max(p["candidate"] for p in peak_pairs),
                "candidate_each_pair_under_1gb": all(p["candidate"] <= 1_000_000_000 for p in peak_pairs),
                "baseline_over_candidate_by_pair": [p["baseline"] / p["candidate"] for p in peak_pairs],
            },
            "exclusive_wall_phases": phase_summaries(six, "wall_exclusive_ns"),
            "exclusive_cpu_phases": phase_summaries(six, "process_cpu_exclusive_ns"),
        }

    members = collect_members(rows, verifiers)
    member_manifest = [
        {"name": name, "sha256": sha(raw), "size_bytes": len(raw)}
        for name, raw in sorted(members.items())
    ]
    evidence_bytes = make_zip(members)
    evidence_sha = sha(evidence_bytes)
    qa = manifests["qa"]
    analysis = {
        "schema": "iteration49.g8_asset_batch_fixed500_closeout.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "measurement": "7col-500-g8-asset-batch",
        "scope": "G8 fixed500 x 243 incremental comparison of 025/026 asset batching versus accepted G7 snapshot; 027 is unchanged control; not B0 cumulative or 5471 acceptance",
        "closeout_preflight_note": (
            "A prior closeout-helper attempt stopped before writes because its p1 candidate-HEAD expectation was wrong. "
            "Read-only metadata inspection of all nine B-arm result.json files confirms each reports the pinned dev HEAD; "
            "this was a delivery-helper assertion error, with no candidate failure or benchmark rerun."
        ),
        "repository": {
            "path": str(ROOT), "branch": "dev", "head": EXPECTED_HEAD,
            "candidate_source_pins": SOURCE_PINS,
            "candidate_execution_heads_by_pair": {str(pair): PAIR_CANDIDATE_HEADS[pair] for pair in PAIRS},
            "canonical_tools": {RUNNER: RUNNER_SHA256, VERIFIER: VERIFIER_SHA256},
            "launcher": {"path": str(LAUNCHER), "sha256": file_sha(LAUNCHER)},
        },
        "baseline": {
            "backtrader_commit": BT_BASE_COMMIT, "backtrader_manifest_sha256": BT_MANIFEST_SHA256,
            "fincore_commit": FC_COMMIT, "fincore_manifest_sha256": FC_MANIFEST_SHA256,
        },
        "fixed_input": {
            "universe": "fixed500", "symbols": 500, "dates": 243, "grid_cells": 121500,
            "selection_sha256": SELECTION_SHA256, "data_root": str(DATA_ROOT),
        },
        "source_qa": {
            "status": qa["status"], "current_helper_release_retest_passed": 8,
            "previous_34_pass_run_used_pre_release_check_helper": True,
            "startup_pin_correction": qa["benchmark_startup_preflight"],
            "qa_json_sha256": file_sha(QA_JSON),
            "logs": [{"path": str(p), "sha256": file_sha(p), "size_bytes": p.stat().st_size} for p in QA_LOGS],
            "review": {"path": str(REVIEW), "sha256": file_sha(REVIEW)},
            "evidence_level": "FOCUSED_SOURCE_QA_AND_STATIC_REVIEW; NOT PERFORMANCE ACCEPTANCE",
        },
        "actual_measurements": {
            "status": "PASS_G8_FIXED500_OUTPUT_AND_SOURCE_IDENTITY_ONLY",
            "actual_processes": 18,
            "unique_comparisons": 9,
            "complete_verifiers": 3,
            "verifier_slots": 9,
            "all_verifiers_pass_scope_complete": True,
            "runs": [
                {
                    "pair": row["_pair"], "arm": row["_arm"], "example": row["_example"],
                    "result_path": str(Path(row["_path"]) / "result.json"),
                    "result_sha256": file_sha(Path(row["_path"]) / "result.json"),
                    "log_path": str(run_log(Path(row["_path"]))),
                    "log_sha256": file_sha(run_log(Path(row["_path"]))),
                    "backtrader_source": row["backtrader_source_before"],
                    "fincore_source": row["fincore_source_before"],
                    "data_identity": row["data_identity_before"],
                    "source_or_input_changes": row["source_or_input_changes"],
                    "example_main_wall_ns": row["example_main_wall_ns"],
                    "example_main_process_cpu_ns": row["example_main_process_cpu_ns"],
                    "cli_total_wall_ns": row["cli_total_wall_ns"],
                    "cli_total_process_cpu_ns": row["cli_total_process_cpu_ns"],
                    "main_peak_working_set_bytes": row["main_peak_working_set_bytes"],
                    "resource_peak_tree_rss_bytes": row["resource_peak_tree_rss_bytes"],
                    "conservative_peak_bytes": row["_conservative_peak_bytes"],
                    "phase_timers": row.get("phase_timers", {}),
                } for row in rows
            ],
        },
        "verifiers": {
            str(pair): {
                "path": str(verifier_path(pair)), "sha256": file_sha(verifier_path(pair)),
                "log_path": str(verifier_log(pair)), "log_sha256": file_sha(verifier_log(pair)),
                "status": verifiers[pair]["status"], "scope_complete": verifiers[pair]["scope_complete"],
                "valid": verifiers[pair]["valid"], "comparisons": verifiers[pair]["comparisons"],
            } for pair in PAIRS
        },
        "per_example": per_example,
        "performance_claim": {
            "full_5471_memory_under_1gb_claimed": False,
            "80_percent_reduction_claimed": False,
            "full_market_acceptance_claimed": False,
            "interpretation": "Fixed-500 paired timing and process-memory characterization only; retain full-market measurement until all selected optimizations are complete.",
        },
        "evidence_archive": {
            "path": str(EVIDENCE_PATH), "sha256": evidence_sha, "size_bytes": len(evidence_bytes),
            "members": member_manifest,
            "excluded": ["example output trees", "factor CSVs", "HTML", "PNG", "full 5471 outputs"],
        },
    }
    analysis_bytes = (json.dumps(analysis, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n").encode("utf-8")
    analysis_sha = sha(analysis_bytes)

    additions = docs_additions(analysis, analysis_sha, evidence_sha)
    doc_originals = {}
    doc_payloads = {}
    markers = {
        DOC_RECORD: "## G8：025/026按资产分批采集".encode("utf-8"),
        DOC_ROUTE: "## G8：025/026资产分批实测后的路线更新".encode("utf-8"),
    }
    for path, addition in additions.items():
        prior = path.read_bytes()
        assert markers[path] not in prior, f"G8 closeout already exists in {path}"
        doc_originals[path] = prior
        doc_payloads[path] = prior.rstrip(b"\r\n") + b"\n\n" + addition.strip(b"\r\n") + b"\n"

    # Recheck source/tool pins and documents immediately before creating evidence.
    check_static_pins()
    assert not ANALYSIS_PATH.exists() and not EVIDENCE_PATH.exists() and not COMMIT_CONFIG.exists()
    assert not git("diff", "--cached", "--name-only").strip()
    for path, raw in doc_originals.items():
        assert path.read_bytes() == raw, f"document changed during closeout preparation: {path}"

    MEASUREMENTS.mkdir(parents=True, exist_ok=True)
    for path, payload in ((ANALYSIS_PATH, analysis_bytes), (EVIDENCE_PATH, evidence_bytes)):
        with path.open("xb") as stream:
            stream.write(payload)
    for path, payload in doc_payloads.items():
        with path.open("wb") as stream:
            stream.write(payload)

    scope = list(SOURCE_PINS) + [
        DOC_RECORD.relative_to(ROOT).as_posix(),
        DOC_ROUTE.relative_to(ROOT).as_posix(),
        ANALYSIS_PATH.relative_to(ROOT).as_posix(),
        EVIDENCE_PATH.relative_to(ROOT).as_posix(),
    ]
    assert len(scope) == 10 and len(set(scope)) == 10
    config = {
        "repository": str(ROOT), "parent": EXPECTED_HEAD, "branch": "dev",
        "receipt": str(COMMIT_RECEIPT),
        "message": "perf(research): bound 025/026 factor collection graphs",
        "files": scope,
        "expected_sha256": {name: file_sha(ROOT / name) for name in scope},
        "acceptance": (
            "G8 fixed500 A/B output equivalence passed 9 unique comparisons across 18 runs and 3 complete verifiers; "
            "record 025/026 batch-graph memory design and actual timing dispersion without claiming 5471 memory or 80% speedup"
        ),
        "expected_scope_count": 10,
        "source_qa": "34 passes were on the pre-release-check helper; the current helper release-check rerun passed 8 focused parameter cases",
        "performance_scope": "500 x 243 incremental versus accepted G7; 027 unchanged control; not cumulative versus B0 or full-market acceptance",
        "git_add_or_commit_executed": False,
    }
    with COMMIT_CONFIG.open("xb") as stream:
        stream.write((json.dumps(config, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    print(json.dumps({
        "status": "PREPARED_NO_GIT_MUTATION",
        "analysis": str(ANALYSIS_PATH), "analysis_sha256": analysis_sha,
        "evidence_zip": str(EVIDENCE_PATH), "evidence_zip_sha256": evidence_sha,
        "commit_config": str(COMMIT_CONFIG), "scope_count": len(scope),
        "wall_conclusions": {example: per_example[example]["main_wall"]["conclusion"] for example in EXAMPLES},
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
