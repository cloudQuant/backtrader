# 026: Multi-factor research on real A-share daily bars

This example collects three native Backtrader factors on the same real daily panel as 025:

- `close / SMA(close, 20)`;
- `close / close[-20] - 1` using the native ROC indicator;
- KDJ.J with a 9-bar high/low range, 3-bar K smoothing and 3-bar D smoothing.

From the repository root:

```powershell
python examples/backtest/026_factor_multi/run.py --output-dir output/026-real
python examples/backtest/026_factor_multi/run.py --factor-mode build --report --save-panel --output-dir output/026-build
```

`--factor-mode native|build` switches all three factors together. The CLI overrides `config.yaml`'s `factor_mode`; the default is `native`. The output order remains `close_ma`, `kdj_j`, `roc`. Both modes construct ordinary indicator dependencies and use the same Cerebro lifecycle; mode selection is independent of the default runonce engine or `--runnext`. The original three factor classes each own both native and build methods; `FactorSpec(mode=...)` selects their behavior. The build methods retain the native SMA/ROC/highest/lowest calculations and pointwise validity rules.

The current single-class refactor passed local source and installed-wheel checks; see the [Iteration49 implementation and acceptance record](../../../docs/_internal/opts/requirements/迭代49-因子单类双模式重构/实施与验收.md). The historical [Iteration48 acceptance record](../../../docs/_internal/opts/requirements/迭代48-Alpha101-build实现/验收结果.md) includes this entry's full native/build evaluation, report and CSV reevaluation comparisons on pinned wheels with 20 assets. The separate 500-asset comparison remains recorded in Iteration47.

Like 025, the runner evenly samples **500** symbols from `tests/datas/a_stocks` by default; `--max-symbols 0` uses all 5,471, and `--data-dir` selects another panel with the same layout. The research calendar is the source-observed session union, prices are unadjusted, and missing rows are not filled.

Native collection defaults to 256 assets per ordinary Cerebro run. Each asset keeps its full date history; the runner merges factors and full-grid prices in manifest order, then evaluates and reports once on the complete panel. Use `--asset-batch-size 0` to run one Cerebro over all selected assets; `--panel` skips factor calculation and ignores this option.

The configured evaluation asks fincore for cross-sectional ranks, the fixed `equal_weight` combination, its leave-one-factor-out ablations, IC/Rank IC, quantiles, stability, correlation and common-pool comparisons. The output factor columns are `close_ma`, `kdj_j`, `roc` (the library's stable order), one row per grid time and symbol.

Outputs:

- `factor_values.csv`: `time`, `asset`, and the three factor columns.
- `evaluation/`: fincore's tables and chart, when the fincore factor-research API is installed.
- `summary.json`: status, symbol/date counts, evaluation identity, report paths, actual factor mode/classes and order counters.
- `factor_report_<factor>.html`: written with `--report`, one self-contained bilingual (中文/English) report per factor with interactive ECharts charts and IC, quantile-return, turnover and coverage tables.
- `panel/`: written only with `--save-panel`; the six CSV files (`factors`, `grid`, `prices_open`, `prices_close`, `universe`, `groups`) for an explicit offline re-evaluation.

Evaluation is optional. When fincore's research API is unavailable, `factor_values.csv` is still written, `EVALUATION SKIPPED` is printed, and the run exits 0 with `summary.json.status="PANEL_ONLY"`. Exit codes are 0 for written outputs, 1 for a failed or `UNEVALUABLE` evaluation, 2 for invalid or missing input, and 3 for an output I/O failure.

Useful flags: `--report`, `--report-language zh|en` (default `zh`; the HTML also has a 中文/EN switch), `--no-charts`, `--periods 1 5 20`, `--runnext`, `--asset-batch-size 256|0`, `--save-panel`, and `--panel <saved-panel>` for offline re-evaluation without Cerebro. `--report` delegates to `fincore.report.factor.write_factor_report`, so it works even when the separate research-evaluation API is unavailable.

`--panel` cannot be combined with an explicit `--factor-mode`; the config's default mode does not trigger calculation. Its summary records `factor_mode="NOT_APPLICABLE"` and `factor_calculation="NOT_RUN"`. Use a new output directory for each run.

The output is a factor research result, not a trading strategy or evidence of investment performance.
