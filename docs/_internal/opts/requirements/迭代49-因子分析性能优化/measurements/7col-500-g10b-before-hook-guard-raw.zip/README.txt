G10b before-hook-guard fixed-500 raw results, logs, summaries, phase-timer projections and verifier receipts; no large output tables.
