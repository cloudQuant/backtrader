# Iteration 49 G10: research period quantile reuse

This candidate keeps a private, evaluate-local qcut cache for one factor at a
time. It is shared only across that factor's requested periods. Combination
factors receive separate caches. Public `quantize_factor` and the public
research API are unchanged; calls outside research keep the existing path.

A cache key binds the UTC date, the exact ordered asset rows using compact
`uint32` asset codes, and the exact float64 factor bytes. Reuse is limited to
ordinary integer-quantile qcut with the same configuration. Grouped, zero-aware,
cut/bins, unsupported index/dtype, and non-UTC inputs use the original qcut
path. Only a complete successful `int64` result is retained. Duplicate-edge
errors and `no_raise` NaN results are never cached.

The cache has a 32 MiB retained key/value budget and a 2,048-entry cap; a
512-byte per-entry allowance accounts for Python containers and array headers.
It does not evict entries: once either limit is reached, later misses run the
original qcut path while existing entries remain available for hits. At 5,471
assets across 243 dates, one full date entry is about 20 bytes per row plus the
fixed allowance; the full first-period set is roughly 25.6 MiB. Additional
distinct masks may exhaust the remaining budget and safely fall back.

The 500-asset panel inspection found 705 same-factor/date matching-mask
candidates among 2,587 period/date qcut calls. This is a reuse opportunity
count, not a runtime estimate. Focused tests compare every production research
table and both result IDs with the forced original path, and exercise changed
masks/factor bytes/configuration, factor-local caches, duplicate edges, and
byte/entry budget fallback. The Root 500-asset paired screen will determine
whether this candidate is retained; no performance acceptance is claimed here.
