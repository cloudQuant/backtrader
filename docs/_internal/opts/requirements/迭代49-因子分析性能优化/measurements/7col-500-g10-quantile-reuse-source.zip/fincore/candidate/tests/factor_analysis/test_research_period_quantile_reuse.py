"""Exact, evaluate-local qcut reuse across matching research periods."""

from __future__ import annotations

import weakref

import numpy as np
import pandas as pd
import pandas.testing as pdt
import pytest

from fincore.factor_analysis import data, research


def _panel(*, n_dates: int = 8, n_assets: int = 12) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    dates = pd.bdate_range("2024-01-02", periods=n_dates, tz="UTC")
    assets = tuple(f"A{position:02d}" for position in range(n_assets))
    index = pd.MultiIndex.from_product((dates, assets), names=("time", "asset"))
    asset_values = np.linspace(-1.0, 1.0, n_assets)
    time_values = np.arange(n_dates, dtype=float) * 1e-3
    factors = pd.DataFrame(
        {
            "factor_a": np.tile(asset_values, n_dates) + np.repeat(time_values, n_assets),
            "factor_b": np.tile(asset_values, n_dates) + np.repeat(time_values, n_assets),
        },
        index=index,
    )
    returns: dict[int, np.ndarray] = {}
    for period in (1, 2, 3):
        values = np.tile(asset_values * (period * 1e-3), n_dates)
        matrix = values.reshape(n_dates, n_assets).copy()
        for date_position in range(n_dates):
            if period > 1 and date_position % 2 == 1:
                matrix[date_position, -period:] = np.nan
            if period == 3 and date_position % 3 == 0:
                matrix[date_position, -2:] = np.nan
        returns[period] = matrix.reshape(-1)
    precomputed = pd.DataFrame(returns, index=index)
    grid = pd.DataFrame({"open_time": dates}, index=dates)
    return factors, precomputed, grid


def _evaluate_inputs(
    factors: pd.DataFrame,
    precomputed: pd.DataFrame,
    grid: pd.DataFrame,
) -> dict[str, object]:
    dates = pd.DatetimeIndex(factors.index.get_level_values("time").unique())
    assets = tuple(factors.index.get_level_values("asset").unique())
    return {
        "grid": grid,
        "prices": None,
        "universe": None,
        "groups": None,
        "precomputed_returns": precomputed,
        "spec": {
            "targets": assets,
            "start": dates[0],
            "end": dates[-1],
            "periods": (1, 2, 3),
            "label": "precomputed",
            "preprocess": "none",
            "min_assets": 2,
            "min_quantile_assets": 1,
            "quantiles": 4,
            "stability_lags": (),
        },
    }


def _group_values(date: pd.Timestamp, assets: tuple[str, ...], values: np.ndarray) -> pd.Series:
    index = pd.MultiIndex.from_arrays(
        (pd.DatetimeIndex([date] * len(assets)), pd.Index(assets)),
        names=("date", "asset"),
    )
    return pd.Series(values, index=index, name="factor", dtype=np.float64)


def _quantize(
    values: pd.Series,
    *,
    quantiles: int = 4,
    no_raise: bool = False,
    context: data._PeriodQuantileReuse | None = None,
) -> pd.Series:
    return data._quantile_calculation(
        values,
        quantiles=quantiles,
        bins=None,
        zero_aware=False,
        no_raise=no_raise,
        reuse_context=context,
    )


def _context(
    panel_index: pd.MultiIndex,
    *,
    quantiles: int = 4,
    no_raise: bool = False,
    max_cache_bytes: int = 32 * 1024 * 1024,
    max_entries: int = 2048,
) -> data._PeriodQuantileReuse:
    return data._PeriodQuantileReuse(
        panel_index,
        quantiles=quantiles,
        bins=None,
        by_group=False,
        zero_aware=False,
        no_raise=no_raise,
        max_cache_bytes=max_cache_bytes,
        max_entries=max_entries,
    )


def test_research_multiperiod_tables_and_ids_match_forced_original_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    factors, precomputed, grid = _panel()
    inputs = _evaluate_inputs(factors, precomputed, grid)

    factory = research._new_period_quantile_reuse_context
    monkeypatch.setattr(research, "_new_period_quantile_reuse_context", lambda *_args: None)
    original_path = research.evaluate_factor_research(factors, **inputs)

    contexts: list[data._PeriodQuantileReuse] = []

    def record_context(panel_index: pd.MultiIndex, spec: research.ResearchEvaluationSpec):
        context = factory(panel_index, spec)
        contexts.append(context)
        return context

    monkeypatch.setattr(research, "_new_period_quantile_reuse_context", record_context)
    reused = research.evaluate_factor_research(factors, **inputs)

    assert len(contexts) == 2
    assert contexts[0] is not contexts[1]
    assert all(context.hits > 0 for context in contexts)
    assert all(context.cache_bytes <= context._max_cache_bytes for context in contexts)
    assert reused.status == original_path.status
    assert dict(reused.manifest) == dict(original_path.manifest)
    assert reused.manifest["evaluation_id"] == original_path.manifest["evaluation_id"]
    assert reused.manifest["result_fingerprint"] == original_path.manifest["result_fingerprint"]
    for table_name in research.RESULT_TABLES:
        pdt.assert_frame_equal(
            reused.table(table_name),
            original_path.table(table_name),
            check_exact=True,
            check_dtype=True,
        )


def test_period_cache_contexts_are_released_before_result_fingerprinting(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    factors, precomputed, grid = _panel()
    inputs = _evaluate_inputs(factors, precomputed, grid)
    spec = dict(inputs["spec"])
    spec["combinations"] = {"combined": {"factor_a": 0.5, "factor_b": 0.5}}
    inputs["spec"] = spec

    factory = research._new_period_quantile_reuse_context
    context_refs: list[weakref.ReferenceType[data._PeriodQuantileReuse]] = []
    released_contexts: list[bool] = []

    def track_context(panel_index: pd.MultiIndex, normalized: research.ResearchEvaluationSpec):
        context = factory(panel_index, normalized)
        context_refs.append(weakref.ref(context))
        weakref.finalize(context, released_contexts.append, True)
        return context

    original_fingerprint = research.fingerprint_value

    def assert_contexts_released(value: object) -> str:
        assert context_refs
        assert all(context_ref() is None for context_ref in context_refs)
        assert len(released_contexts) == 3
        return original_fingerprint(value)

    monkeypatch.setattr(research, "_new_period_quantile_reuse_context", track_context)
    monkeypatch.setattr(research, "fingerprint_value", assert_contexts_released)
    result = research.evaluate_factor_research(factors, **inputs)

    assert result.status == "OK"
    assert len(context_refs) == 3


def test_reuse_requires_same_ordered_rows_factor_bits_and_configuration() -> None:
    date = pd.Timestamp("2024-01-02", tz="UTC")
    other_date = pd.Timestamp("2024-01-03", tz="UTC")
    assets = tuple(f"A{position:02d}" for position in range(8))
    panel_index = pd.MultiIndex.from_product(((date, other_date), assets), names=("time", "asset"))
    context = _context(panel_index)
    values = _group_values(date, assets, np.arange(8, dtype=np.float64))

    first = _quantize(values, context=context)
    same = _quantize(values.copy(), context=context)
    assert context.hits == 1
    pdt.assert_series_equal(first, same, check_exact=True)

    masked = values.iloc[:-1]
    _quantize(masked, context=context)
    assert context.hits == 1

    changed_factor = values.copy()
    changed_factor.iloc[0] = np.nextafter(changed_factor.iloc[0], np.inf)
    _quantize(changed_factor, context=context)
    assert context.hits == 1

    _quantize(values, quantiles=3, context=context)
    assert context.hits == 1
    assert context.bypasses > 0

    other_factor_context = _context(panel_index)
    _quantize(values, context=other_factor_context)
    assert other_factor_context.hits == 0
    assert other_factor_context.misses == 1


def test_duplicate_qcut_edges_and_no_raise_nan_results_are_never_cached() -> None:
    date = pd.Timestamp("2024-01-02", tz="UTC")
    assets = tuple(f"A{position:02d}" for position in range(8))
    panel_index = pd.MultiIndex.from_product(((date,), assets), names=("time", "asset"))
    duplicate_values = _group_values(date, assets, np.ones(8, dtype=np.float64))

    raising = _context(panel_index)
    with pytest.raises(ValueError, match="Bin edges must be unique"):
        _quantize(duplicate_values, context=raising)
    assert raising.cache_entries == 0

    non_raising = _context(panel_index, no_raise=True)
    result = _quantize(duplicate_values, no_raise=True, context=non_raising)
    assert result.isna().all()
    assert non_raising.cache_entries == 0


def test_budget_and_entry_exhaustion_fall_back_without_exceeding_bounds() -> None:
    date1 = pd.Timestamp("2024-01-02", tz="UTC")
    date2 = pd.Timestamp("2024-01-03", tz="UTC")
    assets = tuple(f"A{position:02d}" for position in range(4))
    panel_index = pd.MultiIndex.from_product(((date1, date2), assets), names=("time", "asset"))
    values1 = _group_values(date1, assets, np.arange(4, dtype=np.float64))
    values2 = _group_values(date2, assets, np.arange(4, dtype=np.float64))

    byte_limited = _context(panel_index, quantiles=2, max_cache_bytes=620)
    _quantize(values1, quantiles=2, context=byte_limited)
    _quantize(values2, quantiles=2, context=byte_limited)
    assert byte_limited.cache_entries == 1
    assert byte_limited.cache_bytes <= 620
    assert byte_limited.bypasses > 0

    entry_limited = _context(panel_index, quantiles=2, max_cache_bytes=4096, max_entries=1)
    _quantize(values1, quantiles=2, context=entry_limited)
    _quantize(values2, quantiles=2, context=entry_limited)
    assert entry_limited.cache_entries == 1
    assert entry_limited.cache_bytes <= 4096
    assert entry_limited.bypasses > 0
