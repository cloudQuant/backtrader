# Iteration 49 G10 qcut reuse: static review

Reviewed read-only against Fincore `dev` base `4a8018105cf331969bb88cd26c47e158704a32e5`.

| File | SHA-256 |
|---|---|
| `fincore/factor_analysis/data.py` | `25f1b45c6d59d4d27a5dea318f415851312c26e6ae67147fbb8b21c7c11d6367` |
| `fincore/factor_analysis/research.py` | `202ed2d62c510939817b45b37ad7098a6a7985be9b81515aee5642cdf447b169` |
| `tests/factor_analysis/test_research_period_quantile_reuse.py` | `72b5476ba9abbacbfb2d9fdbaaa2f9f5964e983754393135f742528c76274c8b` |
| `docs/plans/iteration49-g10-quantile-reuse.md` | `194e90b6cb47625161ec8ca50e5adf6a8bae9e40d01d840c158ea0c4aebddd07` |

**Static result: GO on value and API semantics; request one small cache-lifetime cleanup before final acceptance.**

The cache key is conservative for the research call path: it includes the UTC timestamp, ordered asset-row codes derived from the panel universe, exact float64 bytes, and qcut configuration. Reuse is restricted to ordinary Series/MultiIndex float64 input, integer quantiles, no grouping, no zero-aware mode, and no bins. Unsupported inputs and key-construction failures fall back to qcut. Only complete successful int64 labels are retained; qcut errors and `no_raise` NaN results are not cached. Hits return a copy, so downstream mutation cannot alter retained labels. The cache is local to each factor or combination, with a 32 MiB/2,048-entry bound and bounded fallback after exhaustion.

The focused regression compares every `RESULT_TABLES` frame, dtype, status, evaluation ID, and result fingerprint between a context-disabled run and the cached run. Additional cases cover changed row masks, changed float bits, changed quantile configuration, context isolation, duplicate-edge failure, `no_raise` NaNs, and byte/entry limits. The author reports 4 focused tests passing and exact equality across the complete 12-table run; this reviewer did not rerun tests or benchmarks.

One lifetime issue remains: after the final factor/combination period loop, the function local still retains that context and its cache while stability rows, final tables, and fingerprints are assembled. Although bounded to one cache (at most 32 MiB), it is no longer needed. Recommendation sent to the author: delete the context immediately after each factor and combination period loop, preserving reuse within that loop while releasing memory before final output work. Awaiting Root's decision; no source changes made.

No Python/imports, tests, or benchmarks were run for this review.

## Final static recheck after cache-lifetime revision

The two `del quantile_reuse_context` statements are immediately after their
respective factor-period and combination-period loops. They preserve the
cache's full intended reuse window and release it before the following
stability, summary-table, and fingerprint work. The added weakref regression
creates two factor contexts and one combination context, then checks at the
first `fingerprint_value` call that all three have been collected and finalized.
There is no intervening fingerprint call before that point in
`evaluate_factor_research`. The test keeps only weak references, so it does
not itself extend context lifetime. Static inspection found no semantic or
scope issue with this correction.

**Final static result: GO.** This supersedes the earlier request for the
lifetime cleanup above. Final pins:

| File | SHA-256 |
|---|---|
| `fincore/factor_analysis/data.py` | `25f1b45c6d59d4d27a5dea318f415851312c26e6ae67147fbb8b21c7c11d6367` |
| `fincore/factor_analysis/research.py` | `bcd651c6b04eb1e8db0385331ae7e1e0955fd7020ccae716166a199c5c898fe7` |
| `tests/factor_analysis/test_research_period_quantile_reuse.py` | `dc0281edafc79c263dbdf0b888c6df73c39a8b3c9f1e1633d832334e20e568af` |
| `docs/plans/iteration49-g10-quantile-reuse.md` | `194e90b6cb47625161ec8ca50e5adf6a8bae9e40d01d840c158ea0c4aebddd07` |

The author reported focused QA passing before this static recheck; no QA,
Python process, or benchmark was run for the revised pins.

### Metadata correction

The test SHA-256 in the first version of the final pin table was transcribed
incorrectly. Re-reading the file and recomputing its hash confirms the value
shown above: `dc0281edafc79c263dbdf0b888c6df73c39a8b3c9f1e1633d832334e20e568af`
(9,725 bytes). This is a review-metadata correction only; no source, test, or
QA artifact changed, and QA was not rerun.
