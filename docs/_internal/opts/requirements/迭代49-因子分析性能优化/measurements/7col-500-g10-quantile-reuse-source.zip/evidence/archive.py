"""Archive completed G10 quantile-reuse pairs; never runs examples or QA."""

import hashlib
import io
import json
import statistics
import runpy
import zipfile
from pathlib import Path


ROOT = Path("D:/source_code/backtrader")
FC = Path("D:/source_code/fincore")
DEST = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements"
PAIR_HELPER = ROOT / ".codex-tmp/iteration49_next_pairs.py"
PAIR_HELPER_SHA256 = "541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb"
QA = FC / ".codex-tmp/iteration49-g10-source-qa-summary.json"
QA_PIN = {
    "size_bytes": 4500,
    "sha256": "ddf9e7ac123da5b50269cdb5b6c3bf7735064605100e4ecc9e675a04439d6569",
}
REVIEW = ROOT / ".codex-tmp/iteration49-g10-quantile-static-review.md"
REVIEW_PIN = {
    "size_bytes": 4412,
    "sha256": "59facb97dcfe4c6196d1bfbf29e56b2e0db4deb88dfe2849cdd33f032f8ea60a",
}
PAIR1_CONFIG = ROOT / ".codex-tmp/iteration49-g10-quantile-500-pair1-config.json"
PAIR23_CONFIG = ROOT / ".codex-tmp/iteration49-g10-quantile-500-pair23-config.json"
ALL_CONFIG = ROOT / ".codex-tmp/iteration49-g10-quantile-500-all-config.json"
EXAMPLES = ("025", "026", "027")
STEM = "7col-500-g10-quantile-reuse"


def pin(raw):
    return {"size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def read(path):
    return Path(path).read_bytes()


def json_file(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def shared_config(config):
    result = dict(config)
    result["pairs"] = []
    return result


def archive(files, note):
    rows = [{"path": name, **pin(raw)} for name, raw in sorted(files.items())]
    manifest = json.dumps(
        {"schema_version": 1, "note": note, "files": rows}, indent=2
    ).encode("utf-8") + b"\n"
    out = io.BytesIO()
    members = {
        **files,
        "MANIFEST.json": manifest,
        "README.txt": note.encode("utf-8") + b"\n",
    }
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    result = out.getvalue()
    with zipfile.ZipFile(io.BytesIO(result)) as z:
        for row in rows:
            assert pin(z.read(row["path"])) == {
                key: row[key] for key in ("size_bytes", "sha256")
            }
    return result, {
        **pin(result),
        "payload_count": len(rows),
        "manifest_sha256": pin(manifest)["sha256"],
    }


def qa_evidence(helpers, cfg):
    raw = read(QA)
    assert pin(raw) == QA_PIN
    qa = json.loads(raw.decode("utf-8"))
    assert (
        qa.get("schema_version"),
        qa.get("round"),
        qa.get("repository"),
        qa.get("branch"),
        qa.get("base_commit"),
        qa.get("status"),
    ) == (
        1,
        "iteration49-g10-quantile-reuse",
        str(FC),
        "dev",
        cfg["fincore_candidate"]["commit"],
        "SOURCE_QA_ONLY_UNCOMMITTED_PERFORMANCE_SCREEN_PENDING",
    )
    groups = qa.get("accepted_test_groups")
    assert isinstance(groups, dict) and set(groups) == {"initial_tests", "lifetime_fix"}
    initial, lifetime = groups["initial_tests"], groups["lifetime_fix"]
    assert (initial.get("unique_test_count"), initial.get("exit_code"), initial.get("result")) == (
        4,
        0,
        "4 passed",
    )
    assert (lifetime.get("unique_test_count"), lifetime.get("exit_code"), lifetime.get("result")) == (
        1,
        0,
        "1 passed",
    )
    assert lifetime.get("test") == "test_period_cache_contexts_are_released_before_result_fingerprinting"
    assert qa.get("unique_tests_covered_across_groups") == 5
    assert "no combined 5-test run" in qa.get("counting_note", "")

    candidate = cfg["fincore_candidate"]
    final_pins = {
        **candidate["allowed_delta"],
        **candidate["test_pins"],
    }
    qa_final_pins = lifetime.get("pins")
    assert isinstance(qa_final_pins, dict)
    assert set(qa_final_pins) == set(final_pins)
    log_payloads = {}
    log_metadata = {}
    for key, label in (
        ("initial_tests", "initial-4-pass"),
        ("lifetime_fix", "lifetime-1-pass"),
    ):
        log = groups[key].get("log")
        assert isinstance(log, dict) and set(("path", "bytes", "sha256")) <= set(log)
        path = helpers["checked"](FC, log["path"])
        contents = read(path)
        actual = pin(contents)
        expected = {"size_bytes": log["bytes"], "sha256": log["sha256"].lower()}
        assert actual == expected, (str(path), actual, expected)
        log_payloads[f"evidence/source-qa-{label}.log"] = contents
        log_metadata[key] = {"path": str(path), **actual}

    for name, expected in final_pins.items():
        assert qa_final_pins.get(name) == expected["sha256"].lower(), name
    pre_post_note = initial.get("pre_post_pin_evidence", "")
    assert "not separately saved as a file" in pre_post_note
    assert lifetime.get("pre_post_pin_evidence") == pre_post_note
    qa_summary = {
        "path": str(QA),
        **QA_PIN,
        "status": qa["status"],
        "accepted_test_groups": {
            key: {
                "unique_test_count": groups[key]["unique_test_count"],
                "exit_code": groups[key]["exit_code"],
                "result": groups[key]["result"],
                "source_pins": groups[key]["pins"],
                "log": log_metadata[key],
            }
            for key in ("initial_tests", "lifetime_fix")
        },
        "unique_tests_covered_across_groups": qa["unique_tests_covered_across_groups"],
        "combined_five_test_run_claimed": False,
        "pre_post_pin_evidence_separately_archived": False,
        "pre_post_pin_evidence_note": pre_post_note,
        "not_claimed": qa.get("not_claimed", []),
    }
    return qa, raw, qa_summary, log_payloads


def main():
    configs = {
        "pair1": (PAIR1_CONFIG, json_file(PAIR1_CONFIG)),
        "pair23": (PAIR23_CONFIG, json_file(PAIR23_CONFIG)),
        "all": (ALL_CONFIG, json_file(ALL_CONFIG)),
    }
    cfg1, cfg23, cfg_all = configs["pair1"][1], configs["pair23"][1], configs["all"][1]
    assert cfg1.get("pairs") == [1]
    assert cfg23.get("pairs") == [2, 3]
    assert cfg_all.get("pairs") == [1, 2, 3]
    assert shared_config(cfg1) == shared_config(cfg23) == shared_config(cfg_all)
    assert cfg_all.get("output_prefix") == "iteration49-g10-quantile-500"
    assert Path(cfg_all["output_root"]).resolve() == Path("D:/temp").resolve()
    assert "expected_engine" not in cfg_all and "expected_engines" not in cfg_all
    assert Path(cfg_all["workspace_root"]).resolve() == ROOT.resolve()
    bt_snapshot = cfg_all["backtrader_snapshot"]
    assert (bt_snapshot["mode"], bt_snapshot["commit"], bt_snapshot["manifest_sha256"]) == (
        "snapshot",
        "7b155ef2be2e2064b990060dcbfe09ce0c1f2a6f",
        "f18dad9076993f62c5cdc2e305fa20cd1a92fecd67583dbf27f457c258aa1e5f",
    )
    assert Path(bt_snapshot["root"]).resolve() == Path(
        "D:/temp/iteration49-g8-backtrader-7b155ef2"
    ).resolve()
    fa_baseline = cfg_all["fincore_baseline"]
    assert (fa_baseline["mode"], fa_baseline["commit"], fa_baseline["manifest_sha256"]) == (
        "snapshot",
        "4a8018105cf331969bb88cd26c47e158704a32e5",
        "92a8828fef31f5a546abeb419b4eef8cf25864a0a7d61a0e97a14812ce43e27f",
    )
    assert Path(fa_baseline["root"]).resolve() == Path(
        "D:/temp/iteration49-g9-fincore-4a80181"
    ).resolve()
    assert Path(cfg_all["fincore_candidate"]["root"]).resolve() == FC.resolve()
    assert cfg_all["fincore_candidate"]["branch"] == "dev"
    assert cfg_all["data"]["selection_sha256"] == (
        "14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc"
    )
    assert Path(cfg_all["data"]["root"]).resolve() == Path(
        "D:/source_code/backtrader/tests/datas/a_stocks"
    ).resolve()
    assert Path(cfg_all["data"]["selection"]).resolve() == Path(
        "D:/source_code/backtrader/docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json"
    ).resolve()
    config_raw = {name: read(path) for name, (path, _) in configs.items()}
    config_pins = {name: pin(raw) for name, raw in config_raw.items()}

    helper_raw = read(PAIR_HELPER)
    assert hashlib.sha256(helper_raw).hexdigest() == PAIR_HELPER_SHA256
    helpers = runpy.run_path(str(PAIR_HELPER), run_name="g10_quantile_archive_helpers")
    state = helpers["verified_sources"](ROOT, cfg_all)
    data = helpers["data_state"](cfg_all)
    helpers["check_data"](data)
    qa, qa_raw, qa_summary, qa_logs = qa_evidence(helpers, cfg_all)
    review_raw = read(REVIEW)
    assert pin(review_raw) == REVIEW_PIN

    output_root, prefix = Path(cfg_all["output_root"]), cfg_all["output_prefix"]
    records, verifiers, rawfiles = [], [], {}
    measurements = {example: {} for example in EXAMPLES}
    phase_measurements = {example: {} for example in EXAMPLES}
    for pair in (1, 2, 3):
        for example in EXAMPLES:
            measurements[example][pair] = {}
            phase_measurements[example][pair] = {}
            for arm in helpers["ORDERS"][pair - 1]:
                out = output_root / f"{prefix}-p{pair}-{arm}-{example}"
                result_path = out / "result.json"
                result = helpers["validate_run"](result_path, arm, example, cfg_all, state, data)
                values = {
                    "wall_s": result["example_main_wall_ns"] / 1e9,
                    "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                    "peak_bytes": max(
                        result["main_peak_working_set_bytes"],
                        result["resource_peak_tree_rss_bytes"],
                    ),
                }
                measurements[example][pair][arm] = values
                phase_timers = result["phase_timers"]
                assert isinstance(phase_timers, dict)
                phase_measurements[example][pair][arm] = phase_timers
                records.append(
                    {
                        "pair": pair,
                        "arm": arm,
                        "example": example,
                        "observed_engine": result.get("observed_engine"),
                        **values,
                        "phase_timers": result["phase_timers"],
                        "main_peak_working_set_bytes": result["main_peak_working_set_bytes"],
                        "resource_peak_tree_rss_bytes": result["resource_peak_tree_rss_bytes"],
                    }
                )
                rawfiles[f"raw/p{pair}/{arm}-{example}/result.json"] = read(result_path)
                rawfiles[f"raw/p{pair}/{arm}-{example}/run.log"] = read(out.with_suffix(".log"))

        verifier_path = output_root / f"{prefix}-p{pair}-verification.json"
        verifier = json_file(verifier_path)
        assert verifier.get("status") == "PASS" and verifier.get("scope_complete") is True
        assert verifier.get("valid") is True and verifier.get("mode") == "ab-pair"
        assert set(verifier.get("comparisons", {})) == set(EXAMPLES)
        assert all(row.get("valid") is True for row in verifier["comparisons"].values())
        for side, arm in (("baseline", "a"), ("candidate", "b")):
            for example in EXAMPLES:
                expected = output_root / f"{prefix}-p{pair}-{arm}-{example}" / "example"
                actual = Path(verifier["runs"][side][example]["directory"])
                assert actual.resolve() == expected.resolve()
        rawfiles[f"raw/p{pair}/verification.json"] = read(verifier_path)
        rawfiles[f"raw/p{pair}/verification.log"] = read(verifier_path.with_suffix(".log"))
        verifiers.append(
            {
                "pair": pair,
                "status": "PASS",
                "scope_complete": True,
                "path": str(verifier_path),
                **pin(rawfiles[f"raw/p{pair}/verification.json"]),
            }
        )

    assert len(records) == 18 and len(verifiers) == 3
    phase_fields = (
        "wall_inclusive_ns",
        "wall_exclusive_ns",
        "process_cpu_inclusive_ns",
        "process_cpu_exclusive_ns",
    )
    metrics = {}
    for example, by_pair in measurements.items():
        metrics[example] = {}
        for key in ("wall_s", "cpu_s", "peak_bytes"):
            ratios = [by_pair[pair]["b"][key] / by_pair[pair]["a"][key] for pair in (1, 2, 3)]
            gains = [1 / ratio for ratio in ratios]
            median_ratio = statistics.median(ratios)
            metrics[example][key] = {
                "a_median": statistics.median(by_pair[pair]["a"][key] for pair in (1, 2, 3)),
                "b_median": statistics.median(by_pair[pair]["b"][key] for pair in (1, 2, 3)),
                "paired_b_over_a": ratios,
                "median_b_over_a": median_ratio,
                "reduction_percent": 100 * (1 - median_ratio),
                "paired_a_over_b": gains,
                "relative_dispersion": (max(gains) - min(gains)) / statistics.median(gains),
                "within_5pct_relative_dispersion": (
                    (max(gains) - min(gains)) / statistics.median(gains) <= 0.05
                ),
            }

        phase_metrics = {}
        labels = {
            label
            for pair in (1, 2, 3)
            for arm in ("a", "b")
            for label in phase_measurements[example][pair][arm]
        }
        for label in sorted(labels):
            phase_metrics[label] = {}
            for field in phase_fields:
                paired = []
                missing = []
                zero_duration = False
                for pair in (1, 2, 3):
                    arow = phase_measurements[example][pair]["a"].get(label)
                    brow = phase_measurements[example][pair]["b"].get(label)
                    if arow is None or brow is None:
                        missing.append({
                            "pair": pair,
                            "missing_arms": [
                                arm for arm, row in (("a", arow), ("b", brow)) if row is None
                            ],
                        })
                        continue
                    avalue, bvalue = arow.get(field), brow.get(field)
                    assert type(avalue) is int and avalue >= 0
                    assert type(bvalue) is int and bvalue >= 0
                    if avalue == 0 or bvalue == 0:
                        zero_duration = True
                    paired.append({"pair": pair, "a": avalue, "b": bvalue})
                if missing or zero_duration:
                    phase_metrics[label][field] = {
                        "status": "incomplete_or_zero_duration",
                        "missing": missing,
                        "paired_ns": paired,
                        "ratios": None,
                    }
                    continue
                ratios = [row["b"] / row["a"] for row in paired]
                gains = [row["a"] / row["b"] for row in paired]
                median_ratio = statistics.median(ratios)
                dispersion = (max(gains) - min(gains)) / statistics.median(gains)
                phase_metrics[label][field] = {
                    "status": "complete",
                    "paired_ns": paired,
                    "median_a_ns": statistics.median(row["a"] for row in paired),
                    "median_b_ns": statistics.median(row["b"] for row in paired),
                    "paired_b_over_a": ratios,
                    "median_b_over_a": median_ratio,
                    "reduction_percent": 100 * (1 - median_ratio),
                    "relative_dispersion_a_over_b": dispersion,
                    "within_5pct_relative_dispersion": dispersion <= 0.05,
                }
        metrics[example]["phase_timers"] = phase_metrics

    sourcefiles = {
        "evidence/next_pairs.py": helper_raw,
        "evidence/archive.py": read(__file__),
        "evidence/source-qa-summary.json": qa_raw,
        "evidence/static-review.md": review_raw,
        **qa_logs,
    }
    for name, (path, _) in configs.items():
        sourcefiles[f"evidence/config-{name}.json"] = config_raw[name]
    for name in cfg_all["tool_pins"]:
        sourcefiles[name] = read(ROOT / name)
    fc_root = Path(cfg_all["fincore_candidate"]["root"])
    for key in ("backtrader_snapshot", "fincore_baseline"):
        sourcefiles[f"{key}/.iteration49-source.json"] = read(
            Path(cfg_all[key]["root"]) / ".iteration49-source.json"
        )
    for name, expected in cfg_all["fincore_candidate"]["allowed_delta"].items():
        baseline = read(state[2] / name)
        candidate = read(helpers["checked"](fc_root, name))
        assert pin(baseline) == state[3]["files"][name]
        assert pin(candidate) == expected
        sourcefiles[f"fincore/baseline/{name}"] = baseline
        sourcefiles[f"fincore/candidate/{name}"] = candidate
    for name, expected in cfg_all["fincore_candidate"]["test_pins"].items():
        candidate = read(helpers["checked"](fc_root, name))
        assert pin(candidate) == expected
        sourcefiles[f"fincore/candidate/{name}"] = candidate

    raw, rawmeta = archive(
        rawfiles, "G10 fixed-500 raw run results, logs and complete output verifiers."
    )
    source, srcmeta = archive(
        sourcefiles,
        "G10 quantile-reuse source delta, accepted source-QA groups, static review, tools, and configs; not full-universe acceptance.",
    )
    rawmeta["path"], srcmeta["path"] = STEM + "-raw.zip", STEM + "-source.zip"
    source_qa = {
        **qa_summary,
        "groups_counted_separately": True,
        "known_warnings": {
            key: group["known_warning"]
            for key, group in qa["accepted_test_groups"].items()
        },
    }
    summary = {
        "schema": "iteration49.g10-quantile-reuse-paired-measurement.v1",
        "status": "PASS_OUTPUT_EQUIVALENCE_MEASUREMENT_ONLY",
        "counts": {
            "measured_processes": len(records),
            "unique_comparisons": 9,
            "complete_verifiers": len(verifiers),
        },
        "config": cfg_all,
        "execution_configs": {
            name: {"path": str(configs[name][0]), **config_pins[name]}
            for name in ("pair1", "pair23", "all")
        },
        "fixed_data_identity": data[2],
        "actual_runs": records,
        "verifiers": verifiers,
        "metrics": metrics,
        "source_qa": source_qa,
        "static_review": {"path": str(REVIEW), **REVIEW_PIN},
        "raw_archive": rawmeta,
        "measured_source_archive": srcmeta,
        "limitations": [
            "Source QA consists of a four-test file run and a separate one-test lifetime run; there was no combined five-test run.",
            "Source-QA pre/post pins were printed in the original tool output but were not separately saved as a file.",
            "Fixed-500 measurements do not establish 5471-symbol speed or process-tree memory targets.",
            "observed_engine is recorded from each result; no engine is forced or required by this screen.",
            "Peak is max(main working-set high-water, sampled process-tree RSS).",
            "Phase timers may include overlapping inclusive values; do not sum inclusive timers.",
        ],
    }
    outputs = {
        rawmeta["path"]: raw,
        srcmeta["path"]: source,
        STEM + "-pairs.json": json.dumps(summary, indent=2, ensure_ascii=False).encode("utf-8") + b"\n",
    }

    assert helpers["verified_sources"](ROOT, cfg_all) == state
    helpers["check_data"](data)
    assert all(pin(read(path)) == config_pins[name] for name, (path, _) in configs.items())
    assert pin(read(QA)) == QA_PIN and pin(read(REVIEW)) == REVIEW_PIN
    for group in qa["accepted_test_groups"].values():
        log = group["log"]
        assert pin(read(helpers["checked"](FC, log["path"]))) == {
            "size_bytes": log["bytes"],
            "sha256": log["sha256"].lower(),
        }
    assert all(not (DEST / name).exists() for name in outputs)
    for name, content in outputs.items():
        with (DEST / name).open("xb") as stream:
            stream.write(content)
    print(json.dumps({"metrics": metrics, "archives": [rawmeta, srcmeta]}, indent=2))


if __name__ == "__main__":
    main()
