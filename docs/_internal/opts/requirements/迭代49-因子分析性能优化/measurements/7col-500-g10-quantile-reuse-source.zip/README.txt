G10 quantile-reuse source delta, accepted source-QA groups, static review, tools, and configs; not full-universe acceptance.
