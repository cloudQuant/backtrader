"""Archive completed next_pairs runs and measured source, without rerunning work."""
import hashlib
import io
import json
import runpy
import statistics
import sys
import zipfile
from pathlib import Path

ROOT=Path('D:/source_code/backtrader')
DEST=ROOT/'docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements'
HELPER=ROOT/'.codex-tmp/iteration49_next_pairs.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest()=='541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb'
cfgpath, qa_path, label = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
cfg=json.loads(cfgpath.read_text(encoding='utf-8'))
f=runpy.run_path(str(HELPER),run_name='paired_summary_helpers')
state=f['verified_sources'](ROOT,cfg)
data=f['data_state'](cfg)
f['check_data'](data)
prefix=cfg['output_prefix']
temp=Path(cfg['output_root'])
def pin(raw): return {'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def packed(files,note):
    rows=[{'path':name,**pin(raw)} for name,raw in sorted(files.items())]
    manifest=json.dumps({'schema_version':1,'note':note,'files':rows},indent=2).encode()+b'\n'
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted({**files,'MANIFEST.json':manifest,'README.txt':note.encode()+b'\n'}.items()):
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
            z.writestr(info,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    result=out.getvalue()
    with zipfile.ZipFile(io.BytesIO(result)) as z:
        for row in rows: assert pin(z.read(row['path']))=={k:row[k] for k in ['size_bytes','sha256']}
    return result,{**pin(result),'payload_count':len(rows),'manifest_sha256':pin(manifest)['sha256']}

records, verifiers, rawfiles = [],[],{}
examples={ex:{} for ex in f['EXAMPLES']}
for p in cfg['pairs']:
    for ex in f['EXAMPLES']:
        examples[ex][p]={}
        for arm in f['ORDERS'][p-1]:
            out=temp/f'{prefix}-p{p}-{arm}-{ex}'
            result=f['validate_run'](out/'result.json',arm,ex,cfg,state,data)
            m={'wall_s':result['example_main_wall_ns']/1e9,'cpu_s':result['example_main_process_cpu_ns']/1e9,
               'peak_bytes':max(result['main_peak_working_set_bytes'],result['resource_peak_tree_rss_bytes'])}
            examples[ex][p][arm]=m
            records.append({'pair':p,'arm':arm,'example':ex,**m,'phase_timers':result['phase_timers'],
                'main_peak_working_set_bytes':result['main_peak_working_set_bytes'],
                'resource_peak_tree_rss_bytes':result['resource_peak_tree_rss_bytes']})
            rawfiles[f'raw/p{p}/{arm}-{ex}/result.json']=(out/'result.json').read_bytes()
            rawfiles[f'raw/p{p}/{arm}-{ex}/run.log']=out.with_suffix('.log').read_bytes()
    vpath=temp/f'{prefix}-p{p}-verification.json'
    v=json.loads(vpath.read_text())
    assert v['status']=='PASS' and v['scope_complete'] and v['valid'] and v['mode']=='ab-pair'
    assert set(v['comparisons'])==set(f['EXAMPLES']) and all(row['valid'] for row in v['comparisons'].values())
    for side,arm in [('baseline','a'),('candidate','b')]:
        for ex in f['EXAMPLES']:
            assert Path(v['runs'][side][ex]['directory']).resolve()==(temp/f'{prefix}-p{p}-{arm}-{ex}'/'example').resolve()
    rawfiles[f'raw/p{p}/verification.json']=vpath.read_bytes()
    rawfiles[f'raw/p{p}/verification.log']=vpath.with_suffix('.log').read_bytes()
    verifiers.append({'pair':p,'status':'PASS','scope_complete':True,'path':str(vpath),**pin(vpath.read_bytes())})
metrics={}
for ex,pairs in examples.items():
    metrics[ex]={}
    for name in ['wall_s','cpu_s','peak_bytes']:
        ratios=[pair['b'][name]/pair['a'][name] for pair in pairs.values()]
        mid=statistics.median(ratios)
        metrics[ex][name]={'a_median':statistics.median(pair['a'][name] for pair in pairs.values()),
                         'b_median':statistics.median(pair['b'][name] for pair in pairs.values()),
                         'paired_b_over_a':ratios,'reduction_percent':100*(1-mid),
                         'relative_dispersion':(max(ratios)-min(ratios))/mid if len(ratios)>1 else None}
sourcefiles={'evidence/next_pairs.py':HELPER.read_bytes(),'evidence/config.json':cfgpath.read_bytes(),
             'evidence/source-qa.json':qa_path.read_bytes(),'evidence/archive.py':Path(__file__).read_bytes()}
for name in cfg['tool_pins']: sourcefiles[name]=(ROOT/name).read_bytes()
for key in ['backtrader_snapshot','fincore_baseline']:
    sourcefiles[key+'/.iteration49-source.json']=(Path(cfg[key]['root'])/'.iteration49-source.json').read_bytes()
fc=Path(cfg['fincore_candidate']['root'])
for name in cfg['fincore_candidate'].get('allowed_delta',{}):
    sourcefiles['fincore/baseline/'+name]=(state[2]/name).read_bytes()
    sourcefiles['fincore/candidate/'+name]=(fc/name).read_bytes()
for name in cfg['fincore_candidate'].get('test_pins',{}): sourcefiles['qa-input/'+name]=(fc/name).read_bytes()
raw,rawmeta=packed(rawfiles,'Actual fixed500 complete example runs and full output verifiers; no replayed runs.')
src,srcmeta=packed(sourcefiles,'Measured source delta, inherited snapshot manifests, exact runner/config and source QA. Not full-universe acceptance.')
rawmeta['path']=label+'-raw.zip'; srcmeta['path']=label+'-measured-source.zip'
summary={'schema':'iteration49.next-pairs.v1','status':'PASS_OUTPUT_EQUIVALENCE_MEASUREMENT_ONLY',
         'counts':{'measured_processes':len(records),'unique_comparisons':3*len(cfg['pairs']),'verifiers':len(verifiers)},
         'sources':cfg,'fixed_data_identity':data[2],'actual_runs':records,'verifiers':verifiers,'metrics':metrics,
         'raw_archive':rawmeta,'measured_source_archive':srcmeta,
         'limitations':['Single pairs establish an output/nonregression screen, not stable speed.','Final5471/80%/1GB remains pending.',
                        'Peak=max(OS main working-set high-water, 0.5-second sampled process-tree RSS). Inclusive phase timers overlap.']}
for name,content in [(rawmeta['path'],raw),(srcmeta['path'],src),(label+'-pairs.json',json.dumps(summary,indent=2).encode()+b'\n')]:
    with (DEST/name).open('xb') as stream: stream.write(content)
print(json.dumps({'metrics':metrics,'raw_archive':rawmeta,'measured_source_archive':srcmeta},indent=2))
