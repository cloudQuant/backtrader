"""Serial full-output G2c pairs; later pairs reuse the unchanged 027 control."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('D:/source_code/backtrader')
TEMP = Path('D:/temp')
BASE = TEMP / 'iteration49-g3-backtrader-b4c965bbd'
FC = TEMP / 'iteration49-g2b-fincore-41cf7c9'
HEAD = '1293d02eff98b7839bca3b195ef7f85f0a7350ce'
PINS = {
    'backtrader/research/factor_indicator.py': '2aa5e813de354a9ecd8c8589d7d89e5215661f9dd9dc062e6966767d99083fd8',
    'backtrader/research/factor_strategy.py': 'a4b9cd1c3c8e4e56fbb25b2515d3ade203d9381ea85b940cb4c9019222c1ba8a',
    'examples/backtest/025_factor_single/close_ma_factor_strategy.py': '7ab8c4262bb85262e24310f254ac82045c45fe4dfe6f8757ecb5122f897f4997',
    'examples/backtest/026_factor_multi/multi_factor_strategy.py': 'ad0d3a584abe47d1bd75839ffd3c7f167759c05584a0d67adeaf977b2a5da259',
    'scripts/benchmark_factor_examples.py': 'a971ca097236c6ffbaf85f5291bf58e47022d1f452c861e810bc3b8190a2ea0a',
    'scripts/verify_factor_examples_benchmark.py': '10f27eda6f24ecca88142cbd978d9b1eb9cfedfad604bd96d289008cf59a23e7',
}
DAILY = 'examples/backtest/027_alpha003_panel_acceptance/run_daily.py'
MANIFESTS = {
    BASE: 'cc34df388dd9ece34408cbbc278a957bdc15055689019e491d71929316c57725',
    FC: 'b4fc1021cb81d4f54d1e4d597dd885aa510e9861baa65b0cd6e207a02c388e8c',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def check_sources():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == HEAD
    assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).strip() == b'dev'
    for name, pin in PINS.items():
        assert digest(ROOT / name) == pin, name
    for root, pin in MANIFESTS.items():
        assert digest(root / '.iteration49-source.json') == pin
    manifest = read(BASE / '.iteration49-source.json')
    changed = []
    for name, item in manifest['files'].items():
        assert digest(BASE / name) == item['sha256'], name
        if (BASE / name).read_bytes().replace(b'\r\n', b'\n') != (ROOT / name).read_bytes().replace(b'\r\n', b'\n'):
            changed.append(name)
    assert set(changed) == set(list(PINS)[:4]) | {DAILY}, changed
    assert digest(ROOT / DAILY) == '206f13a98d7e153bd0cd6f5d42d38470fb7566788104b957af87614be5999220'

def output(pair, arm, example):
    return TEMP / f'iteration49-7col-g2c-p{pair}-{arm}-{example}'

def execute(args, log):
    with log.open('xb') as stream:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))

def validate(path, arm, example):
    r = read(path / 'result.json')
    assert r['status'] == 'COMPLETED' and r['runner_exit_code'] == r['example_exit_code'] == 0
    assert r['example'] == example and r['profile'] == 'full'
    assert not r['source_or_input_changes'] and not r['summary_check_errors']
    for key in ('backtrader_source', 'fincore_source', 'data_identity'):
        assert r[key + '_before'] == r[key + '_after']
    assert r['backtrader_source_before']['commit'] == (HEAD if arm == 'b' else 'b4c965bbd52438c43d941629742457702215c0e6')
    assert r['fincore_source_before']['manifest_sha256'] == MANIFESTS[FC]
    s = r['summary']
    assert (s['symbols'], s['dates'], s['factor_mode'], s['factor_calculation']) == (500, 243, 'native', 'RAN')
    return r

def main():
    pairs = tuple(map(int, sys.argv[1:]))
    assert pairs and len(pairs) == len(set(pairs)) and all(p in (1, 2, 3) for p in pairs)
    check_sources()
    for pair in pairs:
        if pair > 1:
            v = read(TEMP / 'iteration49-7col-g2c-p1-verification.json')
            assert v['status'] == 'PASS' and v['scope_complete']
        for example in (('025', '026', '027') if pair == 1 else ('025', '026')):
            for arm in (('a', 'b') if pair % 2 else ('b', 'a')):
                check_sources()
                dest = output(pair, arm, example)
                assert not dest.exists()
                print(f'START G2c {pair} {arm} {example}', flush=True)
                execute(['scripts/benchmark_factor_examples.py', '--source-root', str(BASE if arm == 'a' else ROOT), '--fincore-root', str(FC), '--data-root', str(ROOT / 'tests/datas/a_stocks'), '--example', example, '--profile', 'full', '--output', str(dest)], dest.with_suffix('.log'))
                r = validate(dest, arm, example)
                print(json.dumps({'pair': pair, 'arm': arm, 'example': example, 'wall_s': r['example_main_wall_ns'] / 1e9, 'cpu_s': r['example_main_process_cpu_ns'] / 1e9, 'peak_bytes': max(r['main_peak_working_set_bytes'], r['resource_peak_tree_rss_bytes'])}), flush=True)
                check_sources()
        verification = TEMP / f'iteration49-7col-g2c-p{pair}-verification.json'
        assert not verification.exists()
        args = ['scripts/verify_factor_examples_benchmark.py', '--output', str(verification)]
        for arm, flag in (('a', '--baseline'), ('b', '--candidate')):
            for example in ('025', '026', '027'):
                dest = output(1 if example == '027' else pair, arm, example)
                validate(dest, arm, example)
                args.extend((flag, f'{example}={dest}'))
        execute(args, verification.with_suffix('.log'))
        v = read(verification)
        assert v['status'] == 'PASS' and v['scope_complete']
        print(f'G2c PAIR {pair} COMPLETE OUTPUT PASS; 027 control from pair1', flush=True)

if __name__ == '__main__':
    main()
