# Iteration 49 G8: preallocated positions output

This round removes repeated label-based writes from positions for the
float64 input path. The output index and columns are still built with the same
pandas operations. The loop retains the existing trade admission, single-pop
expiry lifecycle, concat, row sum, gross calculation, division, and final
fillna(0.0). The preallocated output buffer is used only when the unstacked
object is exactly a base pandas DataFrame and every column has exact NumPy
float64 dtype. Series inputs whose unstack operation returns a DataFrame
subclass, and all other dtypes, retain the original zero-filled DataFrame and
label-based assignment to preserve pandas subclass dispatch, coercion, and
failure behavior.

The regression test contains an independent copy of the prior positions body
as an oracle. It checks exact frame values and float64 bit patterns for sparse
UTC weights with NaNs, signed and ordinary zeros, overlapping trades,
expiry-boundary trades, a custom holiday calendar, and an intraday holding
remainder. Separate cases cover the default-calendar warning, duplicate
date/asset rejection, and non-float64 dtype fallback. The oracle defaults to
BDay, matching the old production fallback. Its Friday case confirms expiry
on Monday and absence of the Saturday row. A Series subclass whose unstack
returns a DataFrame subclass is compared to the oracle while a NumPy allocation
guard proves that the subclass takes the legacy output path.

The initial focused run passed 20 tests in 6.38 seconds. After static review,
the default-calendar oracle and subclass boundary were corrected; the two
affected tests then passed in a separate 4.015-second run. The final unique
coverage is 21 cases across these two successful runs: the 19 unaffected
initial cases, the corrected Friday/BDay case, and the new subclass fallback
case. This was not a single 21-test run. One intermediate two-test attempt
failed because the Friday date assertions were accidentally placed in the
subclass test; the fixture assertion was corrected and its failed output was
preserved. The QA record retains both successful runs and that failed edit
attempt.

No performance result is claimed in this source round. Root will run the
serial fixed-500 full-output A/B acceptance separately.

## Scope

- fincore/factor_analysis/portfolio.py
- tests/factor_analysis/test_factor_analysis_positions_buffer.py
- this round record

## Focused validation

Initial full focused command:

    C:/anaconda3/python.exe -m pytest -p no:asyncio -q tests/factor_analysis/test_factor_analysis_positions_buffer.py tests/factor_analysis/test_factor_analysis_reuse_contracts.py tests/performance/test_hotspot_regressions.py

It exited zero with 20 tests passing in 6.38 seconds. The stdout text was
preserved from the original tool output at
D:/source_code/backtrader/.codex-tmp/iteration49-g8-initial20-stdout.txt and
is explicitly marked as a transcription because the original tool output
was not saved to a file. The Hypothesis plugin warned that it skipped the
.hypothesis directory due to the configured norecursedirs option. The custom
calendar PerformanceWarning was captured and checked for parity in the oracle
test.

Static-review repair command:

    C:/anaconda3/python.exe -m pytest -p no:asyncio -q tests/factor_analysis/test_factor_analysis_positions_buffer.py::test_default_calendar_warning_and_positions_match_legacy tests/factor_analysis/test_factor_analysis_positions_buffer.py::test_dataframe_subclass_uses_legacy_output_path

It exited zero with both tests passing in 4.015 seconds. Its captured stdout is
D:/source_code/backtrader/.codex-tmp/iteration49-g8-repair-focused-stdout.txt.
The failed intermediate attempt is preserved separately. Both records and
their pins are listed in
D:/source_code/backtrader/.codex-tmp/iteration49-g8-source-qa.json.

Ruff passed for the new test and for both changed Python files with the
existing UP037 annotation findings excluded. A full Ruff check of
portfolio.py reports four unchanged UP037 findings in existing quoted
annotations. git diff --check passed.

No benchmark was run and no commit was made.