"""Exact regression contracts for the float64 positions output buffer."""

from __future__ import annotations

import warnings
from decimal import Decimal
from typing import Any

import numpy as np
import pandas as pd
import pytest
from pandas.tseries.offsets import BDay, CustomBusinessDay, Day

from fincore.factor_analysis import portfolio
from fincore.factor_analysis.calendar import add_custom_calendar_timedelta


def _legacy_positions(
    weights: pd.Series, period: pd.Timedelta | object, freq: Any = None
) -> pd.DataFrame:
    """Independent copy of the pre-buffer positions algorithm."""

    if not isinstance(weights, pd.Series):
        raise TypeError("weights must be a pandas Series")
    if not isinstance(weights.index, pd.MultiIndex) or weights.index.nlevels != 2:
        raise ValueError("weights must use a two-level (date, asset) MultiIndex")
    copied = weights.copy(deep=True)
    copied.index = copied.index.set_names(("date", "asset"))
    weights_frame = copied.unstack()
    holding_period = period if isinstance(period, pd.Timedelta) else pd.Timedelta(period)
    if not isinstance(weights_frame.index, pd.DatetimeIndex):
        raise ValueError("weights date level must be a DatetimeIndex")
    calendar = freq if freq is not None else weights_frame.index.freq
    if calendar is None:
        calendar = BDay()
        warnings.warn("'freq' not set, using business day calendar", UserWarning, stacklevel=2)

    trades_index = weights_frame.index.copy()
    return_index = add_custom_calendar_timedelta(trades_index, holding_period, calendar)
    position_index = trades_index.union(return_index)
    result = pd.DataFrame(0.0, index=position_index, columns=weights_frame.columns, dtype=float)
    active: list[tuple[pd.Timestamp, pd.Series]] = []

    for timestamp in position_index:
        if timestamp in weights_frame.index:
            assets_weights = weights_frame.loc[timestamp].copy(deep=True)
            if not isinstance(assets_weights, pd.Series):
                raise ValueError("weights must contain at most one row per date and asset")
            expires_at = add_custom_calendar_timedelta(timestamp, holding_period, calendar)
            active.append((expires_at, assets_weights))

        if active and active[0][0] <= timestamp:
            active.pop(0)
        if not active:
            continue

        total = pd.concat([entry[1] for entry in active], axis=1).sum(axis=1)
        gross = total.abs().sum()
        if gross != 0 and not pd.isna(gross):
            result.loc[timestamp, total.index] = total / gross

    return result.fillna(0.0)


def _assert_exact_frame(actual: pd.DataFrame, expected: pd.DataFrame) -> None:
    pd.testing.assert_frame_equal(actual, expected, check_exact=True)
    assert actual.index.equals(expected.index)
    assert actual.columns.equals(expected.columns)
    assert actual.dtypes.equals(expected.dtypes)
    actual_bits = np.ascontiguousarray(actual.to_numpy(dtype=np.float64, copy=True)).view(np.uint64)
    expected_bits = np.ascontiguousarray(expected.to_numpy(dtype=np.float64, copy=True)).view(np.uint64)
    np.testing.assert_array_equal(actual_bits, expected_bits)


def _sparse_utc_weights() -> tuple[pd.Series, CustomBusinessDay, pd.DatetimeIndex]:
    dates = pd.DatetimeIndex(
        (
            "2024-01-04 10:00:00+00:00",
            "2024-01-05 11:00:00+00:00",
            "2024-01-05 13:00:00+00:00",
            "2024-01-09 14:00:00+00:00",
            "2024-01-09 16:00:00+00:00",
        ),
        name="source_time",
    )
    rows = (
        (dates[0], "A", 1.0),
        (dates[0], "Z", -0.0),
        (dates[1], "A", -1.0),
        (dates[2], "A", 1.0),
        (dates[2], "Z", np.nan),
        (dates[3], "A", 2.0),
        (dates[3], "M", -3.0),
        (dates[4], "A", -0.0),
        (dates[4], "M", 1.0),
        (dates[4], "Z", 0.0),
    )
    index = pd.MultiIndex.from_tuples(
        [(date, asset) for date, asset, _ in rows],
        names=("date", "asset"),
    )
    weights = pd.Series([value for _, _, value in rows], index=index, dtype=np.float64, name="weight")
    calendar = CustomBusinessDay(holidays=("2024-01-08",))
    return weights, calendar, dates


def test_float64_output_buffer_matches_legacy_for_sparse_utc_positions() -> None:
    weights, calendar, trade_dates = _sparse_utc_weights()
    period = pd.Timedelta("1D3h")

    with pytest.warns(pd.errors.PerformanceWarning) as expected_warnings:
        expected = _legacy_positions(weights, period, calendar)
    with pytest.warns(pd.errors.PerformanceWarning) as actual_warnings:
        actual = portfolio.positions(weights, period, calendar)

    assert [(item.category, str(item.message)) for item in actual_warnings] == [
        (item.category, str(item.message)) for item in expected_warnings
    ]
    _assert_exact_frame(actual, expected)
    assert actual.columns.tolist() == ["A", "M", "Z"]
    assert (actual.loc[trade_dates[1]].to_numpy() == 0.0).all()
    assert (actual.loc[trade_dates[2]].to_numpy() == 0.0).all()
    assert pd.Timestamp("2024-01-09 14:00:00+00:00") in actual.index
    assert pd.Timestamp("2024-01-10 17:00:00+00:00") in actual.index
    assert pd.Timestamp("2024-01-10 19:00:00+00:00") in actual.index
    assert (actual.loc[pd.Timestamp("2024-01-10 19:00:00+00:00")].to_numpy() == 0.0).all()


def _capture_outcome(callable_: Any, weights: pd.Series) -> tuple[Any, tuple[tuple[type[Warning], str], ...]]:
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        try:
            value = callable_(weights, pd.Timedelta("1D"), Day())
        except (TypeError, ValueError, ArithmeticError) as error:
            value = (type(error), str(error))
        warning_facts = tuple((item.category, str(item.message)) for item in captured)
    return value, warning_facts


@pytest.mark.parametrize(
    "values",
    (
        (Decimal("1.25"), Decimal("-0.5")),
        (1.0 + 2.0j, -3.0 + 0.5j),
        (1.25, pd.NA),
    ),
    ids=("decimal-object", "complex128", "nullable-float"),
)
def test_non_float64_dtypes_keep_legacy_output_and_errors(values: tuple[Any, Any]) -> None:
    dtype: Any = "Float64" if values[1] is pd.NA else None
    date0 = pd.Timestamp("2024-02-01 10:00:00+00:00")
    date1 = pd.Timestamp("2024-02-02 10:00:00+00:00")
    index = pd.MultiIndex.from_tuples(((date0, "B"), (date1, "A")), names=("date", "asset"))
    weights = pd.Series(values, index=index, dtype=dtype, name="weight")

    expected, expected_warnings = _capture_outcome(_legacy_positions, weights)
    actual, actual_warnings = _capture_outcome(portfolio.positions, weights)

    assert actual_warnings == expected_warnings
    if isinstance(expected, tuple) and len(expected) == 2 and isinstance(expected[0], type):
        assert isinstance(actual, tuple)
        assert actual == expected
    else:
        assert isinstance(expected, pd.DataFrame)
        assert isinstance(actual, pd.DataFrame)
        pd.testing.assert_frame_equal(actual, expected, check_exact=True)
        assert actual.dtypes.equals(expected.dtypes)
        if all(dtype == np.dtype("float64") for dtype in expected.dtypes):
            _assert_exact_frame(actual, expected)


def test_default_calendar_warning_and_positions_match_legacy() -> None:
    date = pd.Timestamp("2024-02-02 10:00:00+00:00")
    index = pd.MultiIndex.from_tuples(((date, "B"), (date, "A")), names=("date", "asset"))
    weights = pd.Series((1.0, -1.0), index=index, dtype=np.float64)

    with pytest.warns(UserWarning, match="'freq' not set, using business day calendar"):
        expected = _legacy_positions(weights, "1D")
    with pytest.warns(UserWarning, match="'freq' not set, using business day calendar"):
        actual = portfolio.positions(weights, "1D")

    _assert_exact_frame(actual, expected)
    assert pd.Timestamp("2024-02-05 10:00:00+00:00") in actual.index
    assert pd.Timestamp("2024-02-03 10:00:00+00:00") not in actual.index


class _WeightsFrameSubclass(pd.DataFrame):
    @property
    def _constructor(self) -> type[_WeightsFrameSubclass]:
        return _WeightsFrameSubclass


class _WeightsSeriesSubclass(pd.Series):
    @property
    def _constructor(self) -> type[_WeightsSeriesSubclass]:
        return _WeightsSeriesSubclass

    @property
    def _constructor_expanddim(self) -> type[_WeightsFrameSubclass]:
        return _WeightsFrameSubclass


def test_dataframe_subclass_uses_legacy_output_path(monkeypatch: pytest.MonkeyPatch) -> None:
    date0 = pd.Timestamp("2024-03-01 10:00:00+00:00")
    date1 = pd.Timestamp("2024-03-04 10:00:00+00:00")
    index = pd.MultiIndex.from_tuples(
        ((date0, "B"), (date0, "A"), (date1, "B"), (date1, "A")),
        names=("date", "asset"),
    )
    weights = _WeightsSeriesSubclass((0.25, -0.75, -0.5, 0.5), index=index, dtype=np.float64)
    expected = _legacy_positions(weights, "1D", Day())
    weights_frame = weights.copy(deep=True).unstack()
    assert type(weights_frame) is _WeightsFrameSubclass

    class _NumpyBufferGuard:
        dtype = np.dtype

        @staticmethod
        def zeros(*args: Any, **kwargs: Any) -> np.ndarray:
            raise AssertionError("DataFrame subclasses must keep the legacy output path")

    monkeypatch.setattr(portfolio, "np", _NumpyBufferGuard)
    actual = portfolio.positions(weights, "1D", Day())

    _assert_exact_frame(actual, expected)


def test_duplicate_date_asset_pairs_keep_legacy_failure() -> None:
    date = pd.Timestamp("2024-02-02 10:00:00+00:00")
    index = pd.MultiIndex.from_tuples(
        ((date, "A"), (date, "A")),
        names=("date", "asset"),
    )
    weights = pd.Series((1.0, 2.0), index=index, dtype=np.float64)

    with pytest.raises(ValueError) as expected:
        _legacy_positions(weights, "1D", Day())
    with pytest.raises(ValueError) as actual:
        portfolio.positions(weights, "1D", Day())

    assert type(actual.value) is type(expected.value)
    assert str(actual.value) == str(expected.value)