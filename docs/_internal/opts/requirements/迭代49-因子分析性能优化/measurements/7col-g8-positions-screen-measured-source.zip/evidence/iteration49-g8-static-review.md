# Iteration 49 G8 static review

**Decision: HOLD.** Reviewed Fincore `dev` HEAD `4e01ac9f6f081f13acd60b45559119e1a5ed4a4f`, without running Python, tests, or benchmarks. The reviewed source pin is `fincore/factor_analysis/portfolio.py` SHA-256 `5a86624b5a08421e2fb30d1ed96f5477e70b141fd7a21138724a782bd7d7ee82`; test pin is `tests/factor_analysis/test_factor_analysis_positions_buffer.py` `eea9cc1cec759f10ae417c28c82c00a8d3544376b38cd61ca25eab908ff083b6`.

For ordinary base pandas frames with NumPy float64 columns, the implementation keeps the existing trade admission, expiry/pop order, aggregation, normalization, index/column construction, and final `fillna(0.0)`. The buffer rows follow `position_index` enumeration and the test compares frame metadata plus float64 bit patterns. Non-float64 columns retain the prior DataFrame-plus-`.loc` path; the Decimal, complex, and nullable `Float64` cases exercise that fallback against a copied pre-change oracle.

Two issues need correction before the performance run:

1. `use_float64_buffer` is gated only on dtypes. `_require_weight_series` accepts `pd.Series` subclasses, and a subclass can make `unstack()` return a custom DataFrame through pandas' constructor hook. Such a frame can customize row/label behavior that the direct ndarray write bypasses. Restrict the fast path to `type(weights_frame) is pd.DataFrame` as well as NumPy float64 dtypes; let subclasses use the legacy path.
2. The test oracle at `_legacy_positions` defaults to `Day()`, while production defaults to `BDay()`. Its Thursday sample makes both schedules coincide, so this does not detect the mismatch. Use `BDay()` in the oracle and a Friday/weekend input that distinguishes calendar-day from business-day expiry.

The source diff otherwise preserves the stated arithmetic and expiry lifecycle for the base DataFrame path. No tests or performance checks were run in this review.

## Follow-up review — current pin (2026-10-24)

**Decision: HOLD remains.** Static-only review of the updated Fincore files found both original issues fixed: the optimized dispatch now additionally requires `type(weights_frame) is pd.DataFrame`, and the old-algorithm oracle now defaults to `BDay()` with a Friday date that distinguishes Monday expiry from Saturday. The subclass test also correctly produces a `_WeightsFrameSubclass` from `unstack()` and replaces the buffer allocator with a failing sentinel, so it would detect accidental buffer dispatch.

One test assertion pair is inconsistent with its fixture. `test_dataframe_subclass_uses_legacy_output_path` creates March 1 and March 4 timestamps and passes `Day()` explicitly, but then asserts that February 5 is present and February 3 is absent. Neither assertion describes that fixture; with `Day()` the March 2 expiry is expected. Correct those assertions or remove the unrelated calendar assertions, then freeze and review the resulting test pin.

Current reviewed pins: `portfolio.py` SHA-256 `bb495953765d300034f783c0affb99add6c99b65295818bc2878df10c1003f7d`; `test_factor_analysis_positions_buffer.py` SHA-256 `13d8a3cee84c860c1bef0b558d6d35a04d510983dfdcb345044f47e2167631f7`. No imports, tests, or benchmarks were run.

## Final follow-up static review — 2026-10-24

**Decision: GO_STATIC_REVIEW_ONLY.** Rechecked the current Fincore `dev` source and test at HEAD `4e01ac9f6f081f13acd60b45559119e1a5ed4a4f`. Final source SHA-256: `bb495953765d300034f783c0affb99add6c99b65295818bc2878df10c1003f7d`. Final test SHA-256: `e58cfbab427d1d3152f1b414649b2e13aec8768af478278b6f414d67a745612d`.

The author fixed the remaining test issue: the subclass case now checks only its March fixture against the independent legacy oracle, while the separate default-calendar case uses Friday and confirms Monday expiry instead of Saturday. The subclass test proves `unstack()` returned `_WeightsFrameSubclass`, and its `np.zeros` sentinel fails if the buffer path is selected; the production exact-base-DataFrame gate therefore has a meaningful regression check. The dtype guard still sends extension dtypes to the unchanged legacy path. I found no further static semantic issue in the reviewed diff, including column/index ordering, the unchanged calculations and expiry order, or exact float64 value handling.

This is static review only. No Python imports, tests, or benchmarks were run; Root's functional QA and fixed-500 performance acceptance remain separate gates.
