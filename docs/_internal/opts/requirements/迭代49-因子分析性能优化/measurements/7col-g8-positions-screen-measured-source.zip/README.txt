Measured source delta, inherited snapshot manifests, exact runner/config and source QA. Not full-universe acceptance.
