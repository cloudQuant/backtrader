Six candidate/focus files, baseline operator sources and exact measured support sources.
