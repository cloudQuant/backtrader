"""Run G10c-source 025 follow-ups only when explicitly invoked; no QA suite."""
import hashlib
import io
import json
import runpy
import statistics
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
CONFIG_PATH = ROOT / ".codex-tmp/iteration49-g10c-025-followup-config.json"
CONFIG_SHA256 = "e832c4c901b48527e9d5b682431a2d46d3e44f75478fe4e9aab1250359e0c85c"
BASE_CFG_SHA256 = "e2efe1ffa90a8837a76f5b60e8d779e24ad81621430edbf68502b23c17885232"
PAIR_LAUNCHER = ROOT / ".codex-tmp/iteration49_g10_panel_once_pairs.py"
PAIR_LAUNCHER_SHA256 = "64182c2d2dd426dc6a6d6c49415df421f50b0dd9bbccfc1dba1e945ad1d98a4c"
BASE_HELPER = ROOT / ".codex-tmp/iteration49_next_pairs.py"
BASE_HELPER_SHA256 = "541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb"
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
EXAMPLES = ("025", "026", "027")


def raw(path):
    return Path(path).read_bytes()


def pin(data):
    return {"size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def check_config_pins(cfg):
    assert pin(raw(CONFIG_PATH))["sha256"] == CONFIG_SHA256
    base_config = ROOT / cfg["base_config_path"]
    assert pin(raw(base_config))["sha256"] == cfg["base_config_sha256"] == BASE_CFG_SHA256


def phase_result(result, run_path):
    return {
        "path": str(run_path),
        "result": pin(raw(run_path / "result.json")),
        "wall_s": result["example_main_wall_ns"] / 1e9,
        "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
        "peak_bytes": max(result["main_peak_working_set_bytes"],
                           result["resource_peak_tree_rss_bytes"]),
        "expected_engine": result["expected_engine"],
        "observed_engine": result["observed_engine"],
        "phase_timers": result["phase_timers"],
    }


def check_verifier(path, pair, out_root, prefix, control_prefix):
    verifier = read(path)
    assert (verifier.get("status"), verifier.get("valid"),
            verifier.get("scope_complete")) == ("PASS", True, True)
    assert set(verifier.get("comparisons", {})) == set(EXAMPLES)
    assert all(row.get("valid") is True for row in verifier["comparisons"].values())
    for side, arm in (("baseline", "a"), ("candidate", "b")):
        for example in EXAMPLES:
            source_pair = pair if example == "025" else 1
            source_prefix = prefix if example == "025" else control_prefix
            expected = out_root / f"{source_prefix}-p{source_pair}-{arm}-{example}" / "example"
            actual = Path(verifier["runs"][side][example]["directory"])
            assert actual.resolve() == expected.resolve()
    return verifier


def write_partial(path, pair, canonical_path, verifier, out_root, prefix, control_prefix):
    partial = {
        "schema": "iteration49.g10c-025-followup.partial-fixed500-verification.v1",
        "status": "PASS",
        "valid": True,
        "scope_complete": False,
        "independent_examples": ["025"],
        "independent_scope_complete": True,
        "comparisons": {"025": verifier["comparisons"]["025"]},
        "reused_controls": {
            example: {
                "source_pair": 1,
                "comparison_valid": verifier["comparisons"][example]["valid"],
                "baseline": str(out_root / f"{control_prefix}-p1-a-{example}"),
                "candidate": str(out_root / f"{control_prefix}-p1-b-{example}"),
            }
            for example in ("026", "027")
        },
        "canonical_control_inclusive_verifier": {
            "path": str(canonical_path),
            **pin(raw(canonical_path)),
            "status": verifier["status"],
            "scope_complete": verifier["scope_complete"],
        },
        "current_pair_025": {
            "baseline": str(out_root / f"{prefix}-p{pair}-a-025"),
            "candidate": str(out_root / f"{prefix}-p{pair}-b-025"),
        },
        "note": "Only 025 is newly compared in this pair; 026/027 are explicit pair-1 controls.",
    }
    write_new(path, json.dumps(partial, ensure_ascii=False, indent=2).encode("utf-8") + b"\n")
    return partial


def metric_summary(measurements):
    row = {"actual_pairs": [1, 2, 3], "per_pair": measurements, "metrics": {}}
    for key in ("wall_s", "cpu_s", "peak_bytes"):
        ratios = [measurements[pair]["b"][key] / measurements[pair]["a"][key]
                  for pair in (1, 2, 3)]
        median = statistics.median(ratios)
        dispersion = (max(ratios) - min(ratios)) / median
        row["metrics"][key] = {
            "paired_candidate_over_baseline_b_over_a": ratios,
            "median_b_over_a": median,
            "median_gain_percent": 100.0 * (1.0 - median),
            "relative_dispersion_of_b_over_a": dispersion,
        }
    return row


def build_archive(summary, records, verifiers, partials, cfg, pair_api):
    members = {
        "summary.json": json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8") + b"\n",
        "followup.py": raw(__file__),
        "followup-config.json": raw(CONFIG_PATH),
        "g10c-pair1-config.json": raw(ROOT / cfg["base_config_path"]),
        "pair-launcher.py": raw(PAIR_LAUNCHER),
        "source-data-helper.py": raw(BASE_HELPER),
        "canonical-runner.py": raw(ROOT / RUNNER),
        "canonical-verifier.py": raw(ROOT / VERIFIER),
    }
    for run_path, record in records:
        name = Path(run_path).name
        for filename in ("result.json", "example/summary.json"):
            members[f"runs/{name}/{filename.replace('/', '_')}"] = raw(Path(run_path) / filename)
        members[f"runs/{name}/run.log"] = raw(Path(run_path).with_suffix(".log"))
    for path, verifier in verifiers:
        members[f"verifiers/{Path(path).name}"] = raw(path)
        members[f"verifiers/{Path(path).with_suffix('.log').name}"] = raw(Path(path).with_suffix(".log"))
    for path in partials:
        members[f"verifiers/{Path(path).name}"] = raw(path)
    control_root = Path(cfg["output_root"])
    control_prefix = cfg["reused_control_prefix"]
    for arm in ("a", "b"):
        control = pair_api["output"](control_root, control_prefix, 1, arm, "025")
        for filename in ("result.json", "example/summary.json"):
            members[f"pair1-025/{arm}/{filename.replace('/', '_')}"] = raw(control / filename)
        members[f"pair1-025/{arm}/run.log"] = raw(control.with_suffix(".log"))
    pair1_verifier = control_root / f"{control_prefix}-p1-verification.json"
    members[f"pair1-025/{pair1_verifier.name}"] = raw(pair1_verifier)
    members[f"pair1-025/{pair1_verifier.with_suffix('.log').name}"] = raw(
        pair1_verifier.with_suffix(".log"))
    rows = [{"path": name, **pin(data)} for name, data in sorted(members.items())]
    manifest = json.dumps({"schema_version": 1, "files": rows}, indent=2).encode("utf-8") + b"\n"
    members["MANIFEST.json"] = manifest
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(members.items()):
            archive.writestr(name, data)
    blob = out.getvalue()
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        assert set(archive.namelist()) == set(members)
        for name, data in members.items():
            assert archive.read(name) == data
    return blob, {**pin(blob), "payload_count": len(rows),
                  "manifest_sha256": pin(manifest)["sha256"]}


def main():
    assert sys.argv[1:] in ([], ["--archive"]), "usage: script.py [--archive]"
    archive_requested = sys.argv[1:] == ["--archive"]
    assert pin(raw(CONFIG_PATH))["sha256"] == CONFIG_SHA256
    cfg = read(CONFIG_PATH)
    assert cfg["example"] == "025" and cfg["new_pairs"] == [2, 3]
    assert cfg["pair_order"] == {"2": ["b", "a"], "3": ["a", "b"]}
    assert cfg["output_prefix"] == "iteration49-g10c-025-followup-500"
    assert pin(raw(PAIR_LAUNCHER))["sha256"] == PAIR_LAUNCHER_SHA256
    assert pin(raw(BASE_HELPER))["sha256"] == BASE_HELPER_SHA256
    assert pin(raw(ROOT / cfg["base_config_path"]))["sha256"] == cfg["base_config_sha256"] == BASE_CFG_SHA256

    pair_api = runpy.run_path(str(PAIR_LAUNCHER), run_name="g10c_025_followup_pair_api")
    base_api = runpy.run_path(str(BASE_HELPER), run_name="g10c_025_followup_base_api")
    assert pair_api["PAIR_HELPER_SHA256"] == BASE_HELPER_SHA256
    base_cfg = read(ROOT / cfg["base_config_path"])
    check_config_pins(cfg)
    assert base_cfg["pairs"] == [1] and base_cfg["output_prefix"] == cfg["reused_control_prefix"]
    assert base_cfg["expected_engines"]["a"]["025"] == base_cfg["expected_engines"]["b"]["025"] == "runonce"
    assert set(base_cfg["tool_pins"]) == {RUNNER, VERIFIER}
    state = pair_api["source_state"](base_cfg, base_api)
    data = base_api["data_state"](base_cfg)
    base_api["check_data"](data)
    out_root = Path(base_cfg["output_root"]).resolve(strict=True)
    prefix, control_prefix = cfg["output_prefix"], cfg["reused_control_prefix"]
    orders = {int(pair): tuple(arms) for pair, arms in cfg["pair_order"].items()}
    summary_path = Path(cfg["summary_path"])
    archive_path = Path(cfg["archive_path"])
    assert not summary_path.exists()
    if archive_requested:
        assert not archive_path.exists()
    for pair in cfg["new_pairs"]:
        for arm in orders[pair]:
            run_path = pair_api["output"](out_root, prefix, pair, arm, "025")
            assert not run_path.exists() and not run_path.with_suffix(".log").exists(), run_path
        verification_path = out_root / f"{prefix}-p{pair}-control-inclusive-verification.json"
        partial_path = out_root / f"{prefix}-p{pair}-partial-scope.json"
        assert not verification_path.exists() and not verification_path.with_suffix(".log").exists()
        assert not partial_path.exists()

    # Confirm the G10c pair-1 controls once, then count only new 025 runs below.
    control_verifier = pair_api["check_pair1_controls"](
        out_root, control_prefix, base_cfg, base_api, state, data
    )
    control_verifier_path = out_root / f"{control_prefix}-p1-verification.json"
    control_verifier_pin = pin(raw(control_verifier_path))
    measurements = {1: {}}
    control_records = []
    for arm in ("a", "b"):
        run_path = pair_api["output"](out_root, control_prefix, 1, arm, "025")
        result = pair_api["validate_run"](run_path, arm, "025", base_cfg,
                                           base_api, state, data)
        measurements[1][arm] = {
            "wall_s": result["example_main_wall_ns"] / 1e9,
            "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
            "peak_bytes": max(result["main_peak_working_set_bytes"],
                              result["resource_peak_tree_rss_bytes"]),
        }
        control_records.append({"arm": arm, **phase_result(result, run_path)})

    new_records, verifier_records, partial_records = [], [], []
    for pair in cfg["new_pairs"]:
        measurements[pair] = {}
        for arm in orders[pair]:
            pair_api["check_state"](base_cfg, base_api, state, data)
            check_config_pins(cfg)
            run_path = pair_api["output"](out_root, prefix, pair, arm, "025")
            assert not run_path.exists() and not run_path.with_suffix(".log").exists()
            source_root = state[1] if arm == "a" else state[3]
            command = [
                ROOT / RUNNER, "--source-root", source_root, "--fincore-root", state[5],
                "--data-root", data[0], "--selection", data[1], "--universe", "fixed500",
                "--example", "025", "--profile", "full", "--expected-engine", "runonce",
                "--output", run_path,
            ]
            base_api["check_tools"](ROOT, base_cfg)
            pair_api["execute"](command, run_path.with_suffix(".log"), ROOT)
            result = pair_api["validate_run"](run_path, arm, "025", base_cfg,
                                               base_api, state, data)
            pair_api["check_state"](base_cfg, base_api, state, data)
            check_config_pins(cfg)
            record = {"pair": pair, "arm": arm, "example": "025",
                      **phase_result(result, run_path)}
            measurements[pair][arm] = {key: record[key] for key in
                                       ("wall_s", "cpu_s", "peak_bytes")}
            new_records.append(record)

        verification_path = out_root / f"{prefix}-p{pair}-control-inclusive-verification.json"
        assert not verification_path.exists() and not verification_path.with_suffix(".log").exists()
        command = [ROOT / VERIFIER, "--data-root", data[0], "--selection", data[1],
                   "--universe", "fixed500", "--output", verification_path]
        for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
            for example in EXAMPLES:
                source_pair = pair if example == "025" else 1
                source_prefix = prefix if example == "025" else control_prefix
                run_path = pair_api["output"](out_root, source_prefix, source_pair, arm, example)
                pair_api["validate_run"](run_path, arm, example, base_cfg,
                                          base_api, state, data)
                command.extend((flag, f"{example}={run_path}"))
        pair_api["check_state"](base_cfg, base_api, state, data)
        check_config_pins(cfg)
        base_api["check_tools"](ROOT, base_cfg)
        pair_api["execute"](command, verification_path.with_suffix(".log"), ROOT)
        pair_api["check_state"](base_cfg, base_api, state, data)
        check_config_pins(cfg)
        verifier = check_verifier(verification_path, pair, out_root, prefix, control_prefix)
        partial_path = out_root / f"{prefix}-p{pair}-partial-scope.json"
        assert not partial_path.exists()
        partial = write_partial(partial_path, pair, verification_path, verifier,
                                out_root, prefix, control_prefix)
        verifier_records.append({"pair": pair, "path": str(verification_path),
                                **pin(raw(verification_path)), "status": verifier["status"],
                                "scope_complete": True, "independent_examples": ["025"]})
        partial_records.append({"pair": pair, "path": str(partial_path),
                                **pin(raw(partial_path)), "scope_complete": False,
                                "independent_scope_complete": True,
                                "independent_examples": partial["independent_examples"],
                                "reused_controls": ["026", "027"]})

    summary = {
        "schema": "iteration49.g10c-025-followup-fixed500.v1",
        "status": "PASS_OUTPUT_EQUIVALENCE_MEASUREMENT_ONLY",
        "measurement_scope": {
            "new_pairs": cfg["new_pairs"],
            "new_actual_processes": len(new_records),
            "new_independent_comparisons": 2,
            "025_pairs_including_g10c_pair1": [1, 2, 3],
            "026_027_reused_controls_from_pair": 1,
        },
        "counts": {"new_runs": len(new_records), "new_verifiers": len(verifier_records),
                   "partial_scope_receipts": len(partial_records),
                   "reused_control_comparisons": 4},
        "pins": {
            "followup_config": {"path": str(CONFIG_PATH), **pin(raw(CONFIG_PATH))},
            "g10c_pair1_config": {"path": str(ROOT / cfg["base_config_path"]),
                                  **pin(raw(ROOT / cfg["base_config_path"]))},
            "pair_launcher": {"path": str(PAIR_LAUNCHER), **pin(raw(PAIR_LAUNCHER))},
            "base_helper": {"path": str(BASE_HELPER), **pin(raw(BASE_HELPER))},
            "canonical_runner": {"path": str(ROOT / RUNNER), **pin(raw(ROOT / RUNNER))},
            "canonical_verifier": {"path": str(ROOT / VERIFIER), **pin(raw(ROOT / VERIFIER))},
            "selection": {"path": str(data[1]), **pin(raw(data[1]))},
            "pair1_verifier": {"path": str(control_verifier_path),
                               **pin(raw(control_verifier_path))},
        },
        "sources": {"backtrader_baseline": base_cfg["backtrader_snapshot"],
                    "backtrader_candidate": base_cfg["backtrader_candidate"],
                    "fincore_snapshot": base_cfg["fincore_snapshot"]},
        "fixed_500": {"symbols": 500, "dates": 243,
                      "selection_sha256": base_cfg["data"]["selection_sha256"]},
        "pair1_025_control": control_records,
        "new_025_runs": new_records,
        "control_inclusive_verifiers": verifier_records,
        "partial_scope_receipts": partial_records,
        "paired_metrics_025": metric_summary(measurements),
        "performance_claim": "Three measured 025 pairs describe this pinned source only; no fixed-universe performance threshold is accepted here.",
        "reused_controls": {
            example: {
                arm: {
                    "path": str(pair_api["output"](out_root, control_prefix, 1, arm, example)),
                    "result": pin(raw(pair_api["output"](
                        out_root, control_prefix, 1, arm, example) / "result.json")),
                    "summary": pin(raw(pair_api["output"](
                        out_root, control_prefix, 1, arm, example) / "example/summary.json")),
                }
                for arm in ("a", "b")
            }
            for example in ("026", "027")
        } | {
            "counted_as_new_comparisons": False,
        },
        "archive": {"requested": archive_requested,
                    "path": cfg["archive_path"] if archive_requested else None},
    }
    assert pin(raw(control_verifier_path)) == control_verifier_pin
    check_config_pins(cfg)
    summary_bytes = json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    if archive_requested:
        archive_blob, _archive_meta = build_archive(
            summary, [(record["path"], record) for record in new_records],
            [(row["path"], row) for row in verifier_records],
            [row["path"] for row in partial_records], cfg, pair_api
        )
        write_new(summary_path, summary_bytes)
        write_new(archive_path, archive_blob)
    else:
        write_new(summary_path, summary_bytes)
    print(json.dumps({"summary": str(summary_path), "new_runs": len(new_records),
                      "verifiers": len(verifier_records), "partial_receipts": len(partial_records),
                      "archive": archive_requested}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
