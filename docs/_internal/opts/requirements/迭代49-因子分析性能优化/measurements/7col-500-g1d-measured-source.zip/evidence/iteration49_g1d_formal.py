"""Run serial G1d fixed-500 pairs with complete-output verification."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path("D:/source_code/backtrader")
BT = Path("D:/temp/iteration49-g3-backtrader-b4c965bbd")
FC_A = Path("D:/temp/iteration49-g2b-fincore-41cf7c9")
FC_B = Path("D:/source_code/fincore")
TEMP = Path("D:/temp")
DATA = ROOT / "tests/datas/a_stocks"
BT_COMMIT = "b4c965bbd52438c43d941629742457702215c0e6"
BT_MANIFEST_SHA256 = "cc34df388dd9ece34408cbbc278a957bdc15055689019e491d71929316c57725"
FC_COMMIT = "41cf7c918a8249dce06c1e7c1f6d50137284ace8"
FC_A_MANIFEST_SHA256 = "b4fc1021cb81d4f54d1e4d597dd885aa510e9861baa65b0cd6e207a02c388e8c"
FC_MODEL_PATH = "fincore/factor_analysis/models.py"
FC_A_MODEL_SHA256 = "78c9cc243cc5ee163c4231b365bad11f2d835427a49c5c4ded65ec69f9420404"
FC_A_MODEL_SIZE = 129150
FC_B_MODEL_SHA256 = "86fc25db4da460281bfa861dd0f2e202de82dafc5d1ece3b646856aa6c8e9d64"
FC_B_MODEL_SIZE = 135268
FC_B_TEST = Path("tests/factor_analysis/test_fingerprint_streaming.py")
FC_B_TEST_SHA256 = "ac4a58becb79c435b838a82b330fd16e44177394fa1c6f8b0a7347c4d17af623"
FC_B_SOURCE_STATUS = [" M fincore/factor_analysis/models.py"]
EXAMPLES = ("025", "026", "027")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_manifest(root: Path, commit: str, manifest_sha256: str) -> dict:
    path = root / ".iteration49-source.json"
    assert path.is_file() and sha256(path) == manifest_sha256, path
    manifest = json.loads(path.read_text(encoding="utf-8"))
    assert manifest.get("schema_version") == 1
    assert manifest.get("commit") == commit
    return manifest


def check_sources() -> dict:
    bt_manifest = check_manifest(BT, BT_COMMIT, BT_MANIFEST_SHA256)
    assert Path(bt_manifest["source_repository"]).resolve() == ROOT.resolve()

    fc_a_manifest = check_manifest(FC_A, FC_COMMIT, FC_A_MANIFEST_SHA256)
    assert Path(fc_a_manifest["source_repository"]).resolve() == FC_B.resolve()
    expected_a = fc_a_manifest["files"][FC_MODEL_PATH]
    assert expected_a == {"sha256": FC_A_MODEL_SHA256, "size_bytes": FC_A_MODEL_SIZE}
    assert sha256(FC_A / FC_MODEL_PATH) == FC_A_MODEL_SHA256

    head = subprocess.run(
        ["git", "-C", str(FC_B), "rev-parse", "--verify", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    branch = subprocess.run(
        ["git", "-C", str(FC_B), "branch", "--show-current"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert head == FC_COMMIT and branch == "dev", (head, branch)
    assert not (FC_B / ".iteration49-source.json").is_file()
    assert sha256(FC_B / FC_MODEL_PATH) == FC_B_MODEL_SHA256
    assert (FC_B / FC_MODEL_PATH).stat().st_size == FC_B_MODEL_SIZE
    assert sha256(FC_B / FC_B_TEST) == FC_B_TEST_SHA256

    status = subprocess.run(
        [
            "git",
            "-C",
            str(FC_B),
            "status",
            "--porcelain=v1",
            "--untracked-files=all",
            "--",
            "fincore",
        ],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
    ).stdout.splitlines()
    assert status == FC_B_SOURCE_STATUS, status

    return fc_a_manifest


def execute(args: list[str], log: Path) -> None:
    assert not log.exists(), log
    with log.open("xb") as stream:
        result = subprocess.run(
            [sys.executable, *args],
            cwd=ROOT,
            stdout=stream,
            stderr=subprocess.STDOUT,
        )
    assert result.returncode == 0, (result.returncode, str(log))


def run_result(path: Path, arm: str, example: str, fc_a_manifest: dict) -> dict:
    result = json.loads(path.read_text(encoding="utf-8"))
    assert result.get("status") == "COMPLETED", path
    assert result.get("runner_exit_code") == 0 and result.get("example_exit_code") == 0
    assert result.get("example") == example and result.get("profile") == "full"
    assert not result.get("source_or_input_changes") and not result.get("summary_check_errors")
    summary = result.get("summary") or {}
    assert summary.get("status") == "COMPLETED" and summary.get("symbols") == 500
    assert summary.get("dates") == 243 and summary.get("factor_mode") == "native"
    assert summary.get("factor_calculation") == "RAN"

    bt_source = result.get("backtrader_source_before")
    fc_source = result.get("fincore_source_before")
    assert bt_source == result.get("backtrader_source_after")
    assert fc_source == result.get("fincore_source_after")
    assert bt_source and bt_source.get("commit") == BT_COMMIT
    assert fc_source and fc_source.get("commit") == FC_COMMIT
    if arm == "a":
        assert fc_source.get("kind") == "verified_snapshot_manifest_v1"
        assert fc_source.get("manifest_sha256") == FC_A_MANIFEST_SHA256
    else:
        assert fc_source.get("kind") == "git_worktree" and fc_source.get("branch") == "dev"
        assert fc_source.get("source_status") == FC_B_SOURCE_STATUS

    fc_files = result.get("fincore_files_before") or {}
    assert set(fc_files) == set(fc_a_manifest["files"])
    for name, expected in fc_a_manifest["files"].items():
        pinned = expected
        if arm == "b" and name == FC_MODEL_PATH:
            pinned = {"sha256": FC_B_MODEL_SHA256, "size_bytes": FC_B_MODEL_SIZE}
        assert fc_files.get(name) == pinned, (arm, name, fc_files.get(name), pinned)

    args = result.get("example_cli_arguments") or []
    assert args.count("--max-symbols") == 1 and args[args.index("--max-symbols") + 1] == "500"
    assert args.count("--factor-mode") == 1 and args[args.index("--factor-mode") + 1] == "native"
    assert args.count("--data-dir") == 1
    assert Path(args[args.index("--data-dir") + 1]).resolve() == DATA.resolve()
    data_identity = result.get("data_identity_before")
    assert data_identity and data_identity == result.get("data_identity_after")
    assert data_identity.get("symbols") == 500 and data_identity.get("dates") == 243
    return result


def main() -> None:
    pairs = tuple(map(int, sys.argv[1:])) if len(sys.argv) > 1 else (1, 2, 3)
    assert pairs and len(set(pairs)) == len(pairs) and all(pair in (1, 2, 3) for pair in pairs)
    fc_a_manifest = check_sources()

    for pair in pairs:
        order = ("a", "b") if pair % 2 else ("b", "a")
        for example in EXAMPLES:
            sources = {}
            for arm in order:
                check_sources()
                output = TEMP / f"iteration49-7col-g1d-p{pair}-{arm}-{example}"
                assert not output.exists(), output
                fc_root = FC_A if arm == "a" else FC_B
                print(f"START G1d pair={pair} arm={arm} example={example}", flush=True)
                execute(
                    [
                        "scripts/benchmark_factor_examples.py",
                        "--source-root",
                        str(BT),
                        "--fincore-root",
                        str(fc_root),
                        "--data-root",
                        str(DATA),
                        "--example",
                        example,
                        "--profile",
                        "full",
                        "--output",
                        str(output),
                    ],
                    output.with_suffix(".log"),
                )
                result = run_result(output / "result.json", arm, example, fc_a_manifest)
                sources[arm] = result["fincore_source_before"]
                print(
                    json.dumps(
                        {
                            "pair": pair,
                            "arm": arm,
                            "example": example,
                            "wall_s": result["example_main_wall_ns"] / 1e9,
                            "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                            "peak_bytes": max(
                                result["main_peak_working_set_bytes"],
                                result["resource_peak_tree_rss_bytes"],
                            ),
                        }
                    ),
                    flush=True,
                )
                check_sources()
            assert sources["a"].get("source_content_sha256") != sources["b"].get(
                "source_content_sha256"
            )

        verification = TEMP / f"iteration49-7col-g1d-p{pair}-verification.json"
        assert not verification.exists(), verification
        verify_args = ["scripts/verify_factor_examples_benchmark.py", "--output", str(verification)]
        for arm, flag in (("a", "--baseline"), ("b", "--candidate")):
            for example in EXAMPLES:
                verify_args.extend(
                    (
                        flag,
                        f"{example}={TEMP}/iteration49-7col-g1d-p{pair}-{arm}-{example}",
                    )
                )
        execute(verify_args, verification.with_suffix(".log"))
        verified = json.loads(verification.read_text(encoding="utf-8"))
        assert verified.get("status") == "PASS" and verified.get("scope_complete") is True
        print(f"G1d PAIR {pair} COMPLETE OUTPUT PASS", flush=True)


if __name__ == "__main__":
    main()
