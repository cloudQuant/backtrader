G1d measured source slice; shared Backtrader G3 snapshot and FinCore A/B benchmark sources. The B focused-test file is provenance only and is not a benchmark input.
