#!/usr/bin/env python3
"""Diagnostic only: profile one outer 026 phase in a fresh full fixed500 process.

By default one full fixed500 run profiles collection, evaluate_frames, and the
outer html_report call independently. --phase can select just one profiler.
Each run includes profiler overhead and is diagnostic only. Example:
python .codex-tmp/iteration49_026_cprofile.py --source-root D:/temp/iteration49-g3-presence-backtrader-2e9493713 --fincore-root D:/temp/iteration49-g6-fincore-4e01ac9 --data-root D:/source_code/backtrader/tests/datas/a_stocks --selection D:/temp/iteration49-g3-presence-backtrader-2e9493713/docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json --example 026 --universe fixed500 --profile full --output D:/temp/iteration49-026-cprofile-full
"""
import argparse
import cProfile
import functools
import hashlib
import json
import pstats
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BT_ROOT = Path(r"D:\temp\iteration49-g3-presence-backtrader-2e9493713")
FC_ROOT = Path(r"D:\temp\iteration49-g6-fincore-4e01ac9")
RUNNER = ROOT / "scripts" / "benchmark_factor_examples.py"
RUNNER_SHA256 = "63233d4cdfae9fc3f79813f88b96840a9019ea6fcb09d0cb80b667e62c1a8dd2"
BT_COMMIT = "2e94937132c65487d65208cf17cbd5f2046fd420"
BT_MANIFEST = "cf3a6db0931ad5dd445583de44b705ec5e2a365e5e3b38571ab0e25b7813eb2c"
FC_COMMIT = "4e01ac9f6f081f13acd60b45559119e1a5ed4a4f"
FC_MANIFEST = "dd302498270cf278766dca2dbb3c9494abe54c908f84b8c7f97b1493efa7af3c"
PROFILE_LABELS = {"collection": "collection", "evaluate_frames": "evaluate_frames",
                  "html_report": "html_report"}


def main():
    cli = argparse.ArgumentParser(add_help=False)
    cli.add_argument("--phase", choices=tuple(PROFILE_LABELS) + ("all",), default="all")
    options, runner_argv = cli.parse_known_args()
    if hashlib.sha256(RUNNER.read_bytes()).hexdigest() != RUNNER_SHA256:
        raise ValueError("canonical diagnostic runner changed")
    runner = runpy.run_path(str(RUNNER), run_name="iteration49_026_cprofile_runner")
    args = runner["_parser"]().parse_args(runner_argv)
    if (args.example, args.universe, args.profile, args.diagnostic) != ("026", "fixed500", "full", False):
        raise ValueError("cProfile diagnostic requires example 026, fixed500, full, without --diagnostic")
    bt_root, fc_root = args.source_root.resolve(strict=True), args.fincore_root.resolve(strict=True)
    if bt_root != BT_ROOT.resolve(strict=True) or fc_root != FC_ROOT.resolve(strict=True):
        raise ValueError("source roots differ from the frozen diagnostic snapshots")
    examples = tuple("examples/backtest/" + name for name in runner["EXAMPLES"].values())
    bt_identity, bt_files = runner["_source_state"](bt_root, "backtrader", examples)
    fc_identity, fc_files = runner["_source_state"](fc_root, "fincore")
    if (bt_identity.get("commit"), bt_identity.get("manifest_sha256")) != (BT_COMMIT, BT_MANIFEST):
        raise ValueError("Backtrader diagnostic snapshot identity mismatch")
    if (fc_identity.get("commit"), fc_identity.get("manifest_sha256")) != (FC_COMMIT, FC_MANIFEST):
        raise ValueError("Fincore diagnostic snapshot identity mismatch")
    selection = args.selection.resolve(strict=True) if args.selection else bt_root / runner["SELECTION"]
    data_identity, data_files = runner["_data_state"](args.data_root.resolve(strict=True), selection, "fixed500")
    if (data_identity.get("symbols"), data_identity.get("dates"), data_identity.get("grid_cells")) != (500, 243, 121500):
        raise ValueError("diagnostic data is not the pinned 500-by-243 grid")

    timers = runner["Timers"]
    original_wrap = timers.wrap
    selected = PROFILE_LABELS if options.phase == "all" else {options.phase: PROFILE_LABELS[options.phase]}
    profiles = {label: cProfile.Profile() for label in selected.values()}
    depths = {label: 0 for label in selected.values()}

    def profiled_wrap(self, owner, attr, label, after=None):
        installed = original_wrap(self, owner, attr, label, after)
        if label not in profiles:
            return installed
        if not installed:
            raise RuntimeError("requested profiling target was not installed: " + label)
        profiler = profiles[label]
        measured = getattr(owner, attr)

        @functools.wraps(measured)
        def profile_call(*call_args, **call_kwargs):
            outer = depths[label] == 0
            depths[label] += 1
            if outer:
                profiler.enable()
            try:
                return measured(*call_args, **call_kwargs)
            finally:
                depths[label] -= 1
                if outer:
                    profiler.disable()

        setattr(owner, attr, profile_call)
        return True

    timers.wrap = profiled_wrap
    try:
        runner["main"](runner_argv)
    finally:
        timers.wrap = original_wrap
    missing = [phase for phase, label in selected.items() if not profiles[label].getstats()]
    if missing:
        raise RuntimeError("requested phase was not called; no profile produced for " + ", ".join(missing))

    profile_dir = args.output.resolve() / "cprofile"
    profile_dir.mkdir(exist_ok=False)
    for phase, label in selected.items():
        profiles[label].dump_stats(str(profile_dir / (phase + ".prof")))

    result_path = args.output.resolve(strict=True) / "result.json"
    result = json.loads(result_path.read_text(encoding="utf-8"))
    if hashlib.sha256(RUNNER.read_bytes()).hexdigest() != RUNNER_SHA256:
        raise ValueError("canonical diagnostic runner changed during run")
    if (result.get("schema"), result.get("status"), result.get("runner_exit_code")) != (
            "iteration49.benchmark-run.v1", "COMPLETED", 0):
        raise RuntimeError("benchmark runner did not complete; inspect " + str(result_path))
    if result.get("source_or_input_changes") != []:
        raise RuntimeError("runner did not confirm unchanged sources and inputs")
    for phase, label in selected.items():
        phase_row = (result.get("phase_timers") or {}).get(label) or {}
        if phase_row.get("calls", 0) < 1:
            raise RuntimeError("runner did not record a call to phase " + phase)
    if (result.get("backtrader_source_before"), result.get("backtrader_source_after"),
            result.get("fincore_source_before"), result.get("fincore_source_after")) != (
            bt_identity, bt_identity, fc_identity, fc_identity):
        raise RuntimeError("source identity changed during the diagnostic run")
    if (result.get("backtrader_files_before"), result.get("fincore_files_before"),
            result.get("data_identity_before"), result.get("data_identity_after"),
            result.get("data_files_before")) != (bt_files, fc_files, data_identity, data_identity, data_files):
        raise RuntimeError("source or fixed input map differs from preflight")
    environment = result.get("environment") or {}
    if (Path(environment.get("backtrader_origin", "")).resolve(strict=True) != bt_root / "backtrader" / "__init__.py"
            or Path(environment.get("fincore_origin", "")).resolve(strict=True) != fc_root / "fincore" / "__init__.py"):
        raise RuntimeError("loaded package origins differ from the requested snapshot roots")
    if result.get("runner_sha256") != {"sha256": RUNNER_SHA256, "size_bytes": RUNNER.stat().st_size}:
        raise RuntimeError("executed benchmark runner is not the pinned canonical script")
    for field, root, pins, package in (
        ("loaded_module_origins_before_main", bt_root, bt_files, "backtrader"),
        ("loaded_module_origins_after_main", bt_root, bt_files, "backtrader"),
        ("loaded_module_origins_before_main", fc_root, fc_files, "fincore"),
        ("loaded_module_origins_after_main", fc_root, fc_files, "fincore"),
    ):
        for name, source in (result.get(field) or {}).items():
            if not (name == package or name.startswith(package + ".")):
                continue
            path = Path(source).resolve(strict=True)
            if not path.is_relative_to(root) or path.relative_to(root).as_posix() not in pins:
                raise RuntimeError("loaded module escaped its pinned source map: " + name)
    example_path = bt_root / "examples" / "backtest" / runner["EXAMPLES"]["026"] / "run.py"
    for field in ("loaded_module_origins_before_main", "loaded_module_origins_after_main"):
        example_origin = (result.get(field) or {}).get("_iteration49_example_026")
        if Path(example_origin or "").resolve(strict=True) != example_path.resolve(strict=True):
            raise RuntimeError("loaded 026 example origin differs from the pinned snapshot")

    for phase, label in selected.items():
        profile = profiles[label]
        with (profile_dir / (phase + "-top30.txt")).open("x", encoding="utf-8", newline="\n") as stream:
            stream.write("Diagnostic only: cProfile overhead is included; do not compare this run with paired timings.\n")
            stream.write("Target: %s (runner timer label %s); profiled independently in this single full run.\n\n" %
                         (phase, label))
            stats = pstats.Stats(profile, stream=stream).strip_dirs()
            stats.sort_stats(pstats.SortKey.TIME).print_stats(30)
            stream.write("\nTop 30 by cumulative time\n")
            stats.sort_stats(pstats.SortKey.CUMULATIVE).print_stats(30)
    (profile_dir / "postcheck.json").write_text(
        json.dumps({"status": "PASS_DIAGNOSTIC_ONLY", "phases": list(selected),
                    "performance_acceptance": False}, indent=2) + "\n", encoding="utf-8")
    print("PROFILE_ONLY %s -> %s" % (options.phase, profile_dir))


if __name__ == "__main__":
    main()
