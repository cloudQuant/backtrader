"""Serial full-output fixed-500 pairs for the G7 collection-memory candidate."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('D:/source_code/backtrader')
TEMP = Path('D:/temp')
BASE = TEMP / 'iteration49-g3-presence-backtrader-2e9493713'
FC = TEMP / 'iteration49-g6-fincore-4e01ac9'
BT_BASE_COMMIT = '2e94937132c65487d65208cf17cbd5f2046fd420'
FC_COMMIT = '4e01ac9f6f081f13acd60b45559119e1a5ed4a4f'
BT_MANIFEST = 'cf3a6db0931ad5dd445583de44b705ec5e2a365e5e3b38571ab0e25b7813eb2c'
FC_MANIFEST = 'dd302498270cf278766dca2dbb3c9494abe54c908f84b8c7f97b1493efa7af3c'
EXAMPLES = {
    '025': '025_factor_single',
    '026': '026_factor_multi',
    '027': '027_alpha003_panel_acceptance',
}
EXAMPLE_DIRS = tuple('examples/backtest/' + name for name in EXAMPLES.values())
RUNNER = 'scripts/benchmark_factor_examples.py'
VERIFIER = 'scripts/verify_factor_examples_benchmark.py'
DAILY = 'examples/backtest/027_alpha003_panel_acceptance/run_daily.py'
SELECTION = ROOT / 'docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json'
DATA = ROOT / 'tests/datas/a_stocks'
SELECTION_SHA256 = '14f789a9d9e649987b93bc0477a0f94acc5223edd7ccd70166c8ea4b33ba35dc'
DAILY_SHA256 = '206f13a98d7e153bd0cd6f5d42d38470fb7566788104b957af87614be5999220'
# The pinned run_daily.py is an unrelated preserved dirty input; this helper invokes run.py only.
PRESERVED_UNRELATED = {DAILY: DAILY_SHA256}
CANDIDATE_PINS = {
    'backtrader/research/factor_strategy.py': '1927eaa849429f3f4f11bf3bab51a288329fcef15c573793b34a8794b4244fc6',
    'backtrader/research/sink.py': '1b6ce3410999fe961862a46e17b9cddb869039a365daffa847ea35974c383f73',
    'examples/backtest/025_factor_single/run.py': '54b72e009e363a7a56d3b68bf58c5c6de5c1e212e33df7dd7ed3f0f956ee74b1',
    'examples/backtest/026_factor_multi/run.py': '14a5db1badb604734a5a44b837132084208de580e9ba7d62c34a3ca8209147db',
    'examples/backtest/027_alpha003_panel_acceptance/run.py': '76eb1de7a2495f6575dedee53446178d8c97c2e1de9fd96f3c7fbf1cfba027d9',
}
TEST_PINS = {
    'tests/unit/test_factor_research_examples.py': '7931c42a3a418cf776af5c9d3fec922362f3a9f7c95c915199cbef9cc63871f8',
    'tests/unit/test_factor_input_lifecycle.py': '5c74abd1a79423429ff1635e7303a83729769599f9bd7b80e013d65b9214faa8',
    'tests/unit/test_factor_memory_lifecycle.py': 'd905a4dc4c1468ba2e58f3ee55f5726631f65b769785043d2b979a99a9092db3',
    'tests/unit/test_factor_research_g7_memory.py': '3287a2b8f1d7296261b4ed2daea89571b7b7dff8dcf2a1976a5613b9748d32c4',
    'tests/unit/test_factor_research_contracts.py': '35965e560baf5999e632a0f89149585e5cd0a6f6a560fd52555308b78c3ca4fd',
    'tests/unit/test_factor_sink.py': '0ac45a57f4e8b8a991f144d6e54d920bab7d6b633a480e6e7d57c3d01a046205',
}

PINS = {
    **CANDIDATE_PINS,
    **TEST_PINS,
    RUNNER: '63233d4cdfae9fc3f79813f88b96840a9019ea6fcb09d0cb80b667e62c1a8dd2',
    VERIFIER: '5818795349d7856a3dcac897ffbd0687a6c60cde7552e8aa67570a534768c921',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def snapshot(root, expected_manifest, expected_commit):
    manifest_path = root / '.iteration49-source.json'
    assert digest(manifest_path) == expected_manifest
    manifest = read(manifest_path)
    assert manifest.get('schema_version') == 1 and manifest.get('commit') == expected_commit
    files = manifest.get('files')
    assert isinstance(files, dict) and files
    for name, item in files.items():
        path = root / name
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item['sha256'] and len(raw) == item['size_bytes'], name
    return manifest

def current_source_names():
    scopes = ['backtrader', *EXAMPLE_DIRS, RUNNER]
    raw = subprocess.check_output(
        ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard', '--', *scopes],
        cwd=ROOT,
    )
    names = {item.decode('utf-8') for item in raw.split(b'\0') if item}
    suffixes = {'.py', '.md', '.yaml', '.yml', '.json', '.pem'}
    return {
        name for name in names
        if name.startswith('backtrader/') or name == RUNNER
        or any((name == folder or name.startswith(folder + '/')) and Path(name).suffix.lower() in suffixes
               for folder in EXAMPLE_DIRS)
    }

def check_sources(expected_head):
    bt_manifest = snapshot(BASE, BT_MANIFEST, BT_BASE_COMMIT)
    snapshot(FC, FC_MANIFEST, FC_COMMIT)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip()
    assert head == expected_head and branch == 'dev'
    assert digest(SELECTION) == SELECTION_SHA256 and digest(ROOT / DAILY) == DAILY_SHA256
    for name, pin in PINS.items():
        assert digest(ROOT / name) == pin, name
    base_names = set(bt_manifest['files'])
    assert current_source_names() == base_names | {RUNNER}
    changed = set()
    for name in base_names:
        before = (BASE / name).read_bytes().replace(b'\r\n', b'\n')
        after = (ROOT / name).read_bytes().replace(b'\r\n', b'\n')
        if before != after:
            changed.add(name)
    assert changed == set(CANDIDATE_PINS) | {DAILY}, sorted(changed)
    scopes = ['backtrader', *EXAMPLE_DIRS, RUNNER]
    status = subprocess.check_output(
        ['git', 'status', '--porcelain=v1', '--untracked-files=no', '--', *scopes],
        cwd=ROOT, text=True, encoding='utf-8',
    ).splitlines()
    assert {line[3:] for line in status} == set(CANDIDATE_PINS) | set(PRESERVED_UNRELATED), status
    assert all(line[:2] == ' M' for line in status), status
    test_status = subprocess.check_output(
        ['git', 'status', '--porcelain=v1', '--untracked-files=all', '--', *TEST_PINS],
        cwd=ROOT, text=True, encoding='utf-8',
    ).splitlines()
    assert set(test_status) == {
        ' M tests/unit/test_factor_memory_lifecycle.py',
        ' M tests/unit/test_factor_research_examples.py',
        '?? tests/unit/test_factor_input_lifecycle.py',
        '?? tests/unit/test_factor_research_g7_memory.py',
    }, test_status
    staged = subprocess.check_output(
        ['git', 'diff', '--cached', '--name-only', '--', *scopes, *TEST_PINS], cwd=ROOT, text=True
    ).splitlines()
    assert not staged, staged
    return bt_manifest

def output(pair, arm, example):
    return TEMP / f'iteration49-g7-collection-p{pair}-{arm}-{example}'

def execute(args, log):
    with log.open('xb') as stream:
        result = subprocess.run([sys.executable, *args], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))

def validate(path, arm, example, bt_manifest, expected_head):
    result = read(path / 'result.json')
    assert result['status'] == 'COMPLETED'
    assert result['runner_exit_code'] == result['example_exit_code'] == 0
    assert result['input_universe'] == 'fixed500'
    assert result['example'] == example and result['profile'] == 'full'
    assert not result['source_or_input_changes'] and not result['summary_check_errors']
    for key in ('backtrader_source', 'fincore_source', 'data_identity'):
        assert result[key + '_before'] == result[key + '_after'], key
    bt = result['backtrader_source_before']
    if arm == 'a':
        assert bt['kind'] == 'verified_snapshot_manifest_v1'
        assert bt['commit'] == BT_BASE_COMMIT and bt['manifest_sha256'] == BT_MANIFEST
    else:
        assert (
            bt['kind'] == 'git_worktree'
            and bt['commit'] == expected_head
            and bt['branch'] == 'dev'
        )
        assert {line[3:] for line in bt['source_status']} == set(CANDIDATE_PINS) | set(PRESERVED_UNRELATED)
    assert result['fincore_source_before']['kind'] == 'verified_snapshot_manifest_v1'
    assert result['fincore_source_before']['commit'] == FC_COMMIT
    assert result['fincore_source_before']['manifest_sha256'] == FC_MANIFEST
    for name in (*CANDIDATE_PINS, DAILY):
        expected = bt_manifest['files'][name]['sha256'] if arm == 'a' else PINS.get(name, DAILY_SHA256)
        assert result['backtrader_files_before'][name]['sha256'] == expected, name
    summary = result['summary']
    assert (summary['symbols'], summary['dates'], summary['factor_mode'], summary['factor_calculation']) == (
        500, 243, 'native', 'RAN'
    )
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('pairs', nargs='+', type=int)
    args = parser.parse_args()
    expected_head = args.expected_head
    assert len(expected_head) == 40 and all(
        char in '0123456789abcdef' for char in expected_head
    )
    pairs = tuple(args.pairs)
    assert pairs and len(pairs) == len(set(pairs)) and all(pair in (1, 2, 3) for pair in pairs)
    bt_manifest = check_sources(expected_head)
    print(f'UNRELATED_PRESERVED_NOT_EXECUTED_QUICK: {DAILY} sha256={DAILY_SHA256}', flush=True)
    print('G7 PLAN: 18 runs, 9 unique comparisons, 3 verifiers, 9 verifier slots', flush=True)
    for pair in pairs:
        if pair > 1:
            first = TEMP / 'iteration49-g7-collection-p1-verification.json'
            assert first.is_file(), 'run pair 1 before pairs 2/3'
            prior = read(first)
            assert prior['status'] == 'PASS' and prior['scope_complete']
        examples = ('025', '026', '027')
        for example in examples:
            for arm in (('a', 'b') if pair % 2 else ('b', 'a')):
                check_sources(expected_head)
                destination = output(pair, arm, example)
                assert not destination.exists()
                print(f'START G7-collection pair={pair} arm={arm} example={example}', flush=True)
                execute([
                    RUNNER, '--source-root', str(BASE if arm == 'a' else ROOT),
                    '--fincore-root', str(FC), '--data-root', str(DATA),
                    '--selection', str(SELECTION), '--universe', 'fixed500',
                    '--example', example, '--profile', 'full', '--output', str(destination),
                ], destination.with_suffix('.log'))
                result = validate(destination, arm, example, bt_manifest, expected_head)
                peak = max(result['main_peak_working_set_bytes'], result['resource_peak_tree_rss_bytes'])
                print(json.dumps({
                    'pair': pair, 'arm': arm, 'example': example,
                    'wall_s': result['example_main_wall_ns'] / 1e9,
                    'cpu_s': result['example_main_process_cpu_ns'] / 1e9,
                    'peak_bytes': peak,
                }), flush=True)
                check_sources(expected_head)
        verification = TEMP / f'iteration49-g7-collection-p{pair}-verification.json'
        assert not verification.exists()
        verify_args = [
            VERIFIER,
            '--data-root', str(DATA),
            '--selection', str(SELECTION),
            '--universe', 'fixed500',
            '--output', str(verification),
        ]
        for arm, flag in (('a', '--baseline'), ('b', '--candidate')):
            for example in ('025', '026', '027'):
                control_pair = pair
                result_path = output(control_pair, arm, example)
                validate(result_path, arm, example, bt_manifest, expected_head)
                verify_args.extend((flag, f'{example}={result_path}'))
        check_sources(expected_head)
        execute(verify_args, verification.with_suffix('.log'))
        verified = read(verification)
        assert verified['input_universe'] == 'fixed500'
        assert verified['status'] == 'PASS' and verified['scope_complete']
        print(f'G7-collection pair {pair} COMPLETE OUTPUT PASS', flush=True)

if __name__ == '__main__':
    main()
