# Iteration 49 G9 static review

**Decision: GO_STATIC_REVIEW_ONLY.** Reviewed Fincore `dev` HEAD `4e01ac9f6f081f13acd60b45559119e1a5ed4a4f`, without imports, tests, lint, or benchmarks. The exact reviewed pins are:

- `fincore/factor_analysis/models.py`: `171d131fa97eb241d3eaa8c36694a8d99d3c26a4c1cb69adeb7d92ce73879f9c`
- `tests/factor_analysis/test_fingerprint_streaming.py`: `c9f6028dee313b4b8178a93d7f88f8a64e2bbbb26cffbb56243a5cc53c988411`
- `docs/plans/iteration49-g9-datetime-run-encoding.md`: `56ac01d66b82248556d906f3677f7fb943581c9db0d305a5db8e9ac46b10ebc1`

The run writer preserves v1 leaf framing: regular values use the existing timestamp tag, dtype unit, decimal `asi8` tick text, and timezone payload; NaT uses the existing `pandas-nat` envelope. Run detection only compares adjacent int64 ticks, so negative values and the NaT sentinel are not arithmetically transformed. Row order and separated runs remain intact; the length calculation and public fingerprint ID path are unchanged.

The routing threshold keeps chunks with fewer than eight rows and unique-heavy chunks on the existing vector writer. When the repeated path can run, the planned chunk size is at least eight rows, which bounds each maximum leaf frame to the one-MiB batch budget; repeated blocks and joined writer batches are also byte-capped, with the parts list capped by the entry budget. No full-column codes or persistent run cache are introduced.

The new tests compare full streamed bytes and resulting fingerprints with the unchanged legacy `_fingerprint_bytes` encoder. They cover UTC and named zones, ns/us/ms units, negative ticks, NaT and all-NaT runs, a forced cross-chunk repeated value, unique-heavy routing, both Series and DataFrame values, and bounded writes. The targeted router spies verify the new and legacy paths are actually taken. No concrete static blocker found. Root's functional QA and serial performance gate remain separate acceptance steps.
