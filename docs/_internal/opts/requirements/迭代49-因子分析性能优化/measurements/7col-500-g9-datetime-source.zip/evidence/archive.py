"""Archive already-completed G9 fixed-500 pairs; never runs an example."""
import hashlib
import io
import json
import re
import runpy
import statistics
import sys
import zipfile
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
DEST = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements"
PAIR_HELPER = ROOT / ".codex-tmp/iteration49_next_pairs.py"
PAIR_HELPER_SHA256 = "541b834cc57a93e807fd39a7d2c6c960caf78e2e70caa98bb348f884a1405cfb"
QA = ROOT / ".codex-tmp/iteration49-g9-source-qa.json"
REVIEW = ROOT / ".codex-tmp/iteration49-g9-static-review.md"
QA_LOG = ROOT / ".codex-tmp/iteration49-g9-fingerprint-pytest.log"
PAIR1_CONFIG = ROOT / ".codex-tmp/iteration49-g9-datetime-pair1-config.json"
PAIR23_CONFIG = ROOT / ".codex-tmp/iteration49-g9-datetime-pair23-config.json"
PAIR23_CONFIG_SHA256 = "9f565e4779fbf78b1dda66719f322f4ee4ab3af9480b3a5a8f163eb64ea9c3bb"
EXAMPLES = ("025", "026", "027")


def pin(raw):
    return {"size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def read(path):
    return Path(path).read_bytes()


def json_file(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def shared_config(config):
    result = dict(config)
    result["pairs"] = []
    return result


def archive(files, note):
    rows = [{"path": name, **pin(raw)} for name, raw in sorted(files.items())]
    manifest = json.dumps({"schema_version": 1, "note": note, "files": rows},
                          indent=2).encode("utf-8") + b"\n"
    out = io.BytesIO()
    members = {**files, "MANIFEST.json": manifest, "README.txt": note.encode("utf-8") + b"\n"}
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            z.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    result = out.getvalue()
    with zipfile.ZipFile(io.BytesIO(result)) as z:
        for row in rows:
            assert pin(z.read(row["path"])) == {k: row[k] for k in ("size_bytes", "sha256")}
    return result, {**pin(result), "payload_count": len(rows),
                    "manifest_sha256": pin(manifest)["sha256"]}


def main():
    assert len(sys.argv) in (2, 3), "usage: script.py CONFIG.json [archive-stem]"
    cfg_path = Path(sys.argv[1]).resolve(strict=True)
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    assert cfg.get("schema_version") == 1
    assert cfg.get("pairs") == [1, 2, 3], cfg.get("pairs")
    pair1_cfg, pair23_cfg = json_file(PAIR1_CONFIG), json_file(PAIR23_CONFIG)
    assert pair1_cfg.get("pairs") == [1] and pair23_cfg.get("pairs") == [2, 3]
    assert hashlib.sha256(read(PAIR23_CONFIG)).hexdigest() == PAIR23_CONFIG_SHA256
    assert shared_config(cfg) == shared_config(pair1_cfg) == shared_config(pair23_cfg)
    pairs = cfg["pairs"]
    assert hashlib.sha256(PAIR_HELPER.read_bytes()).hexdigest() == PAIR_HELPER_SHA256
    f = runpy.run_path(str(PAIR_HELPER), run_name="paired_summary_helpers")
    state = f["verified_sources"](ROOT, cfg)
    data = f["data_state"](cfg)
    f["check_data"](data)

    qa = json.loads(QA.read_text(encoding="utf-8"))
    review = read(REVIEW)
    qa_log = read(QA_LOG)
    assert (qa.get("round"), qa.get("exit_code"), qa.get("passed"), qa.get("failed"),
            qa.get("skipped")) == ("iteration49-g9-source-qa", 0, 65, 0, 0)
    assert pin(qa_log) == {k: qa["logfile"][k] for k in ("size_bytes", "sha256")}
    assert hashlib.sha256(review).hexdigest() == qa["independent_static_review_sha256"]
    for name, expected in qa["source_pins_after"].items():
        path = Path(name)
        assert pin(read(path)) == {k: expected[k] for k in ("size_bytes", "sha256")}, name
        assert qa["source_pins_before"][name] == expected

    output_root, prefix = Path(cfg["output_root"]), cfg["output_prefix"]
    records, verifiers, rawfiles = [], [], {}
    measurements = {ex: {} for ex in EXAMPLES}
    for pair in pairs:
        for example in EXAMPLES:
            measurements[example][pair] = {}
            for arm in f["ORDERS"][pair - 1]:
                out = output_root / f"{prefix}-p{pair}-{arm}-{example}"
                result_path = out / "result.json"
                result = f["validate_run"](result_path, arm, example, cfg, state, data)
                values = {
                    "wall_s": result["example_main_wall_ns"] / 1e9,
                    "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                    "peak_bytes": max(result["main_peak_working_set_bytes"],
                                      result["resource_peak_tree_rss_bytes"]),
                }
                measurements[example][pair][arm] = values
                records.append({"pair": pair, "arm": arm, "example": example, **values,
                                "phase_timers": result["phase_timers"],
                                "main_peak_working_set_bytes": result["main_peak_working_set_bytes"],
                                "resource_peak_tree_rss_bytes": result["resource_peak_tree_rss_bytes"]})
                rawfiles[f"raw/p{pair}/{arm}-{example}/result.json"] = read(result_path)
                rawfiles[f"raw/p{pair}/{arm}-{example}/run.log"] = read(out.with_suffix(".log"))

        verifier_path = output_root / f"{prefix}-p{pair}-verification.json"
        verifier = json.loads(verifier_path.read_text(encoding="utf-8"))
        assert verifier.get("status") == "PASS" and verifier.get("scope_complete") is True
        assert verifier.get("valid") is True and verifier.get("mode") == "ab-pair"
        assert set(verifier.get("comparisons", {})) == set(EXAMPLES)
        assert all(row.get("valid") is True for row in verifier["comparisons"].values())
        for side, arm in (("baseline", "a"), ("candidate", "b")):
            for example in EXAMPLES:
                expected = output_root / f"{prefix}-p{pair}-{arm}-{example}" / "example"
                actual = Path(verifier["runs"][side][example]["directory"])
                assert actual.resolve() == expected.resolve()
        rawfiles[f"raw/p{pair}/verification.json"] = read(verifier_path)
        rawfiles[f"raw/p{pair}/verification.log"] = read(verifier_path.with_suffix(".log"))
        verifiers.append({"pair": pair, "status": "PASS", "scope_complete": True,
                          "path": str(verifier_path), **pin(read(verifier_path))})

    metrics = {}
    for example, by_pair in measurements.items():
        metrics[example] = {}
        for key in ("wall_s", "cpu_s", "peak_bytes"):
            ratios = [by_pair[p]["b"][key] / by_pair[p]["a"][key] for p in pairs]
            gains = [1 / ratio for ratio in ratios]
            middle = statistics.median(ratios)
            metrics[example][key] = {
                "a_median": statistics.median(by_pair[p]["a"][key] for p in pairs),
                "b_median": statistics.median(by_pair[p]["b"][key] for p in pairs),
                "paired_b_over_a": ratios,
                "median_b_over_a": middle,
                "reduction_percent": 100 * (1 - middle),
                "paired_a_over_b": gains,
                "relative_dispersion": ((max(gains) - min(gains)) / statistics.median(gains)
                                        if len(gains) > 1 else None),
            }

    stem = sys.argv[2] if len(sys.argv) == 3 else "7col-500-g9-datetime"
    assert re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", stem), stem
    raw, rawmeta = archive(rawfiles, "G9 fixed-500 raw run results, logs and complete output verifiers.")
    sourcefiles = {
        "evidence/next_pairs.py": PAIR_HELPER.read_bytes(),
        "evidence/archive.py": Path(__file__).read_bytes(),
        "evidence/source-qa.json": QA.read_bytes(),
        "evidence/source-qa.log": qa_log,
        "evidence/static-review.md": review,
    }
    qa_cfg_path = Path(qa["pair_config"]["path"])
    assert hashlib.sha256(read(qa_cfg_path)).hexdigest() == qa["pair_config"]["sha256"]
    assert qa_cfg_path.resolve() == PAIR1_CONFIG.resolve()
    sourcefiles["evidence/config-pair1.json"] = read(PAIR1_CONFIG)
    sourcefiles["evidence/config-pair23.json"] = read(PAIR23_CONFIG)
    sourcefiles["evidence/config-all-analysis.json"] = cfg_path.read_bytes()
    for name in cfg["tool_pins"]:
        sourcefiles[name] = read(ROOT / name)
    fc_root = Path(cfg["fincore_candidate"]["root"])
    doc = "docs/plans/iteration49-g9-datetime-run-encoding.md"
    sourcefiles[f"fincore/candidate/{doc}"] = read(fc_root / doc)
    for key in ("backtrader_snapshot", "fincore_baseline"):
        sourcefiles[f"{key}/.iteration49-source.json"] = read(Path(cfg[key]["root"]) / ".iteration49-source.json")
    for name in cfg["fincore_candidate"].get("allowed_delta", {}):
        sourcefiles[f"fincore/baseline/{name}"] = read(state[2] / name)
        sourcefiles[f"fincore/candidate/{name}"] = read(fc_root / name)
    for name in cfg["fincore_candidate"].get("test_pins", {}):
        sourcefiles[f"qa-input/{name}"] = read(fc_root / name)
    source, srcmeta = archive(sourcefiles, "Measured G9 source delta and exact QA/review/tool/config evidence; not full-universe acceptance.")
    rawmeta["path"], srcmeta["path"] = stem + "-raw.zip", stem + "-source.zip"
    summary = {
        "schema": "iteration49.g9-paired-measurement.v1",
        "status": "PASS_OUTPUT_EQUIVALENCE_MEASUREMENT_ONLY",
        "counts": {"measured_processes": len(records), "unique_comparisons": 3 * len(pairs),
                   "complete_verifiers": len(verifiers)},
        "config": cfg,
        "execution_configs": {
            "pair1": {"path": str(PAIR1_CONFIG), **pin(read(PAIR1_CONFIG))},
            "pair23": {"path": str(PAIR23_CONFIG), **pin(read(PAIR23_CONFIG))},
            "all_pairs_analysis_only": {"path": str(cfg_path), **pin(cfg_path.read_bytes())},
        },
        "fixed_data_identity": data[2], "actual_runs": records,
        "verifiers": verifiers, "metrics": metrics,
        "raw_archive": rawmeta, "measured_source_archive": srcmeta,
        "limitations": ["Fixed-500 results do not establish 5471-symbol memory or speed targets.",
                        "Peak is max(main working-set high-water, sampled process-tree RSS).",
                        "phase_timers may include overlapping inclusive values; do not sum inclusive timers."],
    }
    outputs = {rawmeta["path"]: raw, srcmeta["path"]: source,
               stem + "-pairs.json": json.dumps(summary, indent=2).encode("utf-8") + b"\n"}
    assert all(not (DEST / name).exists() for name in outputs)
    for name, content in outputs.items():
        with (DEST / name).open("xb") as stream:
            stream.write(content)
    print(json.dumps({"metrics": metrics, "archives": [rawmeta, srcmeta]}, indent=2))


if __name__ == "__main__":
    main()
