Measured G9 source delta and exact QA/review/tool/config evidence; not full-universe acceptance.
