# Iteration 49 G9: bounded adjacent datetime run encoding

## Scope

The streamed fingerprint writer for timezone-aware datetime arrays currently
vector-formats and scatters every timestamp tick in each bounded chunk. This
round adds a chunk-local path for inputs with long adjacent runs of the same
timestamp. A run emits the same v1 timestamp (or pandas-nat) leaf frame once,
then repeats its length-prefixed bytes in original order. The existing vector
writer remains the path for short and unique-heavy chunks.

The change is internal to fincore/factor_analysis/models.py. The fingerprint
version, public APIs, length calculation, index handling, and datetime source
dtype remain unchanged. No timestamp values are sorted or deduplicated across
separated runs or chunks.

## Semantic and memory bounds

The run path compares adjacent signed int64 ticks for equality; it does not
subtract or normalize them. Thus negative pre-epoch ticks, each pandas unit,
timezone payload, and the int64 NaT sentinel keep their existing encoding.
Only the existing exact DatetimeArray route reaches this writer. Regular
timestamp leaves are built with the same v1 timestamp envelope and unit,
decimal tick, and timezone byte parts as the legacy encoder. NaT reuses the
legacy pandas-nat leaf. Repeating a frame preserves exact row order and
length-prefix bytes.

Run detection and output batching are chunk-local. A chunk uses the repeated
path only when it has at least eight rows and no more than one run per four
rows; unique-heavy chunks retain the vectorized writer. Run output is flushed
at the existing one-MiB leaf-batch budget, below the established eight-MiB
writer limit. Temporary run boundaries, encoded leaves, and repeated blocks
are discarded after each chunk. There is no full-column object conversion,
cross-column cache, or new fingerprint identifier.

## Regression coverage

The focused tests compare streamed bytes and final fingerprints with the
independent legacy _fingerprint_bytes encoder. Cases cover repeated and
non-adjacent timestamp runs, all-NaT input, negative ticks at ns/us/ms
resolution, UTC and America/New_York payloads, a run crossing a forced small
chunk boundary, unique-heavy vector-path routing, DataFrame and Series
payloads, and maximum writer-call size.

## Verification status

Implementation and focused tests are prepared on FinCore dev; no Python
command, import, test, lint, or benchmark has run in this round. Root's serial
performance work is active, so source QA and the counterbalanced 026 screen
remain pending until Root opens a QA slot. The earlier fixed-500 profile
reported seven datetime writer calls at 1.296 s self / 2.489 s cumulative.
Those are profile observations, not a projected saving; the maximum possible
self-time saving is limited and actual repeated-run gain must be measured.
No full-universe or fivefold claim is made.
