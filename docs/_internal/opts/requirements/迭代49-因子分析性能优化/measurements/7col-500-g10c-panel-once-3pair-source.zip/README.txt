G10c final measured source, tests, canonical runner/verifier, focused receipts and 96-regression plus three-period full-101 matrix evidence.
