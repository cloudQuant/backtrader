"""Archive already completed G10c fixed-500 and source-matrix evidence; never runs QA."""
import hashlib
import io
import json
import runpy
import statistics
import sys
import zipfile
from pathlib import Path

ROOT = Path("D:/source_code/backtrader")
CFG_PATH = ROOT / ".codex-tmp/iteration49-g10c-panel-once-pair1-config.json"
CFG_SHA256 = "e2efe1ffa90a8837a76f5b60e8d779e24ad81621430edbf68502b23c17885232"
SOURCE_QA = ROOT / ".codex-tmp/iteration49-g10c-source-qa.json"
PAIR23_CFG_PATH = ROOT / ".codex-tmp/iteration49-g10c-panel-once-pair23-config.json"
QA_ROOT = Path("D:/temp/iteration49-g10c-panel-once-qa")
REVIEW = ROOT / ".codex-tmp/iteration49-panel-once-final-hook-review.md"
REVIEW_SHA256 = "aa91d06f29760f0c2538bc9db7f4e974abebd21c3542a950b19bd728928d9db6"
PAIR_RUNNER = ROOT / ".codex-tmp/iteration49_g10_panel_once_pairs.py"
PAIR_HELPER = ROOT / ".codex-tmp/iteration49_next_pairs.py"
SOURCE_QA_RUNNER = ROOT / ".codex-tmp/iteration49_g10c_source_matrix.py"
RUNNER = "scripts/benchmark_factor_examples.py"
VERIFIER = "scripts/verify_factor_examples_benchmark.py"
EXAMPLES = ("025", "026", "027")
STEM = "7col-500-g10c-panel-once"
DEST = ROOT / "docs/_internal/opts/requirements/迭代49-因子分析性能优化/measurements"


def raw(path):
    return Path(path).read_bytes()


def pin(data):
    return {"size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def jread(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def add(files, name, path, expected=None):
    data = raw(path)
    if expected is not None:
        assert pin(data) == {key: expected[key] for key in ("size_bytes", "sha256")}, path
    files[name] = data
    return data


def zip_bytes(files, note):
    rows = [{"path": name, **pin(data)} for name, data in sorted(files.items())]
    manifest = json.dumps({"schema_version": 1, "note": note, "files": rows},
                          ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    members = {**files, "MANIFEST.json": manifest, "README.txt": note.encode("utf-8") + b"\n"}
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    blob = out.getvalue()
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        assert set(archive.namelist()) == set(members)
        for name, data in members.items():
            assert archive.read(name) == data
    return blob, {**pin(blob), "payload_count": len(rows),
                  "manifest_sha256": pin(manifest)["sha256"]}


def check_matrix_receipt(receipt, source_files):
    assert set(receipt["matrix"]) == {"320", "640", "1280"}
    matrix_rows = {}
    ids = list(range(1, 102))
    expected_lanes = {("native", "runnext"), ("native", "runonce"),
                      ("build", "runnext"), ("build", "runonce")}
    for periods, row in receipt["matrix"].items():
        path = Path(row["path"]).resolve(strict=True)
        data = raw(path)
        assert pin(data) == {key: row[key] for key in ("size_bytes", "sha256")}
        doc = json.loads(data)
        assert (doc.get("schema_version"), doc.get("acceptance_profile"), doc.get("status"),
                doc.get("periods"), doc.get("complete_registry_coverage")) == (
            2, "iteration49-single-class-modes", "PASS", int(periods), True)
        assert sorted(doc.get("alpha_ids", [])) == ids and len(doc.get("per_alpha", {})) == 101
        aggregate = doc.get("aggregate", {})
        assert (aggregate.get("alpha_count"), aggregate.get("engine_run_count"),
                aggregate.get("oracle_pass_count"), aggregate.get("finite_witness_count"),
                aggregate.get("lifecycle_pass_count"), aggregate.get("same_engine_build_pair_count"),
                aggregate.get("cross_engine_graph_pair_count"), aggregate.get("all_pass")) == (
            101, 4, 404, 404, 404, 202, 202, True)
        lanes = {(run.get("factor_mode"), run.get("engine"))
                 for run in doc.get("engine_runs", [])}
        assert lanes == expected_lanes
        for run in doc["engine_runs"]:
            assert run.get("alpha_ids") == doc["alpha_ids"]
            assert (run.get("oracle_pass_count"), run.get("finite_witness_count"),
                    run.get("lifecycle_pass_count")) == (101, 101, 101)
            assert run.get("broker") == {"submit": 0, "cancel": 0}
        source_files[f"matrix/alpha101-build-pair-T{periods}.json"] = data
        matrix_rows[periods] = {"path": str(path), **pin(data), "lanes": 4, "alphas_per_lane": 101}
    return matrix_rows


def check_verifier(path, pair, root, prefix):
    verifier = jread(path)
    assert (verifier.get("status"), verifier.get("valid"),
            verifier.get("scope_complete")) == ("PASS", True, True)
    assert set(verifier.get("comparisons", {})) == set(EXAMPLES)
    assert all(row.get("valid") is True for row in verifier["comparisons"].values())
    for side, arm in (("baseline", "a"), ("candidate", "b")):
        for example in EXAMPLES:
            run_pair = 1 if pair > 1 and example != "027" else pair
            expected_dir = root / f"{prefix}-p{run_pair}-{arm}-{example}" / "example"
            actual_dir = Path(verifier["runs"][side][example]["directory"])
            assert actual_dir.resolve() == expected_dir.resolve()
    return verifier


def check_partial(path, pair, canonical_path, canonical, root, prefix):
    partial = jread(path)
    assert (partial.get("status"), partial.get("valid"), partial.get("scope_complete"),
            partial.get("independent_scope_complete")) == ("PASS", True, False, True)
    assert partial.get("independent_examples") == ["027"]
    assert set(partial.get("comparisons", {})) == {"027"}
    assert partial["comparisons"]["027"].get("valid") is True
    assert set(partial.get("reused_controls", {})) == {"025", "026"}
    for example in ("025", "026"):
        control = partial["reused_controls"][example]
        assert control.get("source_pair") == 1 and control.get("comparison_valid") is True
        for side, arm in (("baseline", "a"), ("candidate", "b")):
            expected = root / f"{prefix}-p1-{arm}-{example}"
            assert Path(control[side]).resolve() == expected.resolve()
    canon_meta = partial.get("canonical_control_inclusive_verifier", {})
    assert canon_meta.get("sha256") == pin(raw(canonical_path))["sha256"]
    assert canon_meta.get("status") == canonical["status"] and canon_meta.get("scope_complete") is True
    current = partial.get("current_pair_027", {})
    for side, arm in (("baseline", "a"), ("candidate", "b")):
        expected = root / f"{prefix}-p{pair}-{arm}-027"
        assert Path(current[side]).resolve() == expected.resolve()
    return partial


def main():
    args = sys.argv[1:]
    assert args in ([], ["--include-pair23"]), "usage: script.py [--include-pair23]"
    include_pair23 = args == ["--include-pair23"]
    assert pin(raw(CFG_PATH))["sha256"] == CFG_SHA256
    cfg = jread(CFG_PATH)
    assert cfg["pairs"] == [1] and cfg["output_prefix"] == "iteration49-g10c-panel-once-500"
    assert pin(raw(REVIEW))["sha256"] == REVIEW_SHA256
    assert set(cfg["tool_pins"]) == {RUNNER, VERIFIER}

    # Reuse the already exercised source/data validators; this script itself does no runs.
    pair_api = runpy.run_path(str(PAIR_RUNNER), run_name="g10c_archive_pair_api")
    base_api = runpy.run_path(str(PAIR_HELPER), run_name="g10c_archive_base_api")
    assert hashlib.sha256(raw(PAIR_HELPER)).hexdigest() == pair_api["PAIR_HELPER_SHA256"]
    state = pair_api["source_state"](cfg, base_api)
    data_state = base_api["data_state"](cfg)
    base_api["check_data"](data_state)
    out_root = Path(cfg["output_root"]).resolve(strict=True)
    prefix = cfg["output_prefix"]
    pair23_cfg = None
    if include_pair23:
        pair23_cfg = jread(PAIR23_CFG_PATH)
        assert pair23_cfg["pairs"] == [2, 3]
        assert {key: value for key, value in pair23_cfg.items() if key != "pairs"} == {
            key: value for key, value in cfg.items() if key != "pairs"}
        assert pair_api["source_state"](pair23_cfg, base_api) == state
        assert base_api["data_state"](pair23_cfg) == data_state

    qa = jread(SOURCE_QA)
    assert qa.get("round") == "iteration49-g10c-panel-once-source-qa" and qa.get("exit_code") == 0
    assert qa.get("independent_static_review_sha256") == REVIEW_SHA256
    before, after = qa.get("source_pins_before", {}), qa.get("source_pins_after", {})
    assert before == after and before
    expected_pins = {**cfg["backtrader_candidate"]["allowed_delta"],
                     **cfg["backtrader_candidate"]["test_pins"], **cfg["tool_pins"]}
    assert after == {str(ROOT / name): value for name, value in expected_pins.items()}
    for name, expected in after.items():
        assert pin(raw(name)) == {key: expected[key] for key in ("size_bytes", "sha256")}, name
    stages = {row["stage"]: row for row in qa.get("stages", [])}
    assert set(stages) == {"regressions", "matrix"}
    regression, matrix_stage = stages["regressions"], stages["matrix"]
    assert (regression["tests"], regression["errors"], regression["failures"],
            regression["skipped"], regression["exit_code"]) == (96, 0, 0, 0, 0)
    assert (matrix_stage["tests"], matrix_stage["errors"], matrix_stage["failures"],
            matrix_stage["skipped"], matrix_stage["exit_code"]) == (3, 0, 0, 0, 0)

    source_files = {
        "evidence/config.json": raw(CFG_PATH),
        "evidence/source-qa.json": raw(SOURCE_QA),
        "evidence/source-qa-runner.py": raw(SOURCE_QA_RUNNER),
        "evidence/final-hook-review.md": raw(REVIEW),
        "evidence/pair-launcher.py": raw(PAIR_RUNNER),
        "evidence/pair-helper.py": raw(PAIR_HELPER),
        "evidence/archive-helper.py": raw(__file__),
    }
    if include_pair23:
        source_files["evidence/config-pair23.json"] = raw(PAIR23_CFG_PATH)
    source_qa_log = Path(qa["logfile"]["path"]).resolve(strict=True)
    add(source_files, "evidence/source-qa-combined.log", source_qa_log, qa["logfile"])
    for stage, row in stages.items():
        log = Path(row["logfile"]["path"]).resolve(strict=True)
        add(source_files, f"evidence/{stage}.log", log, row["logfile"])
        add(source_files, f"evidence/{stage}.xml", QA_ROOT / f"{stage}.xml")
    matrix_rows = check_matrix_receipt(qa, source_files)

    focus_context = cfg["qa_context"]["fresh_g10b_focus"]
    focus_path = Path(focus_context["receipt"]).resolve(strict=True)
    focus = jread(focus_path)
    assert (focus.get("status"), focus.get("exit_code"), focus.get("collected"),
            focus.get("passed"), focus.get("failed")) == ("PASS_FOCUSED_SOURCE_QA_ONLY", 0, 8, 8, 0)
    focus_bytes = raw(focus_path)
    assert hashlib.sha256(focus_bytes).hexdigest() == focus_context["receipt_sha256"]
    focus_log = Path(focus_context["log"]).resolve(strict=True)
    focus_log_bytes = raw(focus_log)
    assert pin(focus_log_bytes) == {"size_bytes": cfg["qa_context"]["focused_log_size_bytes"],
                                    "sha256": focus_context["log_sha256"]}
    assert hashlib.sha256(focus_log_bytes).hexdigest() == focus.get("log_sha256")
    source_files["evidence/older-pre-guard-focused-8.json"] = focus_bytes
    source_files["evidence/older-pre-guard-focused-8.log"] = focus_log_bytes
    old_review_context = cfg["qa_context"]["static_review"]
    old_review = Path(old_review_context["path"]).resolve(strict=True)
    add(source_files, "evidence/older-g10b-static-review.md", old_review,
        {"size_bytes": cfg["qa_context"]["static_review_size_bytes"],
         "sha256": old_review_context["sha256"]})
    guard_context = cfg["qa_context"]["final_hook_guard"]
    guard_path = Path(guard_context["receipt"]).resolve(strict=True)
    guard = jread(guard_path)
    assert (guard.get("status"), guard.get("exit_code"), guard.get("collected"),
            guard.get("passed"), guard.get("failed")) == ("PASS_FOCUSED_SOURCE_QA_ONLY", 0, 3, 3, 0)
    assert guard.get("source_pins") == {
        "backtrader/research/operators.py": cfg["backtrader_candidate"]["allowed_delta"][
            "backtrader/research/operators.py"]["sha256"],
        "tests/unit/test_factor_research_panel_once.py": cfg["backtrader_candidate"]["test_pins"][
            "tests/unit/test_factor_research_panel_once.py"]["sha256"],
    }
    add(source_files, "evidence/final-hook-focused-3.json", guard_path,
        {"size_bytes": guard_context["size_bytes"], "sha256": guard_context["sha256"]})
    guard_log = ROOT / guard["log_path"]
    guard_log_bytes = raw(guard_log)
    assert hashlib.sha256(guard_log_bytes).hexdigest() == guard["log_sha256"]
    source_files["evidence/final-hook-focused-3.log"] = guard_log_bytes

    snapshot_paths = {
        "baseline/backtrader/.iteration49-source.json": Path(cfg["backtrader_snapshot"]["root"]) / ".iteration49-source.json",
        "baseline/fincore/.iteration49-source.json": Path(cfg["fincore_snapshot"]["root"]) / ".iteration49-source.json",
    }
    for name, path in snapshot_paths.items():
        source_files[name] = raw(path)
    base_root, base_manifest = state[1], state[2]["files"]
    candidate_root = state[3]
    preserved = cfg["backtrader_candidate"].get("preserved_unrelated", {})
    for name, expected in cfg["backtrader_candidate"]["allowed_delta"].items():
        candidate = raw(candidate_root / name)
        assert pin(candidate) == {"size_bytes": expected["size_bytes"],
                                  "sha256": expected["sha256"].lower()}
        if name in preserved:
            assert pin(candidate) == {"size_bytes": preserved[name]["size_bytes"],
                                      "sha256": preserved[name]["sha256"].lower()}
            source_files[f"context/preserved-unrelated/{name}"] = candidate
        else:
            baseline = raw(base_root / name)
            assert pin(baseline) == base_manifest[name]
            source_files[f"source/baseline/{name}"] = baseline
            source_files[f"source/candidate/{name}"] = candidate
    for name, expected in cfg["backtrader_candidate"]["test_pins"].items():
        candidate = raw(candidate_root / name)
        assert pin(candidate) == {"size_bytes": expected["size_bytes"],
                                  "sha256": expected["sha256"].lower()}
        source_files[f"tests/{name}"] = candidate
    for name, expected in cfg["tool_pins"].items():
        tool = raw(ROOT / name)
        assert pin(tool) == {"size_bytes": expected["size_bytes"],
                             "sha256": expected["sha256"].lower()}
        source_files[f"tools/{name}"] = tool

    results, measurements, raw_files, verifiers = [], {example: {} for example in EXAMPLES}, {}, []
    run_specs = [(1, example, arm) for example in EXAMPLES for arm in ("a", "b")]
    if include_pair23:
        run_specs.extend((pair, "027", arm) for pair in (2, 3)
                         for arm in pair_api["ORDERS"][pair])
    for pair, example, arm in run_specs:
        run_cfg = cfg if pair == 1 else pair23_cfg
        run_dir = out_root / f"{prefix}-p{pair}-{arm}-{example}"
        result = pair_api["validate_run"](run_dir, arm, example, run_cfg,
                                           base_api, state, data_state)
        measured = {"wall_s": result["example_main_wall_ns"] / 1e9,
                    "cpu_s": result["example_main_process_cpu_ns"] / 1e9,
                    "peak_bytes": max(result["main_peak_working_set_bytes"],
                                      result["resource_peak_tree_rss_bytes"])}
        assert all(value > 0 for value in measured.values())
        measurements[example].setdefault(pair, {})[arm] = measured
        results.append({"pair": pair, "example": example, "arm": arm,
                        "expected_engine": result["expected_engine"],
                        "observed_engine": result["observed_engine"], **measured,
                        "phase_timers": result["phase_timers"]})
        raw_files[f"runs/p{pair}/{arm}-{example}/result.json"] = raw(run_dir / "result.json")
        raw_files[f"runs/p{pair}/{arm}-{example}/summary.json"] = raw(run_dir / "example/summary.json")
        raw_files[f"runs/p{pair}/{arm}-{example}/run.log"] = raw(run_dir.with_suffix(".log"))

    pair_ids = (1, 2, 3) if include_pair23 else (1,)
    for pair in pair_ids:
        suffix = "verification.json" if pair == 1 else f"p{pair}-control-inclusive-verification.json"
        verification_path = out_root / (f"{prefix}-p1-verification.json" if pair == 1 else
                                        f"{prefix}-{suffix}")
        verification = check_verifier(verification_path, pair, out_root, prefix)
        raw_files[f"verification/p{pair}/complete-control-inclusive.json"] = raw(verification_path)
        raw_files[f"verification/p{pair}/complete-control-inclusive.log"] = raw(verification_path.with_suffix(".log"))
        verifier_row = {"pair": pair, "path": str(verification_path), **pin(raw(verification_path)),
                        "status": verification["status"], "scope_complete": True,
                        "independent_examples": list(EXAMPLES) if pair == 1 else ["027"]}
        if pair > 1:
            partial_path = out_root / f"{prefix}-p{pair}-partial-scope.json"
            partial = check_partial(partial_path, pair, verification_path, verification,
                                    out_root, prefix)
            raw_files[f"verification/p{pair}/partial-027.json"] = raw(partial_path)
            verifier_row["partial_027"] = {"path": str(partial_path),
                                             **pin(raw(partial_path)),
                                             "scope_complete": False,
                                             "independent_scope_complete": True}
        verifiers.append(verifier_row)

    metric_rows = {}
    for example, pairs in measurements.items():
        actual_pairs = sorted(pairs)
        assert actual_pairs == ([1, 2, 3] if include_pair23 and example == "027" else [1])
        metric_rows[example] = {"actual_pairs": actual_pairs, "per_pair": pairs, "metrics": {}}
        for key in ("wall_s", "cpu_s", "peak_bytes"):
            ratios = [pairs[pair]["b"][key] / pairs[pair]["a"][key] for pair in actual_pairs]
            median = statistics.median(ratios)
            dispersion = ((max(ratios) - min(ratios)) / median if len(ratios) > 1 else None)
            metric_rows[example]["metrics"][key] = {
                "baseline_median": statistics.median(pairs[pair]["a"][key] for pair in actual_pairs),
                "candidate_median": statistics.median(pairs[pair]["b"][key] for pair in actual_pairs),
                "paired_candidate_over_baseline_b_over_a": ratios,
                "median_b_over_a": median,
                "reduction_percent": 100 * (1 - median),
                "relative_dispersion_of_b_over_a": dispersion,
                "dispersion_limit": 0.05 if example == "027" and len(ratios) == 3 else None,
                "within_5pct_dispersion": (dispersion <= 0.05
                                            if example == "027" and len(ratios) == 3 else None),
            }

    label = STEM + ("-3pair" if include_pair23 else "")
    raw_zip, raw_meta = zip_bytes(raw_files,
        "G10c fixed-500 actual runs, logs, summaries and verifier receipts; pair-2/3 controls are reused, not recounted as runs.")
    source_zip, source_meta = zip_bytes(source_files,
        "G10c final measured source, tests, canonical runner/verifier, focused receipts and 96-regression plus three-period full-101 matrix evidence.")
    raw_meta["path"], source_meta["path"] = label + "-raw.zip", label + "-source.zip"
    summary = {
        "schema": "iteration49.g10c-final-fixed500.v1",
        "status": "PASS_COMPLETE_OUTPUT_EQUIVALENCE_MEASUREMENT_ONLY",
        "measurement_scope": {"pairs": list(pair_ids), "new_comparisons": 3 + (2 if include_pair23 else 0),
                               "pair2_pair3_independent_example": ["027"] if include_pair23 else []},
        "counts": {"actual_processes": len(results), "unique_new_comparisons": 3 + (2 if include_pair23 else 0),
                   "canonical_verifier_documents": len(verifiers),
                   "complete_independent_verifiers": 1,
                   "partial_independent_027_verifiers": 2 if include_pair23 else 0,
                   "reused_025_026_control_comparisons": 4 if include_pair23 else 0},
        "source_acceptance": {
            "regression_stage": {key: regression[key] for key in
                                  ("tests", "errors", "failures", "skipped", "exit_code")},
            "alpha101_matrix_stage": {key: matrix_stage[key] for key in
                                       ("tests", "errors", "failures", "skipped", "exit_code")},
            "matrix_records": matrix_rows,
            "focused_receipts": {
                "pre_guard_g10b_8": {"collected": 8, "passed": 8,
                                      "source_stage": "historical, before the guard"},
                "final_hook_guard_3": {"collected": 3, "passed": 3,
                                       "source_stage": "separate final guard focus"},
                "aggregation": "Separate receipts; not a combined 11-case final suite.",
            },
            "receipt": {"path": str(SOURCE_QA), **pin(raw(SOURCE_QA))},
            "log": {"path": str(source_qa_log), **pin(raw(source_qa_log))},
        },
        "fixed_500": {"symbols": 500, "dates": 243,
                      "selection_sha256": cfg["data"]["selection_sha256"]},
        "source_and_tools": {
            "backtrader_baseline": cfg["backtrader_snapshot"],
            "backtrader_candidate": cfg["backtrader_candidate"],
            "fincore_snapshot": cfg["fincore_snapshot"],
            "tool_pins": cfg["tool_pins"],
            "review": {"path": str(REVIEW), **pin(raw(REVIEW))},
        },
        "actual_runs": results,
        "verifiers": verifiers,
        "paired_metrics": metric_rows,
        "limitations": [
            "025/026 each have one independently measured pair; reused pair-1 controls in pair 2/3 are not new comparisons.",
            "027 compares runnext with runonce; only final-G10c-source pairs are included in its B/A dispersion.",
            "Without --include-pair23, 027 dispersion is null because only pair 1 is available.",
            "A/B 027 timing is descriptive for the engine change; output verification is the correctness claim.",
            "This archive does not establish the 5471-symbol 80%-faster or <=1 GB full-universe targets.",
            "Historical 8-case pre-guard and separate 3-case hook receipts are not a combined 11-case final suite.",
        ],
        "raw_archive": raw_meta,
        "source_archive": source_meta,
    }
    outputs = {raw_meta["path"]: raw_zip, source_meta["path"]: source_zip,
               label + ".json": json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"}
    DEST.mkdir(parents=True, exist_ok=True)
    assert all(not (DEST / name).exists() for name in outputs)
    for name, content in outputs.items():
        with (DEST / name).open("xb") as stream:
            stream.write(content)


if __name__ == "__main__":
    main()
