# Iteration 49 G10 final feed-hook guard: static review

**Verdict: GO_STATIC_REVIEW_ONLY.** No blocking semantic issue found in the narrow change. No tests, imports, lint, or benchmarks were run as part of this review.

Reviewed current pins:

- `backtrader/research/operators.py`: 91,758 bytes, SHA-256 `15335c4bd93c5bcad7e7480d499907cdfddf215234002ceb734dadd5710f864f`
- `tests/unit/test_factor_research_panel_once.py`: 15,208 bytes, SHA-256 `118b38d05f3bbc9ee3d2f3b028a4dc7a3bad4dfcf22bca742146fe521b9be2ec`
- Frozen G10b comparison: `.codex-tmp/iteration49-g10b-before-hook-guard/operators.py` (`409c777e45ba56d02b8c083c443c1828b6af44fd33e9fd5e2579599aaa8e4c0a`) and `test_factor_research_panel_once.py` (`055f78b0bb39c3d9d039e88778f90b2b36f409851812990b29bab619d5f1b135`).

The production delta is limited to capturing the standard `PandasData.advance`, `_tick_nullify`, and `_tick_fill` implementations and checking them when `_panel_once_feed_shape` establishes eligibility. Exact `PandasData` type and the raw instance dictionary are already required there. An instance-level shadow of any of the three methods therefore fails eligibility; replacing a method on `PandasData` or an inherited class is detected by comparing the resolved method to its captured identity. The optimization then returns the existing miss sentinel and uses Cerebro's ordinary callback path, where `advance` and its tick hooks retain their normal per-bar dispatch. With the standard implementations unchanged, the exact research-feed fast path remains eligible and keeps its existing cursor synchronization.

The three added parameter cases install an instance override for each hook on a real aligned feed, assert the panel kernel is not entered, assert the replacement is called, and compare the complete graph against the ordinary runnext reference. The test also checks lifecycle coverage and that optimized once ranges remain empty for the fallback run. The existing four-lane test continues to assert all three kernels are entered for ordinary feeds. Class-function replacement is guarded directly by resolved-identity checks; the new cases exercise the instance-shadow branch.

This review covers only feed-hook replacement behavior and the directly related tests. It does not establish the pending full-matrix performance result.
