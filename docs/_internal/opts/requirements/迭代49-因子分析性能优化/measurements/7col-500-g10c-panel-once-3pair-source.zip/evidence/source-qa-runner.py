"""Run the selected regression and complete Alpha101 matrix after serial timing."""
import hashlib
import json
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('D:/source_code/backtrader')
OUT = Path('D:/temp/iteration49-g10c-panel-once-qa')
CFG = ROOT / '.codex-tmp/iteration49-g10c-panel-once-pair1-config.json'
REVIEW = ROOT / '.codex-tmp/iteration49-panel-once-final-hook-review.md'
RECEIPT = ROOT / '.codex-tmp/iteration49-g10c-source-qa.json'

def pin(path):
    raw = path.read_bytes()
    return {'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def main():
    cfg = json.loads(CFG.read_text(encoding='utf-8'))
    candidate = cfg['backtrader_candidate']
    expected = {**candidate['allowed_delta'], **candidate['test_pins'], **cfg['tool_pins']}
    before = {str(ROOT / p): pin(ROOT / p) for p in expected}
    assert before == {str(ROOT / p): v for p, v in expected.items()}
    assert not OUT.exists() and not RECEIPT.exists()
    OUT.mkdir()
    env = dict(os.environ, PYTHONUTF8='1', BT_ALPHA101_BUILD_PAIR='1',
               BT_ALPHA101_BUILD_PAIR_EVIDENCE=str(OUT / 'matrix'))
    for key in ('BT_ALPHA101_NATIVE_BATCHES', 'BT_ALPHA101_NATIVE_IDS', 'BACKTRADER_USE_INSTALLED'):
        env.pop(key, None)
    stages = [
        ('regressions', ['tests/unit/test_factor_research_operators.py',
                         'tests/unit/test_factor_research_binding_clock.py',
                         'tests/unit/test_factor_research_isolation.py',
                         'tests/unit/test_factor_research_inputs.py',
                         'tests/unit/test_factor_research_representatives.py']),
        ('matrix', ['tests/integration/test_alpha101_native_matrix.py::test_alpha101_native_build_pair_graph_matrix']),
    ]
    results = []
    for stage, tests in stages:
        logfile, xmlfile = OUT / (stage + '.log'), OUT / (stage + '.xml')
        command = [sys.executable, '-m', 'pytest', '-p', 'no:asyncio', '-o', 'addopts=',
                   '-q', '--junitxml=' + str(xmlfile), *tests]
        if stage == 'matrix':
            # The three independent T parameters write distinct evidence files.
            # Functional QA only; no performance measurements overlap this run.
            command[3:3] = ['-n', '3', '--dist', 'load']
        print('START ' + stage, flush=True)
        start = time.perf_counter()
        with logfile.open('xb') as stream:
            completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        suites = ET.parse(xmlfile).getroot().iter('testsuite') if xmlfile.exists() else []
        totals = {key: 0 for key in ('tests', 'errors', 'failures', 'skipped')}
        for suite in suites:
            for key in totals:
                totals[key] += int(suite.attrib.get(key, 0))
        row = {'stage': stage, 'command': command, 'exit_code': completed.returncode,
               'wall_s': time.perf_counter() - start, **totals,
               'logfile': {'path': str(logfile), **pin(logfile)}}
        results.append(row)
        print(json.dumps(row), flush=True)
        if completed.returncode:
            break
    after = {name: pin(Path(name)) for name in before}
    assert after == before
    combined = OUT / 'combined.log'
    combined.write_bytes(b''.join((OUT / (row['stage'] + '.log')).read_bytes() for row in results))
    receipt = {'round': 'iteration49-g10c-panel-once-source-qa',
               'exit_code': max(row['exit_code'] for row in results), 'stages': results,
               'source_pins_before': before, 'source_pins_after': after,
               'independent_static_review_sha256': pin(REVIEW)['sha256'],
               'logfile': {'path': str(combined), **pin(combined)},
               'matrix': {}}
    if receipt['exit_code'] == 0:
        for periods in (320, 640, 1280):
            path = OUT / 'matrix' / ('alpha101-build-pair-T%d.json' % periods)
            data = json.loads(path.read_text(encoding='utf-8'))
            assert data['status'] == 'PASS' and data['complete_registry_coverage'] is True
            assert data['aggregate']['all_pass'] is True
            receipt['matrix'][str(periods)] = {'path': str(path), **pin(path)}
    RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'receipt': str(RECEIPT), **pin(RECEIPT)}), flush=True)
    return receipt['exit_code']

if __name__ == '__main__':
    sys.exit(main())
