A is verified Backtrader snapshot 3ba75fe5eb910c87624ce03350745a3efd708a74; B is live dev a47ae1e508351ab2d9e825d4965ebe6d4ce55ee0. Both use the same fincore snapshot 4e01ac9f6f081f13acd60b45559119e1a5ed4a4f. B's recorded source map also contains a pre-existing, unrelated run_daily.py change, excluded from this delivery.

Six actual 027 result/log pairs form three unique comparisons. Each of the three full PASS verifiers reuses the same G6 p3 B 025/026 controls; those are reused control slots, not additional G3 runs or comparisons. The archive includes candidate and baseline source pins, the exact pair helper and both accepted QA logs. Earlier failed focus logs remain outside this acceptance record.

三组 027 墙钟方向均改善；中位 B/A=0.836611 （-16.34%），相对离散度 5.27% 超过 5% 阈值；不宣称稳定加速通过。
No full-101 matrix was run. Peak is max(main-process working set, sampled process-tree RSS).
