"""Complete two serial 027 pairs; reuse unchanged 025/026 verifier controls."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('D:/source_code/backtrader')
TEMP = Path('D:/temp')
BASE = Path('D:/temp/iteration49-g2d-backtrader-3ba75fe5e')
FC = Path('D:/temp/iteration49-g6-fincore-4e01ac9')
RUNNER = ROOT/'scripts/benchmark_factor_examples.py'
VERIFIER = ROOT/'scripts/verify_factor_examples_benchmark.py'
SEL = ROOT/'docs/_internal/opts/requirements/迭代49-因子分析性能优化/benchmark-500-7col.json'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
pins = {p:digest(p) for p in (RUNNER, VERIFIER, ROOT/'backtrader/research/operators.py',
                            ROOT/'tests/unit/test_factor_presence_relation_plan.py', SEL)}
refs = {arm:read(TEMP/f'iteration49-g3-provenance-screen-{arm}-027/result.json') for arm in ('a','b')}
screen = read(TEMP/'iteration49-g3-provenance-screen-verification.json')
assert screen['status']=='PASS' and screen['scope_complete'] and screen['valid']
def check(r, arm):
    assert r['status']=='COMPLETED' and r['example']=='027' and r['profile']=='full'
    assert r['source_or_input_changes']==[] and r['summary_check_errors']==[]
    assert r['example_exit_code']==r['runner_exit_code']==0
    for key in ('backtrader_source','fincore_source','data_identity'):
        assert r[key+'_before']==r[key+'_after']==refs[arm][key+'_before'], key
    for key in ('backtrader_files_before','fincore_files_before','data_files_before','example_cli_arguments','runner_sha256'):
        if key=='example_cli_arguments':
            # Only the output directory changes between fresh runs.
            left,right=list(r[key]),list(refs[arm][key])
            for args in (left,right):
                assert args.count('--output-dir')==1
                args[args.index('--output-dir')+1]='OUTPUT'
            assert left==right
        else: assert r[key]==refs[arm][key], key
    assert (r['summary']['symbols'],r['summary']['dates'])==(500,243)
def call(args, log):
    assert not log.exists()
    with log.open('xb') as f:
        proc=subprocess.run([sys.executable,'-X','utf8',*map(str,args)],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    assert proc.returncode==0, str(log)
for pair,order in ((2,('b','a')),(3,('a','b'))):
    for arm in order:
        assert all(digest(p)==v for p,v in pins.items())
        out=TEMP/f'iteration49-g3-provenance-p{pair}-{arm}-027'
        assert not out.exists()
        call([RUNNER,'--source-root',BASE if arm=='a' else ROOT,'--fincore-root',FC,
              '--data-root',ROOT/'tests/datas/a_stocks','--selection',SEL,'--example','027',
              '--profile','full','--output',out],out.with_suffix('.log'))
        r=read(out/'result.json'); check(r,arm)
        assert all(digest(p)==v for p,v in pins.items())
        print(json.dumps({'pair':pair,'arm':arm,'wall_s':r['example_main_wall_ns']/1e9,
                          'cpu_s':r['example_main_process_cpu_ns']/1e9,
                          'peak_bytes':max(r['main_peak_working_set_bytes'],r['resource_peak_tree_rss_bytes'])}),flush=True)
    out=TEMP/f'iteration49-g3-provenance-p{pair}-verification.json'
    args=[VERIFIER,'--output',out]
    for arm,flag in (('a','--baseline'),('b','--candidate')):
        for ex in ('025','026'):
            args += [flag,f'{ex}=D:/temp/iteration49-g6-utc-500-p3-b-{ex}']
        args += [flag,f'027=D:/temp/iteration49-g3-provenance-p{pair}-{arm}-027']
    call(args,out.with_suffix('.log'))
    v=read(out)
    assert v['status']=='PASS' and v['valid'] and v['scope_complete']
    print(f'PAIR {pair} FULL OUTPUT PASS (025/026 unchanged reused controls)',flush=True)
