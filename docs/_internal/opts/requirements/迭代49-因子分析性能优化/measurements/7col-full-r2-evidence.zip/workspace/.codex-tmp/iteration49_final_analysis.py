#!/usr/bin/env python3
"""Summarize R3 fixed500/full-stage receipts; this is not an acceptance gate."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

LIMIT_BYTES = 1_000_000_000
EXAMPLES = ("025", "026", "027")
ARMS = ("baseline", "candidate")
PHASE_GROUPS = {
    "load_daily_panel": "load",
    "align_to_grid": "alignment_preload", "feed_preload": "alignment_preload",
    "engine_runonce": "engine", "engine_runnext": "engine",
    "collection": "collection_finish", "strategy_init": "collection_finish",
    "collect_grid_points": "collection_finish", "strategy_stop": "collection_finish",
    "sink_finalize": "collection_finish",
    "fincore_evaluate": "fincore_evaluation",
    "evaluate_frames": "evaluation_html_report", "html_report": "evaluation_html_report",
    "fincore_positions": "evaluation_html_report",
    "fincore_positions_float64_fastpath": "evaluation_html_report",
    "evaluation_export": "csv_chart_export", "evaluation_charts": "csv_chart_export",
    "dataframe_to_csv": "csv_chart_export",
    "cerebro_run": "other_small",
}
GROUPS = ("load", "alignment_preload", "engine", "collection_finish",
          "fincore_evaluation", "evaluation_html_report", "csv_chart_export", "other_small")


def ratio_summary(rows, metric):
    pairs = []
    for pair, sides in sorted(rows.items()):
        base, cand = sides["baseline"][metric], sides["candidate"][metric]
        ratio = None if not base else cand / base
        pairs.append({"pair": pair, "baseline": base, "candidate": cand,
                      "candidate_over_baseline": ratio,
                      "reduction_percent": None if ratio is None else (1.0 - ratio) * 100.0})
    ratios = [row["candidate_over_baseline"] for row in pairs if row["candidate_over_baseline"] is not None]
    med = statistics.median(ratios) if ratios else None
    dispersion = (max(ratios) - min(ratios)) / med if med and len(ratios) > 1 else None
    return {"pair_values": pairs,
            "baseline_median": statistics.median([x["baseline"] for x in pairs]) if pairs else None,
            "candidate_median": statistics.median([x["candidate"] for x in pairs]) if pairs else None,
            "candidate_over_baseline_median": med,
            "ratio_range_over_median": dispersion}


def phase_breakdown(result):
    timers = result.get("phase_timers") or {}
    if not isinstance(timers, dict):
        timers = {}
    grouped = {name: 0 for name in GROUPS}
    total = 0
    for label, row in timers.items():
        if not isinstance(row, dict):
            continue
        ns = row.get("wall_exclusive_ns")
        if type(ns) is not int or ns < 0:
            continue
        total += ns
        grouped[PHASE_GROUPS.get(label, "other_small")] += ns
    main = result.get("example_main_wall_ns")
    return {"exclusive_by_stage_ns": grouped, "phase_exclusive_sum_ns": total,
            "main_wall_ns": main,
            "unattributed_remainder_ns": main - total if type(main) is int else None,
            "method": "sum wall_exclusive_ns only; inclusive timers are not added"}


def read_run(row):
    path = Path(row["result"]).resolve(strict=True)
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if row.get("sha256") != digest:
        raise ValueError("raw result hash differs from receipt: " + str(path))
    result = json.loads(raw.decode("utf-8"))
    main_wall = result.get("example_main_wall_ns")
    main_cpu = result.get("example_main_process_cpu_ns")
    cli_wall = result.get("cli_total_wall_ns")
    cli_cpu = result.get("cli_total_process_cpu_ns")
    main_peak = result.get("main_peak_working_set_bytes")
    tree_peak = result.get("resource_peak_tree_rss_bytes")
    peak = max(main_peak, tree_peak) if type(main_peak) is int and type(tree_peak) is int else None
    receipt_metrics_match = (row.get("wall_ns"), row.get("cpu_ns"), row.get("peak_rss_bytes")) == (
        main_wall, main_cpu, peak)
    return {"pair": row.get("pair"), "arm": row.get("arm"), "example": row.get("example"),
            "result": str(path), "result_sha256": digest, "receipt_metrics_match": receipt_metrics_match,
            "wall_ns": main_wall, "cpu_ns": main_cpu, "main_peak_working_set_bytes": main_peak,
            "resource_peak_tree_rss_bytes": tree_peak, "recorded_conservative_peak_bytes": peak,
            "cli_total_wall_ns": cli_wall, "cli_wall_over_main_ns": cli_wall - main_wall
            if type(cli_wall) is int and type(main_wall) is int else None,
            "cli_total_cpu_ns": cli_cpu, "cli_cpu_over_main_ns": cli_cpu - main_cpu
            if type(cli_cpu) is int and type(main_cpu) is int else None,
            "phase_breakdown": phase_breakdown(result),
            "html_report_note": "html_report includes factor evaluation and rendering; positions sub-timers are grouped here using exclusive time only."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path, help="R3 fixed500-stage.json or full-stage.json")
    parser.add_argument("--output", required=True, type=Path, help="new JSON analysis file")
    args = parser.parse_args()
    receipt_path = args.receipt.resolve(strict=True)
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    schema = receipt.get("schema")
    if schema == "iteration49.final-fixed500.v1":
        stage = "fixed500"
    elif schema == "iteration49.final-all.v1":
        stage = "all"
    else:
        raise ValueError("unsupported R3 stage receipt schema")
    raw_rows = receipt.get("runs")
    if not isinstance(raw_rows, list):
        raise ValueError("receipt has no run rows")
    runs = [read_run(row) for row in raw_rows]
    by_example = {}
    for example in EXAMPLES:
        indexed = {}
        for run in runs:
            if run["example"] != example:
                continue
            key = (run["pair"], run["arm"])
            if key in indexed:
                raise ValueError("duplicate run row for %s %r" % (example, key))
            indexed[key] = run
        pair_ids = sorted({pair for pair, _arm in indexed})
        paired = {pair: {arm: indexed[(pair, arm)] for arm in ARMS}
                  for pair in pair_ids if all((pair, arm) in indexed for arm in ARMS)}
        by_example[example] = {metric: ratio_summary(paired, metric)
                               for metric in ("wall_ns", "cpu_ns", "recorded_conservative_peak_bytes")}
        wall = by_example[example]["wall_ns"]
        ratio = wall["candidate_over_baseline_median"]
        wall["final_80_percent_target"] = (
            "NOT_FINAL_FIXED500" if stage == "fixed500" else
            ("UNOBSERVED" if ratio is None else "PASS" if ratio <= 0.20 else "FAIL")
        )
    candidate_runs = [run for run in runs if run["arm"] == "candidate"]
    candidate_peaks = [run["recorded_conservative_peak_bytes"] for run in candidate_runs
                       if type(run["recorded_conservative_peak_bytes"]) is int]
    memory_status = ("NOT_FINAL_FIXED500" if stage == "fixed500" else
                     ("UNOBSERVED" if not candidate_peaks or len(candidate_peaks) != len(candidate_runs) else
                      "PASS" if all(value <= LIMIT_BYTES for value in candidate_peaks) else "FAIL"))
    output = {"schema": "iteration49.final-analysis.v1", "stage": stage,
              "receipt": str(receipt_path), "receipt_status": receipt.get("status"),
              "acceptance_scope": "analysis only; receipt PASS covers source/output integrity, not timing or memory",
              "timing_target": {"per_example_reduction_percent": 80,
                                "status": "NOT_FINAL_FIXED500" if stage == "fixed500" else "see per-example results"},
              "memory_target": {"candidate_peak_limit_bytes": LIMIT_BYTES, "status": memory_status,
                                "max_recorded_candidate_peak_bytes": max(candidate_peaks) if candidate_peaks else None},
              "per_example": by_example, "runs": runs,
              "phase_note": "exclusive timer sums are mutually exclusive; remainder is main wall minus all reported exclusive phase rows"}
    destination = args.output.resolve()
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(output, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
    print("analysis written: %s" % destination)


if __name__ == "__main__":
    main()
