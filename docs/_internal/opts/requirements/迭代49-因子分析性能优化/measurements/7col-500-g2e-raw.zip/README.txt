G2e raw fixed-500 evidence: 26 actual example runs, five complete-output pair verifiers, and their logs. Pairs 4-5 measure 025/026; their 027 verifier slots reuse pair 3 outputs.
