"""Synthetic shape tests for the Root-only write-observation helper."""

from __future__ import annotations

import importlib.util
from pathlib import Path
from types import SimpleNamespace


_HELPER_PATH = Path(__file__).with_name("i51_root_readonly_write_observation_20261027.py")
_SPEC = importlib.util.spec_from_file_location("i51_write_observation", _HELPER_PATH)
assert _SPEC is not None and _SPEC.loader is not None
_HELPER = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_HELPER)


class _Trader:
    def __init__(self, counts=None):
        self.counts = counts or {"order_insert": 0, "order_action": 0}

    def get_session_state(self):
        return {"request_counts": dict(self.counts)}


class _Store:
    def __init__(self, rows=(), *, counts=None, rejected=0, trader=None):
        self._api = SimpleNamespace(trader_client=trader or _Trader(counts))
        self.rows = tuple(rows)
        self.rejected = rejected

    def get_command_health(self):
        return {"rejected_market_data_only": self.rejected}

    def get_ctp_session_state(self):
        return self._api.trader_client.get_session_state()

    def registered_sim_dispatch_history(self):
        return self.rows


class _Broker:
    def __init__(self, submit=0, cancel=0, batch=0):
        self.counts = (submit, cancel, batch)

    def get_market_data_only_audit(self):
        submit, cancel, batch = self.counts
        return {
            "submit_rejected": submit,
            "cancel_rejected": cancel,
            "batch_cancel_rejected": batch,
            "total_rejected": submit + cancel + batch,
        }


def _row(sequence, operation, status):
    return SimpleNamespace(sequence=sequence, operation=operation, status=status)


def test_empty_observation_reports_zero_only_for_available_valid_sources():
    broker, store = _Broker(), _Store()
    token, before = _HELPER.begin_observation(broker, store)
    before["sdk_requests"]["order_insert"] = 99
    result = _HELPER.finish_observation(token, broker, store)
    assert result["before"]["sdk_requests"]["order_insert"] == 0
    assert result["before"]["dispatch"]["valid"] is True
    assert result["same_objects"] is True
    assert result["observations_complete"] is True
    assert result["counters_nondecreasing"] is True
    assert result["zero_write_activity"] is True
    assert set(result["after"]["dispatch"]) == {
        "available",
        "valid",
        "insert_known",
        "insert_unknown",
        "cancel_known",
        "cancel_unknown",
        "highwater_sequence",
    }


def test_missing_surface_is_unavailable_and_never_projected_as_zero():
    broker = object()
    store = _Store()
    store.get_ctp_session_state = None
    store.registered_sim_dispatch_history = None
    token, before = _HELPER.begin_observation(broker, store)
    result = _HELPER.finish_observation(token, broker, store)
    assert before["broker_rejections"]["available"] is False
    assert before["broker_rejections"]["submit_rejected"] is None
    assert before["sdk_requests"]["available"] is False
    assert before["sdk_requests"]["order_insert"] is None
    assert before["dispatch"]["available"] is False
    assert before["dispatch"]["insert_known"] is None
    assert result["zero_write_activity"] is False


def test_malformed_boolean_or_negative_counts_fail_closed():
    broker, store = _Broker(), _Store(counts={"order_insert": True, "order_action": 0})
    token, before = _HELPER.begin_observation(broker, store)
    assert before["sdk_requests"]["available"] is True
    assert before["sdk_requests"]["valid"] is False
    assert before["sdk_requests"]["order_insert"] is None

    malformed_broker = SimpleNamespace(
        get_market_data_only_audit=lambda: {
            "submit_rejected": -1,
            "cancel_rejected": 0,
            "batch_cancel_rejected": 0,
            "total_rejected": -1,
        }
    )
    invalid = _HELPER._broker_rejections(malformed_broker)
    assert invalid["available"] is True
    assert invalid["valid"] is False
    assert invalid["total_rejected"] is None

    for operation, status in (("submit", "KNOWN"), ([], "KNOWN"), ("insert", {})):
        malformed_dispatch = _HELPER._dispatch_counts(
            SimpleNamespace(
                registered_sim_dispatch_history=lambda operation=operation, status=status: (
                    _row(1, operation, status),
                )
            )
        )
        assert malformed_dispatch["available"] is True
        assert malformed_dispatch["valid"] is False
        assert malformed_dispatch["insert_known"] is None


def test_known_and_unknown_dispatches_are_aggregated_without_rows():
    broker, store = _Broker(), _Store(
        rows=(_row(1, "insert", "KNOWN"), _row(2, "cancel", "UNKNOWN"))
    )
    token, before = _HELPER.begin_observation(broker, store)
    assert before["dispatch"]["insert_known"] == 1
    assert before["dispatch"]["insert_unknown"] == 0
    assert before["dispatch"]["cancel_known"] == 0
    assert before["dispatch"]["cancel_unknown"] == 1
    assert "order_ref" not in before["dispatch"]
    result = _HELPER.finish_observation(token, broker, store)
    assert result["zero_delta"] is True
    assert result["zero_write_activity"] is False


def test_in_run_counter_increase_is_observed_as_nonzero_delta():
    broker, store = _Broker(), _Store()
    token, before = _HELPER.begin_observation(broker, store)
    store.rows = (_row(1, "insert", "KNOWN"), _row(2, "cancel", "UNKNOWN"))
    store._api.trader_client.counts = {"order_insert": 1, "order_action": 1}

    result = _HELPER.finish_observation(token, broker, store)
    assert before["dispatch"]["highwater_sequence"] == 0
    assert result["observations_complete"] is True
    assert result["counters_nondecreasing"] is True
    assert result["zero_baseline"] is True
    assert result["zero_after"] is False
    assert result["zero_delta"] is False
    assert result["zero_write_activity"] is False


def test_counter_reset_and_replaced_client_fail_same_run_comparison():
    broker = _Broker()
    trader = _Trader({"order_insert": 4, "order_action": 2})
    store = _Store(counts=trader.counts, trader=trader)
    token, before = _HELPER.begin_observation(broker, store)
    trader.counts = {"order_insert": 0, "order_action": 2}
    result = _HELPER.finish_observation(token, broker, store)
    assert before["sdk_requests"]["valid"] is True
    assert result["counters_nondecreasing"] is False
    assert result["zero_write_activity"] is False

    other_store = _Store(trader=trader)
    replaced = _HELPER.finish_observation(token, broker, other_store)
    assert replaced["same_objects"] is False
    assert replaced["after"] is None
    assert replaced["zero_write_activity"] is False


def test_unchanged_nonzero_baseline_has_zero_observed_delta_only():
    broker = _Broker(submit=1)
    trader = _Trader({"order_insert": 3, "order_action": 1})
    store = _Store(
        rows=(_row(1, "insert", "KNOWN"),),
        counts=trader.counts,
        rejected=2,
        trader=trader,
    )
    token, before = _HELPER.begin_observation(broker, store)
    result = _HELPER.finish_observation(token, broker, store)
    assert before["dispatch"]["insert_known"] == 1
    assert result["zero_baseline"] is False
    assert result["zero_after"] is False
    assert result["counters_nondecreasing"] is True
    assert result["zero_delta"] is True
    assert result["zero_write_activity"] is False
