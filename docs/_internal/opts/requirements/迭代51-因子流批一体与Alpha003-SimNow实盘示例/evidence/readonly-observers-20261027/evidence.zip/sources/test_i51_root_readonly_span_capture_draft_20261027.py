"""UNEXECUTED synthetic sketches for the Root observer integration."""

import sys
from types import SimpleNamespace

import pytest

from i51_root_readonly_span_capture_draft_20261027 import (
    invoke_with_readonly_span_observation,
)


class _Observer:
    def begin_observation(self, broker, store):
        return (broker, store, store.count), {"count": store.count}

    def finish_observation(self, token, broker, store):
        return {
            "same_objects": broker is token[0] and store is token[1],
            "before": token[2],
            "after": store.count,
        }


@pytest.mark.parametrize("raises", (False, True))
def test_exact_cerebro_run_span_is_finished_without_serializing_objects(
    monkeypatch, raises
):
    store = SimpleNamespace(count=0)
    broker = SimpleNamespace(store=store)

    class Cerebro:
        def __init__(self):
            self._broker = broker

        def run(self):
            store.count += 1
            if raises:
                raise RuntimeError("synthetic")
            return "completed"

    monkeypatch.setitem(sys.modules, "backtrader.cerebro", SimpleNamespace(Cerebro=Cerebro))
    cerebro = Cerebro()

    def _unrelated_prelude():
        assert sys.getprofile() is not None

    def run_live():
        _unrelated_prelude()
        return cerebro.run()

    sink = {}
    if raises:
        with pytest.raises(RuntimeError):
            invoke_with_readonly_span_observation(run_live, _Observer(), sink)
    else:
        assert invoke_with_readonly_span_observation(run_live, _Observer(), sink) == "completed"
    assert sink["status"] == "FINISHED"
    assert sink["before"]["count"] == 0
    assert sink["after"]["same_objects"] is True
    assert sink["after"]["before"] == 0
    assert sink["after"]["after"] == 1
    assert not any(key in sink for key in ("broker", "store", "token", "exception"))
    assert sys.getprofile() is None
