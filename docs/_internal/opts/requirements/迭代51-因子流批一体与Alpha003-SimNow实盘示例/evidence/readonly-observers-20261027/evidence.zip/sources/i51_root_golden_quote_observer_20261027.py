"""Bounded quote-source observation for the Iteration 51 golden run.

Consumes Store ticks only. It never constructs feeds, bars, factors, clocks,
authenticated market-data identities, or trading permission. Its result is
QUOTE_SOURCE_QUALIFICATION_ONLY, not AC19 or full-factor acceptance.
"""

from __future__ import annotations

import math
import time
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from typing import Any, Mapping


_MAX_SECONDS = 180.0
_MIN_SECONDS = 60.0
_MAX_AGE_SECONDS = 60.0
_MAX_FUTURE_SKEW_SECONDS = 0.0
_POLL_PAUSE_SECONDS = 0.05
_SOURCE_CODES = frozenset(
    {
        "CTP_FACTOR_SOURCE_TRADING_DAY_INVALID",
        "CTP_FACTOR_SOURCE_PLAN_INVALID",
        "CTP_FACTOR_SOURCE_CLOCK_DOMAIN_INVALID",
        "CTP_FACTOR_SOURCE_PRODUCT_INVALID",
        "CTP_FACTOR_SOURCE_BINDING_INVALID",
        "CTP_FACTOR_SOURCE_RAW_TICK_MISSING",
        "CTP_FACTOR_SOURCE_CALLBACK_GENERATION_UNBOUND",
        "CTP_FACTOR_SOURCE_GENERATION_MISMATCH",
        "CTP_FACTOR_SOURCE_CALLBACK_RECEIPT_INVALID",
        "CTP_FACTOR_SOURCE_ROUTE_MISMATCH",
        "CTP_FACTOR_SOURCE_TIME_FIELDS_INVALID",
        "CTP_FACTOR_SOURCE_RAW_EVENT_CONFLICT",
        "CTP_FACTOR_SOURCE_SESSION_MISMATCH",
        "CTP_FACTOR_SOURCE_TIME_CONFLICT",
        "CTP_FACTOR_SOURCE_PLAN_MEMBER_MISSING",
    }
)
_BAD_QUOTE = frozenset(
    {
        "LAST_NONFINITE_OR_MISSING",
        "LAST_NONPOSITIVE",
        "BID_NONFINITE_OR_MISSING",
        "BID_NONPOSITIVE",
        "ASK_NONFINITE_OR_MISSING",
        "ASK_NONPOSITIVE",
        "BID_SIZE_NONFINITE_OR_MISSING",
        "BID_SIZE_NONPOSITIVE",
        "ASK_SIZE_NONFINITE_OR_MISSING",
        "ASK_SIZE_NONPOSITIVE",
        "CROSSED_BOOK",
        "SOURCE_EVENT_STALE",
        "SOURCE_EVENT_FUTURE",
        "CALLBACK_RECEIPT_STALE",
        "CALLBACK_RECEIPT_FUTURE",
        "CALLBACK_RECEIPT_TIME_UNREPRESENTABLE",
    }
)


def _source_code(error: BaseException) -> str:
    code = getattr(error, "code", None)
    return code if type(code) is str and code in _SOURCE_CODES else "UNRECOGNIZED_SOURCE_GUARD_ERROR"


def _number(value: Any):
    if type(value) not in (int, float):
        return None
    try:
        value = float(value)
    except (OverflowError, ValueError):
        return None
    return value if math.isfinite(value) else None


def _timestamp(value: float):
    try:
        return datetime.fromtimestamp(value, timezone.utc).isoformat(timespec="milliseconds")
    except (OverflowError, OSError, ValueError):
        return None


def _sample(projection, values, eligible: bool, categories, actual_session):
    return {
        "callback_sequence": projection.callback_sequence,
        "event_time_utc": projection.event_time_utc.astimezone(timezone.utc).isoformat(
            timespec="milliseconds"
        ),
        "callback_received_time_utc": _timestamp(projection.callback_received_wall_time),
        "planned_close_time_utc": (
            projection.planned_close_time.astimezone(timezone.utc).isoformat(
                timespec="milliseconds"
            )
            if projection.planned_close_time is not None
            else None
        ),
        "session_date": actual_session[0].isoformat(),
        "session_segment": projection.session_segment or actual_session[1],
        "common_grid_slot_available": projection.planned_close_time is not None,
        "exchange_id_source": projection.exchange_id_source,
        **values,
        "quote_eligible": eligible,
        "eligibility_categories": tuple(sorted(categories)),
    }


def _refresh_witness_freshness(state, observed_at: float) -> int:
    """Recheck retained quote witnesses at the instant qualification is tested."""
    fresh_count = 0
    for sample, (event_timestamp, receipt_timestamp) in zip(
        state["witnesses"], state["witness_times"]
    ):
        source_age = observed_at - event_timestamp
        receipt_age = observed_at - receipt_timestamp
        is_fresh = (
            -_MAX_FUTURE_SKEW_SECONDS <= source_age <= _MAX_AGE_SECONDS
            and -_MAX_FUTURE_SKEW_SECONDS <= receipt_age <= _MAX_AGE_SECONDS
        )
        sample["fresh_at_qualification_check"] = is_fresh
        sample["source_age_seconds_at_qualification_check"] = round(source_age, 3)
        sample["callback_receipt_age_seconds_at_qualification_check"] = round(
            receipt_age, 3
        )
        fresh_count += int(is_fresh)
    state["fresh_witness_count"] = fresh_count
    return fresh_count


def observe_golden_quote_sources(
    store,
    plan,
    active_targets,
    *,
    clock_domain_id: str,
    expected_md_generation: int,
    trader_trading_day: date,
):
    """Observe live quotes for the READY plan's 3–5 active golden targets.

    The caller supplies the already-bound clock domain, MD generation and
    Trader day. This helper does not read config or environment values and does
    not stop, release, or disconnect the caller-owned Store.
    """
    result = {
        "evidence_level": "QUOTE_SOURCE_QUALIFICATION_ONLY",
        "status": "BLOCKED_INPUT",
        "error_code": None,
        "ac19_accepted": False,
        "full_factor_acceptance": False,
        "metadata_field_permission": "UNOBSERVED",
        "limits": {
            "maximum_duration_seconds": _MAX_SECONDS,
            "minimum_observation_seconds": _MIN_SECONDS,
            "maximum_source_age_seconds": _MAX_AGE_SECONDS,
            "maximum_future_skew_seconds": _MAX_FUTURE_SKEW_SECONDS,
            "poll_pause_seconds": _POLL_PAUSE_SECONDS,
        },
        "active_target_count": 0,
        "full_selected_target_count": 0,
        "expected_md_generation": None,
        "trader_trading_day": None,
        "elapsed_seconds": 0.0,
        "source_guard_errors": {},
        "store_errors": {},
        "targets": [],
        "limitations": (
            "NO_AUTHENTICATED_MD_IDENTITY",
            "NO_WIRE_CALLBACK_CONTINUITY_PROOF",
            "NO_FEED_BAR_OR_FACTOR_ACCEPTANCE",
            "NO_FULL_SESSION_OR_DAY_COVERAGE",
            "NO_TRADING_PERMISSION",
        ),
    }

    try:
        from backtrader.feeds.ctp_factor_source import (
            CtpFactorSourceBinding,
            CtpFactorSourceCalendar,
            CtpFactorSourceError,
            project_ctp_factor_tick,
        )
        from backtrader.feeds.futures_main_contract import ProductKey
    except Exception:
        result["error_code"] = "PRODUCTION_SOURCE_UNAVAILABLE"
        return result

    if (
        type(clock_domain_id) is not str
        or not clock_domain_id.strip()
        or type(expected_md_generation) is not int
        or expected_md_generation <= 0
        or type(trader_trading_day) is not date
        or not isinstance(plan, Mapping)
    ):
        result["error_code"] = "OBSERVER_INPUT_INVALID"
        return result
    result["expected_md_generation"] = expected_md_generation
    result["trader_trading_day"] = trader_trading_day.isoformat()

    if (
        getattr(store, "provider", None) != "ctp"
        or getattr(store, "backend", None) != "direct"
        or getattr(store, "registered_sim_route_id", None) != "simnow-registered-v1"
        or getattr(store, "is_connected", None) is not True
    ):
        result["status"] = "BLOCKED_STORE_READ"
        result["error_code"] = "STORE_NOT_READY_DIRECT_CTP"
        return result

    try:
        manifest = plan.get("manifest")
        if (
            plan.get("selection_source") != "ctp_query_snapshot_equal_weight_v1"
            or getattr(manifest, "status", None) != "READY"
        ):
            raise ValueError

        full_products = tuple(plan.get("full_products", plan.get("products", ())))
        full_targets = tuple(plan.get("full_selected_targets", plan.get("targets", ())))
        full_routes = dict(plan.get("full_routes", plan.get("routes", {})))
        full_p2t = dict(plan.get("full_target_by_product", plan.get("target_by_product", {})))
        full_t2p = dict(plan.get("full_product_by_target", plan.get("product_by_target", {})))
        full_grid = plan.get("full_grid", plan.get("grid"))
        active_grid = plan.get("grid")
        active_products = tuple(plan.get("products", ()))
        active_targets_plan = tuple(plan.get("targets", ()))
        active_routes = dict(plan.get("routes", {}))
        requested = tuple(active_targets)
        manifest_routes = dict(manifest.selected_mapping())
        manifest_products = tuple(manifest.target_products)

        if (
            not full_products
            or any(not isinstance(product, ProductKey) for product in full_products)
            or len(set(full_products)) != len(full_products)
            or any(type(target) is not str or not target for target in full_targets)
            or full_targets != tuple(full_p2t.get(product) for product in full_products)
            or len(set(full_targets)) != len(full_targets)
            or set(full_t2p) != set(full_targets)
            or any(full_t2p.get(target) != product for product, target in zip(full_products, full_targets))
            or set(full_routes) != set(full_products)
            or full_routes != manifest_routes
            or set(manifest_products) != set(full_products)
            or len(manifest_products) != len(set(manifest_products))
            or getattr(full_grid, "status", None) != "READY"
            or not getattr(full_grid, "minutes", ())
            or set(getattr(full_grid, "target_products", ())) != set(full_products)
            or not 3 <= len(requested) <= 5
            or any(type(target) is not str or not target for target in requested)
            or len(requested) != len(set(requested))
            or not set(requested).issubset(full_targets)
            or requested != active_targets_plan
            or set(active_products) != {full_t2p[target] for target in requested}
            or len(active_products) != len(set(active_products))
            or tuple(plan["product_by_target"].get(target) for target in requested)
            != tuple(full_t2p[target] for target in requested)
            or set(active_routes) != {full_t2p[target] for target in requested}
            or any(active_routes.get(full_t2p[t]) != full_routes.get(full_t2p[t]) for t in requested)
            or getattr(active_grid, "status", None) != "READY"
            or not getattr(active_grid, "minutes", ())
            or set(getattr(active_grid, "target_products", ()))
            != {full_t2p[target] for target in requested}
            or (plan.get("golden_targets") is not None and tuple(plan["golden_targets"]) != requested)
        ):
            raise ValueError

        calendars = plan.get("session_calendars")
        exchanges = {full_t2p[target].exchange_id for target in requested}
        if not isinstance(calendars, Mapping):
            raise ValueError
        active_calendars = {exchange: calendars[exchange] for exchange in exchanges}
        calendar = CtpFactorSourceCalendar.from_grid(active_grid, clock_domain_id, active_calendars)
        expected_source = getattr(store, "registered_sim_tick_source", None)
        if type(expected_source) is not str or not expected_source:
            result["error_code"] = "STORE_SOURCE_IDENTITY_UNAVAILABLE"
            return result

        states = []
        aliases = set()
        for target in requested:
            product = full_t2p[target]
            instrument, exchange = full_routes[product], product.exchange_id
            if (
                type(instrument) is not str
                or not instrument
                or instrument != instrument.strip()
                or "." in instrument
                or type(exchange) is not str
                or not exchange
                or exchange != exchange.strip().upper()
            ):
                raise ValueError
            alias = f"{instrument}.{exchange}"
            if alias in aliases:
                raise ValueError
            aliases.add(alias)
            binding = CtpFactorSourceBinding(
                calendar, target, product, instrument, exchange,
                trader_trading_day, expected_md_generation
            )
            states.append(
                {
                    "target_id": target,
                    "product_id": product.product_id,
                    "instrument_id": instrument,
                    "exchange_id": exchange,
                    "alias": alias,
                    "calendar_sha256": binding.calendar_hash,
                    "binding": binding,
                    "subscribed": False,
                    "polls": 0,
                    "callbacks": 0,
                    "projected": 0,
                    "eligible": 0,
                    "categories": Counter(),
                    "monotonic": {key: True for key in ("sequence", "event_time", "receipt_wall", "receipt_mono")},
                    "previous": None,
                    "first": None,
                    "last": None,
                    "witnesses": [],
                    "witness_times": [],
                    "fresh_witness_count": 0,
                }
            )
    except CtpFactorSourceError as error:
        result["status"] = "BLOCKED_SOURCE_BINDING"
        result["error_code"] = _source_code(error)
        return result
    except Exception:
        result["error_code"] = "PLAN_VALIDATION_FAILED"
        return result

    result["active_target_count"] = len(states)
    result["full_selected_target_count"] = len(full_targets)
    source_errors, store_errors = Counter(), Counter()
    start = time.monotonic()
    deadline = start + _MAX_SECONDS
    fatal_code, fatal_status = None, None
    for state in states:
        if time.monotonic() >= deadline:
            fatal_code, fatal_status = "OBSERVER_DEADLINE_EXCEEDED", "INCOMPLETE_OBSERVATION"
            break
        try:
            store.subscribe(state["alias"])
            state["subscribed"] = True
        except CtpFactorSourceError as error:
            fatal_code = _source_code(error)
            source_errors[fatal_code] += 1
            fatal_status = "BLOCKED_SOURCE_VALIDATION"
            break
        except Exception:
            fatal_code, fatal_status = "STORE_SUBSCRIBE_FAILED", "BLOCKED_STORE_READ"
            store_errors[fatal_code] += 1
            break
        if time.monotonic() >= deadline:
            fatal_code, fatal_status = "OBSERVER_DEADLINE_EXCEEDED", "INCOMPLETE_OBSERVATION"
            break

    observation_start = time.monotonic() if fatal_code is None else None
    while fatal_code is None:
        for state in states:
            if time.monotonic() >= deadline:
                break
            state["polls"] += 1
            try:
                tick = store.poll_tick(state["alias"])
            except CtpFactorSourceError as error:
                fatal_code = _source_code(error)
                source_errors[fatal_code] += 1
                fatal_status = "BLOCKED_SOURCE_VALIDATION"
                break
            except Exception:
                fatal_code, fatal_status = "STORE_POLL_FAILED", "BLOCKED_STORE_READ"
                store_errors[fatal_code] += 1
                break
            if time.monotonic() >= deadline:
                fatal_code, fatal_status = "OBSERVER_DEADLINE_EXCEEDED", "INCOMPLETE_OBSERVATION"
                break
            if tick is None:
                continue
            state["callbacks"] += 1
            if (
                getattr(tick, "source", None) != expected_source
                or getattr(tick, "symbol", None) != state["alias"]
            ):
                fatal_code, fatal_status = (
                    "REGISTERED_SIM_ROUTE_IDENTITY_MISMATCH", "BLOCKED_SOURCE_VALIDATION"
                )
                source_errors[fatal_code] += 1
                break
            try:
                projection = project_ctp_factor_tick(state["binding"], tick)
            except CtpFactorSourceError as error:
                fatal_code = _source_code(error)
                source_errors[fatal_code] += 1
                fatal_status = "BLOCKED_SOURCE_VALIDATION"
                break
            except Exception:
                fatal_code, fatal_status = "PROJECTION_FAILED", "BLOCKED_SOURCE_VALIDATION"
                source_errors[fatal_code] += 1
                break

            try:
                actual_session = state["binding"].calendar.session_for(
                    state["binding"].product,
                    projection.event_time_utc,
                    state["binding"].trader_trading_day,
                )
            except CtpFactorSourceError as error:
                fatal_code = _source_code(error)
                source_errors[fatal_code] += 1
                fatal_status = "BLOCKED_SOURCE_VALIDATION"
                break
            if actual_session is None or (
                projection.session_segment is not None
                and projection.session_segment != actual_session[1]
            ) or (
                projection.planned_close_time is not None
                and projection.session_segment is None
            ):
                fatal_code, fatal_status = (
                    "CTP_FACTOR_SOURCE_SESSION_MISMATCH",
                    "BLOCKED_SOURCE_VALIDATION",
                )
                source_errors[fatal_code] += 1
                break

            raw_session = getattr(tick, "ctp_raw_tick", None)
            raw_session = raw_session if isinstance(raw_session, Mapping) else {}
            try:
                action_day = datetime.strptime(raw_session.get("ActionDay"), "%Y%m%d").date()
            except (TypeError, ValueError):
                fatal_code, fatal_status = (
                    "CTP_FACTOR_SOURCE_TIME_FIELDS_INVALID",
                    "BLOCKED_SOURCE_VALIDATION",
                )
                source_errors[fatal_code] += 1
                break
            selected_action_days = state["binding"].calendar.action_days_by_product_day.get(
                (state["binding"].product, state["binding"].trader_trading_day), frozenset()
            )
            local_event_day = projection.event_time_utc.astimezone(
                timezone(timedelta(hours=8))
            ).date()
            if (
                action_day not in selected_action_days
                or action_day not in {actual_session[0], local_event_day}
            ):
                fatal_code, fatal_status = (
                    "CTP_FACTOR_SOURCE_SESSION_MISMATCH",
                    "BLOCKED_SOURCE_VALIDATION",
                )
                source_errors[fatal_code] += 1
                break

            state["projected"] += 1
            current = (
                projection.callback_sequence,
                projection.event_time_utc,
                projection.callback_received_wall_time,
                projection.callback_received_monotonic_ns,
            )
            previous = state["previous"]
            names = ("sequence", "event_time", "receipt_wall", "receipt_mono")
            if previous is not None:
                for index, (name, value, prior) in enumerate(zip(names, current, previous)):
                    out_of_order = value <= prior if index == 0 else value < prior
                    if out_of_order:
                        state["monotonic"][name] = False
                        fatal_code = (
                            "CALLBACK_SEQUENCE_NOT_MONOTONIC"
                            if index == 0
                            else "EVENT_TIME_NOT_MONOTONIC"
                            if index == 1
                            else "RECEIPT_WALL_TIME_NOT_MONOTONIC"
                            if index == 2
                            else "RECEIPT_MONOTONIC_NOT_MONOTONIC"
                        )
                        source_errors[fatal_code] += 1
                        fatal_status = "BLOCKED_SOURCE_VALIDATION"
                        break
                if fatal_code is not None:
                    break
            state["previous"] = current

            raw = getattr(tick, "ctp_raw_tick", None)
            raw = raw if isinstance(raw, Mapping) else {}
            values = {
                "last": _number(raw.get("LastPrice")),
                "bid": _number(getattr(tick, "bid_price", None)),
                "ask": _number(getattr(tick, "ask_price", None)),
                "bid_size": _number(getattr(tick, "bid_volume", None)),
                "ask_size": _number(getattr(tick, "ask_volume", None)),
                "cumulative_volume": _number(raw.get("Volume")),
                "volume_delta": _number(getattr(tick, "volume", None)),
            }
            categories = set()
            for field in ("last", "bid", "ask", "bid_size", "ask_size"):
                if values[field] is None:
                    categories.add(field.upper() + "_NONFINITE_OR_MISSING")
                elif values[field] <= 0.0:
                    categories.add(field.upper() + "_NONPOSITIVE")
            if values["bid"] is not None and values["ask"] is not None and values["bid"] > values["ask"]:
                categories.add("CROSSED_BOOK")
            if values["cumulative_volume"] is None:
                categories.add("CUMULATIVE_VOLUME_NONFINITE_OR_MISSING")
            elif values["cumulative_volume"] < 0.0:
                categories.add("CUMULATIVE_VOLUME_NEGATIVE")
            if values["volume_delta"] is None:
                categories.add("VOLUME_DELTA_NONFINITE_OR_MISSING")
            elif values["volume_delta"] < 0.0:
                categories.add("VOLUME_DELTA_NEGATIVE")

            now = time.time()
            event_age = now - projection.event_time_utc.timestamp()
            receipt_age = now - projection.callback_received_wall_time
            if event_age > _MAX_AGE_SECONDS:
                categories.add("SOURCE_EVENT_STALE")
            if event_age < -_MAX_FUTURE_SKEW_SECONDS:
                categories.add("SOURCE_EVENT_FUTURE")
            if receipt_age > _MAX_AGE_SECONDS:
                categories.add("CALLBACK_RECEIPT_STALE")
            if receipt_age < -_MAX_FUTURE_SKEW_SECONDS:
                categories.add("CALLBACK_RECEIPT_FUTURE")
            if _timestamp(projection.callback_received_wall_time) is None:
                categories.add("CALLBACK_RECEIPT_TIME_UNREPRESENTABLE")
            eligible = not categories.intersection(_BAD_QUOTE)
            state["categories"].update(categories)
            sample = _sample(projection, values, eligible, categories, actual_session)
            if state["first"] is None:
                state["first"] = sample
            state["last"] = sample
            if eligible:
                state["eligible"] += 1
                if len(state["witnesses"]) < 2:
                    state["witnesses"].append(dict(sample))
                    state["witness_times"].append(
                        (
                            projection.event_time_utc.timestamp(),
                            projection.callback_received_wall_time,
                        )
                    )
                else:
                    state["witnesses"][1] = dict(sample)
                    state["witness_times"][1] = (
                        projection.event_time_utc.timestamp(),
                        projection.callback_received_wall_time,
                    )

        if fatal_code is not None:
            break
        if time.monotonic() >= deadline:
            fatal_code, fatal_status = "OBSERVER_DEADLINE_EXCEEDED", "INCOMPLETE_OBSERVATION"
            break
        qualification_wall_time = time.time()
        for state in states:
            _refresh_witness_freshness(state, qualification_wall_time)
        qualified = all(
            state["callbacks"] >= 2
            and state["projected"] == state["callbacks"]
            and state["eligible"] >= 1
            and state["fresh_witness_count"] >= 1
            and all(state["monotonic"].values())
            for state in states
        )
        if time.monotonic() - observation_start >= _MIN_SECONDS and qualified:
            result["status"] = "QUALIFIED"
            break
        remaining = deadline - time.monotonic()
        if remaining <= 0.0:
            break
        time.sleep(min(_POLL_PAUSE_SECONDS, remaining))

    result["elapsed_seconds"] = round(max(0.0, time.monotonic() - start), 3)
    result["source_guard_errors"] = {
        code: source_errors[code] for code in sorted(source_errors)
    }
    result["store_errors"] = {code: store_errors[code] for code in sorted(store_errors)}
    if fatal_code is not None:
        result["status"], result["error_code"] = fatal_status, fatal_code
    elif result["status"] != "QUALIFIED":
        result["status"] = "INCOMPLETE_OBSERVATION"
        result["error_code"] = "OBSERVATION_REQUIREMENTS_NOT_MET"

    result["targets"] = [
        {
            "target_id": state["target_id"],
            "product_id": state["product_id"],
            "instrument_id": state["instrument_id"],
            "exchange_id": state["exchange_id"],
            "alias": state["alias"],
            "calendar_sha256": state["calendar_sha256"],
            "subscribed": state["subscribed"],
            "poll_count": state["polls"],
            "callback_count": state["callbacks"],
            "projected_count": state["projected"],
            "quote_eligible_count": state["eligible"],
            "fresh_witness_count_at_qualification_check": state["fresh_witness_count"],
            "sequence_monotonic": state["monotonic"]["sequence"],
            "event_time_monotonic": state["monotonic"]["event_time"],
            "receipt_wall_time_monotonic": state["monotonic"]["receipt_wall"],
            "receipt_monotonic_ns_monotonic": state["monotonic"]["receipt_mono"],
            "quote_categories": {
                code: state["categories"][code] for code in sorted(state["categories"])
            },
            "first": state["first"],
            "last": state["last"],
            "witnesses": state["witnesses"],
            "qualified": (
                state["callbacks"] >= 2
                and state["projected"] == state["callbacks"]
                and state["eligible"] >= 1
                and state["fresh_witness_count"] >= 1
                and all(state["monotonic"].values())
            ),
        }
        for state in states
    ]
    return result


__all__ = ["observe_golden_quote_sources"]
