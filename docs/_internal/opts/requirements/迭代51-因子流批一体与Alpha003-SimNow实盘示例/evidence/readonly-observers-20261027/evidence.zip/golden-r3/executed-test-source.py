"""Source-fake contracts for the bounded Iteration 51 quote observer.

The tests reuse the registered Store and synthetic CTP callback leaves from
``test_ctp_factor_source_cohort``.  The query snapshot and clock are synthetic;
the production selector, source projector, Store queue, and observer remain in
the path.  These cases do not establish provider or account acceptance.
"""

from __future__ import annotations

import hashlib
import importlib.util
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

import backtrader.stores.btapistore as btapistore_module
from backtrader.feeds.futures_main_contract import (
    CurrentDayQuoteRecord,
    FuturesContractCatalogRecord,
    MainContractQuerySnapshot,
    QuerySnapshotSourceEvidence,
)
from backtrader.feeds import futures_expected_calendar
from tests.integration import test_ctp_factor_source_cohort as source_fixture
from tests.unit import test_alpha003_simnow_runner as runner_fixture
from tests.unit.feeds import test_futures_sessions as session_fixtures


_ROOT = Path(__file__).resolve().parents[1]
_OBSERVER_PATH = _ROOT / ".codex-tmp" / "i51_root_golden_quote_observer_20261027.py"
_OBSERVER_SPEC = importlib.util.spec_from_file_location(
    "i51_root_golden_quote_observer_sourcefake", _OBSERVER_PATH
)
assert _OBSERVER_SPEC is not None and _OBSERVER_SPEC.loader is not None
_OBSERVER = importlib.util.module_from_spec(_OBSERVER_SPEC)
_OBSERVER_SPEC.loader.exec_module(_OBSERVER)

_UTC = timezone.utc
_SHANGHAI = timezone(timedelta(hours=8))
_PRODUCTS = tuple(session_fixtures.PRODUCTS[index] for index in (0, 1, 4))
_DECISION_AT = datetime(2026, 10, 22, 2, 31, tzinfo=_UTC)
_TRADING_DAY = session_fixtures.TRADING_DAY
_CLOCK_DOMAIN = "i51-golden-quote-observer-synthetic-clock-v1"


class _FakeClock:
    def __init__(self, *, wall_time, sleep_scale=20.0):
        self.wall_time = float(wall_time)
        self.monotonic_time = 0.0
        self.sleep_scale = float(sleep_scale)
        self.sleep_calls = 0
        self.on_sleep = None

    def time(self):
        return self.wall_time

    def monotonic(self):
        return self.monotonic_time

    def monotonic_ns(self):
        return max(1, int(self.monotonic_time * 1_000_000_000) + 1)

    def sleep(self, requested_seconds):
        elapsed = float(requested_seconds) * self.sleep_scale
        self.wall_time += elapsed
        self.monotonic_time += elapsed
        self.sleep_calls += 1
        if callable(self.on_sleep):
            self.on_sleep(self)


def _source_evidence(*, source_id, source_kind, snapshot_id, decision_at, count):
    return QuerySnapshotSourceEvidence(
        source_id=source_id,
        source_kind=source_kind,
        snapshot_id=snapshot_id,
        source_sha256=hashlib.sha256(source_id.encode("ascii")).hexdigest(),
        request_id=snapshot_id,
        connection_generation=source_fixture._TRADER_GENERATION,
        trading_day=_TRADING_DAY,
        started_at=decision_at - timedelta(seconds=1),
        completed_at=decision_at,
        retrieved_at=decision_at,
        complete=True,
        is_last_seen=True,
        record_count=count,
    )


def _query_plan(monkeypatch, system):
    # Match the established query-runner fixture: reviewed calendar rules are
    # retrieved one minute before the synthetic decision cutoff, never at
    # host wall time.  The plan builder still enforces its production as-of
    # check against these explicit timestamps.
    synthetic_calendar_review_at = _DECISION_AT - timedelta(minutes=1)
    monkeypatch.setattr(
        futures_expected_calendar,
        "RULE_REVIEW_RETRIEVED_AT_UTC",
        synthetic_calendar_review_at,
    )
    catalog = tuple(
        FuturesContractCatalogRecord(
            product=product,
            instrument_id=system.instruments[product],
            asset_type="future",
            is_trading=True,
            expiry_date=date(2026, 12, 31),
            product_class="1",
        )
        for product in _PRODUCTS
    )
    quotes = tuple(
        CurrentDayQuoteRecord(
            exchange_id=product.exchange_id,
            instrument_id=system.instruments[product],
            trading_day=_TRADING_DAY,
            open_interest=1_000 + index,
            volume=100 + index,
            action_day=_TRADING_DAY.strftime("%Y%m%d"),
            update_time="10:30:00",
            update_millisec=0,
        )
        for index, product in enumerate(_PRODUCTS)
    )
    snapshot = MainContractQuerySnapshot(
        catalog_source=_source_evidence(
            source_id="synthetic.ctp.catalog",
            source_kind="instruments",
            snapshot_id="catalog-snapshot-1",
            decision_at=_DECISION_AT,
            count=len(catalog),
        ),
        quote_source=_source_evidence(
            source_id="synthetic.ctp.depth",
            source_kind="depth_market_data",
            snapshot_id="depth-snapshot-1",
            decision_at=_DECISION_AT,
            count=len(quotes),
        ),
        catalog_records=catalog,
        quote_records=quotes,
        session_trading_day_before=_TRADING_DAY,
        session_trading_day_after=_TRADING_DAY,
        session_generation_before=source_fixture._TRADER_GENERATION,
        session_generation_after=source_fixture._TRADER_GENERATION,
    )
    monkeypatch.setattr(
        system.store,
        "registered_sim_collect_futures_snapshot",
        lambda **_kwargs: snapshot,
    )
    full_plan = runner_fixture.RUNNER.build_ctp_query_market_plan(
        system.store,
        {"selection": {"authorized_products": None}},
        clock=SimpleNamespace(utc_now=lambda: _DECISION_AT),
    )
    assert full_plan["manifest"].status == "READY"
    for calendar in full_plan["session_calendars"].values():
        source = calendar.source_index[calendar.calendar_source_id]
        assert source.available_at == synthetic_calendar_review_at
        assert source.retrieved_at == synthetic_calendar_review_at
    plan = runner_fixture.RUNNER._apply_golden_target_subset(
        full_plan, tuple(full_plan["targets"])
    )
    assert len(plan["targets"]) == 3
    return plan


def _clock_context(monkeypatch, clock):
    """Patch only the observer clock and the Store's callback receipt clock."""
    context = monkeypatch.context()
    patcher = context.__enter__()
    patcher.setattr(_OBSERVER, "time", clock)
    patcher.setattr(btapistore_module.time, "time", clock.time)
    patcher.setattr(btapistore_module.time, "monotonic_ns", clock.monotonic_ns)
    return context, patcher


def _ordered_products(plan):
    return tuple(plan["product_by_target"][target] for target in plan["targets"])


def _subscribe_observer_aliases(system, plan):
    # The source fixture's Cerebro feeds subscribe as EXCHANGE.INSTRUMENT, but
    # the production observer subscribes as INSTRUMENT.EXCHANGE.  Register the
    # observer's real Store alias before emitting callbacks so the Store fans
    # each callback into both subscribed queues; it does not replay ticks that
    # were queued before a new alias was subscribed.
    routes = plan.get("full_routes", plan["routes"])
    for product in _ordered_products(plan):
        system.store.subscribe("{}.{}".format(routes[product], product.exchange_id))


def _emit_at(system, product, event_time, total_volume):
    local = event_time.astimezone(_SHANGHAI).replace(tzinfo=None)
    return source_fixture._emit_tick(
        system,
        product,
        local.isoformat(timespec="seconds"),
        total_volume,
        100.0 + total_volume / 1_000.0,
    )


def _observe(system, plan, clock):
    return _OBSERVER.observe_golden_quote_sources(
        system.store,
        plan,
        tuple(plan["targets"]),
        clock_domain_id=_CLOCK_DOMAIN,
        expected_md_generation=system.md_generation,
        trader_trading_day=_TRADING_DAY,
    )


@pytest.mark.integration
def test_pre_common_grid_delivery_quote_witnesses_for_three_targets_can_qualify(monkeypatch):
    system = source_fixture._system(
        monkeypatch,
        products=_PRODUCTS,
        cohort_close=source_fixture._DAY_SLOT_CLOSE,
    )
    try:
        plan = _query_plan(monkeypatch, system)
        products = _ordered_products(plan)
        clock = _FakeClock(wall_time=_DECISION_AT.timestamp())
        first_event = _DECISION_AT - timedelta(seconds=1)
        context, _patcher = _clock_context(monkeypatch, clock)
        try:
            _subscribe_observer_aliases(system, plan)
            for index, product in enumerate(products):
                _emit_at(system, product, first_event, 100 + index)

            injected = False

            def add_fresh_quotes(fake_clock):
                nonlocal injected
                if injected:
                    return
                injected = True
                event_time = datetime.fromtimestamp(fake_clock.time(), _UTC)
                for index, product in enumerate(products):
                    _emit_at(system, product, event_time, 200 + index)

            clock.on_sleep = add_fresh_quotes
            result = _observe(system, plan, clock)
        finally:
            context.__exit__(None, None, None)

        assert result["status"] == "QUALIFIED"
        assert result["active_target_count"] == 3
        assert result["ac19_accepted"] is False
        assert result["full_factor_acceptance"] is False
        assert all(target["callback_count"] == 2 for target in result["targets"])
        first_witnesses = [target["witnesses"][0] for target in result["targets"]]
        assert len({item["event_time_utc"] for item in first_witnesses}) == 1
        assert all(item["common_grid_slot_available"] is True for item in first_witnesses)
        assert all(
            datetime.fromisoformat(item["event_time_utc"])
            < datetime.fromisoformat(item["planned_close_time_utc"])
            for item in first_witnesses
        )
        # The observer consumes Store callbacks directly; it does not drain
        # Feed bars or publish a complete Cerebro cohort batch.
        assert system.cohort.current_batch() is None
        first_sequences = [item["callback_sequence"] for item in first_witnesses]
        assert first_sequences == sorted(set(first_sequences))
        for target in result["targets"]:
            first, latest = target["witnesses"]
            assert latest["callback_sequence"] > first["callback_sequence"]
            assert latest["common_grid_slot_available"] is True
            assert latest["fresh_at_qualification_check"] is True
            assert target["fresh_witness_count_at_qualification_check"] == 1
    finally:
        source_fixture._close_system(system)


@pytest.mark.integration
def test_stale_only_quote_witnesses_do_not_qualify_after_fake_sixty_second_window(
    monkeypatch,
):
    system = source_fixture._system(
        monkeypatch,
        products=_PRODUCTS,
        cohort_close=source_fixture._DAY_SLOT_CLOSE,
    )
    try:
        plan = _query_plan(monkeypatch, system)
        products = _ordered_products(plan)
        clock = _FakeClock(wall_time=_DECISION_AT.timestamp(), sleep_scale=1_200.0)
        event_time = _DECISION_AT - timedelta(seconds=1)
        context, _patcher = _clock_context(monkeypatch, clock)
        try:
            _subscribe_observer_aliases(system, plan)
            for pass_index in range(2):
                for index, product in enumerate(products):
                    _emit_at(system, product, event_time, 100 + pass_index * 10 + index)
            # Start the observer while the callbacks are fresh.  The fake
            # clock then ages these unchanged witnesses through its 60-second
            # qualification window without injecting a replacement quote.
            result = _observe(system, plan, clock)
        finally:
            context.__exit__(None, None, None)

        assert result["status"] == "INCOMPLETE_OBSERVATION"
        assert result["error_code"] == "OBSERVER_DEADLINE_EXCEEDED"
        assert result["elapsed_seconds"] >= 60.0
        assert all(target["callback_count"] == 2 for target in result["targets"])
        assert all(
            target["fresh_witness_count_at_qualification_check"] == 0
            for target in result["targets"]
        )
        for target in result["targets"]:
            assert len(target["witnesses"]) == 2
            assert all(
                witness["fresh_at_qualification_check"] is False
                for witness in target["witnesses"]
            )
            assert all(
                witness["source_age_seconds_at_qualification_check"] > 60.0
                for witness in target["witnesses"]
            )
            assert all(
                witness["callback_receipt_age_seconds_at_qualification_check"] > 60.0
                for witness in target["witnesses"]
            )
            assert target["qualified"] is False
    finally:
        source_fixture._close_system(system)


@pytest.mark.integration
@pytest.mark.parametrize(
    "invalidity", ("wrong-returned-tick-source", "unsupported-action-day")
)
def test_quote_observer_rejects_wrong_tick_source_or_action_day(monkeypatch, invalidity):
    system = source_fixture._system(
        monkeypatch,
        products=_PRODUCTS,
        cohort_close=source_fixture._DAY_SLOT_CLOSE,
    )
    try:
        plan = _query_plan(monkeypatch, system)
        clock = _FakeClock(wall_time=_DECISION_AT.timestamp())
        context, patcher = _clock_context(monkeypatch, clock)
        try:
            _subscribe_observer_aliases(system, plan)
            if invalidity == "wrong-returned-tick-source":
                original_poll_tick = system.store.poll_tick

                def poll_with_wrong_source(alias):
                    tick = original_poll_tick(alias)
                    if tick is not None:
                        tick.source = "synthetic-unexpected-ctp-source"
                    return tick

                patcher.setattr(system.store, "poll_tick", poll_with_wrong_source)
                product = _ordered_products(plan)[0]
                _emit_at(
                    system,
                    product,
                    _DECISION_AT - timedelta(seconds=1),
                    100,
                )
                result = _observe(system, plan, clock)
                assert result["status"] == "BLOCKED_SOURCE_VALIDATION"
                assert result["error_code"] == "REGISTERED_SIM_ROUTE_IDENTITY_MISMATCH"
                assert result["source_guard_errors"] == {
                    "REGISTERED_SIM_ROUTE_IDENTITY_MISMATCH": 1
                }
            else:
                product = _ordered_products(plan)[0]
                local = (_DECISION_AT - timedelta(seconds=1)).astimezone(_SHANGHAI)
                source_fixture._emit_tick(
                    system,
                    product,
                    local.replace(tzinfo=None).isoformat(timespec="seconds"),
                    100,
                    100.0,
                    action_day="20261023",
                )
                result = _observe(system, plan, clock)
                assert result["status"] == "BLOCKED_SOURCE_VALIDATION"
                assert result["error_code"] == "CTP_FACTOR_SOURCE_SESSION_MISMATCH"
                assert result["source_guard_errors"] == {
                    "CTP_FACTOR_SOURCE_SESSION_MISMATCH": 1
                }
        finally:
            context.__exit__(None, None, None)
    finally:
        source_fixture._close_system(system)
