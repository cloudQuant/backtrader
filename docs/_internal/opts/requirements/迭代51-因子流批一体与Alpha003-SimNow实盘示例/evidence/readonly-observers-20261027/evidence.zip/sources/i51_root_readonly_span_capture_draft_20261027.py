"""UNEXECUTED Root-only sketch; this is not production code or a QA result."""


def invoke_with_readonly_span_observation(run_live, observer, sink, *args, **kwargs):
    import sys

    if type(sink) is not dict:
        raise TypeError("I51_OBSERVER_SINK_INVALID")
    sink.clear()
    previous_profile = sys.getprofile()
    if previous_profile is not None:
        sink.update(status="PROFILE_ALREADY_ACTIVE", before=None, after=None)
        raise RuntimeError("I51_OBSERVER_PROFILE_ALREADY_ACTIVE")
    live_code = getattr(run_live, "__code__", None)
    if live_code is None:
        sink.update(status="LIVE_CODE_UNAVAILABLE", before=None, after=None)
        raise RuntimeError("I51_OBSERVER_LIVE_CODE_UNAVAILABLE")
    held = {"status": "NOT_REACHED", "cerebro": None, "token": None, "before": None}

    def capture(frame, event, _arg):
        if event != "call" or frame.f_back is None or frame.f_back.f_code is not live_code:
            return
        try:
            module = sys.modules.get("backtrader.cerebro")
            cerebro_type = getattr(module, "Cerebro", None) if module is not None else None
            run_method = getattr(cerebro_type, "run", None)
            target_code = getattr(run_method, "__code__", None)
        except Exception:
            return
        if frame.f_code is not target_code:
            return
        sys.setprofile(None)
        try:
            cerebro = frame.f_locals.get("self")
            broker = getattr(cerebro, "_broker", None)
            store = getattr(broker, "store", None)
            if cerebro is None or broker is None or store is None:
                held["status"] = "BROKER_STORE_UNAVAILABLE"
                return
            token, before = observer.begin_observation(broker, store)
            held.update(status="CAPTURED", cerebro=cerebro, token=token, before=before)
        except Exception:
            held["status"] = "BEGIN_FAILED"
        finally:
            sys.setprofile(previous_profile)

    try:
        sys.setprofile(capture)
        return run_live(*args, **kwargs)
    finally:
        sys.setprofile(previous_profile)
        status, after = held["status"], None
        if status == "CAPTURED":
            try:
                broker = getattr(held["cerebro"], "_broker", None)
                store = getattr(broker, "store", None)
                after = observer.finish_observation(held["token"], broker, store)
                status = "FINISHED"
            except Exception:
                status = "FINISH_FAILED"
        sink.update(status=status, before=held["before"], after=after)
        held.clear()
