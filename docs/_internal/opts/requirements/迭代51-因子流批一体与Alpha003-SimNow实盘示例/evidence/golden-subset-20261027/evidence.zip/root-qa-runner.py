"""Run one explicit public-source pytest focus and preserve its original result."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

REPO = Path('D:/source_code/backtrader')
spec_path = Path(sys.argv[1])
spec = json.loads(spec_path.read_text(encoding='utf-8-sig'))
output = Path(spec['output'])
assert not output.exists(), 'fresh output directory required'
assert spec['nodes'] and spec['pins']

def pins():
    return {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest()
            for name in spec['pins']}

before = pins()
assert before == spec['pins'], 'source pins changed before pytest'
output.mkdir(parents=True)
(output / 'spec.json').write_bytes(spec_path.read_bytes())
env = dict(os.environ)
for name in ('PYTHONPATH', 'PYTHONHOME'):
    env.pop(name, None)
env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONUTF8='1')
command = [sys.executable, '-m', 'pytest', '-p', 'no:asyncio', '-q',
           '--tb=short', '--junitxml=' + str(output / 'junit.xml'), *spec['nodes']]
started = time.monotonic()
with (output / 'stdout.txt').open('wb') as stdout, (output / 'stderr.txt').open('wb') as stderr:
    completed = subprocess.run(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr)
after = pins()
counts = {}
if (output / 'junit.xml').exists():
    root = ET.parse(output / 'junit.xml').getroot()
    suites = [root] if root.tag == 'testsuite' else list(root.findall('testsuite'))
    counts = {key: sum(int(suite.attrib.get(key, '0')) for suite in suites)
              for key in ('tests', 'failures', 'errors', 'skipped')}
result = {
    'command': command, 'exit_code': completed.returncode,
    'elapsed_seconds': time.monotonic() - started,
    'counts': counts, 'pins_before': before, 'pins_after': after,
    'source_pins_unchanged': before == after,
    'evidence_level': 'PUBLIC_SOURCE_SYNTHETIC_LEAVES_ONLY',
}
(output / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in
                 ('exit_code', 'elapsed_seconds', 'counts', 'source_pins_unchanged')}))
sys.exit(completed.returncode if before == after else 2)
