# I51 golden active-feed subset: static review

Disposition: **GO — static source review only**. This review covers the exact frozen public files below. No tests, imports of candidate code, provider/native actions, staging, or runtime calls were performed.

| File | Bytes | SHA-256 |
|---|---:|---|
| `examples/unified/028_alpha003_simnow_minute/run.py` | 273,789 | `405c998d2dc2f7a140cd23ed8c8aedbdcc5f09bffd6f284bbc4267bd859f8bc9` |
| `examples/unified/028_alpha003_simnow_minute/config.yaml` | 3,848 | `6768ec38c180293c9f3656cc083803e5fc59de100eda0e68d8649c026c9ffd77` |
| `tests/unit/test_alpha003_simnow_shadow_subset.py` | 18,571 | `c2f64cef72db6d2e9fd43965137319d71fe7286bc8f9b48cafcde6397a961421` |

`run_live()` validates the opt-in before importing the Store module or constructing resources (`run.py:4839–4860`). The check requires live mode, `ctp_query`, explicit read-only flags, no arm templates, 3–5 unique canonical target IDs, and an authorized-target list with a non-empty intersection. The public template sets `golden_targets: null` (`config.yaml:93`); omitted keys receive the same default (`run.py:279–282`). The no-option branch returns the original plan, and the new evidence/identity fields are conditional.

The query path collects a current full Store snapshot and runs the existing selector/calendar builder over all discovered futures products (`run.py:484–633`). It checks the full plan against the existing 256-target cap before applying the subset (`run.py:4988–4999`). The subset helper requires a READY full manifest/grid, consistent full product/route/target maps and authorized pool, rejects targets outside that selected pool, preserves the manifest/full grid/full route and authorization values, and builds a new grid only for the exact active products (`run.py:636–738`). I found no manual-contract path that bypasses full CTP discovery or selection.

Tape/history binding carries both scopes: full manifest/query snapshot and full routes/authorization, plus active targets/routes/authorization and full/active grid semantics. These are included in restart identity and selection-evidence hashes; `_load_saved_live_history()` compares old evidence and identity to the current plan before accepting history (`run.py:2098–2160, 4396–4808`). Partial golden evidence is rejected by the exact-key validation. The four focused tests cover pre-Store option rejection, null/default compatibility, READY-before-subset and active-grid reconstruction, and full/active evidence plus tape identity projection (`test_alpha003_simnow_shadow_subset.py:266–425`).

Evidence limit: the focused test uses a hand-built manifest and monkeypatches common-grid construction; it is helper/component coverage, not one executed Store snapshot or a provider/Cerebro/account acceptance. Root’s focused QA should be reported separately.
