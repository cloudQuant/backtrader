"""One new installed-core composition node; public source fixtures only."""
import hashlib
import json
import os
from pathlib import Path
import sys
import types
import xml.etree.ElementTree as ET

ROOT = Path('D:/source_code/backtrader')
SITE = Path('D:/temp/i51-ctp-factor-clean-consumer-20261027-c4c7240a/consumer/Lib/site-packages')
OUT = Path('D:/temp/i51-saved-tape-installed-20261027-r1')
PINS = {
    ROOT / 'scripts/validate_iteration51_saved_factor_tape.py': '7800089b42c54c2902873d69b95a867cc6849599b290fb780fa4756dedf4592d',
    ROOT / 'tests/integration/test_iteration51_saved_factor_tape.py': '858fd3a9cd5039b242469fbe861f5efd87466b0beed5f1e2b9d6c6fedffd4781',
    ROOT / 'examples/unified/028_alpha003_simnow_minute/run.py': '405c998d2dc2f7a140cd23ed8c8aedbdcc5f09bffd6f284bbc4267bd859f8bc9',
    ROOT / 'examples/unified/028_alpha003_simnow_minute/alpha003_strategy.py': '220330a52a0acc65427f5c68448e82b80f4ef9fdddc8c7a75eceb0bea4ee3521',
    SITE / 'back_trader_python-1.4.0.dist-info/RECORD': 'd243f63d1dc8fee67abbab8bcb05ba4e33b23816ee44315c13468f656db5c39a',
}

def check_pins():
    return all(hashlib.sha256(path.read_bytes()).hexdigest() == expected for path, expected in PINS.items())

assert sys.flags.isolated == 1
assert not OUT.exists()
assert check_pins()
assert ROOT.resolve() not in {Path(item).resolve() for item in sys.path if item}
OUT.mkdir()
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
import backtrader
import backtrader_runtime
assert Path(backtrader.__file__).resolve().is_relative_to(SITE)
assert Path(backtrader_runtime.__file__).resolve().is_relative_to(SITE)
# Public fixtures need their own namespaces, not a repository-root sys.path entry.
for name in ('scripts', 'tests', 'tests.integration', 'tests.test_utils'):
    module = types.ModuleType(name)
    module.__path__ = [str(ROOT.joinpath(*name.split('.')))]
    module.__package__ = name
    sys.modules[name] = module

import pytest
node = str(ROOT / 'tests/integration/test_iteration51_saved_factor_tape.py') + '::test_saved_factor_tape_accepts_live_ready_good_batch_with_legal_nan'
arguments = [node, '--noconftest', '-p', 'no:asyncio', '--import-mode=importlib', '-q', '--tb=short',
             '--basetemp=' + str(OUT / 'pytest-tmp'), '--junitxml=' + str(OUT / 'junit.xml')]
(OUT / 'command.json').write_text(json.dumps({'executable': sys.executable, 'isolated': True, 'pytest_arguments': arguments}, indent=2), encoding='utf-8')
code = int(pytest.main(arguments))
origins = {}
for name, module in tuple(sys.modules.items()):
    if name in ('backtrader', 'backtrader_runtime') or name.startswith(('backtrader.', 'backtrader_runtime.')):
        origin = getattr(module, '__file__', None)
        if origin is not None:
            origins[name] = str(Path(origin).resolve())
origins_ok = bool(origins) and all(Path(path).is_relative_to(SITE) for path in origins.values())
tree = ET.parse(OUT / 'junit.xml')
cases = tree.findall('.//testcase')
result = {
    'schema': 'iteration51.installed_saved_tape_focus.v1',
    'status': 'PASS_INSTALLED_SYNTHETIC_SAVED_TAPE_ONLY' if code == 0 and origins_ok and check_pins() and len(cases) == 1 else 'FAIL',
    'pytest_exit_code': code,
    'test_cases': len(cases),
    'installed_origins_ok': origins_ok,
    'installed_module_count': len(origins),
    'pins_unchanged': check_pins(),
    'source_pins': {str(path): pin for path, pin in PINS.items()},
    'real_account_acceptance': False,
}
(OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
(OUT / 'origins.json').write_text(json.dumps(origins, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: result[key] for key in ('status', 'pytest_exit_code', 'test_cases', 'installed_origins_ok', 'installed_module_count', 'pins_unchanged')}))
raise SystemExit(0 if result['status'].startswith('PASS_') else 2)
