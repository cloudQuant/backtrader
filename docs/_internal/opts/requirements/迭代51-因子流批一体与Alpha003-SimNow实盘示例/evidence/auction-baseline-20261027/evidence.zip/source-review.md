# I51 CFFEX opening-auction baseline review

Disposition: **GO for the scoped auction-only baseline change**, static review only.

Reviewed against `dev` baseline `c4c7240ad0b7a5d0e698a9006c95f144ddf8401d`:

- `backtrader/feeds/ctp_factor_source.py` — SHA-256 `AE2305394A61DD2B4F2AF1334A05356644CE6493D8A8C343CFF87A88CDE89F49`.
- `backtrader/feeds/btapifeed.py` — SHA-256 `F08EB46C3EA9320BE008DE1266078FA1053944AD98E3B4736E3CC91723ED8ED5`.
- `tests/integration/test_ctp_factor_preopen_baseline.py` — SHA-256 `F53076D11DD9846D30B5ECD354A528BDD86B5756CD376AB65581D1EAA783DA9C`.

The resolver accepts only CFFEX IF/IH/IC/IM on the selected TradingDay at Shanghai local times `[09:25, 09:30)`. The feed reuses the existing source, generation, TradingDay, ActionDay, price/volume, quality, and freshness gates; only an observed eligible quote can set the one-shot first-bucket marker. Auction ticks remain quote-only and do not enter bar ingestion. No continuous session or common-grid interval is added.

The focused tests cover the actual synthetic callback path, inclusive/exclusive time bounds, non-CFFEX/out-of-window rejection, auction-only baseline volume, no auction bar, and the no-auction fallback guard.

This reviewer ran no imports or QA. Root's separate actual QA record is `D:/temp/i51-auction-and-golden-source-qa-20261027-r1`; its baseline-file result was 12/12 PASS. The golden-observer cases failed fixture setup before reaching the observer and are not included as passes by this review.
