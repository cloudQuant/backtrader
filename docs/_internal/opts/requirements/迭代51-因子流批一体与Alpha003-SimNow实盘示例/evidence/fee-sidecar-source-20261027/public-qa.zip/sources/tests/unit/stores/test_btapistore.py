"""Unit tests for the unified BtApiStore."""

import datetime as dt
import sys
import time
import types

import pytest

from tests.test_utils.optional_sdk import optional_sdk

from backtrader.brokers.btapibroker import BtApiBroker
from backtrader.feeds.btapifeed import BtApiFeed
from backtrader.stores.btapistore import (
    BtApiMissingDependencyError,
    BtApiProviderNotImplementedError,
    BtApiStore,
    BtApiStoreError,
    LegacyGatewayMigrationRequiredError,
    _build_ctp_tick_datetime,
    _create_ctp_wrapper_class,
    _normalize_bar,
    _normalize_datetime,
    _split_ctp_symbol,
)
from tests.fixtures.fake_btapi import (
    DEFAULT_SYMBOL,
    FakeBtApiClient,
    make_bar,
    make_orderbook,
    make_store,
    make_tick,
)


def test_ctp_query_record_preserves_commission_applicability_fields():
    record = types.SimpleNamespace(InvestorRange="3", BizType="1")

    core_public = BtApiStore._ctp_query_record_to_public(record)
    public = BtApiStore._ctp_query_record_to_public(
        record, include_commission_fields=True
    )
    initialized = types.SimpleNamespace(init_data=lambda: record)
    recursive_public = BtApiStore._ctp_query_record_to_public(
        initialized, include_commission_fields=True
    )

    assert public["InvestorRange"] == "3"
    assert public["BizType"] == "1"
    assert "InvestorRange" not in core_public
    assert "BizType" not in core_public
    assert recursive_public["InvestorRange"] == "3"
    assert recursive_public["BizType"] == "1"


def test_ctp_wrapper_forwards_bounded_commission_deadline_through_sdk_rate_limit(
    monkeypatch,
):
    import hashlib
    import inspect
    from pathlib import Path
    import subprocess

    sdk_source_root = next(
        (
            parent / "bt_api_py" / "bt_api" / "bt_api_ctp" / "src"
            for parent in Path(__file__).resolve().parents
            if (parent / "bt_api_py" / "bt_api" / "bt_api_ctp" / "src").is_dir()
        ),
        None,
    )
    if sdk_source_root is None:
        pytest.skip("the reviewed bt_api_ctp source checkout is not available")
    sdk_repo = sdk_source_root.parents[0]
    sdk_head = subprocess.run(
        ["git", "-C", str(sdk_repo), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert sdk_head == "be716e7664fa5db8230ed2e502e06997853d2910"
    client_path = sdk_source_root / "bt_api_ctp" / "ctp" / "client.py"
    assert hashlib.sha256(client_path.read_bytes()).hexdigest() == (
        "8b344d14cb059292f9a957642627cc0fdb0e9f16b61102d43c349ce31704718f"
    )
    monkeypatch.syspath_prepend(str(sdk_source_root))
    for module_name in tuple(sys.modules):
        if module_name == "bt_api_ctp" or module_name.startswith("bt_api_ctp."):
            monkeypatch.delitem(sys.modules, module_name, raising=False)
    sdk_client = optional_sdk("bt_api_ctp.ctp.client")
    assert Path(sdk_client.__file__).resolve() == client_path.resolve()
    deadline_parameter = inspect.signature(
        sdk_client.TraderClient.query_instrument_commission_rate_result
    ).parameters["deadline_monotonic"]
    assert deadline_parameter.kind is inspect.Parameter.KEYWORD_ONLY
    wrapper_cls = _create_ctp_wrapper_class()
    submitted = []

    class SyntheticCommissionField:
        """Keep source method coverage independent of the native SWIG ABI."""

        pass

    # The committed Windows SWIG setter accepts char-array bytes while the
    # source method supplies text. Keep this source-fake focused on deadline,
    # rate-limit and QuerySource plumbing; the native mismatch is a separate
    # SDK integration blocker rather than a reason to fake the client method.
    monkeypatch.setattr(
        sdk_client, "CThostFtdcQryInstrumentCommissionRateField", SyntheticCommissionField
    )

    class VirtualClock:
        now = 100.0

        @classmethod
        def monotonic(cls):
            return cls.now

        @classmethod
        def sleep(cls, seconds):
            cls.now += max(0.0, float(seconds))

    class VirtualEvent:
        def __init__(self):
            self._set = False

        def wait(self, timeout=None):
            if not self._set and timeout is not None:
                VirtualClock.now += max(0.0, float(timeout))
            return self._set

        def set(self):
            self._set = True

        def is_set(self):
            return self._set

    class SyntheticTrader(sdk_client.TraderClient):
        @property
        def is_read_only_ready(self):
            return True

        def _invoke_session_native_request(self, api, method_name, field, request_id):
            submitted.append(
                (
                    VirtualClock.now,
                    method_name,
                    field.BrokerID,
                    field.InvestorID,
                    field.InstrumentID,
                    field.ExchangeID,
                )
            )
            row = types.SimpleNamespace(
                BrokerID=field.BrokerID,
                InvestorID=field.InvestorID,
                InstrumentID=field.InstrumentID,
                ExchangeID=field.ExchangeID,
                InvestUnitID="",
                InvestorRange="3",
                BizType="1",
                OpenRatioByMoney=0.0,
                OpenRatioByVolume=0.1,
                CloseRatioByMoney=0.0,
                CloseRatioByVolume=0.1,
                CloseTodayRatioByMoney=0.0,
                CloseTodayRatioByVolume=0.1,
            )
            self._handle_query_callback(
                "commission_rate", row, None, request_id, True
            )
            return 0

    trader = SyntheticTrader(
        "tcp://127.0.0.1:1", "synthetic-broker", "synthetic-investor", "synthetic-password"
    )
    trader._connection_generation = 1
    trader._trading_day = "20261027"
    trader._query_interval = 1.05
    trader._last_query_submitted_at = VirtualClock.now

    class SyntheticNativeApi:
        def ReqQryInstrumentCommissionRate(self, field, request_id):
            return 0

    trader._api = SyntheticNativeApi()
    wrapper = wrapper_cls(
        md_address="tcp://127.0.0.1:1",
        td_address="tcp://127.0.0.1:1",
        broker_id="synthetic-broker",
        investor_id="synthetic-investor",
        password="synthetic-password",
    )
    wrapper.trader_client = trader

    monkeypatch.setattr(sdk_client, "time", VirtualClock)
    monkeypatch.setattr(sdk_client, "threading", types.SimpleNamespace(Event=VirtualEvent))

    short_deadline = VirtualClock.now + 1.0
    expired = wrapper.query_instrument_commission_rate_result(
        "rb2610",
        "SHFE",
        timeout=1.0,
        deadline_monotonic=short_deadline,
    )
    assert expired.complete is False
    assert expired.error_message == "query_deadline_exceeded"
    assert submitted == []

    VirtualClock.now += 5.0
    trader._last_query_submitted_at = VirtualClock.now
    started = VirtualClock.now
    deadline = started + 3.0
    result = wrapper.query_instrument_commission_rate_result(
        "rb2610",
        "SHFE",
        timeout=3.0,
        deadline_monotonic=deadline,
    )

    assert result.complete is True
    assert len(result.records) == 1
    assert len(submitted) == 1
    assert submitted[0][1:] == (
        "ReqQryInstrumentCommissionRate",
        "synthetic-broker",
        "synthetic-investor",
        "rb2610",
        "SHFE",
    )
    assert submitted[0][0] - started >= 1.05 - 1e-9
    assert submitted[0][0] < deadline
    source = result.query_source
    assert source is not None
    assert dict(source.request_intent_filters) == {
        "BrokerID": "synthetic-broker",
        "InvestorID": "synthetic-investor",
        "InstrumentID": "rb2610",
        "ExchangeID": "SHFE",
    }
    assert dict(source.request_filters) == dict(source.request_intent_filters)
    assert source.explicit_request_filters == ()


@pytest.fixture
def fake_client():
    """Create a fake bt_api_py client with history and live bars."""
    return FakeBtApiClient(
        positions=[{"instrument": DEFAULT_SYMBOL, "volume": 2, "price": 99.5}],
        history={
            DEFAULT_SYMBOL: [
                make_bar(0, 100.0, 101.0, 99.0, 100.5),
                make_bar(1, 100.5, 102.0, 100.0, 101.5),
            ]
        },
        live={DEFAULT_SYMBOL: [make_bar(2, 101.5, 103.0, 101.0, 102.5)]},
    )


def test_normalize_datetime_converts_aware_values_to_utc_naive():
    """Store datetime normalization should keep internal values UTC-naive."""
    shanghai = dt.timezone(dt.timedelta(hours=8))

    assert _normalize_datetime(dt.datetime(2026, 6, 25, 11, 15, 59, tzinfo=shanghai)) == (
        dt.datetime(2026, 6, 25, 3, 15, 59)
    )
    assert _normalize_datetime("2026-06-25T11:15:59+08:00") == dt.datetime(2026, 6, 25, 3, 15, 59)
    assert _normalize_datetime(1782357359000) == dt.datetime(2026, 6, 25, 3, 15, 59)


def test_ctp_tick_datetime_normalizes_to_utc_naive():
    """CTP market data timestamps are exchange-local and must normalize to UTC."""
    payload = type(
        "Payload",
        (),
        {
            "ActionDay": "20260623",
            "TradingDay": "20260623",
            "UpdateTime": "08:22:00",
            "UpdateMillisec": 500,
        },
    )()

    assert _normalize_datetime(_build_ctp_tick_datetime(payload)) == dt.datetime(
        2026, 6, 23, 0, 22, 0, 500000
    )


def test_normalize_bar_prefers_epoch_timestamp_over_provider_datetime():
    """Bar payloads can carry mislabeled provider datetimes; epoch is canonical."""
    bar = {
        "timestamp": 1782357359.0,
        "datetime": "2026-06-25T11:15:00+00:00",
        "open": 100.0,
        "high": 101.0,
        "low": 99.0,
        "close": 100.5,
        "volume": 1.0,
    }

    assert _normalize_bar(bar)["datetime"] == dt.datetime(2026, 6, 25, 3, 15, 59)


def test_store_uses_injected_api_client(fake_client):
    """Store should proxy account, history, and live polling through the injected API."""
    store = make_store(api=fake_client)

    store.start()

    assert store.is_connected is True
    assert fake_client.connected is True
    assert store.get_cash() == pytest.approx(10000.0)
    assert store.get_value() == pytest.approx(10000.0)
    assert len(store.get_positions()) == 1

    store.subscribe(DEFAULT_SYMBOL)
    history = store.fetch_history(DEFAULT_SYMBOL)
    live_bar = store.poll_live(DEFAULT_SYMBOL)

    assert fake_client.subscriptions == [DEFAULT_SYMBOL]
    assert len(history) == 2
    assert history[0]["close"] == pytest.approx(100.5)
    assert live_bar["close"] == pytest.approx(102.5)

    store.stop()
    assert fake_client.connected is False


def test_store_poll_live_uses_preseeded_live_bars_before_start_without_connecting():
    """Test that poll_live uses preseeded live bars before start without connecting."""

    class TrackingClient(FakeBtApiClient):
        """Tracking client that counts connect calls."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = TrackingClient()
    store = make_store(
        api=client,
        live_bars={DEFAULT_SYMBOL: [make_bar(0, 100.0, 101.0, 99.0, 100.5)]},
    )

    assert store.is_connected is False

    live_bar = store.poll_live(DEFAULT_SYMBOL)

    assert live_bar["close"] == pytest.approx(100.5)
    assert store.is_connected is False
    assert client.connect_calls == 0

    assert store.poll_live(DEFAULT_SYMBOL) is None
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_compatibility_query_aliases_match_canonical_methods(fake_client):
    """Test that compatibility query aliases match canonical methods."""
    store = make_store(api=fake_client)

    store.start()

    assert store.getcash() == pytest.approx(store.get_cash())
    assert store.getvalue() == pytest.approx(store.get_value())
    assert store.getpositions() == store.get_positions()


def test_store_seeded_account_queries_return_cached_values_before_start():
    """Test that seeded account queries return cached values before store start."""

    class TrackingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = TrackingClient()
    store = make_store(api=client, cash=321.0, value=654.0, account_cache_ttl=60.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 321.0, "value": 654.0}
    assert store.get_cash() == pytest.approx(321.0)
    assert store.get_value() == pytest.approx(654.0)
    assert store.getcash() == pytest.approx(321.0)
    assert store.getvalue() == pytest.approx(654.0)
    assert store.getvalue(datas=[object()]) == pytest.approx(654.0)
    assert store.is_connected is False
    assert client.connect_calls == 0


def test_store_seeded_account_queries_fall_back_to_cached_values_before_start_when_query_fails():
    """Test fallback to cached values when query fails before store start."""

    class FailingBalanceClient(FakeBtApiClient):
        """Client that fails balance queries but tracks connect calls."""

        def __init__(self):
            """Initialize the failing balance client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

        def get_balance(self):
            """Raise error to simulate balance unavailable."""
            raise RuntimeError("balance unavailable")

    client = FailingBalanceClient()
    store = make_store(api=client, cash=321.0, value=654.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 321.0, "value": 654.0}
    assert store.get_cash() == pytest.approx(321.0)
    assert store.get_value() == pytest.approx(654.0)
    assert store.getcash() == pytest.approx(321.0)
    assert store.getvalue() == pytest.approx(654.0)
    assert store.getvalue(datas=[object()]) == pytest.approx(654.0)
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_seeded_account_queries_fall_back_to_cached_values_before_start_when_get_account_alias_fails():
    """Test fallback to cached values when get_account fails before store start."""

    class FailingAccountAliasClient:
        """Client that fails account queries."""

        def __init__(self):
            """Initialize the failing account client."""
            self.connected = False
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_account(self):
            """Raise error to simulate account unavailable."""
            raise RuntimeError("account unavailable")

    client = FailingAccountAliasClient()
    store = make_store(api=client, cash=321.0, value=654.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 321.0, "value": 654.0}
    assert store.get_cash() == pytest.approx(321.0)
    assert store.get_value() == pytest.approx(654.0)
    assert store.getcash() == pytest.approx(321.0)
    assert store.getvalue() == pytest.approx(654.0)
    assert store.getvalue(datas=[object()]) == pytest.approx(654.0)
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_seeded_position_queries_return_cached_values_before_start():
    """Test that seeded position queries return cached values before store start."""

    class TrackingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = TrackingClient()
    store = make_store(
        api=client,
        positions=[{"instrument": DEFAULT_SYMBOL, "volume": 2.0, "price": 99.5}],
        positions_cache_ttl=60.0,
    )

    assert store.is_connected is False
    positions = store.get_positions()
    compat_positions = store.getpositions()
    assert positions[0]["instrument"] == DEFAULT_SYMBOL
    assert positions[0]["volume"] == pytest.approx(2.0)
    assert positions[0]["price"] == pytest.approx(99.5)
    assert compat_positions[0]["instrument"] == DEFAULT_SYMBOL
    assert compat_positions[0]["volume"] == pytest.approx(2.0)
    assert compat_positions[0]["price"] == pytest.approx(99.5)
    assert store.is_connected is False
    assert client.connect_calls == 0

    positions[0]["volume"] = 999

    assert store._positions_cache[0]["volume"] == pytest.approx(2.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(2.0)


def test_store_seeded_position_queries_fall_back_to_cached_values_before_start_when_query_fails():
    """Test fallback to cached positions when query fails before store start."""

    class FailingPositionsClient(FakeBtApiClient):
        """Client that fails position queries but tracks connect calls."""

        def __init__(self):
            """Initialize the failing positions client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

        def get_positions(self):
            """Raise error to simulate positions unavailable."""
            raise RuntimeError("positions unavailable")

    client = FailingPositionsClient()
    store = make_store(
        api=client,
        positions=[{"instrument": DEFAULT_SYMBOL, "volume": 2.0, "price": 99.5}],
    )

    assert store.is_connected is False
    positions = store.get_positions()
    compat_positions = store.getpositions()
    assert positions[0]["instrument"] == DEFAULT_SYMBOL
    assert positions[0]["volume"] == pytest.approx(2.0)
    assert positions[0]["price"] == pytest.approx(99.5)
    assert compat_positions[0]["instrument"] == DEFAULT_SYMBOL
    assert compat_positions[0]["volume"] == pytest.approx(2.0)
    assert compat_positions[0]["price"] == pytest.approx(99.5)
    assert store.is_connected is True
    assert client.connect_calls == 1

    positions[0]["volume"] = 999
    compat_positions[0]["volume"] = 555

    assert store._positions_cache[0]["volume"] == pytest.approx(2.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(2.0)


def test_store_seeded_open_order_queries_return_cached_values_before_start():
    """Test that seeded open order queries return cached values before store start."""

    class TrackingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = TrackingClient()
    store = make_store(api=client, open_orders_cache_ttl=60.0)
    store._open_orders_cache = [{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]
    store._last_open_orders_refresh = time.monotonic()

    assert store.is_connected is False
    open_orders = store.fetch_open_orders()
    alias_orders = store.get_open_orders()
    compat_orders = store.getopenorders()
    assert [item["id"] for item in open_orders] == ["btapi-1"]
    assert [item["id"] for item in alias_orders] == ["btapi-1"]
    assert [item["id"] for item in compat_orders] == ["btapi-1"]
    assert store.is_connected is False
    assert client.connect_calls == 0

    open_orders[0]["id"] = "mutated"

    assert store._open_orders_cache[0]["id"] == "btapi-1"
    assert store.fetch_open_orders()[0]["id"] == "btapi-1"


def test_store_seeded_open_order_queries_fall_back_to_cached_values_before_start_when_query_fails():
    """Test fallback to cached open orders when query fails before store start."""

    class FailingOpenOrdersClient(FakeBtApiClient):
        """Client that fails open order queries but tracks connect calls."""

        def __init__(self):
            """Initialize the failing open orders client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

        def fetch_open_orders(self):
            """Raise error to simulate open orders unavailable."""
            raise RuntimeError("open orders unavailable")

    client = FailingOpenOrdersClient()
    store = make_store(api=client)
    store._open_orders_cache = [{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]
    store._last_open_orders_refresh = time.monotonic()

    assert store.is_connected is False
    open_orders = store.fetch_open_orders()
    alias_orders = store.get_open_orders()
    compat_orders = store.getopenorders()
    assert [item["id"] for item in open_orders] == ["btapi-1"]
    assert [item["id"] for item in alias_orders] == ["btapi-1"]
    assert [item["id"] for item in compat_orders] == ["btapi-1"]
    assert store.is_connected is True
    assert client.connect_calls == 1

    open_orders[0]["id"] = "mutated"
    alias_orders[0]["id"] = "alias-mutated"

    assert store._open_orders_cache[0]["id"] == "btapi-1"
    assert store.fetch_open_orders()[0]["id"] == "btapi-1"


def test_store_queries_connect_on_demand_before_start_when_cache_is_not_fresh():
    """Test that queries connect on demand when cache is not fresh."""

    class TrackingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = TrackingClient()
    store = make_store(api=client)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 10000.0, "value": 10000.0}
    assert store.get_cash() == pytest.approx(10000.0)
    assert store.get_value() == pytest.approx(10000.0)
    assert store.getcash() == pytest.approx(10000.0)
    assert store.getvalue() == pytest.approx(10000.0)
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_account_queries_work_before_start_with_lightweight_get_balance_client_without_connect_method():
    """Test account queries work with lightweight client that has no connect method."""

    class LightweightBalanceClient:
        """Lightweight client with only get_balance method."""

        def get_balance(self):
            """Return mock balance data."""
            return {"cash": 10000.0, "value": 10000.0}

    store = make_store(api=LightweightBalanceClient(), account_cache_ttl=60.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 10000.0, "value": 10000.0}
    assert store.get_cash() == pytest.approx(10000.0)
    assert store.get_value() == pytest.approx(10000.0)
    assert store.getcash() == pytest.approx(10000.0)
    assert store.getvalue() == pytest.approx(10000.0)
    assert store.getvalue(datas=[object()]) == pytest.approx(10000.0)
    assert store.is_connected is True


def test_store_account_queries_use_get_account_alias_on_demand_before_start():
    """Test that account queries use get_account on demand before store start."""

    class AccountOnlyClient:
        """Client with only connect/disconnect and get_account methods."""

        def __init__(self):
            """Initialize the account-only client."""
            self.connected = False
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_account(self):
            """Return mock account data."""
            return {"cash": 1234.0, "value": 1500.0}

    client = AccountOnlyClient()
    store = make_store(api=client, account_cache_ttl=60.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 1234.0, "value": 1500.0}
    assert store.get_cash() == pytest.approx(1234.0)
    assert store.get_value() == pytest.approx(1500.0)
    assert store.getcash() == pytest.approx(1234.0)
    assert store.getvalue() == pytest.approx(1500.0)
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_account_queries_use_get_account_alias_on_demand_before_start_without_connect_method():
    """Test that lightweight account-only client works without connect method."""

    class LightweightAccountOnlyClient:
        """Lightweight client with only get_account method."""

        def get_account(self):
            """Return mock account data."""
            return {"cash": 1234.0, "value": 1500.0}

    store = make_store(api=LightweightAccountOnlyClient(), account_cache_ttl=60.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 1234.0, "value": 1500.0}
    assert store.get_cash() == pytest.approx(1234.0)
    assert store.get_value() == pytest.approx(1500.0)
    assert store.getcash() == pytest.approx(1234.0)
    assert store.getvalue() == pytest.approx(1500.0)
    assert store.getvalue(datas=[object()]) == pytest.approx(1500.0)
    assert store.is_connected is True


def test_store_account_queries_fall_back_to_cached_values_before_start_when_unsupported():
    """Test fallback to cached values when account query is unsupported."""

    class NoAccountQueryClient:
        """Client with no account query capability."""

    store = make_store(api=NoAccountQueryClient(), cash=321.0, value=654.0)

    assert store.is_connected is False
    assert store.get_balance() == {"cash": 321.0, "value": 654.0}
    assert store.get_cash() == pytest.approx(321.0)
    assert store.get_value() == pytest.approx(654.0)
    assert store.getcash() == pytest.approx(321.0)
    assert store.getvalue() == pytest.approx(654.0)
    assert store.is_connected is True


def test_store_open_order_queries_connect_on_demand_before_start_when_cache_is_not_fresh():
    """Test that open order queries connect on demand when cache is not fresh."""

    class TrackingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__(
                open_orders=[{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]
            )
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = TrackingClient()
    store = make_store(api=client)

    assert store.is_connected is False
    open_orders = store.fetch_open_orders()
    alias_orders = store.get_open_orders()
    compat_orders = store.getopenorders()
    assert [item["id"] for item in open_orders] == ["btapi-1"]
    assert [item["id"] for item in alias_orders] == ["btapi-1"]
    assert [item["id"] for item in compat_orders] == ["btapi-1"]
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_open_order_queries_work_before_start_with_lightweight_client_without_connect_method():
    """Test that open order queries work with lightweight client without connect method."""

    class LightweightOpenOrdersClient:
        """Lightweight client with only fetch_open_orders method."""

        def fetch_open_orders(self):
            """Return mock open orders."""
            return [{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]

    store = make_store(api=LightweightOpenOrdersClient(), open_orders_cache_ttl=60.0)

    assert store.is_connected is False
    open_orders = store.fetch_open_orders()
    alias_orders = store.get_open_orders()
    compat_orders = store.getopenorders()
    assert [item["id"] for item in open_orders] == ["btapi-1"]
    assert [item["id"] for item in alias_orders] == ["btapi-1"]
    assert [item["id"] for item in compat_orders] == ["btapi-1"]
    assert store.is_connected is True

    open_orders[0]["id"] = "mutated"
    alias_orders[0]["id"] = "alias-mutated"

    assert store._open_orders_cache[0]["id"] == "btapi-1"
    assert store.fetch_open_orders()[0]["id"] == "btapi-1"


def test_store_open_order_queries_fall_back_to_get_open_orders_alias_before_start_without_connect_method():
    """Test fallback to get_open_orders alias when fetch_open_orders is unavailable."""

    class LightweightAliasOpenOrdersClient:
        """Lightweight client with only get_open_orders method."""

        def get_open_orders(self):
            """Return mock open orders."""
            return [{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]

    store = make_store(api=LightweightAliasOpenOrdersClient(), open_orders_cache_ttl=60.0)

    assert store.is_connected is False
    open_orders = store.fetch_open_orders()
    alias_orders = store.get_open_orders()
    compat_orders = store.getopenorders()
    assert [item["id"] for item in open_orders] == ["btapi-1"]
    assert [item["id"] for item in alias_orders] == ["btapi-1"]
    assert [item["id"] for item in compat_orders] == ["btapi-1"]
    assert store.is_connected is True

    open_orders[0]["id"] = "mutated"
    compat_orders[0]["id"] = "compat-mutated"

    assert store._open_orders_cache[0]["id"] == "btapi-1"
    assert store.fetch_open_orders()[0]["id"] == "btapi-1"


def test_store_open_order_queries_fall_back_to_empty_list_before_start_when_unsupported():
    """Test fallback to empty list when open order query is unsupported."""

    class NoOpenOrderClient(FakeBtApiClient):
        """Client that raises AttributeError on fetch_open_orders."""

        def __init__(self):
            """Initialize the no open order client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

        def fetch_open_orders(self):
            """Raise AttributeError to simulate unsupported."""
            raise AttributeError("unsupported")

    client = NoOpenOrderClient()
    store = make_store(api=client)

    assert store.is_connected is False
    assert store.fetch_open_orders() == []
    assert store.get_open_orders() == []
    assert store.getopenorders() == []
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_position_queries_work_before_start_with_lightweight_client_without_connect_method():
    """Test that position queries work with lightweight client without connect method."""

    class LightweightPositionsClient:
        """Lightweight client with only get_positions method."""

        def get_positions(self):
            """Return mock positions data."""
            return [{"instrument": DEFAULT_SYMBOL, "volume": 2.0, "price": 99.5}]

    store = make_store(api=LightweightPositionsClient(), positions_cache_ttl=60.0)

    assert store.is_connected is False
    positions = store.get_positions()
    compat_positions = store.getpositions()
    assert positions[0]["instrument"] == DEFAULT_SYMBOL
    assert positions[0]["volume"] == pytest.approx(2.0)
    assert positions[0]["price"] == pytest.approx(99.5)
    assert compat_positions[0]["instrument"] == DEFAULT_SYMBOL
    assert compat_positions[0]["volume"] == pytest.approx(2.0)
    assert compat_positions[0]["price"] == pytest.approx(99.5)
    assert store.is_connected is True

    positions[0]["volume"] = 999
    compat_positions[0]["volume"] = 555

    assert store._positions_cache[0]["volume"] == pytest.approx(2.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(2.0)


def test_store_position_queries_fall_back_to_empty_list_before_start_when_unsupported():
    """Test fallback to empty list when position query is unsupported."""

    class NoPositionsClient(FakeBtApiClient):
        """Client that fails position queries."""

        def __init__(self):
            """Initialize the no positions client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

        def get_positions(self):
            """Raise AttributeError to simulate unsupported."""
            raise AttributeError("unsupported")

    client = NoPositionsClient()
    store = make_store(api=client)

    assert store.is_connected is False
    assert store.get_positions() == []
    assert store.getpositions() == []
    assert store.is_connected is True
    assert client.connect_calls == 1


def test_store_query_results_do_not_expose_mutable_internal_caches():
    """Test that query results do not expose mutable internal caches."""
    client = FakeBtApiClient(
        positions=[{"instrument": DEFAULT_SYMBOL, "volume": 2, "price": 99.5}],
        open_orders=[{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy", "price": 101.0}],
    )
    store = make_store(api=client, positions_cache_ttl=60.0, open_orders_cache_ttl=60.0)
    store.start()

    positions = store.get_positions()
    compat_positions = store.getpositions()
    open_orders = store.fetch_open_orders()
    alias_open_orders = store.get_open_orders()
    compat_open_orders = store.getopenorders()

    positions[0]["volume"] = 999
    compat_positions[0]["volume"] = 555
    open_orders[0]["id"] = "mutated"
    alias_open_orders[0]["id"] = "alias-mutated"
    compat_open_orders[0]["id"] = "compat-mutated"

    assert store.get_positions()[0]["volume"] == pytest.approx(2.0)
    assert store.getpositions()[0]["volume"] == pytest.approx(2.0)
    assert store.fetch_open_orders()[0]["id"] == "btapi-1"
    assert store.get_open_orders()[0]["id"] == "btapi-1"
    assert store.getopenorders()[0]["id"] == "btapi-1"


def test_store_fetch_history_results_do_not_expose_mutable_cache():
    """Test that fetch history results do not expose mutable cache."""
    client = FakeBtApiClient(history={DEFAULT_SYMBOL: [make_bar(0, 100.0, 101.0, 99.0, 100.5)]})
    store = make_store(api=client)
    store.start()

    history = store.fetch_history(DEFAULT_SYMBOL)
    history[0]["close"] = 999.0

    assert store.fetch_history(DEFAULT_SYMBOL)[0]["close"] == pytest.approx(100.5)


def test_store_proxies_live_orderbook_polling():
    """Store should expose fake-client orderbook queues through the live polling helpers."""
    client = FakeBtApiClient(live_orderbooks={DEFAULT_SYMBOL: [make_orderbook(0, 100.0, 100.5)]})
    store = make_store(api=client)

    store.start()

    assert store.supports_live_orderbook(DEFAULT_SYMBOL) is True
    assert store.has_pending_orderbook(DEFAULT_SYMBOL) is True

    orderbook = store.poll_orderbook(DEFAULT_SYMBOL)

    assert orderbook.best_bid == pytest.approx(100.0)
    assert orderbook.best_ask == pytest.approx(100.5)
    assert store.has_pending_orderbook(DEFAULT_SYMBOL) is False


def test_store_proxies_live_tick_polling():
    """Test that store proxies live tick polling."""
    client = FakeBtApiClient(live_ticks={DEFAULT_SYMBOL: [make_tick(0, 100.0)]})
    store = make_store(api=client)

    store.start()

    assert store.supports_live_ticks(DEFAULT_SYMBOL) is True
    assert store.has_pending_tick(DEFAULT_SYMBOL) is True

    tick = store.poll_tick(DEFAULT_SYMBOL)

    assert tick.price == pytest.approx(100.0)
    assert store.has_pending_tick(DEFAULT_SYMBOL) is False


def test_store_live_bar_queries_fall_back_to_get_next_bar_alias():
    """Test fallback to get_next_bar alias when poll_live returns None."""

    class AliasOnlyLiveBarClient:
        """Client with only get_next_bar method for live bars."""

        def __init__(self):
            """Initialize the alias-only live bar client."""
            self.connected = False
            self._bar = make_bar(0, 100.0, 101.0, 99.0, 100.5)

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_next_bar(self, symbol):
            """Return the next bar and clear it."""
            bar, self._bar = self._bar, None
            return bar

    client = AliasOnlyLiveBarClient()
    store = make_store(api=client)
    store.start()

    live_bar = store.poll_live(DEFAULT_SYMBOL)

    assert live_bar["close"] == pytest.approx(100.5)
    assert store.poll_live(DEFAULT_SYMBOL) is None


def test_store_live_bar_queries_work_before_start_with_lightweight_get_next_bar_client_without_connect_method():
    """Test that live bar queries work with lightweight get_next_bar client."""

    class LightweightLiveBarClient:
        """Lightweight client with only get_next_bar method."""

        def __init__(self):
            """Initialize the lightweight live bar client."""
            self._bar = make_bar(0, 100.0, 101.0, 99.0, 100.5)

        def get_next_bar(self, symbol):
            """Return the next bar and clear it."""
            bar, self._bar = self._bar, None
            return bar

    store = make_store(api=LightweightLiveBarClient())

    assert store.is_connected is False

    live_bar = store.poll_live(DEFAULT_SYMBOL)

    assert live_bar["close"] == pytest.approx(100.5)
    assert store.poll_live(DEFAULT_SYMBOL) is None
    assert store.is_connected is True


def test_store_live_bar_queries_work_before_start_with_lightweight_poll_bar_client_without_connect_method():
    """Test that live bar queries work with lightweight poll_bar client without connect method."""

    class LightweightPollBarClient:
        """Lightweight client with only poll_bar method."""

        def __init__(self):
            """Initialize the lightweight poll bar client."""
            self._bar = make_bar(0, 100.0, 101.0, 99.0, 100.5)

        def poll_bar(self, symbol):
            """Return the next bar and clear it."""
            bar, self._bar = self._bar, None
            return bar

    store = make_store(api=LightweightPollBarClient())

    assert store.is_connected is False

    live_bar = store.poll_live(DEFAULT_SYMBOL)

    assert live_bar["close"] == pytest.approx(100.5)
    assert store.poll_live(DEFAULT_SYMBOL) is None
    assert store.is_connected is True


def test_store_history_queries_fall_back_to_fetch_ohlcv_alias():
    """Test fallback to fetch_ohlcv alias for history queries."""

    class AliasOnlyHistoryClient:
        """Client with only fetch_ohlcv method for history."""

        def __init__(self):
            """Initialize the alias-only history client."""
            self.connected = False

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def fetch_ohlcv(self, symbol, timeframe=None, compression=1, since=None, limit=None):
            """Return mock OHLCV data."""
            return [make_bar(0, 100.0, 101.0, 99.0, 100.5)]

    client = AliasOnlyHistoryClient()
    store = make_store(api=client)
    store.start()

    history = store.fetch_history(DEFAULT_SYMBOL)

    assert len(history) == 1
    assert history[0]["close"] == pytest.approx(100.5)


def test_store_history_queries_work_before_start_with_lightweight_fetch_ohlcv_client_without_connect_method():
    """Test that history queries work with lightweight fetch_ohlcv client without connect method."""

    class LightweightHistoryClient:
        """Lightweight client with only fetch_ohlcv method."""

        def fetch_ohlcv(self, symbol, timeframe=None, compression=1, since=None, limit=None):
            """Return mock OHLCV data."""
            return [make_bar(0, 100.0, 101.0, 99.0, 100.5)]

    store = make_store(api=LightweightHistoryClient())

    assert store.is_connected is False

    history = store.fetch_history(DEFAULT_SYMBOL)

    assert len(history) == 1
    assert history[0]["close"] == pytest.approx(100.5)
    assert store.is_connected is True

    history[0]["close"] = 999.0

    assert store._historical_bars[DEFAULT_SYMBOL][0]["close"] == pytest.approx(100.5)
    assert store.fetch_history(DEFAULT_SYMBOL)[0]["close"] == pytest.approx(100.5)


def test_store_history_cache_is_scoped_by_query_signature():
    """Test that history cache is scoped by query parameters (timeframe, compression, limit)."""

    class ParameterAwareHistoryClient:
        """Client that tracks fetch_bars calls and returns different bars based on timeframe."""

        def __init__(self):
            """Initialize the parameter-aware history client."""
            self.connected = False
            self.calls = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def fetch_bars(self, symbol, timeframe=None, compression=1, since=None, limit=None):
            """Return bars based on timeframe parameter."""
            self.calls.append((symbol, timeframe, compression, since, limit))
            if timeframe == "M5":
                return [make_bar(0, 105.0, 106.0, 104.0, 105.5)]
            return [make_bar(0, 100.0, 101.0, 99.0, 100.5)]

    client = ParameterAwareHistoryClient()
    store = make_store(api=client)
    store.start()

    minute_bars = store.fetch_history(DEFAULT_SYMBOL, timeframe="M1", compression=1, limit=1)
    five_minute_bars = store.fetch_history(DEFAULT_SYMBOL, timeframe="M5", compression=5, limit=1)
    cached_minute_bars = store.fetch_history(DEFAULT_SYMBOL, timeframe="M1", compression=1, limit=1)

    assert minute_bars[0]["close"] == pytest.approx(100.5)
    assert five_minute_bars[0]["close"] == pytest.approx(105.5)
    assert cached_minute_bars[0]["close"] == pytest.approx(100.5)
    assert client.calls == [
        (DEFAULT_SYMBOL, "M1", 1, None, 1),
        (DEFAULT_SYMBOL, "M5", 5, None, 1),
    ]


def test_store_live_tick_queries_fall_back_to_get_next_tick_alias():
    """Test fallback to get_next_tick alias when poll_tick returns None."""

    class AliasOnlyTickClient:
        """Client with only get_next_tick method for live ticks."""

        def __init__(self):
            """Initialize the alias-only tick client."""
            self.connected = False
            self._tick = make_tick(0, 100.0)

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_next_tick(self, symbol):
            """Return the next tick and clear it."""
            tick, self._tick = self._tick, None
            return tick

    client = AliasOnlyTickClient()
    store = make_store(api=client)
    store.start()

    tick = store.poll_tick(DEFAULT_SYMBOL)

    assert tick.price == pytest.approx(100.0)
    assert store.poll_tick(DEFAULT_SYMBOL) is None


def test_store_live_tick_queries_return_none_before_start_with_lightweight_get_next_tick_client_without_connect_method():
    """Test that tick queries return None before start with lightweight client without connect method."""

    class LightweightTickClient:
        """Lightweight client with only get_next_tick method."""

        def __init__(self):
            """Initialize the lightweight tick client."""
            self._tick = make_tick(0, 100.0)

        def get_next_tick(self, symbol):
            """Return the next tick and clear it."""
            tick, self._tick = self._tick, None
            return tick

    store = make_store(api=LightweightTickClient())

    assert store.is_connected is False

    assert store.poll_tick(DEFAULT_SYMBOL) is None
    assert store.is_connected is False


def test_store_live_orderbook_queries_fall_back_to_get_next_orderbook_alias():
    """Test fallback to get_next_orderbook alias for orderbook queries."""

    class AliasOnlyOrderbookClient:
        """Client with only get_next_orderbook method for orderbook."""

        def __init__(self):
            """Initialize the alias-only orderbook client."""
            self.connected = False
            self._orderbook = make_orderbook(0, 100.0, 100.5)

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_next_orderbook(self, symbol):
            """Return the next orderbook and clear it."""
            orderbook, self._orderbook = self._orderbook, None
            return orderbook

    client = AliasOnlyOrderbookClient()
    store = make_store(api=client)
    store.start()

    orderbook = store.poll_orderbook(DEFAULT_SYMBOL)

    assert orderbook.best_bid == pytest.approx(100.0)
    assert orderbook.best_ask == pytest.approx(100.5)
    assert store.poll_orderbook(DEFAULT_SYMBOL) is None


def test_store_live_orderbook_queries_return_none_before_start_with_lightweight_get_next_orderbook_client_without_connect_method():
    """Test that orderbook queries return None before start with lightweight client."""

    class LightweightOrderbookClient:
        """Lightweight client with only get_next_orderbook method."""

        def __init__(self):
            """Initialize the lightweight orderbook client."""
            self._orderbook = make_orderbook(0, 100.0, 100.5)

        def get_next_orderbook(self, symbol):
            """Return the next orderbook and clear it."""
            orderbook, self._orderbook = self._orderbook, None
            return orderbook

    store = make_store(api=LightweightOrderbookClient())

    assert store.is_connected is False
    assert store.poll_orderbook(DEFAULT_SYMBOL) is None
    assert store.is_connected is False


def test_store_supports_live_orderbook_falls_back_to_live_orderbooks_attribute():
    """Test fallback to live_orderbooks attribute when poll_orderbook is unavailable."""

    class AttributeOnlyOrderbookClient:
        """Client with only live_orderbooks attribute."""

        def __init__(self):
            """Initialize the attribute-only orderbook client."""
            self.connected = False
            self.live_orderbooks = {DEFAULT_SYMBOL: [make_orderbook(0, 100.0, 100.5)]}

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

    client = AttributeOnlyOrderbookClient()
    store = make_store(api=client)
    store.start()

    assert store.supports_live_orderbook(DEFAULT_SYMBOL) is True
    assert store.supports_live_orderbook("UNKNOWN") is False
    assert store.has_pending_orderbook(DEFAULT_SYMBOL) is True
    assert store.has_pending_orderbook("UNKNOWN") is False


@pytest.mark.parametrize(
    ("helper_name", "client_attr", "payload"),
    [
        ("supports_live_ticks", "live_ticks", {DEFAULT_SYMBOL: [make_tick(0, 100.0)]}),
        ("has_pending_tick", "live_ticks", {DEFAULT_SYMBOL: [make_tick(0, 100.0)]}),
        (
            "supports_live_orderbook",
            "live_orderbooks",
            {DEFAULT_SYMBOL: [make_orderbook(0, 100.0, 100.5)]},
        ),
        (
            "has_pending_orderbook",
            "live_orderbooks",
            {DEFAULT_SYMBOL: [make_orderbook(0, 100.0, 100.5)]},
        ),
    ],
)
def test_store_live_state_helpers_return_false_before_start_even_when_lightweight_client_exposes_live_attributes(
    helper_name, client_attr, payload
):
    """Test that live state helpers return False before start even when client exposes live attributes."""

    class AttributeOnlyLiveClient:
        """Client that only exposes live state attributes without connect method."""

        def __init__(self):
            """Initialize the attribute-only live client."""
            self.connected = False
            setattr(self, client_attr, payload)

    store = make_store(api=AttributeOnlyLiveClient())

    assert store.is_connected is False
    assert getattr(store, helper_name)(DEFAULT_SYMBOL) is False
    assert store.is_connected is False


def test_store_live_tick_state_falls_back_to_live_ticks_attribute():
    """Test fallback to live_ticks attribute when poll_tick is unavailable."""

    class AttributeOnlyTickClient:
        """Client with only live_ticks attribute."""

        def __init__(self):
            """Initialize the attribute-only tick client."""
            self.connected = False
            self.live_ticks = {DEFAULT_SYMBOL: [make_tick(0, 100.0)]}

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

    client = AttributeOnlyTickClient()
    store = make_store(api=client)
    store.start()

    assert store.supports_live_ticks(DEFAULT_SYMBOL) is True
    assert store.supports_live_ticks("UNKNOWN") is False
    assert store.has_pending_tick(DEFAULT_SYMBOL) is True
    assert store.has_pending_tick("UNKNOWN") is False


def test_store_subscription_is_idempotent_within_session_and_resets_after_stop():
    """Test that subscription is idempotent within session and resets after stop."""
    client = FakeBtApiClient()
    store = make_store(api=client)

    store.start()
    store.subscribe(DEFAULT_SYMBOL)
    store.subscribe(DEFAULT_SYMBOL)

    assert client.subscriptions == [DEFAULT_SYMBOL]


def test_store_subscribe_without_api_method_is_noop_and_does_not_mark_symbol_subscribed():
    """Test that subscribe is a noop when client has no subscribe method."""

    class NoSubscribeClient:
        """Client without subscribe capability."""

        def __init__(self):
            """Initialize the no-subscribe client."""
            self.connected = False

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

    store = make_store(api=NoSubscribeClient())

    store.start()
    store.subscribe(DEFAULT_SYMBOL)

    assert DEFAULT_SYMBOL not in store._subscribed_datanames
    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]
    assert "market_data_subscribe_request" not in event_types


def test_store_subscribe_works_before_start_with_lightweight_client_without_connect_method():
    """Test that subscribe works before start with lightweight client without connect method."""

    class LightweightSubscribeClient:
        """Lightweight client with only subscribe method."""

        def __init__(self):
            """Initialize the lightweight subscribe client."""
            self.subscriptions = []

        def subscribe(self, dataname):
            """Subscribe to a dataname."""
            self.subscriptions.append(dataname)

    store = make_store(api=LightweightSubscribeClient())

    assert store.is_connected is False

    store.subscribe(DEFAULT_SYMBOL)
    store.subscribe(DEFAULT_SYMBOL)

    assert store.is_connected is True
    assert store._subscribed_datanames == {DEFAULT_SYMBOL}
    assert store._api.subscriptions == [DEFAULT_SYMBOL]
    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]
    assert "market_data_subscribe_request" in event_types


def test_store_subscribe_before_start_is_noop_for_lightweight_client_without_connect_or_subscribe_method():
    """Test that subscribe is noop when client has neither connect nor subscribe method."""

    class NoSubscribeClient:
        """Client with no subscribe or connect capability."""

    store = make_store(api=NoSubscribeClient())

    assert store.is_connected is False

    store.subscribe(DEFAULT_SYMBOL)

    assert store.is_connected is True
    assert DEFAULT_SYMBOL not in store._subscribed_datanames
    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]
    assert "market_data_subscribe_request" not in event_types


def test_store_subscribe_connects_on_demand_before_start():
    """Test that subscribe connects on demand before start."""

    class TrackingSubscribeClient:
        """Client that tracks connect calls and subscriptions."""

        def __init__(self):
            """Initialize the tracking subscribe client."""
            self.connected = False
            self.connect_calls = 0
            self.subscriptions = []

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def subscribe(self, dataname):
            """Subscribe to a dataname."""
            self.subscriptions.append(dataname)

    client = TrackingSubscribeClient()
    store = make_store(api=client)

    assert store.is_connected is False

    store.subscribe(DEFAULT_SYMBOL)
    store.subscribe(DEFAULT_SYMBOL)

    assert store.is_connected is True
    assert client.connect_calls == 1
    assert client.subscriptions == [DEFAULT_SYMBOL]
    assert store._subscribed_datanames == {DEFAULT_SYMBOL}


def test_store_stop_before_start_is_silent_noop():
    """Test that stop before start is a silent noop."""

    class TrackingClient(FakeBtApiClient):
        """Client that tracks disconnect() call count."""

        def __init__(self):
            """Initialize the tracking client."""
            super().__init__()
            self.disconnect_calls = 0

        def disconnect(self):
            """Disconnect and increment counter."""
            self.disconnect_calls += 1
            return super().disconnect()

    client = TrackingClient()
    store = make_store(api=client)

    store.stop()

    assert client.disconnect_calls == 0
    assert store.get_notifications() == []


def test_store_deduplicates_subscriptions_within_session_but_resubscribes_after_restart():
    """Test that subscriptions are deduplicated within session but resubscribed after restart."""
    client = FakeBtApiClient()
    store = make_store(api=client)

    store.start()
    store.subscribe(DEFAULT_SYMBOL)
    store.subscribe(DEFAULT_SYMBOL)

    assert client.subscriptions == [DEFAULT_SYMBOL]

    store.stop()
    store.start()
    store.subscribe(DEFAULT_SYMBOL)

    assert client.subscriptions == [DEFAULT_SYMBOL, DEFAULT_SYMBOL]


def test_store_stop_is_idempotent_and_does_not_duplicate_disconnect_events():
    """Test that stop is idempotent and does not duplicate disconnect events."""
    client = FakeBtApiClient()
    store = make_store(api=client)

    store.start()
    store.stop()
    store.stop()

    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]

    assert event_types.count("store_disconnect_requested") == 1
    assert event_types.count("store_disconnected") == 1


def test_store_stop_falls_back_to_api_stop_when_disconnect_is_unavailable():
    """Test fallback to stop() when disconnect() is unavailable."""

    class StopOnlyClient:
        """Client with only connect and stop methods (no disconnect)."""

        def __init__(self):
            """Initialize the stop-only client."""
            self.connected = False
            self.stop_calls = 0

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def stop(self):
            """Stop and increment counter."""
            self.stop_calls += 1
            self.connected = False

    client = StopOnlyClient()
    store = make_store(api=client)

    store.start()
    store.stop()

    assert client.stop_calls == 1
    assert store.is_connected is False


def test_store_start_falls_back_to_api_start_when_connect_is_unavailable():
    """Test fallback to start() when connect() is unavailable."""

    class StartOnlyClient:
        """Client with only start and stop methods (no connect/disconnect)."""

        def __init__(self):
            """Initialize the start-only client."""
            self.connected = False
            self.start_calls = 0

        def start(self):
            """Start and increment counter."""
            self.start_calls += 1
            self.connected = True

        def stop(self):
            """Stop and set connected to False."""
            self.connected = False

    client = StartOnlyClient()
    store = make_store(api=client)

    store.start()

    assert client.start_calls == 1
    assert store.is_connected is True


def test_store_start_marks_lightweight_client_ready_without_connect_or_start_methods():
    """Test that lightweight client is marked ready without connect/start methods."""

    class LightweightClient:
        """Lightweight client with only get_balance method."""

        def get_balance(self):
            """Return mock balance data."""
            return {"cash": 1000.0, "value": 1200.0}

    store = make_store(api=LightweightClient())

    store.start()

    assert store.is_connected is True
    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]
    assert event_types[:3] == ["store_connecting", "store_connected", "store_ready"]


def test_store_autostart_connects_during_construction_and_emits_startup_events():
    """Test that autostart connects during construction and emits startup events."""

    class CountingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the counting client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = CountingClient()
    store = make_store(api=client, autostart=True)

    assert client.connect_calls == 1
    assert store.is_connected is True
    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]
    assert event_types[:3] == ["store_connecting", "store_connected", "store_ready"]


def test_store_start_is_idempotent_and_does_not_duplicate_connect_events():
    """Test that start is idempotent and does not duplicate connect events."""

    class CountingClient(FakeBtApiClient):
        """Client that tracks connect() call count."""

        def __init__(self):
            """Initialize the counting client."""
            super().__init__()
            self.connect_calls = 0

        def connect(self):
            """Connect and increment counter."""
            self.connect_calls += 1
            return super().connect()

    client = CountingClient()
    store = make_store(api=client)

    store.start()
    store.start()

    event_types = [
        kwargs["event"]["event_type"] for _msg, _args, kwargs in store.get_notifications()
    ]

    assert client.connect_calls == 1
    assert event_types.count("store_connecting") == 1
    assert event_types.count("store_connected") == 1
    assert event_types.count("store_ready") == 1


def test_ctp_store_emits_auth_login_success_from_session_state():
    """CTP auth/login success events should use real session metadata."""

    class AuthenticatedCtpClient(FakeBtApiClient):
        def get_session_state(self):
            return {
                "auth_state": "authenticated",
                "login_state": "logged_in",
                "front_id": 7,
                "session_id": 8801,
                "trading_day": "20260618",
            }

    store = make_store(api=AuthenticatedCtpClient(), provider="ctp")

    store.start()

    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    event_types = [event["event_type"] for event in runtime_events]
    assert "store_auth_request" in event_types
    assert "store_auth_success" in event_types
    assert "store_login_success" in event_types
    assert event_types.index("store_login_success") < event_types.index("store_ready")
    login_event = next(
        event for event in runtime_events if event["event_type"] == "store_login_success"
    )
    assert login_event["details"]["front_id"] == 7
    assert login_event["details"]["session_id"] == 8801
    assert login_event["details"]["trading_day"] == "20260618"


def test_ctp_store_prefers_inner_trader_session_state_over_unknown_wrapper_state():
    """Wrapper-level unknown state should not hide inner CTP trader metadata."""

    class InnerTrader:
        def get_session_state(self):
            return {
                "connected": True,
                "ready": True,
                "auth_state": "authenticated",
                "login_state": "logged_in",
                "front_id": 8,
                "session_id": 8802,
                "trading_day": "20260619",
            }

    class WrapperCtpClient(FakeBtApiClient):
        def __init__(self):
            super().__init__()
            self.trader_client = InnerTrader()

        def get_session_state(self):
            return {
                "connected": True,
                "ready": False,
                "auth_state": "unknown",
                "login_state": "unknown",
            }

    store = make_store(api=WrapperCtpClient(), provider="ctp")

    store.start()

    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    login_event = next(
        event for event in runtime_events if event["event_type"] == "store_login_success"
    )

    assert login_event["details"]["front_id"] == 8
    assert login_event["details"]["session_id"] == 8802
    assert login_event["details"]["trading_day"] == "20260619"


def test_ctp_store_blocks_ready_when_authentication_failed():
    """CTP auth failure must not be reported as store_ready/auth_success."""

    class FailedAuthCtpClient(FakeBtApiClient):
        def get_session_state(self):
            return {
                "auth_state": "failed",
                "login_state": "blocked",
                "last_auth_error": {"error_id": 63, "error_msg": "auth failed"},
            }

    store = make_store(api=FailedAuthCtpClient(), provider="ctp")

    with pytest.raises(BtApiStoreError, match="CTP authentication failed"):
        store.start()

    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    event_types = [event["event_type"] for event in runtime_events]
    assert "store_auth_request" in event_types
    assert "store_auth_failed" in event_types
    assert "store_auth_success" not in event_types
    assert "store_login_success" not in event_types
    assert "store_ready" not in event_types
    failed_event = next(
        event for event in runtime_events if event["event_type"] == "store_auth_failed"
    )
    assert failed_event["error_code"] == "63"
    assert failed_event["error_msg"] == "auth failed"
    assert store.is_connected is False


def test_store_start_does_not_duplicate_same_data_feed_binding():
    """Test that start does not duplicate same data feed binding."""
    store = make_store(api=FakeBtApiClient())
    feed = store.getdata(dataname=DEFAULT_SYMBOL, backfill_start=False)

    store.start(data=feed)
    store.start(data=feed)

    assert store._data_feeds == [feed]


def test_store_register_does_not_duplicate_same_data_feed_binding():
    """Test that register does not duplicate same data feed binding."""
    store = make_store(api=FakeBtApiClient())
    feed = store.getdata(dataname=DEFAULT_SYMBOL, backfill_start=False)

    store.register(feed)
    store.register(feed)

    assert store._data_feeds == [feed]


def test_store_factory_helpers_return_unified_components(fake_client):
    """Store factory helpers should return the unified broker/feed implementations."""
    store = make_store(api=fake_client)

    assert isinstance(store.getbroker(), BtApiBroker)
    assert isinstance(store.getdata(dataname=DEFAULT_SYMBOL), BtApiFeed)


def test_store_factory_helpers_fall_back_to_default_classes_when_cls_attributes_are_none(
    fake_client,
):
    """Test that factory helpers fall back to default classes when cls attributes are None."""
    store = make_store(api=fake_client)
    store.BrokerCls = None
    store.DataCls = None

    broker = store.getbroker()
    data = store.getdata(dataname=DEFAULT_SYMBOL, backfill_start=False)

    assert isinstance(broker, BtApiBroker)
    assert broker.store is store
    assert isinstance(data, BtApiFeed)
    assert data.store is store
    assert data._store is store


def test_store_getdata_binds_store_provider_and_store_alias_for_custom_data_cls(fake_client):
    """Test that getdata binds store, provider, and store alias for custom data class."""

    class DummyFeed(BtApiFeed):
        """Dummy feed for testing."""

    store = make_store(api=fake_client, provider="btapi")
    data = store.getdata(dataname=DEFAULT_SYMBOL, data_cls=DummyFeed)

    assert isinstance(data, DummyFeed)
    assert data.store is store
    assert data._store is store
    assert data.provider == "btapi"


def test_store_getdata_preserves_explicit_store_and_provider_arguments(fake_client):
    """Test that getdata preserves explicit store and provider arguments."""
    outer_store = make_store(api=fake_client, provider="outer")
    explicit_store = object()

    data = outer_store.getdata(
        dataname=DEFAULT_SYMBOL,
        backfill_start=False,
        store=explicit_store,
        provider="explicit",
    )

    assert data.store is explicit_store
    assert data.provider == "explicit"
    assert data._store is outer_store


def test_store_getbroker_binds_store_and_provider_for_custom_broker_cls(fake_client):
    """Test that getbroker binds store and provider for custom broker class."""

    class DummyBroker(BtApiBroker):
        """Dummy broker for testing."""

    store = make_store(api=fake_client, provider="btapi")
    broker = store.getbroker(broker_cls=DummyBroker)

    assert isinstance(broker, DummyBroker)
    assert broker.store is store
    assert broker.p.provider == "btapi"
    assert store._broker is broker


def test_store_getbroker_updates_store_broker_reference_to_latest_instance(fake_client):
    """Test that getbroker updates store broker reference to latest instance."""
    store = make_store(api=fake_client)

    broker_a = store.getbroker()
    broker_b = store.getbroker()

    assert broker_a is not broker_b
    assert store._broker is broker_b


def test_store_start_binds_provided_broker_instance(fake_client):
    """Test that start binds provided broker instance."""
    store = make_store(api=fake_client)
    broker = BtApiBroker(store=store, provider=store.provider)

    store.start(broker=broker)

    assert store._broker is broker


def test_store_start_binds_data_and_broker_in_single_call(fake_client):
    """Test that start binds data and broker in single call."""
    store = make_store(api=fake_client)
    broker = BtApiBroker(store=store, provider=store.provider)
    data = store.getdata(dataname=DEFAULT_SYMBOL, backfill_start=False)

    store.start(data=data, broker=broker)

    assert store._broker is broker
    assert store._data_feeds == [data]


def test_store_repeated_start_with_data_and_new_broker_updates_broker_without_duplicating_feed(
    fake_client,
):
    """Test that repeated start with data and new broker updates broker without duplicating feed."""
    store = make_store(api=fake_client)
    broker_a = BtApiBroker(store=store, provider=store.provider)
    broker_b = BtApiBroker(store=store, provider=store.provider)
    data = store.getdata(dataname=DEFAULT_SYMBOL, backfill_start=False)

    store.start(data=data, broker=broker_a)
    store.start(data=data, broker=broker_b)

    assert store._broker is broker_b
    assert store._data_feeds == [data]


def test_store_submit_order_uses_create_order_alias_and_emits_runtime_events():
    """Test that submit_order uses create_order alias and emits runtime events."""

    class CreateOrderOnlyClient:
        """Client with only create_order method (no submit_order)."""

        def __init__(self):
            """Initialize the create-order-only client."""
            self.connected = False
            self.created_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def create_order(self, **payload):
            """Create an order and track it."""
            self.created_orders.append(dict(payload))
            return {"id": "alias-1", "order_ref": "alias-ref-1"}

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.exectype = "limit"
            self.price = 101.0
            self.created = type("Created", (), {"price": 101.0})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()
            self.size = 2
            self.valid = None
            self.tradeid = 0
            self.pricelimit = None
            self.info = {}

        def getordername(self):
            """Return the order name."""
            return "Limit"

        def isbuy(self):
            """Return True for buy orders."""
            return True

    client = CreateOrderOnlyClient()
    store = make_store(api=client)

    response = store.submit_order(DummyOrder())

    assert response["id"] == "alias-1"
    assert store.is_connected is True
    assert client.created_orders[0]["symbol"] == DEFAULT_SYMBOL
    assert client.created_orders[0]["side"] == "buy"
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    assert any(event["event_type"] == "order_submit_request" for event in runtime_events)
    accepted = next(
        event for event in runtime_events if event["event_type"] == "order_submit_accepted"
    )
    assert accepted["order_ref"] == "alias-1"
    assert accepted["status"] == "accepted"


def test_store_submit_order_raises_clear_error_and_emits_reject_event_when_unsupported():
    """Test that submit_order raises clear error when unsupported."""

    class NoSubmitClient:
        """Client with no submit_order capability."""

        def __init__(self):
            """Initialize the no-submit client."""
            self.connected = False

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.exectype = "limit"
            self.price = 101.0
            self.created = type("Created", (), {"price": 101.0})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()
            self.size = 2
            self.valid = None
            self.tradeid = 0
            self.pricelimit = None
            self.info = {}

        def getordername(self):
            """Return the order name."""
            return "Limit"

        def isbuy(self):
            """Return True for buy orders."""
            return True

    store = make_store(api=NoSubmitClient())

    with pytest.raises(BtApiStoreError, match="does not support order submission"):
        store.submit_order(DummyOrder())

    assert store.is_connected is True
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    assert any(event["event_type"] == "order_submit_request" for event in runtime_events)
    rejected = next(
        event for event in runtime_events if event["event_type"] == "order_reject_remote"
    )
    assert rejected["order_ref"] == 7
    assert rejected["status"] == "rejected"


def test_store_submit_order_accepted_event_falls_back_to_local_order_ref_when_response_has_no_id():
    """Test that submit order accepted event falls back to local order ref when response has no id."""

    class OrderRefOnlyClient:
        """Client that returns only order_ref without id in create_order response."""

        def __init__(self):
            """Initialize the order-ref-only client."""
            self.connected = False
            self.created_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def create_order(self, **payload):
            """Create an order and return only order_ref."""
            self.created_orders.append(dict(payload))
            return {"order_ref": "alias-ref-1"}

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.exectype = "limit"
            self.price = 101.0
            self.created = type("Created", (), {"price": 101.0})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()
            self.size = 2
            self.valid = None
            self.tradeid = 0
            self.pricelimit = None
            self.info = {}

        def getordername(self):
            """Return the order name."""
            return "Limit"

        def isbuy(self):
            """Return True for buy orders."""
            return True

    store = make_store(api=OrderRefOnlyClient())

    response = store.submit_order(DummyOrder())

    assert response["order_ref"] == "alias-ref-1"
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    accepted = next(
        event for event in runtime_events if event["event_type"] == "order_submit_accepted"
    )
    assert accepted["order_ref"] == 7
    assert accepted["status"] == "accepted"


def test_store_submit_order_accepts_okx_data_list_response_and_extracts_ord_id():
    """OKX-style code/data-list submit responses should confirm order acceptance."""

    class OkxSubmitClient:
        def __init__(self):
            self.connected = False
            self.submitted_orders = []

        def connect(self):
            self.connected = True

        def disconnect(self):
            self.connected = False

        def submit_order(self, payload):
            self.submitted_orders.append(dict(payload))
            return {
                "code": "0",
                "msg": "",
                "data": [
                    {
                        "ordId": "okx-order-1",
                        "clOrdId": "local-client-1",
                        "sCode": "0",
                        "sMsg": "",
                    }
                ],
            }

    class DummyOrder:
        def __init__(self):
            self.ref = 7
            self.exectype = "limit"
            self.price = 101.0
            self.created = type("Created", (), {"price": 101.0})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()
            self.size = 2
            self.valid = None
            self.tradeid = 0
            self.pricelimit = None
            self.info = {}

        def getordername(self):
            return "Limit"

        def isbuy(self):
            return True

    store = make_store(api=OkxSubmitClient())

    response = store.submit_order(DummyOrder())

    assert store._extract_external_order_id(response) == "okx-order-1"
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    accepted = next(
        event for event in runtime_events if event["event_type"] == "order_submit_accepted"
    )
    assert accepted["order_ref"] == "okx-order-1"
    assert accepted["status"] == "accepted"
    assert not any(event["event_type"] == "order_submit_unconfirmed" for event in runtime_events)


def test_store_submit_order_unconfirmed_response_does_not_emit_accepted_event():
    """Ambiguous submit responses must not be logged as remote accepted orders."""

    class UnconfirmedClient:
        """Client returning a malformed submit response."""

        def __init__(self):
            """Initialize the unconfirmed client."""
            self.connected = False
            self.submitted_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def submit_order(self, payload):
            """Record the order and return an ambiguous failure-like payload."""
            self.submitted_orders.append(dict(payload))
            return False

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.exectype = "limit"
            self.price = 101.0
            self.created = type("Created", (), {"price": 101.0})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()
            self.size = 2
            self.valid = None
            self.tradeid = 0
            self.pricelimit = None
            self.info = {}

        def getordername(self):
            """Return the order name."""
            return "Limit"

        def isbuy(self):
            """Return True for buy orders."""
            return True

    store = make_store(api=UnconfirmedClient())

    response = store.submit_order(DummyOrder())

    assert response is False
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    event_types = [event["event_type"] for event in runtime_events]
    assert "order_submit_accepted" not in event_types
    unconfirmed = next(
        event for event in runtime_events if event["event_type"] == "order_submit_unconfirmed"
    )
    assert unconfirmed["order_ref"] == 7
    assert unconfirmed["status"] == "unconfirmed"
    assert unconfirmed["error_code"] == "invalid_submit_response"


def test_store_stop_limit_order_payload_uses_canonical_type_and_price_fields():
    """Backtrader StopLimit price is trigger; pricelimit is the live limit price."""
    import backtrader as bt

    class DummyOrder:
        """Dummy StopLimit order for payload conversion."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 9
            self.exectype = bt.Order.StopLimit
            self.price = 99.0
            self.created = type("Created", (), {"price": 99.0})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()
            self.size = -3
            self.valid = None
            self.tradeid = 0
            self.pricelimit = 98.5
            self.info = {}

        def getordername(self):
            """Return Backtrader's compact order name."""
            return "StopLimit"

        def isbuy(self):
            """Return False for a sell order."""
            return False

    store = make_store()

    payload = store._order_to_payload(DummyOrder())

    assert payload["order_type"] == "stop_limit"
    assert payload["side"] == "sell"
    assert payload["size"] == 3
    assert payload["price"] == pytest.approx(98.5)
    assert payload["limit_price"] == pytest.approx(98.5)
    assert payload["pricelimit"] == pytest.approx(98.5)
    assert payload["stop_price"] == pytest.approx(99.0)
    assert payload["extra_data"]["aux_price"] == pytest.approx(99.0)


def test_store_cancel_order_uses_external_order_id_and_emits_runtime_events():
    """Test that cancel_order uses external order id and emits runtime events."""

    class CancelOrderClient:
        """Client that tracks cancel_order calls."""

        def __init__(self):
            """Initialize the cancel-order client."""
            self.connected = False
            self.cancelled_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def cancel_order(self, order_ref, dataname=None):
            """Cancel an order and track it."""
            self.cancelled_orders.append({"order_ref": order_ref, "dataname": dataname})
            return True

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.info = type("Info", (), {"external_order_id": "alias-1"})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()

    client = CancelOrderClient()
    store = make_store(api=client)

    response = store.cancel_order(DummyOrder())

    assert response is True
    assert store.is_connected is True
    assert client.cancelled_orders == [{"order_ref": "alias-1", "dataname": DEFAULT_SYMBOL}]
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    assert any(event["event_type"] == "order_cancel_request" for event in runtime_events)
    submitted = next(
        event for event in runtime_events if event["event_type"] == "order_cancel_submitted"
    )
    assert submitted["order_ref"] == "alias-1"
    assert submitted["status"] == "accepted"


def test_store_cancel_order_ref_cancels_remote_snapshot_order():
    """cancel_order_ref should cancel an order that has no local Order object."""

    class CancelOrderClient:
        """Client that tracks cancel_order calls."""

        def __init__(self):
            """Initialize the cancel-order client."""
            self.connected = False
            self.cancelled_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def cancel_order(self, order_ref, dataname=None):
            """Cancel an order and track it."""
            self.cancelled_orders.append({"order_ref": order_ref, "dataname": dataname})
            return {"id": order_ref, "status": "cancel_requested"}

    client = CancelOrderClient()
    store = make_store(api=client)

    response = store.cancel_order_ref("remote-1", dataname=DEFAULT_SYMBOL)

    assert response == {"id": "remote-1", "status": "cancel_requested"}
    assert store.is_connected is True
    assert client.cancelled_orders == [{"order_ref": "remote-1", "dataname": DEFAULT_SYMBOL}]
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    event_types = [event["event_type"] for event in runtime_events]
    assert "order_cancel_request" in event_types
    assert "order_cancel_submitted" in event_types
    assert event_types.index("order_cancel_request") < event_types.index("order_cancel_submitted")
    submitted = next(
        event for event in runtime_events if event["event_type"] == "order_cancel_submitted"
    )
    assert submitted["order_ref"] == "remote-1"
    assert submitted["details"] == {"order_ref": "remote-1", "data_name": DEFAULT_SYMBOL}


@pytest.mark.parametrize(
    ("response", "message"),
    [
        (False, "invalid remote cancel response"),
        ({}, "empty remote cancel response"),
        ({"status": "error", "error": "already filled"}, "already filled"),
        ({"success": False, "message": "cancel denied"}, "cancel denied"),
        ({"comment": "queued"}, "invalid remote cancel response"),
    ],
)
def test_store_cancel_order_ref_rejects_unconfirmed_or_error_payload(response, message):
    """Remote cancel error payloads must not be logged as submitted."""

    class RejectingCancelClient:
        """Client returning a failed or ambiguous cancel response."""

        def __init__(self):
            """Initialize the rejecting cancel client."""
            self.connected = False
            self.cancelled_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def cancel_order(self, order_ref, dataname=None):
            """Record the cancel call and return the configured response."""
            self.cancelled_orders.append({"order_ref": order_ref, "dataname": dataname})
            return dict(response) if isinstance(response, dict) else response

    client = RejectingCancelClient()
    store = make_store(api=client)

    with pytest.raises(BtApiStoreError, match=message):
        store.cancel_order_ref("remote-1", dataname=DEFAULT_SYMBOL)

    assert client.cancelled_orders == [{"order_ref": "remote-1", "dataname": DEFAULT_SYMBOL}]
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    event_types = [event["event_type"] for event in runtime_events]
    assert "order_cancel_request" in event_types
    assert "order_cancel_submitted" not in event_types
    rejected = next(
        event for event in runtime_events if event["event_type"] == "order_cancel_reject_remote"
    )
    assert rejected["order_ref"] == "remote-1"
    assert rejected["status"] == "rejected"
    assert rejected["error_msg"] == message


def test_store_cancel_order_falls_back_to_ctp_order_ref_when_external_id_is_missing():
    """Test that cancel_order falls back to CTP order ref when external ID is missing."""

    class CancelOrderClient:
        """Client that tracks cancel_order calls."""

        def __init__(self):
            """Initialize the cancel-order client."""
            self.connected = False
            self.cancelled_orders = []

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def cancel_order(self, order_ref, dataname=None):
            """Cancel an order and track it."""
            self.cancelled_orders.append({"order_ref": order_ref, "dataname": dataname})
            return True

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.info = type("Info", (), {"ctp_order_ref": "ctp-ref-1"})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()

    client = CancelOrderClient()
    store = make_store(api=client)

    response = store.cancel_order(DummyOrder())

    assert response is True
    assert client.cancelled_orders == [{"order_ref": "ctp-ref-1", "dataname": DEFAULT_SYMBOL}]
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    submitted = next(
        event for event in runtime_events if event["event_type"] == "order_cancel_submitted"
    )
    assert submitted["order_ref"] == "ctp-ref-1"


def test_store_cancel_order_raises_clear_error_and_emits_reject_event_when_unsupported():
    """Test that cancel_order raises clear error when unsupported."""

    class NoCancelClient:
        """Client with no cancel_order capability."""

        def __init__(self):
            """Initialize the no-cancel client."""
            self.connected = False

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

    class DummyOrder:
        """Dummy order for testing."""

        def __init__(self):
            """Initialize the dummy order."""
            self.ref = 7
            self.info = type("Info", (), {"external_order_id": "alias-1"})()
            self.data = type("Data", (), {"_name": DEFAULT_SYMBOL})()

    store = make_store(api=NoCancelClient())

    with pytest.raises(BtApiStoreError, match="does not support order cancellation"):
        store.cancel_order(DummyOrder())

    assert store.is_connected is True
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    assert any(event["event_type"] == "order_cancel_request" for event in runtime_events)
    rejected = next(
        event for event in runtime_events if event["event_type"] == "order_cancel_reject_remote"
    )
    assert rejected["order_ref"] == "alias-1"
    assert rejected["status"] == "rejected"


def test_store_account_and_positions_queries_honor_ttl_cache():
    """Test that account and position queries honor TTL cache."""

    class CountingClient(FakeBtApiClient):
        """Client that tracks balance and position call counts."""

        def __init__(self):
            """Initialize the counting client."""
            super().__init__(
                balance={"cash": 1000.0, "value": 1200.0},
                positions=[{"instrument": DEFAULT_SYMBOL, "volume": 2, "price": 99.5}],
            )
            self.balance_calls = 0
            self.position_calls = 0

        def get_balance(self):
            """Get balance and increment counter."""
            self.balance_calls += 1
            return super().get_balance()

        def get_positions(self):
            """Get positions and increment counter."""
            self.position_calls += 1
            return super().get_positions()

    client = CountingClient()
    store = make_store(api=client, account_cache_ttl=60.0, positions_cache_ttl=60.0)
    store.start()

    assert store.get_balance()["cash"] == pytest.approx(1000.0)
    assert store.get_balance()["cash"] == pytest.approx(1000.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(2.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(2.0)
    assert client.balance_calls == 1
    assert client.position_calls == 1


def test_store_query_failures_fall_back_to_last_successful_cache():
    """Test that query failures fall back to last successful cache."""

    class FlakyClient(FakeBtApiClient):
        """Client that can be toggled to fail balance/position queries."""

        def __init__(self):
            """Initialize the flaky client."""
            super().__init__(
                balance={"cash": 800.0, "value": 900.0},
                positions=[{"instrument": DEFAULT_SYMBOL, "volume": 1, "price": 100.0}],
            )
            self.fail = False

        def get_balance(self):
            """Get balance or raise error if fail is True."""
            if self.fail:
                raise RuntimeError("temporary balance failure")
            return super().get_balance()

        def get_positions(self):
            """Get positions or raise error if fail is True."""
            if self.fail:
                raise RuntimeError("temporary positions failure")
            return super().get_positions()

    client = FlakyClient()
    store = make_store(api=client)
    store.start()

    assert store.get_balance()["cash"] == pytest.approx(800.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(1.0)

    client.fail = True

    assert store.get_balance()["cash"] == pytest.approx(800.0)
    assert store.get_balance()["value"] == pytest.approx(900.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(1.0)
    assert store.get_positions()[0]["price"] == pytest.approx(100.0)


def test_store_force_queries_raise_instead_of_returning_stale_cache():
    """Pre-trade force refresh must not hide query failures behind old cache."""

    class FlakyClient(FakeBtApiClient):
        """Client that can be toggled to fail balance/position queries."""

        def __init__(self):
            """Initialize the flaky client."""
            super().__init__(
                balance={"cash": 800.0, "value": 900.0},
                positions=[{"instrument": DEFAULT_SYMBOL, "volume": 1, "price": 100.0}],
            )
            self.fail = False

        def get_balance(self):
            """Get balance or raise error if fail is True."""
            if self.fail:
                raise RuntimeError("temporary balance failure")
            return super().get_balance()

        def get_positions(self):
            """Get positions or raise error if fail is True."""
            if self.fail:
                raise RuntimeError("temporary positions failure")
            return super().get_positions()

    client = FlakyClient()
    store = make_store(api=client, account_cache_ttl=60.0, positions_cache_ttl=60.0)
    store.start()

    assert store.get_balance()["cash"] == pytest.approx(800.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(1.0)

    client.fail = True

    assert store.get_balance()["cash"] == pytest.approx(800.0)
    assert store.get_positions()[0]["volume"] == pytest.approx(1.0)
    with pytest.raises(RuntimeError, match="temporary balance failure"):
        store.get_balance(force=True, raise_errors=True)
    with pytest.raises(RuntimeError, match="temporary positions failure"):
        store.get_positions(force=True, raise_errors=True)


def test_store_balance_derives_cash_from_value_minus_margin_before_balance():
    """Available cash must not fall back to account balance when margin is in use."""

    class MarginAccountClient(FakeBtApiClient):
        """Client returning account value and used margin without available cash."""

        def __init__(self):
            """Initialize the margin account client."""
            super().__init__(
                balance={
                    "balance": "100,000",
                    "equity": "100,250",
                    "margin": {"amount": "1,200"},
                }
            )

    client = MarginAccountClient()
    store = make_store(api=client)
    store.start()

    balance = store.get_balance(force=True)

    assert balance["value"] == pytest.approx(100_250.0)
    assert balance["cash"] == pytest.approx(99_050.0)
    assert store.getcash() == pytest.approx(99_050.0)
    assert store.getvalue() == pytest.approx(100_250.0)


def test_store_balance_queries_fall_back_to_get_account_alias():
    """Test fallback to get_account alias for balance queries."""

    class AccountOnlyClient:
        """Client with only get_account method for account queries."""

        def __init__(self):
            """Initialize the account-only client."""
            self.connected = False

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_account(self):
            """Return mock account data."""
            return {"cash": 1234.0, "value": 1500.0}

    client = AccountOnlyClient()
    store = make_store(api=client)
    store.start()

    assert store.get_balance()["cash"] == pytest.approx(1234.0)
    assert store.get_balance()["value"] == pytest.approx(1500.0)
    assert store.get_cash() == pytest.approx(1234.0)
    assert store.get_value() == pytest.approx(1500.0)
    assert store.getcash() == pytest.approx(1234.0)
    assert store.getvalue() == pytest.approx(1500.0)
    assert store.getvalue(datas=[object()]) == pytest.approx(1500.0)


def test_store_open_order_queries_fall_back_to_get_open_orders_alias():
    """Test fallback to get_open_orders alias for open order queries."""

    class AliasOnlyOpenOrdersClient:
        """Client with only get_open_orders method for open order queries."""

        def __init__(self):
            """Initialize the alias-only open orders client."""
            self.connected = False

        def connect(self):
            """Connect and set connected to True."""
            self.connected = True

        def disconnect(self):
            """Disconnect and set connected to False."""
            self.connected = False

        def get_open_orders(self):
            """Return mock open orders."""
            return [{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]

    client = AliasOnlyOpenOrdersClient()
    store = make_store(api=client)
    store.start()

    assert [item["id"] for item in store.fetch_open_orders()] == ["btapi-1"]
    assert [item["id"] for item in store.get_open_orders()] == ["btapi-1"]
    assert [item["id"] for item in store.getopenorders()] == ["btapi-1"]


def test_store_open_order_queries_honor_ttl_cache():
    """Test that open order queries honor TTL cache."""

    class CountingClient(FakeBtApiClient):
        """Client that tracks open order call counts."""

        def __init__(self):
            """Initialize the counting client."""
            super().__init__(
                open_orders=[{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]
            )
            self.open_order_calls = 0

        def fetch_open_orders(self):
            """Fetch open orders and increment counter."""
            self.open_order_calls += 1
            return super().fetch_open_orders()

    client = CountingClient()
    store = make_store(api=client, open_orders_cache_ttl=60.0)
    store.start()

    assert [item["id"] for item in store.fetch_open_orders()] == ["btapi-1"]
    client.open_orders = [{"id": "btapi-2", "symbol": DEFAULT_SYMBOL, "side": "sell"}]
    assert [item["id"] for item in store.fetch_open_orders()] == ["btapi-1"]
    assert client.open_order_calls == 1


def test_store_open_order_queries_fall_back_to_last_successful_cache_on_failure():
    """Test fallback to last successful cache when open order query fails."""

    class FlakyOpenOrdersClient(FakeBtApiClient):
        """Client that can be toggled to fail open order queries."""

        def __init__(self):
            """Initialize the flaky open orders client."""
            super().__init__(
                open_orders=[{"id": "btapi-1", "symbol": DEFAULT_SYMBOL, "side": "buy"}]
            )
            self.fail = False

        def fetch_open_orders(self):
            """Fetch open orders or raise error if fail is True."""
            if self.fail:
                raise RuntimeError("temporary open order failure")
            return super().fetch_open_orders()

    client = FlakyOpenOrdersClient()
    store = make_store(api=client)
    store.start()

    assert [item["id"] for item in store.fetch_open_orders()] == ["btapi-1"]

    client.fail = True

    assert [item["id"] for item in store.fetch_open_orders()] == ["btapi-1"]


def test_store_open_order_queries_fall_back_to_empty_list_when_unsupported():
    """Test fallback to empty list when open order query is unsupported."""

    class NoOpenOrderClient(FakeBtApiClient):
        """Client that raises AttributeError on fetch_open_orders."""

        def fetch_open_orders(self):
            """Raise AttributeError to simulate unsupported."""
            raise AttributeError("unsupported")

    client = NoOpenOrderClient()
    store = make_store(api=client)
    store.start()

    assert store.fetch_open_orders() == []
    assert store.get_open_orders() == []
    assert store.getopenorders() == []


def test_ctp_gateway_provider_from_env_requires_migration(monkeypatch):
    """An environment-selected CTP gateway route is rejected before setup."""
    monkeypatch.setenv("BT_STORE_PROVIDER", "ctp_gateway")
    monkeypatch.setenv("BT_GATEWAY_COMMAND_ENDPOINT", "ipc://command")
    monkeypatch.setenv("BT_GATEWAY_EVENT_ENDPOINT", "ipc://event")
    monkeypatch.setenv("BT_GATEWAY_MARKET_ENDPOINT", "ipc://market")
    monkeypatch.setenv("BT_GATEWAY_ACCOUNT_ID", "acc-1")
    monkeypatch.setenv("BT_GATEWAY_EXCHANGE_TYPE", "CTP")
    monkeypatch.setenv("BT_GATEWAY_ASSET_TYPE", "FUTURE")
    monkeypatch.setenv("BT_GATEWAY_START_LOCAL_RUNTIME", "0")

    with pytest.raises(LegacyGatewayMigrationRequiredError) as raised:
        BtApiStore(provider="ctp")

    assert raised.value.target == "provider='ctp_gateway'"
    assert raised.value.code == "MIGRATION_REVIEW_REQUIRED"


def test_ctp_gateway_trading_instance_env_requires_migration(monkeypatch):
    """The live-instance identity cannot revive the retired CTP gateway route."""
    monkeypatch.setenv("BT_STORE_PROVIDER", "ctp_gateway")
    monkeypatch.setenv("BT_TRADING_INSTANCE_ID", "instance-42")
    monkeypatch.setenv("BT_GATEWAY_START_LOCAL_RUNTIME", "0")

    with pytest.raises(LegacyGatewayMigrationRequiredError) as raised:
        BtApiStore(provider="ctp")

    assert raised.value.target == "provider='ctp_gateway'"
    assert raised.value.code == "MIGRATION_REVIEW_REQUIRED"


def test_ctp_gateway_strategy_env_conflict_requires_migration(monkeypatch):
    """Conflicting strategy identities do not bypass gateway route retirement."""
    monkeypatch.setenv("BT_STORE_PROVIDER", "ctp_gateway")
    monkeypatch.setenv("BT_GATEWAY_STRATEGY_ID", "env-strategy")
    monkeypatch.setenv("BT_TRADING_INSTANCE_ID", "instance-42")
    monkeypatch.setenv("BT_GATEWAY_START_LOCAL_RUNTIME", "0")

    with pytest.raises(LegacyGatewayMigrationRequiredError) as raised:
        BtApiStore(provider="ctp", strategy_id="explicit-strategy")

    assert raised.value.target == "provider='ctp_gateway'"
    assert raised.value.code == "MIGRATION_REVIEW_REQUIRED"


def test_create_ctp_wrapper_patches_missing_spi_callbacks():
    """Test that create CTP wrapper patches missing SPI callbacks."""
    # Optional live-trading dependency: skip when bt_api_py CTP support is absent
    # (e.g. CI images without the proprietary package) instead of erroring.
    optional_sdk("bt_api_ctp.ctp.client")
    _create_ctp_wrapper_class()

    import bt_api_ctp.ctp.client as ctp_client_module

    assert hasattr(ctp_client_module._MdSpi, "OnRspQryInvestorPositionDetail")
    assert hasattr(ctp_client_module._MdSpi, "OnRspQryNotice")
    assert hasattr(ctp_client_module._TraderSpi, "OnRspQryInvestorPositionDetail")
    assert hasattr(ctp_client_module._TraderSpi, "OnRspQryNotice")


def test_ctp_wrapper_accepts_dict_snapshots_from_trader_client():
    """CTP query callbacks return dict snapshots; wrapper must read them directly."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeTraderClient:
        is_ready = True

        def query_account(self, timeout=5):
            return {"Available": 80000.0, "Balance": 100000.0}

        def query_positions(self, timeout=5):
            return [
                {
                    "InstrumentID": "IF2506",
                    "PosiDirection": "2",
                    "Position": 2,
                    "PositionCost": 7000.0,
                }
            ]

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.trader_client = FakeTraderClient()

    positions = client.get_positions()

    assert client.get_balance() == {"cash": 80000.0, "value": 100000.0}
    assert len(positions) == 1
    assert positions[0]["instrument"] == "IF2506"
    assert positions[0]["direction"] == "long"
    assert positions[0]["volume"] == pytest.approx(2.0)
    assert positions[0]["price"] == pytest.approx(3500.0)


def test_ctp_wrapper_positions_accept_float_string_ctp_codes():
    """CTP position fields may arrive as float-like strings from upstream containers."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeTraderClient:
        is_ready = True

        def query_positions(self, timeout=5):
            return [
                {
                    "InstrumentID": "IF2506",
                    "PosiDirection": "3.0",
                    "Position": "2.0",
                    "PositionCost": "8000.0",
                }
            ]

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.trader_client = FakeTraderClient()

    positions = client.get_positions()

    assert len(positions) == 1
    assert positions[0]["instrument"] == "IF2506"
    assert positions[0]["direction"] == "short"
    assert positions[0]["volume"] == pytest.approx(2.0)
    assert positions[0]["price"] == pytest.approx(4000.0)


def test_ctp_wrapper_positions_use_contract_multiplier_and_exchange_fields():
    """Direct CTP wrapper should expose exchange PnL/margin and undo cost multiplier."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeTraderClient:
        is_ready = True

        def __init__(self):
            self.query_exchange_ids = []

        def query_positions(self, timeout=5):
            return [
                {
                    "InstrumentID": "IF2506",
                    "ExchangeID": "CFFEX",
                    "PosiDirection": "2",
                    "Position": 2,
                    "PositionCost": 2_400_000.0,
                    "OpenCost": 2_400_000.0,
                    "UseMargin": 288_000.0,
                    "PositionProfit": 12_000.0,
                    "CloseProfit": 500.0,
                    "Commission": 18.0,
                    "TodayPosition": 1,
                    "YdPosition": 1,
                    "SettlementPrice": 4010.0,
                }
            ]

        def query_instrument(self, instrument, exchange_id="", timeout=5):
            self.query_exchange_ids.append(("instrument", exchange_id))
            return {
                "InstrumentID": instrument,
                "ExchangeID": exchange_id or "CFFEX",
                "ProductID": "IF",
                "VolumeMultiple": 300,
                "PriceTick": 0.2,
            }

        def query_instrument_margin_rate(self, instrument, exchange_id="", timeout=5):
            self.query_exchange_ids.append(("margin", exchange_id))
            return {
                "InstrumentID": instrument,
                "ExchangeID": exchange_id or "CFFEX",
                "LongMarginRatioByMoney": 0.12,
                "ShortMarginRatioByMoney": 0.13,
            }

        def query_instrument_commission_rate(self, instrument, exchange_id="", timeout=5):
            self.query_exchange_ids.append(("commission", exchange_id))
            return {
                "InstrumentID": instrument,
                "ExchangeID": exchange_id or "CFFEX",
                "OpenRatioByMoney": 0.23,
                "CloseTodayRatioByMoney": 3.45,
            }

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    trader = FakeTraderClient()
    client.trader_client = trader
    client._last_tick_price["IF2506"] = 4020.0

    position = client.get_positions()[0]

    assert trader.query_exchange_ids == [
        ("instrument", "CFFEX"),
        ("margin", "CFFEX"),
        ("commission", "CFFEX"),
    ]
    assert position["price"] == pytest.approx(4000.0)
    assert position["current_price"] == pytest.approx(4020.0)
    assert position["multiplier"] == pytest.approx(300.0)
    assert position["margin_rate"] == pytest.approx(0.12)
    assert position["short_margin_rate"] == pytest.approx(0.13)
    assert position["open_fee_rate"] == pytest.approx(0.000023)
    assert position["close_today_fee_rate"] == pytest.approx(0.000345)
    assert position["margin_value"] == pytest.approx(288_000.0)
    assert position["profit"] == pytest.approx(12_000.0)
    assert position["commission"] == pytest.approx(18.0)


def test_store_contract_metadata_queries_api_symbol_info():
    """Store should cache symbol metadata from the backing API when not preconfigured."""

    class SymbolInfoClient(FakeBtApiClient):
        def get_symbol_info(self, symbol):
            assert symbol == "IF2506"
            return {"symbol": symbol, "multiplier": 300, "price_tick": 0.2}

    store = make_store(api=SymbolInfoClient())
    store.start()

    metadata = store.get_contract_metadata("IF2506")

    assert metadata["multiplier"] == 300
    assert store.contract_metadata["IF2506"]["price_tick"] == 0.2


@pytest.mark.parametrize("configured_symbol", ["CFFEX.IF2506", "IF2506.CFFEX"])
def test_store_contract_metadata_matches_ctp_exchange_aliases(configured_symbol):
    """Store-level metadata must match exchange-prefixed and exchange-suffixed symbols."""

    class FailingSymbolInfoClient(FakeBtApiClient):
        def get_symbol_info(self, symbol):
            raise AssertionError(f"metadata should have been served from cache, got {symbol}")

    store = make_store(
        api=FailingSymbolInfoClient(),
        contract_metadata={
            configured_symbol: {
                "symbol": "IF2506",
                "exchange_id": "CFFEX",
                "multiplier": 300,
                "margin_rate": 0.12,
                "open_fee_rate": 0.000023,
            }
        },
    )
    store.start()

    metadata = store.get_contract_metadata("IF2506")

    assert metadata["multiplier"] == pytest.approx(300.0)
    assert metadata["margin_rate"] == pytest.approx(0.12)
    assert store.contract_metadata["IF2506"]["open_fee_rate"] == pytest.approx(0.000023)


def test_store_contract_metadata_retries_api_with_ctp_symbol_alias():
    """If the exchange-qualified query is empty, retry the plain instrument alias."""

    class AliasSymbolInfoClient(FakeBtApiClient):
        def __init__(self):
            super().__init__()
            self.queries = []

        def get_symbol_info(self, symbol):
            self.queries.append(symbol)
            if symbol == "IF2506":
                return {"symbol": symbol, "multiplier": 300, "price_tick": 0.2}
            return {}

    client = AliasSymbolInfoClient()
    store = make_store(api=client)
    store.start()

    metadata = store.get_contract_metadata("CFFEX.IF2506")

    assert metadata["multiplier"] == pytest.approx(300.0)
    assert client.queries[:2] == ["CFFEX.IF2506", "IF2506"]
    assert store.contract_metadata["IF2506"]["price_tick"] == pytest.approx(0.2)
    assert store.contract_metadata["CFFEX.IF2506"]["price_tick"] == pytest.approx(0.2)


def test_store_contract_metadata_falls_back_to_fetch_symbol_info_alias():
    """Store should accept gateway clients that expose fetch_symbol_info only."""

    class FetchSymbolInfoClient(FakeBtApiClient):
        def fetch_symbol_info(self, symbol):
            assert symbol == "BTC/USDT:USDT"
            return {
                "symbol": symbol,
                "multiplier": 0.001,
                "taker_fee_rate": 0.0005,
            }

    store = make_store(api=FetchSymbolInfoClient())
    store.start()

    metadata = store.get_contract_metadata("BTC/USDT:USDT")

    assert metadata["multiplier"] == pytest.approx(0.001)
    assert store.contract_metadata["BTC/USDT:USDT"]["taker_fee_rate"] == pytest.approx(0.0005)


def test_store_broker_runtime_trade_event_preserves_fee_and_liquidity_fields():
    """Runtime trade notifications must retain real fee and maker/taker metadata."""
    client = FakeBtApiClient(
        broker_updates=[
            {
                "kind": "trade",
                "trade_id": "trade-1",
                "order_ref": "bt-7",
                "external_order_id": "ex-7",
                "data_name": DEFAULT_SYMBOL,
                "side": "buy",
                "offset": "open",
                "price": 100.0,
                "size": 2,
                "filled": 2,
                "remaining": 0,
                "trade_type": "maker",
                "liquidity": "maker",
                "commission_role": "maker",
                "trade_fee": 0.12,
                "trade_commission": 0.12,
                "fee": {"cost": 0.12, "currency": "USDT"},
                "fee_currency": "USDT",
                "commission_asset": "USDT",
                "details": {"raw_trade_id": "raw-1"},
            }
        ]
    )
    store = make_store(api=client)
    store.start()
    store.get_notifications()

    update = store.poll_broker_update()

    assert update["trade_fee"] == pytest.approx(0.12)
    runtime_events = [kwargs["event"] for _msg, _args, kwargs in store.get_notifications()]
    trade_event = next(
        event for event in runtime_events if event["event_type"] == "trade_execution"
    )
    assert trade_event["order_ref"] == "ex-7"
    assert trade_event["details"]["trade_fee"] == pytest.approx(0.12)
    assert trade_event["details"]["trade_commission"] == pytest.approx(0.12)
    assert trade_event["details"]["fee_currency"] == "USDT"
    assert trade_event["details"]["commission_asset"] == "USDT"
    assert trade_event["details"]["trade_type"] == "maker"
    assert trade_event["details"]["liquidity"] == "maker"
    assert trade_event["details"]["commission_role"] == "maker"
    assert trade_event["details"]["filled"] == 2
    assert trade_event["details"]["remaining"] == 0
    assert trade_event["details"]["external_order_id"] == "ex-7"
    assert trade_event["details"]["raw_trade_id"] == "raw-1"


def test_ctp_wrapper_polls_order_insert_error_events_with_order_ref():
    """CTP order-insert errors must retain OrderRef for broker reconciliation."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeTraderClient:
        is_ready = True

        def __init__(self):
            self._events = [
                {
                    "event": "order_insert_error",
                    "error_id": 31,
                    "error_msg": "资金不足",
                    "field": {
                        "OrderRef": "bt-7",
                        "InstrumentID": "rb2610",
                        "ExchangeID": "SHFE",
                    },
                }
            ]

        def wait_error_event(self, timeout=0):
            return self._events.pop(0) if self._events else None

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.trader_client = FakeTraderClient()

    update = client.poll_broker_update()

    assert update["kind"] == "error"
    assert update["order_ref"] == "bt-7"
    assert update["data_name"] == "rb2610"
    assert update["error_code"] == 31
    assert update["error_msg"] == "资金不足"
    assert update["details"]["ErrorID"] == 31
    assert update["details"]["ErrorMsg"] == "资金不足"


def test_ctp_wrapper_order_submit_reject_status_overrides_unknown_order_status():
    """CTP submit rejection callbacks must not leave broker orders accepted forever."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeTraderClient:
        is_ready = True
        _front_id = 11
        _session_id = 22

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.trader_client = FakeTraderClient()
    client._pending_orders["bt-80"] = {
        "order_ref": "bt-80",
        "data_name": "IF2506",
        "instrument": "IF2506",
        "exchange_id": "CFFEX",
        "side": "buy",
        "offset": "open",
        "price": 4010.0,
        "size": 1,
        "front_id": 11,
        "session_id": 22,
    }
    payload = type(
        "OrderPayload",
        (),
        {
            "OrderRef": "bt-80",
            "OrderSysID": "",
            "InstrumentID": "IF2506",
            "ExchangeID": "CFFEX",
            "FrontID": 11,
            "SessionID": 22,
            "OrderStatus": "a",
            "OrderSubmitStatus": "4",
            "StatusMsg": "CTP insert rejected",
            "Direction": "0",
            "CombOffsetFlag": "0",
            "LimitPrice": 4010.0,
            "VolumeTotalOriginal": 1,
            "VolumeTraded": 0,
            "VolumeTotal": 1,
            "UpdateTime": "09:30:00",
            "InsertTime": "09:30:00",
        },
    )()

    client._handle_order(payload)
    update = client.poll_broker_update()

    assert update["kind"] == "order"
    assert update["order_ref"] == "bt-80"
    assert update["status"] == "rejected"
    assert update["submit_status"] == "4"
    assert update["status_msg"] == "CTP insert rejected"


def test_ctp_wrapper_trade_callback_accepts_float_string_ctp_codes():
    """CTP trade callbacks may expose direction, offset and volume as float-like strings."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client._pending_orders["bt-82"] = {
        "order_ref": "bt-82",
        "data_name": "IF2506",
        "instrument": "IF2506",
        "exchange_id": "CFFEX",
        "side": "sell",
        "offset": "close_today",
        "price": 4010.0,
        "size": 1,
    }
    payload = type(
        "TradePayload",
        (),
        {
            "OrderRef": "bt-82",
            "OrderSysID": "SYS005",
            "TradeID": "T001",
            "InstrumentID": "IF2506",
            "ExchangeID": "CFFEX",
            "Direction": "1.0",
            "OffsetFlag": "3.0",
            "Price": "4010.0",
            "Volume": "1.0",
            "TradeTime": "09:31:00",
        },
    )()

    client._handle_trade(payload)
    update = client.poll_broker_update()

    assert update["kind"] == "trade"
    assert update["trade_id"] == "T001"
    assert update["external_order_id"] == "SYS005"
    assert update["order_ref"] == "bt-82"
    assert update["side"] == "sell"
    assert update["offset"] == "close_today"
    assert update["size"] == 1
    assert update["price"] == pytest.approx(4010.0)


def test_ctp_wrapper_fetch_open_orders_converts_ctp_rows():
    """Direct CTP wrapper should expose queryable remote open orders."""
    optional_sdk("bt_api_ctp.ctp.client")
    from bt_api_ctp.containers.ctp.ctp_order import CtpOrderData

    wrapper_cls = _create_ctp_wrapper_class()

    class FakeRequest:
        def get_status(self):
            return True

        def get_data(self):
            return [
                CtpOrderData(
                    {
                        "InstrumentID": "IF2506",
                        "ExchangeID": "CFFEX",
                        "OrderRef": "bt-77",
                        "OrderSysID": "SYS001",
                        "Direction": "1",
                        "CombOffsetFlag": "3",
                        "LimitPrice": 4010.0,
                        "VolumeTotalOriginal": 2,
                        "VolumeTraded": 1,
                        "VolumeTotal": 1,
                        "OrderStatus": "1",
                        "FrontID": 11,
                        "SessionID": 22,
                    },
                    "IF2506",
                    "FUTURE",
                    True,
                ),
                CtpOrderData(
                    {
                        "InstrumentID": "IF2506",
                        "ExchangeID": "CFFEX",
                        "OrderRef": "bt-78",
                        "OrderSysID": "SYS002",
                        "Direction": "0",
                        "CombOffsetFlag": "0",
                        "LimitPrice": 4011.0,
                        "VolumeTotalOriginal": 2,
                        "VolumeTraded": 1,
                        "VolumeTotal": 1,
                        "OrderStatus": "2",
                        "FrontID": 11,
                        "SessionID": 22,
                    },
                    "IF2506",
                    "FUTURE",
                    True,
                ),
                CtpOrderData(
                    {
                        "InstrumentID": "IF2506",
                        "ExchangeID": "CFFEX",
                        "OrderRef": "bt-79",
                        "OrderSysID": "SYS003",
                        "Direction": "0",
                        "CombOffsetFlag": "0",
                        "LimitPrice": 4012.0,
                        "VolumeTotalOriginal": 1,
                        "VolumeTraded": 0,
                        "VolumeTotal": 1,
                        "OrderStatus": "4",
                        "FrontID": 11,
                        "SessionID": 22,
                    },
                    "IF2506",
                    "FUTURE",
                    True,
                ),
                CtpOrderData(
                    {
                        "InstrumentID": "IF2506",
                        "ExchangeID": "CFFEX",
                        "OrderRef": "bt-80",
                        "OrderSysID": "",
                        "Direction": "0",
                        "CombOffsetFlag": "0",
                        "LimitPrice": 4013.0,
                        "VolumeTotalOriginal": 1,
                        "VolumeTraded": 0,
                        "VolumeTotal": 1,
                        "OrderStatus": "a",
                        "OrderSubmitStatus": "4",
                        "StatusMsg": "insert rejected",
                        "FrontID": 11,
                        "SessionID": 22,
                    },
                    "IF2506",
                    "FUTURE",
                    True,
                ),
            ]

    class FakeFeed:
        def get_open_orders(self):
            return FakeRequest()

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.feed = FakeFeed()

    orders = client.fetch_open_orders()

    assert orders == [
        {
            "id": "SYS001",
            "order_id": "SYS001",
            "external_order_id": "SYS001",
            "order_ref": "bt-77",
            "symbol": "IF2506",
            "data_name": "IF2506",
            "instrument": "IF2506",
            "exchange_id": "CFFEX",
            "front_id": 11,
            "session_id": 22,
            "side": "sell",
            "offset": "close_today",
            "price": 4010.0,
            "size": 2,
            "filled": 1,
            "remaining": 1,
            "status": "partial",
        }
    ]


def test_ctp_wrapper_fetch_open_orders_accepts_float_string_ctp_codes():
    """CTP open-order rows may expose enum and volume fields as float-like strings."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeRequest:
        def get_status(self):
            return True

        def get_data(self):
            return [
                type(
                    "OrderPayload",
                    (),
                    {
                        "InstrumentID": "IF2506",
                        "ExchangeID": "CFFEX",
                        "OrderRef": "bt-81",
                        "OrderSysID": "SYS004",
                        "Direction": "1.0",
                        "CombOffsetFlag": "3.0",
                        "LimitPrice": "4010.0",
                        "VolumeTotalOriginal": "2.0",
                        "VolumeTraded": "1.0",
                        "VolumeTotal": "1.0",
                        "OrderStatus": "1.0",
                        "FrontID": "11.0",
                        "SessionID": "22.0",
                    },
                )()
            ]

    class FakeFeed:
        def get_open_orders(self):
            return FakeRequest()

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.feed = FakeFeed()

    orders = client.fetch_open_orders()

    assert orders == [
        {
            "id": "SYS004",
            "order_id": "SYS004",
            "external_order_id": "SYS004",
            "order_ref": "bt-81",
            "symbol": "IF2506",
            "data_name": "IF2506",
            "instrument": "IF2506",
            "exchange_id": "CFFEX",
            "front_id": 11,
            "session_id": 22,
            "side": "sell",
            "offset": "close_today",
            "price": 4010.0,
            "size": 2,
            "filled": 1,
            "remaining": 1,
            "status": "partial",
        }
    ]


def test_ctp_wrapper_submit_order_rejects_caller_forged_store_capability():
    """Direct CTP wrapper submit stays closed despite a caller-set object capability."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeApi:
        def __init__(self):
            self.raw_calls = 0

        def ReqOrderInsert(self, field, req_id):
            self.raw_calls += 1
            return 0

    class FakeTraderClient:
        is_ready = True

        def __init__(self):
            self.api = FakeApi()
            self._req_id = 20
            self._front_id = 11
            self._session_id = 22
            self.insert_calls = 0

        def submit_order_insert(self, field, req_id, *, execution_capability):
            self.insert_calls += 1
            return 0

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client._execution_gate_capability = object()
    client.trader_client = FakeTraderClient()

    with pytest.raises(BtApiStoreError, match="direct native order dispatch is disabled"):
        client.submit_order(
            {
                "data_name": "CFFEX.IF2506",
                "side": "buy",
                "size": "2.0",
                "price": 4010.0,
                "order_type": "limit",
                "offset": "open",
                "bt_order_ref": "bt-77",
            }
        )

    assert client.trader_client.insert_calls == 0
    assert client.trader_client.api.raw_calls == 0

def test_ctp_wrapper_submit_order_rejects_raw_only_client_before_api_access():
    """Disabled direct CTP submission rejects without reading typed or raw API properties."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class RawApi:
        def __init__(self):
            self.raw_calls = 0

        def ReqOrderInsert(self, field, req_id):
            self.raw_calls += 1
            return 0

    class RawOnlyTraderClient:
        is_ready = True

        def __init__(self):
            self._req_id = 20
            self._front_id = 11
            self._session_id = 22
            self.api_reads = 0
            self.typed_method_reads = 0
            self.raw_api = RawApi()

        @property
        def submit_order_insert(self):
            self.typed_method_reads += 1
            raise AssertionError("typed method descriptor must not be read without capability")

        @property
        def api(self):
            self.api_reads += 1
            return self.raw_api

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.trader_client = RawOnlyTraderClient()

    with pytest.raises(BtApiStoreError, match="direct native order dispatch is disabled"):
        client.submit_order(
            {
                "data_name": "CFFEX.IF2506",
                "side": "buy",
                "size": "2.0",
                "price": 4010.0,
                "order_type": "limit",
                "offset": "open",
                "bt_order_ref": "bt-77",
            }
        )

    assert client.trader_client.api_reads == 0
    assert client.trader_client.typed_method_reads == 0
    assert client.trader_client.raw_api.raw_calls == 0


@pytest.mark.parametrize(
    "has_capability",
    [False, True],
    ids=["missing-capability", "caller-forged-capability"],
)
def test_ctp_wrapper_cancel_rejects_without_raw_action_access(has_capability):
    """Direct CTP cancel remains disabled before typed or raw client access."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeApi:
        def __init__(self):
            self.raw_calls = 0

        def ReqOrderAction(self, field, req_id):
            self.raw_calls += 1
            raise AssertionError("raw ReqOrderAction must not be reached")

    class FakeTraderClient:
        is_ready = True

        def __init__(self):
            self.api_reads = 0
            self.typed_method_reads = 0
            self.raw_api = FakeApi()

        @property
        def submit_order_action(self):
            self.typed_method_reads += 1
            return lambda *_args, **_kwargs: 0

        @property
        def api(self):
            self.api_reads += 1
            return self.raw_api

    client = wrapper_cls()
    client.trader_client = FakeTraderClient()
    client._execution_gate_capability = object() if has_capability else None

    with pytest.raises(BtApiStoreError, match="direct native order dispatch is disabled"):
        client._send_native_order_action(object(), 17)

    assert client.trader_client.api_reads == 0
    assert client.trader_client.raw_api.raw_calls == 0
    assert client.trader_client.typed_method_reads == 0


@pytest.mark.parametrize("size", [0, 1.5, "bad"])
def test_ctp_wrapper_submit_order_rejects_non_integer_lots(size):
    """CTP direct wrapper must not truncate fractional or invalid lots."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeApi:
        def ReqOrderInsert(self, field, req_id):
            raise AssertionError("ReqOrderInsert should not be called")

    class FakeTraderClient:
        is_ready = True

        def __init__(self):
            self.api = FakeApi()
            self._req_id = 20
            self._front_id = 11
            self._session_id = 22

    client = wrapper_cls(
        md_address="tcp://md",
        td_address="tcp://td",
        broker_id="9999",
        investor_id="demo",
        password="secret",
    )
    client.trader_client = FakeTraderClient()

    with pytest.raises(BtApiStoreError, match="positive integer lot"):
        client.submit_order(
            {
                "data_name": "IF2506.CFFEX",
                "side": "buy",
                "size": size,
                "price": 4010.0,
                "order_type": "limit",
                "offset": "open",
                "bt_order_ref": "bt-77",
            }
        )


def test_legacy_gateway_provider_from_env_fails_with_migration_error(monkeypatch):
    """A retired environment-selected gateway provider fails before Store setup."""
    monkeypatch.setenv("BT_STORE_PROVIDER", "gateway")
    monkeypatch.setenv("BT_GATEWAY_COMMAND_ENDPOINT", "ipc://command")
    monkeypatch.setenv("BT_GATEWAY_EVENT_ENDPOINT", "ipc://event")
    monkeypatch.setenv("BT_GATEWAY_MARKET_ENDPOINT", "ipc://market")
    monkeypatch.setenv("BT_GATEWAY_ACCOUNT_ID", "du123456")
    monkeypatch.setenv("BT_GATEWAY_EXCHANGE_TYPE", "IB_WEB")
    monkeypatch.setenv("BT_GATEWAY_ASSET_TYPE", "STK")
    monkeypatch.setenv("BT_GATEWAY_START_LOCAL_RUNTIME", "0")

    with pytest.raises(LegacyGatewayMigrationRequiredError) as raised:
        BtApiStore(provider="ctp")

    assert raised.value.target == "provider='gateway'"


def test_explicit_legacy_gateway_provider_fails_with_migration_error(monkeypatch):
    """An explicit gateway provider is rejected before applying legacy env config."""
    monkeypatch.setenv("BT_GATEWAY_COMMAND_ENDPOINT", "ipc://command")
    monkeypatch.setenv("BT_GATEWAY_EVENT_ENDPOINT", "ipc://event")
    monkeypatch.setenv("BT_GATEWAY_MARKET_ENDPOINT", "ipc://market")
    monkeypatch.setenv("BT_GATEWAY_ACCOUNT_ID", "du654321")
    monkeypatch.setenv("BT_GATEWAY_EXCHANGE_TYPE", "IB_WEB")
    monkeypatch.setenv("BT_GATEWAY_ASSET_TYPE", "FUT")
    monkeypatch.setenv("BT_GATEWAY_START_LOCAL_RUNTIME", "1")

    with pytest.raises(LegacyGatewayMigrationRequiredError) as raised:
        BtApiStore(provider="ib_web_gateway")

    assert raised.value.target == "provider='ib_web_gateway'"


def test_mt5_gateway_provider_from_env_fails_with_migration_error(monkeypatch):
    """Environment-selected gateway aliases no longer choose a legacy Store route."""
    monkeypatch.setenv("BT_STORE_PROVIDER", "mt5_gateway")
    monkeypatch.setenv("BT_GATEWAY_COMMAND_ENDPOINT", "tcp://127.0.0.1:33000")
    monkeypatch.setenv("BT_GATEWAY_EVENT_ENDPOINT", "tcp://127.0.0.1:33001")
    monkeypatch.setenv("BT_GATEWAY_MARKET_ENDPOINT", "tcp://127.0.0.1:33002")
    monkeypatch.setenv("BT_GATEWAY_ACCOUNT_ID", "mt5-12345678")
    monkeypatch.setenv("BT_GATEWAY_EXCHANGE_TYPE", "MT5")
    monkeypatch.setenv("BT_GATEWAY_ASSET_TYPE", "OTC")
    monkeypatch.setenv("BT_GATEWAY_START_LOCAL_RUNTIME", "0")

    with pytest.raises(LegacyGatewayMigrationRequiredError) as raised:
        BtApiStore(provider="ctp")

    assert raised.value.target == "provider='mt5_gateway'"


def test_direct_store_fetch_bars_proxies(fake_client):
    """Direct Store history should normalize bars from an injected API."""
    client = FakeBtApiClient(
        history={
            DEFAULT_SYMBOL: [
                make_bar(0, 1.1000, 1.1010, 1.0990, 1.1005),
                make_bar(1, 1.1005, 1.1020, 1.1000, 1.1015),
            ]
        },
    )
    store = make_store(api=client)
    store.start()
    bars = store.fetch_history(DEFAULT_SYMBOL, timeframe="M1", limit=200)
    assert len(bars) == 2
    assert bars[0]["close"] == pytest.approx(1.1005)
    store.stop()


def test_split_ctp_symbol_normalizes_czce_with_exchange():
    """Test that split CTP symbol normalizes CZCE with exchange."""
    assert _split_ctp_symbol("CF2609.CZCE") == ("CF609", "CZCE")


@pytest.mark.parametrize(
    ("symbol", "expected"),
    [
        ("CFFEX.IF2609", ("IF2609", "CFFEX")),
        ("IF2609.CFFEX", ("IF2609", "CFFEX")),
        ("SHFE.rb2510", ("rb2510", "SHFE")),
        ("rb2510.SHFE", ("rb2510", "SHFE")),
        ("SHFE_rb2510", ("rb2510", "SHFE")),
        ("rb2510_SHFE", ("rb2510", "SHFE")),
    ],
)
def test_split_ctp_symbol_supports_exchange_and_symbol_orders(symbol, expected):
    """CTP symbols may appear as exchange.instrument or instrument.exchange."""
    assert _split_ctp_symbol(symbol) == expected


def test_split_ctp_symbol_normalizes_known_czce_prefix_without_exchange():
    """Test that split CTP symbol normalizes known CZCE prefix without exchange."""
    assert _split_ctp_symbol("MA2609") == ("MA609", "")


def test_split_ctp_symbol_does_not_change_cffex_style_symbol_without_exchange():
    """Test that split CTP symbol does not change CFFEX style symbol without exchange."""
    assert _split_ctp_symbol("IF2609") == ("IF2609", "")


@pytest.mark.parametrize("provider", ["futu", "oanda", "vc"])
def test_placeholder_provider_raises(provider):
    """Providers not yet implemented in bt_api_py should fail explicitly."""
    store = BtApiStore(provider=provider)

    with pytest.raises(BtApiProviderNotImplementedError):
        store.start()


def test_missing_dependency_raises_without_api(monkeypatch):
    """Starting without bt_api_py installed should raise a clear dependency error."""
    store = BtApiStore(provider="okx")

    def _raise_import_error(_name):
        raise ImportError("bt_api_py not installed")

    monkeypatch.setattr("backtrader.stores.btapistore.importlib.import_module", _raise_import_error)

    with pytest.raises(BtApiMissingDependencyError):
        store.start()


@pytest.mark.parametrize(
    "provider,exchange",
    [("ctp", "CTP"), ("btapi", "CTP___FUTURE")],
)
def test_ctp_forwarding_store_direct_writes_fail_closed_before_api(
    provider, exchange, monkeypatch
):
    """CTP provider or exchange routes may not use the generic forwarding writer."""
    monkeypatch.delenv("BT_STORE_PROVIDER", raising=False)
    calls = []
    fake_api = types.SimpleNamespace(
        submit_order=lambda payload: calls.append(("submit", payload)) or {"ok": True},
        cancel_order=lambda ref, dataname=None: calls.append(("cancel", ref, dataname))
        or {"ok": True, "status": "accepted"},
    )
    store = BtApiStore(
        provider=provider,
        api=fake_api,
        backend="direct",
        config={"exchange": exchange},
        api_kwargs={"exchange": exchange},
    )
    # Start from a valid direct Store/API route, then simulate stale runtime
    # mutation so both public entrypoints and injected legacy ports hit guards.
    store.backend = "forwarding"

    with pytest.raises(LegacyGatewayMigrationRequiredError) as submit_error:
        store.submit_order(object())
    assert submit_error.value.target == "backend='forwarding'"
    with pytest.raises(BtApiStoreError, match="direct CTP Store order writes are disabled"):
        store._submit_order_legacy(object())
    with pytest.raises(LegacyGatewayMigrationRequiredError) as cancel_error:
        store.cancel_order(object())
    assert cancel_error.value.target == "backend='forwarding'"
    with pytest.raises(LegacyGatewayMigrationRequiredError) as cancel_ref_error:
        store.cancel_order_ref("fake-order", dataname="IF2506")
    assert cancel_ref_error.value.target == "backend='forwarding'"
    with pytest.raises(BtApiStoreError, match="direct CTP Store cancellation is disabled"):
        store._cancel_order_ref_legacy("fake-order", dataname="IF2506")
    assert calls == []


def test_forwarding_ctp_signal_in_lower_precedence_config_fails_closed():
    """Any CTP exchange signal is denied despite conflicting forwarding kwargs."""
    store = object.__new__(BtApiStore)
    store.provider = "btapi"
    store.backend = "forwarding"
    store._sdk_mode = False
    store._config = {"exchange": "CTP___SHFE"}
    store._api_kwargs = {"exchange_type": "BINANCE"}
    store._managed_execution_adapter = None
    calls = []
    fake_api = types.SimpleNamespace(
        submit_order=lambda payload: calls.append(("submit", payload)) or {"ok": True},
        cancel_order=lambda ref, dataname=None: calls.append(("cancel", ref, dataname))
        or {"ok": True, "status": "accepted"},
    )
    store._ensure_api_ready = lambda: fake_api
    store._order_to_payload = lambda order: {"symbol": "IF2506", "side": "buy"}
    store._extract_external_order_id = lambda response: None
    store._submit_response_looks_accepted = lambda response: True
    store.emit_runtime_event = lambda *args, **kwargs: None
    store._extract_dataname = lambda data: "IF2506"

    with pytest.raises(LegacyGatewayMigrationRequiredError) as submit_error:
        store.submit_order(object())
    assert submit_error.value.target == "backend='forwarding'"
    with pytest.raises(LegacyGatewayMigrationRequiredError) as cancel_error:
        store.cancel_order_ref("fake-order", dataname="IF2506")
    assert cancel_error.value.target == "backend='forwarding'"
    assert calls == []


def test_forwarding_ctp_signal_fails_closed_through_adapter_legacy_ports():
    """An adapter cannot dispatch a conflicting CTP forwarding route via legacy ports."""
    class DispatchAdapter:
        def submit_order(self, order, legacy_dispatch):
            return legacy_dispatch(order)

        def cancel_order(self, order_or_ref, dataname, legacy_dispatch):
            return legacy_dispatch(order_or_ref, dataname)

    store = object.__new__(BtApiStore)
    store.provider = "btapi"
    store.backend = "forwarding"
    store._sdk_mode = False
    store._config = {"exchange": "CTP"}
    store._api_kwargs = {"exchange_type": "BINANCE"}
    store._managed_execution_adapter = DispatchAdapter()
    calls = []
    fake_api = types.SimpleNamespace(
        submit_order=lambda payload: calls.append(("submit", payload)) or {"ok": True},
        cancel_order=lambda ref, dataname=None: calls.append(("cancel", ref, dataname))
        or {"ok": True, "status": "accepted"},
    )
    store._ensure_api_ready = lambda: fake_api
    store._order_to_payload = lambda order: {"symbol": "IF2506", "side": "buy"}
    store._extract_external_order_id = lambda response: None
    store._submit_response_looks_accepted = lambda response: True
    store.emit_runtime_event = lambda *args, **kwargs: None
    store._extract_dataname = lambda data: "IF2506"

    with pytest.raises(LegacyGatewayMigrationRequiredError) as submit_error:
        store.submit_order(object())
    assert submit_error.value.target == "backend='forwarding'"
    with pytest.raises(LegacyGatewayMigrationRequiredError) as cancel_error:
        store.cancel_order_ref("fake-order", dataname="IF2506")
    assert cancel_error.value.target == "backend='forwarding'"
    assert calls == []


def test_non_ctp_forwarding_backend_rejects_public_order_routes():
    """A valid Store cannot regain the retired backend through public write APIs."""

    class CountingFakeClient(FakeBtApiClient):
        def __init__(self):
            super().__init__()
            self.api_calls = []

        def connect(self):
            self.api_calls.append(("connect",))
            return super().connect()

        def submit_order(self, payload):
            self.api_calls.append(("submit", payload))
            return super().submit_order(payload)

        def cancel_order(self, order_ref, dataname=None):
            self.api_calls.append(("cancel", order_ref, dataname))
            return super().cancel_order(order_ref, dataname=dataname)

    client = CountingFakeClient()
    store = make_store(api=client, provider="binance")
    assert store.backend == "direct"

    # Construct normally first, then emulate a stale or mutated legacy Store.
    store.backend = "forwarding"

    with pytest.raises(LegacyGatewayMigrationRequiredError) as submit_error:
        store.submit_order(object())
    assert submit_error.value.target == "backend='forwarding'"
    assert submit_error.value.code == "MIGRATION_REVIEW_REQUIRED"

    with pytest.raises(LegacyGatewayMigrationRequiredError) as cancel_error:
        store.cancel_order(object())
    assert cancel_error.value.target == "backend='forwarding'"
    assert cancel_error.value.code == "MIGRATION_REVIEW_REQUIRED"

    with pytest.raises(LegacyGatewayMigrationRequiredError) as cancel_ref_error:
        store.cancel_order_ref("fake-order", dataname="BTC-USDT")
    assert cancel_ref_error.value.target == "backend='forwarding'"
    assert cancel_ref_error.value.code == "MIGRATION_REVIEW_REQUIRED"

    assert client.api_calls == []
    assert client.connected is False
    assert client.submitted_orders == []
    assert client.cancelled_orders == []


@pytest.fixture
def query_result_type():
    return optional_sdk("bt_api_ctp.query").QueryResult


def _registered_sim_snapshot_store(
    query_result_type,
    *,
    session_states=None,
    catalog_complete=True,
    quote_complete=True,
    omit_depth_method=False,
):
    optional_sdk("bt_api_ctp.ctp.client")
    from backtrader.stores.btapistore import _create_ctp_wrapper_class
    from backtrader.stores.registered_sim import RegisteredSimStore, RegisteredSimWrapper
    from tests.unit.feeds.test_futures_ctp_snapshot import (
        _catalog_row,
        _query_result,
        _quote_row,
        _session,
    )

    catalog = _query_result(
        query_result_type,
        "instruments",
        101,
        (_catalog_row(),),
        complete=catalog_complete,
    )
    quotes = _query_result(
        query_result_type,
        "depth_market_data",
        102,
        (_quote_row(volume=25),),
        complete=quote_complete,
    )

    class FakeTraderClient:
        def __init__(self):
            self.query_calls = []
            self.query_instances = []
            self.write_calls = []
            self.capability_calls = []
            self.session_calls = 0
            self.session_states = list(session_states or (_session(), _session()))

        def get_session_state(self):
            index = min(self.session_calls, len(self.session_states) - 1)
            self.session_calls += 1
            return dict(self.session_states[index])

        def query_instruments_result(self, **kwargs):
            self.query_calls.append(("instruments", dict(kwargs)))
            self.query_instances.append(self)
            return catalog

        def query_depth_market_data_result(self, **kwargs):
            self.query_calls.append(("depth_market_data", dict(kwargs)))
            self.query_instances.append(self)
            return quotes

        def submit_order_insert(self, *args, **kwargs):
            self.write_calls.append((args, kwargs))
            raise AssertionError("snapshot collector attempted an order write")

        def acquire_execution_capability(self, *args, **kwargs):
            self.capability_calls.append((args, kwargs))
            raise AssertionError("snapshot collector attempted a capability call")

    wrapper_cls = type(
        "TestRegisteredSimSnapshotWrapper",
        (RegisteredSimWrapper, _create_ctp_wrapper_class()),
        {"__module__": __name__},
    )
    api = wrapper_cls(registered_sim_allow_writes=False)
    trader = FakeTraderClient()
    if omit_depth_method:
        trader.query_depth_market_data_result = None
    api.trader_client = trader
    api._connected = True
    store = RegisteredSimStore(api=api, autostart=False)
    # Model an already-connected Store without calling connect or making an SDK client.
    store._connected = True
    store._ensure_api_ready = lambda: pytest.fail("snapshot collector reinitialized the Store")
    return store, api, trader


def test_registered_sim_snapshot_uses_existing_session_and_records_source_provenance(
    query_result_type, monkeypatch
):
    from backtrader.feeds import futures_ctp_snapshot as adapter
    from tests.unit.feeds.test_futures_ctp_snapshot import NOW

    monkeypatch.setattr(adapter, "_now_utc", lambda: NOW)
    store, api, trader = _registered_sim_snapshot_store(query_result_type)

    snapshot = store.registered_sim_collect_futures_snapshot(
        max_collection_seconds=30.0,
        max_snapshot_age_seconds=30.0,
    )

    assert store._api is api and store._sdk_owned_api is False
    assert api.trader_client is trader
    assert [kind for kind, _ in trader.query_calls] == ["instruments", "depth_market_data"]
    assert trader.query_instances == [trader, trader]
    assert trader.session_calls == 2
    assert trader.write_calls == trader.capability_calls == []
    assert store.allow_writes is False
    assert snapshot.catalog_records[0].instrument_id == "M2611"
    catalog_kwargs = trader.query_calls[0][1]
    quote_kwargs = trader.query_calls[1][1]
    assert set(catalog_kwargs) == {
        "instrument_id",
        "exchange_id",
        "product_id",
        "timeout",
        "max_duration",
        "deadline_monotonic",
    }
    assert set(quote_kwargs) == {
        "instrument_id",
        "exchange_id",
        "timeout",
        "deadline_monotonic",
    }
    assert all(catalog_kwargs[key] == "" for key in ("instrument_id", "exchange_id", "product_id"))
    assert quote_kwargs["instrument_id"] == quote_kwargs["exchange_id"] == ""
    assert 0 < catalog_kwargs["timeout"] <= 30.0
    assert 0 < catalog_kwargs["max_duration"] <= 30.0
    assert 0 < quote_kwargs["timeout"] <= 30.0
    assert type(catalog_kwargs["deadline_monotonic"]) is float
    assert quote_kwargs["deadline_monotonic"] == catalog_kwargs["deadline_monotonic"]
    assert snapshot.catalog_source.source_id == (
        "backtrader.stores.btapistore.CtpClientWrapper."
        "bt_api_ctp.TraderClient.query_instruments_result"
    )
    assert snapshot.quote_source.source_id == (
        "backtrader.stores.btapistore.CtpClientWrapper."
        "bt_api_ctp.TraderClient.query_depth_market_data_result"
    )
    assert len(snapshot.catalog_source.source_sha256) == 64
    assert len(snapshot.quote_source.source_sha256) == 64

    # Direct legacy wrapper calls omit the new optional SDK argument.
    api.query_instruments_result(
        instrument_id="", exchange_id="", product_id="", timeout=1.0, max_duration=1.0
    )
    api.query_depth_market_data_result(instrument_id="", exchange_id="", timeout=1.0)
    assert "deadline_monotonic" not in trader.query_calls[-2][1]
    assert "deadline_monotonic" not in trader.query_calls[-1][1]


@pytest.mark.parametrize(
    "second_state",
    (
        {
            "connected": True,
            "read_only_ready": True,
            "connection_generation": 8,
            "trading_day": "20261023",
        },
        {
            "connected": True,
            "read_only_ready": True,
            "connection_generation": 7,
            "trading_day": "20261026",
        },
    ),
)
def test_registered_sim_snapshot_rejects_session_generation_or_day_drift(
    query_result_type, second_state
):
    from backtrader.feeds.futures_ctp_snapshot import CtpFuturesSnapshotError
    from tests.unit.feeds.test_futures_ctp_snapshot import _session

    store, _, trader = _registered_sim_snapshot_store(
        query_result_type, session_states=(_session(), second_state)
    )
    with pytest.raises(CtpFuturesSnapshotError) as caught:
        store.registered_sim_collect_futures_snapshot()

    assert caught.value.code == "SESSION_CHANGED_DURING_COLLECTION"
    assert [kind for kind, _ in trader.query_calls] == ["instruments", "depth_market_data"]


@pytest.mark.parametrize(
    ("catalog_complete", "quote_complete", "expected_calls"),
    ((False, True, ["instruments"]), (True, False, ["instruments", "depth_market_data"])),
)
def test_registered_sim_snapshot_rejects_incomplete_query_without_fallback(
    query_result_type, catalog_complete, quote_complete, expected_calls
):
    from backtrader.feeds.futures_ctp_snapshot import CtpFuturesSnapshotError

    store, _, trader = _registered_sim_snapshot_store(
        query_result_type,
        catalog_complete=catalog_complete,
        quote_complete=quote_complete,
    )
    with pytest.raises(CtpFuturesSnapshotError):
        store.registered_sim_collect_futures_snapshot()

    assert [kind for kind, _ in trader.query_calls] == expected_calls
    assert trader.write_calls == trader.capability_calls == []


def test_registered_sim_snapshot_missing_depth_capability_fails_closed(query_result_type):
    from backtrader.feeds.futures_ctp_snapshot import CtpFuturesSnapshotError

    store, _, trader = _registered_sim_snapshot_store(query_result_type, omit_depth_method=True)
    with pytest.raises(CtpFuturesSnapshotError) as caught:
        store.registered_sim_collect_futures_snapshot()

    assert caught.value.code == "QUOTE_QUERY_CALL_FAILED"
    assert [kind for kind, _ in trader.query_calls] == ["instruments"]
    assert trader.write_calls == trader.capability_calls == []


def test_registered_sim_snapshot_requires_an_already_connected_store(query_result_type):
    from backtrader.stores.btapistore import BtApiStoreError

    store, api, trader = _registered_sim_snapshot_store(query_result_type)
    store._connected = False
    with pytest.raises(BtApiStoreError, match="existing connected Store"):
        store.registered_sim_collect_futures_snapshot()

    assert store._api is api
    assert trader.query_calls == [] and trader.session_calls == 0
    assert trader.write_calls == trader.capability_calls == []
