from __future__ import annotations

import base64
import csv
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile
import xml.etree.ElementTree as ET


def fail(code):
    raise RuntimeError(code)


def within(path, parent):
    try:
        Path(path).resolve().relative_to(Path(parent).resolve())
        return True
    except (OSError, ValueError):
        return False


if len(sys.argv) < 10:
    fail("installed_focus_arguments_invalid")
repo, consumer, fixture_root, wheel, out, pytest_ini = (Path(v).resolve() for v in sys.argv[1:7])
distribution_version = sys.argv[7]
must_load_sources = json.loads(sys.argv[8])
node_specs = sys.argv[9:]
if not sys.flags.isolated or Path(sys.prefix).resolve() != consumer:
    fail("consumer_interpreter_isolation_mismatch")
site = (consumer / "Lib" / "site-packages").resolve()
if not site.is_dir() or not fixture_root.is_dir() or not wheel.is_file() or not pytest_ini.is_file():
    fail("installed_focus_input_missing")

import backtrader
import backtrader_runtime

if not within(backtrader.__file__, site / "backtrader"):
    fail("backtrader_initial_origin_not_consumer")
if not within(backtrader_runtime.__file__, site / "backtrader_runtime"):
    fail("backtrader_runtime_initial_origin_not_consumer")
for entry in sys.path:
    if entry and within(entry, repo):
        fail("repository_path_present_before_fixture_import")
sys.path.insert(0, str(fixture_root))

dist = metadata.distribution("back-trader-python")
if dist.version != distribution_version:
    fail("backtrader_distribution_version_mismatch")
record_rel = next((item for item in dist.files or () if str(item).endswith(".dist-info/RECORD")), None)
if record_rel is None:
    fail("backtrader_installed_record_missing")
record_path = Path(dist.locate_file(record_rel)).resolve()
if not within(record_path, site):
    fail("backtrader_record_origin_not_consumer")
record_entries = 0
with record_path.open("r", encoding="utf-8", newline="") as stream:
    for relative, encoded, size in csv.reader(stream):
        installed = Path(dist.locate_file(relative)).resolve()
        is_console_script = (
            relative == "../../Scripts/bt-runtime.exe"
            and installed == (consumer / "Scripts/bt-runtime.exe").resolve()
            and within(installed, consumer)
            and any(ep.group == "console_scripts" and ep.name == "bt-runtime"
                    and ep.value == "backtrader_runtime.cli:main" for ep in dist.entry_points)
        )
        if (not within(installed, site) and not is_console_script) or not installed.is_file():
            fail("backtrader_record_path_invalid")
        if encoded:
            algorithm, expected = encoded.split("=", 1)
            raw = installed.read_bytes()
            actual = base64.urlsafe_b64encode(hashlib.new(algorithm, raw).digest()).rstrip(b"=").decode("ascii")
            if actual != expected or not size or len(raw) != int(size):
                fail("backtrader_record_entry_mismatch")
        elif size and len(installed.read_bytes()) != int(size):
            fail("backtrader_unhashed_record_size_mismatch")
        record_entries += 1

wheel_members = {}
with zipfile.ZipFile(wheel) as bundle:
    for name in bundle.namelist():
        if name.endswith("/") or not name.startswith(("backtrader/", "backtrader_runtime/")):
            continue
        wheel_members[name] = bundle.read(name)
if not wheel_members:
    fail("backtrader_wheel_payload_empty")
for name, expected in wheel_members.items():
    installed = (site / Path(*PurePosixPath(name).parts)).resolve()
    if not within(installed, site) or not installed.is_file() or installed.read_bytes() != expected:
        fail("installed_backtrader_wheel_payload_mismatch")

import pytest

node_arguments = []
for spec in node_specs:
    source_path, separator, selector = spec.partition("::")
    if not separator or not selector:
        fail("pytest_node_selector_invalid")
    test_path = (fixture_root / Path(*PurePosixPath(source_path).parts)).resolve()
    if not within(test_path, fixture_root) or not test_path.is_file():
        fail("pytest_node_file_missing")
    node_arguments.append(str(test_path) + "::" + selector)

basetemp = out / "pytest-basetemp"
junit_path = out / "junit.xml"
if basetemp.exists() or junit_path.exists():
    fail("pytest_output_namespace_invalid")
pytest_code = int(pytest.main([
    "-c", str(pytest_ini), "--import-mode=importlib", "--basetemp", str(basetemp),
    "--junitxml", str(junit_path), *node_arguments,
]))
if not junit_path.is_file():
    fail("pytest_junit_result_missing")
root = ET.parse(junit_path).getroot()
cases = root.findall(".//testcase")
failures = len(root.findall(".//failure")) + len(root.findall(".//error"))
skips = len(root.findall(".//skipped"))
if pytest_code != 0 or len(cases) != len(node_specs) or failures or skips:
    fail("selected_installed_nodes_not_all_passed")

package_origins = {}
fixture_origins = {}
loaded_required = set()
for name, module in tuple(sys.modules.items()):
    origin = getattr(module, "__file__", None)
    if origin is None:
        continue
    resolved = Path(origin).resolve()
    if name == "backtrader" or name.startswith("backtrader.") or name == "backtrader_runtime" or name.startswith("backtrader_runtime."):
        if not within(resolved, site):
            fail("loaded_backtrader_module_origin_mismatch")
        package_origins[name] = str(resolved)
    if within(resolved, repo):
        fail("repository_source_module_loaded")
    if within(resolved, fixture_root):
        fixture_origins[name] = str(resolved)
        for rel in must_load_sources:
            if resolved == (fixture_root / Path(*PurePosixPath(rel).parts)).resolve():
                loaded_required.add(rel)
for rel in must_load_sources:
    if rel not in loaded_required:
        fail("required_public_source_not_loaded_from_fixture_snapshot")
for entry in sys.path:
    if entry and within(entry, repo) and not within(entry, fixture_root):
        fail("repository_path_present_after_fixture_import")

result = {
    "status": "PASS_SELECTED_INSTALLED_SYNTHETIC_NODES_ONLY",
    "consumer": str(consumer),
    "backtrader_distribution_version": dist.version,
    "record_entry_count": record_entries,
    "wheel_payload_file_count": len(wheel_members),
    "pytest_node_count": len(cases),
    "pytest_failures": failures,
    "pytest_skips": skips,
    "node_ids": node_specs,
    "package_origins": package_origins,
    "fixture_origins": fixture_origins,
    "must_load_sources": must_load_sources,
    "required_sources_loaded": sorted(loaded_required),
    "provider_or_account_claim": "NONE",
}
(out / "installed-focus.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
