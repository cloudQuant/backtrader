"""Draft public-profile preflight; do not run until Root supplies final consumer pins."""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys

PROFILE = "set1_group1_vpn"
CONFIG_SHA = "6e7d8594783528f6c6fca79a63e53cead0d006a3b0ea8c3258ee96d53b9c54bd"
MARKET_SHA = "34293bb33b2d88f37b32600889c741885b0b2f3de23e68fc1b55f092b842cf63"
MARKET = Path("D:/temp/i51-root-current-market-selection-20261027-r1.json")
SECRET_KEYS = {"password", "passwd", "username", "userid", "user_id", "brokerid", "broker_id", "authcode", "auth_code", "appid", "app_id", "token", "secret"}


class CheckFailure(Exception):
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)
def need(ok: bool, code: str) -> None:
    if not ok:
        raise CheckFailure(code)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False

def no_secret_keys(value) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            normalized = str(key).lower().replace("-", "_")
            need(normalized not in SECRET_KEYS, "CREDENTIAL_KEY_FORBIDDEN")
            no_secret_keys(child)
    elif isinstance(value, list):
        for child in value:
            no_secret_keys(child)

def expect_runner_error(runner, call, code: str) -> None:
    try:
        call()
    except runner.RunnerError as error:
        need(error.code == code, "UNEXPECTED_RUNNER_REJECTION")
        return
    raise CheckFailure("EXPECTED_RUNNER_REJECTION_MISSING")

def expect_profile_error(runner, config, kwargs, reason: str) -> None:
    try:
        runner.validate_official_simnow_store_profile(config, kwargs)
    except runner.SimNowProfileValidationError as error:
        need(error.reason == reason, "UNEXPECTED_PROFILE_REJECTION")
        return
    raise CheckFailure("EXPECTED_PROFILE_REJECTION_MISSING")

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--consumer-root", type=Path, required=True)
    for name in ("--expected-runner-sha256", "--expected-selector-sha256",
                 "--store-config-json", "--api-kwargs-json"):
        parser.add_argument(name, required=True)
    parser.add_argument("--golden-target", action="append", required=True)
    args = parser.parse_args()
    try:
        repo = Path(__file__).resolve().parent.parent
        runner_path = repo / "examples/unified/028_alpha003_simnow_minute/run.py"
        config_path = repo / ".codex-tmp/i5051_r0_full_profile_20261027.json"
        need(digest(config_path) == CONFIG_SHA, "PUBLIC_CONFIG_PIN_MISMATCH")
        need(digest(MARKET) == MARKET_SHA, "MARKET_EVIDENCE_PIN_MISMATCH")
        runner_sha = digest(runner_path)
        need(runner_sha == args.expected_runner_sha256.lower(), "RUNNER_PIN_MISMATCH")

        sys.path.insert(0, str(runner_path.parent.resolve()))
        import backtrader
        bt_path = Path(inspect.getfile(backtrader)).resolve()
        need(inside(bt_path, args.consumer_root), "BACKTRADER_SOURCE_SHADOWED")
        selector = importlib.import_module("bt_api_ctp.ctp_env_selector")
        selector_path = Path(inspect.getfile(selector)).resolve()
        need(inside(selector_path, args.consumer_root), "CTP_SELECTOR_SOURCE_SHADOWED")
        selector_sha = digest(selector_path)
        need(selector_sha == args.expected_selector_sha256.lower(), "CTP_SELECTOR_PIN_MISMATCH")

        spec = importlib.util.spec_from_file_location("i5051_profile_runner", runner_path)
        need(spec is not None and spec.loader is not None, "RUNNER_LOAD_UNAVAILABLE")
        runner = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = runner
        spec.loader.exec_module(runner)
        config = runner.load_config(config_path)
        mode, decision = runner.resolve_mode(config, None)
        need(mode == "live", "PROFILE_MODE_MISMATCH")
        factor_mode, _direction, preheat, cadence = runner._factor_parameters(config, None)
        need(factor_mode == "native", "PROFILE_FACTOR_MODE_MISMATCH")
        need(config["selection"]["source"] == "ctp_query", "PROFILE_SELECTION_SOURCE_MISMATCH")
        need(not config["selection"]["daily_bundles"], "PROFILE_DAILY_FALLBACK_PRESENT")
        need(config["live"]["allow_writes"] is False, "PROFILE_WRITE_CONFIG_ENABLED")
        need(config["live"]["arm_templates"] == [], "PROFILE_ARM_TEMPLATES_PRESENT")
        need(runner._write_requested(config, False, decision) is False, "PROFILE_WRITES_ENABLED")
        expect_runner_error(runner, lambda: runner._write_requested(config, True, decision),
                            "LIVE_WRITE_GRANT_MISSING_IN_CONFIG")
        need(runner._risk_policy(config) is None, "PROFILE_RISK_POLICY_PRESENT")
        need(runner._validate_golden_targets_option(
            config, mode=mode, decision=decision, allow_write_flag=False
        ) is None, "GOLDEN_DEFAULT_NOT_NULL")

        overlay = {"config": json.loads(args.store_config_json), "api_kwargs": json.loads(args.api_kwargs_json)}
        no_secret_keys(overlay)
        store_config, api_kwargs = runner._validated_live_store_config(overlay)
        official_pair = selector.official_simnow_fronts(PROFILE)
        effective = dict(store_config)
        effective.update(api_kwargs)
        actual_pair = (runner._resolve_ctp_front(effective, "td_address", "td_front"),
                       runner._resolve_ctp_front(effective, "md_address", "md_front"))
        need(actual_pair == official_pair, "OFFICIAL_ROUTE_PAIR_MISMATCH")
        admitted = runner.validate_official_simnow_store_profile(store_config, api_kwargs)
        need(admitted == {"verified": True, "environment": "simnow", "profile": PROFILE}, "OFFICIAL_SIMNOW_PROFILE_MISMATCH")

        wrong_config, wrong_kwargs = copy.deepcopy(store_config), copy.deepcopy(api_kwargs)
        for name in ("ctp_env_profile", "environment_profile"):
            wrong_config[name] = wrong_kwargs[name] = "set2_7x24"
        expect_profile_error(runner, wrong_config, wrong_kwargs, "CTP_PROFILE_FRONT_MISMATCH")
        prod_config, prod_kwargs = copy.deepcopy(store_config), copy.deepcopy(api_kwargs)
        prod_kwargs.update({"environment": "production", "ctp_environment": "production"})
        expect_profile_error(runner, prod_config, prod_kwargs, "CTP_ENVIRONMENT_NOT_SIMNOW")

        evidence = json.loads(MARKET.read_text(encoding="utf-8"))
        evidence = runner._validate_selection_evidence(evidence)
        projection = json.loads(runner._query_history_selection_projection(evidence))
        manifest = evidence["manifest"]
        products = manifest["target_products"]
        query_coverage = manifest["query_coverage"]
        targets = {f'{p["exchange_id"]}.{p["product_id"]}' for p in products}
        query_coverage_products = {
            f'{row["product"]["exchange_id"]}.{row["product"]["product_id"]}'
            for row in query_coverage
        }
        need(evidence["selection_source"] == "ctp_query_snapshot_equal_weight_v1" and
             len(products) == len(manifest["products"]) == len(manifest["query_coverage"]) == 87 and
             len(evidence["routes"]) == len(evidence["authorized_targets"]) == 87 and
             set(evidence["routes"]) == set(evidence["authorized_targets"]) == targets and
             len(query_coverage_products) == 87 and query_coverage_products == targets,
             "FULL_SELECTION_MAPPING_INCOMPLETE")
        exchanges = {p["exchange_id"] for p in products}
        calendars = manifest["calendars"]
        need(len(calendars) == 6 and {c["exchange_id"] for c in calendars} == exchanges and
             all(c["complete"] is True for c in calendars), "FULL_CALENDAR_EVIDENCE_INCOMPLETE")
        need(all(
            row["metric_unit"] == "contracts"
            and all(
                type(row[field]) is list
                and bool(row[field])
                and all(type(value) is str and value for value in row[field])
                for field in (
                    "catalog_instrument_ids",
                    "expected_quote_instrument_ids",
                    "observed_quote_instrument_ids",
                )
            )
            and set(row["expected_quote_instrument_ids"]).issubset(
                row["observed_quote_instrument_ids"]
            )
            and set(row["observed_quote_instrument_ids"]).issubset(
                row["catalog_instrument_ids"]
            )
            for row in query_coverage), "FULL_QUERY_COVERAGE_INCOMPLETE")
        policy = projection["manifest"]["policy"]
        need(policy["ranking_mode"] == "ctp_query_snapshot_equal_weight_v1" and
             policy["score_formula"] == "0.5 * open_interest + 0.5 * volume" and
             policy["weights"] == {"open_interest": "0.5", "volume": "0.5"} and
             policy["metric_unit"] == "contracts" and policy["max_snapshot_age_seconds"] == 300 and
             policy["max_collection_span_seconds"] == 300, "FULL_SCORE_POLICY_MISMATCH")

        golden = copy.deepcopy(config)
        golden["live"]["golden_targets"] = list(args.golden_target)
        selected = runner._validate_golden_targets_option(
            golden, mode=mode, decision=decision, allow_write_flag=False
        )
        need(selected is not None and len(selected) == 3 and set(selected).issubset(evidence["routes"]), "GOLDEN_TARGETS_NOT_VALIDATED_IN_FULL_POOL")
        result = {"schema": "i5051_r0_public_profile_check.v1", "status": "PASS_PUBLIC_PROFILE_AND_SELECTION_PREFLIGHT",
                  "evidence_level": "SOURCE_PROFILE_AND_SANITIZED_QUERY_EVIDENCE_ONLY",
                  "source_pins": {"runner": runner_sha, "config": CONFIG_SHA, "market": MARKET_SHA,
                                  "selector": selector_sha, "installed_backtrader_init": digest(bt_path)},
                  "counts": {"full_targets": len(targets), "routes": len(evidence["routes"]),
                             "calendars": len(calendars), "coverage_rows": len(query_coverage),
                             "golden_targets": len(selected), "preheat_bars": preheat, "rebalance_every": cadence},
                  "checks": {"official_profile": PROFILE, "wrong_profile_rejected": True,
                             "production_environment_rejected": True, "write_escalation_rejected": True,
                             "risk_policy_absent": True, "golden_default_null": True,
                             "golden_subset_in_full_pool": True, "store_construction_attempted": False},
                  "limits": ["No Store/Broker/Cerebro/provider/account operation.",
                             "Accepted composition remains separate; no fresh full-profile composition claimed.",
                             "No live-account acceptance claimed."]}
        print(json.dumps(result, sort_keys=True))
        return 0
    except Exception as error:
        reason = getattr(error, "reason", None) or getattr(error, "code", None)
        if not isinstance(reason, str) or not reason or len(reason) > 80:
            reason = type(error).__name__
        print(json.dumps({"status": "HOLD", "reason": reason}, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
