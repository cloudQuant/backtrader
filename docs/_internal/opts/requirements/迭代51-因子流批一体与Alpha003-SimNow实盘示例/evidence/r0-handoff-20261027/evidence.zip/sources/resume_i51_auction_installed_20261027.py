"""Resume after the wheel was built; preserve the original CRLF-metadata failure."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import zipfile
from email.parser import BytesParser

REPO = Path('D:/source_code/backtrader')
BUILT = Path('D:/temp/i51-auction-installed-20261027-r2')
OUT = BUILT / 'installed-resume'
CONSUMER = Path('D:/temp/i51-ctp-factor-clean-consumer-20261027-c4c7240a/consumer')
HISTORY = CONSUMER.parent / 'fixture-closure-focus-resume'
HELPER = REPO / '.codex-tmp/prepare_i51_factor_clean_consumer_20261027.py'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '3aa56bb3c2b7d82245690ec2abaec9c242fd44bf4fe2856e0951566f1ad0d68f'
spec = importlib.util.spec_from_file_location('installed_tools', HELPER)
tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tools)
prior = json.loads((BUILT / 'run.json').read_text(encoding='utf-8'))
assert prior['status'] == 'FAILED' and prior['commit'] == 'bc80fb2a878aa963f39e812433909061dafa35ab'
assert [(row['phase'], row['exit_code']) for row in prior['commands']] == [('git-archive', 0), ('backtrader-wheel-build', 0)]
assert not OUT.exists()
wheel = BUILT / 'wheelhouse/back_trader_python-1.4.0-py3-none-any.whl'
tools.verify_file(wheel, 2437256, '7ff2e82449154457aa4f85570a932bcab4a29534d4a02091c9720ee033de9fd8', 'built_wheel_changed')
site = CONSUMER / 'Lib/site-packages'
tools.verify_file(site / 'back_trader_python-1.4.0.dist-info/RECORD', 112674, '720f97df9cd83037341c4bd0644588129ba46eff8ed0ae7d3daacfb48667cb23', 'old_record_changed')
for path, (size, digest) in tools.SDK_RECORD_PINS.items():
    tools.verify_file(site / path, size, digest, 'sdk_record_changed_before_resume')
source_zip = BUILT / 'source.zip'
assert tools.pin(source_zip) == prior['source_archive']
with zipfile.ZipFile(source_zip) as source, zipfile.ZipFile(wheel) as package:
    expected = {name: source.read(name) for name in source.namelist() if name.endswith('.py') and name.startswith(('backtrader/', 'backtrader_runtime/'))}
    actual = {name: package.read(name) for name in package.namelist() if name.endswith('.py') and name.startswith(('backtrader/', 'backtrader_runtime/'))}
    assert expected == actual and len(expected) == 663
    metadata = [name for name in package.namelist() if name.endswith('.dist-info/METADATA')]
    assert len(metadata) == 1
    parsed = BytesParser().parsebytes(package.read(metadata[0]))
    assert parsed.get_all('Version') == ['1.4.0'] and parsed.get_all('Name') == ['back-trader-python']
    ep = [name for name in package.namelist() if name.endswith('.dist-info/entry_points.txt')]
    assert len(ep) == 1 and package.read(ep[0]).decode('utf-8').splitlines() == ['[console_scripts]', 'bt-runtime = backtrader_runtime.cli:main']
tools.validate_source_pins(BUILT / 'source', {key: value for key, value in prior['source_pins'].items() if key.startswith(('backtrader/', 'backtrader_runtime/'))})
fixtures = BUILT / 'fixtures'
for row in prior['fixture_files']:
    tools.verify_file(fixtures / row['path'], row['size_bytes'], row['sha256'], 'fixture_changed')
focus_template = HISTORY / 'installed_focus.py'
assert tools.pin(focus_template)['sha256'] == '1cd7717acb1c45d13d6486c9d58f084ba434f81b9d064ab7af4f907b8a35ac81'
assert tools.pin(HISTORY / 'run.json')['sha256'] == 'b1513abb2058ef2d28e4e3c1eda9b40855492235caf6ee490ecfa7ee9a86a5de'
state = {'schema': 'i51_auction_installed_resume_v1', 'status': 'PREPARING', 'commit': prior['commit'],
         'consumer': str(CONSUMER), 'prior_build_result': tools.pin(BUILT / 'run.json'),
         'wheel': tools.pin(wheel), 'wheel_python_payload_count': len(expected), 'commands': [],
         'node_ids': prior['node_ids'], 'source_pins': prior['source_pins'],
         'benchmark_consumer_touched': False, 'rebuilt_wheel': False, 'repeated_old_eight_nodes': False}
OUT.mkdir()
tools.save(state, OUT)
env = {key: value for key, value in os.environ.items() if key.upper() in tools.WINDOWS_RUNTIME_ENV}
env.update(PYTHONUTF8='1', PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
python = CONSUMER / 'Scripts/python.exe'
try:
    tools.run_command(state, OUT, 'backtrader-install-only', [str(python), '-I', '-m', 'pip', 'install', '--disable-pip-version-check', '--no-index', '--no-cache-dir', '--no-deps', '--force-reinstall', str(wheel)], cwd=OUT, env=env, timeout=300)
    for path, (size, digest) in tools.SDK_RECORD_PINS.items():
        tools.verify_file(site / path, size, digest, 'sdk_record_changed_after_install')
    tools.run_command(state, OUT, 'pip-check', [str(python), '-I', '-m', 'pip', 'check'], cwd=OUT, env=env, timeout=60)
    focus = OUT / 'installed_focus.py'
    shutil.copyfile(focus_template, focus)
    ini = OUT / 'pytest.ini'
    ini.write_text('[pytest]\naddopts =\nmarkers =\n    integration: selected local synthetic integration nodes\n', encoding='utf-8')
    temp = OUT / 'process-temp'
    temp.mkdir()
    test_env = dict(env, TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp))
    command = [str(python), '-I', str(focus), str(REPO), str(CONSUMER), str(fixtures), str(wheel), str(OUT), str(ini), '1.4.0', '[]', *prior['node_ids']]
    tools.run_command(state, OUT, 'three-auction-nodes', command, cwd=OUT, env=test_env, timeout=1200)
    result = json.loads((OUT / 'installed-focus.json').read_text(encoding='utf-8'))
    assert result['status'] == 'PASS_SELECTED_INSTALLED_SYNTHETIC_NODES_ONLY'
    assert result['pytest_node_count'] == 3 and result['node_ids'] == prior['node_ids']
    state['installed_focus'] = result
    for row in prior['fixture_files']:
        tools.verify_file(fixtures / row['path'], row['size_bytes'], row['sha256'], 'fixture_changed_after_tests')
    state['installed_backtrader_record'] = tools.pin(site / 'back_trader_python-1.4.0.dist-info/RECORD')
    state['sdk_records_after'] = {path: tools.verify_file(site / path, size, digest, 'sdk_record_changed_after_tests') for path, (size, digest) in tools.SDK_RECORD_PINS.items()}
    assert tools.pin(BUILT / 'run.json') == state['prior_build_result']
    assert tools.pin(wheel) == state['wheel']
    state['status'] = 'PASS_THREE_INSTALLED_SYNTHETIC_AUCTION_NODES_ONLY'
    tools.save(state, OUT)
except BaseException as error:
    state.update(status='FAILED', failure_type=type(error).__name__)
    tools.save(state, OUT)
    raise
