"""Build one committed auction-fix wheel and run only its three installed nodes."""
from __future__ import annotations

import ast, hashlib, importlib.util, json, os
from pathlib import Path, PurePosixPath
import shutil, subprocess, zipfile
REPO = Path(r"D:\source_code\backtrader")
COMMIT = "bc80fb2a878aa963f39e812433909061dafa35ab"
OUT = Path(r"D:\temp\i51-auction-installed-20261027-r1")
OLD_ROOT = Path(r"D:\temp\i51-ctp-factor-clean-consumer-20261027-c4c7240a")
CONSUMER = OLD_ROOT / "consumer"
HISTORY = OLD_ROOT / "fixture-closure-focus-resume"
BASE_SPEC = REPO / ".codex-tmp" / "i51_factor_installed_spec_20261027_r3.json"
HELPER = REPO / ".codex-tmp" / "prepare_i51_factor_clean_consumer_20261027.py"
HELPER_SHA256 = "3aa56bb3c2b7d82245690ec2abaec9c242fd44bf4fe2856e0951566f1ad0d68f"
FOCUS_SHA256, EIGHT_RUN_SHA256 = ("1cd7717acb1c45d13d6486c9d58f084ba434f81b9d064ab7af4f907b8a35ac81",
                                 "b1513abb2058ef2d28e4e3c1eda9b40855492235caf6ee490ecfa7ee9a86a5de")
OLD_WHEEL_SHA256 = "18c488a76882355f1c5a9f621b54103678e81a2e9d5c6f6c98d89b6f3d39aea6"
OLD_RECORD, OLD_ENTRY_POINTS, OLD_CONSOLE_SCRIPT = (
    (112674, "720f97df9cd83037341c4bd0644588129ba46eff8ed0ae7d3daacfb48667cb23"),
    (59, "6d719988fff57e53415ceda830059cc4e0dba2d37b892ac8079f8ee029a0ded6"),
    (108442, "de078ffa5f76f24d5e1049ce3c089522eca4c88ffdea20fd3111fc6508bccce1"),
)
HISTORY_PINS = {"eight-node-pass/installed-focus.json": "160b7da80ac18fa9ed56b3f94dac212077bb300b130f0f482a01447df8c3809e",
    "eight-node-pass/junit.xml": "1d43224aa893765f548c01a7afaf5eabd0a31dd00bd8927a2b3d306a35e6d556",
    "eight-node-pass/installed-focused-nodes.log": "ae48768d7936fdbe23c57ad8bef5122cd065e9d2159619ac0dad8fc5c5b871d8",
    "eight-node-pass/pytest.ini": "fe7fb1972297e6ddcc185c6febd7b192e2681c8309b6920afeb82e6565199680"}
ARCHIVE_PATHS = ("setup.py", "pyproject.toml", "README.md", "LICENSE", "backtrader", "backtrader_runtime")
FACTORY, PREOPEN = ("tests/test_utils/factories.py", "tests/integration/test_ctp_factor_preopen_baseline.py")
NODES = tuple(PREOPEN + "::" + name for name in (
    "test_actual_cffex_index_opening_auction_quote_seeds_baseline_without_auction_bar",
    "test_opening_auction_baseline_is_limited_to_cffex_index_products_and_times",
    "test_cffex_first_minute_without_an_actual_auction_quote_keeps_normal_guard"))
assert all(isinstance(path, Path) for path in (REPO, OUT, OLD_ROOT, CONSUMER, HISTORY, BASE_SPEC, HELPER))
assert OUT == Path(r"D:\temp\i51-auction-installed-20261027-r1") and not OUT.exists()
assert CONSUMER.is_dir() and (CONSUMER / "Scripts" / "python.exe").is_file()
assert CONSUMER != Path(r"D:\temp\i51-ctp-nojoin-consumer-20261027-r1\consumer")
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA256
helper_spec = importlib.util.spec_from_file_location("i51_auction_installed_tools", HELPER)
assert helper_spec is not None and helper_spec.loader is not None
tools = importlib.util.module_from_spec(helper_spec); helper_spec.loader.exec_module(tools)
assert tools.ROOT.resolve() == REPO.resolve()
base_spec = tools.parse_spec(BASE_SPEC)
assert base_spec["expected_commit"] == "c4c7240ad0b7a5d0e698a9006c95f144ddf8401d"
fixture_paths = tuple(base_spec["fixture_paths"]) + (FACTORY,)
assert len(fixture_paths) == len(set(fixture_paths)) == 25 and {"tests/test_utils/__init__.py", FACTORY, PREOPEN} <= set(fixture_paths)
assert len(NODES) == 3 and all(node.startswith(PREOPEN + "::test_") for node in NODES)
assert all(node.split("::", 1)[0] in fixture_paths for node in NODES)

def git_bytes(relative: str) -> bytes:
    return subprocess.check_output(["git", "show", f"{COMMIT}:{relative}"], cwd=REPO)

factory_init, factory_source = git_bytes("tests/test_utils/__init__.py"), git_bytes(FACTORY)
assert b"from .factories import" in factory_init and b"import backtrader as bt" in factory_source
assert not any(isinstance(node, ast.ImportFrom) and (node.level or (node.module or '').startswith('tests'))
               for node in ast.walk(ast.parse(factory_source)))
baseline_source = git_bytes(PREOPEN).decode("utf-8")
assert all(f"def {node.split('::', 1)[1]}(" in baseline_source for node in NODES)
old_run_path = HISTORY / "run.json"
old_run = json.loads(old_run_path.read_text(encoding="utf-8"))
assert old_run["status"] == old_run["installed_focus"]["status"] == "PASS_SELECTED_INSTALLED_SYNTHETIC_NODES_ONLY"
assert old_run["checkout_head"] == base_spec["expected_commit"] and old_run["installed_focus"]["pytest_node_count"] == 8
assert tools.pin(old_run_path)["sha256"] == EIGHT_RUN_SHA256
old_wheel = Path(old_run["backtrader_wheel"]["path"])
assert tools.pin(old_wheel)["sha256"] == OLD_WHEEL_SHA256
bt_dist = CONSUMER / "Lib" / "site-packages" / "back_trader_python-1.4.0.dist-info"
tools.verify_file(bt_dist / "RECORD", *OLD_RECORD, "preupgrade_backtrader_record_mismatch")
tools.verify_file(bt_dist / "entry_points.txt", *OLD_ENTRY_POINTS, "preupgrade_entry_points_mismatch")
tools.verify_file(CONSUMER / "Scripts" / "bt-runtime.exe", *OLD_CONSOLE_SCRIPT, "preupgrade_console_script_mismatch")
old_artifacts = (("eight-node-pass/run.json", old_run_path), ("eight-node-pass/installed-focus.json", HISTORY / "installed-focus.json"),
    ("eight-node-pass/junit.xml", HISTORY / "junit.xml"), ("eight-node-pass/installed-focused-nodes.log", HISTORY / "installed-focused-nodes.log"),
    ("eight-node-pass/installed_focus.py", HISTORY / "installed_focus.py"), ("eight-node-pass/pytest.ini", HISTORY / "pytest.ini"),
    ("preupgrade/backtrader-wheel.whl", old_wheel), ("preupgrade/backtrader-RECORD", bt_dist / "RECORD"),
    ("preupgrade/backtrader-entry_points.txt", bt_dist / "entry_points.txt"), ("preupgrade/bt-runtime.exe", CONSUMER / "Scripts" / "bt-runtime.exe"),
    ("preupgrade/installed-spec.json", BASE_SPEC))
for _relative, source in old_artifacts:
    assert isinstance(source, Path) and source.is_file()
    assert _relative not in HISTORY_PINS or tools.pin(source)["sha256"] == HISTORY_PINS[_relative]
focus_template = HISTORY / "installed_focus.py"
assert tools.pin(focus_template)["sha256"] == FOCUS_SHA256
assert all(isinstance(path, Path) for path in (OUT, CONSUMER, old_wheel, focus_template))
assert not tools.within(CONSUMER.resolve(), tools.BENCHMARK_CONSUMER.resolve()) and not tools.within(tools.BENCHMARK_CONSUMER.resolve(), CONSUMER.resolve())
state = {"schema": "i51_auction_incremental_installed_v1", "status": "PREPARING", "commit": COMMIT,
         "consumer": str(CONSUMER), "benchmark_consumer_touched": False, "archive_paths": list(ARCHIVE_PATHS),
         "fixture_paths": list(fixture_paths), "node_ids": list(NODES), "sdk_records_before": {}, "commands": [],
         "evidence_scope": "exact committed wheel and three installed synthetic auction nodes only"}
OUT.mkdir()
tools.save(state, OUT)
env = {key: value for key, value in os.environ.items() if key.upper() in tools.WINDOWS_RUNTIME_ENV}
env.update(PYTHONUTF8="1", PYTHONNOUSERSITE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1")
try:
    preserved = OUT / "preserved"
    copied = []
    for relative, source in old_artifacts:
        destination = preserved / Path(*PurePosixPath(relative).parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        assert tools.pin(source)["sha256"] == tools.pin(destination)["sha256"]
        copied.append({"archive_path": relative, **tools.pin(destination)})
    copied_by_path = {row["archive_path"]: row for row in copied}
    state["preupgrade_artifacts"] = copied
    for relative, (size, digest) in tools.SDK_RECORD_PINS.items():
        state["sdk_records_before"][relative] = tools.verify_file(
            CONSUMER / "Lib" / "site-packages" / relative, size, digest, "sdk_record_preinstall_mismatch"
        )
    pins = {}
    for relative in sorted(set(base_spec["source_pins"]) | set(fixture_paths)):
        raw = git_bytes(relative)
        pins[relative] = {"size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    state["source_pins"] = pins
    source_zip, source_root = OUT / "source.zip", OUT / "source"
    source_root.mkdir()
    archive_command = ["git", "archive", "--format=zip", f"--output={source_zip}", COMMIT, *ARCHIVE_PATHS]
    tools.run_command(state, OUT, "git-archive", archive_command, cwd=REPO, env=env, timeout=120)
    with zipfile.ZipFile(source_zip) as bundle:
        allowed = set(ARCHIVE_PATHS)
        for member in bundle.namelist():
            path = PurePosixPath(member.rstrip("/"))
            assert path.parts and path.parts[0] in allowed and ".." not in path.parts
        bundle.extractall(source_root)
    package_pins = {path: pin for path, pin in pins.items() if path.startswith(("backtrader/", "backtrader_runtime/"))}
    state["package_source_pins"] = tools.validate_source_pins(source_root, package_pins)
    fixture_root = OUT / "fixtures"
    fixture_root.mkdir()
    fixture_rows = []
    for relative in fixture_paths:
        raw = git_bytes(relative)
        expected = pins[relative]
        assert len(raw) == expected["size_bytes"] and hashlib.sha256(raw).hexdigest() == expected["sha256"]
        destination = fixture_root.joinpath(*PurePosixPath(relative).parts)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        fixture_rows.append({"path": relative, **expected})
    state["fixture_files"] = fixture_rows
    wheelhouse = OUT / "wheelhouse"
    wheelhouse.mkdir()
    build = [str(tools.BUILD_PYTHON), "-I", "-m", "pip", "wheel", "--disable-pip-version-check",
             "--no-cache-dir", "--no-index", "--no-deps", "--no-build-isolation",
             "--wheel-dir", str(wheelhouse), str(source_root)]
    assert isinstance(wheelhouse, Path) and all(isinstance(arg, str) for arg in build)
    tools.run_command(state, OUT, "backtrader-wheel-build", build, cwd=OUT, env=env, timeout=900)
    wheels = list(wheelhouse.glob("*.whl"))
    assert len(wheels) == 1
    wheel = wheels[0]
    with zipfile.ZipFile(wheel) as bundle:
        names = bundle.namelist()
        metadata = [name for name in names if name.endswith(".dist-info/METADATA")]
        entrypoints = [name for name in names if name.endswith(".dist-info/entry_points.txt")]
        assert len(metadata) == len(entrypoints) == 1
        assert b"Version: 1.4.0\n" in bundle.read(metadata[0])
        assert bundle.read(entrypoints[0]) == b"[console_scripts]\nbt-runtime = backtrader_runtime.cli:main\n"
        expected_py = {p.relative_to(source_root).as_posix(): p.read_bytes() for package in ("backtrader", "backtrader_runtime") for p in (source_root / package).rglob("*.py")}
        actual_py = {name: bundle.read(name) for name in names if name.startswith(("backtrader/", "backtrader_runtime/")) and name.endswith(".py")}
        assert actual_py == expected_py and expected_py
    state["new_wheel"] = tools.pin(wheel)
    consumer_python = CONSUMER / "Scripts" / "python.exe"
    install = [str(consumer_python), "-I", "-m", "pip", "install", "--disable-pip-version-check", "--no-index", "--no-cache-dir", "--no-deps", "--force-reinstall", str(wheel)]
    assert isinstance(consumer_python, Path) and Path(install[0]) == consumer_python
    tools.run_command(state, OUT, "backtrader-install-only", install, cwd=OUT, env=env, timeout=300)
    for relative, (size, digest) in tools.SDK_RECORD_PINS.items():
        tools.verify_file(CONSUMER / "Lib" / "site-packages" / relative, size, digest,
                          "sdk_record_changed_after_backtrader_install")
    tools.run_command(state, OUT, "pip-check", [str(consumer_python), "-I", "-m", "pip", "check"],
                      cwd=OUT, env=env, timeout=60)
    focus = OUT / "installed_focus.py"
    shutil.copyfile(focus_template, focus)
    assert tools.pin(focus)["sha256"] == FOCUS_SHA256
    ini = OUT / "pytest.ini"
    ini.write_text("[pytest]\naddopts =\nmarkers =\n    integration: selected local synthetic integration nodes\n",
                   encoding="utf-8")
    command = [str(consumer_python), "-I", str(focus), str(REPO), str(CONSUMER), str(fixture_root), str(wheel), str(OUT), str(ini), "1.4.0", "[]", *NODES]
    assert command[3:7] == [str(REPO), str(CONSUMER), str(fixture_root), str(wheel)]
    assert command[7:10] == [str(OUT), str(ini), "1.4.0"] and command[11:] == list(NODES)
    test_temp = OUT / "process-temp"
    test_temp.mkdir()
    test_env = dict(env, TEMP=str(test_temp), TMP=str(test_temp), TMPDIR=str(test_temp))
    tools.run_command(state, OUT, "three-auction-nodes", command, cwd=OUT, env=test_env, timeout=1200)
    focus_result = json.loads((OUT / "installed-focus.json").read_text(encoding="utf-8"))
    assert focus_result["pytest_node_count"] == 3 and focus_result["node_ids"] == list(NODES)
    assert all(tools.pin(fixture_root / row["path"])["sha256"] == row["sha256"] for row in fixture_rows)
    state["installed_focus"] = focus_result
    state["new_installed_backtrader_record"] = tools.pin(
        CONSUMER / "Lib" / "site-packages" / "back_trader_python-1.4.0.dist-info" / "RECORD"
    )
    for relative, (size, digest) in tools.SDK_RECORD_PINS.items():
        state.setdefault("sdk_records_after", {})[relative] = tools.verify_file(
            CONSUMER / "Lib" / "site-packages" / relative, size, digest, "sdk_record_changed_after_focus"
        )
    replaced_by_install = {"preupgrade/backtrader-RECORD", "preupgrade/backtrader-entry_points.txt", "preupgrade/bt-runtime.exe"}
    for relative, source in old_artifacts:
        preserved_path = preserved / Path(*PurePosixPath(relative).parts)
        preserved_pin = tools.pin(preserved_path)
        assert (preserved_pin["size_bytes"], preserved_pin["sha256"]) == (copied_by_path[relative]["size_bytes"], copied_by_path[relative]["sha256"])
        if relative not in replaced_by_install:
            source_pin = tools.pin(source)
            assert (source_pin["size_bytes"], source_pin["sha256"]) == (preserved_pin["size_bytes"], preserved_pin["sha256"])
    state["status"] = "PASS_THREE_INSTALLED_SYNTHETIC_AUCTION_NODES_ONLY"
    tools.save(state, OUT)
except BaseException as error:
    state.update(status="FAILED", failure_type=type(error).__name__,
                 failure_code=str(error) if isinstance(error, tools.CheckFailure) else "unclassified")
    tools.save(state, OUT)
    raise
