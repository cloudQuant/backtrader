"""Run the bounded public source/fixture focus and retain its original outputs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/source_code/backtrader')
OUT = Path(sys.argv[1])
NODES = sys.argv[2:]
assert NODES and not OUT.exists()
SOURCES = (
    'backtrader/feeds/ctp_factor_source.py',
    'backtrader/feeds/btapifeed.py',
    'backtrader/stores/btapistore.py',
    'backtrader/stores/registered_sim.py',
    'backtrader/research/live_cohort.py',
    'examples/unified/028_alpha003_simnow_minute/run.py',
    'tests/integration/test_ctp_factor_source_cohort.py',
    'tests/integration/test_ctp_live_midnight_trading_day.py',
    'tests/integration/test_live_cohort_ctp_trading_day_normalization.py',
    'tests/unit/test_alpha003_simnow_runner.py',
)
missing_sources = [name for name in SOURCES if not (ROOT / name).is_file()]
assert set(missing_sources) <= {'tests/integration/test_ctp_factor_source_cohort.py'}
assert all((ROOT / node.split('::', 1)[0]).is_file() for node in NODES)
SOURCES = tuple(name for name in SOURCES if name not in missing_sources)

def pins():
    result = {}
    for name in SOURCES:
        raw = (ROOT / name).read_bytes()
        result[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    return result

before = pins()
OUT.mkdir()
command = [
    'C:/anaconda3/python.exe', '-m', 'pytest', '-p', 'no:asyncio',
    '-q', '--tb=short', '--junitxml=' + str(OUT / 'junit.xml'), *NODES,
]
env = os.environ.copy()
for name in ('PYTHONPATH', 'PYTHONHOME'):
    env.pop(name, None)
env.update(PYTHONUTF8='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
state = {'command': command, 'source_pins_before': before, 'nodes': NODES,
         'unavailable_unselected_source_paths': missing_sources}
(OUT / 'command.json').write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
started = time.monotonic()
with (OUT / 'stdout.txt').open('wb') as stdout, (OUT / 'stderr.txt').open('wb') as stderr:
    try:
        completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=240)
        state['exit_code'] = completed.returncode
        state['timed_out'] = False
    except subprocess.TimeoutExpired:
        state['exit_code'] = None
        state['timed_out'] = True
state['elapsed_seconds'] = time.monotonic() - started
state['source_pins_after'] = pins()
state['source_pins_unchanged'] = state['source_pins_after'] == before
state['level'] = 'SOURCE_FAKE_CTP_FACTOR_SOURCE_ONLY'
(OUT / 'result.json').write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: state[key] for key in ('exit_code', 'timed_out', 'elapsed_seconds', 'source_pins_unchanged', 'level')}))
sys.exit(0 if state['exit_code'] == 0 and state['source_pins_unchanged'] and not state['timed_out'] else 1)
