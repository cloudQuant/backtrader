"""Bounded public-source QA with pins limited to the selected fixture closure."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('D:/source_code/backtrader')
OUT = Path(sys.argv[1])
NODES = sys.argv[2:]
assert NODES and not OUT.exists()
SOURCES = [
    'backtrader/feeds/ctp_factor_source.py',
    'backtrader/feeds/btapifeed.py',
    'backtrader/feeds/futures_sessions.py',
    'backtrader/feeds/futures_main_contract.py',
    'backtrader/stores/btapistore.py',
    'backtrader/stores/registered_sim.py',
    'backtrader/research/live_cohort.py',
]
SELECTED = {node.split('::', 1)[0] for node in NODES}
SOURCES.extend(sorted(SELECTED))
SELECTOR = Path('D:/bt_api_py/bt_api/bt_api_ctp/src/bt_api_ctp/ctp_env_selector.py')
RUNNER_SELECTED = 'tests/unit/test_alpha003_simnow_runner.py' in SELECTED
if RUNNER_SELECTED:
    SOURCES.extend([
        'examples/unified/028_alpha003_simnow_minute/run.py',
        'examples/unified/028_alpha003_simnow_minute/entry_tier.py',
        'examples/unified/028_alpha003_simnow_minute/alpha003_strategy.py',
        'tests/unit/stores/test_factor_execution_facts.py',
        str(SELECTOR),
    ])
if 'tests/integration/test_ctp_factor_source_cohort.py' in SELECTED:
    SOURCES.append('tests/unit/feeds/test_futures_sessions.py')
assert len(SOURCES) == len(set(SOURCES))
assert all((ROOT / name).is_file() for name in SOURCES)

def pins():
    result = {}
    for name in SOURCES:
        raw = (ROOT / name).read_bytes()
        result[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    return result

before = pins()
OUT.mkdir()
command = [
    'C:/anaconda3/python.exe', '-m', 'pytest', '-p', 'no:asyncio',
    '-q', '--tb=short', '--junitxml=' + str(OUT / 'junit.xml'), *NODES,
]
env = os.environ.copy()
for name in ('PYTHONPATH', 'PYTHONHOME', 'BT_CTP_TEST_SELECTOR_SOURCE'):
    env.pop(name, None)
env.update(PYTHONUTF8='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
if RUNNER_SELECTED:
    env['BT_CTP_TEST_SELECTOR_SOURCE'] = str(SELECTOR)
state = {'command': command, 'source_pins_before': before, 'nodes': NODES,
         'selector_public_source_override': str(SELECTOR) if RUNNER_SELECTED else None}
(OUT / 'command.json').write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
started = time.monotonic()
with (OUT / 'stdout.txt').open('wb') as stdout, (OUT / 'stderr.txt').open('wb') as stderr:
    try:
        completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=240)
        state['exit_code'] = completed.returncode
        state['timed_out'] = False
    except subprocess.TimeoutExpired:
        state['exit_code'] = None
        state['timed_out'] = True
state['elapsed_seconds'] = time.monotonic() - started
state['source_pins_after'] = pins()
state['source_pins_unchanged'] = state['source_pins_after'] == before
state['level'] = 'SOURCE_FAKE_CTP_FACTOR_SOURCE_ONLY'
(OUT / 'result.json').write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: state[key] for key in ('exit_code', 'timed_out', 'elapsed_seconds', 'source_pins_unchanged', 'level')}))
sys.exit(0 if state['exit_code'] == 0 and state['source_pins_unchanged'] and not state['timed_out'] else 1)
