"""Unexecutable postflight draft for one same-run, full-pool tape.

The existing saved-tape validator remains mandatory and runs once in native
and once in build mode against the exact plan and tape returned by one closed
read-only run. This module only adds the three-target continuous-witness
predicate; it never creates a reduced three-feed plan or Cerebro.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timezone
import hashlib
import math
from pathlib import Path
from typing import Any


DRAFT_UNEXECUTABLE = True
EXPECTED_FULL_TARGET_COUNT = 87
EXPECTED_FULL_GRID_MINUTES = 195
REQUIRED_LIVE_READY_ROWS = 100
MIN_RUN_SECONDS = 2 * 60 * 60
REQUIRED_TARGETS = ("DCE.I", "SHFE.RB", "CZCE.MA")
MAX_TAPE_BYTES = 64 * 1024 * 1024
MIN_CONSECUTIVE_TARGET_WITNESSES = 3


def _utc_window_value(value: Any) -> datetime | None:
    if type(value) is not str or not value or value != value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value[:-1] + "+00:00" if value.endswith("Z") else value)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    if parsed.utcoffset().total_seconds() != 0:
        return None
    return parsed.astimezone(timezone.utc)


def fullpool_acceptance_checks(result: Any) -> dict[str, bool]:
    """Aggregate the final public run, cleanup, source, and postflight facts.

    A passing offline tape validator is one required fact, not a complete
    run acceptance. This projection never claims that the host process exited.
    """

    result = result if isinstance(result, Mapping) else {}
    run_value = result.get("run")
    post_value = result.get("postflight")
    run = run_value if isinstance(run_value, Mapping) else {}
    post = post_value if isinstance(post_value, Mapping) else {}
    offline = post.get("offline_modes")
    offline = offline if isinstance(offline, Mapping) else {}
    window_value = result.get("live_call_window")
    window = window_value if isinstance(window_value, Mapping) else {}
    window_start = _utc_window_value(window.get("started_at_utc"))
    window_end = _utc_window_value(window.get("returned_at_utc"))
    source_time_marker = _utc_window_value(
        window.get("first_qualified_source_available_at_utc")
    )
    source_time_marker_kind = window.get("source_time_marker_kind")
    postflight_warmup_marker = _utc_window_value(
        post.get("first_full_cohort_live_ready_available_at_utc")
    )
    window_duration = (
        (window_end - window_start).total_seconds()
        if window_start is not None and window_end is not None and window_end >= window_start
        else None
    )
    availability_value = result.get("validated_tape_availability")
    availability = availability_value if isinstance(availability_value, Mapping) else {}
    availability_time = _utc_window_value(availability.get("validated_at_utc"))
    duration = post.get("run_duration_seconds")
    try:
        duration_ok = (
            type(duration) in (int, float)
            and math.isfinite(float(duration))
            and duration >= MIN_RUN_SECONDS
        )
    except (OverflowError, TypeError, ValueError):
        duration_ok = False
    digest = post.get("tape_sha256")
    digest_ok = (
        type(digest) is str
        and len(digest) == 64
        and all(character in "0123456789abcdef" for character in digest)
    )
    tape_bytes = post.get("tape_bytes")
    checks = {
        "closed_complete_phase": (
            result.get("phase") == "complete"
            and result.get("status")
            in {"FULL_POOL_POSTFLIGHT_PASS", "FULL_POOL_TAPE_WITNESS_PASS"}
            and result.get("private_context_closed") is True
        ),
        "read_only_profile": result.get("allow_writes") is False,
        "source_pins_unchanged": result.get("source_pins_unchanged") is True,
        "process_tree_memory_scope_explicit": (
            result.get("process_tree_memory_observation") == "NOT_RUN_IN_R9"
        ),
        "zero_writes_observed": result.get("write_surfaces_observed_zero") is True,
        "native_cleanup_confirmed": result.get("native_cleanup_confirmed") is True,
        "timer_joined": result.get("timer_joined") is True,
        "live_run_complete": run.get("run_returned_complete") is True,
        "full_target_selection": (
            run.get("target_count") == EXPECTED_FULL_TARGET_COUNT
            and run.get("expected_full_target_count_matches") is True
            and run.get("same_run_plan_target_count") == EXPECTED_FULL_TARGET_COUNT
            and run.get("factor_mode_native") is True
        ),
        "full_planned_grid_recorded": (
            run.get("same_run_plan_grid_minutes") == EXPECTED_FULL_GRID_MINUTES
            and run.get("decision_tape_records") == EXPECTED_FULL_GRID_MINUTES
            and run.get("full_grid_record_count_matches") is True
        ),
        "read_only_mode": run.get("write_mode_disabled") is True,
        "normal_resource_cleanup": run.get("cleanup_complete") is True,
        "normal_epoch_retirement": run.get("normal_epoch_retired") is True,
        "controlled_stop": run.get("controlled_stop") is True,
        "strategy_shutdown_proof": (
            run.get("strategy_ready_to_close") is True
            and run.get("strategy_post_join_confirmed") is True
        ),
        "qualified_fullpool_postflight": (
            post.get("status") == "PASS"
            and post.get("normal_cleanup_complete") is True
            and post.get("zero_writes_confirmed") is True
            and post.get("controlled_stop_confirmed") is True
            and post.get("epoch_retired_confirmed") is True
            and post.get("evidence_level")
            == "SAME_RUN_FULL_87_MEMBER_TAPE_WITH_THREE_TARGET_WITNESS_ONLY"
            and post.get("selection_manifest_binding_verified") is True
            and post.get("same_run_plan_used") is True
            and post.get("target_count") == EXPECTED_FULL_TARGET_COUNT
            and post.get("planned_grid_minutes") == EXPECTED_FULL_GRID_MINUTES
            and post.get("decision_record_count") == EXPECTED_FULL_GRID_MINUTES
            and type(post.get("required_live_ready_rows")) is int
            and post.get("required_live_ready_rows") >= REQUIRED_LIVE_READY_ROWS
            and offline.get("native") == "PASS"
            and offline.get("build") == "PASS"
        ),
        "three_target_qualified_streak": (
            type(post.get("longest_consecutive_three_target_rows")) is int
            and post.get("longest_consecutive_three_target_rows")
            >= MIN_CONSECUTIVE_TARGET_WITNESSES
            and post.get("required_consecutive_three_target_rows")
            == MIN_CONSECUTIVE_TARGET_WITNESSES
        ),
        "full_run_duration": duration_ok,
        "actual_live_call_window_for_external_sampling": (
            window.get("runner_call_returned") is True
            and window_duration is not None
            and window_duration >= MIN_RUN_SECONDS
        ),
        "first_full_cohort_source_time_marker_matches_tape": (
            source_time_marker is not None
            and source_time_marker == postflight_warmup_marker
            and source_time_marker_kind == "TAPE_EVENT_WATERMARK_NOT_OS_WALL_CLOCK"
        ),
        "validated_tape_availability_for_external_sampling": (
            availability.get("status") == "VERIFIED"
            and type(availability.get("file_id")) is str
            and bool(availability.get("file_id"))
            and availability.get("file_id") == post.get("tape_file_id")
            and availability.get("sha256") == post.get("tape_sha256")
            and availability.get("bytes") == post.get("tape_bytes")
            and availability.get("record_count") == post.get("decision_record_count")
            and availability_time is not None
            and window_end is not None
            and availability_time >= window_end
        ),
        "bounded_tape_identity": (
            type(post.get("tape_file_id")) is str
            and bool(post.get("tape_file_id"))
            and digest_ok
            and type(tape_bytes) is int
            and 1 <= tape_bytes <= MAX_TAPE_BYTES
        ),
    }
    return checks


class _PostflightFailure(Exception):
    def __init__(self, code: str):
        self.code = code


def _fail(code: str) -> None:
    raise _PostflightFailure(code)


def _mapping(value: Any, code: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(code)
    return value


def _text(value: Any, code: str) -> str:
    if type(value) is not str or not value or value != value.strip():
        _fail(code)
    return value


def _utc(runner: Any, value: Any, code: str) -> datetime:
    try:
        result = runner._aware_datetime(value, "full-pool postflight")
    except Exception:
        _fail(code)
    if not isinstance(result, datetime) or result.tzinfo is None:
        _fail(code)
    return result.astimezone(timezone.utc)


def _finite(value: Any) -> float | None:
    if type(value) not in (int, float):
        return None
    try:
        number = float(value)
    except (OverflowError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _qualified_target_point(row: Mapping[str, Any], target: str) -> bool:
    members = row.get("members")
    factors = row.get("factors")
    if not isinstance(members, Mapping) or not isinstance(factors, Mapping):
        return False
    factor_rows = factors.get("factors")
    if not isinstance(factor_rows, Mapping):
        return False
    alpha003 = factor_rows.get("alpha003")
    if not isinstance(alpha003, Mapping):
        return False
    values = alpha003.get("values")
    if not isinstance(values, Mapping):
        return False
    member = members.get(target)
    point = values.get(target)
    if not isinstance(member, Mapping) or not isinstance(point, Mapping):
        return False
    value_row = point.get("value")
    if not isinstance(value_row, Mapping) or value_row.get("finite") is not True:
        return False
    number = _finite(value_row.get("value"))
    if number is None:
        return False
    try:
        if value_row.get("float64_hex") != number.hex():
            return False
    except (OverflowError, ValueError):
        return False
    generation = member.get("connection_generation")
    sequence = member.get("feed_sequence")
    return bool(
        member.get("complete") is True
        and member.get("present") is True
        and member.get("quality") == "GOOD"
        and member.get("source_role") == "live"
        and type(generation) is int
        and generation > 0
        and type(sequence) is int
        and sequence > 0
        and point.get("status") == "OUTPUT_AVAILABLE"
        and point.get("reason") is None
        and point.get("present") is True
        and point.get("complete") is True
        and point.get("quality") == "GOOD"
        and point.get("source_role") == "live"
        and point.get("member_id") == target
        and point.get("sequence") == sequence
        and point.get("generation") == generation
    )


def measure_three_target_witness_streak(
    runner: Any,
    rows: Any,
    expected: Mapping[str, Any],
    expected_cohort: Mapping[str, Any],
) -> dict[str, Any]:
    """Measure adjacent all-three-qualified rows in an already validated tape.

    Warmup and valid unavailable-factor rows reset the streak. Slot/time
    identity is checked against the independent expected-plan projection;
    a discontinuity resets the witness streak. The enclosing saved-tape
    validator remains responsible for rejecting any missing or extra grid row.
    """

    targets = expected.get("targets")
    minutes = expected.get("minutes")
    if (
        type(targets) is not list
        or len(targets) != EXPECTED_FULL_TARGET_COUNT
        or len(set(targets)) != EXPECTED_FULL_TARGET_COUNT
        or not set(REQUIRED_TARGETS).issubset(targets)
        or type(minutes) is not list
        or len(minutes) != EXPECTED_FULL_GRID_MINUTES
    ):
        _fail("FULL_POOL_EXPECTED_PLAN_INVALID")
    if (
        not isinstance(expected_cohort, Mapping)
        or set(expected_cohort)
        != {"cohort_id", "calendar_version", "epoch_id", "timezone_id"}
        or type(expected_cohort.get("epoch_id")) is not int
        or expected_cohort["epoch_id"] < 1
        or expected_cohort.get("timezone_id") != "UTC"
    ):
        _fail("FULL_POOL_EXPECTED_COHORT_INVALID")
    cohort_id = _text(expected_cohort.get("cohort_id"), "FULL_POOL_EXPECTED_COHORT_INVALID")
    calendar_version = _text(
        expected_cohort.get("calendar_version"), "FULL_POOL_EXPECTED_COHORT_INVALID"
    )

    target_set = set(targets)
    seen = 0
    qualified_rows = 0
    current_streak = 0
    longest_streak = 0
    previous_slot = None
    first_full_cohort_live_ready_available_at_utc = None
    try:
        iterator = iter(rows)
        for index, row_value in enumerate(iterator):
            if index >= EXPECTED_FULL_GRID_MINUTES:
                _fail("FULL_POOL_TAPE_ROW_COUNT_INVALID")
            row = _mapping(row_value, "FULL_POOL_TAPE_ROW_INVALID")
            planned = _mapping(minutes[index], "FULL_POOL_PLAN_MINUTE_INVALID")
            slot_index = row.get("slot_index")
            expected_slot = planned.get("slot_index")
            if (
                type(slot_index) is not int
                or type(expected_slot) is not int
                or slot_index != expected_slot
                or _utc(runner, row.get("close_time"), "FULL_POOL_TAPE_TIME_INVALID")
                != _utc(runner, planned.get("close_time"), "FULL_POOL_PLAN_TIME_INVALID")
            ):
                _fail("FULL_POOL_TAPE_GRID_MISMATCH")
            if (
                row.get("cohort_id") != cohort_id
                or row.get("calendar_version") != calendar_version
                or type(row.get("epoch_id")) is not int
                or row.get("epoch_id") != expected_cohort["epoch_id"]
            ):
                _fail("FULL_POOL_TAPE_COHORT_MISMATCH")
            members = row.get("members")
            factor_block = row.get("factors")
            factors = factor_block.get("factors") if isinstance(factor_block, Mapping) else None
            alpha003 = factors.get("alpha003") if isinstance(factors, Mapping) else None
            values = alpha003.get("values") if isinstance(alpha003, Mapping) else None
            if (
                not isinstance(members, Mapping)
                or set(members) != target_set
                or not isinstance(values, Mapping)
                or set(values) != target_set
            ):
                _fail("FULL_POOL_TAPE_MEMBERSHIP_INVALID")
            readiness = row.get("readiness")
            reasons = row.get("readiness_reasons")
            if (
                readiness not in {"WARMUP", "LIVE_READY"}
                or type(reasons) is not list
                or any(type(reason) is not str or not reason for reason in reasons)
                or (readiness == "LIVE_READY" and reasons)
            ):
                _fail("FULL_POOL_TAPE_READINESS_INVALID")
            ready = readiness == "LIVE_READY" and reasons == []
            if ready:
                available_at = _utc(
                    runner,
                    row.get("available_at"),
                    "FULL_POOL_TAPE_AVAILABLE_AT_INVALID",
                )
                close_time = _utc(
                    runner,
                    row.get("close_time"),
                    "FULL_POOL_TAPE_TIME_INVALID",
                )
                if available_at < close_time:
                    _fail("FULL_POOL_TAPE_AVAILABLE_AT_INVALID")
                if not all(
                    isinstance(members[target], Mapping)
                    and members[target].get("complete") is True
                    and members[target].get("present") is True
                    and members[target].get("quality") == "GOOD"
                    and members[target].get("source_role") == "live"
                    and type(members[target].get("connection_generation")) is int
                    and members[target].get("connection_generation") > 0
                    and type(members[target].get("feed_sequence")) is int
                    and members[target].get("feed_sequence") > 0
                    for target in targets
                ):
                    _fail("FULL_POOL_TAPE_LIVE_READY_RECEIPTS_INVALID")
                if first_full_cohort_live_ready_available_at_utc is None:
                    first_full_cohort_live_ready_available_at_utc = available_at.isoformat()
            all_targets_qualified = ready and all(
                _qualified_target_point(row, target) for target in REQUIRED_TARGETS
            )
            adjacent = previous_slot is None or slot_index == previous_slot + 1
            if all_targets_qualified:
                qualified_rows += 1
                current_streak = current_streak + 1 if adjacent else 1
            else:
                current_streak = 0
            longest_streak = max(longest_streak, current_streak)
            previous_slot = slot_index
            seen += 1
    except _PostflightFailure:
        raise
    except Exception:
        _fail("FULL_POOL_TAPE_ITERATOR_REJECTED")

    if seen != EXPECTED_FULL_GRID_MINUTES:
        _fail("FULL_POOL_TAPE_ROW_COUNT_INVALID")
    if longest_streak < MIN_CONSECUTIVE_TARGET_WITNESSES:
        _fail("THREE_TARGET_QUALIFIED_STREAK_MISSING")
    return {
        "decision_record_count": seen,
        "three_target_qualified_rows": qualified_rows,
        "longest_consecutive_three_target_rows": longest_streak,
        "required_consecutive_three_target_rows": MIN_CONSECUTIVE_TARGET_WITNESSES,
        "first_full_cohort_live_ready_available_at_utc": (
            first_full_cohort_live_ready_available_at_utc
        ),
    }


def _hash_file(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_TAPE_BYTES:
                _fail("FULL_POOL_TAPE_BYTE_LIMIT_EXCEEDED")
            digest.update(chunk)
    return size, digest.hexdigest()


def _validate_offline_result(
    result: Any,
    *,
    factor_mode: str,
    file_id: str,
    sha256: str,
    byte_count: int,
) -> Mapping[str, Any]:
    result = _mapping(result, "FULL_POOL_OFFLINE_VALIDATION_INVALID")
    if (
        result.get("status") != "PASS"
        or result.get("evidence_level") != "SAVED_DECISION_TAPE_OFFLINE_CEREBRO_PARITY_ONLY"
        or result.get("file_id") != file_id
        or result.get("tape_sha256") != sha256
        or result.get("tape_bytes") != byte_count
        or result.get("decision_record_count") != EXPECTED_FULL_GRID_MINUTES
        or result.get("target_count") != EXPECTED_FULL_TARGET_COUNT
        or result.get("grid_minute_count") != EXPECTED_FULL_GRID_MINUTES
        or result.get("offline_factor_mode") != factor_mode
        or type(result.get("live_ready_rows")) is not int
        or result.get("live_ready_rows") < REQUIRED_LIVE_READY_ROWS
        or type(result.get("required_live_ready")) is not int
        or result.get("required_live_ready") < REQUIRED_LIVE_READY_ROWS
        or result.get("orders_submitted") != 0
        or result.get("provider_calls") != 0
    ):
        _fail("FULL_POOL_OFFLINE_VALIDATION_FAILED")
    return result


def validate_fullpool_postflight(
    runner: Any,
    saved_tape_validator: Any,
    summary: Any,
    *,
    clock_domain_id: str,
    calendar_id: str,
    expected_cohort: Mapping[str, Any],
    normal_cleanup_complete: Any,
    zero_writes_confirmed: Any,
    controlled_stop_confirmed: Any,
    epoch_retired_confirmed: Any,
    run_duration_seconds: Any,
    direction: int,
    preheat_bars: int,
) -> dict[str, Any]:
    """Validate one closed 87-target run, then its three-target witness slice."""

    try:
        summary = _mapping(summary, "FULL_POOL_SUMMARY_INVALID")
        if (
            normal_cleanup_complete is not True
            or summary.get("cleanup_complete") is not True
            or zero_writes_confirmed is not True
            or controlled_stop_confirmed is not True
            or epoch_retired_confirmed is not True
            or type(run_duration_seconds) not in (int, float)
            or not math.isfinite(float(run_duration_seconds))
            or run_duration_seconds < MIN_RUN_SECONDS
            or summary.get("status") != "LIVE_RUN_COMPLETE"
            or summary.get("mode") != "live"
            or summary.get("source_clock_domain_id") != clock_domain_id
        ):
            _fail("FULL_POOL_RUN_GATES_NOT_CONFIRMED")
        if type(direction) is not int or direction not in (-1, 1):
            _fail("FULL_POOL_DIRECTION_INVALID")
        if type(preheat_bars) is not int or preheat_bars < 1:
            _fail("FULL_POOL_PREHEAT_INVALID")
        if (
            not isinstance(expected_cohort, Mapping)
            or set(expected_cohort)
            != {"cohort_id", "calendar_version", "epoch_id", "timezone_id"}
            or type(expected_cohort.get("epoch_id")) is not int
            or expected_cohort["epoch_id"] < 1
            or summary.get("epoch_id") != expected_cohort["epoch_id"]
            or expected_cohort.get("timezone_id") != "UTC"
        ):
            _fail("FULL_POOL_SUMMARY_COHORT_MISMATCH")

        plan = _mapping(summary.get("_plan"), "FULL_POOL_SAME_RUN_PLAN_MISSING")
        targets = plan.get("targets")
        if (
            type(targets) not in (tuple, list)
            or len(targets) != EXPECTED_FULL_TARGET_COUNT
            or len(set(targets)) != EXPECTED_FULL_TARGET_COUNT
            or not set(REQUIRED_TARGETS).issubset(targets)
            or plan.get("golden_targets") not in (None, (), [])
        ):
            _fail("FULL_POOL_PLAN_NOT_FULL_SELECTION")
        projection = saved_tape_validator.project_expected_plan(
            plan, clock_domain_id=clock_domain_id, calendar_id=calendar_id
        )
        if (
            len(projection.get("targets", ())) != EXPECTED_FULL_TARGET_COUNT
            or len(projection.get("minutes", ())) != EXPECTED_FULL_GRID_MINUTES
            or set(REQUIRED_TARGETS).difference(projection.get("targets", ()))
        ):
            _fail("FULL_POOL_PLAN_PROJECTION_INVALID")

        route_projection = projection.get("routes")
        if not isinstance(route_projection, Mapping):
            _fail("FULL_POOL_PLAN_ROUTES_INVALID")
        expected_summary_routes = {
            target: route_projection[target]["instrument_id"] for target in projection["targets"]
        }
        if (
            summary.get("selection_source") != projection.get("selection_source")
            or summary.get("source_snapshot_id") != projection.get("source_snapshot_id")
            or summary.get("routes") != expected_summary_routes
        ):
            _fail("FULL_POOL_SUMMARY_PLAN_BINDING_MISMATCH")

        writer = _mapping(summary.get("decision_tape"), "FULL_POOL_TAPE_SUMMARY_MISSING")
        readback = _mapping(
            summary.get("decision_tape_readback"), "FULL_POOL_TAPE_READBACK_MISSING"
        )
        file_id = _text(writer.get("file_id"), "FULL_POOL_TAPE_FILE_ID_INVALID")
        path_text = _text(writer.get("path"), "FULL_POOL_TAPE_PATH_INVALID")
        path = Path(path_text)
        max_bytes = writer.get("max_bytes")
        byte_count = writer.get("bytes")
        record_count = writer.get("record_count")
        digest = writer.get("sha256")
        last_reference = writer.get("last_record_reference")
        if (
            not path.is_absolute()
            or path.is_symlink()
            or not path.is_file()
            or type(max_bytes) is not int
            or not 1 <= max_bytes <= MAX_TAPE_BYTES
            or type(byte_count) is not int
            or not 1 <= byte_count <= max_bytes
            or type(record_count) is not int
            or record_count != EXPECTED_FULL_GRID_MINUTES
            or type(digest) is not str
            or len(digest) != 64
            or any(character not in "0123456789abcdef" for character in digest)
            or writer.get("closed") is not True
            or writer.get("failed") is not False
            or not isinstance(last_reference, Mapping)
            or last_reference.get("file_id") != file_id
            or type(last_reference.get("record_index")) is not int
            or last_reference.get("record_index") != EXPECTED_FULL_GRID_MINUTES
            or not _text(last_reference.get("record_id"), "FULL_POOL_TAPE_LAST_REFERENCE_INVALID")
            or not _text(last_reference.get("batch_id"), "FULL_POOL_TAPE_LAST_REFERENCE_INVALID")
        ):
            _fail("FULL_POOL_TAPE_SUMMARY_INVALID")
        before = path.stat()
        size_before, digest_before = _hash_file(path)
        if size_before != byte_count or digest_before != digest or before.st_size != byte_count:
            _fail("FULL_POOL_TAPE_PIN_MISMATCH")
        if (
            readback.get("file_id") != file_id
            or readback.get("record_count") != record_count
            or readback.get("actual_bytes") != byte_count
            or readback.get("last_record_reference") != writer.get("last_record_reference")
        ):
            _fail("FULL_POOL_TAPE_READBACK_MISMATCH")

        offline_results = []
        for factor_mode in ("native", "build"):
            result = saved_tape_validator.validate_saved_factor_tape(
                path,
                expected=projection,
                expected_file_id=file_id,
                expected_sha256=digest,
                expected_bytes=byte_count,
                expected_record_count=record_count,
                factor_mode=factor_mode,
                direction=direction,
                preheat_bars=preheat_bars,
                required_live_ready=REQUIRED_LIVE_READY_ROWS,
                max_bytes=max_bytes,
            )
            offline_results.append(
                _validate_offline_result(
                    result,
                    factor_mode=factor_mode,
                    file_id=file_id,
                    sha256=digest,
                    byte_count=byte_count,
                )
            )

        def rows_after_header():
            iterator = iter(runner.iter_decision_tape(path, max_bytes=max_bytes))
            try:
                header = next(iterator)
            except StopIteration:
                _fail("FULL_POOL_TAPE_HEADER_MISSING")
            if (
                header.get("record_type") != "HEADER"
                or header.get("file_id") != file_id
                or header.get("calendar_id") != calendar_id
                or header.get("source_snapshot_id") != projection["source_snapshot_id"]
                or header.get("targets") != projection["targets"]
                or header.get("grid_sha256") != projection.get("grid_sha256")
                or header.get("factor_mode") != "native"
                or header.get("direction") != direction
            ):
                _fail("FULL_POOL_TAPE_HEADER_BINDING_MISMATCH")
            yield from iterator

        witness = measure_three_target_witness_streak(
            runner, rows_after_header(), projection, expected_cohort
        )
        size_after, digest_after = _hash_file(path)
        after = path.stat()
        if (
            size_after != byte_count
            or digest_after != digest
            or after.st_size != before.st_size
            or after.st_mtime_ns != before.st_mtime_ns
        ):
            _fail("FULL_POOL_TAPE_CHANGED_DURING_VALIDATION")
        return {
            "status": "PASS",
            "evidence_level": "SAME_RUN_FULL_87_MEMBER_TAPE_WITH_THREE_TARGET_WITNESS_ONLY",
            "selection_manifest_binding_verified": True,
            "normal_cleanup_complete": True,
            "zero_writes_confirmed": True,
            "controlled_stop_confirmed": True,
            "epoch_retired_confirmed": True,
            "run_duration_seconds": float(run_duration_seconds),
            "minimum_run_duration_seconds": MIN_RUN_SECONDS,
            "same_run_plan_used": True,
            "target_count": EXPECTED_FULL_TARGET_COUNT,
            "planned_grid_minutes": EXPECTED_FULL_GRID_MINUTES,
            "decision_record_count": witness["decision_record_count"],
            "required_live_ready_rows": REQUIRED_LIVE_READY_ROWS,
            "offline_modes": {
                "native": offline_results[0]["status"],
                "build": offline_results[1]["status"],
            },
            "tape_file_id": file_id,
            "tape_sha256": digest,
            "tape_bytes": byte_count,
            **witness,
        }
    except _PostflightFailure as error:
        return {"status": "FAIL", "code": error.code}
    except Exception:
        return {"status": "FAIL", "code": "FULL_POOL_POSTFLIGHT_INVALID"}


def main() -> int:
    if DRAFT_UNEXECUTABLE:
        raise RuntimeError("R9_DRAFT_UNEXECUTABLE")
    raise RuntimeError("ROOT_FINALIZATION_REQUIRED")


if __name__ == "__main__":
    raise SystemExit(main())
