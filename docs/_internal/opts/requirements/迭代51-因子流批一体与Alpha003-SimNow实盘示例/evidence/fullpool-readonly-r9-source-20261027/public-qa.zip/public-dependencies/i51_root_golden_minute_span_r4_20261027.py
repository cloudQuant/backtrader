"""Root-only one-shot span, CTP diagnostics, and timed graceful-stop observer.

This module imports no Backtrader or SDK modules. The caller must already hold
the pinned runner and install its public write observer before invoking it.
"""

import datetime
import sys
import threading
import time


_RETAINED = []
_RETAIN_LOCK = threading.Lock()
_JOIN_TIMEOUT_SECONDS = 5.0

_QUERY_STAGE_FIELDS = (
    "stage",
    "entered",
    "returned",
    "elapsed_seconds",
    "prior_stage_complete",
    "result_type_matches",
    "request_type_matches",
    "generation_matches",
    "request_id_positive",
    "timed_out",
    "complete",
    "is_last_seen",
    "unsupported",
    "late_callbacks_reported",
    "late_callback_count_valid",
    "record_count",
    "record_count_capped",
    "submit_category",
    "error_code_present",
    "error_code_valid",
    "error_code_nonzero",
    "error_message_present",
    "error_message_valid",
    "error_category",
    "first_completion_origin",
    "completion_origin",
)
_QUERY_UNAVAILABLE = frozenset(
    {
        "NO_QUERY_OBSERVATION",
        "COLLECTOR_SOURCE_UNAVAILABLE",
        "COLLECTOR_CHAIN_MISMATCH",
        "COLLECTOR_DID_NOT_RETURN_SNAPSHOT",
        "COLLECTOR_DIAGNOSTICS_INVALID",
        "MULTIPLE_COLLECTOR_RETURNS",
    }
)
_MD_STATUSES = frozenset(
    {
        "API_UNAVAILABLE",
        "MD_CLIENT_UNAVAILABLE",
        "SDK_IDENTITY_API_UNAVAILABLE",
        "OBSERVATION_READ_FAILED",
        "DISCONNECTED",
        "READ_ONLY_ACCEPTED",
        "MD_LOGIN_STALE_SPI",
        "MD_LOGIN_GENERATION_MISMATCH",
        "MD_LOGIN_REQUEST_ID_TYPE_INVALID",
        "MD_LOGIN_REQUEST_ID_MISMATCH",
        "MD_LOGIN_NONTERMINAL",
        "MD_LOGIN_IDENTITY_REJECTED",
        "MD_LOGIN_PROVIDER_REJECTED",
        "MD_LOGIN_OTHER",
        "MD_IDENTITY_UNAVAILABLE",
        "SESSION_CHANGED",
        "IDENTITY_UNQUALIFIED",
        "MD_SOURCE_UNBOUND",
        "MD_SOURCE_GENERATION_MISMATCH",
        "TRADING_DAY_UNOBSERVED",
        "TRADING_DAY_MISMATCH",
        "QUALIFIED",
    }
)


def _unavailable_query(category):
    if category not in _QUERY_UNAVAILABLE:
        category = "COLLECTOR_DIAGNOSTICS_INVALID"
    return {"status": "UNAVAILABLE", "category": category}


def _copy_sanitized_query(value):
    """Keep only the already-sanitized finite runner diagnostics."""
    if type(value) is not dict:
        return _unavailable_query("COLLECTOR_DIAGNOSTICS_INVALID")
    if value.get("status") == "UNAVAILABLE":
        if (
            set(value) == {"status", "category"}
            and value.get("category") in _QUERY_UNAVAILABLE
        ):
            return {"status": "UNAVAILABLE", "category": value["category"]}
        return _unavailable_query("COLLECTOR_DIAGNOSTICS_INVALID")
    stages = value.get("stages")
    if (
        set(value) != {"status", "stages"}
        or value.get("status") != "AVAILABLE"
        or type(stages) is not list
        or not 1 <= len(stages) <= 2
    ):
        return _unavailable_query("COLLECTOR_DIAGNOSTICS_INVALID")
    copied = []
    for stage in stages:
        if type(stage) is not dict or set(stage) != set(_QUERY_STAGE_FIELDS):
            return _unavailable_query("COLLECTOR_DIAGNOSTICS_INVALID")
        if any(
            value is not None
            and type(value) not in (bool, int, float, str)
            for value in stage.values()
        ):
            return _unavailable_query("COLLECTOR_DIAGNOSTICS_INVALID")
        copied.append({name: stage[name] for name in _QUERY_STAGE_FIELDS})
    return {"status": "AVAILABLE", "stages": copied}


def _sanitize_md_facts(value):
    """Copy the exact six-field RegisteredSimStore identity projection."""
    names = {
        "status",
        "observation_present",
        "identity_matches_bound",
        "source_generation_matches",
        "trading_day_matches",
        "identity_qualified",
    }
    if type(value) is not dict or set(value) != names:
        return None
    status = value.get("status")
    if type(status) is not str or status not in _MD_STATUSES:
        return None
    for name in ("observation_present", "identity_matches_bound", "identity_qualified"):
        if type(value.get(name)) is not bool:
            return None
    for name in ("source_generation_matches", "trading_day_matches"):
        if value.get(name) is not None and type(value[name]) is not bool:
            return None
    qualified = status == "QUALIFIED"
    if value["identity_qualified"] is not qualified:
        return None
    if qualified and not all(
        value[name] is True
        for name in (
            "observation_present",
            "identity_matches_bound",
            "source_generation_matches",
            "trading_day_matches",
        )
    ):
        return None
    if status == "MD_SOURCE_UNBOUND" and not (
        value["observation_present"] is True
        and value["identity_matches_bound"] is True
        and value["source_generation_matches"] is None
        and value["identity_qualified"] is False
    ):
        return None
    if status == "READ_ONLY_ACCEPTED" and not (
        value["observation_present"] is False
        and value["identity_matches_bound"] is False
        and value["source_generation_matches"] is None
        and value["trading_day_matches"] is None
        and value["identity_qualified"] is False
    ):
        return None
    return {name: value[name] for name in (
        "status",
        "observation_present",
        "identity_matches_bound",
        "source_generation_matches",
        "trading_day_matches",
        "identity_qualified",
    )}


def _utc_deadline(value):
    if type(value) is not datetime.datetime or value.tzinfo is None:
        raise ValueError("I51_SHUTDOWN_DEADLINE_INVALID")
    try:
        if value.utcoffset() != datetime.timedelta(0):
            raise ValueError("I51_SHUTDOWN_DEADLINE_INVALID")
        return value.astimezone(datetime.timezone.utc)
    except Exception:
        raise ValueError("I51_SHUTDOWN_DEADLINE_INVALID") from None


def _controlled_stop(run_live, summary):
    check = run_live.__globals__.get("_live_epoch_controlled_stopped")
    if not callable(check):
        return False
    try:
        return check(summary) is True
    except BaseException:
        return False


def _cleanup_confirmed(run_live, result, *, returned):
    check = run_live.__globals__.get("_cleanup_complete")
    if not callable(check):
        return False
    if returned:
        if type(result) is not dict or result.get("cleanup_complete") is not True:
            return False
        rows = result.get("resource_shutdown")
    else:
        rows = getattr(result, "cleanup_results", None)
    if type(rows) not in (list, tuple):
        return False
    try:
        return check(rows) is True
    except BaseException:
        return False


def _retain_visible_runner_locals(error, live_code, held):
    """Keep only named runner-owned objects from an uncertain exception path."""
    traceback = getattr(error, "__traceback__", None)
    while traceback is not None:
        frame = traceback.tb_frame
        if frame.f_code is live_code:
            locals_map = frame.f_locals
            for key, local_name in (
                ("cerebro", "cerebro"),
                ("broker", "broker"),
                ("store", "store"),
                ("loop", "refresh_loop"),
            ):
                if held[key] is None and local_name in locals_map:
                    held[key] = locals_map[local_name]
            return
        traceback = traceback.tb_next


def invoke_with_readonly_span_observation(
    run_live, observer, sink, *args, shutdown_deadline_utc, **kwargs
):
    """Run the pinned runner and request one bounded graceful stop at deadline.

    The profile hook accepts only the exact ``Cerebro.run`` call directly from
    this ``run_live`` code object. The timer only invokes that captured loop's
    exact bound ``request_shutdown`` method. Production cleanup remains owned
    by the runner and Strategy.
    """
    if type(sink) is not dict or sink:
        raise TypeError("I51_OBSERVER_SINK_INVALID")
    deadline = _utc_deadline(shutdown_deadline_utc)
    live_code = getattr(run_live, "__code__", None)
    live_globals = getattr(run_live, "__globals__", None)
    if live_code is None or type(live_globals) is not dict:
        raise RuntimeError("I51_LIVE_CODE_UNAVAILABLE")
    loop_type = live_globals.get("QueryRefreshLoop")
    request_function = getattr(loop_type, "request_shutdown", None)
    request_code = getattr(request_function, "__code__", None)
    if not callable(request_function) or request_code is None:
        raise RuntimeError("I51_REFRESH_METHOD_UNAVAILABLE")
    query_builder = live_globals.get("build_ctp_query_market_plan")
    query_builder_code = getattr(query_builder, "__code__", None)
    query_sanitizer = live_globals.get("_sanitize_ctp_query_diagnostics")
    query_field_names = live_globals.get("_CTP_QUERY_STAGE_FIELD_NAMES")
    query_contract_available = bool(
        query_builder_code is not None
        and callable(query_sanitizer)
        and type(query_field_names) is tuple
        and query_field_names == _QUERY_STAGE_FIELDS
    )
    module = sys.modules.get("backtrader.cerebro")
    cerebro_type = getattr(module, "Cerebro", None) if module is not None else None
    run_function = getattr(cerebro_type, "run", None)
    cerebro_code = getattr(run_function, "__code__", None)
    if cerebro_code is None:
        raise RuntimeError("I51_CEREBRO_CODE_UNAVAILABLE")

    sink.update(
        status="NOT_REACHED",
        capture_count=0,
        loop_bound=False,
        observer_begin_ok=False,
        observer_finish_ok=False,
        write_zero_confirmed=None,
        timer_started=False,
        timer_failed=False,
        timer_fired=False,
        request_count=0,
        request_returned=False,
        request_failed=False,
        timer_joined=True,
        cleanup_confirmed=False,
        controlled_stop=False,
        query_capture_count=0,
        query_status="NOT_OBSERVED",
        query_snapshot_returned=False,
        query_success=False,
        query_diagnostics={"status": "UNAVAILABLE", "category": "NO_QUERY_OBSERVATION"},
        query_store_matches_cerebro=False,
        md_identity_capture_status="NOT_OBSERVED",
        md_identity_status=None,
        md_observation_present=None,
        md_identity_matches_bound=None,
        md_source_generation_matches=None,
        md_trading_day_matches=None,
        md_identity_qualified=False,
        md_pre_source_identity_capture_status="NOT_OBSERVED",
        md_pre_source_identity_status=None,
        md_pre_source_observation_present=None,
        md_pre_source_identity_matches_bound=None,
        md_pre_source_generation_matches=None,
        md_pre_source_trading_day_matches=None,
        md_pre_source_identity_qualified=False,
    )
    previous_profile = sys.getprofile()
    if previous_profile is not None:
        sink["status"] = "PROFILE_ALREADY_ACTIVE"
        raise RuntimeError("I51_OBSERVER_PROFILE_ALREADY_ACTIVE")

    held = {
        "status": "NOT_REACHED",
        "cerebro": None,
        "broker": None,
        "store": None,
        "loop": None,
        "request_method": None,
        "request_function": request_function,
        "request_code": request_code,
        "timer": None,
        "timer_started": False,
        "timer_fired": False,
        "request_count": 0,
        "request_returned": False,
        "request_error": None,
        "observer_token": None,
        "observer_before": None,
        "observer_after": None,
        "observer_started": False,
        "observer_finished": False,
        "observer_error": None,
        "write_zero": None,
        "capture_count": 0,
        "capture_error": None,
        "timer_error": None,
        "profile_restore_failed": False,
        "query_capture_count": 0,
        "query_status": "NOT_OBSERVED",
        "query_snapshot_returned": False,
        "query_success": False,
        "query_diagnostics": {"status": "UNAVAILABLE", "category": "NO_QUERY_OBSERVATION"},
        "query_store": None,
        "query_builder_entered": False,
        "pre_source_capture_count": 0,
    }
    call_lock = threading.Lock()

    def fail_capture(code):
        held["status"] = code
        held["capture_error"] = code
        sink["status"] = code
        sys.setprofile(previous_profile)
        raise RuntimeError(code)

    def request_once():
        with call_lock:
            if held["timer_fired"]:
                held["request_error"] = "DUPLICATE_REQUEST_BLOCKED"
                return
            held["timer_fired"] = True
        loop = held["loop"]
        method = held["request_method"]
        function = held["request_function"]
        expected_code = held["request_code"]
        try:
            current = getattr(loop, "request_shutdown")
            if (
                type(loop) is not loop_type
                or method is None
                or getattr(method, "__self__", None) is not loop
                or getattr(method, "__func__", None) is not function
                or getattr(function, "__code__", None) is not expected_code
                or getattr(method, "__code__", None) is not expected_code
                or getattr(current, "__self__", None) is not loop
                or getattr(current, "__func__", None) is not function
                or getattr(current, "__code__", None) is not expected_code
            ):
                raise RuntimeError("I51_REFRESH_METHOD_CHANGED")
            with call_lock:
                held["request_count"] += 1
            returned = method()
            held["request_returned"] = returned is True
            if returned is not True:
                raise RuntimeError("I51_REFRESH_REQUEST_REJECTED")
        except BaseException as error:
            held["request_error"] = error

    def record_query_return(frame, returned_value):
        """Project bounded DTO fields from the exact collector call."""
        module = sys.modules.get("backtrader.feeds.futures_ctp_snapshot")
        collector = getattr(module, "collect_ctp_futures_snapshot", None)
        collector_code = getattr(collector, "__code__", None)
        if collector_code is None or frame.f_code is not collector_code:
            return

        held["query_capture_count"] += 1
        sink["query_capture_count"] = held["query_capture_count"]
        if held["query_capture_count"] != 1:
            held["query_status"] = "MULTIPLE_COLLECTOR_RETURNS"
            held["query_snapshot_returned"] = False
            held["query_success"] = False
            held["query_diagnostics"] = _unavailable_query(
                "MULTIPLE_COLLECTOR_RETURNS"
            )
            sink.update(
                query_status=held["query_status"],
                query_snapshot_returned=False,
                query_success=False,
                query_diagnostics=dict(held["query_diagnostics"]),
            )
            return

        if not query_contract_available:
            held["query_status"] = "COLLECTOR_SOURCE_UNAVAILABLE"
            held["query_diagnostics"] = _unavailable_query(
                "COLLECTOR_SOURCE_UNAVAILABLE"
            )
            sink.update(
                query_status=held["query_status"],
                query_diagnostics=dict(held["query_diagnostics"]),
            )
            return

        try:
            bridge_frame = frame.f_back
            builder_frame = bridge_frame.f_back if bridge_frame is not None else None
            live_frame = builder_frame.f_back if builder_frame is not None else None
            bridge_store = (
                bridge_frame.f_locals.get("self") if bridge_frame is not None else None
            )
            bridge_function = getattr(
                type(bridge_store), "registered_sim_collect_futures_snapshot", None
            ) if bridge_store is not None else None
            bridge_code = getattr(bridge_function, "__code__", None)
            bridge_method = (
                getattr(bridge_store, "registered_sim_collect_futures_snapshot", None)
                if bridge_store is not None
                else None
            )
            builder_collector = (
                builder_frame.f_locals.get("collector")
                if builder_frame is not None
                else None
            )
            api = getattr(bridge_store, "_api", None) if bridge_store is not None else None
            chain_ok = bool(
                bridge_frame is not None
                and bridge_code is not None
                and bridge_frame.f_code is bridge_code
                and getattr(bridge_method, "__self__", None) is bridge_store
                and getattr(bridge_method, "__func__", None) is bridge_function
                and builder_frame is not None
                and builder_frame.f_code is query_builder_code
                and builder_frame.f_locals.get("store") is bridge_store
                and getattr(builder_collector, "__self__", None) is bridge_store
                and getattr(builder_collector, "__func__", None) is bridge_function
                and live_frame is not None
                and live_frame.f_code is live_code
                and live_frame.f_locals.get("store") is bridge_store
                and frame.f_locals.get("feed") is api
                and api is not None
            )
            if not chain_ok:
                held["query_status"] = "COLLECTOR_CHAIN_MISMATCH"
                held["query_diagnostics"] = _unavailable_query(
                    "COLLECTOR_CHAIN_MISMATCH"
                )
                sink.update(
                    query_status=held["query_status"],
                    query_diagnostics=dict(held["query_diagnostics"]),
                )
                return

            held["query_store"] = bridge_store
            observation_module = module
            observation_type = getattr(
                observation_module, "CtpFuturesSnapshotQueryObservation", None
            )
            snapshot_module = sys.modules.get("backtrader.feeds.futures_main_contract")
            snapshot_type = getattr(snapshot_module, "MainContractQuerySnapshot", None)
            observations = frame.f_locals.get("observations")
            if (
                observation_type is None
                or snapshot_type is None
                or type(observations) is not list
                or len(observations) > 2
                or any(type(item) is not observation_type for item in observations)
            ):
                held["query_status"] = "COLLECTOR_DIAGNOSTICS_INVALID"
                held["query_diagnostics"] = _unavailable_query(
                    "COLLECTOR_DIAGNOSTICS_INVALID"
                )
                sink.update(
                    query_status=held["query_status"],
                    query_diagnostics=dict(held["query_diagnostics"]),
                )
                return

            stages = [
                {name: getattr(item, name) for name in query_field_names}
                for item in observations
            ]
            sanitized = query_sanitizer({"status": "AVAILABLE", "stages": stages})
            copied = _copy_sanitized_query(sanitized)
            if copied.get("status") != "AVAILABLE":
                held["query_status"] = "COLLECTOR_DIAGNOSTICS_INVALID"
                held["query_diagnostics"] = copied
                sink.update(
                    query_status=held["query_status"],
                    query_diagnostics=dict(copied),
                )
                return

            snapshot_returned = type(returned_value) is snapshot_type
            stage_rows = copied["stages"]
            query_success = bool(
                snapshot_returned
                and len(stage_rows) == 2
                and all(
                    stage.get("returned") is True
                    and stage.get("result_type_matches") is True
                    and stage.get("stage") == expected
                    for stage, expected in zip(stage_rows, ("catalog", "depth"))
                )
            )
            held["query_snapshot_returned"] = snapshot_returned
            held["query_success"] = query_success
            held["query_status"] = (
                "SNAPSHOT_RETURNED" if query_success else "COLLECTOR_DID_NOT_RETURN_SNAPSHOT"
            )
            held["query_diagnostics"] = copied
            sink.update(
                query_status=held["query_status"],
                query_snapshot_returned=snapshot_returned,
                query_success=query_success,
                query_diagnostics={
                    "status": "AVAILABLE",
                    "stages": [dict(stage) for stage in stage_rows],
                },
            )
        except BaseException:
            # Diagnostics are observational. The runner remains responsible
            # for its ordinary query success or failure decision.
            held["query_status"] = "COLLECTOR_DIAGNOSTICS_INVALID"
            held["query_snapshot_returned"] = False
            held["query_success"] = False
            held["query_diagnostics"] = _unavailable_query(
                "COLLECTOR_DIAGNOSTICS_INVALID"
            )
            sink.update(
                query_status=held["query_status"],
                query_snapshot_returned=False,
                query_success=False,
                query_diagnostics=dict(held["query_diagnostics"]),
            )

    def publish_md_identity(phase, capture_status, facts=None):
        if phase == "pre_source":
            keys = (
                "md_pre_source_identity_capture_status",
                "md_pre_source_identity_status",
                "md_pre_source_observation_present",
                "md_pre_source_identity_matches_bound",
                "md_pre_source_generation_matches",
                "md_pre_source_trading_day_matches",
                "md_pre_source_identity_qualified",
            )
        else:
            keys = (
                "md_identity_capture_status",
                "md_identity_status",
                "md_observation_present",
                "md_identity_matches_bound",
                "md_source_generation_matches",
                "md_trading_day_matches",
                "md_identity_qualified",
            )
        sink[keys[0]] = capture_status
        if facts is None:
            sink[keys[1]] = capture_status
            sink[keys[2]] = None
            sink[keys[3]] = None
            sink[keys[4]] = None
            sink[keys[5]] = None
            sink[keys[6]] = False
            return
        sink[keys[1]] = facts["status"]
        sink[keys[2]] = facts["observation_present"]
        sink[keys[3]] = facts["identity_matches_bound"]
        sink[keys[4]] = facts["source_generation_matches"]
        sink[keys[5]] = facts["trading_day_matches"]
        sink[keys[6]] = facts["identity_qualified"] is True

    def observe_md_identity(store, *, phase):
        """Read the bound Store's exact redacted six-field MD projection."""
        if store is None:
            publish_md_identity(phase, "STORE_UNAVAILABLE")
            return
        if phase == "post_source" and held["query_store"] is not store:
            publish_md_identity(phase, "QUERY_STORE_MISMATCH")
            return
        try:
            module = sys.modules.get("backtrader.stores.registered_sim")
            store_type = getattr(module, "RegisteredSimStore", None)
            method_function = getattr(store_type, "registered_sim_md_identity_facts", None)
            method = getattr(store, "registered_sim_md_identity_facts", None)
            if (
                store_type is None
                or not isinstance(store, store_type)
                or not callable(method)
                or getattr(method, "__self__", None) is not store
                or getattr(method, "__func__", None) is not method_function
                or getattr(method_function, "__code__", None) is None
                or getattr(method, "__code__", None) is not method_function.__code__
            ):
                publish_md_identity(phase, "METHOD_BINDING_UNAVAILABLE")
                return
            facts = _sanitize_md_facts(method())
            if facts is None:
                publish_md_identity(phase, "INVALID_FACTS")
                return
            publish_md_identity(phase, "OBSERVED", facts)
        except BaseException:
            publish_md_identity(phase, "OBSERVATION_READ_FAILED")

    def record_pre_source_md(frame, returned_value):
        if frame.f_code.co_name != "registered_sim_login_facts":
            return
        if held["pre_source_capture_count"]:
            return
        caller = frame.f_back
        store = frame.f_locals.get("self")
        module = sys.modules.get("backtrader.stores.registered_sim")
        store_type = getattr(module, "RegisteredSimStore", None)
        login_function = getattr(store_type, "registered_sim_login_facts", None)
        if (
            store_type is None
            or not isinstance(store, store_type)
            or getattr(login_function, "__code__", None) is not frame.f_code
            or caller is None
            or caller.f_code is not live_code
            or caller.f_locals.get("store") is not store
        ):
            publish_md_identity("pre_source", "PRE_SOURCE_BINDING_UNAVAILABLE")
            return
        if held["pre_source_capture_count"] or held["query_builder_entered"]:
            return
        if type(returned_value) is not dict or set(returned_value) != {
            "front_id",
            "session_id",
            "trading_day",
            "connection_generation",
            "read_only_ready",
            "trading_ready",
        }:
            publish_md_identity("pre_source", "LOGIN_FACTS_RETURN_INVALID")
            return
        held["pre_source_capture_count"] = 1
        observe_md_identity(store, phase="pre_source")

    def capture(frame, event, _arg):
        if event == "return":
            record_pre_source_md(frame, _arg)
            record_query_return(frame, _arg)
            return
        if event != "call":
            return
        if frame.f_code is query_builder_code:
            caller = frame.f_back
            if (
                caller is not None
                and caller.f_code is live_code
                and caller.f_locals.get("store") is frame.f_locals.get("store")
            ):
                held["query_builder_entered"] = True
        caller = frame.f_back
        if (
            frame.f_code is not cerebro_code
            and frame.f_code.co_name == "run"
            and caller is not None
            and caller.f_code is live_code
        ):
            fail_capture("I51_CEREBRO_CODE_MISMATCH")
        if frame.f_code is not cerebro_code:
            return
        held["capture_count"] += 1
        if held["capture_count"] != 1:
            fail_capture("I51_CEREBRO_CALL_COUNT_INVALID")
        if caller is None or caller.f_code is not live_code:
            # Preserve any visible runner-owned references for an uncertain
            # unwind, but never schedule a timer against a mismatched frame.
            cursor = caller
            while cursor is not None and cursor.f_code is not live_code:
                cursor = cursor.f_back
            if cursor is not None:
                held["loop"] = cursor.f_locals.get("refresh_loop")
            held["cerebro"] = frame.f_locals.get("self")
            fail_capture("I51_CEREBRO_CALLER_BINDING_MISMATCH")

        cerebro = frame.f_locals.get("self")
        broker = getattr(cerebro, "_broker", None)
        store = getattr(broker, "store", None)
        loop = caller.f_locals.get("refresh_loop")
        bound_method = getattr(loop, "request_shutdown", None)
        try:
            loop_valid = (
                type(loop) is loop_type
                and getattr(loop, "started", None) is True
                and getattr(loop, "joined", None) is False
                and getattr(bound_method, "__self__", None) is loop
                and getattr(bound_method, "__func__", None) is request_function
                and getattr(request_function, "__code__", None) is request_code
                and getattr(bound_method, "__code__", None) is request_code
            )
        except BaseException:
            loop_valid = False
        if type(cerebro) is not cerebro_type or broker is None or store is None:
            held["cerebro"] = cerebro
            held["loop"] = loop
            fail_capture("I51_BROKER_STORE_BINDING_UNAVAILABLE")
        if not loop_valid:
            held["cerebro"] = cerebro
            held["broker"] = broker
            held["store"] = store
            held["loop"] = loop
            fail_capture("I51_REFRESH_LOOP_BINDING_INVALID")

        # Stop profiling before calling the observer or starting its timer.
        sys.setprofile(previous_profile)
        held.update(
            status="CAPTURED",
            cerebro=cerebro,
            broker=broker,
            store=store,
            loop=loop,
            request_method=bound_method,
        )
        sink.update(
            status="CAPTURED",
            capture_count=1,
            loop_bound=True,
            query_store_matches_cerebro=held["query_store"] is store,
        )
        try:
            token, before = observer.begin_observation(broker, store)
            held.update(
                observer_token=token,
                observer_before=before,
                observer_started=True,
            )
            sink["observer_begin_ok"] = True
        except BaseException as error:
            held["status"] = "OBSERVER_BEGIN_FAILED"
            held["observer_error"] = error
            sink["status"] = "OBSERVER_BEGIN_FAILED"
            raise RuntimeError("I51_OBSERVER_BEGIN_FAILED") from None

        delay = max(0.0, (deadline - datetime.datetime.now(datetime.timezone.utc)).total_seconds())
        timer = threading.Timer(delay, request_once)
        timer.daemon = True
        held["timer"] = timer
        try:
            timer.start()
            held["timer_started"] = True
            sink["timer_started"] = True
        except BaseException as error:
            held["status"] = "TIMER_START_FAILED"
            held["timer_error"] = error
            sink["status"] = "TIMER_START_FAILED"
            raise RuntimeError("I51_TIMER_START_FAILED") from None
        observe_md_identity(store, phase="post_source")

    sink["status"] = "ARMED"
    result = None
    primary_error = None
    primary_traceback = None
    returned = False
    cleanup_ok = False
    timer_joined = True
    controlled = False
    try:
        sys.setprofile(capture)
        try:
            result = run_live(*args, **kwargs)
            returned = True
        except BaseException as error:
            primary_error = error
            primary_traceback = error.__traceback__
            _retain_visible_runner_locals(error, live_code, held)
    finally:
        try:
            sys.setprofile(previous_profile)
        except BaseException:
            held["profile_restore_failed"] = True

        timer = held["timer"]
        if timer is not None:
            try:
                timer.cancel()
            except BaseException:
                held["timer_error"] = held["timer_error"] or "CANCEL_FAILED"
            try:
                if timer.ident is not None:
                    timer.join(timeout=_JOIN_TIMEOUT_SECONDS)
                    timer_joined = not timer.is_alive()
                else:
                    timer_joined = not timer.is_alive()
            except BaseException:
                timer_joined = False
        sink["timer_joined"] = timer_joined
        sink["timer_fired"] = held["timer_fired"]
        sink["request_count"] = held["request_count"]
        sink["request_returned"] = held["request_returned"]
        sink["request_failed"] = held["request_error"] is not None
        sink["timer_failed"] = held["timer_error"] is not None

        if held["observer_started"]:
            try:
                after = observer.finish_observation(
                    held["observer_token"], held["broker"], held["store"]
                )
                held["observer_after"] = after
                held["observer_finished"] = True
                if type(after) is dict:
                    held["write_zero"] = all(
                        after.get(key) is True
                        for key in (
                            "same_objects",
                            "observations_complete",
                            "zero_baseline",
                            "zero_after",
                            "zero_write_activity",
                        )
                    )
                sink["observer_finish_ok"] = True
                sink["write_zero_confirmed"] = held["write_zero"] is True
            except BaseException as error:
                held["status"] = "OBSERVER_FINISH_FAILED"
                held["observer_error"] = error
                sink["status"] = "OBSERVER_FINISH_FAILED"

        cleanup_ok = _cleanup_confirmed(run_live, result if returned else primary_error, returned=returned)
        sink["cleanup_confirmed"] = cleanup_ok
        sink["profile_restore_failed"] = held["profile_restore_failed"]
        if returned and type(result) is dict:
            controlled = _controlled_stop(run_live, result)
        sink["controlled_stop"] = controlled

        if not timer_joined or not cleanup_ok:
            retained = dict(held)
            retained.update(
                result=result,
                primary_error=primary_error,
                primary_traceback=primary_traceback,
            )
            with _RETAIN_LOCK:
                _RETAINED.append(retained)
            held["status"] = "RETAINED_UNCERTAIN_CUSTODY"
            sink["status"] = "RETAINED_UNCERTAIN_CUSTODY"
        elif held["capture_error"] is not None:
            sink["status"] = held["capture_error"]
        elif held["observer_error"] is not None:
            sink["status"] = (
                "OBSERVER_FINISH_FAILED"
                if held["observer_finished"] is False and held["observer_started"]
                else "OBSERVER_BEGIN_FAILED"
            )
        elif held["timer_error"] is not None:
            sink["status"] = "TIMER_FAILED"
        elif held["profile_restore_failed"]:
            sink["status"] = "PROFILE_RESTORE_FAILED"
        elif primary_error is not None:
            held["status"] = "RUN_LIVE_FAILED"
            sink["status"] = "RUN_LIVE_FAILED"
        elif held["request_error"] is not None:
            sink["status"] = "SHUTDOWN_REQUEST_FAILED"
        elif not held["timer_started"]:
            sink["status"] = "TIMER_NOT_STARTED"
        elif held["request_count"] != 1 or not held["request_returned"]:
            sink["status"] = "SHUTDOWN_REQUEST_NOT_CONFIRMED"
        elif not controlled:
            sink["status"] = "CONTROLLED_STOP_UNPROVEN"
        elif held["write_zero"] is not True:
            sink["status"] = "WRITE_OBSERVATION_UNPROVEN"
        else:
            held["status"] = "FINISHED"
            sink["status"] = "FINISHED"

    if primary_error is not None:
        raise primary_error.with_traceback(primary_traceback)
    if sink["status"] != "FINISHED":
        raise RuntimeError(sink["status"])
    return result
