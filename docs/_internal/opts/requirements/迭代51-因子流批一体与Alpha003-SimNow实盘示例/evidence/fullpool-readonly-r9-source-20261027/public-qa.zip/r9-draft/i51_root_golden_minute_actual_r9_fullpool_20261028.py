import ctypes
import hashlib
import json
import logging
import os
import sys
import tempfile
import time
import warnings
from contextlib import ExitStack
from datetime import datetime, timedelta, timezone
from pathlib import Path

EXAMPLE = Path('D:\\source_code\\backtrader\\examples\\unified\\028_alpha003_simnow_minute')
CONSUMER = Path('D:\\temp\\i51-final-source-consumer-20261027-r3\\consumer\\Lib\\site-packages')
PROFILE = Path('D:\\source_code\\backtrader\\.codex-tmp\\i51_golden_fullpool_profile_r9_20261028.json')
WRITE_OBSERVER = Path('D:\\source_code\\backtrader\\.codex-tmp\\i51_root_readonly_write_observation_20261027.py')
SPAN_HELPER = Path('D:\\source_code\\backtrader\\.codex-tmp\\i51_root_golden_minute_span_r4_20261027.py')
POSTFLIGHT_HELPER = Path('D:\\source_code\\backtrader\\.codex-tmp\\i51_fullpool_golden_postflight_r9_20261027.py')
SAVED_TAPE_VALIDATOR = Path('D:\\source_code\\backtrader\\scripts\\validate_iteration51_saved_factor_tape.py')
RUN_ROOT = Path('D:/temp/i51-golden-minute-readonly-20261028-r9-fullpool')
PRIVATE_TEMP = Path('D:/temp/i51-root-golden-private-20261028-r9-fullpool')
OUTPUT = Path('D:/temp/i51-root-golden-minute-readonly-20261028-r9-fullpool.json')
BT_RECORD = CONSUMER / 'back_trader_python-1.4.0.dist-info/RECORD'
BT_RECORD_SHA = '5975a32820cbfab85145ffd865f805199dac082f3d7f9c66976e234607c4e14f'
SDK_RECORD = CONSUMER / 'bt_api_ctp-2.0.4+iteration41.i9.dist-info/RECORD'
SDK_RECORD_SHA = 'cb2c2f3501a447ab34c403f35e2a000e53d9c6ba04b88b822a23682d54b9006a'
ROOT_STATE = {}

DRAFT_UNEXECUTABLE = True
EXPECTED_DEV_HEAD = 'ROOT_MUST_BIND_ACCEPTED_R9_HEAD'
# Root binds this value against the accepted dev HEAD outside the protected caller.
PUBLIC_RUNNER_ERROR_CODES = frozenset(('ALLOW_WRITE_REQUIRES_LIVE_MODE', 'ALPHA003_STRATEGY_API_PENDING', 'AUTHORIZED_PRODUCTS_INVALID', 'AUTHORIZED_PRODUCTS_OUTSIDE_POOL', 'COHORT_CTP_TRADING_DAY_OPTION_INVALID', 'COHORT_EPOCH_INVALID', 'COHORT_HAS_NO_PLANNED_SLOTS', 'COHORT_MEMBER_SESSION_API_REQUIRED', 'COHORT_TRADING_DAY_INVALID', 'CONFIG_FIELDS_INVALID', 'CONFIG_FILE_UNAVAILABLE', 'CONFIG_MODE_INVALID', 'CONFIG_SCHEMA_UNSUPPORTED', 'CONFIG_SECTION_FIELDS_INVALID', 'CONFIG_YAML_INVALID', 'CTP_FUTURES_PRODUCT_POOL_UNAVAILABLE', 'CTP_FUTURES_SNAPSHOT_BRIDGE_UNAVAILABLE', 'CTP_FUTURES_SNAPSHOT_COLLECTION_FAILED', 'CTP_FUTURES_SNAPSHOT_ID_UNAVAILABLE', 'CTP_FUTURES_SNAPSHOT_TYPE_INVALID', 'CTP_FUTURES_TRADING_DAY_UNAVAILABLE', 'CTP_QUERY_PLAN_BUILD_FAILED', 'CTP_QUERY_SELECTION_NOT_CONFIGURED', 'DAILY_EPOCH_RETIREMENT_UNPROVEN', 'DAILY_ROLLOVER_CLOSE_ALL_POLICY_REQUIRED', 'DAILY_ROLLOVER_LIVE_MODE_REQUIRED', 'DAILY_ROLLOVER_LIVE_TIER_REQUIRED', 'DAILY_SELECTION_AUTHORIZED_POOL_CHANGED', 'DAILY_SELECTION_BUNDLES_INVALID', 'DAILY_SELECTION_BUNDLE_DUPLICATE', 'DAILY_SELECTION_DECISION_TIME_NOT_ADVANCED', 'DAILY_SELECTION_EXCHANGE_SET_CHANGED', 'DAILY_SELECTION_POLICY_CHANGED', 'DAILY_SELECTION_PRODUCT_POOL_CHANGED', 'DAILY_SELECTION_TRADING_DAY_NOT_ADVANCED', 'DAILY_SELECTION_TRADING_DAY_SET_CHANGED', 'DECISION_TAPE_BATCH_SNAPSHOT_MISMATCH', 'DECISION_TAPE_BYTE_BUDGET_EXCEEDED', 'DECISION_TAPE_BYTE_BUDGET_INVALID', 'DECISION_TAPE_CLOSE_FAILED', 'DECISION_TAPE_CREATE_FAILED', 'DECISION_TAPE_FACTOR_SNAPSHOT_INVALID', 'DECISION_TAPE_FACTOR_TARGET_SET_INVALID', 'DECISION_TAPE_GRID_COVERAGE_MISMATCH', 'DECISION_TAPE_HEADER_BINDING_MISMATCH', 'DECISION_TAPE_HEADER_BINDING_REQUIRED', 'DECISION_TAPE_HEADER_INVALID', 'DECISION_TAPE_HEADER_MISSING', 'DECISION_TAPE_MEMBER_SET_INVALID', 'DECISION_TAPE_MODE_INVALID', 'DECISION_TAPE_PROFILE_REQUIRED', 'DECISION_TAPE_RAW_FIELDS_INVALID', 'DECISION_TAPE_READBACK_MISMATCH', 'DECISION_TAPE_READ_FAILED', 'DECISION_TAPE_RECEIPT_INVALID', 'DECISION_TAPE_RECORD_HASH_INVALID', 'DECISION_TAPE_RECORD_INVALID', 'DECISION_TAPE_SELECTION_EVIDENCE_MISMATCH', 'DECISION_TAPE_TARGETS_INVALID', 'DECISION_TAPE_UNAVAILABLE', 'DECISION_TAPE_VALUE_INVALID', 'DECISION_TAPE_WRITE_FAILED', 'ENTRY_TIER_ESCALATION_DENIED', 'ENTRY_TIER_INVALID', 'FACTOR_DIRECTION_INVALID', 'FACTOR_MODE_INVALID', 'FACTOR_WINDOW_INVALID', 'FINCORE_FLAG_INVALID', 'GOLDEN_AUTHORIZED_TARGETS_EMPTY', 'GOLDEN_TARGETS_COUNT_INVALID', 'GOLDEN_TARGETS_DUPLICATE', 'GOLDEN_TARGETS_EMPTY', 'GOLDEN_TARGETS_FULL_SELECTION_INVALID', 'GOLDEN_TARGETS_FULL_SELECTION_NOT_READY', 'GOLDEN_TARGETS_GRID_BUILD_FAILED', 'GOLDEN_TARGETS_GRID_UNAVAILABLE', 'GOLDEN_TARGETS_INVALID', 'GOLDEN_TARGETS_LIVE_CTP_QUERY_REQUIRED', 'GOLDEN_TARGETS_OUTSIDE_SELECTED_POOL', 'GOLDEN_TARGETS_QUERY_PLAN_REQUIRED', 'GOLDEN_TARGETS_READ_ONLY_REQUIRED', 'GOLDEN_TARGETS_WRITE_CONFIGURATION_UNSUPPORTED', 'INPUT_DATE_INVALID', 'INPUT_DECIMAL_INVALID', 'INPUT_FIELDS_INVALID', 'INPUT_FILE_UNAVAILABLE', 'INPUT_JSON_INVALID', 'INPUT_NUMBER_INVALID', 'INPUT_OBJECT_REQUIRED', 'INPUT_PATH_REQUIRED', 'INPUT_TEXT_INVALID', 'INPUT_TIMESTAMP_INVALID', 'INPUT_TIMESTAMP_NAIVE', 'LIVE_ARM_TEMPLATES_INVALID', 'LIVE_ARM_TEMPLATE_DUPLICATE', 'LIVE_ARM_TEMPLATE_FIELDS_INVALID', 'LIVE_ARM_TEMPLATE_ROUTE_SET_MISMATCH', 'LIVE_ARM_TEMPLATE_TARGET_NOT_AUTHORIZED', 'LIVE_BAR_AGE_PROFILE_REQUIRED', 'LIVE_CANCEL_DISPATCHING_STORE_ABSENCE_PENDING', 'LIVE_COHORT_WAKE_API_UNAVAILABLE', 'LIVE_CORE_WINDDOWN_NOT_CONFIRMED', 'LIVE_CTP_READ_ONLY_STATE_UNAVAILABLE', 'LIVE_CTP_SESSION_NOT_READY', 'LIVE_CTP_STORE_UNAVAILABLE_FOR_FACTOR_SOURCE', 'LIVE_CTP_TRADING_DAY_UNAVAILABLE_FOR_FACTOR_SOURCE', 'LIVE_CTP_TRADING_STATE_UNAVAILABLE', 'LIVE_DATED_TRADE_RECONCILIATION_BLOCKED', 'LIVE_DATED_TRADE_RECONCILIATION_PAGE_INVALID', 'LIVE_EXECUTION_TARGETS_INVALID', 'LIVE_FEE_BUDGET_REQUIRED', 'LIVE_GRID_HAS_NO_REMAINING_COMMON_MINUTES', 'LIVE_HISTORY_AVAILABILITY_INVALID', 'LIVE_HISTORY_BATCH_ID_INVALID', 'LIVE_HISTORY_EPOCH_INVALID', 'LIVE_HISTORY_FRESH_SELECTION_REQUIRED', 'LIVE_HISTORY_GENERATION_CHANGED', 'LIVE_HISTORY_GRID_WINDOW_UNAVAILABLE', 'LIVE_HISTORY_HEADER_MISMATCH', 'LIVE_HISTORY_IDENTITY_INVALID', 'LIVE_HISTORY_IDENTITY_MISMATCH', 'LIVE_HISTORY_IDENTITY_REQUIRED', 'LIVE_HISTORY_JOURNAL_DECISION_ANCHOR_MISMATCH', 'LIVE_HISTORY_JOURNAL_HIGHWATER_MISMATCH', 'LIVE_HISTORY_LIVE_MODE_REQUIRED', 'LIVE_HISTORY_MEMBER_INVALID', 'LIVE_HISTORY_MEMBER_SET_INVALID', 'LIVE_HISTORY_MODE_MISMATCH', 'LIVE_HISTORY_OHLCV_INVALID', 'LIVE_HISTORY_ORDER_INVALID', 'LIVE_HISTORY_OUTSIDE_CURRENT_GRID', 'LIVE_HISTORY_PATH_CONFLICT', 'LIVE_HISTORY_RECORDS_MISSING', 'LIVE_HISTORY_RECORD_IDENTITY_INVALID', 'LIVE_HISTORY_SELECTION_EVIDENCE_INVALID', 'LIVE_HISTORY_SELECTION_MISMATCH', 'LIVE_HISTORY_SELECTION_UNSUPPORTED', 'LIVE_HISTORY_SEQUENCE_INVALID', 'LIVE_HISTORY_SESSION_CHANGED', 'LIVE_HISTORY_SLOT_IDENTITY_INVALID', 'LIVE_HISTORY_SLOT_SEQUENCE_INVALID', 'LIVE_HISTORY_SOURCE_ROLE_INVALID', 'LIVE_HISTORY_SOURCE_ROLE_ORDER_INVALID', 'LIVE_HISTORY_TAIL_NOT_LIVE', 'LIVE_HISTORY_WARMUP_INVALID', 'LIVE_HISTORY_WARMUP_NOT_CONTIGUOUS', 'LIVE_HISTORY_WARMUP_NOT_READY', 'LIVE_INITIAL_QUERY_REFRESH_FAILED', 'LIVE_INITIAL_QUERY_REFRESH_INCOMPLETE', 'LIVE_QUERY_REFRESH_DID_NOT_JOIN', 'LIVE_RECONCILIATION_BLOCKED', 'LIVE_RECONCILIATION_LIMIT_EXCEEDED', 'LIVE_RECONCILIATION_PAGE_INVALID', 'LIVE_RECOVERY_INTENT_SNAPSHOT_INVALID', 'LIVE_RECOVERY_INTENT_SNAPSHOT_UNAVAILABLE', 'LIVE_REFRESH_TARGETS_INVALID', 'LIVE_REFRESH_TARGETS_REQUIRED', 'LIVE_RESOURCE_CLEANUP_INCOMPLETE', 'LIVE_RISK_BUDGETS_REQUIRED', 'LIVE_SECTION_INVALID', 'LIVE_SELECTION_PLAN_REQUIRED', 'LIVE_SESSION_CHANGED_DURING_FACTOR_SOURCE_BINDING', 'LIVE_SESSION_CHANGED_DURING_SELECTION', 'LIVE_SHUTDOWN_NOT_CONFIRMED', 'LIVE_SHUTDOWN_SIGNAL_HANDLER_UNAVAILABLE', 'LIVE_STORE_CONFIG_ENV_INVALID', 'LIVE_STORE_CONFIG_ENV_MISSING', 'LIVE_STORE_CONFIG_FIELDS_INVALID', 'LIVE_STORE_CONFIG_INJECTION_DENIED', 'LIVE_STORE_CONFIG_OVERRIDE_REQUIRES_LIVE_MODE', 'LIVE_STRATEGY_BINDING_CONFLICT', 'LIVE_STRATEGY_POST_JOIN_RETIREMENT_NOT_CONFIRMED', 'LIVE_STRATEGY_SHUTDOWN_NOT_CONFIRMED', 'LIVE_TARGET_CAPACITY_EXCEEDED', 'LIVE_TIER_REQUIRED', 'LIVE_TRADE_RECONCILIATION_BLOCKED', 'LIVE_WRITE_FLAG_INVALID', 'LIVE_WRITE_GRANT_MISSING_IN_CONFIG', 'LIVE_ZERO_LOGIN_RESPONSE_READ_ONLY', 'LIVE_WRITE_TIER_REQUIRED', 'MINUTE_BAR_AVAILABILITY_INVALID', 'MINUTE_BAR_CLOCK_PROFILE_MISMATCH', 'MINUTE_BAR_FIELDS_INVALID', 'MINUTE_BAR_GENERATION_INVALID', 'MINUTE_BAR_ID_DUPLICATE', 'MINUTE_BAR_INCOMPLETE', 'MINUTE_BAR_NOT_PRESENT', 'MINUTE_BAR_OHLC_INVALID', 'MINUTE_BAR_OUTSIDE_PLANNED_GRID', 'MINUTE_BAR_PLANNED_MEMBER_MISSING', 'MINUTE_BAR_PRICE_INVALID', 'MINUTE_BAR_QUALITY_BLOCKED', 'MINUTE_BAR_ROUTE_MISMATCH', 'MINUTE_BAR_SEQUENCE_INVALID', 'MINUTE_BAR_SEQUENCE_NOT_INCREASING', 'MINUTE_BAR_SESSION_MISMATCH', 'MINUTE_BAR_TARGET_OUTSIDE_POOL', 'MINUTE_BAR_TIMESTAMP_MISMATCH', 'MINUTE_TAPE_BARS_REQUIRED', 'MINUTE_TAPE_FIELDS_INVALID', 'MINUTE_TAPE_PRICE_BASIS_MISMATCH', 'MINUTE_TAPE_PRICE_BASIS_UNSPECIFIED', 'MINUTE_TAPE_SCHEMA_UNSUPPORTED', 'MINUTE_TAPE_SOURCE_ORDER_INVALID', 'MINUTE_TAPE_TIMEZONE_MISMATCH', 'OFFLINE_MODE_REQUIRES_SAVED_SELECTION_BUNDLE', 'PLANNED_GRID_DUPLICATE_CLOSE', 'PLANNED_GRID_RECORD_INVALID', 'PLANNED_MINUTE_GRID_BLOCKED', 'POINT_IN_TIME_ROUTE_SET_MISMATCH', 'POINT_IN_TIME_SELECTION_BLOCKED', 'POINT_IN_TIME_TRADING_DAY_SET_MISMATCH', 'QUERY_SELECTION_DAILY_BUNDLES_UNSUPPORTED', 'QUERY_SELECTION_LIVE_TIER_REQUIRED', 'QUOTE_AVAILABILITY_INVALID', 'QUOTE_CROSSED', 'QUOTE_FIELDS_INVALID', 'QUOTE_ID_DUPLICATE', 'QUOTE_ROUTE_MISMATCH', 'QUOTE_TAPE_FIELDS_INVALID', 'QUOTE_TAPE_ROWS_REQUIRED', 'QUOTE_TAPE_SCHEMA_UNSUPPORTED', 'REGISTERED_SIM_STORE_CONTRACT_INVALID', 'REPLAY_INSTRUMENT_FIELDS_INVALID', 'REPLAY_METADATA_AVAILABILITY_MISMATCH', 'REPLAY_METADATA_FIELDS_INVALID', 'REPLAY_METADATA_ROUTE_MISMATCH', 'REPLAY_METADATA_ROWS_INVALID', 'REPLAY_METADATA_SCHEMA_UNSUPPORTED', 'REPLAY_METADATA_TARGET_SET_MISMATCH', 'REPLAY_PERMISSION_INVALID', 'REPLAY_PRICE_LIMITS_INVALID', 'REPLAY_RISK_BUDGETS_REQUIRED', 'REPLAY_TAPE_NOT_FULL_GRID', 'REPLAY_TIER_REQUIRED', 'RESEARCH_ENDPOINTS_OUTSIDE_PLANNED_GRID', 'RESEARCH_ENDPOINTS_REQUIRED', 'RISK_POLICY_INVALID', 'SAVED_SELECTION_BUNDLE_REQUIRED', 'SELECTION_EVIDENCE_AUTHORIZED_TARGETS_INVALID', 'SELECTION_EVIDENCE_BYTE_BUDGET_EXCEEDED', 'SELECTION_EVIDENCE_BYTE_BUDGET_INVALID', 'SELECTION_EVIDENCE_EPOCH_INVALID', 'SELECTION_EVIDENCE_GRID_INVALID', 'SELECTION_EVIDENCE_GRID_UNAVAILABLE', 'SELECTION_EVIDENCE_MANIFEST_UNAVAILABLE', 'SELECTION_EVIDENCE_SERIALIZATION_FAILED', 'SELECTION_MAX_EPOCHS_INVALID', 'SELECTION_SOURCE_INVALID', 'SESSION_CALENDAR_DUPLICATE_EXCHANGE', 'SESSION_CALENDAR_REQUIRED', 'SESSION_CALENDAR_SCHEMA_REQUIRED', 'SESSION_CALENDAR_SET_MISMATCH'))
PUBLIC_RUNNER_ERROR_CODES = PUBLIC_RUNNER_ERROR_CODES | frozenset(('CTP_FUTURES_QUERY_MODE_MISMATCH', 'CTP_FUTURES_QUERY_SET_UNAVAILABLE'))
PUBLIC_RUNNER_ERROR_CODES = PUBLIC_RUNNER_ERROR_CODES | frozenset(('ALLOW_WRITE_REQUIRES_LIVE_MODE', 'ALPHA003_STRATEGY_API_PENDING', 'AUTHORIZED_PRODUCTS_INVALID', 'AUTHORIZED_PRODUCTS_OUTSIDE_POOL', 'COHORT_CALENDAR_OVERRIDE_IDENTITY_INVALID', 'COHORT_CALENDAR_OVERRIDE_INVALID', 'COHORT_CTP_TRADING_DAY_OPTION_INVALID', 'COHORT_EPOCH_INVALID', 'COHORT_HAS_NO_PLANNED_SLOTS', 'COHORT_MEMBER_SESSION_API_REQUIRED', 'COHORT_TRADING_DAY_INVALID', 'CONFIG_FIELDS_INVALID', 'CONFIG_FILE_UNAVAILABLE', 'CONFIG_MODE_INVALID', 'CONFIG_SCHEMA_UNSUPPORTED', 'CONFIG_SECTION_FIELDS_INVALID', 'CONFIG_YAML_INVALID', 'CTP_FUTURES_PRODUCT_POOL_UNAVAILABLE', 'CTP_FUTURES_QUERY_MODE_MISMATCH', 'CTP_FUTURES_QUERY_SET_UNAVAILABLE', 'CTP_FUTURES_SNAPSHOT_BRIDGE_UNAVAILABLE', 'CTP_FUTURES_SNAPSHOT_COLLECTION_FAILED', 'CTP_FUTURES_SNAPSHOT_ID_UNAVAILABLE', 'CTP_FUTURES_SNAPSHOT_TYPE_INVALID', 'CTP_FUTURES_TRADING_DAY_UNAVAILABLE', 'CTP_QUERY_PLAN_BUILD_FAILED', 'CTP_QUERY_SELECTION_NOT_CONFIGURED', 'DAILY_EPOCH_RETIREMENT_UNPROVEN', 'DAILY_ROLLOVER_CLOSE_ALL_POLICY_REQUIRED', 'DAILY_ROLLOVER_LIVE_MODE_REQUIRED', 'DAILY_ROLLOVER_LIVE_TIER_REQUIRED', 'DAILY_SELECTION_AUTHORIZED_POOL_CHANGED', 'DAILY_SELECTION_BUNDLES_INVALID', 'DAILY_SELECTION_BUNDLE_DUPLICATE', 'DAILY_SELECTION_DECISION_TIME_NOT_ADVANCED', 'DAILY_SELECTION_EXCHANGE_SET_CHANGED', 'DAILY_SELECTION_POLICY_CHANGED', 'DAILY_SELECTION_PRODUCT_POOL_CHANGED', 'DAILY_SELECTION_TRADING_DAY_NOT_ADVANCED', 'DAILY_SELECTION_TRADING_DAY_SET_CHANGED', 'DECISION_TAPE_BATCH_SNAPSHOT_MISMATCH', 'DECISION_TAPE_BYTE_BUDGET_EXCEEDED', 'DECISION_TAPE_BYTE_BUDGET_INVALID', 'DECISION_TAPE_CALENDAR_FINGERPRINT_INVALID', 'DECISION_TAPE_CLOSE_FAILED', 'DECISION_TAPE_CREATE_FAILED', 'DECISION_TAPE_FACTOR_SNAPSHOT_INVALID', 'DECISION_TAPE_FACTOR_TARGET_SET_INVALID', 'DECISION_TAPE_GRID_COVERAGE_MISMATCH', 'DECISION_TAPE_HEADER_BINDING_MISMATCH', 'DECISION_TAPE_HEADER_BINDING_REQUIRED', 'DECISION_TAPE_HEADER_INVALID', 'DECISION_TAPE_HEADER_MISSING', 'DECISION_TAPE_MEMBER_SET_INVALID', 'DECISION_TAPE_MODE_INVALID', 'DECISION_TAPE_PROFILE_REQUIRED', 'DECISION_TAPE_RAW_FIELDS_INVALID', 'DECISION_TAPE_READBACK_MISMATCH', 'DECISION_TAPE_READ_FAILED', 'DECISION_TAPE_RECEIPT_INVALID', 'DECISION_TAPE_RECORD_HASH_INVALID', 'DECISION_TAPE_RECORD_INVALID', 'DECISION_TAPE_SELECTION_EVIDENCE_MISMATCH', 'DECISION_TAPE_TARGETS_INVALID', 'DECISION_TAPE_UNAVAILABLE', 'DECISION_TAPE_VALUE_INVALID', 'DECISION_TAPE_WRITE_FAILED', 'ENTRY_TIER_ESCALATION_DENIED', 'ENTRY_TIER_INVALID', 'FACTOR_DIRECTION_INVALID', 'FACTOR_MODE_INVALID', 'FACTOR_WINDOW_INVALID', 'FINCORE_FLAG_INVALID', 'GOLDEN_AUTHORIZED_TARGETS_EMPTY', 'GOLDEN_TARGETS_COUNT_INVALID', 'GOLDEN_TARGETS_DUPLICATE', 'GOLDEN_TARGETS_EMPTY', 'GOLDEN_TARGETS_FULL_SELECTION_INVALID', 'GOLDEN_TARGETS_FULL_SELECTION_NOT_READY', 'GOLDEN_TARGETS_GRID_BUILD_FAILED', 'GOLDEN_TARGETS_GRID_UNAVAILABLE', 'GOLDEN_TARGETS_INVALID', 'GOLDEN_TARGETS_LIVE_CTP_QUERY_REQUIRED', 'GOLDEN_TARGETS_OUTSIDE_SELECTED_POOL', 'GOLDEN_TARGETS_QUERY_PLAN_REQUIRED', 'GOLDEN_TARGETS_READ_ONLY_REQUIRED', 'GOLDEN_TARGETS_WRITE_CONFIGURATION_UNSUPPORTED', 'INPUT_DATE_INVALID', 'INPUT_DECIMAL_INVALID', 'INPUT_FIELDS_INVALID', 'INPUT_FILE_UNAVAILABLE', 'INPUT_JSON_INVALID', 'INPUT_NUMBER_INVALID', 'INPUT_OBJECT_REQUIRED', 'INPUT_PATH_REQUIRED', 'INPUT_TEXT_INVALID', 'INPUT_TIMESTAMP_INVALID', 'INPUT_TIMESTAMP_NAIVE', 'LIVE_ARM_TEMPLATES_INVALID', 'LIVE_ARM_TEMPLATE_DUPLICATE', 'LIVE_ARM_TEMPLATE_FIELDS_INVALID', 'LIVE_ARM_TEMPLATE_ROUTE_SET_MISMATCH', 'LIVE_ARM_TEMPLATE_TARGET_NOT_AUTHORIZED', 'LIVE_BAR_AGE_PROFILE_REQUIRED', 'LIVE_CANCEL_DISPATCHING_STORE_ABSENCE_PENDING', 'LIVE_COHORT_WAKE_API_UNAVAILABLE', 'LIVE_CORE_WINDDOWN_NOT_CONFIRMED', 'LIVE_CTP_READ_ONLY_STATE_UNAVAILABLE', 'LIVE_CTP_SESSION_NOT_READY', 'LIVE_CTP_STORE_UNAVAILABLE_FOR_FACTOR_SOURCE', 'LIVE_CTP_TRADING_DAY_UNAVAILABLE_FOR_FACTOR_SOURCE', 'LIVE_CTP_TRADING_STATE_UNAVAILABLE', 'LIVE_DATED_TRADE_RECONCILIATION_BLOCKED', 'LIVE_DATED_TRADE_RECONCILIATION_PAGE_INVALID', 'LIVE_EXECUTION_TARGETS_INVALID', 'LIVE_FEE_BUDGET_REQUIRED', 'LIVE_GRID_HAS_NO_REMAINING_COMMON_MINUTES', 'LIVE_HISTORY_AVAILABILITY_INVALID', 'LIVE_HISTORY_BATCH_ID_INVALID', 'LIVE_HISTORY_EPOCH_INVALID', 'LIVE_HISTORY_FRESH_SELECTION_REQUIRED', 'LIVE_HISTORY_GENERATION_CHANGED', 'LIVE_HISTORY_GRID_WINDOW_UNAVAILABLE', 'LIVE_HISTORY_HEADER_CALENDAR_FINGERPRINT_INVALID', 'LIVE_HISTORY_HEADER_MISMATCH', 'LIVE_HISTORY_IDENTITY_INVALID', 'LIVE_HISTORY_IDENTITY_MISMATCH', 'LIVE_HISTORY_IDENTITY_REQUIRED', 'LIVE_HISTORY_JOURNAL_DECISION_ANCHOR_MISMATCH', 'LIVE_HISTORY_JOURNAL_HIGHWATER_MISMATCH', 'LIVE_HISTORY_LIVE_MODE_REQUIRED', 'LIVE_HISTORY_MEMBER_INVALID', 'LIVE_HISTORY_MEMBER_SET_INVALID', 'LIVE_HISTORY_MODE_MISMATCH', 'LIVE_HISTORY_OHLCV_INVALID', 'LIVE_HISTORY_ORDER_INVALID', 'LIVE_HISTORY_OUTSIDE_CURRENT_GRID', 'LIVE_HISTORY_PATH_CONFLICT', 'LIVE_HISTORY_RECORDS_MISSING', 'LIVE_HISTORY_RECORD_IDENTITY_INVALID', 'LIVE_HISTORY_RESTART_CALENDAR_ORDER_INVALID', 'LIVE_HISTORY_RESTART_CALENDAR_UNAVAILABLE', 'LIVE_HISTORY_RESTART_GAP_INVALID', 'LIVE_HISTORY_SELECTION_EVIDENCE_INVALID', 'LIVE_HISTORY_SELECTION_MISMATCH', 'LIVE_HISTORY_SELECTION_UNSUPPORTED', 'LIVE_HISTORY_SEQUENCE_INVALID', 'LIVE_HISTORY_SESSION_CHANGED', 'LIVE_HISTORY_SLOT_IDENTITY_INVALID', 'LIVE_HISTORY_SLOT_SEQUENCE_INVALID', 'LIVE_HISTORY_SOURCE_HIGHWATER_MISMATCH', 'LIVE_HISTORY_SOURCE_HIGHWATER_MISSING', 'LIVE_HISTORY_SOURCE_JOURNAL_REQUIRED', 'LIVE_HISTORY_SOURCE_RECEIPT_MISMATCH', 'LIVE_HISTORY_SOURCE_ROLE_INVALID', 'LIVE_HISTORY_SOURCE_ROLE_ORDER_INVALID', 'LIVE_HISTORY_TAIL_NOT_RESTORABLE', 'LIVE_HISTORY_TAPE_REQUIRED_FOR_SOURCE_HIGHWATER', 'LIVE_HISTORY_WARMUP_INVALID', 'LIVE_HISTORY_WARMUP_NOT_CONTIGUOUS', 'LIVE_INITIAL_QUERY_REFRESH_FAILED', 'LIVE_INITIAL_QUERY_REFRESH_INCOMPLETE', 'LIVE_LEGACY_SOURCE_HIGHWATER_UNSUPPORTED', 'LIVE_QUERY_REFRESH_DID_NOT_JOIN', 'LIVE_RECONCILIATION_BLOCKED', 'LIVE_RECONCILIATION_LIMIT_EXCEEDED', 'LIVE_RECONCILIATION_PAGE_INVALID', 'LIVE_RECOVERY_INTENT_SNAPSHOT_INVALID', 'LIVE_RECOVERY_INTENT_SNAPSHOT_UNAVAILABLE', 'LIVE_REFRESH_TARGETS_INVALID', 'LIVE_REFRESH_TARGETS_REQUIRED', 'LIVE_RESOURCE_CLEANUP_INCOMPLETE', 'LIVE_RISK_BUDGETS_REQUIRED', 'LIVE_RUN_LOSS_POLICY_INVALID', 'LIVE_RUN_LOSS_POLICY_REQUIRED', 'LIVE_SECTION_INVALID', 'LIVE_SELECTION_PLAN_REQUIRED', 'LIVE_SESSION_CHANGED_DURING_FACTOR_SOURCE_BINDING', 'LIVE_SESSION_CHANGED_DURING_SELECTION', 'LIVE_SHUTDOWN_NOT_CONFIRMED', 'LIVE_SHUTDOWN_SIGNAL_HANDLER_UNAVAILABLE', 'LIVE_SOURCE_CONTINUITY_UNAVAILABLE', 'LIVE_SOURCE_TRADING_DAYS_INVALID', 'LIVE_SOURCE_TRADING_DAYS_UNAVAILABLE', 'LIVE_STORE_CONFIG_ENV_INVALID', 'LIVE_STORE_CONFIG_ENV_MISSING', 'LIVE_STORE_CONFIG_FIELDS_INVALID', 'LIVE_STORE_CONFIG_INJECTION_DENIED', 'LIVE_STORE_CONFIG_OVERRIDE_REQUIRES_LIVE_MODE', 'LIVE_STRATEGY_BINDING_CONFLICT', 'LIVE_STRATEGY_POST_JOIN_RETIREMENT_NOT_CONFIRMED', 'LIVE_STRATEGY_SHUTDOWN_NOT_CONFIRMED', 'LIVE_TARGET_CAPACITY_EXCEEDED', 'LIVE_TIER_REQUIRED', 'LIVE_TRADE_RECONCILIATION_BLOCKED', 'LIVE_WRITE_FLAG_INVALID', 'LIVE_WRITE_GRANT_MISSING_IN_CONFIG', 'LIVE_WRITE_TIER_REQUIRED', 'LIVE_ZERO_LOGIN_RESPONSE_READ_ONLY', 'MINUTE_BAR_AVAILABILITY_INVALID', 'MINUTE_BAR_CLOCK_PROFILE_MISMATCH', 'MINUTE_BAR_FIELDS_INVALID', 'MINUTE_BAR_GENERATION_INVALID', 'MINUTE_BAR_ID_DUPLICATE', 'MINUTE_BAR_INCOMPLETE', 'MINUTE_BAR_NOT_PRESENT', 'MINUTE_BAR_OHLC_INVALID', 'MINUTE_BAR_OUTSIDE_PLANNED_GRID', 'MINUTE_BAR_PLANNED_MEMBER_MISSING', 'MINUTE_BAR_PRICE_INVALID', 'MINUTE_BAR_QUALITY_BLOCKED', 'MINUTE_BAR_ROUTE_MISMATCH', 'MINUTE_BAR_SEQUENCE_INVALID', 'MINUTE_BAR_SEQUENCE_NOT_INCREASING', 'MINUTE_BAR_SESSION_MISMATCH', 'MINUTE_BAR_TARGET_OUTSIDE_POOL', 'MINUTE_BAR_TIMESTAMP_MISMATCH', 'MINUTE_TAPE_BARS_REQUIRED', 'MINUTE_TAPE_FIELDS_INVALID', 'MINUTE_TAPE_PRICE_BASIS_MISMATCH', 'MINUTE_TAPE_PRICE_BASIS_UNSPECIFIED', 'MINUTE_TAPE_SCHEMA_UNSUPPORTED', 'MINUTE_TAPE_SOURCE_ORDER_INVALID', 'MINUTE_TAPE_TIMEZONE_MISMATCH', 'OFFLINE_MODE_REQUIRES_SAVED_SELECTION_BUNDLE', 'PLANNED_GRID_DUPLICATE_CLOSE', 'PLANNED_GRID_RECORD_INVALID', 'PLANNED_MINUTE_GRID_BLOCKED', 'POINT_IN_TIME_ROUTE_SET_MISMATCH', 'POINT_IN_TIME_SELECTION_BLOCKED', 'POINT_IN_TIME_TRADING_DAY_SET_MISMATCH', 'QUERY_SELECTION_DAILY_BUNDLES_UNSUPPORTED', 'QUERY_SELECTION_LIVE_TIER_REQUIRED', 'QUOTE_AVAILABILITY_INVALID', 'QUOTE_CROSSED', 'QUOTE_FIELDS_INVALID', 'QUOTE_ID_DUPLICATE', 'QUOTE_ROUTE_MISMATCH', 'QUOTE_TAPE_FIELDS_INVALID', 'QUOTE_TAPE_ROWS_REQUIRED', 'QUOTE_TAPE_SCHEMA_UNSUPPORTED', 'REGISTERED_SIM_STORE_CONTRACT_INVALID', 'REPLAY_INSTRUMENT_FIELDS_INVALID', 'REPLAY_METADATA_AVAILABILITY_MISMATCH', 'REPLAY_METADATA_FIELDS_INVALID', 'REPLAY_METADATA_ROUTE_MISMATCH', 'REPLAY_METADATA_ROWS_INVALID', 'REPLAY_METADATA_SCHEMA_UNSUPPORTED', 'REPLAY_METADATA_TARGET_SET_MISMATCH', 'REPLAY_PERMISSION_INVALID', 'REPLAY_PRICE_LIMITS_INVALID', 'REPLAY_RISK_BUDGETS_REQUIRED', 'REPLAY_TAPE_NOT_FULL_GRID', 'REPLAY_TIER_REQUIRED', 'RESEARCH_ENDPOINTS_OUTSIDE_PLANNED_GRID', 'RESEARCH_ENDPOINTS_REQUIRED', 'RISK_POLICY_INVALID', 'SAVED_SELECTION_BUNDLE_REQUIRED', 'SELECTION_EVIDENCE_AUTHORIZED_TARGETS_INVALID', 'SELECTION_EVIDENCE_BYTE_BUDGET_EXCEEDED', 'SELECTION_EVIDENCE_BYTE_BUDGET_INVALID', 'SELECTION_EVIDENCE_EPOCH_INVALID', 'SELECTION_EVIDENCE_GRID_INVALID', 'SELECTION_EVIDENCE_GRID_UNAVAILABLE', 'SELECTION_EVIDENCE_MANIFEST_UNAVAILABLE', 'SELECTION_EVIDENCE_SERIALIZATION_FAILED', 'SELECTION_MAX_EPOCHS_INVALID', 'SELECTION_QUERY_MODE_INVALID', 'SELECTION_QUERY_MODE_REQUIRES_CTP_QUERY', 'SELECTION_SOURCE_INVALID', 'SESSION_CALENDAR_DUPLICATE_EXCHANGE', 'SESSION_CALENDAR_REQUIRED', 'SESSION_CALENDAR_SCHEMA_REQUIRED', 'SESSION_CALENDAR_SET_MISMATCH'))
PUBLIC_PINS = {'D:\\source_code\\backtrader\\examples\\unified\\028_alpha003_simnow_minute\\alpha003_strategy.py': '0ec9a612fdbd08033430ecb67924dd56e4272a48d0889c6169960e43ca11c9fe', 'D:\\source_code\\backtrader\\examples\\unified\\028_alpha003_simnow_minute\\discovery_lifecycle.py': '305ecf7cb89ccf8aee15179312fbf4b311f41ead7e65a97b01e19c0e3ccb3f3d', 'D:\\source_code\\backtrader\\examples\\unified\\028_alpha003_simnow_minute\\entry_tier.py': '230ab3ab1bb94313a186fef2bf181f1e1d80e769cd029832bab1614ea659c15e', 'D:\\source_code\\backtrader\\examples\\unified\\028_alpha003_simnow_minute\\protected_simnow.py': '88fef4e0ed6268dca4399e36e2ed42a7229ca73035c10726beea4856917eca60', 'D:\\source_code\\backtrader\\examples\\unified\\028_alpha003_simnow_minute\\run.py': 'ea2a21325f5f1e56fac3aed09f5a16bbc24fdccce754e8fe1ddc87bb3653619e', 'D:\\source_code\\backtrader\\.codex-tmp\\i51_root_readonly_write_observation_20261027.py': 'cf0c540c68ce23959e4d63d007ab1aae6b526710523b2d4be4cc313d4385ec59', 'D:\\source_code\\backtrader\\.codex-tmp\\i51_golden_minute_profile_r7_20261028.json': '20651d0e1d9abcc7d1bd1762fd6f5d1841f5dc79ee79f56519a8b96298b9172d', 'D:\\source_code\\backtrader\\.codex-tmp\\i51_root_golden_minute_span_r4_20261027.py': '59b475eb6e3bf63c8710e990b0e6d85e7a6767fbe953fd42b25f92d3dd837bb9', 'D:\\source_code\\backtrader\\.codex-tmp\\i51_golden_postflight_r1_20261027.py': 'd11859309e21991e04271c8bb19ad211a420926b33e6972622767b1176b53459', 'D:\\temp\\i51-final-source-consumer-20261027-r3\\consumer\\Lib\\site-packages\\bt_api_ctp\\ctp\\client.py': 'cd020b4ea3496a4e8c357a1fd58a5bba33a94784e65401963c0d605cb77be92b', 'D:\\temp\\i51-final-source-consumer-20261027-r3\\consumer\\Lib\\site-packages\\bt_api_ctp\\md_identity.py': 'f884b734fc719d015a58d351c47f493ef368aab54d5437b83e8dfb000d7a9f35'}


PUBLIC_PINS.update({
    str(PROFILE): 'c1da03a96911d85a951f2ac00cd94f1cf1fbe1a8752dd2efa9f22e2b9e7396c9',
    str(POSTFLIGHT_HELPER): '320e7fd9fc009a73e248d7f2fbbe2e3eb451235ebd641ec10883eeb49712e747',
    str(SAVED_TAPE_VALIDATOR): '7800089b42c54c2902873d69b95a867cc6849599b290fb780fa4756dedf4592d',
})


class NativeOutputMute:
    """Discard provider output, retaining no raw private capture."""
    def __init__(self):
        self.saved_fds = []
        self.saved_handles = []
        self.null_fd = None
        self.warning_scope = None
        self.prior_logging = logging.root.manager.disable
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.kernel.GetStdHandle.argtypes = [ctypes.c_ulong]
        self.kernel.GetStdHandle.restype = ctypes.c_void_p
        self.kernel.SetStdHandle.argtypes = [ctypes.c_ulong, ctypes.c_void_p]
        self.kernel.SetStdHandle.restype = ctypes.c_int

    def enter(self):
        import msvcrt
        sys.stdout.flush()
        sys.stderr.flush()
        try:
            self.null_fd = os.open(os.devnull, os.O_WRONLY)
            for number, handle_id in ((1, -11), (2, -12)):
                self.saved_fds.append((number, os.dup(number)))
                self.saved_handles.append((handle_id, self.kernel.GetStdHandle(handle_id)))
                os.dup2(self.null_fd, number)
                if not self.kernel.SetStdHandle(handle_id, msvcrt.get_osfhandle(self.null_fd)):
                    raise RuntimeError('OUTPUT_SUPPRESSION_FAILED')
            logging.disable(logging.CRITICAL)
            self.warning_scope = warnings.catch_warnings()
            self.warning_scope.__enter__()
            warnings.simplefilter('ignore')
        except BaseException:
            # No provider or private context exists yet; undo partial setup.
            self.close()
            raise

    def close(self):
        sys.stdout.flush()
        sys.stderr.flush()
        for handle_id, value in self.saved_handles:
            if not self.kernel.SetStdHandle(handle_id, value):
                raise RuntimeError('OUTPUT_RESTORE_FAILED')
        for number, saved in self.saved_fds:
            os.dup2(saved, number)
            os.close(saved)
        if self.null_fd is not None:
            os.close(self.null_fd)
        if self.warning_scope is not None:
            self.warning_scope.__exit__(None, None, None)
        logging.disable(self.prior_logging)

def verify_sources():
    if DRAFT_UNEXECUTABLE or EXPECTED_DEV_HEAD.startswith('ROOT_MUST_BIND_'):
        raise RuntimeError('ROOT_FINALIZATION_REQUIRED')
    if BT_RECORD_SHA.startswith('ROOT_MUST_BIND_') or SDK_RECORD_SHA.startswith('ROOT_MUST_BIND_'):
        raise RuntimeError('FRESH_INSTALLED_RECORDS_REQUIRED')
    for path, expected in PUBLIC_PINS.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise RuntimeError('PUBLIC_INPUT_CHANGED')
    if hashlib.sha256(BT_RECORD.read_bytes()).hexdigest() != BT_RECORD_SHA:
        raise RuntimeError('INSTALLED_RECORD_CHANGED')
    # This is also verified by the source-pinned protected handoff before
    # credential resolution, using its existing approved SDK artifact pin.
    if hashlib.sha256(SDK_RECORD.read_bytes()).hexdigest() != SDK_RECORD_SHA:
        raise RuntimeError('INSTALLED_SDK_RECORD_CHANGED')


def bounded_snapshot_failure_detail(detail, allowed_details):
    if type(detail) is str and type(allowed_details) is frozenset and detail in allowed_details:
        return detail
    if type(detail) is str and detail.startswith('INSTRUMENTS_') and detail.endswith('_QUERY_CALL_FAILED'):
        ordinal = detail[len('INSTRUMENTS_'):-len('_QUERY_CALL_FAILED')]
        if len(ordinal) == 3 and ordinal.isascii() and ordinal.isdigit() and 1 <= int(ordinal) <= 256:
            return detail
    return 'UNEXPECTED_COLLECTION_FAILURE'

def persist(result):
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')


def load_public_module(name, path):
    import importlib.util
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def public_cleanup(cleanup):
    allowed_resources = {'query_refresh', 'broker', 'store', 'journal', 'decision_tape'}
    allowed_states = {'PASS', 'FAIL', 'INCOMPLETE', 'UNPROVEN', 'NOT_CREATED', 'NOT_RUN',
                      'NOT_STARTED', 'RETURNED', 'CLOSED', 'CLOSED_BY_BROKER',
                      'OBSERVATION_ONLY', 'OBSERVATION_ONLY_NONFLAT',
                      'SKIPPED_REFRESH_UNJOINED', 'SKIPPED_BROKER_SHUTDOWN_UNPROVEN'}
    rows = []
    if not isinstance(cleanup, (list, tuple)):
        return rows
    for item in cleanup:
        if not isinstance(item, dict) or item.get('resource') not in allowed_resources:
            continue
        row = {'resource': item['resource']}
        for key in ('status', 'shutdown_state', 'store_shutdown_state'):
            value = item.get(key)
            row[key] = value if type(value) is str and value in allowed_states else None
        for key in ('started', 'joined'):
            row[key] = item.get(key) if type(item.get(key)) is bool else None
        source = item.get('ctp_factor_source_shutdown')
        if isinstance(source, dict):
            row['ctp_source_required'] = source.get('required') is True
            row['ctp_source_pass'] = source.get('status') == 'PASS'
        rows.append(row)
    return rows


def public_summary(summary, runner):
    routes = summary.get('routes')
    count = len(routes) if type(routes) is dict else None
    tape = summary.get('decision_tape')
    tape = tape if type(tape) is dict else {}
    plan = summary.get('_plan')
    grid = plan.get('grid') if type(plan) is dict else None
    grid_to_dict = getattr(grid, 'to_dict', None)
    try:
        grid_row = grid_to_dict() if callable(grid_to_dict) else None
        grid_minutes = (len(grid_row.get('minutes'))
                        if type(grid_row) is dict and type(grid_row.get('minutes')) is list else None)
    except Exception:
        grid_minutes = None
    def count_or_none(value):
        return value if type(value) is int and 0 <= value < (1 << 63) else None
    return {
        'run_returned_complete': summary.get('status') == 'LIVE_RUN_COMPLETE',
        'target_count': count,
        'expected_full_target_count_matches': count == 87,
        'same_run_plan_target_count': (len(plan.get('targets'))
                                       if type(plan) is dict and type(plan.get('targets')) in (tuple, list) else None),
        'same_run_plan_grid_minutes': grid_minutes,
        'factor_mode_native': summary.get('factor_mode') == 'native',
        'write_mode_disabled': summary.get('write_mode') is False,
        'cleanup_complete': summary.get('cleanup_complete') is True,
        'normal_epoch_retired': runner._live_epoch_retired(summary),
        'controlled_stop': runner._live_epoch_controlled_stopped(summary),
        'strategy_ready_to_close': summary.get('strategy_shutdown_ready') is True,
        'strategy_post_join_confirmed': summary.get('strategy_shutdown_post_join_confirmed') is True,
        'decision_tape_records': count_or_none(tape.get('record_count')),
        'full_grid_record_count_matches': type(tape.get('record_count')) is int and tape['record_count'] == 195,
        'decision_tape_bytes': count_or_none(tape.get('bytes')),
        'resources': public_cleanup(summary.get('resource_shutdown')),
    }


def main():
    if DRAFT_UNEXECUTABLE:
        raise RuntimeError('R9_DRAFT_UNEXECUTABLE')
    if sys.flags.isolated != 1 or sys.flags.interactive != 1:
        raise RuntimeError('ISOLATED_INTERACTIVE_HOST_REQUIRED')
    if OUTPUT.exists() or RUN_ROOT.exists() or not PRIVATE_TEMP.is_dir():
        raise RuntimeError('FRESH_NAMESPACE_REQUIRED')
    verify_sources()
    local = datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8)))
    # This is only an attempt window; pre-open query/subscription availability is unproven.
    # The same-run 195-slot tape validator is decisive; subscribe return is not acknowledgement.
    if local.strftime('%Y%m%d') != '20261028' or not ('08:30' <= local.strftime('%H:%M') < '08:35'):
        raise RuntimeError('GOLDEN_MINUTE_START_WINDOW_REQUIRED')
    tempfile.tempdir = str(PRIVATE_TEMP)
    os.environ['TEMP'] = os.environ['TMP'] = str(PRIVATE_TEMP)
    sys.path.insert(0, str(EXAMPLE))
    import backtrader
    import backtrader_runtime
    import protected_simnow
    import run as runner
    for module in (backtrader, backtrader_runtime):
        if not Path(module.__file__).resolve().is_relative_to(CONSUMER):
            raise RuntimeError('INSTALLED_ORIGIN_REQUIRED')
    from backtrader_runtime.capability_imports import trusted_installed_capability_import_context
    with trusted_installed_capability_import_context(('bt_api_base', 'bt_api_ctp')):
        import bt_api_ctp
        import bt_api_ctp.ctp.client as sdk_client
        import bt_api_ctp.md_identity as sdk_md_identity
    for module in (bt_api_ctp, sdk_client, sdk_md_identity):
        if not Path(module.__file__).resolve().is_relative_to(CONSUMER):
            raise RuntimeError('SDK_INSTALLED_ORIGIN_REQUIRED')
    config = runner.load_config(PROFILE)
    mode, decision = runner.resolve_mode(config, None)
    factor_mode, direction, _, _ = runner._factor_parameters(config, None)
    if not (mode == decision.effective_tier == 'live' and factor_mode == 'native'
            and config['selection']['source'] == 'ctp_query'
            and config['selection']['query_mode'] == 'staged_product_set'
            and config['selection']['authorized_products'] is None
            and config['selection']['max_epochs'] == 1
            and config['live']['allow_writes'] is False
            and config['live']['golden_targets'] is None
            and config['live']['arm_templates'] == []
            and config['cohort']['clock_domain_id'] == 'i51-md-20261028-fullpool-r9'
            and config['cohort']['epoch_id'] == 1):
        raise RuntimeError('FULL_POOL_READONLY_PROFILE_REQUIRED')
    for key in ('journal_path',):
        if Path(config['live'][key]).parent != RUN_ROOT:
            raise RuntimeError('OUTPUT_ROOT_MISMATCH')
    if Path(config['output']['decision_tape_path']).parent != RUN_ROOT:
        raise RuntimeError('OUTPUT_ROOT_MISMATCH')
    if Path(config['output']['directory']) != RUN_ROOT / 'output':
        raise RuntimeError('OUTPUT_ROOT_MISMATCH')
    observer = load_public_module('i51_root_write_observer', WRITE_OBSERVER)
    span = load_public_module('i51_root_span_capture', SPAN_HELPER)
    postflight = load_public_module('i51_fullpool_golden_postflight', POSTFLIGHT_HELPER)
    saved_tape_validator = load_public_module('i51_saved_factor_tape_validator', SAVED_TAPE_VALIDATOR)
    result = {'schema': 'i51_root_golden_fullpool_readonly.r9.v1', 'status': 'PREPARING',
              'root_pid': os.getpid(), 'started_at': datetime.now(timezone.utc).isoformat(),
              'phase': 'protected_configuration', 'allow_writes': False,
              'expected_targets': 87, 'required_witness_targets': ['DCE.I', 'SHFE.RB', 'CZCE.MA'],
              'expected_grid_minutes': 195, 'minimum_runtime_seconds': 7200,
              'expected_dev_head': EXPECTED_DEV_HEAD,
              'query_mode': config['selection']['query_mode'], 'source_pins': PUBLIC_PINS,
              'installed_record_pins': {'backtrader': BT_RECORD_SHA, 'bt_api_ctp': SDK_RECORD_SHA},
              'process_tree_memory_observation': 'NOT_RUN_IN_R9',
              'validated_tape_availability': {'status': 'NOT_VALIDATED'},
              'full_factor_acceptance': False, 'account_acceptance': False,
              'private_values_exported': False}
    ROOT_STATE['result'] = result
    persist(result)
    stack = ExitStack()
    mute = NativeOutputMute()
    ROOT_STATE.update(stack=stack, mute=mute, closed=False, observer_sink={})
    mute.enter()
    live_entered = False
    closed = False
    summary = None
    run_duration_seconds = None
    try:
        handoff = stack.enter_context(protected_simnow.protected_simnow_store_config(selected_config_index=0))
        ROOT_STATE['handoff'] = handoff
        if handoff.profile != 'set1_group1_vpn':
            raise RuntimeError('OFFICIAL_PROFILE_CATEGORY_MISMATCH')
        private_mapping = handoff.for_runner()
        # The accepted SDK compatibility mode is read-only and does not invent
        # an authenticated MD identity. The public runner still disables writes.
        override = {'config': private_mapping['config'],
                    'api_kwargs': {'ctp_join_observer': False, 'allow_zero_login_response': True}}
        RUN_ROOT.mkdir()
        (RUN_ROOT / 'output').mkdir()
        result.update(status='RUNNING', phase='run_live', profile_category=handoff.profile)
        run_started_at_utc = datetime.now(timezone.utc)
        result['live_call_window'] = {
            'started_at_utc': run_started_at_utc.isoformat(),
            'returned_at_utc': None,
            'runner_call_returned': False,
        }
        persist(result)
        live_entered = True
        run_started = time.monotonic()
        run_call_returned = False
        try:
            summary = span.invoke_with_readonly_span_observation(
                runner.run_live, observer, ROOT_STATE['observer_sink'],
                config, PROFILE, None, factor_mode, direction,
                decision=decision, allow_write_flag=False,
                _live_store_config_override=override, _include_plan=True,
                # Conservative session cutoff after the public day session.
                # The accepted 195-slot count still comes from this run's plan.
                shutdown_deadline_utc=datetime(2026, 10, 28, 7, 10, 0, tzinfo=timezone.utc),
            )
            run_call_returned = True
        finally:
            run_duration_seconds = time.monotonic() - run_started
            result['live_call_window']['returned_at_utc'] = datetime.now(
                timezone.utc
            ).isoformat()
            result['live_call_window']['runner_call_returned'] = run_call_returned
        ROOT_STATE['summary'] = summary
        result['run'] = public_summary(summary, runner)
        cleanup = summary.get('resource_shutdown')
        closed = (summary.get('cleanup_complete') is True and runner._cleanup_complete(cleanup)
                  and ROOT_STATE['observer_sink'].get('timer_joined') is True)
        result['status'] = 'FULL_POOL_RUN_RETURNED_REQUIRES_TAPE_VALIDATION'
    except BaseException as error:
        ROOT_STATE['original_error'] = error
        # Never export arbitrary exception code/text, causes, frame locals, or
        # account snapshots. Keep original objects privately if cleanup is unsure.
        result['status'] = 'BLOCKED_ROOT_GOLDEN_MINUTE_READONLY'
        result['reason'] = 'RUN_LIVE_FAILED' if live_entered else 'PROTECTED_SETUP_FAILED'
        if (type(error) is runner.RunnerError and type(error.code) is str
                and error.code in PUBLIC_RUNNER_ERROR_CODES):
            result['reason'] = error.code
            if error.code == 'CTP_FUTURES_SNAPSHOT_COLLECTION_FAILED':
                detail = getattr(error, 'detail', None)
                allowed_details = getattr(runner, '_CTP_FUTURES_SNAPSHOT_ERROR_CODES', None)
                result['snapshot_failure_detail'] = bounded_snapshot_failure_detail(detail, allowed_details)
                result['snapshot_query_diagnostics'] = runner._sanitize_ctp_query_diagnostics(
                    getattr(error, 'query_diagnostics', None)
                )
        capture_count = ROOT_STATE['observer_sink'].get('capture_count')
        result['engine_span_reached'] = (capture_count == 1) if type(capture_count) is int else None
        cleanup = getattr(error, 'cleanup_results', None)
        result['resources'] = public_cleanup(cleanup)
        closed = (not live_entered) or (
            ROOT_STATE['observer_sink'].get('cleanup_confirmed') is True
            and ROOT_STATE['observer_sink'].get('timer_joined') is True
        )
    finally:
        result['observation'] = ROOT_STATE['observer_sink']
        result['write_surfaces_observed_zero'] = bool(
            ROOT_STATE['observer_sink'].get('status') == 'FINISHED'
            and ROOT_STATE['observer_sink'].get('write_zero_confirmed') is True
        )
        result['native_cleanup_confirmed'] = (
            ROOT_STATE['observer_sink'].get('cleanup_confirmed') is True
        ) if live_entered else None
        result['timer_joined'] = ROOT_STATE['observer_sink'].get('timer_joined')
        if closed:
            stack.close()
            # Drop traceback/private-mapping ownership before restoring output.
            ROOT_STATE.pop('original_error', None)
            ROOT_STATE.pop('handoff', None)
            mute.close()
            ROOT_STATE['closed'] = True
        else:
            result['status'] = 'BLOCKED_RETAINED_GOLDEN_CUSTODY'
        result['private_context_closed'] = ROOT_STATE['closed']
        if summary is not None and ROOT_STATE['closed'] is True:
            normal_cleanup_complete = bool(
                result.get('native_cleanup_confirmed') is True
                and result.get('private_context_closed') is True
                and result.get('timer_joined') is True
            )
            if normal_cleanup_complete:
                cohort_cfg = config['cohort']
                expected_cohort = {
                    'cohort_id': (
                        f"alpha003:{cohort_cfg['calendar_id']}:{cohort_cfg['epoch_id']}"
                    ),
                    'calendar_version': cohort_cfg['calendar_version'],
                    'epoch_id': cohort_cfg['epoch_id'],
                    'timezone_id': cohort_cfg['timezone_id'],
                }
                try:
                    postflight_facts = postflight.validate_fullpool_postflight(
                        runner,
                        saved_tape_validator,
                        summary,
                        clock_domain_id=cohort_cfg['clock_domain_id'],
                        calendar_id=cohort_cfg['calendar_id'],
                        expected_cohort=expected_cohort,
                        normal_cleanup_complete=True,
                        zero_writes_confirmed=(result.get('write_surfaces_observed_zero') is True
                                               and config['live']['allow_writes'] is False),
                        controlled_stop_confirmed=runner._live_epoch_controlled_stopped(summary) is True,
                        epoch_retired_confirmed=runner._live_epoch_retired(summary) is True,
                        run_duration_seconds=run_duration_seconds,
                        direction=direction,
                        preheat_bars=config['factor']['preheat_bars'],
                    )
                    if type(postflight_facts) is not dict or postflight_facts.get(
                        'status'
                    ) not in ('PASS', 'FAIL'):
                        postflight_facts = {
                            'status': 'FAIL',
                            'code': 'POSTFLIGHT_RESULT_INVALID',
                        }
                except BaseException:
                    postflight_facts = {
                        'status': 'FAIL',
                        'code': 'POSTFLIGHT_VALIDATION_FAILED',
                    }
                result['postflight'] = postflight_facts
                if postflight_facts['status'] == 'PASS':
                    result['live_call_window']['first_qualified_source_available_at_utc'] = postflight_facts.get(
                        'first_full_cohort_live_ready_available_at_utc'
                    )
                    result['live_call_window']['source_time_marker_kind'] = (
                        'TAPE_EVENT_WATERMARK_NOT_OS_WALL_CLOCK'
                    )
                    result['validated_tape_availability'] = {
                        'status': 'VERIFIED',
                        'validated_at_utc': datetime.now(timezone.utc).isoformat(),
                        'file_id': postflight_facts.get('tape_file_id'),
                        'sha256': postflight_facts.get('tape_sha256'),
                        'bytes': postflight_facts.get('tape_bytes'),
                        'record_count': postflight_facts.get('decision_record_count'),
                    }
                    result['status'] = 'FULL_POOL_POSTFLIGHT_PASS'
                else:
                    # Tape failure is a validation result; the already-closed
                    # host and private/native cleanup remain closed.
                    result['status'] = 'FULL_POOL_POSTFLIGHT_FAIL'
            else:
                result['postflight'] = {
                    'status': 'NOT_RUN',
                    'code': 'NORMAL_CLEANUP_NOT_CONFIRMED',
                }
        else:
            result['postflight'] = {
                'status': 'NOT_RUN',
                'code': 'RUN_SUMMARY_OR_NORMAL_CLOSE_UNAVAILABLE',
            }
        result['phase'] = 'complete' if closed else 'retained'
        result['finished_at'] = datetime.now(timezone.utc).isoformat()
        verify_sources()
        result['source_pins_unchanged'] = True
        if summary is not None and result.get('private_context_closed') is True:
            try:
                checks = postflight.fullpool_acceptance_checks(result)
                if type(checks) is not dict or not checks or any(
                    type(value) is not bool for value in checks.values()
                ):
                    checks = {'aggregate_facts_valid': False}
            except BaseException:
                checks = {'aggregate_facts_valid': False}
            passed = bool(checks) and all(value is True for value in checks.values())
            result['fullpool_acceptance_checks'] = checks
            result['fullpool_tape_witness_pass'] = passed
            result['status'] = (
                'FULL_POOL_TAPE_WITNESS_PASS'
                if passed else 'FULL_POOL_TAPE_WITNESS_ACCEPTANCE_FAIL'
            )
        persist(result)
    if closed:
        print(json.dumps({'status': result['status'], 'native_cleanup_confirmed': result['native_cleanup_confirmed']}))


if __name__ == '__main__':
    if DRAFT_UNEXECUTABLE:
        raise SystemExit('R9_DRAFT_UNEXECUTABLE')
    try:
        main()
    except BaseException as error:
        ROOT_STATE['launcher_error'] = error
        failed = ROOT_STATE.get('result', {'schema': 'i51_root_golden_fullpool_readonly.r9.v1'})
        failed.update(status='BLOCKED_LAUNCHER', reason='ROOT_CALLER_FAILED')
        try:
            persist(failed)
        except BaseException:
            pass
