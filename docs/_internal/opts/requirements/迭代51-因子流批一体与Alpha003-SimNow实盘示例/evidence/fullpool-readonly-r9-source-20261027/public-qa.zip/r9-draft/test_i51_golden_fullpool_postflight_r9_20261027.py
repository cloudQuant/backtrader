"""Synthetic contracts for the unexecutable R9 full-pool postflight draft."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from types import SimpleNamespace

import pytest


SOURCE = Path(__file__).with_name("i51_fullpool_golden_postflight_r9_20261027.py")
CALLER = Path(__file__).with_name("i51_root_golden_minute_actual_r9_fullpool_20261028.py")
SPEC = importlib.util.spec_from_file_location("i51_fullpool_postflight_r9", SOURCE)
POSTFLIGHT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(POSTFLIGHT)

TARGETS = tuple(
    sorted(
        ["DCE.I", "SHFE.RB", "CZCE.MA"]
        + [f"TEST.P{i:02d}" for i in range(84)]
    )
)
BASE = datetime(2026, 10, 28, 1, 0, tzinfo=timezone.utc)
EXPECTED = {
    "targets": list(TARGETS),
    "minutes": [
        {
            "slot_index": index,
            "close_time": (BASE + timedelta(minutes=index)).isoformat(),
        }
        for index in range(195)
    ],
    "calendar_id": "alpha003-one-minute-v1",
    "clock_domain_id": "i51-r9-fullpool-test",
    "source_snapshot_id": "synthetic-selection-snapshot",
    "selection_source": "ctp_query_snapshot_equal_weight_v1",
    "grid_sha256": None,
    "routes": {target: {"instrument_id": f"{target}.SIM"} for target in TARGETS},
}
EXPECTED_COHORT = {
    "cohort_id": "alpha003:alpha003-one-minute-v1:1",
    "calendar_version": "source-session-snapshot-v1",
    "epoch_id": 1,
    "timezone_id": "UTC",
}


class FakeRunner:
    @staticmethod
    def _aware_datetime(value, _label):
        if isinstance(value, datetime):
            return value
        return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _point(target, number=1.25, *, available=True):
    member = {
        "complete": True,
        "present": True,
        "quality": "GOOD",
        "source_role": "live",
        "connection_generation": 7,
        "feed_sequence": 1,
    }
    if available:
        point = {
            "value": {
                "finite": True,
                "value": number,
                "float64_hex": float(number).hex(),
            },
            "status": "OUTPUT_AVAILABLE",
            "reason": None,
            "present": True,
            "complete": True,
            "quality": "GOOD",
            "source_role": "live",
            "member_id": target,
            "sequence": 1,
            "generation": 7,
        }
    else:
        point = {
            "value": {"finite": False, "value": None, "float64_hex": "nan"},
            "status": "OUTPUT_UNAVAILABLE",
            "reason": "SYNTHETIC_UNAVAILABLE",
            "present": True,
            "complete": True,
            "quality": "GOOD",
            "source_role": "live",
            "member_id": target,
            "sequence": 1,
            "generation": 7,
        }
    return member, point


def _rows(*, ready_indices=(), unavailable_indices=(), slot_gap_at=None):
    ready_indices = set(ready_indices)
    unavailable_indices = set(unavailable_indices)
    for index in range(195):
        slot_index = index + (1 if slot_gap_at is not None and index >= slot_gap_at else 0)
        members = {}
        values = {}
        for target in TARGETS:
            member, point = _point(
                target,
                number=1.0 + (index % 13) / 10.0,
                available=not (index in unavailable_indices and target == "SHFE.RB"),
            )
            members[target] = member
            values[target] = point
        yield {
            "record_type": "DECISION",
            "record_index": index + 1,
            "slot_index": slot_index,
            "close_time": EXPECTED["minutes"][index]["close_time"],
            "available_at": EXPECTED["minutes"][index]["close_time"],
            "cohort_id": EXPECTED_COHORT["cohort_id"],
            "calendar_version": EXPECTED_COHORT["calendar_version"],
            "epoch_id": EXPECTED_COHORT["epoch_id"],
            "readiness": "LIVE_READY" if index in ready_indices else "WARMUP",
            "readiness_reasons": [] if index in ready_indices else ["PREHEAT"],
            "members": members,
            "factors": {"factors": {"alpha003": {"values": values}}},
        }


def _measure(rows):
    return POSTFLIGHT.measure_three_target_witness_streak(
        FakeRunner(), rows, EXPECTED, EXPECTED_COHORT
    )


def test_fullpool_warmup_prefix_then_three_qualified_rows_passes():
    result = _measure(_rows(ready_indices=range(30, 33)))
    assert result == {
        "decision_record_count": 195,
        "three_target_qualified_rows": 3,
        "longest_consecutive_three_target_rows": 3,
        "required_consecutive_three_target_rows": 3,
        "first_full_cohort_live_ready_available_at_utc": (
            BASE + timedelta(minutes=30)
        ).isoformat(),
    }


@pytest.mark.parametrize("ready_indices", [(), (40, 41)])
def test_fullpool_warmup_only_or_two_ready_rows_fail(ready_indices):
    with pytest.raises(POSTFLIGHT._PostflightFailure) as exc:
        _measure(_rows(ready_indices=ready_indices))
    assert exc.value.code == "THREE_TARGET_QUALIFIED_STREAK_MISSING"


def test_unavailable_factor_breaks_three_target_streak():
    with pytest.raises(POSTFLIGHT._PostflightFailure) as exc:
        _measure(
            _rows(
                ready_indices=(30, 31, 32, 33),
                unavailable_indices=(32,),
            )
        )
    assert exc.value.code == "THREE_TARGET_QUALIFIED_STREAK_MISSING"


def test_warmup_row_inside_session_breaks_three_target_streak():
    with pytest.raises(POSTFLIGHT._PostflightFailure) as exc:
        _measure(_rows(ready_indices=(30, 31, 33, 34)))
    assert exc.value.code == "THREE_TARGET_QUALIFIED_STREAK_MISSING"


def test_nonadjacent_grid_slot_cannot_complete_qualified_streak():
    with pytest.raises(POSTFLIGHT._PostflightFailure) as exc:
        _measure(_rows(ready_indices=range(30, 33), slot_gap_at=32))
    assert exc.value.code == "FULL_POOL_TAPE_GRID_MISMATCH"


def test_nonfinite_or_unavailable_required_target_is_not_a_witness():
    rows = list(_rows(ready_indices=range(30, 33)))
    rows[31]["factors"]["factors"]["alpha003"]["values"]["DCE.I"]["value"] = {
        "finite": True,
        "value": math.inf,
        "float64_hex": "inf",
    }
    rows[31]["factors"]["factors"]["alpha003"]["values"]["DCE.I"]["status"] = (
        "OUTPUT_AVAILABLE"
    )
    with pytest.raises(POSTFLIGHT._PostflightFailure) as exc:
        _measure(rows)
    assert exc.value.code == "THREE_TARGET_QUALIFIED_STREAK_MISSING"


def test_finite_flag_must_be_true_even_when_value_looks_finite():
    rows = list(_rows(ready_indices=range(30, 33)))
    rows[31]["factors"]["factors"]["alpha003"]["values"]["DCE.I"]["value"][
        "finite"
    ] = False
    with pytest.raises(POSTFLIGHT._PostflightFailure) as exc:
        _measure(rows)
    assert exc.value.code == "THREE_TARGET_QUALIFIED_STREAK_MISSING"


def test_r9_profile_is_readonly_full_query_and_uses_fresh_paths():
    profile_path = SOURCE.with_name("i51_golden_fullpool_profile_r9_20261028.json")
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    assert profile["selection"]["source"] == "ctp_query"
    assert profile["selection"]["query_mode"] == "staged_product_set"
    assert profile["selection"]["authorized_products"] is None
    assert profile["selection"]["max_epochs"] == 1
    assert profile["live"]["allow_writes"] is False
    assert profile["live"]["golden_targets"] is None
    assert profile["live"]["arm_templates"] == []
    assert "r9-fullpool" in profile["live"]["journal_path"]
    assert "r9-fullpool" in profile["output"]["directory"]
    assert "r7" not in profile["live"]["journal_path"]


def test_r9_caller_uses_early_attempt_window_and_real_tape_marker_path():
    source = CALLER.read_text(encoding="utf-8")
    assert "'08:30' <= local.strftime('%H:%M') < '08:35'" in source
    assert "pre-open query/subscription availability is unproven" in source
    assert "first_qualified_source_available_at_utc'] = postflight_facts.get(" in source
    assert "'first_full_cohort_live_ready_available_at_utc'" in source
    assert "TAPE_EVENT_WATERMARK_NOT_OS_WALL_CLOCK" in source
    assert "same-run 195-slot tape validator is decisive" in source
    assert "subscribe return is not acknowledgement" in source

def _summary(tmp_path, plan):
    tape = tmp_path / "synthetic-fullpool-tape.bin"
    raw = b"synthetic bounded tape fixture\n"
    tape.write_bytes(raw)
    file_id = "synthetic-file-id"
    digest = hashlib.sha256(raw).hexdigest()
    last = {
        "file_id": file_id,
        "record_id": "synthetic-last-record",
        "record_index": 195,
        "batch_id": "synthetic-last-batch",
    }
    return {
        "status": "LIVE_RUN_COMPLETE",
        "mode": "live",
        "cleanup_complete": True,
        "source_clock_domain_id": EXPECTED["clock_domain_id"],
        "epoch_id": 1,
        "selection_source": EXPECTED["selection_source"],
        "source_snapshot_id": EXPECTED["source_snapshot_id"],
        "routes": {
            target: EXPECTED["routes"][target]["instrument_id"] for target in TARGETS
        },
        "_plan": plan,
        "decision_tape": {
            "file_id": file_id,
            "path": str(tape),
            "bytes": len(raw),
            "max_bytes": POSTFLIGHT.MAX_TAPE_BYTES,
            "record_count": 195,
            "sha256": digest,
            "closed": True,
            "failed": False,
            "last_record_reference": last,
        },
        "decision_tape_readback": {
            "file_id": file_id,
            "record_count": 195,
            "actual_bytes": len(raw),
            "last_record_reference": last,
        },
    }, tape, raw, last


class FakeSavedTapeValidator:
    def __init__(self, expected, fail_mode=None):
        self.expected = expected
        self.fail_mode = fail_mode
        self.plan_seen = None
        self.calls = []

    def project_expected_plan(self, plan, *, clock_domain_id, calendar_id):
        self.plan_seen = plan
        assert clock_domain_id == EXPECTED["clock_domain_id"]
        assert calendar_id == EXPECTED["calendar_id"]
        return self.expected

    def validate_saved_factor_tape(self, path, **kwargs):
        self.calls.append((path, kwargs))
        mode = kwargs["factor_mode"]
        return {
            "status": "FAIL" if mode == self.fail_mode else "PASS",
            "evidence_level": "SAVED_DECISION_TAPE_OFFLINE_CEREBRO_PARITY_ONLY",
            "file_id": kwargs["expected_file_id"],
            "tape_sha256": kwargs["expected_sha256"],
            "tape_bytes": kwargs["expected_bytes"],
            "decision_record_count": 195,
            "target_count": 87,
            "grid_minute_count": 195,
            "offline_factor_mode": mode,
            "live_ready_rows": 100,
            "required_live_ready": 100,
            "orders_submitted": 0,
            "provider_calls": 0,
        }


class FakeTapeRunner(FakeRunner):
    def __init__(self, tape_rows):
        self.tape_rows = tape_rows

    def iter_decision_tape(self, _path, *, max_bytes):
        assert max_bytes == POSTFLIGHT.MAX_TAPE_BYTES
        yield {
            "record_type": "HEADER",
            "file_id": "synthetic-file-id",
            "calendar_id": EXPECTED["calendar_id"],
            "source_snapshot_id": EXPECTED["source_snapshot_id"],
            "targets": list(TARGETS),
            "grid_sha256": None,
            "factor_mode": "native",
            "direction": 1,
        }
        yield from self.tape_rows


def test_fullpool_wrapper_binds_same_full_plan_and_invokes_both_modes(tmp_path):
    grid = SimpleNamespace(to_dict=lambda: {"minutes": EXPECTED["minutes"]})
    plan = {"targets": TARGETS, "golden_targets": None, "grid": grid}
    summary, _tape, _raw, _last = _summary(tmp_path, plan)
    validator = FakeSavedTapeValidator(EXPECTED)
    runner = FakeTapeRunner(_rows(ready_indices=range(30, 33)))
    result = POSTFLIGHT.validate_fullpool_postflight(
        runner,
        validator,
        summary,
        clock_domain_id=EXPECTED["clock_domain_id"],
        calendar_id=EXPECTED["calendar_id"],
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
        zero_writes_confirmed=True,
        controlled_stop_confirmed=True,
        epoch_retired_confirmed=True,
        run_duration_seconds=POSTFLIGHT.MIN_RUN_SECONDS,
        direction=1,
        preheat_bars=30,
    )
    assert result["status"] == "PASS"
    assert result["evidence_level"] == (
        "SAME_RUN_FULL_87_MEMBER_TAPE_WITH_THREE_TARGET_WITNESS_ONLY"
    )
    assert result["selection_manifest_binding_verified"] is True
    assert validator.plan_seen is plan
    assert [call[1]["factor_mode"] for call in validator.calls] == ["native", "build"]
    assert all(call[1]["expected"] is EXPECTED for call in validator.calls)
    assert all(call[1]["expected_record_count"] == 195 for call in validator.calls)


def test_fullpool_wrapper_rejects_reduced_plan_and_failed_offline_mode(tmp_path):
    grid = SimpleNamespace(to_dict=lambda: {"minutes": EXPECTED["minutes"]})
    reduced_plan = {"targets": TARGETS[:3], "golden_targets": TARGETS[:3], "grid": grid}
    summary, _tape, _raw, _last = _summary(tmp_path, reduced_plan)
    validator = FakeSavedTapeValidator(EXPECTED)
    result = POSTFLIGHT.validate_fullpool_postflight(
        FakeTapeRunner(_rows(ready_indices=range(30, 33))),
        validator,
        summary,
        clock_domain_id=EXPECTED["clock_domain_id"],
        calendar_id=EXPECTED["calendar_id"],
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
        zero_writes_confirmed=True,
        controlled_stop_confirmed=True,
        epoch_retired_confirmed=True,
        run_duration_seconds=POSTFLIGHT.MIN_RUN_SECONDS,
        direction=1,
        preheat_bars=30,
    )
    assert result == {"status": "FAIL", "code": "FULL_POOL_PLAN_NOT_FULL_SELECTION"}
    assert validator.calls == []

    full_plan = {"targets": TARGETS, "golden_targets": None, "grid": grid}
    summary, _tape, _raw, _last = _summary(tmp_path, full_plan)
    validator = FakeSavedTapeValidator(EXPECTED, fail_mode="build")
    result = POSTFLIGHT.validate_fullpool_postflight(
        FakeTapeRunner(_rows(ready_indices=range(30, 33))),
        validator,
        summary,
        clock_domain_id=EXPECTED["clock_domain_id"],
        calendar_id=EXPECTED["calendar_id"],
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
        zero_writes_confirmed=True,
        controlled_stop_confirmed=True,
        epoch_retired_confirmed=True,
        run_duration_seconds=POSTFLIGHT.MIN_RUN_SECONDS,
        direction=1,
        preheat_bars=30,
    )
    assert result == {"status": "FAIL", "code": "FULL_POOL_OFFLINE_VALIDATION_FAILED"}
    assert [call[1]["factor_mode"] for call in validator.calls] == ["native", "build"]


def test_fullpool_wrapper_rejects_short_run_before_offline_recompute(tmp_path):
    grid = SimpleNamespace(to_dict=lambda: {"minutes": EXPECTED["minutes"]})
    plan = {"targets": TARGETS, "golden_targets": None, "grid": grid}
    summary, _tape, _raw, _last = _summary(tmp_path, plan)
    validator = FakeSavedTapeValidator(EXPECTED)
    result = POSTFLIGHT.validate_fullpool_postflight(
        FakeTapeRunner(_rows(ready_indices=range(30, 33))),
        validator,
        summary,
        clock_domain_id=EXPECTED["clock_domain_id"],
        calendar_id=EXPECTED["calendar_id"],
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
        zero_writes_confirmed=True,
        controlled_stop_confirmed=True,
        epoch_retired_confirmed=True,
        run_duration_seconds=POSTFLIGHT.MIN_RUN_SECONDS - 1,
        direction=1,
        preheat_bars=30,
    )
    assert result == {"status": "FAIL", "code": "FULL_POOL_RUN_GATES_NOT_CONFIRMED"}
    assert validator.calls == []


def _fullpool_acceptance_result():
    run_end = "2026-10-28T03:00:00+00:00"
    digest = "a" * 64
    return {
        "phase": "complete",
        "status": "FULL_POOL_POSTFLIGHT_PASS",
        "private_context_closed": True,
        "allow_writes": False,
        "source_pins_unchanged": True,
        "process_tree_memory_observation": "NOT_RUN_IN_R9",
        "write_surfaces_observed_zero": True,
        "native_cleanup_confirmed": True,
        "timer_joined": True,
        "live_call_window": {
            "started_at_utc": "2026-10-28T01:00:00+00:00",
            "first_qualified_source_available_at_utc": (
                "2026-10-28T01:30:00+00:00"
            ),
            "source_time_marker_kind": (
                "TAPE_EVENT_WATERMARK_NOT_OS_WALL_CLOCK"
            ),
            "returned_at_utc": run_end,
            "runner_call_returned": True,
        },
        "validated_tape_availability": {
            "status": "VERIFIED",
            "validated_at_utc": "2026-10-28T03:01:00+00:00",
            "file_id": "same-run-file-id",
            "sha256": digest,
            "bytes": 4096,
            "record_count": 195,
        },
        "run": {
            "run_returned_complete": True,
            "target_count": 87,
            "expected_full_target_count_matches": True,
            "same_run_plan_target_count": 87,
            "factor_mode_native": True,
            "same_run_plan_grid_minutes": 195,
            "decision_tape_records": 195,
            "full_grid_record_count_matches": True,
            "write_mode_disabled": True,
            "cleanup_complete": True,
            "normal_epoch_retired": True,
            "controlled_stop": True,
            "strategy_ready_to_close": True,
            "strategy_post_join_confirmed": True,
        },
        "postflight": {
            "status": "PASS",
            "evidence_level": "SAME_RUN_FULL_87_MEMBER_TAPE_WITH_THREE_TARGET_WITNESS_ONLY",
            "normal_cleanup_complete": True,
            "zero_writes_confirmed": True,
            "controlled_stop_confirmed": True,
            "epoch_retired_confirmed": True,
            "run_duration_seconds": 7200.0,
            "first_full_cohort_live_ready_available_at_utc": (
                "2026-10-28T01:30:00+00:00"
            ),
            "same_run_plan_used": True,
            "selection_manifest_binding_verified": True,
            "target_count": 87,
            "planned_grid_minutes": 195,
            "decision_record_count": 195,
            "required_live_ready_rows": 100,
            "offline_modes": {"native": "PASS", "build": "PASS"},
            "longest_consecutive_three_target_rows": 3,
            "required_consecutive_three_target_rows": 3,
            "tape_file_id": "same-run-file-id",
            "tape_sha256": digest,
            "tape_bytes": 4096,
        },
    }


def test_fullpool_aggregate_requires_all_run_cleanup_source_and_tape_facts():
    result = _fullpool_acceptance_result()
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert checks
    assert all(value is True for value in checks.values())
    assert checks["actual_live_call_window_for_external_sampling"] is True
    assert checks["first_full_cohort_source_time_marker_matches_tape"] is True
    assert checks["validated_tape_availability_for_external_sampling"] is True
    assert checks["process_tree_memory_scope_explicit"] is True


@pytest.mark.parametrize(
    ("path", "value", "check"),
    [
        (("run", "strategy_ready_to_close"), False, "strategy_shutdown_proof"),
        (("run", "strategy_post_join_confirmed"), False, "strategy_shutdown_proof"),
        (("run", "write_mode_disabled"), False, "read_only_mode"),
        (("run", "target_count"), 86, "full_target_selection"),
        (("run", "factor_mode_native"), False, "full_target_selection"),
        (("run", "normal_epoch_retired"), False, "normal_epoch_retirement"),
        (("run", "controlled_stop"), False, "controlled_stop"),
        (("run", "cleanup_complete"), False, "normal_resource_cleanup"),
        (("postflight", "offline_modes"), {"native": "PASS", "build": "FAIL"},
         "qualified_fullpool_postflight"),
        (("source_pins_unchanged",), False, "source_pins_unchanged"),
        (("postflight", "run_duration_seconds"), 7199.99, "full_run_duration"),
        (("live_call_window", "runner_call_returned"), False,
         "actual_live_call_window_for_external_sampling"),
        (("validated_tape_availability", "sha256"), "b" * 64,
         "validated_tape_availability_for_external_sampling"),
    ],
)
def test_fullpool_aggregate_rejects_missing_or_drifted_required_fact(path, value, check):
    result = _fullpool_acceptance_result()
    target = result
    for segment in path[:-1]:
        target = target[segment]
    target[path[-1]] = value
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert checks[check] is False
    assert not all(item is True for item in checks.values())


def test_fullpool_aggregate_rejects_unusable_external_sampling_window():
    result = _fullpool_acceptance_result()
    result["live_call_window"]["returned_at_utc"] = "2026-10-28T02:59:59+00:00"
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert checks["actual_live_call_window_for_external_sampling"] is False


def test_fullpool_aggregate_rejects_unbound_warmup_marker():
    result = _fullpool_acceptance_result()
    result["live_call_window"]["first_qualified_source_available_at_utc"] = (
        "2026-10-28T01:29:00+00:00"
    )
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert checks["first_full_cohort_source_time_marker_matches_tape"] is False


def test_fullpool_aggregate_requires_postflight_tape_event_marker():
    result = _fullpool_acceptance_result()
    result["postflight"].pop("first_full_cohort_live_ready_available_at_utc")
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert checks["first_full_cohort_source_time_marker_matches_tape"] is False
    assert not all(value is True for value in checks.values())

def test_fullpool_aggregate_accepts_final_witness_status_after_readback():
    result = _fullpool_acceptance_result()
    result["status"] = "FULL_POOL_TAPE_WITNESS_PASS"
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert all(value is True for value in checks.values())


def test_fullpool_aggregate_does_not_claim_process_tree_memory_acceptance():
    result = _fullpool_acceptance_result()
    result["process_tree_memory_observation"] = "PASS"
    checks = POSTFLIGHT.fullpool_acceptance_checks(result)
    assert checks["process_tree_memory_scope_explicit"] is False
