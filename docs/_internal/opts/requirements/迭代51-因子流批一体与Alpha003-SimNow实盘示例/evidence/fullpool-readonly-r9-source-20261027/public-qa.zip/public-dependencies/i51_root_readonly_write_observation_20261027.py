"""Finite, identity-bound observation of read-only CTP write surfaces.

This helper only calls existing Broker/Store read APIs. It never constructs,
starts, configures, or stops a provider object. Returned values contain only
fixed field names, booleans, nonnegative counts, and ``None`` for unavailable
or invalid observations; raw dispatch rows and session identities stay local.
"""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from typing import Any


_MAX_COUNT = (1 << 63) - 1
_MAX_DISPATCH_ROWS = 256
_BROKER_COUNT_KEYS = (
    "submit_rejected",
    "cancel_rejected",
    "batch_cancel_rejected",
    "total_rejected",
)
_SDK_COUNT_KEYS = ("order_insert", "order_action")
_DISPATCH_KEYS = (
    "insert_known",
    "insert_unknown",
    "cancel_known",
    "cancel_unknown",
    "highwater_sequence",
)


def _count(value: Any) -> int | None:
    if type(value) is not int or value < 0 or value > _MAX_COUNT:
        return None
    return value


def _read_mapping(method_owner: Any, method_name: str) -> tuple[bool, Any]:
    try:
        method = getattr(method_owner, method_name, None)
    except Exception:
        return False, None
    if not callable(method):
        return False, None
    try:
        return True, method()
    except Exception:
        return True, None


def _broker_rejections(broker: Any) -> dict[str, Any]:
    available, raw = _read_mapping(broker, "get_market_data_only_audit")
    values = {key: None for key in _BROKER_COUNT_KEYS}
    valid = isinstance(raw, Mapping)
    if valid:
        for key in _BROKER_COUNT_KEYS:
            parsed = _count(raw.get(key))
            if parsed is None:
                valid = False
            values[key] = parsed
        valid = bool(
            valid
            and values["total_rejected"]
            == values["submit_rejected"]
            + values["cancel_rejected"]
            + values["batch_cancel_rejected"]
        )
    if not valid:
        values = {key: None for key in _BROKER_COUNT_KEYS}
    return {"available": available, "valid": valid, **values}


def _store_rejections(store: Any) -> dict[str, Any]:
    available, raw = _read_mapping(store, "get_command_health")
    value = _count(raw.get("rejected_market_data_only")) if isinstance(raw, Mapping) else None
    valid = value is not None
    return {"available": available, "valid": valid, "rejected_market_data_only": value}


def _sdk_requests(store: Any) -> dict[str, Any]:
    available, raw = _read_mapping(store, "get_ctp_session_state")
    counts = raw.get("request_counts") if isinstance(raw, Mapping) else None
    values = {
        key: _count(counts.get(key)) if isinstance(counts, Mapping) else None
        for key in _SDK_COUNT_KEYS
    }
    valid = all(value is not None for value in values.values())
    if not valid:
        values = {key: None for key in _SDK_COUNT_KEYS}
    return {"available": available, "valid": valid, **values}


def _row_value(row: Any, name: str) -> Any:
    try:
        if isinstance(row, Mapping):
            return row.get(name)
        return getattr(row, name, None)
    except Exception:
        return None


def _dispatch_counts(store: Any) -> dict[str, Any]:
    available, rows = _read_mapping(store, "registered_sim_dispatch_history")
    values = {key: 0 for key in _DISPATCH_KEYS}
    valid = isinstance(rows, (tuple, list)) and len(rows) <= _MAX_DISPATCH_ROWS
    previous_sequence = 0
    if valid:
        for row in rows:
            sequence = _count(_row_value(row, "sequence"))
            operation = _row_value(row, "operation")
            status = _row_value(row, "status")
            if (
                sequence is None
                or sequence <= previous_sequence
                or type(operation) is not str
                or operation not in {"insert", "cancel"}
                or type(status) is not str
                or status not in {"KNOWN", "UNKNOWN"}
            ):
                valid = False
                break
            previous_sequence = sequence
            values[f"{operation}_{status.lower()}"] += 1
        if valid:
            values["highwater_sequence"] = previous_sequence
    if not valid:
        values = {key: None for key in _DISPATCH_KEYS}
    return {"available": available, "valid": valid, **values}


def _snapshot(broker: Any, store: Any) -> dict[str, Any]:
    return {
        "broker_rejections": _broker_rejections(broker),
        "store_rejections": _store_rejections(store),
        "sdk_requests": _sdk_requests(store),
        "dispatch": _dispatch_counts(store),
    }


def _all_valid(snapshot: Mapping[str, Any]) -> bool:
    return all(
        isinstance(snapshot.get(name), Mapping)
        and snapshot[name].get("available") is True
        and snapshot[name].get("valid") is True
        for name in ("broker_rejections", "store_rejections", "sdk_requests", "dispatch")
    )


def _all_zero(snapshot: Mapping[str, Any]) -> bool:
    if not _all_valid(snapshot):
        return False
    blocks = (
        snapshot["broker_rejections"],
        snapshot["store_rejections"],
        snapshot["sdk_requests"],
        snapshot["dispatch"],
    )
    return all(
        type(value) is int and value == 0
        for block in blocks
        for key, value in block.items()
        if key not in {"available", "valid"}
    )


def _nondecreasing(before: Mapping[str, Any], after: Mapping[str, Any]) -> bool | None:
    if not (_all_valid(before) and _all_valid(after)):
        return None
    for section in ("broker_rejections", "store_rejections", "sdk_requests", "dispatch"):
        for key, previous in before[section].items():
            if key in {"available", "valid"}:
                continue
            current = after[section][key]
            if type(previous) is not int or type(current) is not int or current < previous:
                return False
    return True


class ObservationToken:
    """Private same-object anchors and the baseline snapshot; do not serialize."""

    __slots__ = ("_broker", "_store", "_wrapper", "_trader", "_before")

    def __init__(self, broker: Any, store: Any, wrapper: Any, trader: Any, before: dict[str, Any]):
        self._broker = broker
        self._store = store
        self._wrapper = wrapper
        self._trader = trader
        self._before = deepcopy(before)

    def __repr__(self) -> str:
        return "<ObservationToken>"


def begin_observation(broker: Any, store: Any) -> tuple[ObservationToken, dict[str, Any]]:
    """Capture the baseline and hold object references without exposing them."""
    try:
        wrapper = getattr(store, "_api", None)
        trader = getattr(wrapper, "trader_client", None) if wrapper is not None else None
    except Exception:
        wrapper = trader = None
    before = _snapshot(broker, store)
    return ObservationToken(broker, store, wrapper, trader, before), deepcopy(before)


def finish_observation(
    token: ObservationToken, broker: Any, store: Any
) -> dict[str, Any]:
    """Compare against the baseline only when all live object identities match."""
    if not isinstance(token, ObservationToken):
        return {
            "schema": "i51_root_readonly_write_observation.v1",
            "same_objects": False,
            "observations_complete": False,
            "counters_nondecreasing": None,
            "zero_baseline": False,
            "zero_after": False,
            "zero_delta": False,
            "zero_write_activity": False,
            "before": None,
            "after": None,
        }

    try:
        wrapper = getattr(store, "_api", None)
        trader = getattr(wrapper, "trader_client", None) if wrapper is not None else None
    except Exception:
        wrapper = trader = None
    same_objects = bool(
        broker is token._broker
        and store is token._store
        and token._wrapper is not None
        and wrapper is token._wrapper
        and token._trader is not None
        and trader is token._trader
    )
    after = _snapshot(broker, store) if same_objects else None
    complete = bool(same_objects and after is not None and _all_valid(token._before) and _all_valid(after))
    nondecreasing = _nondecreasing(token._before, after) if after is not None else None
    zero_before = _all_zero(token._before)
    zero_after = _all_zero(after) if after is not None else False
    zero_delta = bool(
        complete
        and nondecreasing is True
        and all(
            token._before[section][key] == after[section][key]
            for section in ("broker_rejections", "store_rejections", "sdk_requests", "dispatch")
            for key in token._before[section]
            if key not in {"available", "valid"}
        )
    )
    zero_write_activity = bool(
        complete and nondecreasing is True and zero_before and zero_after
    )
    return {
        "schema": "i51_root_readonly_write_observation.v1",
        "same_objects": same_objects,
        "observations_complete": complete,
        "counters_nondecreasing": nondecreasing,
        "zero_baseline": zero_before,
        "zero_after": zero_after,
        "zero_delta": zero_delta,
        "zero_write_activity": zero_write_activity,
        "before": deepcopy(token._before),
        "after": after,
    }
