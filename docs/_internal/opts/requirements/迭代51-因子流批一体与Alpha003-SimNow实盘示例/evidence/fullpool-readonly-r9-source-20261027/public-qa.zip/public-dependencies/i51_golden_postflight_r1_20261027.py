"""Bounded read-only postflight for one same-run three-target golden tape.

The caller supplies the already-held runner module, actual run summary and an
independent normal-cleanup observation. This helper reads no config, journal,
Store or account state. It checks the public DecisionTape through the runner's
bounded iterator; the separate raw-byte pass computes only the writer digest.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timedelta, timezone
import hashlib
import math
from pathlib import Path
from typing import Any


MAX_TAPE_BYTES = 64 * 1024 * 1024
EXPECTED_TARGET_COUNT = 3
EXPECTED_ACTIVE_GRID_MINUTES = 225
EXPECTED_FULL_GRID_MINUTES = 195
MAX_PLAN_TARGETS = 256
OHLCV_FIELDS = {"open", "high", "low", "close", "volume", "openinterest"}
MEMBER_FIELDS = {
    "cohort_id",
    "calendar_id",
    "epoch_id",
    "slot_index",
    "slot_id",
    "instrument",
    "source_ref",
    "source_role",
    "connection_generation",
    "feed_sequence",
    "bucket_start",
    "close_time",
    "available_at",
    "trading_day",
    "session_segment",
    "timezone_id",
    "clock_domain_id",
    "bar_id",
    "complete",
    "quality",
    "present",
    "quality_flags",
    "event_source",
    "received_monotonic_ns",
    "raw_values",
}
FACTOR_POINT_FIELDS = {
    "value",
    "status",
    "reason",
    "present",
    "complete",
    "quality",
    "source_role",
    "member_id",
    "source_ref",
    "sequence",
    "generation",
}
EXPECTED_COHORT_FIELDS = {
    "cohort_id",
    "calendar_version",
    "epoch_id",
    "timezone_id",
}


class _PostflightFailure(Exception):
    def __init__(self, code: str):
        self.code = code


def _fail(code: str) -> None:
    raise _PostflightFailure(code)


def _mapping(value: Any, code: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(code)
    return value


def _text(value: Any, code: str) -> str:
    if type(value) is not str or not value or value != value.strip():
        _fail(code)
    return value


def _sha256(value: Any, code: str) -> str:
    if (
        type(value) is not str
        or len(value) != 64
        or any(character not in "0123456789abcdef" for character in value)
    ):
        _fail(code)
    return value


def _utc(runner: Any, value: Any, code: str) -> datetime:
    try:
        result = runner._aware_datetime(value, "golden postflight")
    except Exception:
        _fail(code)
    if not isinstance(result, datetime) or result.tzinfo is None:
        _fail(code)
    return result.astimezone(timezone.utc)


def _day(runner: Any, value: Any, code: str) -> str:
    try:
        result = runner._tape_trading_day(value, "golden postflight")
    except Exception:
        _fail(code)
    if type(result) is not str:
        _fail(code)
    return result


def _number(value: Any, code: str, *, nonnegative: bool = False) -> float:
    if type(value) not in (int, float):
        _fail(code)
    number = float(value)
    if not math.isfinite(number) or (nonnegative and number < 0):
        _fail(code)
    return number


def _raw_hash(path: Path, maximum: int) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    try:
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > maximum:
                    _fail("TAPE_BYTE_BUDGET_EXCEEDED")
                digest.update(chunk)
    except _PostflightFailure:
        raise
    except Exception:
        _fail("TAPE_READ_FAILED")
    return size, digest.hexdigest()


def _plan_projection(
    runner: Any,
    plan: Mapping[str, Any],
    *,
    clock_domain_id: str,
    calendar_id: str,
    target_count: int = EXPECTED_TARGET_COUNT,
) -> dict[str, Any]:
    if plan.get("selection_source") != "ctp_query_snapshot_equal_weight_v1":
        _fail("PLAN_SOURCE_INVALID")
    _text(plan.get("selection_path"), "PLAN_SELECTION_INVALID")
    if not plan["selection_path"].startswith("ctp-query://"):
        _fail("PLAN_SELECTION_INVALID")
    source_snapshot_id = _text(plan.get("source_snapshot_id"), "PLAN_SNAPSHOT_INVALID")

    targets_raw = plan.get("targets")
    products = plan.get("product_by_target")
    reverse = plan.get("target_by_product")
    routes = plan.get("routes")
    if (
        not isinstance(targets_raw, (tuple, list))
        or not isinstance(products, Mapping)
        or not isinstance(reverse, Mapping)
        or not isinstance(routes, Mapping)
    ):
        _fail("PLAN_TARGETS_INVALID")
    targets = tuple(sorted(targets_raw))
    if (
        len(targets) != target_count
        or any(type(target) is not str or not target for target in targets)
        or len(set(targets)) != len(targets)
        or set(products) != set(targets)
    ):
        _fail("PLAN_TARGETS_INVALID")

    target_by_pair: dict[tuple[str, str], str] = {}
    route_by_target: dict[str, str] = {}
    for target in targets:
        product = products[target]
        exchange = _text(getattr(product, "exchange_id", None), "PLAN_PRODUCT_INVALID")
        product_id = _text(getattr(product, "product_id", None), "PLAN_PRODUCT_INVALID")
        pair = (exchange, product_id)
        instrument = _text(routes.get(product), "PLAN_ROUTE_INVALID")
        if (
            target != f"{exchange}.{product_id}"
            or reverse.get(product) != target
            or pair in target_by_pair
        ):
            _fail("PLAN_PRODUCT_ROUTE_MISMATCH")
        target_by_pair[pair] = target
        route_by_target[target] = instrument

    grid = plan.get("grid")
    to_dict = getattr(grid, "to_dict", None)
    if not callable(to_dict):
        _fail("PLAN_GRID_INVALID")
    try:
        grid_row = to_dict()
    except Exception:
        _fail("PLAN_GRID_INVALID")
    if (
        type(grid_row) is not dict
        or set(grid_row)
        != {
            "schema",
            "status",
            "decision_at",
            "target_products",
            "product_trading_days",
            "calendar_hashes",
            "minutes",
        }
        or grid_row.get("schema") != "backtrader.futures_common_minute_grid.v1"
        or grid_row.get("status") != "READY"
    ):
        _fail("PLAN_GRID_INVALID")

    grid_products = grid_row["target_products"]
    if type(grid_products) is not list:
        _fail("PLAN_GRID_TARGETS_INVALID")
    grid_pairs = set()
    for item in grid_products:
        row = _mapping(item, "PLAN_GRID_TARGETS_INVALID")
        if set(row) != {"exchange_id", "product_id"}:
            _fail("PLAN_GRID_TARGETS_INVALID")
        grid_pairs.add(
            (
                _text(row["exchange_id"], "PLAN_GRID_TARGETS_INVALID"),
                _text(row["product_id"], "PLAN_GRID_TARGETS_INVALID"),
            )
        )
    if (
        len(grid_products) != target_count
        or len(grid_pairs) != target_count
        or grid_pairs != set(target_by_pair)
    ):
        _fail("PLAN_GRID_TARGETS_INVALID")

    raw_days = grid_row["product_trading_days"]
    if type(raw_days) is not list or len(raw_days) != target_count:
        _fail("PLAN_GRID_DAYS_INVALID")
    days_by_target: dict[str, set[str]] = {}
    for item in raw_days:
        row = _mapping(item, "PLAN_GRID_DAYS_INVALID")
        if set(row) != {"product", "trading_days"}:
            _fail("PLAN_GRID_DAYS_INVALID")
        product_row = _mapping(row["product"], "PLAN_GRID_DAYS_INVALID")
        if set(product_row) != {"exchange_id", "product_id"}:
            _fail("PLAN_GRID_DAYS_INVALID")
        pair = (product_row["exchange_id"], product_row["product_id"])
        target = target_by_pair.get(pair)
        raw_product_days = row["trading_days"]
        if target is None or target in days_by_target or type(raw_product_days) is not list:
            _fail("PLAN_GRID_DAYS_INVALID")
        normalized = {_day(runner, value, "PLAN_GRID_DAYS_INVALID") for value in raw_product_days}
        if not normalized or len(normalized) != len(raw_product_days):
            _fail("PLAN_GRID_DAYS_INVALID")
        days_by_target[target] = normalized
    if set(days_by_target) != set(targets):
        _fail("PLAN_GRID_DAYS_INVALID")

    minutes = grid_row["minutes"]
    if type(minutes) is not list or not 1 <= len(minutes) <= 512:
        _fail("PLAN_GRID_MINUTES_INVALID")
    by_close: dict[datetime, dict[str, Any]] = {}
    previous_close = None
    for index, minute_value in enumerate(minutes):
        minute = _mapping(minute_value, "PLAN_GRID_MINUTE_INVALID")
        if set(minute) != {"close_time", "members"}:
            _fail("PLAN_GRID_MINUTE_INVALID")
        close_at = _utc(runner, minute["close_time"], "PLAN_GRID_TIME_INVALID")
        if previous_close is not None and close_at <= previous_close:
            _fail("PLAN_GRID_TIME_ORDER_INVALID")
        previous_close = close_at
        member_values = minute["members"]
        if type(member_values) is not list or len(member_values) != target_count:
            _fail("PLAN_GRID_MEMBERS_INVALID")
        projected: dict[str, dict[str, Any]] = {}
        for raw_member in member_values:
            member = _mapping(raw_member, "PLAN_GRID_MEMBER_INVALID")
            if set(member) != {
                "product",
                "trading_day",
                "session_date",
                "action_day",
                "session_id",
            }:
                _fail("PLAN_GRID_MEMBER_INVALID")
            product_row = _mapping(member["product"], "PLAN_GRID_MEMBER_INVALID")
            if set(product_row) != {"exchange_id", "product_id"}:
                _fail("PLAN_GRID_MEMBER_INVALID")
            pair = (product_row["exchange_id"], product_row["product_id"])
            target = target_by_pair.get(pair)
            if target is None or target in projected:
                _fail("PLAN_GRID_MEMBER_SET_INVALID")
            trading_day = _day(runner, member["trading_day"], "PLAN_GRID_MEMBER_DAY_INVALID")
            if trading_day not in days_by_target[target]:
                _fail("PLAN_GRID_MEMBER_DAY_INVALID")
            projected[target] = {
                "instrument": route_by_target[target],
                "trading_day": trading_day,
                "session_segment": _text(member["session_id"], "PLAN_GRID_SESSION_INVALID"),
                "session_date": _day(runner, member["session_date"], "PLAN_GRID_SESSION_INVALID"),
                "action_day": _day(runner, member["action_day"], "PLAN_GRID_SESSION_INVALID"),
                "bucket_start": close_at - timedelta(minutes=1),
            }
        if set(projected) != set(targets):
            _fail("PLAN_GRID_MEMBER_SET_INVALID")
        by_close[close_at] = {"slot_index": index, "members": projected}

    grid_hash = getattr(grid, "evidence_sha256", None)
    if grid_hash is not None:
        _sha256(grid_hash, "PLAN_GRID_HASH_INVALID")
    try:
        grid_semantics_sha256 = _sha256(
            runner._grid_semantics_sha256(grid), "PLAN_GRID_HASH_INVALID"
        )
    except _PostflightFailure:
        raise
    except Exception:
        _fail("PLAN_GRID_HASH_INVALID")
    manifest = plan.get("manifest")
    manifest_status = getattr(manifest, "status", None)
    manifest_status = getattr(manifest_status, "value", manifest_status)
    if manifest_status != "READY":
        _fail("PLAN_MANIFEST_NOT_READY")

    return {
        "targets": targets,
        "route_by_target": route_by_target,
        "source_snapshot_id": source_snapshot_id,
        "grid": grid,
        "grid_hash": grid_hash,
        "grid_semantics_sha256": grid_semantics_sha256,
        "by_close": by_close,
        "clock_domain_id": _text(clock_domain_id, "CLOCK_DOMAIN_INVALID"),
        "calendar_id": _text(calendar_id, "CALENDAR_ID_INVALID"),
    }


def _golden_plan_projection(
    runner: Any,
    plan: Mapping[str, Any],
    active: Mapping[str, Any],
    *,
    clock_domain_id: str,
    calendar_id: str,
) -> dict[str, Any]:
    """Bind the active grid to the full selection retained by golden subset."""

    required = (
        "golden_targets",
        "active_shadow_targets",
        "full_products",
        "full_routes",
        "full_selected_targets",
        "full_product_by_target",
        "full_target_by_product",
        "full_authorized_targets",
        "full_grid",
    )
    if any(key not in plan for key in required) or plan.get("golden_targets") is None:
        _fail("PLAN_GOLDEN_SUBSET_REQUIRED")

    full_products = plan["full_products"]
    full_targets_raw = plan["full_selected_targets"]
    full_routes = plan["full_routes"]
    full_products_by_target = plan["full_product_by_target"]
    full_target_by_product = plan["full_target_by_product"]
    full_authorized = plan["full_authorized_targets"]
    active_products = plan.get("products")
    active_authorized = plan.get("authorized_targets")
    golden_targets = plan["golden_targets"]
    active_shadow = plan["active_shadow_targets"]
    if (
        type(full_products) not in (tuple, list)
        or not EXPECTED_TARGET_COUNT < len(full_products) <= MAX_PLAN_TARGETS
        or len(set(full_products)) != len(full_products)
        or type(full_targets_raw) not in (tuple, list)
        or len(full_targets_raw) != len(full_products)
        or any(type(target) is not str or not target for target in full_targets_raw)
        or len(set(full_targets_raw)) != len(full_targets_raw)
        or not isinstance(full_routes, Mapping)
        or not isinstance(full_products_by_target, Mapping)
        or not isinstance(full_target_by_product, Mapping)
        or type(full_authorized) not in (tuple, list)
        or len(set(full_authorized)) != len(full_authorized)
        or any(type(target) is not str or not target for target in full_authorized)
        or not set(full_authorized).issubset(set(full_targets_raw))
        or type(golden_targets) not in (tuple, list)
        or type(active_shadow) not in (tuple, list)
        or len(golden_targets) != EXPECTED_TARGET_COUNT
        or len(active_shadow) != EXPECTED_TARGET_COUNT
        or len(set(golden_targets)) != EXPECTED_TARGET_COUNT
        or len(set(active_shadow)) != EXPECTED_TARGET_COUNT
        or set(golden_targets) != set(active["targets"])
        or set(active_shadow) != set(active["targets"])
        or set(golden_targets) != set(active_shadow)
        or type(active_products) not in (tuple, list)
        or len(active_products) != EXPECTED_TARGET_COUNT
        or len(set(active_products)) != EXPECTED_TARGET_COUNT
        or set(active_products)
        != {plan["product_by_target"][target] for target in active["targets"]}
        or type(active_authorized) not in (tuple, list)
    ):
        _fail("PLAN_GOLDEN_SELECTION_INVALID")

    full_targets = tuple(full_targets_raw)
    expected_full_products_by_target = {}
    expected_full_target_by_product = {}
    expected_full_routes_by_target = {}
    for product in full_products:
        exchange = _text(
            getattr(product, "exchange_id", None), "PLAN_GOLDEN_PRODUCT_INVALID"
        )
        product_id = _text(
            getattr(product, "product_id", None), "PLAN_GOLDEN_PRODUCT_INVALID"
        )
        target = f"{exchange}.{product_id}"
        if target in expected_full_target_by_product.values():
            _fail("PLAN_GOLDEN_PRODUCT_INVALID")
        expected_full_products_by_target[target] = product
        expected_full_target_by_product[product] = target
        expected_full_routes_by_target[target] = _text(
            full_routes.get(product), "PLAN_GOLDEN_ROUTE_INVALID"
        )
    if (
        tuple(expected_full_products_by_target) != full_targets
        or dict(full_products_by_target) != expected_full_products_by_target
        or dict(full_target_by_product) != expected_full_target_by_product
        or set(full_routes) != set(full_products)
        or set(active["targets"]).difference(full_targets)
    ):
        _fail("PLAN_GOLDEN_PRODUCT_ROUTE_MISMATCH")

    manifest = plan.get("manifest")
    selected_mapping = getattr(manifest, "selected_mapping", None)
    target_products = getattr(manifest, "target_products", None)
    try:
        route_pairs = selected_mapping() if callable(selected_mapping) else None
    except Exception:
        route_pairs = None
    if type(route_pairs) is not tuple or type(target_products) is not tuple:
        _fail("PLAN_GOLDEN_MANIFEST_INVALID")
    manifest_routes = {}
    for pair in route_pairs:
        if type(pair) is not tuple or len(pair) != 2:
            _fail("PLAN_GOLDEN_MANIFEST_INVALID")
        product, instrument = pair
        try:
            if product in manifest_routes:
                _fail("PLAN_GOLDEN_MANIFEST_INVALID")
            manifest_routes[product] = _text(
                instrument, "PLAN_GOLDEN_MANIFEST_INVALID"
            )
        except _PostflightFailure:
            raise
        except Exception:
            _fail("PLAN_GOLDEN_MANIFEST_INVALID")
    if (
        dict(manifest_routes) != dict(full_routes)
        or set(target_products) != set(full_products)
    ):
        _fail("PLAN_GOLDEN_MANIFEST_MISMATCH")

    if (
        set(active["route_by_target"])
        != set(active["targets"])
        or any(
            active["route_by_target"][target]
            != expected_full_routes_by_target[target]
            for target in active["targets"]
        )
        or set(active_products)
        != {expected_full_products_by_target[target] for target in active["targets"]}
        or dict(plan.get("routes", {}))
        != {product: full_routes[product] for product in active_products}
    ):
        _fail("PLAN_GOLDEN_ACTIVE_PROJECTION_MISMATCH")
    expected_active_authorized = tuple(
        target for target in full_authorized if target in set(active["targets"])
    )
    if tuple(active_authorized) != expected_active_authorized:
        _fail("PLAN_GOLDEN_AUTHORIZATION_MISMATCH")

    full_grid = plan.get("full_grid")
    try:
        full_projection = _plan_projection(
            runner,
            {
                "selection_source": plan["selection_source"],
                "selection_path": plan["selection_path"],
                "source_snapshot_id": plan["source_snapshot_id"],
                "targets": full_targets,
                "product_by_target": full_products_by_target,
                "target_by_product": full_target_by_product,
                "routes": full_routes,
                "grid": full_grid,
                "manifest": manifest,
            },
            clock_domain_id=clock_domain_id,
            calendar_id=calendar_id,
            target_count=len(full_targets),
        )
    except _PostflightFailure:
        raise
    except Exception:
        _fail("PLAN_GOLDEN_GRID_INVALID")
    if (
        len(active["by_close"]) != EXPECTED_ACTIVE_GRID_MINUTES
        or len(full_projection["by_close"]) != EXPECTED_FULL_GRID_MINUTES
        or active["grid_semantics_sha256"] == full_projection["grid_semantics_sha256"]
    ):
        _fail("PLAN_GOLDEN_GRID_RELATION_INVALID")
    return {
        "full_targets": full_targets,
        "full_routes_by_target": expected_full_routes_by_target,
        "full_authorized_targets": tuple(full_authorized),
        "full_projection": full_projection,
    }


def _check_raw_values(value: Any) -> None:
    values = _mapping(value, "TAPE_RAW_VALUES_INVALID")
    if set(values) != OHLCV_FIELDS:
        _fail("TAPE_RAW_FIELDS_INVALID")
    numbers = {
        field: _number(
            values[field],
            "TAPE_RAW_VALUE_INVALID",
            nonnegative=field in {"volume", "openinterest"},
        )
        for field in OHLCV_FIELDS
    }
    if (
        min(numbers[field] for field in ("open", "high", "low", "close")) <= 0
        or numbers["high"] < max(numbers["open"], numbers["close"], numbers["low"])
        or numbers["low"] > min(numbers["open"], numbers["close"], numbers["high"])
    ):
        _fail("TAPE_RAW_OHLC_INVALID")


def _check_factor_block(
    row: Mapping[str, Any], members: Mapping[str, Mapping[str, Any]], targets: tuple[str, ...], header: Mapping[str, Any]
) -> tuple[str, str]:
    block = _mapping(row.get("factors"), "TAPE_FACTORS_INVALID")
    if set(block) != {"plan_id", "factors"}:
        _fail("TAPE_FACTORS_INVALID")
    plan_id = _text(block["plan_id"], "TAPE_FACTOR_PLAN_INVALID")
    factors = _mapping(block["factors"], "TAPE_FACTORS_INVALID")
    if set(factors) != {"alpha003"}:
        _fail("TAPE_FACTOR_MEMBERSHIP_INVALID")
    factor = _mapping(factors["alpha003"], "TAPE_FACTOR_INVALID")
    if set(factor) != {"mode", "panel_line", "direction", "source_sha256", "values"}:
        _fail("TAPE_FACTOR_INVALID")
    if (
        factor["mode"] != header.get("factor_mode")
        or factor["panel_line"] != "factor"
        or type(factor["direction"]) is not int
        or factor["direction"] != header.get("direction")
    ):
        _fail("TAPE_FACTOR_BINDING_INVALID")
    source_sha256 = _sha256(factor["source_sha256"], "TAPE_FACTOR_SOURCE_INVALID")
    values = _mapping(factor["values"], "TAPE_FACTOR_VALUES_INVALID")
    if set(values) != set(targets):
        _fail("TAPE_FACTOR_MEMBERSHIP_INVALID")
    for target in targets:
        point = _mapping(values[target], "TAPE_FACTOR_POINT_INVALID")
        if set(point) != FACTOR_POINT_FIELDS:
            _fail("TAPE_FACTOR_POINT_INVALID")
        value_row = _mapping(point["value"], "TAPE_FACTOR_VALUE_INVALID")
        if set(value_row) != {"finite", "value", "float64_hex"} or type(value_row["finite"]) is not bool:
            _fail("TAPE_FACTOR_VALUE_INVALID")
        if value_row["finite"]:
            number = _number(value_row["value"], "TAPE_FACTOR_VALUE_INVALID")
            if number.hex() != value_row["float64_hex"]:
                _fail("TAPE_FACTOR_VALUE_INVALID")
            available = True
        else:
            if value_row["value"] is not None or value_row["float64_hex"] != "nan":
                _fail("TAPE_FACTOR_VALUE_INVALID")
            available = False
        if (
            point["status"] != ("OUTPUT_AVAILABLE" if available else "OUTPUT_UNAVAILABLE")
            or (point["reason"] is None) != available
            or (point["reason"] is not None and type(point["reason"]) is not str)
            or type(point["present"]) is not bool
            or type(point["complete"]) is not bool
            or point["present"] is not True
            or point["complete"] is not True
            or point["quality"] != "GOOD"
            or point["source_role"] != "live"
            or point["member_id"] != target
            or point["source_ref"] != members[target]["source_ref"]
            or type(point["sequence"]) is not int
            or point["sequence"] != members[target]["feed_sequence"]
            or type(point["generation"]) is not int
            or point["generation"] != members[target]["connection_generation"]
        ):
            _fail("TAPE_FACTOR_RECEIPT_MISMATCH")
    return plan_id, source_sha256


def _expected_md_generation(summary: Mapping[str, Any]) -> int:
    resources = summary.get("resource_shutdown")
    if not isinstance(resources, list):
        _fail("CTP_SHUTDOWN_RECEIPT_MISSING")
    store_rows = [
        row
        for row in resources
        if isinstance(row, Mapping) and row.get("resource") == "store"
    ]
    if len(store_rows) != 1:
        _fail("CTP_SHUTDOWN_RECEIPT_MISSING")
    store = store_rows[0]
    shutdown = store.get("ctp_factor_source_shutdown")
    if (
        store.get("shutdown_state") != "PASS"
        or store.get("status") not in {"RETURNED", "CLOSED_BY_BROKER"}
        or not isinstance(shutdown, Mapping)
        or shutdown.get("required") is not True
        or shutdown.get("status") != "PASS"
        or shutdown.get("reason_codes") not in ((), [])
    ):
        _fail("CTP_SHUTDOWN_RECEIPT_INCOMPLETE")
    md_generation = shutdown.get("expected_md_generation")
    trader_generation = shutdown.get("expected_trader_generation")
    join_required = shutdown.get("join_required")
    if (
        type(md_generation) is not int
        or md_generation < 1
        or type(trader_generation) is not int
        or trader_generation < 1
        or type(join_required) is not bool
    ):
        _fail("CTP_SHUTDOWN_RECEIPT_INCOMPLETE")
    for key, generation in (
        ("md_receipt", md_generation),
        ("trader_receipt", trader_generation),
    ):
        receipt = shutdown.get(key)
        if (
            not isinstance(receipt, Mapping)
            or type(receipt.get("connection_generation")) is not int
            or receipt["connection_generation"] != generation
            or receipt.get("join_required") is not join_required
            or type(receipt.get("join_completed")) is not bool
            or receipt.get("native_released") is not True
            or receipt.get("thread_alive") is not False
            or receipt.get("timed_out") is not False
            or receipt.get("complete") is not True
            or (join_required and receipt.get("join_completed") is not True)
        ):
            _fail("CTP_SHUTDOWN_RECEIPT_INCOMPLETE")
    return md_generation


def _validate(
    runner: Any,
    summary: Mapping[str, Any],
    *,
    clock_domain_id: str,
    calendar_id: str,
    expected_cohort: Mapping[str, Any],
    normal_cleanup_complete: Any,
) -> dict[str, Any]:
    if normal_cleanup_complete is not True or summary.get("cleanup_complete") is not True:
        _fail("NORMAL_CLEANUP_NOT_CONFIRMED")
    if summary.get("status") != "LIVE_RUN_COMPLETE" or summary.get("mode") != "live":
        _fail("LIVE_SUMMARY_INCOMPLETE")
    if summary.get("source_clock_domain_id") != clock_domain_id:
        _fail("LIVE_CLOCK_DOMAIN_MISMATCH")
    if (
        set(expected_cohort) != EXPECTED_COHORT_FIELDS
        or type(expected_cohort.get("epoch_id")) is not int
        or expected_cohort["epoch_id"] < 1
        or type(expected_cohort.get("timezone_id")) is not str
        or not expected_cohort["timezone_id"]
        or type(summary.get("epoch_id")) is not int
        or summary["epoch_id"] != expected_cohort["epoch_id"]
    ):
        _fail("LIVE_EPOCH_INVALID")
    expected_cohort_id = _text(expected_cohort.get("cohort_id"), "EXPECTED_COHORT_INVALID")
    expected_calendar_version = _text(
        expected_cohort.get("calendar_version"), "EXPECTED_COHORT_INVALID"
    )
    expected_timezone_id = expected_cohort["timezone_id"]
    expected_md_generation = _expected_md_generation(summary)
    plan = _mapping(summary.get("_plan"), "SAME_RUN_PLAN_MISSING")
    projection = _plan_projection(
        runner, plan, clock_domain_id=clock_domain_id, calendar_id=calendar_id
    )
    golden = _golden_plan_projection(
        runner,
        plan,
        projection,
        clock_domain_id=clock_domain_id,
        calendar_id=calendar_id,
    )
    targets = projection["targets"]
    if summary.get("selection_source") != plan.get("selection_source"):
        _fail("LIVE_PLAN_BINDING_MISMATCH")
    if summary.get("source_snapshot_id") != projection["source_snapshot_id"]:
        _fail("LIVE_PLAN_BINDING_MISMATCH")
    if summary.get("routes") != projection["route_by_target"]:
        _fail("LIVE_PLAN_BINDING_MISMATCH")

    writer = _mapping(summary.get("decision_tape"), "TAPE_SUMMARY_MISSING")
    readback = _mapping(summary.get("decision_tape_readback"), "TAPE_READBACK_MISSING")
    file_id = _text(writer.get("file_id"), "TAPE_FILE_ID_INVALID")
    max_bytes = writer.get("max_bytes")
    expected_bytes = writer.get("bytes")
    expected_count = writer.get("record_count")
    if (
        type(max_bytes) is not int
        or not 1 <= max_bytes <= MAX_TAPE_BYTES
        or type(expected_bytes) is not int
        or not 1 <= expected_bytes <= max_bytes
        or type(expected_count) is not int
        or expected_count < 3
        or writer.get("closed") is not True
        or writer.get("failed") is not False
    ):
        _fail("TAPE_NOT_CLOSED_CLEANLY")
    expected_sha = _sha256(writer.get("sha256"), "TAPE_SHA256_INVALID")
    raw_path = _text(writer.get("path"), "TAPE_PATH_INVALID")
    path = Path(raw_path)
    if not path.is_absolute() or path.is_symlink() or not path.is_file():
        _fail("TAPE_PATH_INVALID")
    try:
        before = path.stat()
    except OSError:
        _fail("TAPE_PATH_INVALID")
    if before.st_size != expected_bytes:
        _fail("TAPE_BYTE_COUNT_MISMATCH")

    if (
        readback.get("file_id") != file_id
        or type(readback.get("record_count")) is not int
        or readback["record_count"] != expected_count
        or type(readback.get("actual_bytes")) is not int
        or readback["actual_bytes"] != expected_bytes
        or readback.get("last_record_reference") != writer.get("last_record_reference")
    ):
        _fail("TAPE_READBACK_MISMATCH")

    size_before, digest_before = _raw_hash(path, max_bytes)
    if size_before != expected_bytes or digest_before != expected_sha:
        _fail("TAPE_PIN_MISMATCH")

    epoch_id = summary["epoch_id"]
    try:
        evidence = runner._selection_evidence(plan, epoch_id=epoch_id, max_bytes=max_bytes)
    except Exception:
        _fail("PLAN_SELECTION_EVIDENCE_INVALID")
    if summary.get("selection_evidence") != evidence:
        _fail("SUMMARY_SELECTION_BINDING_MISMATCH")
    if (
        evidence.get("full_selected_targets")
        != sorted(plan.get("full_selected_targets", ()))
        or summary.get("full_selected_targets") != list(plan.get("full_selected_targets", ()))
        or summary.get("active_shadow_targets") != list(plan.get("active_shadow_targets", ()))
        or evidence.get("routes") != golden["full_routes_by_target"]
        or evidence.get("authorized_targets")
        != sorted(golden["full_authorized_targets"])
        or evidence.get("active_shadow_targets") != sorted(targets)
        or evidence.get("active_routes") != projection["route_by_target"]
        or evidence.get("active_authorized_targets")
        != sorted(plan["authorized_targets"])
        or evidence.get("grid_semantics_sha256")
        != golden["full_projection"]["grid_semantics_sha256"]
        or evidence.get("active_grid_semantics_sha256")
        != projection["grid_semantics_sha256"]
    ):
        _fail("SUMMARY_SELECTION_BINDING_MISMATCH")

    try:
        iterator = iter(runner.iter_decision_tape(path, max_bytes=max_bytes))
        header = next(iterator)
    except StopIteration:
        _fail("TAPE_HEADER_MISSING")
    except Exception:
        _fail("TAPE_ITERATOR_REJECTED")
    if (
        header.get("record_type") != "HEADER"
        or header.get("mode") != "live"
        or header.get("file_id") != file_id
        or header.get("calendar_id") != projection["calendar_id"]
        or header.get("source_snapshot_id") != projection["source_snapshot_id"]
        or header.get("targets") != list(targets)
        or header.get("grid_sha256") != projection["grid_hash"]
        or header.get("factor_mode") != summary.get("factor_mode")
        or type(header.get("direction")) is not int
        or header["direction"] not in (-1, 1)
        or header.get("selection_evidence") != evidence
    ):
        _fail("TAPE_HEADER_BINDING_MISMATCH")

    previous_record_index = 0
    previous_slot_index = None
    previous_plan_index = None
    previous_received: dict[str, int] = {}
    previous_sequence: dict[str, int] = {}
    source_identity: dict[str, tuple[Any, ...]] = {}
    bar_ids: dict[str, set[str]] = {target: set() for target in targets}
    seen_batches: set[str] = set()
    factor_plan_id = None
    factor_source_sha256 = None
    count = 0
    consecutive = 0
    longest_consecutive = 0
    last_reference = None
    target_set = set(targets)

    def consume(row: Mapping[str, Any]) -> None:
        nonlocal previous_record_index, previous_slot_index, previous_plan_index
        nonlocal factor_plan_id, factor_source_sha256
        nonlocal count, consecutive, longest_consecutive, last_reference
        count += 1
        if count > expected_count:
            _fail("TAPE_RECORD_COUNT_MISMATCH")
        record_index = row.get("record_index")
        slot_index = row.get("slot_index")
        if (
            row.get("record_type") != "DECISION"
            or type(record_index) is not int
            or record_index != previous_record_index + 1
            or type(slot_index) is not int
            or slot_index < 0
            or row.get("file_id") != file_id
            or row.get("calendar_id") != projection["calendar_id"]
        ):
            _fail("TAPE_RECORD_IDENTITY_INVALID")
        previous_record_index = record_index
        close_at = _utc(runner, row.get("close_time"), "TAPE_CLOSE_TIME_INVALID")
        planned = projection["by_close"].get(close_at)
        if planned is None:
            _fail("TAPE_CLOSE_NOT_IN_PLAN")
        plan_index = planned["slot_index"]
        if previous_slot_index is not None and slot_index <= previous_slot_index:
            _fail("TAPE_SLOT_ORDER_INVALID")
        if previous_plan_index is not None and plan_index <= previous_plan_index:
            _fail("TAPE_PLAN_SLOT_ORDER_INVALID")

        current_cohort = _text(row.get("cohort_id"), "TAPE_COHORT_INVALID")
        current_batch = _text(row.get("batch_id"), "TAPE_BATCH_INVALID")
        current_calendar_version = _text(
            row.get("calendar_version"), "TAPE_CALENDAR_VERSION_INVALID"
        )
        if type(row.get("epoch_id")) is not int or row["epoch_id"] != epoch_id:
            _fail("TAPE_EPOCH_BINDING_MISMATCH")
        if (
            current_cohort != expected_cohort_id
            or current_calendar_version != expected_calendar_version
        ):
            _fail("TAPE_COHORT_BINDING_MISMATCH")
        if current_batch in seen_batches:
            _fail("TAPE_BATCH_DUPLICATED")
        seen_batches.add(current_batch)
        available_at = _utc(runner, row.get("available_at"), "TAPE_AVAILABILITY_INVALID")
        if available_at < close_at:
            _fail("TAPE_AVAILABILITY_INVALID")
        if (
            row.get("header_record_id") != header.get("record_id")
            or row.get("selection_evidence_sha256") != evidence.get("binding_sha256")
        ):
            _fail("TAPE_HEADER_BINDING_MISMATCH")
        readiness = row.get("readiness")
        readiness_reasons = row.get("readiness_reasons")
        if (
            readiness not in {"WARMUP", "LIVE_READY"}
            or type(readiness_reasons) is not list
            or any(type(reason) is not str or not reason for reason in readiness_reasons)
            or (readiness == "LIVE_READY" and readiness_reasons)
        ):
            _fail("TAPE_READINESS_INVALID")

        members = _mapping(row.get("members"), "TAPE_MEMBERS_INVALID")
        if set(members) != target_set:
            _fail("TAPE_MEMBER_SET_INVALID")
        member_rows: dict[str, Mapping[str, Any]] = {}
        slot_ids = set()
        for target in targets:
            member = _mapping(members[target], "TAPE_MEMBER_INVALID")
            if set(member) != MEMBER_FIELDS:
                _fail("TAPE_MEMBER_FIELDS_INVALID")
            planned_member = planned["members"][target]
            member_close = _utc(runner, member["close_time"], "TAPE_MEMBER_TIME_INVALID")
            bucket_start = _utc(runner, member["bucket_start"], "TAPE_MEMBER_BUCKET_INVALID")
            member_available = _utc(
                runner, member["available_at"], "TAPE_MEMBER_AVAILABILITY_INVALID"
            )
            expected_slot_id = f"minute:{close_at.isoformat()}"
            expected_source_ref = f"ctp-live:{target}:{planned_member['instrument']}"
            if member["slot_id"] != expected_slot_id:
                _fail("TAPE_MEMBER_SLOT_PLAN_MISMATCH")
            if member["source_ref"] != expected_source_ref:
                _fail("TAPE_MEMBER_SOURCE_INVALID")
            if (
                member["cohort_id"] != expected_cohort_id
                or member["calendar_id"] != projection["calendar_id"]
                or type(member["epoch_id"]) is not int
                or member["epoch_id"] != epoch_id
                or type(member["slot_index"]) is not int
                or member["slot_index"] != slot_index
                or member_close != close_at
                or bucket_start != planned_member["bucket_start"]
                or member["instrument"] != planned_member["instrument"]
                or _day(runner, member["trading_day"], "TAPE_MEMBER_DAY_INVALID")
                != planned_member["trading_day"]
                or member["session_segment"] != planned_member["session_segment"]
                or member["clock_domain_id"] != projection["clock_domain_id"]
                or member["timezone_id"] != expected_timezone_id
                or member["complete"] is not True
                or member["present"] is not True
                or member["quality"] != "GOOD"
                or member["quality_flags"] != []
                or member_available < close_at
                or member_available > available_at
            ):
                _fail("TAPE_MEMBER_PLAN_OR_QUALITY_MISMATCH")
            if (
                _text(member["source_role"], "TAPE_MEMBER_SOURCE_INVALID") != "live"
                or _text(member["source_ref"], "TAPE_MEMBER_SOURCE_INVALID")
                != expected_source_ref
                or not _text(member["timezone_id"], "TAPE_MEMBER_SOURCE_INVALID")
                or not _text(member["event_source"], "TAPE_MEMBER_SOURCE_INVALID")
            ):
                _fail("TAPE_MEMBER_SOURCE_INVALID")
            bar_id = _text(member["bar_id"], "TAPE_MEMBER_BAR_INVALID")
            if bar_id in bar_ids[target]:
                _fail("TAPE_MEMBER_BAR_DUPLICATED")
            bar_ids[target].add(bar_id)
            slot_ids.add(_text(member["slot_id"], "TAPE_MEMBER_SLOT_INVALID"))
            generation = member["connection_generation"]
            sequence = member["feed_sequence"]
            received = member["received_monotonic_ns"]
            if (
                type(generation) is not int
                or generation < 1
                or type(sequence) is not int
                or sequence < 1
                or type(received) is not int
                or received < 1
            ):
                _fail("TAPE_MEMBER_SEQUENCE_INVALID")
            if generation != expected_md_generation:
                _fail("TAPE_MEMBER_GENERATION_MISMATCH")
            identity = (
                generation,
                member["source_role"],
                member["source_ref"],
                member["timezone_id"],
                member["event_source"],
            )
            if target in source_identity and source_identity[target] != identity:
                _fail("TAPE_MEMBER_SOURCE_CHANGED")
            if sequence <= previous_sequence.get(target, 0):
                _fail("TAPE_MEMBER_SEQUENCE_ORDER_INVALID")
            if received < previous_received.get(target, 0):
                _fail("TAPE_MEMBER_RECEIPT_ORDER_INVALID")
            source_identity[target] = identity
            previous_sequence[target] = sequence
            previous_received[target] = received
            _check_raw_values(member["raw_values"])
            member_rows[target] = member
        if len(slot_ids) != 1:
            _fail("TAPE_MEMBER_SLOT_MISMATCH")

        current_plan_id, current_factor_sha = _check_factor_block(
            row, member_rows, targets, header
        )
        if factor_plan_id is None:
            factor_plan_id = current_plan_id
            factor_source_sha256 = current_factor_sha
        elif factor_plan_id != current_plan_id or factor_source_sha256 != current_factor_sha:
            _fail("TAPE_FACTOR_SOURCE_CHANGED")

        if (
            previous_slot_index is not None
            and slot_index == previous_slot_index + 1
            and previous_plan_index is not None
            and plan_index == previous_plan_index + 1
        ):
            consecutive += 1
        else:
            consecutive = 1
        longest_consecutive = max(longest_consecutive, consecutive)
        previous_slot_index = slot_index
        previous_plan_index = plan_index
        last_reference = {
            "file_id": file_id,
            "record_id": row.get("record_id"),
            "record_index": record_index,
            "batch_id": current_batch,
        }

    try:
        for row in iterator:
            consume(row)
    except _PostflightFailure:
        raise
    except Exception:
        _fail("TAPE_ITERATOR_REJECTED")
    if count != expected_count or count < 3:
        _fail("TAPE_RECORD_COUNT_MISMATCH")
    if longest_consecutive < 3:
        _fail("THREE_CONSECUTIVE_COHORTS_MISSING")
    if last_reference != writer.get("last_record_reference"):
        _fail("TAPE_LAST_RECORD_MISMATCH")

    size_after, digest_after = _raw_hash(path, max_bytes)
    try:
        after = path.stat()
    except OSError:
        _fail("TAPE_PATH_INVALID")
    if (
        size_after != expected_bytes
        or digest_after != expected_sha
        or after.st_size != before.st_size
        or after.st_mtime_ns != before.st_mtime_ns
    ):
        _fail("TAPE_CHANGED_DURING_VALIDATION")
    return {
        "status": "PASS",
        "evidence_level": "SAME_RUN_GOLDEN_TAPE_POSTFLIGHT_ONLY",
        "normal_cleanup_complete": True,
        "tape_closed": True,
        "tape_failed": False,
        "tape_pin_matches": True,
        "tape_readback_matches": True,
        "target_count": len(targets),
        "planned_minute_count": len(projection["by_close"]),
        "full_selected_target_count": len(golden["full_targets"]),
        "full_grid_minute_count": len(golden["full_projection"]["by_close"]),
        "decision_record_count": count,
        "longest_consecutive_complete_cohorts": longest_consecutive,
        "clock_domain_matches": True,
        "calendar_matches": True,
        "native_md_generation_matches": True,
    }


def validate_golden_postflight(
    runner_module: Any,
    summary: Any,
    *,
    clock_domain_id: str,
    calendar_id: str,
    expected_cohort: Mapping[str, Any],
    normal_cleanup_complete: Any,
) -> dict[str, Any]:
    """Return only sanitized facts for one closed same-run golden DecisionTape."""
    try:
        result = _validate(
            runner_module,
            _mapping(summary, "LIVE_SUMMARY_INVALID"),
            clock_domain_id=clock_domain_id,
            calendar_id=calendar_id,
            expected_cohort=_mapping(expected_cohort, "EXPECTED_COHORT_INVALID"),
            normal_cleanup_complete=normal_cleanup_complete,
        )
        return result
    except _PostflightFailure as error:
        return {"status": "FAIL", "code": error.code}
    except Exception:
        return {"status": "FAIL", "code": "POSTFLIGHT_VALIDATION_FAILED"}
