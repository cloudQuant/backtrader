"""Reuse the verified wheel; repair only the console-script RECORD path check."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

prior = Path('D:/temp/i51-ctp-factor-installed-20261027-r2')
out = Path('D:/temp/i51-ctp-factor-installed-20261027-r3')
consumer = Path('D:/temp/i51-ctp-nojoin-consumer-20261027-r1/consumer')
state = json.loads((prior / 'run.json').read_text(encoding='utf-8'))
assert state['failure_code'] == 'installed-focus_failed'
assert state['wheel_python_payload_files'] == 663
assert [c['phase'] for c in state['commands'] if c['exit_code']] == ['installed-focus']
assert not out.exists()

def pin(path):
    raw = path.read_bytes()
    return {'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

wheel = Path(state['backtrader_wheel']['path'])
assert pin(wheel) == {k: state['backtrader_wheel'][k] for k in ('size_bytes', 'sha256')}
for row in state['fixture_files']:
    assert pin(Path(row['path'])) == {k: row[k] for k in ('size_bytes', 'sha256')}
for relative, row in state['sdk_record_pins_after'].items():
    assert pin(consumer / 'Lib/site-packages' / relative) == {k: row[k] for k in ('size_bytes', 'sha256')}
child = (prior / 'installed_focus.py').read_text(encoding='utf-8')
old = '    if not within(installed, site) or not installed.is_file():\n'
new = '''    console_launcher = (
        relative == "../../Scripts/bt-runtime.exe"
        and installed == (consumer / "Scripts/bt-runtime.exe").resolve()
        and dist.read_text("entry_points.txt").strip()
        == "[console_scripts]\\nbt-runtime = backtrader_runtime.cli:main"
    )
    if not (within(installed, site) or console_launcher) or not installed.is_file():
'''
assert child.count(old) == 1
child = child.replace(old, new)
out.mkdir()
(out / 'installed_focus.py').write_text(child, encoding='utf-8')
env = {name: value for name, value in os.environ.items()
       if name.upper() not in {'PYTHONPATH', 'PYTHONHOME', 'BT_CTP_TEST_SELECTOR_SOURCE',
                               'BT_CTP_TEST_QUERY_SOURCE', 'BT_CTP_TEST_INSTRUMENT_SOURCE'}}
env.update(PYTHONUTF8='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONNOUSERSITE='1')
command = [str(consumer / 'Scripts/python.exe'), '-I', str(out / 'installed_focus.py'),
           str(consumer), str(prior / 'fixtures'), str(wheel), str(out),
           str(prior / 'pytest.ini'), *state['nodes']]
record = {'parent_run': str(prior / 'run.json'), 'wheel_reused': state['backtrader_wheel'],
          'command': command, 'child': pin(out / 'installed_focus.py'),
          'scope': 'INSTALLED_SYNTHETIC_COMPONENTS_ONLY'}
with (out / 'stdout.txt').open('wb') as stdout, (out / 'stderr.txt').open('wb') as stderr:
    completed = subprocess.run(command, cwd=out, env=env, stdout=stdout, stderr=stderr, timeout=240)
record['exit_code'] = completed.returncode
record['fixture_files_unchanged'] = all(
    pin(Path(row['path'])) == {k: row[k] for k in ('size_bytes', 'sha256')}
    for row in state['fixture_files'])
record['sdk_record_pins_unchanged'] = all(
    pin(consumer / 'Lib/site-packages' / relative) == {k: row[k] for k in ('size_bytes', 'sha256')}
    for relative, row in state['sdk_record_pins_after'].items())
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
assert record['fixture_files_unchanged'] and record['sdk_record_pins_unchanged']
print(json.dumps({'exit_code': completed.returncode,
                  'fixture_files_unchanged': record['fixture_files_unchanged'],
                  'sdk_record_pins_unchanged': record['sdk_record_pins_unchanged']}))
raise SystemExit(completed.returncode)
