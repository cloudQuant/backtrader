"""Draft: build and check the two accepted CTP-factor installed nodes.

Root supplies the accepted commit and source SHA-256 pins on the command line.
Do not run before that source round is accepted and committed.
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time
import zipfile


ROOT = Path(r"D:/source_code/backtrader")
CONSUMER = Path(r"D:/temp/i51-ctp-nojoin-consumer-20261027-r1/consumer")
BUILD_PYTHON = Path(r"C:/anaconda3/python.exe")
SDK_RECORD_PINS = {
    "bt_api_base-0.15.8.dist-info/RECORD": (
        15821,
        "6284d7236b283cbcc5599d2ad14e5ab81d83d93ee641392ef612acbe1df54dda",
    ),
    "bt_api_ctp-2.0.4+iteration41.i9.dist-info/RECORD": (
        14197,
        "928671c3cb7f211f2157b183e9d033e7afdddfbea153d6f4eba995e87956e8a1",
    ),
}
PACKAGE_PIN_PATHS = (
    "backtrader/stores/btapistore.py",
    "backtrader/stores/registered_sim.py",
    "backtrader/feeds/btapifeed.py",
    "backtrader/feeds/ctp_factor_source.py",
    "backtrader/feeds/futures_sessions.py",
    "backtrader/feeds/futures_main_contract.py",
    "backtrader/research/live_cohort.py",
)
EXAMPLE = "examples/unified/028_alpha003_simnow_minute"
FIXTURE_PATHS = (
    "tests/__init__.py",
    "tests/integration/__init__.py",
    "tests/integration/test_ctp_factor_source_cohort.py",
    "tests/unit/test_alpha003_simnow_runner.py",
    "tests/unit/feeds/__init__.py",
    "tests/unit/feeds/test_futures_sessions.py",
    "tests/unit/stores/test_factor_execution_facts.py",
    f"{EXAMPLE}/run.py",
    f"{EXAMPLE}/entry_tier.py",
    f"{EXAMPLE}/alpha003_strategy.py",
    f"{EXAMPLE}/config.yaml",
)
PIN_PATHS = frozenset((*PACKAGE_PIN_PATHS, *FIXTURE_PATHS))
ARCHIVE_PATHS = (
    "setup.py",
    "pyproject.toml",
    "README.md",
    "LICENSE",
    "backtrader",
    "backtrader_runtime",
    *FIXTURE_PATHS,
)
NODE_IDS = (
    "tests/integration/test_ctp_factor_source_cohort.py::"
    "test_registered_sim_ctp_callbacks_aggregate_two_product_overnight_cohort",
    "tests/unit/test_alpha003_simnow_runner.py::"
    "test_live_two_epoch_uses_real_three_route_cerebro_and_closes_before_next_bundle[same-store-query-live]",
)


class CheckFailure(RuntimeError):
    pass


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def pin(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": str(path), "size_bytes": len(raw), "sha256": sha256_bytes(raw)}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--source-pin", action="append", required=True, metavar="PATH=SHA256")
    parser.add_argument("--out", required=True, type=Path, help="new external evidence directory")
    return parser.parse_args()


def parse_source_pins(values):
    pins = {}
    for value in values:
        path, separator, digest = value.rpartition("=")
        rel = PurePosixPath(path)
        if not separator or rel.is_absolute() or ".." in rel.parts:
            raise CheckFailure("invalid_source_pin_argument")
        if len(digest) != 64 or any(c not in "0123456789abcdefABCDEF" for c in digest):
            raise CheckFailure("invalid_source_pin_digest")
        if path in pins:
            raise CheckFailure("duplicate_source_pin_path")
        pins[path] = digest.lower()
    if frozenset(pins) != PIN_PATHS:
        raise CheckFailure("source_pin_path_set_mismatch")
    return pins


def save(state, out):
    (out / "run.json").write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def run(state, out, label, command, *, cwd, timeout=300, allow_failure=False, env=None):
    log = out / f"{label}.log"
    started = time.monotonic()
    with log.open("wb") as stream:
        try:
            completed = subprocess.run(
                command,
                cwd=cwd,
                env=env,
                stdout=stream,
                stderr=subprocess.STDOUT,
                timeout=timeout,
                check=False,
            )
        except subprocess.TimeoutExpired:
            state["commands"].append({
                "phase": label, "command": command, "timed_out": True,
                "timeout_seconds": timeout, "elapsed_seconds": time.monotonic() - started,
                "log": pin(log),
            })
            save(state, out)
            raise CheckFailure(label + "_timeout") from None
    record = {
        "phase": label,
        "command": command,
        "exit_code": completed.returncode,
        "elapsed_seconds": time.monotonic() - started,
        "log": pin(log),
    }
    state["commands"].append(record)
    save(state, out)
    if completed.returncode and not allow_failure:
        raise CheckFailure(label + "_failed")
    return completed.returncode


WINDOWS_RUNTIME_ENV = frozenset(
    {
        "PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "USERPROFILE", "HOMEDRIVE",
        "HOMEPATH", "APPDATA", "LOCALAPPDATA", "COMSPEC", "PATHEXT",
        "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER", "NUMBER_OF_PROCESSORS",
    }
)


def main():
    args = parse_args()
    if len(args.expected_commit) != 40 or any(c not in "0123456789abcdefABCDEF" for c in args.expected_commit):
        raise CheckFailure("invalid_expected_commit")
    pins = parse_source_pins(args.source_pin)
    out = args.out.resolve()
    if out.exists() or not out.parent.is_dir():
        raise CheckFailure("output_path_not_fresh_or_parent_missing")
    out.mkdir()
    state = {
        "schema": "i51_ctp_factor_installed_focus_v1",
        "status": "RUNNING",
        "expected_commit": args.expected_commit.lower(),
        "consumer": str(CONSUMER),
        "nodes": list(NODE_IDS),
        "source_pins": pins,
        "commands": [],
        "pytest_prerequisite": "pytest and PyYAML already present in fixed consumer; script does not install them",
        "account_provider_native_claim": "NONE; selected nodes use synthetic SDK/provider leaves",
        "retained_i51cal_consumer_touched": False,
    }
    save(state, out)
    env = {
        name: value
        for name, value in os.environ.items()
        if name.upper() in WINDOWS_RUNTIME_ENV
    }
    env.update(
        PYTHONUTF8="1",
        PYTHONNOUSERSITE="1",
        PIP_CONFIG_FILE="NUL",
        PIP_NO_INDEX="1",
        PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
    )
    try:
        run(state, out, "checkout-head", ["git", "rev-parse", "HEAD"], cwd=ROOT, timeout=15, env=env)
        head = (out / "checkout-head.log").read_text(encoding="utf-8").strip().lower()
        if head != args.expected_commit.lower():
            raise CheckFailure("checkout_head_does_not_match_expected_commit")
        state["checkout_head"] = head
        save(state, out)

        consumer_python = CONSUMER / "Scripts" / "python.exe"
        if not consumer_python.is_file():
            raise CheckFailure("approved_consumer_interpreter_missing")
        pytest_preflight = run(
            state, out, "pytest-preflight",
            [
                str(consumer_python), "-I", "-c",
                "import sys, pytest, yaml; assert sys.version_info[:3] == (3, 11, 5); print(pytest.__version__)",
            ],
            cwd=out, timeout=30, allow_failure=True, env=env,
        )
        if pytest_preflight:
            state["status"] = "HOLD_FIXED_CONSUMER_PYTEST_YAML_PREREQUISITE"
            save(state, out)
            return 2

        archive = out / "source.zip"
        run(state, out, "archive", [
            "git", "archive", "--format=zip", "--output=" + str(archive),
            args.expected_commit, *ARCHIVE_PATHS,
        ], cwd=ROOT)
        state["source_archive"] = pin(archive)
        source = out / "source"
        source.mkdir()
        with zipfile.ZipFile(archive) as bundle:
            bundle.extractall(source)
        for relative, expected in pins.items():
            path = source.joinpath(*PurePosixPath(relative).parts)
            if not path.is_file() or sha256_bytes(path.read_bytes()) != expected:
                raise CheckFailure("committed_source_pin_mismatch")

        fixture_root = out / "fixtures"
        fixture_root.mkdir()
        for relative in FIXTURE_PATHS:
            src = source.joinpath(*PurePosixPath(relative).parts)
            dest = fixture_root.joinpath(*PurePosixPath(relative).parts)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
        if (fixture_root / "backtrader").exists() or (fixture_root / "conftest.py").exists():
            raise CheckFailure("fixture_tree_contains_source_or_repository_conftest")
        state["fixture_files"] = [pin(fixture_root.joinpath(*PurePosixPath(p).parts)) for p in FIXTURE_PATHS]
        save(state, out)

        wheelhouse = out / "wheelhouse"
        wheelhouse.mkdir()
        run(state, out, "wheel-build", [
            str(BUILD_PYTHON), "-I", "-m", "pip", "wheel", "--disable-pip-version-check",
            "--no-cache-dir", "--no-index", "--no-deps", "--no-build-isolation",
            "--wheel-dir", str(wheelhouse), str(source),
        ], cwd=out, timeout=900, env=env)
        wheels = list(wheelhouse.glob("*.whl"))
        if len(wheels) != 1:
            raise CheckFailure("wheel_count_not_one")
        wheel = wheels[0]
        state["backtrader_wheel"] = pin(wheel)
        expected_py = {
            p.relative_to(source).as_posix(): p.read_bytes()
            for package in ("backtrader", "backtrader_runtime")
            for p in (source / package).rglob("*.py")
        }
        with zipfile.ZipFile(wheel) as bundle:
            wheel_py = {
                name: bundle.read(name)
                for name in bundle.namelist()
                if name.startswith(("backtrader/", "backtrader_runtime/")) and name.endswith(".py")
            }
        if wheel_py != expected_py:
            raise CheckFailure("wheel_python_payload_differs_from_commit_archive")
        state["wheel_python_payload_files"] = len(wheel_py)
        save(state, out)

        site = CONSUMER / "Lib" / "site-packages"
        before_sdk_records = {}
        for relative, (size, digest) in SDK_RECORD_PINS.items():
            record = site.joinpath(*PurePosixPath(relative).parts)
            if not record.is_file() or record.stat().st_size != size or sha256_bytes(record.read_bytes()) != digest:
                raise CheckFailure("base_or_ctp_record_preinstall_pin_mismatch")
            before_sdk_records[relative] = pin(record)
        state["sdk_record_pins_before"] = before_sdk_records
        save(state, out)

        run(state, out, "backtrader-force-reinstall", [
            str(consumer_python), "-I", "-m", "pip", "install", "--disable-pip-version-check",
            "--no-index", "--force-reinstall", "--no-deps", str(wheel),
        ], cwd=out, timeout=300, env=env)
        after_sdk_records = {}
        for relative, before in before_sdk_records.items():
            record = site.joinpath(*PurePosixPath(relative).parts)
            after = pin(record)
            if after["size_bytes"] != before["size_bytes"] or after["sha256"] != before["sha256"]:
                raise CheckFailure("base_or_ctp_record_changed_by_backtrader_install")
            after_sdk_records[relative] = after
        state["sdk_record_pins_after"] = after_sdk_records
        run(state, out, "pip-check", [str(consumer_python), "-I", "-m", "pip", "check"],
            cwd=out, timeout=60, env=env)

        pytest_ini = out / "pytest.ini"
        pytest_ini.write_text("[pytest]\naddopts =\n", encoding="utf-8")
        (out / "installed_focus.py").write_text(INSTALLED_FOCUS, encoding="utf-8")
        test_tmp = out / "process-temp"
        test_tmp.mkdir()
        test_env = dict(env, TEMP=str(test_tmp), TMP=str(test_tmp), TMPDIR=str(test_tmp))
        run(state, out, "installed-focus", [
            str(consumer_python), "-I", str(out / "installed_focus.py"),
            str(CONSUMER), str(fixture_root), str(wheel), str(out), str(pytest_ini), *NODE_IDS,
        ], cwd=out, timeout=900, env=test_env)
        focus_result = out / "installed-focus.json"
        if not focus_result.is_file():
            raise CheckFailure("installed_focus_result_missing")
        state["installed_focus"] = json.loads(focus_result.read_text(encoding="utf-8"))
        state["installed_focus_result"] = pin(focus_result)
        state["junit"] = pin(out / "junit.xml")
        fixture_after = [pin(fixture_root.joinpath(*PurePosixPath(p).parts)) for p in FIXTURE_PATHS]
        if fixture_after != state["fixture_files"]:
            raise CheckFailure("fixture_tree_changed_during_focus")
        state["fixture_files_after"] = fixture_after
        final_sdk_records = {}
        for relative, before in before_sdk_records.items():
            record = site.joinpath(*PurePosixPath(relative).parts)
            after = pin(record)
            if after["size_bytes"] != before["size_bytes"] or after["sha256"] != before["sha256"]:
                raise CheckFailure("base_or_ctp_record_changed_during_focus")
            final_sdk_records[relative] = after
        state["sdk_record_pins_after_focus"] = final_sdk_records
        state["status"] = "PASS_TWO_INSTALLED_SYNTHETIC_NODES_ONLY"
        save(state, out)
        print(json.dumps({"status": state["status"], "wheel": state["backtrader_wheel"],
                          "nodes": list(NODE_IDS), "result": str(out / "run.json")}))
        return 0
    except BaseException as exc:
        state["status"] = "FAILED"
        state["failure_type"] = type(exc).__name__
        state["failure_code"] = str(exc) if isinstance(exc, CheckFailure) else "unclassified"
        save(state, out)
        raise


INSTALLED_FOCUS = r'''from __future__ import annotations

import base64
import csv
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile
import xml.etree.ElementTree as ET


def fail(code):
    raise RuntimeError(code)


def within(path, parent):
    try:
        Path(path).resolve().relative_to(Path(parent).resolve())
        return True
    except (OSError, ValueError):
        return False


if len(sys.argv) < 7:
    fail("installed_focus_arguments_invalid")
consumer, fixture_root, wheel, out, pytest_ini = (Path(value).resolve() for value in sys.argv[1:6])
node_specs = sys.argv[6:]
if not sys.flags.isolated or Path(sys.prefix).resolve() != consumer:
    fail("consumer_interpreter_isolation_mismatch")
site = (consumer / "Lib" / "site-packages").resolve()
if not site.is_dir() or not fixture_root.is_dir() or not wheel.is_file() or not pytest_ini.is_file():
    fail("installed_focus_input_missing")

import backtrader
import backtrader_runtime

if not within(backtrader.__file__, site / "backtrader"):
    fail("backtrader_initial_origin_not_consumer")
if not within(backtrader_runtime.__file__, site / "backtrader_runtime"):
    fail("backtrader_runtime_initial_origin_not_consumer")
repo = Path(r"D:/source_code/backtrader").resolve()
for entry in sys.path:
    if entry and within(entry, repo):
        fail("repository_path_present_before_fixture_import")
sys.path.insert(0, str(fixture_root))

dist = metadata.distribution("back-trader-python")
if dist.version != "1.4.0":
    fail("backtrader_distribution_version_mismatch")
record_rel = next((item for item in dist.files or () if str(item).endswith(".dist-info/RECORD")), None)
if record_rel is None:
    fail("backtrader_installed_record_missing")
record_path = Path(dist.locate_file(record_rel)).resolve()
if not within(record_path, site):
    fail("backtrader_record_origin_not_consumer")
record_entries = 0
with record_path.open("r", encoding="utf-8", newline="") as stream:
    for relative, encoded, size in csv.reader(stream):
        installed = Path(dist.locate_file(relative)).resolve()
        if not within(installed, site) or not installed.is_file():
            fail("backtrader_record_path_invalid")
        if encoded:
            algorithm, expected = encoded.split("=", 1)
            raw = installed.read_bytes()
            actual = base64.urlsafe_b64encode(hashlib.new(algorithm, raw).digest()).rstrip(b"=").decode("ascii")
            if actual != expected or size == "" or len(raw) != int(size):
                fail("backtrader_record_entry_mismatch")
        elif size and len(installed.read_bytes()) != int(size):
            fail("backtrader_unhashed_record_size_mismatch")
        record_entries += 1

package_members = {}
with zipfile.ZipFile(wheel) as bundle:
    for name in bundle.namelist():
        if name.endswith("/") or not name.startswith(("backtrader/", "backtrader_runtime/")):
            continue
        package_members[name] = bundle.read(name)
for name, expected in package_members.items():
    installed = (site / Path(*PurePosixPath(name).parts)).resolve()
    if not within(installed, site) or not installed.is_file() or installed.read_bytes() != expected:
        fail("installed_backtrader_wheel_payload_mismatch")

import pytest

node_arguments = []
for spec in node_specs:
    source_path, separator, selector = spec.partition("::")
    if not separator or not selector:
        fail("pytest_node_selector_invalid")
    test_path = (fixture_root / Path(*PurePosixPath(source_path).parts)).resolve()
    if not within(test_path, fixture_root) or not test_path.is_file():
        fail("pytest_node_file_missing")
    node_arguments.append(str(test_path) + "::" + selector)

basetemp = out / "pytest-basetemp"
junit_path = out / "junit.xml"
if basetemp.exists() or junit_path.exists():
    fail("pytest_output_namespace_invalid")
pytest_code = int(
    pytest.main(
        [
            "-c", str(pytest_ini),
            "--import-mode=importlib",
            "--basetemp", str(basetemp),
            "--junitxml", str(junit_path),
            *node_arguments,
        ]
    )
)
if not junit_path.is_file():
    fail("pytest_junit_result_missing")
root = ET.parse(junit_path).getroot()
cases = root.findall(".//testcase")
failure_count = len(root.findall(".//failure")) + len(root.findall(".//error"))
skipped_count = len(root.findall(".//skipped"))
if pytest_code != 0 or len(cases) != 2 or failure_count or skipped_count:
    fail("two_installed_nodes_not_all_passed")

origin_facts = {}
for name, module in tuple(sys.modules.items()):
    if not (
        name == "backtrader"
        or name.startswith("backtrader.")
        or name == "backtrader_runtime"
        or name.startswith("backtrader_runtime.")
    ):
        continue
    origin = getattr(module, "__file__", None)
    if origin is None:
        continue
    resolved = Path(origin).resolve()
    if not within(resolved, site):
        fail("loaded_backtrader_module_origin_mismatch")
    origin_facts[name] = str(resolved)
for name, module in tuple(sys.modules.items()):
    if not (
        name == "tests"
        or name.startswith("tests.")
        or name in {"alpha003_strategy", "alpha003_simnow_runner_under_test", "entry_tier"}
    ):
        continue
    origin = getattr(module, "__file__", None)
    if origin is not None and not within(origin, fixture_root):
        fail("loaded_fixture_module_origin_mismatch")
for entry in sys.path:
    if entry and within(entry, repo) and not within(entry, fixture_root):
        fail("repository_path_present_after_fixture_import")

result = {
    "status": "PASS_TWO_INSTALLED_SYNTHETIC_NODES_ONLY",
    "consumer": str(consumer),
    "backtrader_distribution_version": dist.version,
    "wheel": {
        "path": str(wheel),
        "size_bytes": wheel.stat().st_size,
        "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
    },
    "installed_record": {
        "path": str(record_path),
        "size_bytes": record_path.stat().st_size,
        "sha256": hashlib.sha256(record_path.read_bytes()).hexdigest(),
        "entries_checked": record_entries,
    },
    "wheel_package_payload_files_checked": len(package_members),
    "pytest_exit_code": pytest_code,
    "pytest_cases": len(cases),
    "pytest_failures": failure_count,
    "pytest_skips": skipped_count,
    "nodes": node_specs,
    "backtrader_module_origins": origin_facts,
    "provider_or_account_calls_claimed": False,
}
(out / "installed-focus.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(
    json.dumps(
        {
            "status": result["status"],
            "pytest_cases": len(cases),
            "record_entries_checked": record_entries,
            "wheel_payload_files_checked": len(package_members),
        }
    )
)
'''


if __name__ == "__main__":
    raise SystemExit(main())
