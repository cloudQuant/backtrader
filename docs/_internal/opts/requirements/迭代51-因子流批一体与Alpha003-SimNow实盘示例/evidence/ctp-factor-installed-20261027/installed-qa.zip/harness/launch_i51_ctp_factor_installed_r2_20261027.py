import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

root = Path('D:/source_code/backtrader')
script = root / '.codex-tmp/run_i51_ctp_factor_installed_focus_r2_20261027.py'
assert hashlib.sha256(script.read_bytes()).hexdigest() == '08a372008327c9d289feaa6239116b82b5292661e15c0d749075c999031832df'
expected = '7b3d45ed13ba722755b4f481fde573b7d51bd670'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == expected
namespace = runpy.run_path(str(script), run_name='i51_installed_focus_metadata')
command = [sys.executable, '-I', str(script), '--expected-commit', expected,
           '--out', 'D:/temp/i51-ctp-factor-installed-20261027-r2']
for path in sorted(namespace['PIN_PATHS']):
    raw = subprocess.check_output(['git', 'show', expected + ':' + path], cwd=root)
    command.extend(['--source-pin', path + '=' + hashlib.sha256(raw).hexdigest()])
(root / '.codex-tmp/i51_ctp_factor_installed_command_r2_20261027.json').write_text(
    json.dumps(command, indent=2) + '\n', encoding='utf-8')
raise SystemExit(subprocess.run(command, cwd=root).returncode)
