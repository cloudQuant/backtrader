import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

root = Path('D:/source_code/backtrader')
script = root / '.codex-tmp/run_i51_ctp_factor_installed_focus_20261027.py'
assert hashlib.sha256(script.read_bytes()).hexdigest() == '42005208f0f648d393e6c234075530c36003cdde532a840def071d8fc326f80e'
expected = '7b3d45ed13ba722755b4f481fde573b7d51bd670'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == expected
namespace = runpy.run_path(str(script), run_name='i51_installed_focus_metadata')
command = [sys.executable, '-I', str(script), '--expected-commit', expected,
           '--out', 'D:/temp/i51-ctp-factor-installed-20261027-r1']
for path in sorted(namespace['PIN_PATHS']):
    raw = subprocess.check_output(['git', 'show', expected + ':' + path], cwd=root)
    command.extend(['--source-pin', path + '=' + hashlib.sha256(raw).hexdigest()])
(root / '.codex-tmp/i51_ctp_factor_installed_command_20261027.json').write_text(
    json.dumps(command, indent=2) + '\n', encoding='utf-8')
raise SystemExit(subprocess.run(command, cwd=root).returncode)
