"""Synthetic contracts for the bounded same-run golden tape postflight."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
import copy
import hashlib
import importlib.util
from pathlib import Path
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "examples" / "unified" / "028_alpha003_simnow_minute" / "run.py"
HELPER_PATH = ROOT / ".codex-tmp" / "i51_golden_postflight_r1_20261027.py"
CLOCK_DOMAIN_ID = "i51-md-20261027-golden-minute-r1"
CALENDAR_ID = "alpha003-one-minute-v1"
CALENDAR_VERSION = "source-session-snapshot-v1"
COHORT_ID = "alpha003:alpha003-one-minute-v1:1"
EPOCH_ID = 1
TIMEZONE_ID = "UTC"
EXPECTED_COHORT = {
    "cohort_id": COHORT_ID,
    "calendar_version": CALENDAR_VERSION,
    "epoch_id": EPOCH_ID,
    "timezone_id": TIMEZONE_ID,
}
UTC = timezone.utc


def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _runner_module():
    sibling = str(RUNNER_PATH.parent)
    inserted = sibling not in sys.path
    if inserted:
        sys.path.insert(0, sibling)
    try:
        return _load_module("_i51_golden_postflight_test_runner", RUNNER_PATH)
    finally:
        if inserted:
            sys.path.remove(sibling)


def _postflight_module():
    return _load_module("_i51_golden_postflight_test_helper", HELPER_PATH)


class _Product:
    def __init__(self, exchange_id, product_id):
        self.exchange_id = exchange_id
        self.product_id = product_id


class _Grid:
    def __init__(self, runner, row, products):
        self._row = row
        self.status = "READY"
        self.target_products = tuple(products)
        self.product_trading_days = {product: (date(2026, 10, 27),) for product in products}
        self.minutes = tuple(row["minutes"])
        self.decision_at = datetime(2026, 10, 27, 9, 0, tzinfo=UTC)
        self.evidence_sha256 = runner._grid_semantics_sha256(self)

    def to_dict(self):
        return self._row


class _Manifest:
    status = "READY"

    def __init__(self, runner, products, routes):
        self.target_products = tuple(products)
        self._routes = dict(routes)
        self._row = {
            "schema": "synthetic.manifest.v1",
            "status": "READY",
            "snapshot": "fixture",
            "selected": {
                f"{product.exchange_id}.{product.product_id}": routes[product]
                for product in products
            },
        }
        self.manifest_sha256 = hashlib.sha256(
            runner._canonical_json_bytes(self._row).rstrip(b"\n")
        ).hexdigest()

    def to_dict(self):
        return self._row

    def selected_mapping(self):
        return dict(self._routes)


def _make_plan(runner):
    products = (
        _Product("CFFEX", "IF"),
        _Product("SHFE", "rb"),
        _Product("DCE", "m"),
        _Product("CZCE", "TA"),
    )
    full_targets = tuple(f"{item.exchange_id}.{item.product_id}" for item in products)
    active_products = products[:3]
    targets = full_targets[:3]
    full_routes = dict(zip(products, ("IF2610", "rb2610", "m2611", "TA611")))
    routes = {product: full_routes[product] for product in active_products}
    first_close = datetime(2026, 10, 27, 9, 31, tzinfo=UTC)
    def grid_for(grid_products, minute_count):
        minutes = []
        for index in range(minute_count):
            close = first_close + timedelta(minutes=index)
            members = [
                {
                    "product": {
                        "exchange_id": product.exchange_id,
                        "product_id": product.product_id,
                    },
                    "trading_day": "2026-10-27",
                    "session_date": "2026-10-27",
                    "action_day": "2026-10-27",
                    "session_id": "regular",
                }
                for product in grid_products
            ]
            minutes.append(
                {"close_time": close.isoformat(), "members": members}
            )
        row = {
            "schema": "backtrader.futures_common_minute_grid.v1",
            "status": "READY",
            "decision_at": "2026-10-27T09:00:00Z",
            "target_products": [
                {"exchange_id": product.exchange_id, "product_id": product.product_id}
                for product in grid_products
            ],
            "product_trading_days": [
                {
                    "product": {
                        "exchange_id": product.exchange_id,
                        "product_id": product.product_id,
                    },
                    "trading_days": ["2026-10-27"],
                }
                for product in grid_products
            ],
            "calendar_hashes": [],
            "minutes": minutes,
        }
        return _Grid(runner, row, grid_products)

    full_grid = grid_for(products, 195)
    grid = grid_for(active_products, 225)
    assert runner._grid_semantics_sha256(full_grid) != runner._grid_semantics_sha256(grid)
    product_by_target = dict(zip(targets, active_products))
    target_by_product = {product: target for target, product in product_by_target.items()}
    full_product_by_target = dict(zip(full_targets, products))
    full_target_by_product = {product: target for target, product in full_product_by_target.items()}
    return {
        "selection_source": "ctp_query_snapshot_equal_weight_v1",
        "selection_path": "ctp-query://synthetic/selection",
        "source_snapshot_id": "synthetic-snapshot-1",
        "targets": targets,
        "authorized_targets": targets,
        "product_by_target": product_by_target,
        "target_by_product": target_by_product,
        "routes": routes,
        "grid": grid,
        "manifest": _Manifest(runner, products, full_routes),
        "products": active_products,
        "full_products": products,
        "full_routes": full_routes,
        "full_selected_targets": full_targets,
        "full_product_by_target": full_product_by_target,
        "full_target_by_product": full_target_by_product,
        "full_authorized_targets": full_targets,
        "full_grid": full_grid,
        "active_shadow_targets": targets,
        "golden_targets": targets,
    }


def _record_bytes(runner, row):
    row = dict(row)
    row["record_id"] = hashlib.sha256(
        runner._canonical_json_bytes(row).rstrip(b"\n")
    ).hexdigest()
    return runner._canonical_json_bytes(row), row


def _member(target, instrument, close, cohort_id, slot_index, sequence, *, clock_domain_id):
    price = 100.0 + slot_index + sequence / 10.0
    return {
        "cohort_id": cohort_id,
        "calendar_id": CALENDAR_ID,
        "epoch_id": EPOCH_ID,
        "slot_index": slot_index,
        "slot_id": f"minute:{close.isoformat()}",
        "instrument": instrument,
        "source_ref": f"ctp-live:{target}:{instrument}",
        "source_role": "live",
        "connection_generation": 3,
        "feed_sequence": sequence,
        "bucket_start": (close - timedelta(minutes=1)).isoformat().replace("+00:00", "Z"),
        "close_time": close.isoformat().replace("+00:00", "Z"),
        "available_at": (close + timedelta(seconds=2)).isoformat().replace("+00:00", "Z"),
        "trading_day": "2026-10-27",
        "session_segment": "regular",
        "timezone_id": TIMEZONE_ID,
        "clock_domain_id": clock_domain_id,
        "bar_id": f"bar-{target}-{sequence}",
        "complete": True,
        "quality": "GOOD",
        "present": True,
        "quality_flags": [],
        "event_source": "synthetic-feed",
        "received_monotonic_ns": 1_000_000 + sequence,
        "raw_values": {
            "open": price,
            "high": price + 1.0,
            "low": price - 1.0,
            "close": price + 0.25,
            "volume": float(sequence),
            "openinterest": 100.0,
        },
    }


def _factor_point(target, member, value, *, unavailable=False):
    value_record = (
        {"finite": False, "value": None, "float64_hex": "nan"}
        if unavailable
        else {"finite": True, "value": value, "float64_hex": value.hex()}
    )
    return {
        "value": value_record,
        "status": "OUTPUT_UNAVAILABLE" if unavailable else "OUTPUT_AVAILABLE",
        "reason": "MINPERIOD" if unavailable else None,
        "present": True,
        "complete": True,
        "quality": "GOOD",
        "source_role": "live",
        "member_id": target,
        "source_ref": member["source_ref"],
        "sequence": member["feed_sequence"],
        "generation": member["connection_generation"],
    }


def _make_summary(
    tmp_path,
    runner,
    *,
    plan_slots=(10, 11, 12),
    slot_indexes=(0, 1, 2),
    mutation=None,
    header_mutation=None,
):
    plan = _make_plan(runner)
    evidence = runner._selection_evidence(plan, epoch_id=EPOCH_ID, max_bytes=16 * 1024 * 1024)
    tape_evidence = dict(evidence)
    if header_mutation is not None:
        tape_evidence = header_mutation(runner, tape_evidence)
    file_id = "synthetic-file-id"
    grid_rows = plan["grid"].to_dict()["minutes"]
    header = {
        "schema": runner.DECISION_TAPE_SCHEMA,
        "record_type": "HEADER",
        "file_id": file_id,
        "created_at": "2026-10-27T09:00:00Z",
        "mode": "live",
        "factor_mode": "build",
        "direction": 1,
        "targets": sorted(plan["targets"]),
        "calendar_id": CALENDAR_ID,
        "grid_sha256": plan["grid"].evidence_sha256,
        "source_snapshot_id": plan["source_snapshot_id"],
        "selection_evidence": tape_evidence,
    }
    chunks = []
    header_bytes, header = _record_bytes(runner, header)
    chunks.append(header_bytes)
    header_evidence_sha = tape_evidence["binding_sha256"]
    last_reference = None
    for record_index, (plan_index, slot_index) in enumerate(zip(plan_slots, slot_indexes), start=1):
        close = datetime.fromisoformat(grid_rows[plan_index]["close_time"].replace("Z", "+00:00"))
        cohort_id = COHORT_ID
        members = {
            target: _member(
                target,
                plan["routes"][plan["product_by_target"][target]],
                close,
                cohort_id,
                slot_index,
                record_index,
                clock_domain_id=CLOCK_DOMAIN_ID,
            )
            for target in sorted(plan["targets"])
        }
        factor_values = {
            target: _factor_point(
                target,
                members[target],
                1.0 + record_index + index,
                unavailable=(record_index == 1 and index == 0),
            )
            for index, target in enumerate(sorted(plan["targets"]))
        }
        if mutation is not None:
            mutation(record_index, members)
        row = {
            "schema": runner.DECISION_TAPE_SCHEMA,
            "record_type": "DECISION",
            "file_id": file_id,
            "record_index": record_index,
            "batch_id": f"batch-{record_index}",
            "cohort_id": cohort_id,
            "calendar_id": CALENDAR_ID,
            "calendar_version": CALENDAR_VERSION,
            "epoch_id": EPOCH_ID,
            "slot_index": slot_index,
            "close_time": close.isoformat().replace("+00:00", "Z"),
            "available_at": (close + timedelta(seconds=2)).isoformat().replace("+00:00", "Z"),
            "readiness": "WARMUP",
            "readiness_reasons": ["synthetic_warmup"],
            "members": members,
            "factors": {
                "plan_id": "synthetic-factor-plan",
                "factors": {
                    "alpha003": {
                        "mode": "build",
                        "panel_line": "factor",
                        "direction": 1,
                        "source_sha256": "b" * 64,
                        "values": factor_values,
                    }
                },
            },
            "target_decision": None,
            "order_plan": None,
            "header_record_id": header["record_id"],
            "selection_evidence_sha256": header_evidence_sha,
        }
        row_bytes, row = _record_bytes(runner, row)
        chunks.append(row_bytes)
        last_reference = {
            "file_id": file_id,
            "record_id": row["record_id"],
            "record_index": record_index,
            "batch_id": row["batch_id"],
        }

    payload = b"".join(chunks)
    path = (tmp_path / "synthetic-decision-tape.jsonl").resolve()
    path.write_bytes(payload)
    writer = {
        "file_id": file_id,
        "path": str(path),
        "bytes": len(payload),
        "max_bytes": 16 * 1024 * 1024,
        "record_count": len(plan_slots),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "closed": True,
        "failed": False,
        "last_record_reference": last_reference,
    }
    readback = {
        "file_id": file_id,
        "record_count": len(plan_slots),
        "last_record_reference": last_reference,
        "actual_bytes": len(payload),
    }
    summary = {
        "status": "LIVE_RUN_COMPLETE",
        "mode": "live",
        "epoch_id": EPOCH_ID,
        "selection_source": plan["selection_source"],
        "source_snapshot_id": plan["source_snapshot_id"],
        "selection_evidence": evidence,
        "full_selected_targets": list(plan["full_selected_targets"]),
        "active_shadow_targets": list(plan["active_shadow_targets"]),
        "routes": {
            target: plan["routes"][plan["product_by_target"][target]]
            for target in plan["targets"]
        },
        "factor_mode": "build",
        "source_clock_domain_id": CLOCK_DOMAIN_ID,
        "cleanup_complete": True,
        "resource_shutdown": [
            {
                "resource": "store",
                "status": "CLOSED_BY_BROKER",
                "shutdown_state": "PASS",
                "ctp_factor_source_shutdown": {
                    "required": True,
                    "status": "PASS",
                    "expected_md_generation": 3,
                    "expected_trader_generation": 5,
                    "join_required": False,
                    "reason_codes": [],
                    "md_receipt": {
                        "connection_generation": 3,
                        "join_required": False,
                        "join_completed": False,
                        "native_released": True,
                        "thread_alive": False,
                        "timed_out": False,
                        "complete": True,
                    },
                    "trader_receipt": {
                        "connection_generation": 5,
                        "join_required": False,
                        "join_completed": False,
                        "native_released": True,
                        "thread_alive": False,
                        "timed_out": False,
                        "complete": True,
                    },
                },
            }
        ],
        "decision_tape": writer,
        "decision_tape_readback": readback,
        "_plan": plan,
    }
    return summary


def _run(
    tmp_path,
    *,
    plan_slots=(10, 11, 12),
    slot_indexes=(0, 1, 2),
    mutation=None,
    header_mutation=None,
    expected_cohort=EXPECTED_COHORT,
):
    runner = _runner_module()
    helper = _postflight_module()
    summary = _make_summary(
        tmp_path,
        runner,
        plan_slots=plan_slots,
        slot_indexes=slot_indexes,
        mutation=mutation,
        header_mutation=header_mutation,
    )
    return helper.validate_golden_postflight(
        runner,
        summary,
        clock_domain_id=CLOCK_DOMAIN_ID,
        calendar_id=CALENDAR_ID,
        expected_cohort=expected_cohort,
        normal_cleanup_complete=True,
    )


def test_three_consecutive_complete_warmup_cohorts_pass(tmp_path):
    runner = _runner_module()
    helper = _postflight_module()
    summary = _make_summary(tmp_path, runner)
    result = helper.validate_golden_postflight(
        runner,
        summary,
        clock_domain_id=CLOCK_DOMAIN_ID,
        calendar_id=CALENDAR_ID,
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
    )

    assert result["status"] == "PASS"
    assert result["target_count"] == 3
    assert result["full_selected_target_count"] == 4
    assert result["full_grid_minute_count"] == 195
    assert result["planned_minute_count"] == 225
    assert result["decision_record_count"] == 3
    assert result["longest_consecutive_complete_cohorts"] == 3
    tape = list(
        runner.iter_decision_tape(
            Path(summary["decision_tape"]["path"]),
            max_bytes=summary["decision_tape"]["max_bytes"],
        )
    )
    factor_points = tape[1]["factors"]["factors"]["alpha003"]["values"]
    assert any(
        point["status"] == "OUTPUT_UNAVAILABLE"
        and point["reason"] == "MINPERIOD"
        and point["value"] == {"finite": False, "value": None, "float64_hex": "nan"}
        for point in factor_points.values()
    )
    assert any(point["status"] == "OUTPUT_AVAILABLE" for point in factor_points.values())


def test_missing_member_is_rejected_by_iterator_contract(tmp_path):
    def remove_member(record_index, members):
        if record_index == 1:
            members.pop(sorted(members)[-1])

    result = _run(tmp_path, mutation=remove_member)

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_ITERATOR_REJECTED"


def test_nonconsecutive_planned_closes_do_not_satisfy_three_slot_gate(tmp_path):
    result = _run(tmp_path, plan_slots=(10, 12, 13), slot_indexes=(0, 2, 3))

    assert result["status"] == "FAIL"
    assert result["code"] == "THREE_CONSECUTIVE_COHORTS_MISSING"


def test_rehashed_route_substitution_is_rejected_against_same_run_plan(tmp_path):
    def change_route(record_index, members):
        if record_index == 2:
            members["SHFE.rb"]["instrument"] = "rb9999"

    result = _run(tmp_path, mutation=change_route)

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_MEMBER_PLAN_OR_QUALITY_MISMATCH"


def test_source_reference_is_bound_to_exact_ctp_route(tmp_path):
    def change_source_ref(record_index, members):
        if record_index == 1:
            members["CFFEX.IF"]["source_ref"] = "ctp-live:CFFEX.IF:OTHER"

    result = _run(tmp_path, mutation=change_source_ref)

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_MEMBER_SOURCE_INVALID"


def test_bar_id_must_be_unique_within_each_target(tmp_path):
    def repeat_bar_id(record_index, members):
        if record_index == 2:
            members["CFFEX.IF"]["bar_id"] = "bar-CFFEX.IF-1"

    result = _run(tmp_path, mutation=repeat_bar_id)

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_MEMBER_BAR_DUPLICATED"


def test_slot_id_must_match_the_planned_aware_minute_close(tmp_path):
    def change_slot_id(record_index, members):
        if record_index == 1:
            members["CFFEX.IF"]["slot_id"] = "minute:2026-10-27T09:40:00+00:00"

    result = _run(tmp_path, mutation=change_slot_id)

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_MEMBER_SLOT_PLAN_MISMATCH"


def test_full_pool_selection_evidence_is_bound_to_same_run_plan(tmp_path):
    def change_full_selection(runner, evidence):
        altered = copy.deepcopy(evidence)
        inactive = next(
            target
            for target in altered["full_selected_targets"]
            if target not in altered["active_shadow_targets"]
        )
        altered["full_selected_targets"].remove(inactive)
        altered["full_selected_targets"].sort()
        altered["routes"].pop(inactive)
        altered["authorized_targets"].remove(inactive)
        binding = {
            key: value
            for key, value in altered.items()
            if key not in {"binding_sha256", "manifest"}
        }
        altered["binding_sha256"] = hashlib.sha256(
            runner._canonical_json_bytes(binding).rstrip(b"\n")
        ).hexdigest()
        return altered

    result = _run(tmp_path, header_mutation=change_full_selection)

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_HEADER_BINDING_MISMATCH"


def test_plain_three_target_plan_is_not_a_golden_subset(tmp_path):
    runner = _runner_module()
    helper = _postflight_module()
    summary = _make_summary(tmp_path, runner)
    summary["_plan"]["golden_targets"] = None

    result = helper.validate_golden_postflight(
        runner,
        summary,
        clock_domain_id=CLOCK_DOMAIN_ID,
        calendar_id=CALENDAR_ID,
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
    )

    assert result["status"] == "FAIL"
    assert result["code"] == "PLAN_GOLDEN_SUBSET_REQUIRED"


@pytest.mark.parametrize(
    ("field", "value", "code"),
    [
        ("cohort_id", "untrusted-first-row", "TAPE_COHORT_BINDING_MISMATCH"),
        (
            "calendar_version",
            "untrusted-first-row-calendar",
            "TAPE_COHORT_BINDING_MISMATCH",
        ),
        ("epoch_id", 2, "LIVE_EPOCH_INVALID"),
        ("timezone_id", "untrusted-timezone", "TAPE_MEMBER_PLAN_OR_QUALITY_MISMATCH"),
    ],
)
def test_expected_profile_fields_are_not_derived_from_tape(tmp_path, field, value, code):
    expected = dict(EXPECTED_COHORT, **{field: value})

    result = _run(tmp_path, expected_cohort=expected)

    assert result["status"] == "FAIL"
    assert result["code"] == code


def test_md_generation_must_match_normal_shutdown_receipt(tmp_path):
    runner = _runner_module()
    helper = _postflight_module()
    summary = _make_summary(tmp_path, runner)
    shutdown = summary["resource_shutdown"][0]["ctp_factor_source_shutdown"]
    shutdown["expected_md_generation"] = 4
    shutdown["md_receipt"]["connection_generation"] = 4

    result = helper.validate_golden_postflight(
        runner,
        summary,
        clock_domain_id=CLOCK_DOMAIN_ID,
        calendar_id=CALENDAR_ID,
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
    )

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_MEMBER_GENERATION_MISMATCH"


def test_writer_hash_must_match_the_bounded_tape_bytes(tmp_path):
    runner = _runner_module()
    helper = _postflight_module()
    summary = _make_summary(tmp_path, runner)
    summary["decision_tape"]["sha256"] = "f" * 64

    result = helper.validate_golden_postflight(
        runner,
        summary,
        clock_domain_id=CLOCK_DOMAIN_ID,
        calendar_id=CALENDAR_ID,
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=True,
    )

    assert result["status"] == "FAIL"
    assert result["code"] == "TAPE_PIN_MISMATCH"


def test_external_cleanup_observation_requires_literal_true(tmp_path):
    runner = _runner_module()
    helper = _postflight_module()
    summary = _make_summary(tmp_path, runner)

    result = helper.validate_golden_postflight(
        runner,
        summary,
        clock_domain_id=CLOCK_DOMAIN_ID,
        calendar_id=CALENDAR_ID,
        expected_cohort=EXPECTED_COHORT,
        normal_cleanup_complete=1,
    )

    assert result["status"] == "FAIL"
    assert result["code"] == "NORMAL_CLEANUP_NOT_CONFIRMED"
