import sys
from pathlib import Path
root=Path(__file__).resolve().parent/'replay2'
sys.path.insert(0,str(root))
import account_actor_port, store_boundary_harness, store_boundary_harness_testonly
for module in (account_actor_port,store_boundary_harness,store_boundary_harness_testonly):
 p=Path(module.__file__).resolve()
 assert p.is_relative_to(root), (module.__name__,p,root)
 print(f'{module.__name__}={p}')
assert not any(x=='bt_api_py' or x.startswith('bt_api_py.') or x=='_ctp' or x.startswith('_ctp.') for x in sys.modules)
print('native_sdk_modules_loaded=0')
