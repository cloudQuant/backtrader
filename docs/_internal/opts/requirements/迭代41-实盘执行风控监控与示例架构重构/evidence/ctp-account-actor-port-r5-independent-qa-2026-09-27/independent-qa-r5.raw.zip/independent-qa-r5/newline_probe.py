from pathlib import Path
for s in [r'D:\temp\iteration41-ctp-account-actor-port-freeze-20260927-r4\store_boundary_harness.py',r'D:\temp\iteration41-ctp-account-actor-port-r5-independent-qa-20260927\replay\store_boundary_harness.py',r'D:\temp\iteration41-ctp-account-actor-port-r5-20260927\source\store_boundary_harness.py']:
 b=Path(s).read_bytes(); print(s, 'first',repr(b[:24]), 'crlf',b.count(bytes([13,10])),'lf',b.count(bytes([10])))
