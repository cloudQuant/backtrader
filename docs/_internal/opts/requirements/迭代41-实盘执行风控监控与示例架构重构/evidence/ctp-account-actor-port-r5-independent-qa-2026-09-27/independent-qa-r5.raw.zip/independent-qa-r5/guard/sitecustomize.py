import importlib.abc
import socket
import sys

class _BlockNative(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_py' or fullname.startswith('bt_api_py.') or fullname == '_ctp' or fullname.startswith('_ctp.'):
            raise ModuleNotFoundError('independent QA blocks CTP SDK/native imports')
        return None

sys.meta_path.insert(0, _BlockNative())
def _deny(*args, **kwargs):
    raise AssertionError('independent QA blocks network APIs')
socket.create_connection = _deny
socket.getaddrinfo = _deny
socket.socket.connect = _deny
socket.socket.connect_ex = _deny
