import json
import subprocess
import sys
from decimal import Decimal
from pathlib import Path
from account_actor_port import AccountActorGateError, ActorCommandContextV1, ActorCommandReceiptV2, ActorCommandState, CtpAccountActorPort, CtpSubmitIntentV2, FakeLocalActorReplayLedger, RouteKind, StoreRouteDescriptor, classify_store_route
from store_boundary_harness import StoreBoundaryHarness
from store_boundary_harness_testonly import LocalFakeStoreBoundaryHarness

root=Path(__file__).resolve().parent
observed={}

class TrapMap(dict):
    calls=[]
    def __iter__(self): self.calls.append('__iter__'); raise AssertionError('custom Mapping iterated')
    def items(self): self.calls.append('items'); raise AssertionError('custom Mapping items called')
    def values(self): self.calls.append('values'); raise AssertionError('custom Mapping values called')
    def __getitem__(self, key): self.calls.append('__getitem__'); raise AssertionError('custom Mapping read')

trap=TrapMap({'exchange_type':'CTP'})
route=StoreRouteDescriptor(provider='btapi', config={'exchange_kwargs':trap})
observed['custom_mapping_route_kind']=classify_store_route(route).value
observed['custom_mapping_calls']=list(TrapMap.calls)

class TrapRoute:
    reads=[]
    @property
    def provider(self): self.reads.append('provider'); raise AssertionError('route property read')
observed['opaque_route_kind']=classify_store_route(TrapRoute()).value
observed['opaque_route_property_reads']=list(TrapRoute.reads)

class TrapApi:
    reads=[]
    @property
    def exchange_kwargs(self): self.reads.append('exchange_kwargs'); raise AssertionError('API property read')
api=TrapApi()
ctp_route=StoreRouteDescriptor(provider='ctp',api=api)
try:
    StoreBoundaryHarness(ctp_route)
except AccountActorGateError as exc:
    observed['injected_api_rejection']=exc.code
observed['injected_api_property_reads']=list(TrapApi.reads)

shared={'BTC-USDT':'OKX___SWAP'}
shared_config={'symbol_routes':shared}
route_a=StoreRouteDescriptor(provider='okx',config=shared_config)
route_b=StoreRouteDescriptor(provider='okx',config=shared_config)
h_a=StoreBoundaryHarness(route_a); h_b=StoreBoundaryHarness(route_b)
shared['BTC-USDT']='CTP'
for label,h,op in [('a',h_a,h_a.submit_order),('b',h_b,h_b.cancel_order)]:
    try: op({'command_id':'shared-route-mutation'})
    except AccountActorGateError as exc: observed[f'shared_route_{label}_result']=exc.code
observed['shared_route_legacy_calls']=[h_a.legacy_calls,h_b.legacy_calls]

# A callback between snapshot creation and the local factory can mutate the nested route.
mut_config={'exchange_type':'IB_WEB'}
mut_route=StoreRouteDescriptor(provider='gateway',backend='gateway',config=mut_config)
factory_calls=[]
def resolver(): mut_config['exchange_type']='CTP'
def factory(): factory_calls.append('called'); return object()
observed['mutation_route_kind_before']=classify_store_route(mut_route).value
mut_harness=StoreBoundaryHarness(mut_route,credential_resolver=resolver,gateway_factory=factory)
observed['mutation_route_kind_after']=classify_store_route(mut_route).value
observed['gateway_factory_calls_after_ctp_mutation']=len(factory_calls)
try: mut_harness.submit_order({'command_id':'after-mutation'})
except AccountActorGateError as exc: observed['mutated_route_submit']=exc.code
observed['mutation_harness_legacy_calls']=mut_harness.legacy_calls

# Default harness stays closed even when handed a fake actor; test-only subclass dispatches by design.
ctx=ActorCommandContextV1('account-ref','runtime','simulation','a'*64,'session',7,11,4,3)
intent=CtpSubmitIntentV2('same-cross-process-id','IF2601','CFFEX','BUY','OPEN','SPECULATION',1,Decimal('3000.5'),ctx)
class Actor(CtpAccountActorPort):
    def __init__(self): self.calls=0
    def submit_order(self,intent):
        self.calls+=1
        return ActorCommandReceiptV2('SUBMIT',intent.command_id,ActorCommandState.QUEUED,intent.context,intent.command_digest)
    def cancel_order(self,intent): raise AssertionError('unexpected cancel')
actor=Actor(); default=StoreBoundaryHarness(StoreRouteDescriptor(provider='ctp',backend='direct'),actor_port=actor,actor_context=ctx)
try: default.submit_order(intent)
except AccountActorGateError as exc: observed['ordinary_harness_submit']=exc.code
observed['ordinary_harness_actor_calls']=actor.calls

child=r'''from decimal import Decimal
from account_actor_port import ActorCommandContextV1,ActorCommandReceiptV2,ActorCommandState,CtpAccountActorPort,CtpSubmitIntentV2,FakeLocalActorReplayLedger,StoreRouteDescriptor
from store_boundary_harness_testonly import LocalFakeStoreBoundaryHarness
class Actor(CtpAccountActorPort):
 def __init__(self): self.calls=0
 def submit_order(self,intent):
  self.calls+=1
  return ActorCommandReceiptV2('SUBMIT',intent.command_id,ActorCommandState.QUEUED,intent.context,intent.command_digest)
 def cancel_order(self,intent): raise AssertionError('unexpected cancel')
ctx=ActorCommandContextV1('account-ref','runtime','simulation','a'*64,'session',7,11,4,3)
intent=CtpSubmitIntentV2('same-cross-process-id','IF2601','CFFEX','BUY','OPEN','SPECULATION',1,Decimal('3000.5'),ctx)
actor=Actor(); h=LocalFakeStoreBoundaryHarness(StoreRouteDescriptor(provider='ctp',backend='direct'),actor_port=actor,actor_context=ctx,receipt_ledger=FakeLocalActorReplayLedger())
receipt=h.submit_order(intent)
print(actor.calls,receipt.state.value,intent.command_id)
'''
child_observations=[]
for _ in range(2):
 p=subprocess.run([sys.executable,'-B','-c',child],cwd=str(root),capture_output=True,text=True,check=False)
 child_observations.append({'exit':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()})
observed['separate_process_testonly_replay']=child_observations
print(json.dumps(observed,indent=2,sort_keys=True))
