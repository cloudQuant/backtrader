import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import pytest

from account_actor_port import (
    AccountActorGateError,
    ActorCommandContextV1,
    ActorCommandReceiptV2,
    ActorCommandState,
    CtpAccountActorPort,
    CtpSubmitIntentV2,
    FakeLocalActorReplayLedger,
    RouteKind,
    StoreRouteDescriptor,
    classify_store_route,
)
from store_boundary_harness import StoreBoundaryHarness
from store_boundary_harness_testonly import LocalFakeStoreBoundaryHarness


def _context():
    return ActorCommandContextV1("account-ref", "runtime", "simulation", "a" * 64,
                                 "session", 7, 11, 4, 3)


def _intent(ctx=None):
    return CtpSubmitIntentV2("same-cross-process-id", "IF2601", "CFFEX", "BUY", "OPEN",
                             "SPECULATION", 1, Decimal("3000.5"), ctx or _context())


class _Actor(CtpAccountActorPort):
    def __init__(self):
        self.calls = 0
    def submit_order(self, intent):
        self.calls += 1
        return ActorCommandReceiptV2("SUBMIT", intent.command_id, ActorCommandState.QUEUED,
                                     intent.context, intent.command_digest)
    def cancel_order(self, intent):
        raise AssertionError("unexpected cancel")


def test_custom_mapping_and_route_properties_are_not_evaluated():
    calls=[]
    class TrapMapping(dict):
        def __iter__(self): calls.append("iter"); raise AssertionError("iter")
        def items(self): calls.append("items"); raise AssertionError("items")
        def values(self): calls.append("values"); raise AssertionError("values")
        def __getitem__(self,key): calls.append("get"); raise AssertionError("get")
    assert classify_store_route(StoreRouteDescriptor(provider="btapi", config={"exchange_kwargs":TrapMapping(exchange_type="CTP")})) is RouteKind.AMBIGUOUS
    class OpaqueRoute:
        reads=[]
        @property
        def provider(self): self.reads.append("provider"); raise AssertionError("route property")
    assert classify_store_route(OpaqueRoute()) is RouteKind.AMBIGUOUS
    assert calls == []
    assert OpaqueRoute.reads == []


def test_shared_nested_route_mutation_blocks_both_handles_before_legacy_call():
    shared={"BTC-USDT":"OKX___SWAP"}
    config={"symbol_routes":shared}
    a=StoreBoundaryHarness(StoreRouteDescriptor(provider="okx",config=config))
    b=StoreBoundaryHarness(StoreRouteDescriptor(provider="okx",config=config))
    shared["BTC-USDT"]="CTP"
    for operation in (a.submit_order,b.cancel_order):
        with pytest.raises(AccountActorGateError,match="store route changed after construction"):
            operation({"command_id":"must-not-route"})
    assert (a.legacy_calls,b.legacy_calls)==(0,0)


def test_ordinary_harness_denies_fake_actor_and_testonly_fresh_process_replays_are_local():
    ctx=_context(); intent=_intent(ctx); actor=_Actor()
    ordinary=StoreBoundaryHarness(StoreRouteDescriptor(provider="ctp",backend="direct"),
                                  actor_port=actor,actor_context=ctx)
    with pytest.raises(AccountActorGateError,match="trusted durable remote actor unavailable"):
        ordinary.submit_order(intent)
    assert actor.calls == 0
    child=r'''from decimal import Decimal
from account_actor_port import ActorCommandContextV1,ActorCommandReceiptV2,ActorCommandState,CtpAccountActorPort,CtpSubmitIntentV2,FakeLocalActorReplayLedger,StoreRouteDescriptor
from store_boundary_harness_testonly import LocalFakeStoreBoundaryHarness
class Actor(CtpAccountActorPort):
 def __init__(self): self.calls=0
 def submit_order(self,intent):
  self.calls+=1
  return ActorCommandReceiptV2('SUBMIT',intent.command_id,ActorCommandState.QUEUED,intent.context,intent.command_digest)
 def cancel_order(self,intent): raise AssertionError('unexpected cancel')
ctx=ActorCommandContextV1('account-ref','runtime','simulation','a'*64,'session',7,11,4,3)
intent=CtpSubmitIntentV2('same-cross-process-id','IF2601','CFFEX','BUY','OPEN','SPECULATION',1,Decimal('3000.5'),ctx)
actor=Actor(); h=LocalFakeStoreBoundaryHarness(StoreRouteDescriptor(provider='ctp',backend='direct'),actor_port=actor,actor_context=ctx,receipt_ledger=FakeLocalActorReplayLedger())
receipt=h.submit_order(intent)
print(actor.calls,receipt.state.value,intent.command_id)
'''
    for _ in range(2):
        result=subprocess.run([sys.executable,"-B","-c",child],capture_output=True,text=True,check=False)
        assert result.returncode == 0, result.stderr
        assert result.stdout.strip() == "1 queued same-cross-process-id"


def test_testonly_type_guard_rejects_subclassed_fake_ledger():
    class DerivedLedger(FakeLocalActorReplayLedger):
        pass
    ctx=_context()
    with pytest.raises(AccountActorGateError,match="fake replay ledger required"):
        LocalFakeStoreBoundaryHarness(StoreRouteDescriptor(provider="ctp",backend="direct"),
                                      actor_port=_Actor(),actor_context=ctx,
                                      receipt_ledger=DerivedLedger())
