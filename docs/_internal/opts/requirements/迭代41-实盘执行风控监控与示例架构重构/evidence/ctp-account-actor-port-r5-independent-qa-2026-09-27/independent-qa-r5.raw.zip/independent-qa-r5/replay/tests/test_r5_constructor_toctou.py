import pytest
from account_actor_port import AccountActorGateError, StoreRouteDescriptor, classify_store_route
from store_boundary_harness import StoreBoundaryHarness
from account_actor_port import RouteKind


def test_route_change_inside_credential_resolver_blocks_gateway_factory():
    config={"exchange_type":"IB_WEB"}
    route=StoreRouteDescriptor(provider="gateway",backend="gateway",config=config)
    assert classify_store_route(route) is RouteKind.NON_CTP
    factory_calls=[]
    def resolver():
        config["exchange_type"]="CTP"
    def factory():
        factory_calls.append("created")
        return object()
    with pytest.raises(AccountActorGateError,match="store route changed during construction"):
        StoreBoundaryHarness(route,credential_resolver=resolver,gateway_factory=factory)
    assert factory_calls == []
