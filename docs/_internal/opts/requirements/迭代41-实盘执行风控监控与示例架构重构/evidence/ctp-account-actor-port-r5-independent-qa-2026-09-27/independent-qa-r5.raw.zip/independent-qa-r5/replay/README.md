# External CTP Account Actor Port — offline candidate r5

This isolated candidate hardens the route snapshot and local fake boundary. It does not edit or import the main Backtrader package, implement a remote service, or create a CTP write route. Unknown providers, ambiguous gateway selectors, and raw `api`/`api_cls` injection fail closed without inspecting injected objects.

Run the isolated fake harness with:

    python -m unittest discover -s tests -v

The default CTP command path rejects with `trusted_durable_remote_actor_unavailable`, even when a local fake port is supplied. Tests that deliberately exercise fake command/receipt plumbing use the separate `store_boundary_harness_testonly.LocalFakeStoreBoundaryHarness` module and a `FakeLocalActorReplayLedger`. The ordinary harness has no local fake-dispatch switch. The test-only mode has no durable or cross-process uniqueness and is not imported by Backtrader, a Store, or a runtime registry. Route snapshots are rehashed before every submit/cancel. Mutations fail closed; an equal-content replacement mapping keeps the same semantic digest.

The tests cover stale context/receipt bindings, CTP environment-downgrade attempts, nested route maps, route mutation, cross-process/reopen replay attempts, unknown providers, and injected API objects with trap properties. `ActorCommandContextV1`, the typed V2 intents/receipts, and the in-memory ledger remain local contract fixtures, not authenticated actor authority.

See INTEGRATION_CONTRACT.md for the precise main Store call points and current limits.
