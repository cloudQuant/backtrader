import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
entries=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.name=='qa-manifest.json' or p.suffix=='.pyc' or '__pycache__' in p.parts:
  continue
 b=p.read_bytes(); entries.append({'path':p.relative_to(root).as_posix(),'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()})
manifest={
 'schema':'iteration41-account-actor-port-r5-independent-qa.v1',
 'candidate_manifest_sha256':'73521009058983A0E34172C4CA0020C5F32F4CBF25DA7B1FB554F4D68BAAA4BD',
 'r4_base_manifest_sha256':'8F793CC85754F6FA447925BD0AD40570DD7F10480773F45500B56FD0933591A8',
 'r5_patch_sha256':'5646BCD7959D2BE35F0EB38299B26F4D3CFFEA5C8CD4A6AB5ADD902E3B3E8D6C',
 'verdict':'PARTIAL / NEEDS_REVISION; LOCAL_FAKE only',
 'tests':{'candidate_pytest':{'passed':40,'failed':0},'candidate_unittest':{'passed':40,'failed':0},'extra_controls':{'passed':4,'failed':0},'constructor_toctou_counterexample':{'passed':0,'failed':1,'expected_red':True}},
 'controls':{'native_sdk_imports_blocked':True,'network_socket_and_dns_calls_blocked':True,'private_config_read':False,'provider_or_order_used':False},
 'findings':['Construction invokes gateway_factory after credential_resolver mutates the shared route snapshot from IB_WEB to CTP.','Ordinary harness rejects before fake actor call; test-only harness is directly importable and its per-process fake ledger admits the same command once in each fresh process.'],
 'artifacts':entries
}
out=root/'qa-manifest.json'; out.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('manifest_path='+str(out)); print('manifest_sha256='+hashlib.sha256(out.read_bytes()).hexdigest().upper()); print('artifact_count='+str(len(entries)))
