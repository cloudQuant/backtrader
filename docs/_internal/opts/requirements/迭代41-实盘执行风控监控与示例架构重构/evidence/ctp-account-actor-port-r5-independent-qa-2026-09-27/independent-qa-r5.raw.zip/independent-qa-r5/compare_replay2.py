import hashlib, json
from pathlib import Path
cand=Path(r'D:\temp\iteration41-ctp-account-actor-port-r5-20260927')
replay=Path(r'D:\temp\iteration41-ctp-account-actor-port-r5-independent-qa-20260927\replay2')
mp={'source/account_actor_port.py':'account_actor_port.py','source/store_boundary_harness.py':'store_boundary_harness.py','source/store_boundary_harness_testonly.py':'store_boundary_harness_testonly.py','source/README.md':'README.md','source/INTEGRATION_CONTRACT.md':'INTEGRATION_CONTRACT.md','tests/test_store_boundary_harness.py':'tests/test_store_boundary_harness.py'}
rows=[]
for rel,outrel in mp.items():
 pa=cand/rel; pb=replay/outrel; a=pa.read_bytes().replace(b'\r\n',b'\n'); b=pb.read_bytes().replace(b'\r\n',b'\n')
 rows.append({'path':rel,'candidate_sha256':hashlib.sha256(a).hexdigest().upper(),'replay_sha256':hashlib.sha256(b).hexdigest().upper(),'normalized_match':a==b})
result={'files':rows,'all_match':all(r['normalized_match'] for r in rows)}
text=json.dumps(result,indent=2)+'\n'; (Path(__file__).parent/'replay2-compare.json').write_text(text,encoding='utf-8'); print(text)
if not result['all_match']: raise SystemExit(1)
