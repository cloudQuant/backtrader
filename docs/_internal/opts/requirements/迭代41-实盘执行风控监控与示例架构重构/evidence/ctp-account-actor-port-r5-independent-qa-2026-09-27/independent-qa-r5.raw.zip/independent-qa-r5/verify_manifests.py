import hashlib,json,re
from pathlib import Path
roots={
'r4':(Path(r'D:\temp\iteration41-ctp-account-actor-port-freeze-20260927-r4'),Path(r'D:\temp\iteration41-ctp-account-actor-port-freeze-20260927-r4\manifest.json')),
'r5':(Path(r'D:\temp\iteration41-ctp-account-actor-port-r5-20260927'),Path(r'D:\temp\iteration41-ctp-account-actor-port-r5-20260927\hashes\manifest.json'))}
result={}
for name,(root,mp) in roots.items():
 b=mp.read_bytes(); data=json.loads(b); entries=data['files']; ok=[]
 for e in entries:
  p=root/e['path']; raw=p.read_bytes() if p.is_file() else None
  ok.append(raw is not None and len(raw)==e['size_bytes'] and hashlib.sha256(raw).hexdigest().lower()==e['sha256'].lower())
 result[name]={'manifest_sha256':hashlib.sha256(b).hexdigest().upper(),'payload_count':len(entries),'payload_ok':sum(ok),'payload_all_match':all(ok)}
r4_hash=result['r4']['manifest_sha256'].lower(); r5=json.loads(roots['r5'][1].read_bytes()); result['r5']['base_manifest_matches_r4']=r5['base_manifest_sha256'].lower()==r4_hash
idxroot=roots['r5'][0]; lines=(idxroot/'hashes'/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines(); parsed={}
for line in lines:
 m=re.fullmatch(r'([A-Fa-f0-9]{64})  (.+)',line)
 if m: parsed[m.group(2)]=m.group(1).lower()
r5entries=r5['files']; idxchecks=[parsed.get(e['path'])==e['sha256'].lower() for e in r5entries]
idxchecks += [parsed.get('hashes/manifest.json')==result['r5']['manifest_sha256'].lower(),parsed.get('hashes/manifest.sha256')==hashlib.sha256((idxroot/'hashes'/'manifest.sha256').read_bytes()).hexdigest().lower()]
result['r5_checksum_index']={'entries':len(parsed),'checks_passed':sum(idxchecks),'checks_total':len(idxchecks)}
print(json.dumps(result,indent=2))
if not result['r4']['payload_all_match'] or not result['r5']['payload_all_match'] or not result['r5']['base_manifest_matches_r4'] or any(not x for x in idxchecks): raise SystemExit(1)
