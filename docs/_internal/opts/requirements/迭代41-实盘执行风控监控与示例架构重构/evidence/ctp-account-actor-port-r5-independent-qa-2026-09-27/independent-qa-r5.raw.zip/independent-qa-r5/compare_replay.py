import hashlib, json
from pathlib import Path
cand=Path(r'D:\temp\iteration41-ctp-account-actor-port-r5-20260927')
replay=Path(r'D:\temp\iteration41-ctp-account-actor-port-r5-independent-qa-20260927\replay')
mp={
'source/account_actor_port.py':'account_actor_port.py',
'source/store_boundary_harness.py':'store_boundary_harness.py',
'source/store_boundary_harness_testonly.py':'store_boundary_harness_testonly.py',
'source/README.md':'README.md',
'source/INTEGRATION_CONTRACT.md':'INTEGRATION_CONTRACT.md',
'tests/test_store_boundary_harness.py':'tests/test_store_boundary_harness.py'}
rows=[]
for rel,outrel in mp.items():
 pa=cand/rel; pb=replay/outrel
 a=pa.read_bytes().replace(b'\r\n',b'\n'); b=pb.read_bytes().replace(b'\r\n',b'\n')
 rows.append({'path':rel,'candidate_normalized_sha256':hashlib.sha256(a).hexdigest().upper(),'replay_normalized_sha256':hashlib.sha256(b).hexdigest().upper(),'normalized_match':a==b,'candidate_bytes':len(pa.read_bytes()),'replay_bytes':len(pb.read_bytes())})
print(json.dumps(rows,indent=2))
