# Frozen r4 input verification

The source was copied from candidate-copy under the r4 independent QA evidence directory. Before editing, the candidate-original/manifest.json SHA-256 was verified as:

8f793cc85754f6fa447925bd0ad40570dd7f10480773f45500b56fd0933591a8

The adjacent manifest.sha256 sidecar matched. All 9 files listed by that manifest were present in candidate-copy with matching byte counts and SHA-256 values. The manifest's base_manifest_sha256 is 417ebef0fc2a85b4e37ee22122024b0118211c161795abb79dac438840b960a1.

The independent r4 QA report records 41 passing fake tests and identifies the two r5 targets: post-construction shared-route mutation entering the legacy route, and fresh-process replay through a new in-memory ledger. The original frozen r4 payload was not edited.
