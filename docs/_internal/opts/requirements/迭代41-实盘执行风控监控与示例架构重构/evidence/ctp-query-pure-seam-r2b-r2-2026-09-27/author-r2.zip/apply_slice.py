from pathlib import Path
p=Path(r'D:\temp\iteration41-ctp-query-pure-seam-r2b-20260927\repo\tests\unit\stores\test_btapistore_iteration22.py')
data=p.read_bytes()
start=data.index(b'def test_nested_query_failure_cannot_be_overridden_by_outer_success_fields():')
end=data.index(b'def test_duplicate_query_request_ids_fail_closed_across_reference_queries():', start)
# Preserve surrounding source bytes, including the file's mixed EOLs; replace only this test function.
new=(
 b'def test_nested_query_failure_cannot_be_overridden_by_outer_success_fields():\r\n'
 b'    # Query normalization and completion validation are pure; do not construct a\r\n'
 b'    # Store or treat this read-result fixture as AccountActor authority.\r\n'
 b'    client = CompleteQueryClient()\r\n'
 b'    complete = client._result("positions")\r\n'
 b'    normalized_complete = BtApiStore._normalise_ctp_query_result(complete, "positions")\r\n'
 b'    assert BtApiStore._ctp_query_result_complete(normalized_complete) is True\r\n'
 b'\r\n'
 b'    nested_failure = {\r\n'
 b'        **complete,\r\n'
 b'        "complete": False,\r\n'
 b'        "is_last_seen": False,\r\n'
 b'        "completed_at_utc": None,\r\n'
 b'        "timed_out": True,\r\n'
 b'        "error_code": "timeout",\r\n'
 b'    }\r\n'
 b'\r\n'
 b'    result = BtApiStore._normalise_ctp_query_result(\r\n'
 b'        {**complete, "query_result": nested_failure}, "positions"\r\n'
 b'    )\r\n'
 b'\r\n'
 b'    assert result["complete"] is False\r\n'
 b'    assert BtApiStore._ctp_query_result_complete(result) is False\r\n'
 b'\r\n\r\n'
)
p.write_bytes(data[:start]+new+data[end:])
new_test=Path(r'D:\temp\iteration41-ctp-query-pure-seam-r2b-20260927\repo\tests\unit\stores\test_btapistore_ctp_query_evidence_pure.py')
new_test_source=Path(r'D:\temp\iteration41-ctp-query-pure-seam-r2b-20260927\pure-test-source.py')
new_test.write_bytes(new_test_source.read_bytes())
