from __future__ import annotations

import os
import sys
from importlib.abc import MetaPathFinder

blocked_attempts = []


class NativeSdkBlocker(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_py" or fullname.startswith("bt_api_py.") or fullname == "_ctp" or fullname.startswith("_ctp."):
            blocked_attempts.append(fullname)
            raise ModuleNotFoundError("QA guard blocks CTP SDK/native imports")
        return None


sys.meta_path.insert(0, NativeSdkBlocker())
repo = os.path.join(os.path.dirname(__file__), "repo")
sys.path.insert(0, repo)
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"

import pytest

result = pytest.main(
    [
        "-q",
        "-p",
        "no:asyncio",
        os.path.join(repo, "tests", "unit", "stores", "test_btapistore_ctp_query_evidence_pure.py"),
        os.path.join(
            repo,
            "tests",
            "unit",
            "stores",
            "test_btapistore_iteration22.py::test_nested_query_failure_cannot_be_overridden_by_outer_success_fields",
        ),
    ]
)
print(f"pytest_exit_code={int(result)}")
if int(result) != 0:
    raise SystemExit(int(result))

from backtrader.stores.btapistore import BtApiStore, BtApiStoreError

attribute_reads = []
api_calls = []


class TrapApi:
    def __getattribute__(self, name):
        attribute_reads.append(name)
        raise AssertionError(f"opaque API attribute was read: {name}")

    def __call__(self, *args, **kwargs):
        api_calls.append((args, kwargs))
        raise AssertionError("opaque API object was called")



def expect_rejected(label, **kwargs):
    try:
        BtApiStore(**kwargs)
    except BtApiStoreError as exc:
        print(f"{label}=rejected:{exc}")
        return
    raise AssertionError(f"{label} unexpectedly constructed")


os.environ.pop("BT_STORE_PROVIDER", None)
os.environ.pop("BT_GATEWAY_EXCHANGE_TYPE", None)
expect_rejected("explicit_ctp_gateway", provider="ctp_gateway", api=TrapApi())
expect_rejected(
    "nested_ctp_selector",
    provider="btapi",
    api=TrapApi(),
    api_kwargs={"exchange_kwargs": {"CTP___FUTURE": {}}},
)
os.environ["BT_STORE_PROVIDER"] = "ctp_gateway"
expect_rejected("environment_ctp_provider", provider="btapi", api=TrapApi())
os.environ.pop("BT_STORE_PROVIDER", None)
print(f"opaque_api_attribute_reads={attribute_reads}")
print(f"opaque_api_calls={api_calls}")
if attribute_reads or api_calls:
    raise SystemExit("route-gate probe reached opaque API surface")
if blocked_attempts:
    raise SystemExit(f"blocked native SDK import attempts: {blocked_attempts}")
if any(name == "bt_api_py" or name.startswith("bt_api_py.") or name == "_ctp" or name.startswith("_ctp.") for name in sys.modules):
    raise SystemExit("native SDK module remained loaded")
print("native_sdk_import_attempts=0")
print("native_sdk_modules_loaded=0")
print("guarded_probe=PASS")
