from __future__ import annotations
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()

manifest = json.loads((ROOT / "package-manifest.json").read_text(encoding="utf-8"))
if manifest.get("schema") != "iteration41-query-pure-seam-independent-qa-r2":
    raise SystemExit("unexpected manifest schema")
indexed = manifest["payloads"]
for item in indexed:
    data = (ROOT / Path(item["path"])).read_bytes()
    if len(data) != item["size_bytes"] or sha(data) != item["sha256"]:
        raise SystemExit(f"payload mismatch: {item['path']}")
index_bytes = (ROOT / "SHA256SUMS.txt").read_bytes()
if sha(index_bytes) != manifest["sha256sums_sha256"]:
    raise SystemExit("SHA256SUMS.txt hash mismatch")
parsed = []
for line in index_bytes.decode("ascii").splitlines():
    match = re.fullmatch(r"([0-9A-F]{64})  (.+)  \((\d+) bytes\)", line)
    if not match:
        raise SystemExit(f"bad SHA256SUMS entry: {line}")
    parsed.append({"path": match.group(2), "sha256": match.group(1), "size_bytes": int(match.group(3))})
if parsed != indexed:
    raise SystemExit("manifest payload table differs from SHA256SUMS")
for item in manifest["support_files"]:
    data = (ROOT / item["path"]).read_bytes()
    if len(data) != item["size_bytes"] or sha(data) != item["sha256"]:
        raise SystemExit(f"support file mismatch: {item['path']}")
expected_names = {x["path"] for x in indexed}
expected_names.update({"SHA256SUMS.txt", "package-manifest.json"})
expected_names.update(x["path"] for x in manifest["support_files"])
print(f"payloads_verified={len(indexed)}")
print(f"support_files_verified={len(manifest['support_files'])}")
print(f"sha256sums_verified={len(parsed)}")
print(f"package_manifest_sha256={sha((ROOT / 'package-manifest.json').read_bytes())}")

parser = argparse.ArgumentParser()
parser.add_argument("--zip", type=Path)
args = parser.parse_args()
if args.zip:
    with zipfile.ZipFile(args.zip, "r") as zf:
        bad = zf.testzip()
        print(f"zip_testzip={bad}")
        if bad is not None:
            raise SystemExit(f"ZIP CRC failure: {bad}")
        names = set(zf.namelist())
        if names != expected_names or len(zf.namelist()) != len(expected_names):
            raise SystemExit(f"ZIP member set mismatch: expected={sorted(expected_names)} actual={sorted(names)}")
        for name in sorted(expected_names):
            archived = zf.read(name)
            disk = (ROOT / Path(name)).read_bytes()
            if archived != disk:
                raise SystemExit(f"ZIP member differs from package directory: {name}")
        print(f"zip_members_verified={len(expected_names)}")
        print("zip_member_bytes=exact")
print("verification=PASS")
