from __future__ import annotations

import ast
import hashlib
import shutil
import subprocess
import tempfile
from pathlib import Path

QA = Path(r"D:\temp\iteration41-ctp-query-pure-seam-r2b-20260927")
BASE_TEST = Path(r"D:\source_code\backtrader\tests\unit\stores\test_btapistore_iteration22.py")
R2B_ROOT = Path(r"D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r2b\backtrader")
COPY_ROOT = QA / "repo" / "backtrader"
EXPECTED_BASE_TEST = "30EEAA2C9816E6D0792E801A6EA2A8960CC1BCAA3728679111318E5178AFA49D"
EXPECTED_STORE = "24F8199E199BBE84BBB113C3EDBBEE9E71D4736FDD8573297E24EAD3298F2518"

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

base_hash = sha(BASE_TEST)
store_hash = sha(R2B_ROOT / "stores" / "btapistore.py")
print(f"original_i22_test_sha256={base_hash}")
print(f"r2b_store_sha256={store_hash}")
assert base_hash == EXPECTED_BASE_TEST
assert store_hash == EXPECTED_STORE

source_files = {p.relative_to(R2B_ROOT).as_posix(): p.read_bytes() for p in R2B_ROOT.rglob("*.py")}
copy_files = {p.relative_to(COPY_ROOT).as_posix(): p.read_bytes() for p in COPY_ROOT.rglob("*.py")}
assert source_files.keys() == copy_files.keys()
different = [name for name in source_files if source_files[name] != copy_files[name]]
print(f"r2b_python_source_file_count={len(source_files)}")
print(f"isolated_python_source_file_count={len(copy_files)}")
print(f"different_python_source_files={different}")
assert len(source_files) == 481 and not different

isolated_test = QA / "repo" / "tests" / "unit" / "stores" / "test_btapistore_iteration22.py"
source = isolated_test.read_text(encoding="utf-8")
tree = ast.parse(source)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "test_nested_query_failure_cannot_be_overridden_by_outer_success_fields")
calls = [n for n in ast.walk(node) if isinstance(n, ast.Call)]
assert not any(isinstance(c.func, ast.Name) and c.func.id == "make_store" for c in calls)
assert not any(isinstance(c.func, ast.Name) and c.func.id == "BtApiStore" for c in calls)
pure_path = QA / "repo" / "tests" / "unit" / "stores" / "test_btapistore_ctp_query_evidence_pure.py"
pure_tree = ast.parse(pure_path.read_text(encoding="utf-8"))
pure_calls = [n for n in ast.walk(pure_tree) if isinstance(n, ast.Call)]
assert not any(isinstance(c.func, ast.Name) and c.func.id in {"BtApiStore", "make_store"} for c in pure_calls)
print("migrated_nodeid_store_construction_calls=0")
print("pure_test_store_construction_calls=0")

patch = QA / "query-evidence-test-seam.patch"
with tempfile.TemporaryDirectory(prefix="patch-verify-", dir=QA) as temp:
    verify = Path(temp)
    (verify / "tests" / "unit" / "stores").mkdir(parents=True)
    shutil.copy2(BASE_TEST, verify / "tests" / "unit" / "stores" / BASE_TEST.name)
    for extra in (True, False):
        cmd = ["git", "-c", "core.autocrlf=false", "-C", str(verify), "apply"]
        if extra:
            cmd.append("--check")
        cmd.append(str(patch))
        subprocess.run(cmd, check=True)
    for name in (BASE_TEST.name, pure_path.name):
        actual = verify / "tests" / "unit" / "stores" / name
        expected = QA / "repo" / "tests" / "unit" / "stores" / name
        assert actual.read_bytes() == expected.read_bytes(), name
        print(f"applied_{name}_sha256={sha(actual)}")
print("patch_check_and_exact_apply=PASS")
