from __future__ import annotations
import base64, csv, hashlib, io, json, os, sys, zipfile
from pathlib import Path

candidate = Path(r'D:\temp\iteration41-coordinated-release-probe-20260927-r1')
independent = Path(r'D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927')
main = Path(r'D:\source_code\backtrader')
out = Path(r'D:\temp\iteration41-g4-parent-sdk-status-qa-20260927')

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def wheel_record_audit(path: Path):
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        names = zf.namelist()
        record_names = [n for n in names if n.endswith('.dist-info/RECORD')]
        assert bad is None and len(record_names) == 1, (bad, record_names)
        record_name = record_names[0]
        rows = list(csv.reader(io.StringIO(zf.read(record_name).decode('utf-8'))))
        checked = 0
        for rel, hash_spec, size in rows:
            if rel == record_name:
                assert not hash_spec and not size
                continue
            payload = zf.read(rel)
            if hash_spec:
                algo, encoded = hash_spec.split('=', 1)
                assert algo == 'sha256'
                actual = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).decode('ascii').rstrip('=')
                assert actual == encoded, rel
                checked += 1
            if size:
                assert len(payload) == int(size), rel
        meta = [n for n in names if n.endswith('.dist-info/METADATA')]
        wheelmeta = [n for n in names if n.endswith('.dist-info/WHEEL')]
        metadata = zf.read(meta[0]).decode('utf-8')
        wheelfile = zf.read(wheelmeta[0]).decode('utf-8')
        return {'zip_members': len(names), 'record_member': record_name, 'record_sha256': hash_bytes(zf.read(record_name)), 'record_rows': len(rows), 'record_payload_rows_checked': checked, 'metadata': metadata, 'wheel': wheelfile}

src_manifest_path = candidate / 'coordinated-probe-source-manifest-final.json'
source_manifest_sha = sha(src_manifest_path)
assert source_manifest_sha == '01fa737d2a0f385dec8ce6187d95c4a104c13cce9dde6d693152df7dd94ef4b6'
build_manifest_path = candidate / 'build-input-manifest-v4.json'
build_manifest = json.loads(build_manifest_path.read_text(encoding='utf-8'))
parent_files = build_manifest['packages']['parent']['files']
assert len(parent_files) == build_manifest['packages']['parent']['file_count'] == 156
build_roots = {k: Path(v) for k, v in build_manifest['build_input_roots'].items()}
source_match = {}
for side in ('build-a', 'build-b'):
    root = build_roots[side] / 'parent'
    misses = []
    for item in parent_files:
        p = root / Path(item['path'])
        if not p.is_file() or p.stat().st_size != item['size_bytes'] or sha(p) != item['sha256']:
            misses.append(item['path'])
    assert not misses, (side, misses[:5])
    source_match[side] = len(parent_files)

wheel_paths = [
    candidate / 'wheel-build-logs-v4' / 'build-a-wheels' / 'parent' / 'bt_api_py-0.15.7.dev0+r4r3r3.67e54513-py3-none-any.whl',
    candidate / 'wheel-build-logs-v4' / 'build-b-wheels' / 'parent' / 'bt_api_py-0.15.7.dev0+r4r3r3.67e54513-py3-none-any.whl',
]
wheel_hashes = [sha(p) for p in wheel_paths]
assert wheel_hashes[0] == wheel_hashes[1] == '5e6e846d26b5038c0916fa15d3ce3f7a1c1334fd0aa160cd263d2d0397c07b0f'
wheel_size = wheel_paths[0].stat().st_size
assert wheel_size == 534260
wheel_audit = wheel_record_audit(wheel_paths[0])
assert 'Name: bt_api_py' in wheel_audit['metadata']
assert 'Version: 0.15.7.dev0+r4r3r3.67e54513' in wheel_audit['metadata']

qa_wheel = independent / 'wheelhouse' / wheel_paths[0].name
assert sha(qa_wheel) == wheel_hashes[0]
qa_archive = independent / 'author-raw-evidence.zip'
assert sha(qa_archive) == '9510abeffcf040bf4a7ea8b8e0524e93cfe1046a8b9498dbc7e26626adbb2c46'
with zipfile.ZipFile(qa_archive) as zf:
    assert zf.testzip() is None
    qa_zip_members = len(zf.namelist())

site = independent / 'venv' / 'Lib' / 'site-packages'
dist_info = site / 'bt_api_py-0.15.7.dev0+r4r3r3.67e54513.dist-info'
installed_record = dist_info / 'RECORD'
installed_record_bytes = installed_record.read_bytes()
installed_rows = list(csv.reader(io.StringIO(installed_record_bytes.decode('utf-8'))))
installed_files_checked = 0
venv = independent / 'venv'
for rel, hash_spec, size in installed_rows:
    p = (site / Path(rel)).resolve()
    if not p.exists():
        raise AssertionError(f'installed RECORD path missing: {rel}')
    if hash_spec:
        algo, encoded = hash_spec.split('=', 1)
        assert algo == 'sha256'
        actual = base64.urlsafe_b64encode(hashlib.sha256(p.read_bytes()).digest()).decode('ascii').rstrip('=')
        assert actual == encoded, rel
        installed_files_checked += 1
    if size:
        assert p.stat().st_size == int(size), rel
    assert os.path.commonpath([str(venv.resolve()), str(p)]) == str(venv.resolve()), rel
assert len(installed_rows) == 286 and installed_files_checked == 146
installed_direct_url = json.loads((dist_info / 'direct_url.json').read_text(encoding='utf-8'))
archive_hash = installed_direct_url['archive_info']['hash']
assert archive_hash == 'sha256=' + wheel_hashes[0]
assert sha(installed_record) == '2157c78969a17576397cd05828264111f79e793e6bb653532effb13b41ddf036'

install_audit = json.loads((independent / 'installation-audit.json').read_text(encoding='utf-8'))
test_summary = json.loads((independent / 'test-summary.json').read_text(encoding='utf-8'))
assert install_audit['venv_no_system_site_packages'] is True
assert install_audit['pip_install_exit'] == 0 and install_audit['pip_check_exit'] == 0
assert install_audit['installed_record_pep610']['bt_api_py']['wheel_payload_members_checked'] == 143
assert install_audit['installed_record_pep610']['bt_api_py']['all_installed_wheel_payloads_byte_identical'] is True
assert test_summary['total_executions'] == 143 and test_summary['total_failures'] == 0 and test_summary['total_errors'] == 0 and test_summary['total_skipped'] == 0
assert all(not suite['native_modules_loaded'] for suite in test_summary['suite_results'])

pin_source = main / 'backtrader_runtime' / 'ctp_artifact_provenance.py'
pin_source_text = pin_source.read_text(encoding='utf-8')
assert '"bt_api_py": CtpSdkArtifactPin(' not in pin_source_text
assert '_MANAGED_SIMNOW_MODULES = (*_READONLY_CTP_MODULES, "bt_api_py")' in pin_source_text
assert '_verify_pinned_sdk_distributions(_MANAGED_SIMNOW_MODULES, pins=CTP_SDK_ARTIFACT_PINS)' in pin_source_text

result = {
    'schema': 'iteration41-g4-parent-artifact-status-independent-qa-v1',
    'result': 'DISPOSABLE_PARENT_WHEEL_VERIFIED / THREE_PACKAGE_PIN_NOT_AVAILABLE / G4_CLOSED',
    'candidate': {
        'source_manifest_sha256': source_manifest_sha,
        'build_input_manifest_sha256': sha(build_manifest_path),
        'parent_build_inputs': source_match,
        'wheel_a_sha256': wheel_hashes[0],
        'wheel_b_sha256': wheel_hashes[1],
        'wheel_size_bytes': wheel_size,
        'wheel_zip_members': wheel_audit['zip_members'],
        'wheel_embedded_record_sha256': wheel_audit['record_sha256'],
        'wheel_embedded_record_rows': wheel_audit['record_rows'],
        'wheel_embedded_record_payload_rows_checked': wheel_audit['record_payload_rows_checked'],
        'distribution_version': '0.15.7.dev0+r4r3r3.67e54513',
    },
    'isolated_consumer': {
        'author_archive_sha256': sha(qa_archive),
        'author_archive_zip_members': qa_zip_members,
        'venv_no_system_site_packages': install_audit['venv_no_system_site_packages'],
        'pip_check_exit': install_audit['pip_check_exit'],
        'pip_check_output': install_audit['pip_check_output'],
        'installed_record_sha256': sha(installed_record),
        'installed_record_rows': len(installed_rows),
        'installed_record_file_hashes_checked': installed_files_checked,
        'installed_direct_url_archive_hash': archive_hash,
        'fake_test_executions': test_summary['total_executions'],
        'fake_test_unique_ids': test_summary['unique_node_ids'],
        'fake_test_failures': test_summary['total_failures'],
        'fake_test_errors': test_summary['total_errors'],
        'fake_test_skips': test_summary['total_skipped'],
        'native_modules_loaded': [],
    },
    'code_owned_pin': {
        'source_sha256': sha(pin_source),
        'path': str(pin_source),
        'parent_pin_present': False,
        'managed_verifier_requires': ['bt_api_base', 'bt_api_ctp', 'bt_api_py'],
        'managed_verifier_pin_mapping': 'CTP_SDK_ARTIFACT_PINS (contains only bt_api_base and bt_api_ctp)',
        'expected_fail_closed_reason': 'artifact_pin_unavailable',
    },
    'scope': ['offline wheel/hash/RECORD/origin checks', 'local fake tests only'],
    'not_established': ['three-package code pin', 'G4 native start/Join/Release', 'provider session', 'default route', 'release approval'],
}
(out / 'status-audit.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))


