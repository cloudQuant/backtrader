from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

root=Path(r'D:\temp\iteration41-g4-parent-sdk-status-qa-20260927')
archive=root/'g4-parent-sdk-independent-qa.zip'
receipt=root/'g4-parent-sdk-independent-qa.archive-receipt.json'
sha_sidecar=root/'g4-parent-sdk-independent-qa.zip.sha256'
index_path=root/'ARCHIVE-INDEX.json'
sums_path=root/'SHA256SUMS.txt'
excluded={archive.name,receipt.name,sha_sidecar.name,index_path.name,sums_path.name}

def sha(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()

files=sorted((p for p in root.rglob('*') if p.is_file() and p.name not in excluded and not (p.relative_to(root).parts[:2] in (('record-install-a','venv'),('record-install-b','venv')))),key=lambda p:p.relative_to(root).as_posix())
rows=[]
for p in files:
    rel=p.relative_to(root).as_posix()
    rows.append({'path':rel,'size_bytes':p.stat().st_size,'sha256':sha(p)})
index={'schema':'iteration41-g4-parent-sdk-independent-qa-archive-index-v1','member_count':len(rows),'members':rows}
index_path.write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
all_for_sums=rows+[{'path':index_path.name,'size_bytes':index_path.stat().st_size,'sha256':sha(index_path)}]
sums=''.join(f"{r['sha256']}  {r['path']}\n" for r in all_for_sums)
sums_path.write_text(sums,encoding='utf-8')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
    for p in files:
        zf.write(p,p.relative_to(root).as_posix())
    zf.write(index_path,index_path.name)
    zf.write(sums_path,sums_path.name)
with zipfile.ZipFile(archive,'r') as zf:
    bad=zf.testzip()
    assert bad is None,bad
    members=set(zf.namelist())
    expected={r['path'] for r in rows}|{index_path.name,sums_path.name}
    assert members==expected,(members^expected)
    for r in rows:
        assert hashlib.sha256(zf.read(r['path'])).hexdigest()==r['sha256'],r['path']
    assert hashlib.sha256(zf.read(index_path.name)).hexdigest()==sha(index_path)
    for line in zf.read(sums_path.name).decode('utf-8').splitlines():
        expected_sha,rel=line.split('  ',1)
        assert hashlib.sha256(zf.read(rel)).hexdigest()==expected_sha,rel
archive_sha=sha(archive)
sha_sidecar.write_text(f'{archive_sha}  {archive.name}\n',encoding='ascii')
receipt_value={
 'schema':'iteration41-g4-parent-sdk-independent-qa-archive-receipt-v1',
 'archive_path':str(archive),
 'archive_sha256':archive_sha,
 'archive_size_bytes':archive.stat().st_size,
 'archive_index_sha256':sha(index_path),
 'archive_index_member_count':len(rows),
 'zip_testzip':None,
 'all_member_hashes_match':True,
 'sha256_sums_sha256':sha(sums_path),
 'disposition':'DISPOSABLE_PARENT_WHEEL_VERIFIED / THREE_PACKAGE_PIN_NOT_AVAILABLE / G4_CLOSED',
}
receipt.write_text(json.dumps(receipt_value,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt_value,indent=2))

