from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

root = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
manifest_path = root / "evidence/final-output-manifest.json"
excluded_cache_dirs = {"__pycache__", ".pytest_cache", ".ruff_cache"}
outputs = []
for path in sorted(root.rglob("*")):
    if not path.is_file() or path == manifest_path:
        continue
    relative = path.relative_to(root)
    if excluded_cache_dirs.intersection(relative.parts):
        continue
    data = path.read_bytes()
    outputs.append(
        {"path": relative.as_posix(), "bytes": len(data), "sha256": sha256(data).hexdigest()}
    )

qa_root = Path(r"D:\temp\iteration41-g5-order-authority-independent-qa-20260927")
qa_manifest = qa_root / "qa-manifest.json"
source = {
    "format": "iteration41-g5-worker-handoff-output-manifest.v1",
    "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "status": "LOCAL_OFFLINE_CONTRACTS / NO_WRITE / LIVE_NO_GO",
    "backtrader_source_head": "ad2c142b9a8b42cede85886528c681abdfcb8096",
    "sdk_snapshot_head": "2700cb5454ef4c3d1780eda28b6f33307a860998",
    "frozen_input_manifest_sha256": sha256(
        (root / "frozen-input-manifest.json").read_bytes()
    ).hexdigest(),
    "archived_independent_qa_manifest_sha256": sha256(qa_manifest.read_bytes()).hexdigest(),
    "excluded_paths_note": (
        "Generated Python and tool cache directories are omitted. Frozen source inputs "
        "are enumerated in frozen-input-manifest.json."
    ),
    "outputs": outputs,
}
manifest_path.write_text(json.dumps(source, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(f"outputs={len(outputs)}")
print(f"frozen_input_manifest_sha256={source['frozen_input_manifest_sha256']}")
print(f"archived_qa_manifest_sha256={source['archived_independent_qa_manifest_sha256']}")
print(f"manifest={manifest_path}")
