from pathlib import Path
import difflib

root = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
source_paths = (
    "backtrader/stores/ctp_i9_managed_dispatch.py",
    "backtrader/stores/ctp_i9_parent_request_builder.py",
)

def source_diff(path: str) -> str:
    old = root / "inputs" / "backtrader" / path
    new = root / "implementation/main_repo_patch" / path
    return "".join(
        difflib.unified_diff(
            old.read_text(encoding="utf-8").splitlines(keepends=True),
            new.read_text(encoding="utf-8").splitlines(keepends=True),
            fromfile="a/" + path,
            tofile="b/" + path,
        )
    )

builder_path = "backtrader/stores/ctp_i9_parent_request_builder.py"
(root / "implementation/main_repo_patch/G5_ORDERREF_ACTIONREF_AUTHORITY.patch").write_text(
    source_diff(builder_path), encoding="utf-8", newline=""
)
(root / "implementation/main_repo_patch/G5_ORDERREF_ACTIONREF_WORKER_HANDOFF.patch").write_text(
    "".join(source_diff(path) for path in source_paths), encoding="utf-8", newline=""
)
