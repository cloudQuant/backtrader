from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
manifest = json.loads((ROOT / "frozen-input-manifest.json").read_text(encoding="utf-8"))
missing = []
changed = []
for item in manifest:
    relative = Path(item["path"])
    path = ROOT / relative
    if not path.is_file():
        missing.append(item["path"])
        continue
    if sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        changed.append(item["path"])

print(f"entries={len(manifest)} missing={len(missing)} changed={len(changed)}")
for path in missing:
    print("missing=" + path)
for path in changed:
    print("changed=" + path)
if missing or changed:
    raise SystemExit(1)
