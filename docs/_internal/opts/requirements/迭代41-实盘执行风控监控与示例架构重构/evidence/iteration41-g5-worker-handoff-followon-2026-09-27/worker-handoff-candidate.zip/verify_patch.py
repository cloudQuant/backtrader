from hashlib import sha256
from pathlib import Path
import shutil
import subprocess

root = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
relative_paths = (
    "backtrader/stores/ctp_i9_managed_dispatch.py",
    "backtrader/stores/ctp_i9_parent_request_builder.py",
)
patch_check = root / "patch-check"
for relative in relative_paths:
    frozen = root / "inputs" / "backtrader" / relative
    target = patch_check / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(frozen, target)

patch_path = root / "implementation/main_repo_patch/G5_ORDERREF_ACTIONREF_WORKER_HANDOFF.patch"
check = subprocess.run(
    ["git", "apply", "--check", str(patch_path)],
    cwd=patch_check,
    capture_output=True,
    text=True,
    check=False,
)
if check.returncode:
    raise SystemExit(check.stdout + check.stderr)
apply = subprocess.run(
    ["git", "apply", str(patch_path)],
    cwd=patch_check,
    capture_output=True,
    text=True,
    check=False,
)
if apply.returncode:
    raise SystemExit(apply.stdout + apply.stderr)

normalize = lambda value: value.replace(b"\r\n", b"\n")
lines = ["git apply --check: passed", "git apply: passed"]
for relative in relative_paths:
    applied = (patch_check / relative).read_bytes()
    candidate = (root / "implementation/main_repo_patch" / relative).read_bytes()
    match = normalize(applied) == normalize(candidate)
    lines.extend(
        (
            f"path={relative}",
            f"applied_raw_sha256={sha256(applied).hexdigest()}",
            f"candidate_raw_sha256={sha256(candidate).hexdigest()}",
            f"normalized_match={match}",
        )
    )
    if not match:
        raise SystemExit("normalized patch result differs: " + relative)
lines.append("Patch output matches both candidate Backtrader source files after LF normalization.")
(root / "evidence/g5-followon-patch-apply-check.log").write_text(
    "\n".join(lines) + "\n", encoding="utf-8"
)
