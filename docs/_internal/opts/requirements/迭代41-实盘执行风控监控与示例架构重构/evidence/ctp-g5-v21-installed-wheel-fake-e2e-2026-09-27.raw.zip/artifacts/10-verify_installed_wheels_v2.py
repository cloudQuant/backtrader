import base64
import csv
import hashlib
import importlib
import importlib.metadata as metadata
import json
import pathlib
import sys
import zipfile

EVIDENCE = pathlib.Path(r"D:\temp\g5-v21-finalizer-evidence-20260927")
VENV = pathlib.Path(r"D:\q\unified-g5-v21-consumer-20260927")
SITE = VENV / "Lib" / "site-packages"
V21_ROOT = pathlib.Path(r"D:\temp\iteration41_v21_ctp_account_handoff_freeze_r3_20260927")
BUILD_ROOT = pathlib.Path(r"D:\temp\g5-v21-execution-wheel-build-20260927\source")
PACKAGES = {
    "bt_api_execution": ("bt_api_execution", "0.2.0", r"D:\temp\g5-v21-execution-wheel-build-20260927\wheelhouse\bt_api_execution-0.2.0-py3-none-any.whl", "08743c4a1bf978c02c9391a787f692fef8a1d49d3ee34afc602b3c1393ff4f6e"),
    "bt_api_ctp": ("bt_api_ctp", "2.0.4+iteration41.i9", r"D:\q\lazy-ctp-build-e\wheelhouse-e\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl", "f08e231dd65599438c1467eb3d65f1205dd9a458ea147e1f996a8d12a40ba7ab"),
    "bt_api_py": ("bt_api_py", "0.15.5", r"D:\q\pwb\bt_api_py-0.15.5-py3-none-any.whl", "3d4ccf8560f28dc6f0279860ca6257e4980b7c6efb0f9932fe66c98b681a660d"),
    "bt_api_base": ("bt_api_base", "0.15.4", r"D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse\bt_api_base-0.15.4-py3-none-any.whl", "cfe3507e1324f675454c41c37cd09ff72c8947c5254e9496e97c373cb8f3b369"),
    "bt_api_risk": ("bt_api_risk", "0.1.0", r"D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse\bt_api_risk-0.1.0-py3-none-any.whl", "d7e7bb28cfd049be3aa0b50f1e9deb7a83e97f24da3bc9bce51dc6f599a5202f"),
    "bt_api_monitor": ("bt_api_monitor", "0.1.0", r"D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse\bt_api_monitor-0.1.0-py3-none-any.whl", "0277663855356b22a7946da07ed4c6d33cebac11d93cbdc152531c287040ae8e"),
    "cryptography": ("cryptography", "44.0.3", str(EVIDENCE / "public-test-wheelhouse" / "cryptography-44.0.3-cp39-abi3-win_amd64.whl"), "5d186f32e52e66994dce4f766884bcb9c68b8da62d61d9d215bfe5fb56d21334"),
    "cffi": ("cffi", "1.15.1", str(EVIDENCE / "public-test-wheelhouse" / "cffi-1.15.1-cp311-cp311-win_amd64.whl"), "04ed324bda3cda42b9b695d51bb7d54b680b9719cfab04227cdd1e04e5de3104"),
    "pycparser": ("pycparser", "2.21", str(EVIDENCE / "public-test-wheelhouse" / "pycparser-2.21-py2.py3-none-any.whl"), "8ee45429555515e1f6b185e78100aea234072576aa43ab53aefcae078162fca9"),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_record_rows(rows, read_bytes, label):
    hashed = 0
    unhashed = {"record_self": 0, "generated_pyc": 0, "other": []}
    for name, digest_field, size_field in rows:
        data = read_bytes(name)
        if size_field and len(data) != int(size_field):
            raise AssertionError(f"{label} size mismatch: {name}")
        if not digest_field:
            if name.endswith(".dist-info/RECORD"):
                unhashed["record_self"] += 1
            elif "/__pycache__/" in f"/{name}" and name.endswith(".pyc"):
                unhashed["generated_pyc"] += 1
            else:
                unhashed["other"].append(name)
            continue
        mode, expected = digest_field.split("=", 1)
        actual = base64.urlsafe_b64encode(hashlib.new(mode, data).digest()).decode("ascii").rstrip("=")
        if actual != expected:
            raise AssertionError(f"{label} hash mismatch: {name}")
        hashed += 1
    if unhashed["other"]:
        raise AssertionError(f"unexpected unhashed {label} rows: {unhashed['other']}")
    return {"rows": len(rows), "hashed_rows_verified": hashed, "unhashed_rows": unhashed}


def verify_wheel_and_install(dist, wheel_path, expected_sha):
    wheel_path = pathlib.Path(wheel_path)
    wheel_bytes = wheel_path.read_bytes()
    if sha256(wheel_bytes) != expected_sha:
        raise AssertionError(f"wheel hash mismatch: {wheel_path}")
    with zipfile.ZipFile(wheel_path) as archive:
        names = archive.namelist()
        record_name = next(n for n in names if n.endswith(".dist-info/RECORD"))
        rows = list(csv.reader(archive.read(record_name).decode("utf-8").splitlines()))
        wheel_record = verify_record_rows(rows, archive.read, "wheel RECORD")
        installed = 0
        for name, digest_field, size_field in rows:
            if name == record_name:
                continue
            expected = archive.read(name)
            installed_path = pathlib.Path(dist.locate_file(name)).resolve()
            if not installed_path.is_file() or installed_path.read_bytes() != expected:
                raise AssertionError(f"installed file differs from exact wheel: {name}")
            installed += 1
    installed_record_path = pathlib.Path(dist._path) / "RECORD"
    installed_rows = list(csv.reader(installed_record_path.read_text(encoding="utf-8").splitlines()))
    installed_record = verify_record_rows(
        installed_rows,
        lambda name: pathlib.Path(dist.locate_file(name)).resolve().read_bytes(),
        "installed RECORD",
    )
    return {
        "wheel_sha256": sha256(wheel_bytes),
        "wheel_bytes": len(wheel_bytes),
        "wheel_record": wheel_record,
        "installed_wheel_files_byte_equal": installed,
        "installed_record": installed_record,
    }


venv_cfg = (VENV / "pyvenv.cfg").read_text(encoding="utf-8")
if "include-system-site-packages = false" not in venv_cfg.lower():
    raise AssertionError("consumer venv permits system site packages")
if pathlib.Path(sys.executable).resolve() != (VENV / "Scripts" / "python.exe").resolve():
    raise AssertionError(f"wrong interpreter: {sys.executable}")
if any(pathlib.Path(item).resolve() == pathlib.Path(r"C:\Anaconda3\Lib\site-packages").resolve() for item in sys.path if item):
    raise AssertionError("global Anaconda site-packages leaked into test interpreter")

results = {}
module_origins = {}
for dist_name, (module_name, expected_version, wheel_path, expected_wheel_sha) in PACKAGES.items():
    dist = metadata.distribution(dist_name)
    if dist.version != expected_version:
        raise AssertionError(f"version mismatch {dist_name}: {dist.version}")
    module = importlib.import_module(module_name)
    origin = pathlib.Path(module.__file__).resolve()
    if SITE.resolve() not in origin.parents:
        raise AssertionError(f"module did not resolve from venv site-packages: {module_name} {origin}")
    module_origins[module_name] = str(origin)
    direct_url_text = dist.read_text("direct_url.json")
    if not direct_url_text:
        raise AssertionError(f"missing direct_url.json for {dist_name}")
    direct_url = json.loads(direct_url_text)
    archive_hashes = direct_url.get("archive_info", {}).get("hashes", {})
    if archive_hashes.get("sha256") != expected_wheel_sha:
        raise AssertionError(f"direct_url wheel hash mismatch {dist_name}")
    results[dist_name] = {
        "version": dist.version,
        "wheel_path": wheel_path,
        "direct_url": direct_url,
        **verify_wheel_and_install(dist, wheel_path, expected_wheel_sha),
    }

ctp_client = importlib.import_module("bt_api_ctp.ctp.client")
ctp_client_origin = pathlib.Path(ctp_client.__file__).resolve()
if SITE.resolve() not in ctp_client_origin.parents:
    raise AssertionError(f"CTP client did not resolve from installed wheel: {ctp_client_origin}")
if "bt_api_ctp.ctp._ctp" in sys.modules:
    raise AssertionError("CTP native extension was loaded")

source_manifest_bytes = (V21_ROOT / "SOURCE-MANIFEST.json").read_bytes()
source_manifest = json.loads(source_manifest_bytes)
for entry in source_manifest["files"]:
    rel = pathlib.PurePosixPath(entry["path"])
    for root in (V21_ROOT, BUILD_ROOT):
        path = root.joinpath(*rel.parts)
        if sha256(path.read_bytes()) != entry["sha256"]:
            raise AssertionError(f"V21 source manifest mismatch: {path}")

execution_wheel = pathlib.Path(PACKAGES["bt_api_execution"][2])
with zipfile.ZipFile(execution_wheel) as archive:
    store_member_sha = sha256(archive.read("bt_api_execution/store.py"))
    source_store_sha = sha256((V21_ROOT / "src" / "bt_api_execution" / "store.py").read_bytes())
    if store_member_sha != source_store_sha:
        raise AssertionError("V21 finalizer bytes differ between frozen source and built wheel")

receipt = {
    "schema": "g5-v21-installed-wheel-verification.v2",
    "python": sys.version,
    "executable": sys.executable,
    "venv_include_system_site_packages": False,
    "sys_prefix": sys.prefix,
    "sys_base_prefix": sys.base_prefix,
    "site_packages": str(SITE.resolve()),
    "global_site_packages_on_sys_path": False,
    "module_origins": module_origins,
    "ctp_client_origin": str(ctp_client_origin),
    "package_distributions": results,
    "v21_source_manifest_sha256": sha256(source_manifest_bytes),
    "v21_source_files_verified_in_frozen_and_build_copy": len(source_manifest["files"]),
    "v21_store_source_and_wheel_member_sha256": store_member_sha,
    "ctp_native_module_names_in_sys_modules": [],
    "test_runner_public_cryptography_wheel_sha256": PACKAGES["cryptography"][3],
}
(EVIDENCE / "installed-wheel-verification-v2.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({
    "schema": receipt["schema"],
    "python": receipt["python"],
    "executable": receipt["executable"],
    "venv_include_system_site_packages": False,
    "global_site_packages_on_sys_path": False,
    "module_origins": module_origins,
    "source_manifest_sha256": receipt["v21_source_manifest_sha256"],
    "source_files_verified": len(source_manifest["files"]),
    "ctp_native_module_names_in_sys_modules": [],
    "package_records": {name: value["wheel_record"] for name, value in results.items()},
}, indent=2))
