import importlib.util
import json
import sys
from importlib.abc import MetaPathFinder
from pathlib import Path

class BlockCTPNative(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_ctp.ctp._ctp':
            raise ModuleNotFoundError('native extension blocked for fake evidence')
        return None

sys.meta_path.insert(0, BlockCTPNative())
repo = Path(r'D:\work\backtrader-g5-cancel-issuer')
site = Path(r'D:\q\unified-v20r3-consumer-20260927\Lib\site-packages')
sys.path[:0] = [str(repo), str(site)]
spec = importlib.util.spec_from_file_location('g5_test_candidate', repo / 'tests/integration/test_iteration41_ctp_i9_account_session_candidate.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
import pytest
mp = pytest.MonkeyPatch()
root = Path(r'D:\temp\iteration41-g5-r3-crash-claim-repro')
candidate, store, reserve, make_prepared, _ = mod._source_candidate_fixture(root, mp)
reservation = reserve('g5-crash-claim-repro')
prepared = make_prepared(reservation)
source_binding = candidate.stage_and_queue(prepared)
claim = store.claim_ctp_dispatch_command_for_session(
    candidate._scope,
    prepared.command_id,
    owner_handle=candidate.owner_handle,
    writer_lease=candidate._writer_lease,
    authority_verifier=candidate._worker._authority_verifier,
    required_local_queue_receipt_id=source_binding.local_queue_receipt_id,
)
if claim is None:
    raise SystemExit('expected durable Store claim')
command_before = store._connection.execute('SELECT status,native_call_inflight,unknown_reason FROM ctp_dispatch_commands WHERE command_id=?', (prepared.command_id,)).fetchone()
owner_before = store._connection.execute('SELECT owner_state,poison_code FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id=?', (candidate.owner_handle.owner_intent_id,)).fetchone()
family_before = store._connection.execute('SELECT owner_state FROM ctp_account_family_owners WHERE family_key=?', (store._ctp_account_family_key(candidate._scope),)).fetchone()
db_path = store._connection.execute('PRAGMA database_list').fetchone()[2]
api_order_calls = [call for call in mod._FakeTraderApiFactory.instances[-1].calls if isinstance(call, tuple) and call[0] in {'ReqOrderInsert','ReqOrderAction'}]
store.close()  # crash boundary: no candidate.stop(), no poison/cleanup transition
store_type = mod._candidate_types_or_skip()[1]
reopened = store_type(db_path)
command_after = reopened._connection.execute('SELECT status,native_call_inflight,unknown_reason FROM ctp_dispatch_commands WHERE command_id=?', (prepared.command_id,)).fetchone()
owner_after = reopened._connection.execute('SELECT owner_state,poison_code FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id=?', (candidate.owner_handle.owner_intent_id,)).fetchone()
family_after = reopened._connection.execute('SELECT owner_state FROM ctp_account_family_owners WHERE family_key=?', (reopened._ctp_account_family_key(candidate._scope),)).fetchone()
try:
    reopened.acquire_ctp_account_family_owner(candidate._scope)
except BaseException as error:
    reacquire = type(error).__name__
else:
    reacquire = 'unexpectedly_acquired'
reopened.close()
mp.undo()
print(json.dumps({
    'claim_type': type(claim).__name__,
    'command_before_crash': list(command_before),
    'owner_before_crash': list(owner_before),
    'family_owner_before_crash': None if family_before is None else family_before[0],
    'command_after_reopen': list(command_after),
    'owner_after_reopen': list(owner_after),
    'family_owner_after_reopen': None if family_after is None else family_after[0],
    'new_family_owner_result': reacquire,
    'native_order_calls': api_order_calls,
    'db_path': db_path,
}, sort_keys=True))
