import hashlib
import json
import pathlib
import urllib.request

OUT = pathlib.Path(r"D:\temp\g5-v21-finalizer-evidence-20260927\public-test-wheelhouse")
SPECS = {
    "cryptography": ("44.0.3", lambda name: name.endswith("cp39-abi3-win_amd64.whl")),
    "cffi": ("1.15.1", lambda name: name.endswith("cp311-cp311-win_amd64.whl")),
    "pycparser": ("2.21", lambda name: name.endswith("py2.py3-none-any.whl")),
}
records = []
for package, (version, selector) in SPECS.items():
    json_url = f"https://pypi.org/pypi/{package}/{version}/json"
    request = urllib.request.Request(json_url, headers={"User-Agent": "iteration41-offline-test-dependency-audit/1"})
    with urllib.request.urlopen(request, timeout=30) as response:
        metadata_bytes = response.read()
    metadata_path = OUT / f"pypi-{package}-{version}.json"
    metadata_path.write_bytes(metadata_bytes)
    metadata = json.loads(metadata_bytes)
    matches = [item for item in metadata["urls"] if selector(item["filename"])]
    if len(matches) != 1:
        raise SystemExit(f"expected one compatible wheel for {package}, got {[item['filename'] for item in matches]}")
    item = matches[0]
    expected = item["digests"]["sha256"].lower()
    request = urllib.request.Request(item["url"], headers={"User-Agent": "iteration41-offline-test-dependency-audit/1"})
    with urllib.request.urlopen(request, timeout=60) as response:
        wheel = response.read()
    actual = hashlib.sha256(wheel).hexdigest()
    if actual != expected:
        raise SystemExit(f"PyPI hash mismatch for {item['filename']}: {actual} != {expected}")
    wheel_path = OUT / item["filename"]
    wheel_path.write_bytes(wheel)
    records.append({
        "package": package,
        "version": version,
        "filename": item["filename"],
        "url": item["url"],
        "sha256": actual,
        "bytes": len(wheel),
        "pypi_json_url": json_url,
        "pypi_json_sha256": hashlib.sha256(metadata_bytes).hexdigest(),
    })
    print(f"{item['filename']} {len(wheel)} {actual}")
(OUT / "download-manifest.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
