from account_actor_port import StoreRouteDescriptor, classify_store_route, require_account_actor_before_local_client, RouteKind
from store_boundary_harness import StoreBoundaryHarness

observations = {}
class SideEffectApi:
    def __init__(self): self.reads = 0
    @property
    def exchange_kwargs(self):
        self.reads += 1
        return {}
api = SideEffectApi()
route = StoreRouteDescriptor(provider='ctp', api=api)
observations['ctp_injected_api_route_kind'] = classify_store_route(route).value
observations['ctp_injected_api_property_reads_before_gate'] = api.reads

constructed = []
class UnclassifiedCtpLikeApi:
    def __init__(self): constructed.append('constructed')
route = StoreRouteDescriptor(provider='custom-provider', api_cls=UnclassifiedCtpLikeApi)
observations['unknown_provider_with_api_cls_route_kind'] = classify_store_route(route).value
try:
    require_account_actor_before_local_client(route, None)
    observations['unknown_provider_unavailable_actor_gate'] = 'allowed'
except Exception as exc:
    observations['unknown_provider_unavailable_actor_gate'] = type(exc).__name__
StoreBoundaryHarness(route, api_factory=UnclassifiedCtpLikeApi)
observations['unknown_provider_factory_calls'] = len(constructed)
for key, value in observations.items(): print(f'{key}={value}')
