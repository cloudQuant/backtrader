from account_actor_port import StoreRouteDescriptor, classify_store_route, require_account_actor_before_local_client
observations = {}
class SideEffectApi:
    def __init__(self): self.reads = 0
    @property
    def exchange_kwargs(self):
        self.reads += 1
        return {}
api = SideEffectApi()
route = StoreRouteDescriptor(provider='btapi', api=api)
observations['btapi_injected_api_route_kind'] = classify_store_route(route).value
observations['btapi_injected_api_property_reads_before_reject'] = api.reads
try: require_account_actor_before_local_client(route, None)
except Exception as exc: observations['unavailable_actor_rejection'] = type(exc).__name__
observations['btapi_api_property_reads_after_reject'] = api.reads
for key, value in observations.items(): print(f'{key}={value}')
