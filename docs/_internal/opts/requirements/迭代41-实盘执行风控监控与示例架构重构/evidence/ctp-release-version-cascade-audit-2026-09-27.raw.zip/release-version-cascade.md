# Iteration 41 release-version cascade audit

**Classification:** read-only planning evidence. No default pins or source trees changed. No package was built or installed. No CTP native/provider/session, private configuration, account, or network was used.

## Frozen inputs and provenance

| Input | Identity | Current evidence |
|---|---|---|
| Execution R3r3 + V21 composite | `D:\temp\iteration41_v20_r3r3_v21_handoff_freeze_r1_20260927\COMPOSITE-SOURCE-MANIFEST.json`, SHA `00577665667A33C9A7D62D331C0CAD99B0B660790D0B475D0BD8C1B6CAA6E2DD`; metadata is `bt_api_execution 0.2.0` | Inputs: R3r3 `7655307f…`, V21 `b3a614d6…`, base `15c37a6c…`. Composite `store.py` SHA `79931909…`, `cancellation.py` SHA `a38acbc9…`. The base commit recorded in the manifest is not a clean commit for the overlaid composite. |
| Parent cancel-control r2 | `D:\temp\iteration41-cancel-control-composition-freeze-r2-20260927`; metadata is `bt_api_py 0.15.5` | `pyproject.toml` `7AA5FAD4…`; `cancellation_control.py` `7C959792…`; test `CF27581E…`; verified result 23 passed, 1 warning in the frozen run; independent rerun 23 passed in 8.82s with no warning, exit 0. Source-only, no new wheel. |
| Parent terminal issuer r2 | `D:\temp\iteration41_parent76_cancel_resolution_issuer_r3r3_review_20260927_freeze_r2\snapshot-manifest.json`, SHA `50B0D8B9…` | Parent base HEAD `76d5e0e6…`; issuer `D902A376…`; tests `AB1CCC88…` and `39EBC5BF…`; result 23 passed. Main composition wiring is excluded. |
| Risk cancel-resolution candidate | `D:\temp\iteration41_risk_cancel_resolution_20260927\risk-cancel-resolution-manifest.json`, SHA `B5B066E9…` | Base HEAD `d4bc030…`; metadata remains `0.1.0`; focused 72 passed and package 222 passed, each with one warning. No new wheel identity. |
| G5 V21 installed-wheel evidence | `D:\temp\g5-v21-finalizer-evidence-20260927\final-receipt-v21.json`, SHA `7D26D498…` | 45 passed, 1 warning. It still blocks crash-after-CLAIMED/before-Req recovery when owner/family remain ACTIVE. No process-crash proof or real CTP request. |
| V22 G5 | Not a frozen input | Root reports active edits. The currently visible composite manifest is byte-identical to R3r3+V21 r1; its name cannot be used as V22 provenance. |

## Minimum version cascade to reserve

These are candidate next versions, not assigned or built releases. Check the package registry before reserving them.

| Distribution | Candidate version | Reason |
|---|---:|---|
| `bt_api_execution` | `0.2.2` | `0.2.0` describes multiple older trees; `0.2.1` was already built for the R3r3-only migration probe. Final R3r3+V21+V22 needs a distinct source identity. |
| `bt_api_risk` | `0.1.1` | Cancel-dispatch resolution is new source still carrying `0.1.0` metadata. |
| `bt_api_py` | `0.15.7` | `0.15.5` is the current parent source; `0.15.6` was built for the older parent archive. Final parent must merge control r2, issuer r2, and the execution `0.2.2` guard. |
| `bt_api_ctp` | Pending V22 | Main pin and V21 test wheel both say `2.0.4+iteration41.i9`, but hashes differ (`7148c4…` vs `f08e23…`). Choose one exact source/hash and a unique version only after V22 freezes. |
| `bt_api_base`, `bt_api_monitor` | Keep current pins unless source changes | Existing constraints accept base `0.15.5`; monitor is unchanged. Do not confuse `bt_api_base 0.15.5` with `bt_api_py 0.15.5`. |

Execution metadata declares Python `>=3.11`, no runtime dependencies. Risk declares Python `>=3.9`, `bt_api_base>=0.15.4,<0.16`, NumPy, Pydantic, and typing-extensions. Parent declares Python `>=3.11`, requires `bt_api_base>=0.15.4`, and has no execution/risk dependency extra; its `_execution_session.py` exact gates still require execution `0.2.0` at lines 115 and 134. The final optional managed install should carry exact `bt_api_execution==0.2.2` and `bt_api_risk==0.1.1` pins in a release lock/artifact set or explicit managed extra; keep ordinary SDK installation optional.

## Why the previous 0.2.1 / 0.15.6 probe does not transfer

The probe receipt is `D:\temp\iteration41_v20_r3r3_021_pin_migration_20260927\final-probe-receipt.json`, SHA `FEE30BDA…`. It built two byte-identical `bt_api_execution 0.2.1` wheels (SHA `0bdc90ea…`, RECORD `118225c7…`) from the 30-payload R3r3 input only. Its `bt_api_py 0.15.6` came from parent commit `e53b6b5…` / tree `df14a637…`, not the control/issuer r2 overlays. It excluded V21 handoff/finalizer, parent cancel-control r2, parent issuer r2, and risk cancel-resolution. Probe package suites were 284/2 skipped and 356/2 skipped, but its main overlay suite was 77 passed, 16 failed, 1 skipped (exit 1). These artifacts cannot be relabeled as the final tuple.

The V21 standalone wheel is also not the R3r3+V21 composite: V21 `store.py` SHA is `1f01eda…`, composite `store.py` is `79931909…`. The V21 strict-consumer wheel is still version `0.2.0`, SHA `08743c4a…`.

## Main-tree pins and tests to update after tuple freeze

Production gates currently pin execution `0.2.0` in:

- `D:\source_code\backtrader\backtrader_runtime\ctp_managed_action_scope_resolver.py:97,434`
- `D:\source_code\backtrader\backtrader_runtime\ctp_managed_action_authority.py:123,153`
- `D:\source_code\backtrader\backtrader_runtime\ctp_managed_account_runtime_candidate.py:244-248`
- `D:\source_code\backtrader\backtrader_runtime\ctp_i9_account_session_candidate.py:60-62`
- `D:\source_code\backtrader\backtrader_runtime\_iteration41_l2_fixture\managed_013_3.py:47-49`
- `D:\source_code\backtrader\backtrader_runtime\_iteration41_l2_fixture\mechanical_p1b.py:53-55`

The artifact manifest is `D:\source_code\backtrader\backtrader_runtime\ctp_i9_candidate_artifact_set.py:34-35,117-121`; preserve its reviewed I9 three-wheel set and add a distinct full cancellation-composition set with exact wheel, RECORD, source-manifest, and evidence hashes. Update exact gates and negative tests in `tests/unit/runtime/test_ctp_managed_action_scope_resolver.py`, `test_ctp_managed_action_authority.py`, `test_ctp_i9_candidate_artifact_set.py`, `test_iteration41_l2_fixture_package.py`, `tests/unit/stores/test_ctp_i9_managed_dispatch_bridge.py`, `test_ctp_i9_parent_request_builder.py`, and `tests/integration/test_iteration41_managed_cancellation_composition.py:217-219,814-816`. Keep the I2/read-only base pins unchanged.

External package changes needed for the composed release: parent `pyproject.toml` version and optional managed dependency metadata; parent `_execution_session.py` execution gates; merge the frozen cancel-control r2 and issuer r2 into one parent source manifest. Risk needs a unique metadata version and wheel for the frozen cancel-resolution API.

## Release blockers

1. V22 G5 is not frozen. V21 evidence does not cover an authentic crash after CLAIMED but before Req while owner/family remain ACTIVE.
2. Main has no references yet for `resolve_cancel_dispatch_freeze`, `CancelDispatchResolutionProof`, `read_terminal_cancel_commit`, or `cancel_dispatch_resolution_guard`; the typed terminal proof path is not wired into the main managed bridge.
3. Parent cancel-control r2 and terminal issuer r2 are separate snapshots; they need one parent tree, a new parent version, and one exact source manifest/wheel.
4. Risk remains at metadata `0.1.0` for changed source; its final wheel must be bound into the same composition manifest.
5. Resolve the same-version/different-hash CTP artifact conflict, then create one full artifact set and perform reproducible builds, installed RECORD/origin verification, `pip check`, and a combined fake-only consumer suite with old-version and wrong-digest rejection.
6. None of this authorizes a default CTP route, real session, provider call, or trading write. Keep `NO_WRITE / LIVE_NO_GO` unchanged.

Machine-readable receipt: `D:\temp\iteration41-release-version-cascade-audit-20260927\release-version-cascade.json` (generated and validated; see the machine-readable receipt).

