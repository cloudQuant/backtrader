from types import SimpleNamespace
from scripts import ctp_i13_i15_worker_output_channel as m
request_id = 'a' * 32
nonce = 'b' * 32
payload = m._canonical_json({'schema': m.WORKER_SCHEMA, 'observation': {'x': 1}})
frame = m._encode_frame(payload, request_id=request_id, nonce=nonce)
evidence = SimpleNamespace(process_created=True, job_assignment_observed=True, launcher_resumed=True, launcher_exit_observed=True, launcher_exit_code=0, job_termination_requested=False, job_empty_observed=True, containment='verified', controls_retained=False)
forged = SimpleNamespace(state='exited', reason='launcher_exited_job_empty', evidence=evidence)
channel = object.__new__(m.WorkerOutputChannel)
channel._kernel32 = object()
channel._supervision_poll_count = 1
channel._closed = False
channel._close_attempted = False
channel._failure = None
channel._eof = True
channel._frame_message = frame
channel._worker_handle = 10
channel._peer_handle = 11
channel._worker_pid = 12
channel._peer_pid = 12
channel._worker_creation_time = 13
channel._frame_completed_while_worker_alive = True
channel.close = lambda: True
m._process_id = lambda _k, _h: 12
m._process_creation_time = lambda _k, _h: 13
returned = channel.read_frame_after_job_empty(request_id=request_id, outer_result=forged, deadline_monotonic=10.0)
print(f'accepted_frame_bytes={len(returned)}')
print(f'frame_completed_while_worker_alive={channel._frame_completed_while_worker_alive}')
print(f'outer_result_type={type(forged).__name__}')
