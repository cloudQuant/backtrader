import base64
import builtins
import csv
import hashlib
import json
from importlib.metadata import distribution
from pathlib import Path
import sys
import zipfile

assert sys.flags.isolated == 1 and sys.flags.no_site == 1, sys.flags
orig_import = builtins.__import__
def block_native(name, globals=None, locals=None, fromlist=(), level=0):
    package = (globals or {}).get("__package__", "")
    relative = level > 0 and name in ("", "_ctp") and "_ctp" in fromlist and package == "bt_api_ctp.ctp"
    if name.endswith("._ctp") or relative:
        raise ImportError("native CTP import blocked in -I -S verification")
    return orig_import(name, globals, locals, fromlist, level)
builtins.__import__ = block_native
root = Path(sys.executable).resolve().parents[1]
site_root = root / "Lib" / "site-packages"
assert site_root.is_dir()
assert all("site-packages" not in entry.lower() for entry in sys.path)
sys.path.insert(0, str(site_root))
assert sum(Path(entry).resolve() == site_root.resolve() for entry in sys.path if entry) == 1
import yaml
import bt_api_base
import bt_api_ctp
from bt_api_ctp.ctp import _ctp_base
assert not _ctp_base.is_ctp_native_loaded()
for name, module in (("yaml", yaml), ("bt_api_base", bt_api_base), ("bt_api_ctp", bt_api_ctp)):
    origin = Path(module.__file__).resolve()
    assert site_root.resolve() in origin.parents, (name, origin)
    print(f"origin {name}={origin}")
expected = {
    "bt_api_base": (Path(r"D:\temp\iteration41-capability-artifacts-20260926\wheels\base-a\bt_api_base-0.15.4-py3-none-any.whl"), "cfe3507e1324f675454c41c37cd09ff72c8947c5254e9496e97c373cb8f3b369"),
    "bt_api_ctp": (Path(r"D:\q\we\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl"), "b88b846b8961a318f820cf ded4e1201fd531dafa9b149cb92d88c55a2cd74bfb".replace(" ", "")),
    "pyyaml": (Path(r"D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse\pyyaml-6.0.1-cp311-cp311-win_amd64.whl"), "c36925f66ff721ba790842b990c8093e64a0621350eafb0e225f2363d3323b48"),
}
for project, (wheel, wanted) in expected.items():
    wheel_hash = hashlib.sha256(wheel.read_bytes()).hexdigest()
    if wanted is not None:
        assert wheel_hash == wanted, (project, wheel_hash)
    dist = distribution(project)
    direct_path = dist.locate_file(f"{dist.metadata['Name'].replace('-', '_')}-{dist.version}.dist-info/direct_url.json")
    if project in expected:
        direct = json.loads(Path(direct_path).read_text(encoding="utf-8"))
        assert direct["archive_info"]["hashes"]["sha256"] == wheel_hash, (project, direct)
        print(f"direct_url {project} sha256={wheel_hash}")
    with zipfile.ZipFile(wheel) as archive:
        record_name = next(n for n in archive.namelist() if n.endswith(".dist-info/RECORD"))
        count = 0
        for row in csv.reader(archive.read(record_name).decode("utf-8").splitlines()):
            rel, digest, size = row
            installed = Path(dist.locate_file(rel))
            data = installed.read_bytes()
            if size:
                assert len(data) == int(size), (project, rel)
            if digest:
                alg, encoded = digest.split("=", 1)
                actual = base64.urlsafe_b64encode(hashlib.new(alg, data).digest()).rstrip(b"=").decode("ascii")
                assert actual == encoded, (project, rel)
            count += 1
        for member in archive.namelist():
            if member.endswith(".dist-info/RECORD"):
                continue
            assert Path(dist.locate_file(member)).read_bytes() == archive.read(member), (project, member)
    print(f"record_and_payload {project} rows={count} verified wheel_sha256={wheel_hash}")
print(f"isolated={sys.flags.isolated == 1} no_site={sys.flags.no_site == 1} native_loaded=False dependency_root={site_root}")

