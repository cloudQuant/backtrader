@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
if errorlevel 1 exit /b %errorlevel%
cl.exe /Brepro /nologo /c D:\q\z.c /FoD:\q\z.obj > D:\q\logs\brepro-cl.log 2>&1
if errorlevel 1 exit /b %errorlevel%
link.exe /Brepro /OUT:D:\q\z.exe D:\q\z.obj > D:\q\logs\brepro-link.log 2>&1
exit /b %errorlevel%
