import builtins
import pathlib
import sys

_orig_import = builtins.__import__
def _deny_ctp_native(name, globals=None, locals=None, fromlist=(), level=0):
    package = (globals or {}).get("__package__", "")
    relative_native = level > 0 and name in ("", "_ctp") and "_ctp" in fromlist and package == "bt_api_ctp.ctp"
    if name.endswith("._ctp") or relative_native:
        raise ImportError("native CTP extension import blocked by offline consumer harness")
    return _orig_import(name, globals, locals, fromlist, level)

builtins.__import__ = _deny_ctp_native
import bt_api_base
import bt_api_ctp
from importlib.metadata import version
prefix = pathlib.Path(sys.prefix).resolve()
for module in (bt_api_base, bt_api_ctp):
    origin = pathlib.Path(module.__file__).resolve()
    if prefix not in origin.parents:
        raise RuntimeError(f"module not from isolated wheel environment: {origin}")
    print(f"origin {module.__name__}={origin}")
print(f"versions base={version(chr(98)+chr(116)+chr(95)+chr(97)+chr(112)+chr(105)+chr(95)+chr(98)+chr(97)+chr(115)+chr(101))} ctp={version(chr(98)+chr(116)+chr(95)+chr(97)+chr(112)+chr(105)+chr(95)+chr(99)+chr(116)+chr(112))}")
import pytest
status = pytest.main(["--noconftest", "-q", "--tb=short", r"D:\q\e\tests\test_ctp_callback_ingress_client.py"])
from bt_api_ctp.ctp import _ctp_base
if _ctp_base.is_ctp_native_loaded():
    raise RuntimeError("native CTP extension was loaded")
print("native_loaded=False")
raise SystemExit(status)


