from __future__ import annotations
import hashlib,json,runpy,shutil
from pathlib import Path
SNAP=Path(r"D:\temp\iteration41_v18_cancel_postcondition_r0")
FIX=Path(r"D:\temp\iteration41_v18_v17_baseline_fixtures_20260926_run2")
OUT=Path(r"D:\temp\iteration41_v18_migration_repro_final_20260926")
R=runpy.run_path(str(SNAP/'tests'/'test_ctp_callback_session_router.py'))
D=runpy.run_path(str(SNAP/'tests'/'test_ctp_dispatch_commands.py'))
Store=R['SqliteExecutionStore']
fixtures=[
 ('v17_ready_unclaimed_cancel.sqlite3',None,False),
 ('v17_claimed_possible_send_cancel.sqlite3','UNMAPPABLE',True),
 ('v17_queued_action_ack_cancel.sqlite3','UNMAPPABLE',True),
 ('v17_session_owned_claimed_cancel.sqlite3','EXACT',True),
 ('v17_session_owned_completed_ack_cancel.sqlite3','EXACT',True),
 ('v17_session_owned_completed_no_callback_cancel.sqlite3','EXACT',True),
]
results=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected_identity,expected_pending in fixtures:
 source=FIX/name; path=OUT/name.replace('.sqlite3','-v18.sqlite3'); shutil.copyfile(source,path); source_hash=sha(source)
 store=Store(path)
 try:
  version=store._connection.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
  cancel=store._connection.execute("SELECT command_id,status,callback_owner_intent_id FROM ctp_dispatch_commands WHERE operation='CANCEL'").fetchone()
  assert cancel is not None
  post=store._connection.execute("SELECT identity_state,target_submit_command_id,owner_intent_id,native_action_ref_int FROM ctp_dispatch_cancel_postconditions WHERE cancel_command_id=?",(cancel['command_id'],)).fetchone()
  account=store._connection.execute("SELECT account_key FROM ctp_dispatch_commands WHERE command_id=?",(cancel['command_id'],)).fetchone()[0]
  pending=store._ctp_has_pending_cancel_postcondition(store._connection.cursor(),account)
  resolution_count=store._connection.execute("SELECT COUNT(*) FROM ctp_dispatch_cancel_postcondition_resolutions").fetchone()[0]
  source_fences=store._connection.execute("SELECT COUNT(*) FROM ctp_dispatch_callback_source_lifecycle_fences WHERE account_key=?",(account,)).fetchone()[0]
  fk=[tuple(r) for r in store._connection.execute('PRAGMA foreign_key_check')]
  assert version=='18' and bool(pending)==expected_pending and resolution_count==0 and not fk
  if expected_identity is None: assert post is None,(name,post)
  else: assert post is not None and post['identity_state']==expected_identity,(name,post)
  post_value=None if post is None else list(post)
  cancel_value=list(cancel)
 finally: store.close()
 store=Store(path)
 try:
  version2=store._connection.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
  account=store._connection.execute("SELECT account_key FROM ctp_dispatch_commands WHERE command_id=?",(cancel['command_id'],)).fetchone()[0]
  pending2=store._ctp_has_pending_cancel_postcondition(store._connection.cursor(),account)
  assert version2=='18' and pending2==expected_pending
 finally: store.close()
 results.append({'fixture':name,'source_sha256':source_hash,'v18_copy':path.name,'cancel_row_after_migration':cancel_value,'postcondition':post_value,'pending_after_open_and_reopen':pending2,'resolution_count':resolution_count,'source_lifecycle_fence_count':source_fences,'foreign_key_check':fk,'schema_version_after_reopen':version2})
receipt={'v18_snapshot_manifest_sha256':sha(SNAP/'V18-SNAPSHOT-MANIFEST.sha256'),'v17_fixture_manifest_sha256':sha(FIX/'manifest.json'),'v17_session_claim_receipt_sha256':sha(FIX/'session_owned_fixture_receipt.json'),'v17_session_ack_receipt_sha256':sha(FIX/'session_owned_completed_ack_fixture_receipt.json'),'v17_session_no_callback_receipt_sha256':sha(FIX/'session_owned_no_callback_fixture_receipt.json'),'scope':'V18 applied only to copied synthetic V17 databases. Each source database is hash-checked; no provider/native/network/config.','results':results}
p=OUT/'v18_migration_receipt.json'; p.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2,sort_keys=True)); print('receipt_sha256='+sha(p))
