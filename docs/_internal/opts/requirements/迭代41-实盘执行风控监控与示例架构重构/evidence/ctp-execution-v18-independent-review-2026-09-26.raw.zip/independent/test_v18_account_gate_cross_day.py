from __future__ import annotations

from pathlib import Path

import pytest

import test_ctp_dispatch_commands as h
from bt_api_execution import ExecutionScope, InvalidStateTransition, SqliteExecutionStore


def test_pending_cancel_blocks_submit_claim_across_scope_and_day(tmp_path: Path):
    store = SqliteExecutionStore(tmp_path / 'cross-day.sqlite3')
    scope1 = h._scope()
    lease = h._lease(store, scope1, 'cross-day-gate-owner')
    scope2 = ExecutionScope('CTP', 'simulation', scope1.account_ref, 'strategy.next-day', '20260926')
    try:
        reservation1 = h._reserve_seeded(
            store, scope1, lease, 'cross-day-target', session_generation_id='test-session-generation'
        )
        submit1 = h._stage_submit(
            store, scope1, lease, reservation1, command_id='cross-day-target-submit',
            session_generation_id='test-session-generation',
        )
        h._dispatch_fake(store, scope1, lease, submit1)
        projection = h._issue_target_projection(
            store, scope1, reservation1, verifier=h._FakeOrderTargetProjectionVerifier()
        )
        cancel = h._stage_cancel_with_projection(
            store, scope1, lease, reservation1, projection,
            command_id='cross-day-pending-cancel',
        )
        h._dispatch_fake(store, scope1, lease, cancel)
        obligation = store._connection.execute(
            'SELECT identity_state, account_key, trading_day FROM ctp_dispatch_cancel_postconditions '
            'WHERE cancel_command_id = ?', (cancel.command_id,)
        ).fetchone()
        assert tuple(obligation) == ('UNMAPPABLE', scope1.account_key, scope1.trading_day)
        assert store._ctp_has_pending_cancel_postcondition(
            store._connection.cursor(), scope1.account_key
        )

        reservation2 = h._reserve_seeded(
            store, scope2, lease, 'cross-day-next-submit', session_generation_id='day-two-session'
        )
        submit2 = h._stage_submit(
            store, scope2, lease, reservation2, command_id='cross-day-next-submit',
            session_generation_id='day-two-session', approval_use_id='approval-next-day',
        )
        with pytest.raises(InvalidStateTransition, match='cancel awaiting verified terminal-order'):
            store.claim_ctp_dispatch_command(
                scope2, submit2.command_id, writer_lease=lease,
                authority_verifier=h._authority_verifier(),
            )
        reread = store.read_ctp_dispatch_command(scope2, submit2.command_id)
        assert reread is not None and reread.status == 'READY'
        inflight = store._connection.execute(
            'SELECT native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?',
            (submit2.command_id,),
        ).fetchone()[0]
        assert inflight == 0
    finally:
        store.close()
