from __future__ import annotations
import hashlib,json,sqlite3,sys
from pathlib import Path
root=Path(r"D:\temp\iteration41_v18_v17_baseline_fixtures_20260926_run2")
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for item in manifest['fixtures']+[manifest['preterminal_claim_repro']]:
    p=root/item['file']
    assert sha(p)==item['sha256'], (p,sha(p),item['sha256'])
    con=sqlite3.connect(f"file:{p.as_posix()}?mode=ro",uri=True)
    con.row_factory=sqlite3.Row
    version=con.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
    fk=[tuple(r) for r in con.execute('PRAGMA foreign_key_check')]
    assert version=='17'
    assert not fk
    if item['file']=='v17_ack_open_target_second_submit_claim.sqlite3':
        command=con.execute("SELECT status,native_call_inflight FROM ctp_dispatch_commands WHERE command_id=?",(item['second_submit_command'],)).fetchone()
        assert tuple(command)==('CLAIMED',0)
    rows.append({'file':p.name,'sha256':sha(p),'schema_version':version,'foreign_key_check':fk})
    con.close()
receipt={
  'base_manifest_sha256':sha(root/'manifest.json'),
  'generator_script_sha256':sha(root/'create_v17_fixtures.py'),
  'python':sys.version,
  'validation':'Read-only SQLite validation of all synthetic fixtures; schema 17 and foreign_key_check empty; database hashes match base manifest.',
  'exact_generation_command':"$env:PYTHONPATH='D:\\temp\\iteration41_v17_execution_review_20260926_r4_cancel_fk_regression\\src'; $env:PYTHONDONTWRITEBYTECODE='1'; python D:\\temp\\iteration41_v18_v17_baseline_fixtures_20260926_run2\\create_v17_fixtures.py",
  'fixtures':rows,
  'preterminal_repro':manifest['preterminal_claim_repro']
}
p=root/'validation_receipt.json'
p.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2,sort_keys=True))
print('validation_receipt_sha256='+sha(p))
