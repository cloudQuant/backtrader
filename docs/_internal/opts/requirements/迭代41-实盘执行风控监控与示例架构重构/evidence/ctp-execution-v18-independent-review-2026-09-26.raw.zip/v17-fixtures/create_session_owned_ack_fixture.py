from __future__ import annotations
import hashlib,json,runpy
from pathlib import Path
SNAP=Path(r"D:\temp\iteration41_v17_execution_review_20260926_r4_cancel_fk_regression")
OUT=Path(r"D:\temp\iteration41_v18_v17_baseline_fixtures_20260926_run2")
R=runpy.run_path(str(SNAP/'tests'/'test_ctp_callback_session_router.py'))
D=runpy.run_path(str(SNAP/'tests'/'test_ctp_dispatch_commands.py'))
Store=R['SqliteExecutionStore']; scope=R['_scope'](); path=OUT/'v17_session_owned_completed_ack_cancel.sqlite3'
store=Store(path); lease=R['_lease'](store,scope); owner=R['_active_owner'](store,scope,lease)
session=store._active_ctp_callback_sessions[owner.owner_intent_id]
target=R['_reserve'](store,scope,lease,session.session_generation_id,'session-owned-ack-migration-target')
submit_payload={'BrokerID':'broker','InvestorID':'user','UserID':'user','InstrumentID':'rb2710','ExchangeID':'SHFE','OrderRef':target.order_ref,'Direction':'0','CombOffsetFlag':'0','CombHedgeFlag':'1','LimitPrice':100.0,'VolumeTotalOriginal':1,'OrderPriceType':'2','TimeCondition':'3'}
submit=R['_queue_and_complete'](store,scope,lease,owner,target,'session-owned-ack-migration-submit',submit_payload,71)
projection=store.issue_ctp_order_target_projection(scope,target.managed_intent_id,{'session_generation_id':session.session_generation_id},verifier=R['_OrderTargetVerifier']())
cancel_target=R['CtpCancelTarget'](order_ref=target.order_ref,exchange_id='SHFE',order_sys_id='sys-'+target.order_ref,front_id=session.dispatch_front_id,session_id=session.dispatch_session_id)
command_id='session-owned-ack-migration-cancel'; receipt_id=hashlib.sha256(command_id.encode('ascii')).hexdigest()[:32]
session_binding={'binding_type':'ctp_callback_session_binding.v1','owner_intent_id':session.owner_intent_id,'account_key':session.account_key,'scope_key':session.scope_key,'trading_day':session.trading_day,'session_generation_id':session.session_generation_id,'dispatch_front_id':session.dispatch_front_id,'dispatch_session_id':session.dispatch_session_id,'source_tags':{'source_instance_id':session.source_instance_id,'native_client_epoch':session.native_client_epoch,'native_api_source_id':session.native_api_source_id,'native_spi_source_id':session.native_spi_source_id,'native_api_generation':session.native_api_generation,'connection_generation':session.source_connection_generation},'source_high_watermark':session.source_high_watermark}
cancel=store.stage_ctp_dispatch_command(scope,command_id,'CANCEL',{'InstrumentID':'rb2710','OrderRef':cancel_target.order_ref,'ExchangeID':cancel_target.exchange_id,'OrderSysID':cancel_target.order_sys_id,'FrontID':cancel_target.front_id,'SessionID':cancel_target.session_id,'ActionFlag':'0','LimitPrice':0.0,'VolumeChange':0},approval_use_id='approval-'+command_id,approval_digest=hashlib.sha256(('approval-'+command_id).encode('ascii')).hexdigest(),session_binding=session_binding,writer_lease=lease,managed_action_id='cancel-action-'+command_id,cancel_target=cancel_target,session_generation_id=session.session_generation_id,dispatch_front_id=session.dispatch_front_id,dispatch_session_id=session.dispatch_session_id,native_request_id=501,local_queue_receipt_id=receipt_id,cancel_target_projection=projection)
store.record_ctp_dispatch_queue_receipt(scope,command_id,{'kind':'command_receipt','command':'cancel','receipt_id':receipt_id,'queued':True},writer_lease=lease)
claim=store.claim_ctp_dispatch_command_for_session(scope,command_id,owner_handle=owner,writer_lease=lease,authority_verifier=R['_Authority'](),required_local_queue_receipt_id=receipt_id)
assert claim is not None
command=claim.command
receipt=D['CtpDispatchReceipt'](receipt_type='ctp_dispatch_receipt.v2',command_id=command.command_id,account_key=command.account_key,scope_key=command.scope_key,trading_day=command.trading_day,operation=command.operation,request_payload_sha256=command.request_payload_sha256,reservation_managed_intent_id=command.reservation_managed_intent_id,order_ref=command.order_ref,cancel_target_order_ref=command.cancel_target_order_ref,cancel_target_exchange_id=command.cancel_target_exchange_id,cancel_target_order_sys_id=command.cancel_target_order_sys_id,cancel_target_front_id=command.cancel_target_front_id,cancel_target_session_id=command.cancel_target_session_id,approval_use_id=command.approval_use_id,approval_digest=command.approval_digest,session_binding_sha256=command.session_binding_sha256,outcome='QUEUED',native_receipt_payload={'request_id':501,'queue_code':0},correlation_key=command.correlation_key,local_queue_receipt_id=receipt_id)
completed=store.complete_ctp_dispatch_command_for_session(scope,receipt,owner_handle=owner,writer_lease=lease)
assert completed.status=='COMPLETED'
callback=D['_callback'](completed,event_id='session-owned-cancel-action-ack')
applied=D['_apply_callback'](store,scope,completed,callback,lease,D['_FakeCtpDispatchCallbackVerifier']('ACKNOWLEDGED'))
assert applied.projection_state=='ACKNOWLEDGED'
row=store._connection.execute('SELECT status,callback_owner_intent_id,claimed_at_ns,native_call_inflight FROM ctp_dispatch_commands WHERE command_id=?',(command_id,)).fetchone()
proj=store.read_ctp_dispatch_projection(scope,command_id)
assert proj.cancel_action.action_state=='ACKNOWLEDGED' and not proj.cancel_action.terminal
fk=[tuple(r) for r in store._connection.execute('PRAGMA foreign_key_check')]
version=store._connection.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
assert version=='17' and not fk and row['callback_owner_intent_id']==owner.owner_intent_id
store.close()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
receipt_obj={'source_snapshot_manifest_sha256':sha(SNAP/'MANIFEST.json'),'store_sha256':sha(SNAP/'src'/'bt_api_execution'/'store.py'),'router_test_sha256':sha(SNAP/'tests'/'test_ctp_callback_session_router.py'),'dispatch_test_sha256':sha(SNAP/'tests'/'test_ctp_dispatch_commands.py'),'file':path.name,'sha256':sha(path),'schema_version':version,'command':command_id,'submit_command':submit.command_id,'owner_intent_id':owner.owner_intent_id,'callback_owner_intent_id':row['callback_owner_intent_id'],'cancel_row':list(row),'action_state':proj.cancel_action.action_state,'action_terminal':proj.cancel_action.terminal,'target_state':proj.cancel_action.target_order.order_state.provider_state,'target_terminal':proj.cancel_action.target_order.order_state.terminal,'foreign_key_check':fk,'setup':'Frozen V17 router/session APIs, test-only authority/target/callback verifiers and fake queue receipt; no native/provider/network/config.'}
rec=OUT/'session_owned_completed_ack_fixture_receipt.json'; rec.write_text(json.dumps(receipt_obj,indent=2,sort_keys=True)+'\n',encoding='utf8')
print(json.dumps(receipt_obj,indent=2,sort_keys=True)); print('receipt_sha256='+sha(rec))
