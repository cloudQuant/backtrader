from __future__ import annotations
import hashlib, json, os, runpy, shutil, sqlite3, sys, time
from pathlib import Path

SNAP = Path(r"D:\temp\iteration41_v17_execution_review_20260926_r4_cancel_fk_regression")
OUT = Path(r"D:\temp\iteration41_v18_v17_baseline_fixtures_20260926_run2")
TESTMOD = runpy.run_path(str(SNAP / "tests" / "test_ctp_dispatch_commands.py"))

scope_fn = TESTMOD["_scope"]
lease_fn = TESTMOD["_lease"]
reserve_fn = TESTMOD["_reserve_seeded"]
stage_submit_fn = TESTMOD["_stage_submit"]
stage_cancel_fn = TESTMOD["_stage_cancel"]
dispatch_fn = TESTMOD["_dispatch_fake"]
apply_fn = TESTMOD["_apply_callback"]
callback_fn = TESTMOD["_callback"]
CallbackVerifier = TESTMOD["_FakeCtpDispatchCallbackVerifier"]
authority_fn = TESTMOD["_authority_verifier"]
Store = TESTMOD["SqliteExecutionStore"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_base(store, scope, lease, suffix):
    reservation = reserve_fn(store, scope, lease, "baseline-intent-" + suffix)
    submit = stage_submit_fn(store, scope, lease, reservation, "baseline-submit-" + suffix)
    submitted = dispatch_fn(store, scope, lease, submit)
    assert submitted.status == "COMPLETED"
    order_cb = callback_fn(submit, event_id="baseline-order-ack-" + suffix)
    applied = apply_fn(store, scope, submit, order_cb, lease, CallbackVerifier("ACKNOWLEDGED"))
    assert applied.projection_state == "ACKNOWLEDGED"
    cancel = stage_cancel_fn(store, scope, lease, reservation, "baseline-cancel-" + suffix)
    return reservation, submit, cancel


def create_migration_fixture(name, status_kind):
    path = OUT / f"v17_{name}.sqlite3"
    scope = scope_fn()
    store = Store(path)
    lease = lease_fn(store, scope, "v17-fixture-owner-" + name)
    try:
        reservation, submit, cancel = prepare_base(store, scope, lease, name)
        if status_kind == "ready_unclaimed":
            pass
        elif status_kind == "claimed":
            claimed = store.claim_ctp_dispatch_command(
                scope, cancel.command_id, writer_lease=lease,
                authority_verifier=authority_fn(),
            )
            assert claimed is not None and claimed.status == "CLAIMED"
        elif status_kind == "queued_ack":
            done = dispatch_fn(store, scope, lease, cancel)
            assert done.status == "COMPLETED"
            cancel_cb = callback_fn(cancel, event_id="baseline-cancel-ack-" + name)
            ack = apply_fn(store, scope, cancel, cancel_cb, lease, CallbackVerifier("ACKNOWLEDGED"))
            assert ack.projection_state == "ACKNOWLEDGED"
        else:
            raise AssertionError(status_kind)
        command_row = store._connection.execute(
            "SELECT status, local_queue_receipt_queued, native_call_inflight, "
            "native_action_ref, native_action_ref_int FROM ctp_dispatch_commands "
            "WHERE command_id = ?", (cancel.command_id,),
        ).fetchone()
        assert command_row is not None
        foreign_keys = [tuple(row) for row in store._connection.execute("PRAGMA foreign_key_check")]
        assert foreign_keys == []
        meta = store._connection.execute(
            "SELECT value FROM execution_meta WHERE key='schema_version'"
        ).fetchone()[0]
        assert str(meta) == "17", meta
        store.close()
        store = None
    finally:
        if store is not None:
            store.close()
    return {
        "file": path.name,
        "sha256": sha(path),
        "status_kind": status_kind,
        "cancel_command": cancel.command_id,
        "command_row": list(command_row),
        "schema_version": str(meta),
        "foreign_key_check": foreign_keys,
        "submit_command": submit.command_id,
        "managed_intent_id": reservation.managed_intent_id,
        "scope_key": scope.key,
        "account_key": scope.account_key,
        "trading_day": scope.trading_day,
    }


def reproduce_v17_preterminal_submit_claim():
    path = OUT / "v17_ack_open_target_second_submit_claim.sqlite3"
    scope = scope_fn()
    store = Store(path)
    lease = lease_fn(store, scope, "v17-gap-owner")
    try:
        reservation, submit, cancel = prepare_base(store, scope, lease, "gap")
        cancel_done = dispatch_fn(store, scope, lease, cancel)
        assert cancel_done.status == "COMPLETED"
        cancel_cb = callback_fn(cancel, event_id="gap-cancel-action-ack")
        ack = apply_fn(store, scope, cancel, cancel_cb, lease, CallbackVerifier("ACKNOWLEDGED"))
        assert ack.projection_state == "ACKNOWLEDGED"
        before = store.read_ctp_dispatch_projection(scope, submit.command_id)
        assert before is not None and before.submit_action.order_state.terminal is False
        new_reservation = reserve_fn(store, scope, lease, "baseline-intent-gap-second")
        second = stage_submit_fn(store, scope, lease, new_reservation, "baseline-submit-gap-second", approval_use_id="approval-use-gap-second")
        claimed = store.claim_ctp_dispatch_command(
            scope, second.command_id, writer_lease=lease,
            authority_verifier=authority_fn(),
        )
        assert claimed is not None and claimed.status == "CLAIMED"
        second_row = store._connection.execute(
            "SELECT status, native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?",
            (second.command_id,),
        ).fetchone()
        cancel_projection = store.read_ctp_dispatch_projection(scope, cancel.command_id)
        result = {
            "case": "V17_CANCEL_ACK_TARGET_ORDER_NONTERMINAL_THEN_SECOND_SUBMIT_CLAIM",
            "v17_schema": store._connection.execute(
                "SELECT value FROM execution_meta WHERE key='schema_version'"
            ).fetchone()[0],
            "cancel_status": store.read_ctp_dispatch_command(scope, cancel.command_id).status,
            "cancel_action_state": cancel_projection.cancel_action.action_state,
            "cancel_action_terminal": cancel_projection.cancel_action.terminal,
            "target_order_state": cancel_projection.cancel_action.target_order.order_state.provider_state,
            "target_order_terminal": cancel_projection.cancel_action.target_order.order_state.terminal,
            "second_submit_command": second.command_id,
            "second_submit_claim_status": claimed.status,
            "second_submit_row": list(second_row),
            "scope_key": scope.key,
            "account_key": scope.account_key,
            "trading_day": scope.trading_day,
        }
        assert int(result["v17_schema"]) == 17
        assert result["cancel_action_state"] == "ACKNOWLEDGED"
        assert result["cancel_action_terminal"] is False
        assert result["target_order_terminal"] is False
        assert result["second_submit_claim_status"] == "CLAIMED"
        store.close()
        store = None
    finally:
        if store is not None:
            store.close()
    return {**result, "file": path.name, "sha256": sha(path)}

fixtures = [
    create_migration_fixture("ready_unclaimed_cancel", "ready_unclaimed"),
    create_migration_fixture("claimed_possible_send_cancel", "claimed"),
    create_migration_fixture("queued_action_ack_cancel", "queued_ack"),
]
baseline = reproduce_v17_preterminal_submit_claim()
source_files = {
    "store.py": sha(SNAP / "src" / "bt_api_execution" / "store.py"),
    "test_ctp_dispatch_commands.py": sha(SNAP / "tests" / "test_ctp_dispatch_commands.py"),
    "manifest.json": sha(SNAP / "MANIFEST.json"),
}
manifest = {
    "title": "Synthetic V17 cancel migration and preterminal-submit baseline fixtures",
    "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "source_snapshot": str(SNAP),
    "source_snapshot_manifest_sha256": sha(SNAP / "MANIFEST.json"),
    "source_hashes": source_files,
    "fixture_creation": "Frozen V17 source APIs only; fake verifier/receipt/callback; no native/provider/network/config access.",
    "fixtures": fixtures,
    "preterminal_claim_repro": baseline,
}
manifest_path = OUT / "manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(manifest, indent=2, sort_keys=True))
print("manifest_sha256=" + sha(manifest_path))


