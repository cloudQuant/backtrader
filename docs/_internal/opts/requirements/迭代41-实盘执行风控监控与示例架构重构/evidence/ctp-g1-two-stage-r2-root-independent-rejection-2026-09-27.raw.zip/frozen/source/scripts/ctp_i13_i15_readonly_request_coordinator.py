"""Fixed, bootstrap-dispatched coordinator for one inert read-only request.

This file is a data-only I13 source entry.  It is never imported by the
runtime finder and must only be compiled from the retained source lease by
the fixed bootstrap.  The production runtime object is built by that
bootstrap from code-owned APIs; no callback or path is accepted in the wire
binding.
"""

from __future__ import annotations

import json
import hashlib
import math
import ntpath
import os
import re
import sys
import time
from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping, Protocol


COORDINATOR_BINDING_SCHEMA = "ctp_i13_i15_readonly_request_coordinator_binding.v1"
COORDINATOR_OUTPUT_SCHEMA = "ctp_i13_i15_readonly_request_coordinator_output.v1"
COORDINATOR_FRAME_SCHEMA = "ctp_i13_i15_readonly_request_coordinator_frame.v1"
_REQUEST_ID_RE = re.compile(r"[0-9a-f]{32}\Z")
_SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
_SID_RE = re.compile(r"S-1-(?:[0-9]+-){1,14}[0-9]+\Z")
_SERVICE_SID_RE = re.compile(r"S-1-5-80-(?:[0-9]+-){4}[0-9]+\Z")
_REASONS = frozenset(
    {
        "completed",
        "deadline_expired",
        "deployment_binding_mismatch",
        "owner_token_invalid",
        "owner_token_session_failed",
        "worker_output_invalid",
        "worker_launch_failed",
        "worker_cleanup_unverified",
        "worker_source_invalid",
        "worker_failed",
        "supervisor_channel_failed",
    }
)
_DEPLOYMENT_FIELDS = frozenset(
    {
        "descriptor_sha256",
        "source_manifest_sha256",
        "runtime_manifest_sha256",
        "dependency_manifest_sha256",
        "python_sha256",
        "i13_pin_sha256",
        "i15_pin_sha256",
        "bootstrap_sha256",
        "worker_sha256",
        "coordinator_sha256",
        "receipt_writer_sha256",
        "token_bootstrap_sha256",
    }
)
_IDENTITY_FIELDS = frozenset({"service_sid", "owner_sid"})
_CHANNEL_FIELDS = frozenset({"nonce", "server_pid"})
_BINDING_FIELDS = frozenset(
    {
        "schema",
        "request_id",
        "deadline_monotonic_ns",
        "deployment",
        "identities",
        "supervisor_output_channel",
        "token_control_channel",
    }
)
_WORKER_FACT_FIELDS = frozenset(
    {
        "process_created",
        "job_assignment_observed",
        "launcher_resumed",
        "launcher_exit_observed",
        "launcher_exit_code",
        "job_termination_requested",
        "job_termination_call_succeeded",
        "job_empty_observed",
        "containment",
        "controls_retained",
    }
)
_OUTPUT_FIELDS = frozenset(
    {"schema", "request_id", "state", "reason", "worker_observation", "worker_facts"}
)
_WORKER_SUMMARY_SCHEMA = "ctp_i13_i15_readonly_worker_summary.v1"
_WORKER_IDENTITY_FIELDS = frozenset(
    {"account_scope", "provider", "environment", "trading_day", "connection_generation"}
)
_WORKER_QUERY_NAMES = (
    "account",
    "commission_rates",
    "instruments",
    "margin_rates",
    "orders",
    "positions",
    "trades",
)
_WORKER_SUMMARY_FIELDS = frozenset({"schema", "identity", "query_digests", "snapshot_sha256"})
_WORKER_OUTPUT_SCHEMA = "ctp_i13_i15_readonly_preflight_worker_output.v1"
_WORKER_PUBLIC_FIELDS = frozenset(
    {
        "credentials_resolved",
        "provider_connected",
        "account_identity_verified",
        "preflight_authorized",
        "execution_authorized",
        "external_writes_authorized",
        "order_submission_authorized",
        "cancellation_authorized",
        "settlement_authorized",
        "arming_authorized",
        "external_write_requests",
        "market_data_trading_writes",
        "read_only_observation",
        "market_data_observation",
    }
)
_WORKER_ACCOUNT_FIELDS = frozenset(
    {
        "account_acceptance_established", "account_scope", "approval_required",
        "arming_authorized", "cancellation_authorized", "connection_generation",
        "effective_config_digest", "environment", "exchange_id", "execution_authorized",
        "external_write_requests", "external_writes_authorized", "hedge_flag",
        "instrument_id", "native_certificate_provenance", "native_certificate_sha256",
        "order_submission_authorized", "provider", "provider_preflight_started",
        "query_snapshot", "read_only_route_admitted", "registration_digest",
        "runtime_id", "sdk_profile", "session_connected", "settlement_authorized",
        "strategy_id", "trading_day",
    }
)
_WORKER_MARKET_FIELDS = frozenset(
    {
        "client_stop_returned", "connection_generation", "account_probe_lock_scope",
        "account_scope_bound", "exchange_id", "first_tick_observed", "instrument_id",
        "market_login_ready", "market_path_ready", "md_front_sha256",
        "native_join_pending", "order_submission_authorized", "probe_session_closed",
        "subscription_acknowledged", "settlement_writes", "tick_binding",
        "tick_observation_count", "trading_writes",
    }
)
_WORKER_TICK_FIELDS = frozenset(
    {"account_bound", "connection_generation", "exchange_id", "instrument_id", "md_front_sha256"}
)
_OUTPUT_LIMIT = 64 * 1024


class CoordinatorError(ValueError):
    """A fixed, non-sensitive coordinator contract rejection."""


@dataclass(frozen=True)
class CoordinatorBinding:
    request_id: str
    deadline_monotonic_ns: int
    deployment: Mapping[str, str]
    service_sid: str
    owner_sid: str
    supervisor_output_channel: Mapping[str, object]
    token_control_channel: Mapping[str, object]


class CoordinatorApi(Protocol):
    """Internal methods supplied only by the fixed bootstrap runtime."""

    def monotonic_ns(self) -> int: ...

    def verify_deployment(self, deployment: Mapping[str, str]) -> None: ...

    def receive_and_set_owner_token_session_zero(self, binding: CoordinatorBinding) -> None: ...

    def run_fixed_worker(self, binding: CoordinatorBinding) -> tuple[object, object]:
        """Return a redacted worker summary and OS-supervised worker facts."""
        ...

    def write_supervisor_output(
        self, binding: CoordinatorBinding, output: Mapping[str, object]
    ) -> None: ...


def _reject_duplicate_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise CoordinatorError("duplicate_json_key")
        result[key] = value
    return result


def _freeze(value):
    if type(value) is dict:
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if type(value) is list:
        return tuple(_freeze(item) for item in value)
    return value


def _thaw(value):
    if isinstance(value, Mapping):
        return {key: _thaw(item) for key, item in value.items()}
    if type(value) is tuple:
        return [_thaw(item) for item in value]
    return value


def _canonical_json(value, *, maximum: int = _OUTPUT_LIMIT) -> bytes:
    try:
        raw = json.dumps(
            value,
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("ascii")
    except (TypeError, ValueError, UnicodeError):
        raise CoordinatorError("json_value_invalid") from None
    if not raw or len(raw) > maximum:
        raise CoordinatorError("json_size_invalid")
    return raw


def _parse_canonical_object(raw: bytes, *, maximum: int = _OUTPUT_LIMIT) -> dict:
    if type(raw) is not bytes or not raw or len(raw) > maximum:
        raise CoordinatorError("json_size_invalid")
    try:
        value = json.loads(raw.decode("ascii"), object_pairs_hook=_reject_duplicate_pairs)
    except CoordinatorError:
        raise
    except (UnicodeError, ValueError, TypeError):
        raise CoordinatorError("json_invalid") from None
    if type(value) is not dict or _canonical_json(value, maximum=maximum) != raw:
        raise CoordinatorError("json_not_canonical")
    return value


def _exact_positive_int(value: object, reason: str) -> int:
    if type(value) is not int or value <= 0:
        raise CoordinatorError(reason)
    return value


def _exact_sha(value: object, reason: str) -> str:
    if type(value) is not str or _SHA256_RE.fullmatch(value) is None or value == "0" * 64:
        raise CoordinatorError(reason)
    return value


def _channel(value: object, reason: str) -> Mapping[str, object]:
    if type(value) is not dict or set(value) != _CHANNEL_FIELDS:
        raise CoordinatorError(reason)
    nonce = value["nonce"]
    if type(nonce) is not str or _REQUEST_ID_RE.fullmatch(nonce) is None:
        raise CoordinatorError(reason)
    pid = _exact_positive_int(value["server_pid"], reason)
    return MappingProxyType({"nonce": nonce, "server_pid": pid})


def parse_coordinator_binding(value: object) -> CoordinatorBinding:
    """Validate a bootstrap-created binding; caller data alone grants no trust."""

    if type(value) is not dict or set(value) != _BINDING_FIELDS:
        raise CoordinatorError("coordinator_binding_fields_invalid")
    if value["schema"] != COORDINATOR_BINDING_SCHEMA:
        raise CoordinatorError("coordinator_binding_schema_invalid")
    request_id = value["request_id"]
    if type(request_id) is not str or _REQUEST_ID_RE.fullmatch(request_id) is None:
        raise CoordinatorError("request_id_invalid")
    deadline = _exact_positive_int(value["deadline_monotonic_ns"], "deadline_invalid")
    deployment = value["deployment"]
    if type(deployment) is not dict or set(deployment) != _DEPLOYMENT_FIELDS:
        raise CoordinatorError("deployment_binding_invalid")
    validated_deployment = {
        name: _exact_sha(deployment[name], "deployment_binding_invalid")
        for name in sorted(_DEPLOYMENT_FIELDS)
    }
    identities = value["identities"]
    if type(identities) is not dict or set(identities) != _IDENTITY_FIELDS:
        raise CoordinatorError("request_identity_invalid")
    service_sid = identities["service_sid"]
    owner_sid = identities["owner_sid"]
    if (
        type(service_sid) is not str
        or _SERVICE_SID_RE.fullmatch(service_sid) is None
        or type(owner_sid) is not str
        or _SID_RE.fullmatch(owner_sid) is None
        or service_sid == owner_sid
    ):
        raise CoordinatorError("request_identity_invalid")
    return CoordinatorBinding(
        request_id=request_id,
        deadline_monotonic_ns=deadline,
        deployment=MappingProxyType(validated_deployment),
        service_sid=service_sid,
        owner_sid=owner_sid,
        supervisor_output_channel=_channel(
            value["supervisor_output_channel"], "supervisor_channel_invalid"
        ),
        token_control_channel=_channel(value["token_control_channel"], "token_channel_invalid"),
    )


def _worker_facts(value: object) -> Mapping[str, object]:
    if type(value) is not dict or set(value) != _WORKER_FACT_FIELDS:
        raise CoordinatorError("worker_facts_invalid")
    for name in (
        "process_created",
        "job_assignment_observed",
        "launcher_resumed",
        "launcher_exit_observed",
        "job_termination_requested",
        "job_empty_observed",
        "controls_retained",
    ):
        if type(value[name]) is not bool:
            raise CoordinatorError("worker_facts_invalid")
    for name in ("job_termination_call_succeeded",):
        if value[name] is not None and type(value[name]) is not bool:
            raise CoordinatorError("worker_facts_invalid")
    code = value["launcher_exit_code"]
    if code is not None and type(code) is not int:
        raise CoordinatorError("worker_facts_invalid")
    if value["launcher_exit_observed"] != (code is not None):
        raise CoordinatorError("worker_facts_invalid")
    if type(value["containment"]) is not str or value["containment"] not in {
        "verified",
        "unknown",
        "not_started",
    }:
        raise CoordinatorError("worker_facts_invalid")
    if value["job_assignment_observed"] and not value["process_created"]:
        raise CoordinatorError("worker_facts_invalid")
    if value["launcher_resumed"] and not value["job_assignment_observed"]:
        raise CoordinatorError("worker_facts_invalid")
    if not value["process_created"] and any(
        value[name]
        for name in (
            "job_assignment_observed",
            "launcher_resumed",
            "launcher_exit_observed",
            "job_termination_requested",
            "job_empty_observed",
        )
    ):
        raise CoordinatorError("worker_facts_invalid")
    if value["job_empty_observed"] and not value["launcher_exit_observed"]:
        raise CoordinatorError("worker_facts_invalid")
    return MappingProxyType(dict(value))


def _worker_summary(value: object) -> Mapping[str, object]:
    if type(value) is not dict or set(value) != _WORKER_SUMMARY_FIELDS:
        raise CoordinatorError("worker_observation_invalid")
    if value["schema"] != _WORKER_SUMMARY_SCHEMA:
        raise CoordinatorError("worker_observation_invalid")
    identity = value["identity"]
    if type(identity) is not dict or set(identity) != _WORKER_IDENTITY_FIELDS:
        raise CoordinatorError("worker_observation_invalid")
    if (
        identity["account_scope"] != "redacted"
        or identity["provider"] != "ctp"
        or identity["environment"] != "simnow"
        or type(identity["trading_day"]) is not str
        or re.fullmatch(r"[0-9]{8}", identity["trading_day"]) is None
        or type(identity["connection_generation"]) is not int
        or identity["connection_generation"] <= 0
    ):
        raise CoordinatorError("worker_observation_invalid")
    _exact_sha(value["snapshot_sha256"], "worker_observation_invalid")
    digests = value["query_digests"]
    if type(digests) is not list or len(digests) != len(_WORKER_QUERY_NAMES):
        raise CoordinatorError("worker_observation_invalid")
    names = []
    for pair in digests:
        if (
            type(pair) is not list
            or len(pair) != 2
            or type(pair[0]) is not str
            or type(pair[1]) is not str
            or not _SHA256_RE.fullmatch(pair[1])
            or pair[1] == "0" * 64
        ):
            raise CoordinatorError("worker_observation_invalid")
        names.append(pair[0])
    if tuple(names) != _WORKER_QUERY_NAMES:
        raise CoordinatorError("worker_observation_invalid")
    _canonical_json(value)
    return _freeze(value)


def parse_coordinator_output(value: object, *, expected_request_id: str) -> Mapping[str, object]:
    if type(value) is not dict or set(value) != _OUTPUT_FIELDS:
        raise CoordinatorError("coordinator_output_fields_invalid")
    if value["schema"] != COORDINATOR_OUTPUT_SCHEMA:
        raise CoordinatorError("coordinator_output_schema_invalid")
    if value["request_id"] != expected_request_id:
        raise CoordinatorError("coordinator_output_request_mismatch")
    state = value["state"]
    reason = value["reason"]
    if (
        type(state) is not str
        or state not in {"observed", "unknown"}
        or type(reason) is not str
        or reason not in _REASONS
    ):
        raise CoordinatorError("coordinator_output_state_invalid")
    facts = _worker_facts(value["worker_facts"])
    observation = value["worker_observation"]
    if observation is not None:
        observation = _worker_summary(observation)
    if state == "observed":
        if (
            reason != "completed"
            or observation is None
            or facts["process_created"] is not True
            or facts["job_assignment_observed"] is not True
            or facts["launcher_resumed"] is not True
            or facts["launcher_exit_observed"] is not True
            or facts["launcher_exit_code"] != 0
            or facts["job_termination_requested"] is not False
            or facts["job_empty_observed"] is not True
            or facts["containment"] != "verified"
            or facts["controls_retained"] is not False
        ):
            raise CoordinatorError("coordinator_output_success_unproven")
    elif reason == "completed":
        raise CoordinatorError("coordinator_output_state_invalid")
    return _freeze(
        {
            "schema": COORDINATOR_OUTPUT_SCHEMA,
            "request_id": expected_request_id,
            "state": state,
            "reason": reason,
            "worker_observation": _thaw(observation) if observation is not None else None,
            "worker_facts": dict(facts),
        }
    )


def encode_coordinator_output(value: Mapping[str, object], *, request_id: str) -> bytes:
    parsed = parse_coordinator_output(_thaw(value), expected_request_id=request_id)
    return _canonical_json(_thaw(parsed))


def encode_coordinator_frame(
    value: Mapping[str, object], *, request_id: str, nonce: str
) -> bytes:
    """Encode the service-only transport envelope for one coordinator result."""

    if type(nonce) is not str or _REQUEST_ID_RE.fullmatch(nonce) is None:
        raise CoordinatorError("supervisor_channel_invalid")
    output = parse_coordinator_output(_thaw(value), expected_request_id=request_id)
    return _canonical_json(
        {
            "schema": COORDINATOR_FRAME_SCHEMA,
            "request_id": request_id,
            "nonce": nonce,
            "coordinator_output": _thaw(output),
        }
    )


def parse_coordinator_frame(
    raw: bytes, *, expected_request_id: str, expected_nonce: str
) -> Mapping[str, object]:
    """Validate one channel-bound coordinator frame and its nested payload."""

    value = _parse_canonical_object(raw)
    if set(value) != {"schema", "request_id", "nonce", "coordinator_output"}:
        raise CoordinatorError("coordinator_frame_fields_invalid")
    if (
        value["schema"] != COORDINATOR_FRAME_SCHEMA
        or type(expected_request_id) is not str
        or _REQUEST_ID_RE.fullmatch(expected_request_id) is None
        or value["request_id"] != expected_request_id
        or type(expected_nonce) is not str
        or _REQUEST_ID_RE.fullmatch(expected_nonce) is None
        or value["nonce"] != expected_nonce
    ):
        raise CoordinatorError("coordinator_frame_binding_invalid")
    return parse_coordinator_output(
        value["coordinator_output"], expected_request_id=expected_request_id
    )


def _unknown_output(request_id: str, reason: str) -> Mapping[str, object]:
    if reason not in _REASONS or reason == "completed":
        reason = "worker_failed"
    return _freeze(
        {
            "schema": COORDINATOR_OUTPUT_SCHEMA,
            "request_id": request_id,
            "state": "unknown",
            "reason": reason,
            "worker_observation": None,
            "worker_facts": {
                "process_created": False,
                "job_assignment_observed": False,
                "launcher_resumed": False,
                "launcher_exit_observed": False,
                "launcher_exit_code": None,
                "job_termination_requested": False,
                "job_termination_call_succeeded": None,
                "job_empty_observed": False,
                "containment": "not_started",
                "controls_retained": False,
            },
        }
    )


def _unknown_output_with_facts(
    request_id: str, reason: str, worker_facts: object
) -> Mapping[str, object]:
    if reason not in _REASONS or reason == "completed":
        reason = "worker_failed"
    facts = _worker_facts(worker_facts)
    return _freeze(
        {
            "schema": COORDINATOR_OUTPUT_SCHEMA,
            "request_id": request_id,
            "state": "unknown",
            "reason": reason,
            "worker_observation": None,
            "worker_facts": dict(facts),
        }
    )


class BootstrapCoordinatorRuntime:
    """Fixed implementation constructed only by the generated bootstrap.

    It receives objects that the bootstrap loaded from retained, hash-checked
    sources.  Nothing in the coordinator wire binding can choose an API,
    process path, environment value, or token implementation.
    """

    __slots__ = (
        "_binding", "_descriptor", "_parent_facts", "_source_seal", "_finder",
        "_dependency_seal", "_runtime_seal", "_anchor_paths", "_support",
        "_token_module", "_output_module", "_expected", "_transfer", "_channel",
        "_worker_facts_value", "_failure_reason", "_closed",
    )

    def __init__(
        self,
        binding: CoordinatorBinding,
        *,
        descriptor: object,
        parent_facts: object,
        source_seal: object,
        source_finder: object,
        dependency_seal: object,
        runtime_seal: object,
        anchor_paths: object,
        support_modules: Mapping[str, object],
        token_module: object,
        output_channel_module: object,
        expected_deployment: Mapping[str, str],
    ) -> None:
        if type(binding) is not CoordinatorBinding:
            raise CoordinatorError("coordinator_binding_invalid")
        self._binding = binding
        self._descriptor = descriptor
        self._parent_facts = parent_facts
        self._source_seal = source_seal
        self._finder = source_finder
        self._dependency_seal = dependency_seal
        self._runtime_seal = runtime_seal
        self._anchor_paths = anchor_paths
        self._support = dict(support_modules)
        self._token_module = token_module
        self._output_module = output_channel_module
        self._expected = dict(expected_deployment)
        self._transfer = None
        self._channel = None
        self._worker_facts_value = {
            "process_created": False,
            "job_assignment_observed": False,
            "launcher_resumed": False,
            "launcher_exit_observed": False,
            "launcher_exit_code": None,
            "job_termination_requested": False,
            "job_termination_call_succeeded": None,
            "job_empty_observed": False,
            "containment": "not_started",
            "controls_retained": False,
        }
        self._failure_reason = "worker_failed"
        self._closed = False

    @property
    def failure_reason(self) -> str:
        return self._failure_reason

    def _check_deadline(self) -> None:
        now = time.monotonic_ns()
        if type(now) is not int or now < 0 or now >= self._binding.deadline_monotonic_ns:
            raise CoordinatorError("deadline_expired")

    def _verify_current(self) -> None:
        self._check_deadline()
        if dict(self._binding.deployment) != self._expected or self._closed:
            raise CoordinatorError("deployment_binding_mismatch")
        self._source_seal.source_lease.verify_current()
        self._dependency_seal.verify_current()
        self._runtime_seal.verify_current()
        self._anchor_paths.verify_current()
        self._check_deadline()

    def monotonic_ns(self) -> int:
        return time.monotonic_ns()

    def verify_deployment(self, deployment: Mapping[str, str]) -> None:
        if dict(deployment) != self._expected:
            raise CoordinatorError("deployment_binding_mismatch")
        self._verify_current()

    def receive_and_set_owner_token_session_zero(
        self, binding: CoordinatorBinding
    ) -> None:
        if binding != self._binding or self._transfer is not None:
            raise CoordinatorError("owner_token_invalid")
        self._verify_current()
        transfer = None
        try:
            transfer = self._token_module.read_token_bootstrap_frame_from_pipe(
                binding.token_control_channel,
                expected_request_id=binding.request_id,
                expected_owner_sid=binding.owner_sid,
                deadline_monotonic_ns=binding.deadline_monotonic_ns,
            )
            facts = self._token_module.apply_owner_token_session_zero(
                transfer,
                api=self._token_module.WindowsTokenSessionApi(),
            )
            if (
                facts.owner_sid != binding.owner_sid
                or facts.target_session_id != 0
                or facts.authentication_id != transfer.authentication_id
            ):
                raise CoordinatorError("owner_token_session_failed")
            self._transfer = transfer
            self._verify_current()
        except BaseException as error:
            if transfer is not None:
                try:
                    self._token_module.WindowsTokenSessionApi().close_owner_token(transfer)
                except BaseException:
                    self._token_module.WindowsTokenSessionApi().fail_stop_current_process(
                        "owner_token_cleanup_unknown"
                    )
            if isinstance(error, self._token_module.FatalPrivilegeRestore):
                raise
            if isinstance(error, CoordinatorError):
                raise
            name = error.args[0] if getattr(error, "args", ()) else None
            reason = (
                "owner_token_session_failed"
                if type(name) is str and ("session" in name or "se_tcb" in name)
                else "owner_token_invalid"
            )
            raise CoordinatorError(reason) from None

    @staticmethod
    def _facts_from_result(result: object) -> dict[str, object]:
        evidence = getattr(result, "evidence", None)
        if evidence is None:
            raise CoordinatorError("worker_cleanup_unverified")
        exit_code = getattr(evidence, "launcher_exit_code", None)
        facts = {
            "process_created": getattr(evidence, "process_created", None) is True,
            "job_assignment_observed": getattr(evidence, "job_assignment_observed", None) is True,
            "launcher_resumed": getattr(evidence, "launcher_resumed", None) is True,
            "launcher_exit_observed": getattr(evidence, "launcher_exit_observed", None) is True,
            "launcher_exit_code": exit_code if type(exit_code) is int else None,
            "job_termination_requested": getattr(evidence, "job_termination_requested", None) is True,
            "job_termination_call_succeeded": getattr(
                evidence, "job_termination_call_succeeded", None
            ),
            "job_empty_observed": getattr(evidence, "job_empty_observed", None) is True,
            "containment": getattr(evidence, "containment", "unknown"),
            "controls_retained": getattr(evidence, "controls_retained", None) is not False,
        }
        if facts["launcher_exit_observed"] != (facts["launcher_exit_code"] is not None):
            facts["launcher_exit_observed"] = facts["launcher_exit_code"] is not None
        if facts["containment"] not in {"verified", "unknown", "not_started"}:
            facts["containment"] = "unknown"
        return dict(_worker_facts(facts))

    @staticmethod
    def _worker_summary_from_raw(raw: bytes) -> Mapping[str, object]:
        value = _parse_canonical_object(raw, maximum=63 * 1024)
        if set(value) != {"schema", "observation"} or value["schema"] != _WORKER_OUTPUT_SCHEMA:
            raise CoordinatorError("worker_output_invalid")
        observation = value["observation"]
        if type(observation) is not dict or set(observation) != _WORKER_PUBLIC_FIELDS:
            raise CoordinatorError("worker_output_invalid")
        bools = (
            "credentials_resolved", "provider_connected", "account_identity_verified",
            "preflight_authorized", "execution_authorized", "external_writes_authorized",
            "order_submission_authorized", "cancellation_authorized", "settlement_authorized",
            "arming_authorized",
        )
        if (
            any(type(observation[name]) is not bool for name in bools)
            or observation["credentials_resolved"] is not True
            or any(observation[name] is not False for name in bools[1:])
            or type(observation["external_write_requests"]) is not int
            or observation["external_write_requests"] != 0
            or type(observation["market_data_trading_writes"]) is not int
            or observation["market_data_trading_writes"] != 0
        ):
            raise CoordinatorError("worker_output_invalid")
        account = observation["read_only_observation"]
        market = observation["market_data_observation"]
        if (
            type(account) is not dict or set(account) != _WORKER_ACCOUNT_FIELDS
            or type(market) is not dict or set(market) != _WORKER_MARKET_FIELDS
            or account["account_scope"] != "redacted"
            or account["account_acceptance_established"] is not False
            or account["approval_required"] is not False
            or account["read_only_route_admitted"] is not True
            or account["session_connected"] is not True
            or account["provider_preflight_started"] is not True
            or account["provider"] != "ctp"
            or account["environment"] != "simnow"
            or account["sdk_profile"] != "config_front_pair"
            or account["runtime_id"] != "example.013_3.sa_midfreq_simnow.ctp_private"
            or account["strategy_id"] != "example.013_3.sa_midfreq_simnow"
            or any(account[name] is not False for name in (
                "arming_authorized", "cancellation_authorized", "execution_authorized",
                "external_writes_authorized", "order_submission_authorized",
                "settlement_authorized",
            ))
            or account["external_write_requests"] != 0
            or account["query_snapshot"] is None
            or market["account_scope_bound"] is not True
            or market["market_login_ready"] is not True
            or market["subscription_acknowledged"] is not True
            or market["first_tick_observed"] is not True
            or market["market_path_ready"] is not True
            or market["client_stop_returned"] is not True
            or market["native_join_pending"] is not False
            or market["probe_session_closed"] is not True
            or market["order_submission_authorized"] is not False
            or market["trading_writes"] != 0
            or market["settlement_writes"] != 0
            or market["account_probe_lock_scope"] != "cooperating_probe_invocations_only"
            or account["instrument_id"] != market["instrument_id"]
            or account["exchange_id"] != market["exchange_id"]
        ):
            raise CoordinatorError("worker_output_invalid")
        snapshot = account["query_snapshot"]
        if type(snapshot) is not dict or not {"identity", "query_digests", "snapshot_sha256"}.issubset(snapshot):
            raise CoordinatorError("worker_output_invalid")
        canonical_facts = {
            key: snapshot[key]
            for key in ("identity", "query_digests", "native_certificate_sha256", "rate_exchange_scopes")
            if key in snapshot
        }
        expected_snapshot = hashlib.sha256(
            json.dumps(
                canonical_facts, sort_keys=True, separators=(",", ":"), ensure_ascii=True
            ).encode("ascii")
        ).hexdigest()
        if snapshot["snapshot_sha256"] != expected_snapshot:
            raise CoordinatorError("worker_output_invalid")
        identity = snapshot["identity"]
        if (
            account["connection_generation"] != identity.get("connection_generation")
            or account["trading_day"] != identity.get("trading_day")
            or account["native_certificate_sha256"] != snapshot.get("native_certificate_sha256")
            or account["native_certificate_provenance"] != (
                "UNVERIFIED_DIGEST_ONLY"
                if account["native_certificate_sha256"] is not None
                else "LOCAL_ONLY"
            )
        ):
            raise CoordinatorError("worker_output_invalid")
        tick = market["tick_binding"]
        if (
            type(tick) is not dict or set(tick) != _WORKER_TICK_FIELDS
            or tick.get("account_bound") is not True
            or tick.get("connection_generation") != market["connection_generation"]
            or tick.get("instrument_id") != market["instrument_id"]
            or tick.get("exchange_id") != market["exchange_id"]
            or tick.get("md_front_sha256") != market["md_front_sha256"]
            or type(market["tick_observation_count"]) is not int
            or market["tick_observation_count"] < 1
        ):
            raise CoordinatorError("worker_output_invalid")
        summary = {
            "schema": _WORKER_SUMMARY_SCHEMA,
            "identity": identity,
            "query_digests": snapshot["query_digests"],
            "snapshot_sha256": snapshot["snapshot_sha256"],
        }
        return _worker_summary(summary)

    def run_fixed_worker(self, binding: CoordinatorBinding) -> tuple[object, object]:
        if binding != self._binding or self._transfer is None:
            self._failure_reason = "owner_token_invalid"
            return None, dict(self._worker_facts_value)
        self._verify_current()
        worker_schema = "ctp_i13_i15_readonly_preflight_bootstrap_binding.v3"
        channel = None
        result = None
        transfer = self._transfer
        try:
            channel = self._output_module.create_worker_output_channel(
                service_sid=binding.service_sid, client_sid=binding.owner_sid
            )
            self._channel = channel
            worker_binding = {
                "schema": worker_schema,
                "deployment_descriptor_sha256": self._expected["descriptor_sha256"],
                "source_manifest_sha256": self._expected["source_manifest_sha256"],
                "i13_pin_sha256": self._expected["i13_pin_sha256"],
                "i15_pin_sha256": self._expected["i15_pin_sha256"],
                "bootstrap_sha256": self._expected["bootstrap_sha256"],
                "worker_sha256": self._expected["worker_sha256"],
                "dependency_manifest_sha256": self._expected["dependency_manifest_sha256"],
                "runtime_manifest_sha256": self._expected["runtime_manifest_sha256"],
                "python_sha256": self._expected["python_sha256"],
                "deadline_monotonic_ns": binding.deadline_monotonic_ns,
                "request_id": binding.request_id,
                "worker_output": dict(channel.bootstrap_binding),
            }
            system_root = os.environ.get("SYSTEMROOT")
            if type(system_root) is not str or not system_root or system_root != os.environ.get("WINDIR"):
                raise CoordinatorError("worker_launch_failed")
            root = str(self._source_seal.source_root)
            executable = os.path.abspath(sys.executable)
            bootstrap_path = ntpath.join(root, "scripts", "ctp_i13_i15_readonly_preflight_bootstrap.py")
            worker_command = self._support["scripts/ctp_i13_i15_outer_watchdog.py"].FixedOuterCommand(
                [
                    executable, "-I", "-S", "-B", "-X",
                    "pycache_prefix={}".format(self._parent_facts.python_home + "\\disabled-bytecode-cache"),
                    bootstrap_path,
                ],
                root,
                {
                    "PATH": os.path.dirname(executable),
                    "SYSTEMROOT": system_root,
                    "WINDIR": system_root,
                    "BT_I13_READONLY_BOOTSTRAP_BINDING": json.dumps(
                        worker_binding, ensure_ascii=True, sort_keys=True, separators=(",", ":")
                    ),
                },
            )
            now = time.monotonic()
            deadline = binding.deadline_monotonic_ns / 1_000_000_000.0
            stop_deadline = deadline - 2.0
            if now >= stop_deadline:
                raise CoordinatorError("deadline_expired")
            backend = self._support["scripts/ctp_i13_i15_windows_job_backend.py"].WindowsJobBackend(
                primary_token_handle=transfer.remote_primary_token_handle,
                no_inherited_handles=True,
                process_created_callback=channel.bind_suspended_worker,
            )
            result = self._output_module.run_child_with_output_channel(
                channel,
                worker_command,
                backend=backend,
                request_id=binding.request_id,
                deadline_monotonic=deadline,
                stop_deadline_monotonic=stop_deadline,
            )
            facts = self._facts_from_result(result)
            self._worker_facts_value = dict(facts)
            clean = (
                getattr(result, "state", None) == "exited"
                and getattr(result, "reason", None) == "launcher_exited_job_empty"
                and facts["process_created"] is True
                and facts["job_assignment_observed"] is True
                and facts["launcher_resumed"] is True
                and facts["launcher_exit_observed"] is True
                and facts["launcher_exit_code"] == 0
                and facts["job_termination_requested"] is False
                and facts["job_empty_observed"] is True
                and facts["containment"] == "verified"
                and facts["controls_retained"] is False
            )
            if not clean:
                self._failure_reason = (
                    "worker_cleanup_unverified"
                    if facts["job_empty_observed"] is not True or facts["controls_retained"]
                    else "worker_failed"
                )
                return None, facts
            raw = channel.read_after_job_empty(
                request_id=binding.request_id,
                outer_result=result,
                deadline_monotonic=deadline,
            )
            observation = self._worker_summary_from_raw(raw)
            self._failure_reason = "completed"
            return _thaw(observation), facts
        except CoordinatorError as error:
            reason = error.args[0] if error.args else "worker_failed"
            self._failure_reason = reason if reason in _REASONS else "worker_failed"
            if result is not None:
                try:
                    self._worker_facts_value = self._facts_from_result(result)
                except BaseException:
                    pass
            return None, dict(self._worker_facts_value)
        except BaseException:
            self._failure_reason = "worker_launch_failed" if result is None else "worker_output_invalid"
            if result is not None:
                try:
                    self._worker_facts_value = self._facts_from_result(result)
                except BaseException:
                    self._failure_reason = "worker_cleanup_unverified"
            return None, dict(self._worker_facts_value)
        finally:
            close_failed = False
            if channel is not None:
                try:
                    if channel.close() is not True:
                        close_failed = True
                except BaseException:
                    close_failed = True
            try:
                self._token_module.WindowsTokenSessionApi().close_owner_token(transfer)
            except BaseException:
                close_failed = True
            self._transfer = None
            self._channel = None
            if close_failed:
                self._failure_reason = "worker_cleanup_unverified"
                self._worker_facts_value["controls_retained"] = True

    def write_supervisor_output(
        self, binding: CoordinatorBinding, output: Mapping[str, object]
    ) -> None:
        if binding != self._binding:
            raise CoordinatorError("supervisor_channel_failed")
        self._verify_current()
        channel = binding.supervisor_output_channel
        body = encode_coordinator_frame(
            output, request_id=binding.request_id, nonce=str(channel["nonce"])
        )
        frame = len(body).to_bytes(4, "big", signed=False) + body
        self._output_module._write_bounded_frame(
            frame,
            nonce=str(channel["nonce"]),
            expected_server_pid=int(channel["server_pid"]),
            deadline_monotonic_ns=binding.deadline_monotonic_ns,
        )

    def close(self) -> None:
        if self._closed:
            return
        failures = []
        if self._channel is not None:
            try:
                if self._channel.close() is not True:
                    failures.append("worker_channel_close")
            except BaseException:
                failures.append("worker_channel_close")
        if self._transfer is not None:
            try:
                self._token_module.WindowsTokenSessionApi().close_owner_token(self._transfer)
            except BaseException:
                failures.append("owner_token_close")
            self._transfer = None
        self._closed = True
        if failures:
            raise CoordinatorError("coordinator_cleanup_unverified")


def run_request_coordinator(binding_value: object, *, api: CoordinatorApi) -> int:
    """Run one fixed inert request through bootstrap-owned OS adapters.

    This function does not choose paths, load configuration or construct a
    backend.  Those operations are supplied by the sealed bootstrap runtime.
    An ordinary adapter failure produces an UNKNOWN frame.  Fatal identity
    cleanup exceptions deliberately escape so the containing Job is killed.
    """

    binding = parse_coordinator_binding(binding_value)
    output = _unknown_output(binding.request_id, "worker_failed")
    worker_facts = dict(output["worker_facts"])
    now_ns = api.monotonic_ns()
    if type(now_ns) is not int or now_ns < 0 or now_ns >= binding.deadline_monotonic_ns:
        return 2
    try:
        api.verify_deployment(binding.deployment)
        api.receive_and_set_owner_token_session_zero(binding)
        now_ns = api.monotonic_ns()
        if type(now_ns) is not int or now_ns < 0 or now_ns >= binding.deadline_monotonic_ns:
            return 2
        observation, facts = api.run_fixed_worker(binding)
        worker_facts = dict(_worker_facts(facts))
        worker_reason = getattr(api, "failure_reason", "worker_failed")
        is_clean = (
            worker_facts["process_created"] is True
            and worker_facts["job_assignment_observed"] is True
            and worker_facts["launcher_resumed"] is True
            and worker_facts["launcher_exit_observed"] is True
            and worker_facts["launcher_exit_code"] == 0
            and worker_facts["job_termination_requested"] is False
            and worker_facts["job_empty_observed"] is True
            and worker_facts["containment"] == "verified"
            and worker_facts["controls_retained"] is False
        )
        if observation is not None and is_clean and worker_reason == "completed":
            candidate = {
                "schema": COORDINATOR_OUTPUT_SCHEMA,
                "request_id": binding.request_id,
                "state": "observed",
                "reason": "completed",
                "worker_observation": observation,
                "worker_facts": worker_facts,
            }
            output = parse_coordinator_output(
                candidate, expected_request_id=binding.request_id
            )
        else:
            if worker_reason not in _REASONS or worker_reason == "completed":
                worker_reason = "worker_cleanup_unverified" if not is_clean else "worker_failed"
            output = _unknown_output_with_facts(
                binding.request_id, worker_reason, worker_facts
            )
    except CoordinatorError as error:
        reason = error.args[0] if error.args else "worker_failed"
        if reason not in _REASONS or reason == "completed":
            reason = "worker_failed"
        output = _unknown_output_with_facts(binding.request_id, reason, worker_facts)
    except Exception:
        output = _unknown_output_with_facts(
            binding.request_id, "worker_failed", worker_facts
        )
    now_ns = api.monotonic_ns()
    if type(now_ns) is not int or now_ns < 0 or now_ns >= binding.deadline_monotonic_ns:
        return 2
    api.write_supervisor_output(binding, output)
    return 0 if output["state"] == "observed" else 2


def main(binding: object, runtime: CoordinatorApi) -> int:
    """Fixed-bootstrap entrypoint; ``runtime`` is never read from the binding."""

    return run_request_coordinator(binding, api=runtime)


__all__ = [
    "COORDINATOR_BINDING_SCHEMA",
    "COORDINATOR_OUTPUT_SCHEMA",
    "COORDINATOR_FRAME_SCHEMA",
    "CoordinatorBinding",
    "CoordinatorError",
    "parse_coordinator_binding",
    "parse_coordinator_output",
    "encode_coordinator_output",
    "encode_coordinator_frame",
    "parse_coordinator_frame",
    "run_request_coordinator",
    "BootstrapCoordinatorRuntime",
    "main",
]
