"""Local-process evidence for the isolated G1 two-stage candidate.

These tests use inert Python children and the real Windows Job backend. They
do not load a deployment anchor, configuration, SDK, provider, or native CTP
module. The normal success case uses an explicit test-only worker adapter so
it can prove the coordinator and receipt-writer Job stages without depending
on r6's immediate outer Job-empty observation racing a nested worker Job.
These tests validate process/Job mechanics only, not a deployable trust root.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import pytest

from scripts import (
    ctp_i13_i15_outer_watchdog as outer_watchdog,
)
from scripts import (
    ctp_i13_i15_readonly_receipt_writer as receipt_writer,
)
from scripts import (
    ctp_i13_i15_readonly_request_coordinator as coordinator,
)
from scripts import (
    ctp_i13_i15_windows_job_backend as job_backend,
)

ROOT = Path(__file__).resolve().parents[3]


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _deployment() -> dict[str, str]:
    keys = (
        "descriptor_sha256",
        "source_manifest_sha256",
        "runtime_manifest_sha256",
        "dependency_manifest_sha256",
        "python_sha256",
        "i13_pin_sha256",
        "i15_pin_sha256",
        "bootstrap_sha256",
        "worker_sha256",
        "coordinator_sha256",
        "receipt_writer_sha256",
        "token_bootstrap_sha256",
    )
    return {key: _sha(key.encode("ascii")) for key in keys}


def _clean_facts(result: object) -> dict[str, object]:
    evidence = result.evidence
    return {
        "process_created": evidence.process_created is True,
        "job_assignment_observed": evidence.job_assignment_observed is True,
        "launcher_resumed": evidence.launcher_resumed is True,
        "launcher_exit_observed": evidence.launcher_exit_observed is True,
        "launcher_exit_code": evidence.launcher_exit_code,
        "job_termination_requested": evidence.job_termination_requested,
        "job_termination_call_succeeded": evidence.job_termination_call_succeeded,
        "job_empty_observed": evidence.job_empty_observed is True,
        "containment": evidence.containment,
        "controls_retained": evidence.controls_retained is not False,
    }


def _clean_success(result: object) -> bool:
    facts = _clean_facts(result)
    return (
        result.state == "exited"
        and result.reason == "launcher_exited_job_empty"
        and facts["process_created"] is True
        and facts["job_assignment_observed"] is True
        and facts["launcher_resumed"] is True
        and facts["launcher_exit_observed"] is True
        and facts["launcher_exit_code"] == 0
        and facts["job_termination_requested"] is False
        and facts["job_empty_observed"] is True
        and facts["containment"] == "verified"
        and facts["controls_retained"] is False
    )


def _minimal_env() -> dict[str, str]:
    system_root = os.environ.get("SYSTEMROOT")
    assert system_root and system_root == os.environ.get("WINDIR")
    return {
        "PATH": str(Path(sys.executable).parent),
        "SYSTEMROOT": system_root,
        "WINDIR": system_root,
    }


def _command(source: str, tmp_path: Path, *, env: dict[str, str] | None = None):
    return outer_watchdog.FixedOuterCommand(
        [sys.executable, "-I", "-S", "-B", "-c", source],
        str(tmp_path),
        _minimal_env() if env is None else env,
    )


def _run(
    command: object,
    deadline: float,
    *,
    stop_deadline: float | None = None,
    backend=None,
):
    return outer_watchdog.run_outer_watchdog(
        command,
        backend=backend or job_backend.WindowsJobBackend(no_inherited_handles=True),
        deadline_monotonic=deadline,
        stop_deadline_monotonic=stop_deadline,
        poll_interval_seconds=0.01,
    )


class _ProcessOnlySession:
    """Test-only process launcher with synthetic Job evidence.

    This makes the successful two-stage ordering deterministic. It is not a
    Windows Job backend and is never used to establish containment; separate
    tests below exercise real Job termination and cleanup.
    """

    process_created = True
    job_assignment_observed = True

    def __init__(self, command: object):
        self.command = command
        self.process: subprocess.Popen[bytes] | None = None

    def resume_launcher(self) -> bool:
        if self.process is not None:
            return False
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.process = subprocess.Popen(
            list(self.command.argv),
            cwd=self.command.cwd,
            env=dict(self.command.env),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=flags,
        )
        return True

    def poll_launcher_exit_code(self):
        return None if self.process is None else self.process.poll()

    def poll_job_empty(self) -> bool:
        return self.poll_launcher_exit_code() is not None

    def terminate_job(self) -> bool:
        return self.terminate_launcher_process()

    def terminate_launcher_process(self) -> bool:
        if self.process is None:
            return False
        if self.process.poll() is None:
            self.process.kill()
        return True

    def release_controls(self) -> bool:
        return self.process is not None and self.process.poll() is not None


class _ProcessOnlyBackend:
    def create_suspended_in_job(self, command, *, deadline_monotonic):
        del deadline_monotonic
        return _ProcessOnlySession(command)

    def retain_controls(self, _session):
        return "test-only-not-a-job-custody-token"


def test_r2_single_nonempty_job_poll_fails_closed_even_if_cleanup_later_observes_empty(
    tmp_path,
):
    class LaggingJobSession:
        process_created = True
        job_assignment_observed = True

        def __init__(self):
            self.job_empty_polls = 0

        def resume_launcher(self):
            return True

        def poll_launcher_exit_code(self):
            return 0

        def poll_job_empty(self):
            self.job_empty_polls += 1
            return self.job_empty_polls > 1

        def terminate_job(self):
            return True

        def terminate_launcher_process(self):
            return True

        def release_controls(self):
            return True

    class LaggingJobBackend:
        def create_suspended_in_job(self, _command, *, deadline_monotonic):
            del deadline_monotonic
            return LaggingJobSession()

        def retain_controls(self, _session):
            return "test-only-retained-controls"

    deadline = time.monotonic() + 1.0
    result = _run(
        _command("pass", tmp_path),
        deadline,
        backend=LaggingJobBackend(),
    )
    facts = _clean_facts(result)
    assert result.state == "failed"
    assert result.reason == "descendant_or_job_state_unconfirmed"
    assert facts["job_termination_requested"] is True
    assert facts["job_termination_call_succeeded"] is True
    assert facts["job_empty_observed"] is True
    assert facts["containment"] == "verified"
    assert facts["controls_retained"] is False


def _coordinator_source(
    *,
    binding: dict[str, object],
    root: Path,
    frame_path: Path,
    workdir: Path,
    worker_mode: str = "fake-clean",
) -> str:
    binding_literal = repr(json.dumps(binding, sort_keys=True, separators=(",", ":")))
    worker_marker = str(workdir / "worker-complete.marker")
    worker_code = (
        "import pathlib,time; pathlib.Path("
        + repr(worker_marker)
        + ").write_bytes(b'worker');"
        + ("time.sleep(30)" if worker_mode == "blocked" else "time.sleep(0.04)")
    )
    frame_literal = repr(str(frame_path))
    error_literal = repr(str(frame_path) + ".error")
    source_root_literal = repr(str(root))
    worker_code_literal = repr(worker_code)
    worker_result_literal = repr(str(frame_path) + ".worker-result")
    worker_mode_literal = repr(worker_mode)
    return f"""\
import hashlib, json, os, sys, time
sys.path.insert(0, {source_root_literal})
from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand, run_outer_watchdog
from scripts.ctp_i13_i15_windows_job_backend import WindowsJobBackend
from scripts.ctp_i13_i15_readonly_request_coordinator import (
    COORDINATOR_OUTPUT_SCHEMA, encode_coordinator_frame, run_request_coordinator,
)
BINDING = json.loads({binding_literal})
WORKER_CODE = {worker_code_literal}
FRAME_PATH = {frame_literal}
ERROR_PATH = {error_literal}
WORKER_RESULT_PATH = {worker_result_literal}
WORKER_MODE = {worker_mode_literal}
class Runtime:
    failure_reason = "completed"
    def monotonic_ns(self):
        return time.monotonic_ns()
    def verify_deployment(self, deployment):
        if set(deployment) != set(BINDING["deployment"]):
            raise ValueError("deployment mismatch")
    def receive_and_set_owner_token_session_zero(self, binding):
        return None  # test-only inert token seam; no token APIs are called
    def run_fixed_worker(self, binding):
        if WORKER_MODE == "fake-clean":
            with open({worker_marker!r}, "wb") as stream:
                stream.write(b"test-only worker adapter; no worker process")
            facts = {{
                "process_created": True,
                "job_assignment_observed": True,
                "launcher_resumed": True,
                "launcher_exit_observed": True,
                "launcher_exit_code": 0,
                "job_termination_requested": False,
                "job_termination_call_succeeded": None,
                "job_empty_observed": True,
                "containment": "verified",
                "controls_retained": False,
            }}
            names = ("account", "commission_rates", "instruments", "margin_rates", "orders", "positions", "trades")
            summary = {{
                "schema": "ctp_i13_i15_readonly_worker_summary.v1",
                "identity": {{"account_scope": "redacted", "provider": "ctp", "environment": "simnow", "trading_day": "20260927", "connection_generation": 1}},
                "query_digests": [[name, hashlib.sha256(name.encode("ascii")).hexdigest()] for name in names],
                "snapshot_sha256": hashlib.sha256(b"synthetic inert observation").hexdigest(),
            }}
            self.failure_reason = "completed"
            return summary, facts
        deadline = binding.deadline_monotonic_ns / 1_000_000_000.0
        command = FixedOuterCommand(
            [sys.executable, "-I", "-S", "-B", "-c", WORKER_CODE],
            os.getcwd(),
            {{"PATH": os.environ["PATH"], "SYSTEMROOT": os.environ["SYSTEMROOT"], "WINDIR": os.environ["WINDIR"]}},
        )
        result = run_outer_watchdog(
            command,
            backend=WindowsJobBackend(no_inherited_handles=True),
            deadline_monotonic=deadline,
            stop_deadline_monotonic=deadline - 0.35,
            poll_interval_seconds=0.01,
        )
        evidence = result.evidence
        with open(WORKER_RESULT_PATH, "w", encoding="utf-8") as stream:
            stream.write(repr((result.state, result.reason, evidence)))
        code = evidence.launcher_exit_code
        facts = {{
            "process_created": evidence.process_created is True,
            "job_assignment_observed": evidence.job_assignment_observed is True,
            "launcher_resumed": evidence.launcher_resumed is True,
            "launcher_exit_observed": evidence.launcher_exit_observed is True,
            "launcher_exit_code": code,
            "job_termination_requested": evidence.job_termination_requested,
            "job_termination_call_succeeded": evidence.job_termination_call_succeeded,
            "job_empty_observed": evidence.job_empty_observed is True,
            "containment": evidence.containment,
            "controls_retained": evidence.controls_retained is not False,
        }}
        if result.state == "exited" and result.reason == "launcher_exited_job_empty" and code == 0 and facts["job_empty_observed"] and facts["controls_retained"] is False:
            names = ("account", "commission_rates", "instruments", "margin_rates", "orders", "positions", "trades")
            summary = {{
                "schema": "ctp_i13_i15_readonly_worker_summary.v1",
                "identity": {{"account_scope": "redacted", "provider": "ctp", "environment": "simnow", "trading_day": "20260927", "connection_generation": 1}},
                "query_digests": [[name, hashlib.sha256(name.encode("ascii")).hexdigest()] for name in names],
                "snapshot_sha256": hashlib.sha256(b"synthetic inert observation").hexdigest(),
            }}
            self.failure_reason = "completed"
            return summary, facts
        self.failure_reason = "worker_cleanup_unverified" if facts["job_empty_observed"] is not True or facts["controls_retained"] else "worker_failed"
        return None, facts
    def write_supervisor_output(self, binding, output):
        try:
            frame = encode_coordinator_frame(output, request_id=binding.request_id, nonce=binding.supervisor_output_channel["nonce"])
        except BaseException:
            with open(FRAME_PATH + ".output", "w", encoding="utf-8") as stream:
                stream.write(repr(dict(output)))
            raise
        with open(FRAME_PATH, "xb") as stream:
            stream.write(frame)
runtime = Runtime()
try:
    exit_code = run_request_coordinator(BINDING, api=runtime)
except BaseException:
    import traceback
    with open(ERROR_PATH, "w", encoding="utf-8") as stream:
        stream.write(traceback.format_exc())
    raise
raise SystemExit(exit_code)
"""


def _writer_source(
    *,
    binding: dict[str, object],
    root: Path,
    frame_path: Path,
    receipt_path: Path,
    mode: str = "success",
) -> str:
    binding_literal = repr(json.dumps(binding, sort_keys=True, separators=(",", ":")))
    source_root_literal = repr(str(root))
    frame_literal = repr(str(frame_path))
    receipt_literal = repr(str(receipt_path))
    close_code = "time.sleep(30)" if mode == "blocked" else "None"
    return f"""\
import hashlib, json, os, sys, time
sys.path.insert(0, {source_root_literal})
from scripts.ctp_i13_i15_readonly_receipt_writer import encode_receipt_writer_frame, run_receipt_writer
BINDING = json.loads({binding_literal})
FRAME_PATH = {frame_literal}
RECEIPT_PATH = {receipt_literal}
class Runtime:
    def monotonic_ns(self):
        return time.monotonic_ns()
    def verify_deployment(self, deployment):
        if set(deployment) != set(BINDING["deployment"]):
            raise ValueError("deployment mismatch")
    def close_execution(self):
        {close_code}
    def persist_fixed_receipt(self, request_id, raw):
        fd = os.open(RECEIPT_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            if os.write(fd, raw) != len(raw):
                raise OSError("short write")
            os.fsync(fd)
        finally:
            os.close(fd)
        with open(RECEIPT_PATH, "rb") as stream:
            if stream.read() != raw:
                raise OSError("readback mismatch")
    def write_supervisor_output(self, binding, output):
        frame = encode_receipt_writer_frame(output, request_id=binding.request_id, nonce=binding.receipt_output_channel["nonce"])
        with open(FRAME_PATH, "xb") as stream:
            stream.write(frame)
raise SystemExit(run_receipt_writer(BINDING, api=Runtime()))
"""


def _base_coordinator_binding(request_id: str, deadline_ns: int) -> dict[str, object]:
    return {
        "schema": coordinator.COORDINATOR_BINDING_SCHEMA,
        "request_id": request_id,
        "deadline_monotonic_ns": deadline_ns,
        "deployment": _deployment(),
        "identities": {
            "service_sid": "S-1-5-80-100-200-300-400-500",
            "owner_sid": "S-1-5-21-100-200-300-400-1001",
        },
        "supervisor_output_channel": {
            "nonce": uuid.uuid4().hex,
            "server_pid": os.getpid(),
        },
        "token_control_channel": {"nonce": uuid.uuid4().hex, "server_pid": os.getpid()},
    }


@pytest.mark.skipif(os.name != "nt", reason="requires the real Windows Job backend")
def test_r2_two_job_local_process_success_observes_each_job_before_next_stage(tmp_path):
    request_id = uuid.uuid4().hex
    deadline_ns = time.monotonic_ns() + 15_000_000_000
    deadline = deadline_ns / 1_000_000_000.0
    coordinator_frame_path = tmp_path / "coordinator.frame"
    coordinator_binding = _base_coordinator_binding(request_id, deadline_ns)
    coordinator_command = _command(
        _coordinator_source(
            binding=coordinator_binding,
            root=ROOT,
            frame_path=coordinator_frame_path,
            workdir=tmp_path,
        ),
        tmp_path,
    )
    coordinator_result = _run(
        coordinator_command,
        deadline,
        stop_deadline=deadline - 1.0,
        backend=_ProcessOnlyBackend(),
    )
    (tmp_path / "coordinator-outer-facts.txt").write_text(
        repr(
            (
                coordinator_result.state,
                coordinator_result.reason,
                _clean_facts(coordinator_result),
            )
        ),
        encoding="utf-8",
    )
    assert _clean_success(coordinator_result), (
        coordinator_result.state,
        coordinator_result.reason,
        _clean_facts(coordinator_result),
        (tmp_path / "coordinator.frame.error").read_text()
        if (tmp_path / "coordinator.frame.error").exists()
        else None,
        (tmp_path / "coordinator.frame.worker-result").read_text()
        if (tmp_path / "coordinator.frame.worker-result").exists()
        else None,
    )
    # Do not read a role frame until exit, Job-empty and control release are observed.
    coordinator_frame = coordinator_frame_path.read_bytes()
    work_result = coordinator._thaw(
        coordinator.parse_coordinator_frame(
            coordinator_frame,
            expected_request_id=request_id,
            expected_nonce=coordinator_binding["supervisor_output_channel"]["nonce"],
        )
    )
    assert work_result["state"] == "observed"
    assert work_result["worker_facts"]["job_empty_observed"] is True
    assert work_result["worker_facts"]["controls_retained"] is False
    assert (tmp_path / "worker-complete.marker").is_file()
    assert (tmp_path / "worker-complete.marker").read_bytes() == (
        b"test-only worker adapter; no worker process"
    )

    writer_frame_path = tmp_path / "writer.frame"
    receipt_path = tmp_path / "receipt.json"
    writer_binding = {
        "schema": receipt_writer.RECEIPT_BINDING_SCHEMA,
        "request_id": request_id,
        "deadline_monotonic_ns": deadline_ns,
        "deployment": _deployment(),
        "work_result": work_result,
        "coordinator_job": _clean_facts(coordinator_result),
        "receipt_output_channel": {
            "nonce": uuid.uuid4().hex,
            "server_pid": os.getpid(),
        },
    }
    writer_command = _command(
        _writer_source(
            binding=writer_binding,
            root=ROOT,
            frame_path=writer_frame_path,
            receipt_path=receipt_path,
        ),
        tmp_path,
    )
    writer_result = _run(
        writer_command,
        deadline,
        stop_deadline=deadline - 0.2,
        backend=_ProcessOnlyBackend(),
    )
    assert _clean_success(writer_result), writer_result
    # Job2 is only inspected after its own process/Job/control evidence is clean.
    writer_output = receipt_writer.parse_receipt_writer_frame(
        writer_frame_path.read_bytes(),
        expected_request_id=request_id,
        expected_nonce=writer_binding["receipt_output_channel"]["nonce"],
    )
    assert writer_output["state"] == "observed"
    assert receipt_path.is_file()
    assert writer_output["receipt_sha256"] == _sha(receipt_path.read_bytes())
    assert time.monotonic_ns() < deadline_ns


@pytest.mark.skipif(os.name != "nt", reason="requires the real Windows Job backend")
def test_r2_nested_worker_frame_is_not_accepted_without_outer_job_empty(tmp_path):
    """A clean nested worker result cannot substitute for Job1-empty evidence.

    The frozen watchdog performs one Job-empty query at launcher exit. On
    Windows, nested Job accounting may still be propagating at that instant.
    Either it observes empty immediately and returns a clean result, or it
    fails closed; it must never let the coordinator's frame override a
    non-clean outer result.
    """
    request_id = uuid.uuid4().hex
    deadline_ns = time.monotonic_ns() + 12_000_000_000
    deadline = deadline_ns / 1_000_000_000.0
    frame_path = tmp_path / "nested-coordinator.frame"
    binding = _base_coordinator_binding(request_id, deadline_ns)
    result = _run(
        _command(
            _coordinator_source(
                binding=binding,
                root=ROOT,
                frame_path=frame_path,
                workdir=tmp_path,
                worker_mode="success",
            ),
            tmp_path,
        ),
        deadline,
        stop_deadline=deadline - 1.0,
    )
    outer_facts = _clean_facts(result)
    (tmp_path / "nested-outer-outcome.json").write_text(
        json.dumps(
            {
                "state": result.state,
                "reason": result.reason,
                "facts": outer_facts,
                "coordinator_frame_present": frame_path.exists(),
            },
            sort_keys=True,
            separators=(",", ":"),
        ),
        encoding="ascii",
    )
    if _clean_success(result):
        # The outer Job-empty observation itself is authoritative. The inner
        # result is only inspected after that exact clean outer result.
        parsed = coordinator.parse_coordinator_frame(
            frame_path.read_bytes(),
            expected_request_id=request_id,
            expected_nonce=binding["supervisor_output_channel"]["nonce"],
        )
        assert parsed["state"] == "observed"
    else:
        facts = outer_facts
        assert result.state in {"failed", "unknown"}
        assert facts["job_termination_requested"] is True
        assert facts["job_termination_call_succeeded"] is True
        assert facts["job_empty_observed"] is True
        assert facts["containment"] == "verified"
        assert facts["controls_retained"] is False
        # A frame may exist on disk, but the stage runner has no authority to
        # parse or promote it after a non-clean outer Job result.
        assert frame_path.exists()


@pytest.mark.skipif(os.name != "nt", reason="requires the real Windows Job backend")
def test_r2_two_job_blocked_coordinator_is_killed_and_never_starts_writer(tmp_path):
    deadline_ns = time.monotonic_ns() + 2_000_000_000
    deadline = deadline_ns / 1_000_000_000.0
    marker = tmp_path / "late-coordinator.marker"
    code = f"import pathlib,time; time.sleep(30); pathlib.Path({str(marker)!r}).write_text('late')"
    result = _run(_command(code, tmp_path), deadline, stop_deadline=deadline - 0.25)
    facts = _clean_facts(result)
    assert result.state == "timed_out"
    assert facts["job_termination_requested"] is True
    assert facts["job_termination_call_succeeded"] is True
    assert facts["launcher_exit_observed"] is True
    assert facts["job_empty_observed"] is True
    assert facts["containment"] == "verified"
    assert facts["controls_retained"] is False
    assert not marker.exists()
    assert not (tmp_path / "receipt.json").exists()


@pytest.mark.skipif(os.name != "nt", reason="requires the real Windows Job backend")
def test_r2_two_job_blocked_receipt_writer_cannot_publish_late_observed(tmp_path):
    request_id = uuid.uuid4().hex
    deadline_ns = time.monotonic_ns() + 4_000_000_000
    deadline = deadline_ns / 1_000_000_000.0
    coordinator_binding = _base_coordinator_binding(request_id, deadline_ns)
    coordinator_frame_path = tmp_path / "coordinator.frame"
    coordinator_result = _run(
        _command(
            _coordinator_source(
                binding=coordinator_binding,
                root=ROOT,
                frame_path=coordinator_frame_path,
                workdir=tmp_path,
            ),
            tmp_path,
        ),
        deadline,
        stop_deadline=deadline - 1.0,
        backend=_ProcessOnlyBackend(),
    )
    assert _clean_success(coordinator_result), (
        coordinator_result.state,
        coordinator_result.reason,
        _clean_facts(coordinator_result),
        (tmp_path / "coordinator.frame.error").read_text()
        if (tmp_path / "coordinator.frame.error").exists()
        else None,
        (tmp_path / "coordinator.frame.worker-result").read_text()
        if (tmp_path / "coordinator.frame.worker-result").exists()
        else None,
    )
    work_result = coordinator._thaw(
        coordinator.parse_coordinator_frame(
            coordinator_frame_path.read_bytes(),
            expected_request_id=request_id,
            expected_nonce=coordinator_binding["supervisor_output_channel"]["nonce"],
        )
    )
    writer_frame_path = tmp_path / "late-writer.frame"
    receipt_path = tmp_path / "late-receipt.json"
    writer_binding = {
        "schema": receipt_writer.RECEIPT_BINDING_SCHEMA,
        "request_id": request_id,
        "deadline_monotonic_ns": deadline_ns,
        "deployment": _deployment(),
        "work_result": work_result,
        "coordinator_job": _clean_facts(coordinator_result),
        "receipt_output_channel": {
            "nonce": uuid.uuid4().hex,
            "server_pid": os.getpid(),
        },
    }
    writer_result = _run(
        _command(
            _writer_source(
                binding=writer_binding,
                root=ROOT,
                frame_path=writer_frame_path,
                receipt_path=receipt_path,
                mode="blocked",
            ),
            tmp_path,
        ),
        deadline,
        stop_deadline=deadline - 0.25,
    )
    writer_facts = _clean_facts(writer_result)
    assert writer_result.state == "timed_out"
    assert writer_facts["job_termination_requested"] is True
    assert writer_facts["job_empty_observed"] is True
    assert writer_facts["containment"] == "verified"
    assert writer_facts["controls_retained"] is False
    assert not receipt_path.exists()
    assert not writer_frame_path.exists()
    assert writer_result.reason == "outer_worker_deadline_exceeded"


@pytest.mark.skipif(os.name != "nt", reason="requires the real Windows Job backend")
def test_r2_process_exit_with_unconfirmed_control_release_is_not_success(tmp_path):
    real_backend = job_backend.WindowsJobBackend(no_inherited_handles=True)

    class SessionProxy:
        def __init__(self, session):
            self.inner = session
            self.release_attempted = False

        def __getattr__(self, name):
            return getattr(self.inner, name)

        def release_controls(self):
            self.release_attempted = True
            return False

    class ReleaseFailureBackend:
        def __init__(self):
            self.proxy = None

        def create_suspended_in_job(self, command, *, deadline_monotonic):
            self.proxy = SessionProxy(
                real_backend.create_suspended_in_job(
                    command, deadline_monotonic=deadline_monotonic
                )
            )
            return self.proxy

        def retain_controls(self, _session):
            return None

    backend = ReleaseFailureBackend()
    marker = tmp_path / "child-exited.marker"
    deadline = time.monotonic() + 5.0
    result = _run(
        _command(
            f"import pathlib; pathlib.Path({str(marker)!r}).write_text('done')",
            tmp_path,
        ),
        deadline,
        backend=backend,
    )
    facts = _clean_facts(result)
    assert result.state == "unknown"
    assert result.reason == "control_release_unconfirmed"
    assert facts["launcher_exit_observed"] is True
    assert facts["launcher_exit_code"] == 0
    assert facts["job_empty_observed"] is True
    assert facts["containment"] == "unknown"
    assert facts["controls_retained"] is True
    assert backend.proxy is not None and backend.proxy.release_attempted
    assert marker.is_file()
    # Test-only custody: clean the real handles after proving the result stayed UNKNOWN.
    assert backend.proxy.inner.release_controls() is True
    assert not (tmp_path / "receipt.json").exists()
