# ruff: noqa: E402
"""Offline source-only import primitives for the I13/I15 launcher review.

This module is deliberately not an operator entry point.  It does not read a
runtime config, inspect a marker, create a Job, contact a provider, or invoke a
candidate supervisor.  A future captured ``python -I -S -B -c`` bootstrap may
use these primitives only after an external trust descriptor has supplied the
manifest and interpreter pins.  The current I13/I15 pins are unset/zero, so
there is no production trust descriptor that can successfully seal this
checkout. This offline slice targets only the fixed CPython 3.11.5 interpreter;
it is not part of the repository's general Python 3.8+ runtime or CLI.

The finder owns the complete ``backtrader_runtime`` namespace.  It never lets
PathFinder retry an unlisted runtime name, explicitly rejects ``backtrader``
and non-stdlib imports, and compiles only the exact source bytes it hashes.
The standard-library roots passed by a caller must themselves come from an
independently pinned interpreter descriptor; merely passing ``sys.path`` is
not proof of that fact.

Only standard-library module objects captured by this bootstrap or exact source
and extension entries in the verified runtime closure are in the import
closure. New stdlib names fail closed unless the runtime seal supplies their
exact origin and kind; no general ``PathFinder`` fallback is permitted.

The Windows source lease below is integrated with this offline manifest sealer
and source loader. It opens every path component with ``OPEN_REPARSE_POINT``,
retains handles that deny write/delete sharing, and reopens paths to compare
volume/file IDs before reading. The returned seal owns the lease until explicit
close. The parent descriptor, PyYAML/SDK artifacts, fixed stdlib closure, and
actual Windows launch path still require independent pins and review.
"""

import sys


# Exact startup image for the pinned Windows CPython 3.11.5 build used by this
# offline slice.  A name allowlist (for example ``sys.stdlib_module_names``)
# alone is insufficient: an arbitrary preloaded ``sys.modules['json']`` would
# otherwise survive the helper imports below.  The external interpreter and
# stdlib still need an independently reviewed pin; this list cannot establish
# that trust root by itself.
_STARTUP_MODULE_NAMES = frozenset(
    {
        "__main__",
        "_abc",
        "_codecs",
        "_codecs_cn",
        "_frozen_importlib",
        "_frozen_importlib_external",
        "_imp",
        "_io",
        "_multibytecodec",
        "_signal",
        "_thread",
        "_warnings",
        "_weakref",
        "abc",
        "builtins",
        "codecs",
        "encodings",
        "encodings.aliases",
        "encodings.gbk",
        "encodings.utf_8",
        "io",
        "marshal",
        "nt",
        "sys",
        "time",
        "winreg",
        "zipimport",
    }
)
_BUILTIN_STARTUP_MODULES = frozenset(
    {
        "_abc",
        "_codecs",
        "_codecs_cn",
        "_imp",
        "_io",
        "_multibytecodec",
        "_signal",
        "_thread",
        "_warnings",
        "_weakref",
        "builtins",
        "marshal",
        "nt",
        "sys",
        "time",
        "winreg",
    }
)
_FROZEN_STARTUP_MODULES = frozenset(
    {"_frozen_importlib", "_frozen_importlib_external", "abc", "codecs", "io", "zipimport"}
)
_SOURCE_STARTUP_MODULES = frozenset(
    {"encodings", "encodings.aliases", "encodings.gbk", "encodings.utf_8"}
)
_MODULE_NAME_ALIASES = {
    "_collections_abc": "collections.abc",
    "_io": "io",
    "os.path": "ntpath",
}
_MODULE_SPEC_NAME_ALIASES = {
    "importlib._bootstrap": "_frozen_importlib",
    "importlib._bootstrap_external": "_frozen_importlib_external",
    "os.path": "ntpath",
}


def _startup_fail(reason):
    raise RuntimeError(reason)


def _default_filefinder_loader_details(external):
    categories = (
        (external.ExtensionFileLoader, external.EXTENSION_SUFFIXES),
        (external.SourceFileLoader, external.SOURCE_SUFFIXES),
        (external.SourcelessFileLoader, external.BYTECODE_SUFFIXES),
    )
    return tuple((suffix, loader) for loader, suffixes in categories for suffix in suffixes)


def _filefinder_is_default(finder, external, path):
    if type(finder) is not external.FileFinder or finder.path != path:
        return False
    expected = _default_filefinder_loader_details(external)
    actual = finder._loaders
    if type(actual) is not list or len(actual) != len(expected):
        return False
    if not all(
        type(item) is tuple
        and len(item) == 2
        and item[0] == expected[index][0]
        and item[1] is expected[index][1]
        for index, item in enumerate(actual)
    ):
        return False
    try:
        nt = sys.modules["nt"]
        details = nt.stat(path)
        names = nt.listdir(path)
    except (OSError, KeyError):
        return False
    cache = finder._path_cache
    if type(cache) is not set or any(type(name) is not str for name in cache):
        return False
    return finder._path_mtime == details.st_mtime and cache == set(names)


def _module_matches_startup_origin(name, module, *, external, frozen, stdlib_root):
    expected_module_name = _MODULE_NAME_ALIASES.get(name, name)
    if type(module) is not type(sys) or getattr(module, "__name__", None) != expected_module_name:
        return False
    if name == "__main__":
        return getattr(module, "__spec__", None) is None
    spec = getattr(module, "__spec__", None)
    if spec is None or getattr(spec, "name", None) != name:
        return False
    if name in _BUILTIN_STARTUP_MODULES:
        return (
            getattr(spec, "origin", None) == "built-in"
            and getattr(spec, "loader", None) is frozen.BuiltinImporter
            and getattr(module, "__loader__", None) is frozen.BuiltinImporter
        )
    if name in _FROZEN_STARTUP_MODULES:
        return (
            getattr(spec, "origin", None) == "frozen"
            and getattr(spec, "loader", None) is frozen.FrozenImporter
            and getattr(module, "__loader__", None) is frozen.FrozenImporter
        )
    if name not in _SOURCE_STARTUP_MODULES:
        return False
    relative = name.replace(".", "\\")
    source_name = "__init__.py" if name == "encodings" else relative + ".py"
    expected = (
        stdlib_root + "\\" + relative + "\\" + source_name
        if name == "encodings"
        else stdlib_root + "\\" + source_name
    )
    loader = getattr(spec, "loader", None)
    return (
        getattr(spec, "origin", None) == expected
        and getattr(module, "__file__", None) == expected
        and type(loader) is external.SourceFileLoader
        and getattr(loader, "name", None) == name
        and getattr(loader, "path", None) == expected
        and getattr(module, "__loader__", None) is loader
    )


def _check_initial_importer_cache(*, external, zipimport):
    cache = sys.path_importer_cache
    if type(cache) is not dict or len(sys.path) != 4:
        _startup_fail("bootstrap_importer_cache_invalid")
    encodings_path = sys.path[2] + "\\encodings"
    expected_keys = {sys.path[0], sys.path[1], sys.path[2], encodings_path}
    if set(cache) != expected_keys:
        _startup_fail("bootstrap_importer_cache_invalid")
    zip_path = sys.path[0]
    zip_importer = cache[zip_path]
    try:
        sys.modules["nt"].stat(zip_path)
    except OSError:
        if zip_importer is not None:
            _startup_fail("bootstrap_importer_cache_invalid")
    else:
        if (
            type(zip_importer) is not zipimport.zipimporter
            or getattr(zip_importer, "archive", None) != zip_path
            or getattr(zip_importer, "prefix", None) != ""
        ):
            _startup_fail("bootstrap_importer_cache_invalid")
    for path in expected_keys - {zip_path}:
        if not _filefinder_is_default(cache[path], external, path):
            _startup_fail("bootstrap_importer_cache_invalid")


def _check_initial_import_state():
    """Reject any process that differs from the pinned 3.11.5 startup image."""

    frozen = sys.modules.get("_frozen_importlib")
    external = sys.modules.get("_frozen_importlib_external")
    zipimport = sys.modules.get("zipimport")
    if frozen is None or external is None or zipimport is None:
        raise RuntimeError("bootstrap_import_state_invalid")

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        _startup_fail("bootstrap_runtime_baseline_invalid")
    if type(sys.modules) is not dict or frozenset(sys.modules) != _STARTUP_MODULE_NAMES:
        _startup_fail("bootstrap_preloaded_module_set_invalid")
    for name, module in sys.modules.items():
        if not _module_matches_startup_origin(
            name,
            module,
            external=external,
            frozen=frozen,
            stdlib_root=sys.path[2],
        ):
            _startup_fail("bootstrap_preloaded_module_invalid")

    expected_meta_path = [frozen.BuiltinImporter, frozen.FrozenImporter, external.PathFinder]
    if sys.meta_path != expected_meta_path:
        raise RuntimeError("bootstrap_meta_path_invalid")

    prefix = sys.pycache_prefix
    prefix_absolute = type(prefix) is str and (
        (len(prefix) >= 3 and prefix[1] == ":" and prefix[2] in "\\/") or prefix.startswith("\\\\")
    )
    if (
        not sys.flags.isolated
        or not sys.flags.no_site
        or not sys.dont_write_bytecode
        or not prefix_absolute
    ):
        raise RuntimeError("bootstrap_interpreter_flags_invalid")
    try:
        sys.modules["nt"].stat(prefix)
    except OSError:
        pass
    else:
        _startup_fail("bootstrap_pycache_prefix_not_fresh")

    hooks = sys.path_hooks
    if len(hooks) == 2:
        hook = hooks[1]
        try:
            closure = tuple(cell.cell_contents for cell in hook.__closure__ or ())
        except (AttributeError, ValueError):
            closure = ()
        expected_loader_details = (
            (external.ExtensionFileLoader, list(external.EXTENSION_SUFFIXES)),
            (external.SourceFileLoader, list(external.SOURCE_SUFFIXES)),
            (external.SourcelessFileLoader, list(external.BYTECODE_SUFFIXES)),
        )
        hook_is_default = (
            len(closure) == 2
            and external is not None
            and closure[0] is external.FileFinder
            and type(closure[1]) is tuple
            and len(closure[1]) == len(expected_loader_details)
            and all(
                actual[0] is expected[0] and actual[1] == expected[1]
                for actual, expected in zip(closure[1], expected_loader_details)
            )
        )
    else:
        hook_is_default = False
    if (
        len(hooks) != 2
        or hooks[0] is not zipimport.zipimporter
        or getattr(hooks[1], "__module__", None) != "_frozen_importlib_external"
        or getattr(hooks[1], "__qualname__", None)
        != "FileFinder.path_hook.<locals>.path_hook_for_FileFinder"
        or not hook_is_default
    ):
        raise RuntimeError("bootstrap_path_hooks_invalid")

    _check_initial_importer_cache(external=external, zipimport=zipimport)

    blocked = ("backtrader", "backtrader_runtime", "sitecustomize", "usercustomize")
    for name in tuple(sys.modules):
        if any(name == prefix or name.startswith(prefix + ".") for prefix in blocked):
            raise RuntimeError("bootstrap_preloaded_module_invalid")
        root = name.partition(".")[0]
        if (
            root != "__main__"
            and root not in sys.stdlib_module_names
            and root not in sys.builtin_module_names
        ):
            raise RuntimeError("bootstrap_preloaded_nonstdlib_module")


_check_initial_import_state()

# Preserve the validated interpreter-owned objects before importing any helper
# modules.  The snapshots let later public calls reject replacement modules or
# importer-cache objects even after this file has loaded its stdlib helpers.
_INITIAL_MODULE_OBJECTS = dict(sys.modules)
_INITIAL_IMPORTER_CACHE = dict(sys.path_importer_cache)

import hashlib
import hmac
import importlib.abc
import importlib.machinery  # noqa: F401 - preloaded for the sealed dependency helper
import importlib.util
import ast  # noqa: F401 - preloaded for the appended captured parent launcher
import base64  # noqa: F401 - used by the fixed child bootstrap payload
import csv  # noqa: F401 - preloaded for the sealed dependency helper
import ctypes
import json
import io  # noqa: F401 - preloaded for the sealed dependency helper
import ntpath  # noqa: F401 - preloaded for the appended captured parent launcher
import os
import re
import stat
import threading  # noqa: F401 - preloaded for the sealed dependency helper
import zlib  # noqa: F401 - used by the fixed child bootstrap payload
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
from types import MappingProxyType
from typing import Mapping, Optional, Sequence


_BOOTSTRAP_MODULE_OBJECTS = dict(sys.modules)
_BOOTSTRAP_IMPORTER_CACHE = dict(sys.path_importer_cache)
_BOOTSTRAP_META_PATH = tuple(sys.meta_path)
_BOOTSTRAP_PATH_HOOKS = tuple(sys.path_hooks)
_BOOTSTRAP_PATHS = tuple(sys.path)
_BOOTSTRAP_PYCACHE_PREFIX = sys.pycache_prefix


def _path_is_beneath(path: object, root: str) -> bool:
    if type(path) is not str:
        return False
    normalized_path = os.path.normcase(os.path.abspath(path))
    normalized_root = os.path.normcase(os.path.abspath(root)).rstrip("\\/")
    return normalized_path.startswith(normalized_root + os.sep)


def _path_is_root_or_beneath(path: object, root: str) -> bool:
    if type(path) is not str:
        return False
    normalized_path = os.path.normcase(os.path.abspath(path))
    normalized_root = os.path.normcase(os.path.abspath(root)).rstrip("\\/")
    return normalized_path == normalized_root or normalized_path.startswith(
        normalized_root + os.sep
    )


def _module_has_pinned_kind(name: str, module: object) -> bool:
    """Check a post-bootstrap module's kind and origin, without trusting its name."""

    expected_module_name = _MODULE_NAME_ALIASES.get(name, name)
    if type(module) is not type(sys) or getattr(module, "__name__", None) != expected_module_name:
        return False
    spec = getattr(module, "__spec__", None)
    expected_spec_name = _MODULE_SPEC_NAME_ALIASES.get(name, name)
    if spec is None or getattr(spec, "name", None) != expected_spec_name:
        return False
    frozen = sys.modules.get("_frozen_importlib")
    external = sys.modules.get("_frozen_importlib_external")
    origin = getattr(spec, "origin", None)
    loader = getattr(spec, "loader", None)
    if origin == "built-in":
        return loader is frozen.BuiltinImporter and getattr(module, "__loader__", None) is loader
    if origin == "frozen":
        return loader is frozen.FrozenImporter and getattr(module, "__loader__", None) is loader
    root = name.partition(".")[0]
    if root not in sys.stdlib_module_names and root not in sys.builtin_module_names:
        return False
    if type(loader) is external.SourceFileLoader:
        return (
            type(origin) is str
            and origin.endswith(".py")
            and _path_is_beneath(origin, sys.path[2])
            and getattr(module, "__file__", None) == origin
            and getattr(loader, "name", None) == expected_module_name
            and getattr(loader, "path", None) == origin
            and getattr(module, "__loader__", None) is loader
        )
    zipimport = sys.modules.get("zipimport")
    if zipimport is not None and type(loader) is zipimport.zipimporter:
        archive = getattr(loader, "archive", None)
        return (
            type(origin) is str
            and type(archive) is str
            and archive in _BOOTSTRAP_PATHS
            and origin.lower().endswith(".py")
            and _path_is_beneath(origin, archive)
            and getattr(module, "__file__", None) == origin
            and getattr(module, "__loader__", None) is loader
        )
    if type(loader) is external.ExtensionFileLoader:
        return (
            type(origin) is str
            and origin.lower().endswith(".pyd")
            and any(_path_is_beneath(origin, root_path) for root_path in sys.path[1:3])
            and getattr(module, "__file__", None) == origin
            and getattr(loader, "name", None) == expected_module_name
            and getattr(loader, "path", None) == origin
            and getattr(module, "__loader__", None) is loader
        )
    return False


def _is_bootstrap_typing_alias(name: str, module: object) -> bool:
    return (
        name in {"typing.io", "typing.re"}
        and _BOOTSTRAP_MODULE_OBJECTS.get(name) is module
        and isinstance(module, type)
        and type(module).__name__ == "_DeprecatedType"
        and type(module).__module__ == "typing"
        and getattr(module, "__module__", None) == "typing"
        and getattr(module, "__name__", None) == name
    )


def _check_post_bootstrap_state(seal=None, finder=None):
    """Reject object/cache swaps after helper import and before each load."""

    if type(sys.modules) is not dict or type(sys.path_importer_cache) is not dict:
        raise SealedImportError("bootstrap_import_state_invalid")
    if tuple(sys.path) != _BOOTSTRAP_PATHS:
        raise SealedImportError("sys_path_changed")
    if (
        not sys.flags.isolated
        or not sys.flags.no_site
        or not sys.dont_write_bytecode
        or type(sys.pycache_prefix) is not str
        or not os.path.isabs(sys.pycache_prefix)
        or sys.pycache_prefix != _BOOTSTRAP_PYCACHE_PREFIX
        or os.path.exists(sys.pycache_prefix)
    ):
        raise SealedImportError("bootstrap_interpreter_flags_invalid")
    for name, module in _BOOTSTRAP_MODULE_OBJECTS.items():
        if sys.modules.get(name) is not module:
            raise SealedImportError("bootstrap_module_replaced")
    dependency_modules = tuple(
        (name, module)
        for name, module in sys.modules.items()
        if name.partition(".")[0] in _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS
    )
    dependency_finder = (
        getattr(finder, "_dependency_finder", None)
        if type(finder) is SealedSourceFinder
        else None
    )
    if dependency_modules:
        validator = getattr(dependency_finder, "validate_current", None)
        if not callable(validator):
            raise SealedImportError("bootstrap_dependency_module_invalid")
        try:
            validator()
        except BaseException:
            raise SealedImportError("bootstrap_dependency_seal_invalid") from None
    runtime_stdlib_names = tuple(
        name
        for name in sys.modules
        if type(finder) is SealedSourceFinder
        and name in finder._runtime_stdlib_entries
    )
    if runtime_stdlib_names:
        runtime_seal = finder._runtime_closure
        if runtime_seal is None or runtime_seal is not finder._runtime_closure_identity:
            raise SealedImportError("bootstrap_runtime_closure_invalid")
        validator = getattr(runtime_seal, "verify_current", None)
        if not callable(validator):
            raise SealedImportError("bootstrap_runtime_closure_invalid")
        try:
            validator()
        except BaseException:
            raise SealedImportError("bootstrap_runtime_closure_invalid") from None
    for name, module in sys.modules.items():
        if name == "__main__":
            if type(module) is not type(sys):
                raise SealedImportError("bootstrap_preloaded_module_invalid")
            continue
        if name == "backtrader" or name.startswith("backtrader."):
            raise SealedImportError("unsealed_backtrader_namespace")
        if name in {"sitecustomize", "usercustomize"}:
            raise SealedImportError("site_import_blocked")
        if name == "backtrader_runtime" or name.startswith("backtrader_runtime."):
            if seal is None or finder is None:
                raise SealedImportError("bootstrap_preloaded_module_invalid")
            if (
                type(finder) is not SealedSourceFinder
                or finder._seal is not seal
                or not finder._was_executed_or_in_progress(name, module)
            ):
                raise SealedImportError("bootstrap_runtime_module_invalid")
            module_spec = getattr(module, "__spec__", None)
            loader = getattr(module_spec, "loader", None)
            expected_relatives = {
                name.replace(".", "/") + "/__init__.py",
                name.replace(".", "/") + ".py",
            }
            if (
                type(loader) is not _SealedSourceLoader
                or loader._finder is not finder
                or loader._seal is not seal
                or loader._fullname != name
                or loader._relative not in expected_relatives
                or loader._relative not in seal.files
            ):
                raise SealedImportError("bootstrap_runtime_module_invalid")
            expected_origin = str(seal.source_root.joinpath(*PurePosixPath(loader._relative).parts))
            if getattr(module_spec, "origin", None) != expected_origin:
                raise SealedImportError("bootstrap_runtime_module_invalid")
            continue
        if name.partition(".")[0] in _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS:
            owns_module = getattr(dependency_finder, "owns_module", None)
            if not callable(owns_module):
                raise SealedImportError("bootstrap_dependency_module_invalid")
            try:
                owned = owns_module(name, module)
            except BaseException:
                owned = False
            if owned is not True:
                raise SealedImportError("bootstrap_dependency_module_invalid")
            continue
        if type(finder) is SealedSourceFinder and finder._owns_runtime_stdlib_module(
            name, module
        ):
            continue
        if type(finder) is SealedSourceFinder and finder._owns_fixed_role_module(
            name, module
        ):
            continue
        if type(finder) is SealedSourceFinder and finder._owns_fixed_bootstrap_support(
            name, module
        ):
            continue
        if _is_bootstrap_typing_alias(name, module):
            continue
        if name in _BOOTSTRAP_MODULE_OBJECTS:
            if _BOOTSTRAP_MODULE_OBJECTS[name] is not module:
                raise SealedImportError("bootstrap_module_replaced")
            if any(module is initial for initial in _INITIAL_MODULE_OBJECTS.values()):
                continue
            if not _module_has_pinned_kind(name, module):
                raise SealedImportError("bootstrap_module_origin_invalid")
            continue
        raise SealedImportError("bootstrap_module_outside_snapshot")

    cache = sys.path_importer_cache
    external = sys.modules.get("_frozen_importlib_external")
    zipimport = sys.modules.get("zipimport")
    for key, original in _BOOTSTRAP_IMPORTER_CACHE.items():
        if key not in cache or cache[key] is not original:
            raise SealedImportError("importer_cache_replaced")
    for key, importer in cache.items():
        if type(key) is not str:
            raise SealedImportError("importer_cache_invalid")
        if importer is None:
            if key != _BOOTSTRAP_PATHS[0]:
                raise SealedImportError("importer_cache_invalid")
            continue
        if type(importer) is zipimport.zipimporter:
            if key != _BOOTSTRAP_PATHS[0] or getattr(importer, "archive", None) != key:
                raise SealedImportError("importer_cache_invalid")
            continue
        if not any(_path_is_root_or_beneath(key, root_path) for root_path in _BOOTSTRAP_PATHS[1:]):
            raise SealedImportError("importer_cache_outside_stdlib")
        if not _filefinder_is_default(importer, external, key):
            raise SealedImportError("importer_cache_invalid")

    if finder is None:
        if tuple(sys.meta_path) != _BOOTSTRAP_META_PATH:
            raise SealedImportError("meta_path_changed")
    elif tuple(sys.meta_path) != (finder,) + _BOOTSTRAP_META_PATH:
        raise SealedImportError("meta_path_changed")
    if tuple(sys.path_hooks) != _BOOTSTRAP_PATH_HOOKS:
        raise SealedImportError("path_hooks_changed")


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_MAX_MANIFEST_BYTES = 1024 * 1024
_MAX_SOURCE_BYTES = 16 * 1024 * 1024
_MAX_SOURCE_FILES = 4096
_REPARSE_POINT_ATTRIBUTE = 0x400
_FILE_ATTRIBUTE_DIRECTORY = 0x10
_FILE_ATTRIBUTE_REPARSE_POINT = 0x400
_FILE_ATTRIBUTE_DEVICE = 0x40
_FILE_LIST_DIRECTORY = 0x00000001
_FILE_READ_ATTRIBUTES = 0x80
_GENERIC_READ = 0x80000000
_FILE_SHARE_READ = 0x1
_FILE_SHARE_WRITE = 0x2
_FILE_SHARE_DELETE = 0x4
_OPEN_EXISTING = 3
_FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
_FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
_FILE_ATTRIBUTE_TAG_INFO_CLASS = 9
_FILE_ID_INFO_CLASS = 18
_FILE_ID_BOTH_DIRECTORY_INFO_CLASS = 10
_FILE_ID_BOTH_DIRECTORY_RESTART_INFO_CLASS = 11
_PIN_PATHS = MappingProxyType(
    {
        "i13": "backtrader_runtime/ctp_i13_source_identity_pin.py",
        "i15": "backtrader_runtime/ctp_i15_source_identity_pin.py",
    }
)
_FIXED_READONLY_WORKER_RELATIVE_PATH = "scripts/ctp_i13_i15_readonly_preflight_worker.py"
_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
)
_FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_request_coordinator.py"
)
_FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_receipt_writer.py"
)
_FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_token_bootstrap.py"
)
# Service-role sources are fixed data, executed only from this sealed bootstrap.
# They never widen the `backtrader_runtime` import namespace.
_FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS = frozenset(
    {
        _FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH,
        _FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH,
        _FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH,
    }
)
_FIXED_READONLY_ROLE_MODULES = MappingProxyType(
    {
        "request_coordinator": (
            _FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH,
            "_i13_fixed_readonly_request_coordinator",
            "ctp_i13_i15_readonly_request_coordinator_binding.v1",
            "main",
        ),
        "receipt_writer": (
            _FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH,
            "_i13_fixed_readonly_receipt_writer",
            "ctp_i13_i15_readonly_receipt_writer_binding.v1",
            "main",
        ),
    }
)
_FIXED_READONLY_TOKEN_HELPER_MODULE = (
    _FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH,
    "_i13_fixed_readonly_token_bootstrap",
    "ctp_i13_i15_readonly_token_bootstrap.v1",
)
_FIXED_BOOTSTRAP_SUPPORT_MODULES = MappingProxyType(
    {
        "scripts/ctp_i13_i15_outer_watchdog.py": "scripts.ctp_i13_i15_outer_watchdog",
        "scripts/ctp_i13_i15_worker_output_channel.py": "scripts.ctp_i13_i15_worker_output_channel",
        "scripts/ctp_i13_i15_windows_job_backend.py": "scripts.ctp_i13_i15_windows_job_backend",
    }
)
_FIXED_BOOTSTRAP_SUPPORT_PACKAGE_ORIGIN = "<fixed-i13-bootstrap-support-package>"
_FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN = object()
_FIXED_READONLY_DATA_RELATIVE_PATHS = frozenset(
    {
        _FIXED_READONLY_WORKER_RELATIVE_PATH,
        _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH,
        *_FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS,
    }
)
_FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH = (
    "backtrader_runtime/ctp_i13_worker_dependency_seal.py"
)
_SEALED_DEPENDENCY_TOP_LEVEL_ROOTS = ("yaml", "bt_api_base", "bt_api_ctp")
_MAX_LEASE_PATHS = _MAX_SOURCE_FILES + len(_PIN_PATHS) + 1


@dataclass(frozen=True)
class CandidateSpec:
    manifest_path: str
    manifest_schema: object
    entrypoint: str
    pin_key: str


CANDIDATES = MappingProxyType(
    {
        "i13_md": CandidateSpec(
            "backtrader_runtime/ctp_i13_source_manifest.json",
            1,
            "backtrader_runtime.ctp_i13_md_oneshot_supervisor",
            "i13",
        ),
        "i15_td": CandidateSpec(
            "backtrader_runtime/ctp_i15_source_manifest.json",
            "ctp_i15_source_manifest.v2",
            "backtrader_runtime.ctp_i15_td_only_readonly",
            "i15",
        ),
    }
)


class SealedImportError(ValueError):
    """A redacted fail-closed source seal or import rejection."""


class WindowsSourceLeaseError(ValueError):
    """A Windows source lease or reopened-file identity check failed."""


_PENDING_WINDOWS_SOURCE_LEASES = []


def _remember_pending_windows_lease(lease) -> None:
    if not any(pending is lease for pending in _PENDING_WINDOWS_SOURCE_LEASES):
        _PENDING_WINDOWS_SOURCE_LEASES.append(lease)


def _forget_pending_windows_lease(lease) -> None:
    _PENDING_WINDOWS_SOURCE_LEASES[:] = [
        pending for pending in _PENDING_WINDOWS_SOURCE_LEASES if pending is not lease
    ]


class _FileAttributeTagInfo(ctypes.Structure):
    _fields_ = [("FileAttributes", wintypes.DWORD), ("ReparseTag", wintypes.DWORD)]


class _FileIdInfo(ctypes.Structure):
    _fields_ = [("VolumeSerialNumber", ctypes.c_ulonglong), ("FileId", ctypes.c_ubyte * 16)]


class _FileIdBothDirectoryInfo(ctypes.Structure):
    """Fixed prefix of FILE_ID_BOTH_DIR_INFO; FileName is variable length."""

    _fields_ = [
        ("NextEntryOffset", wintypes.DWORD),
        ("FileIndex", wintypes.DWORD),
        ("CreationTime", ctypes.c_longlong),
        ("LastAccessTime", ctypes.c_longlong),
        ("LastWriteTime", ctypes.c_longlong),
        ("ChangeTime", ctypes.c_longlong),
        ("EndOfFile", ctypes.c_longlong),
        ("AllocationSize", ctypes.c_longlong),
        ("FileAttributes", wintypes.DWORD),
        ("FileNameLength", wintypes.DWORD),
        ("EaSize", wintypes.DWORD),
        ("ShortNameLength", ctypes.c_ubyte),
        ("ShortName", wintypes.WCHAR * 12),
        ("FileId", ctypes.c_longlong),
        ("FileName", wintypes.WCHAR * 1),
    ]


@dataclass(frozen=True)
class WindowsFileIdentity:
    volume_serial: int
    file_id: bytes


@dataclass(frozen=True)
class _WindowsLeaseEntry:
    path: str
    identity: WindowsFileIdentity
    is_directory: bool
    size: Optional[int]
    handle: object


class _WindowsLeaseApi:
    def __init__(self):
        if sys.platform != "win32":
            raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        except (AttributeError, OSError):
            raise WindowsSourceLeaseError("windows_file_id_api_unavailable") from None
        kernel32.CreateFileW.argtypes = (
            wintypes.LPCWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.HANDLE,
        )
        kernel32.CreateFileW.restype = wintypes.HANDLE
        kernel32.GetFileInformationByHandleEx.argtypes = (
            wintypes.HANDLE,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
        )
        kernel32.GetFileInformationByHandleEx.restype = wintypes.BOOL
        kernel32.GetFileSizeEx.argtypes = (wintypes.HANDLE, ctypes.POINTER(ctypes.c_longlong))
        kernel32.GetFileSizeEx.restype = wintypes.BOOL
        kernel32.ReadFile.argtypes = (
            wintypes.HANDLE,
            wintypes.LPVOID,
            wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD),
            wintypes.LPVOID,
        )
        kernel32.ReadFile.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL
        self.kernel32 = kernel32

    @staticmethod
    def _invalid_handle(handle) -> bool:
        return handle is None or handle == wintypes.HANDLE(-1).value

    def open(self, path: str, *, is_directory: bool, lease: bool, read_data: bool = False):
        access = _FILE_READ_ATTRIBUTES
        if is_directory:
            access |= _FILE_LIST_DIRECTORY
        elif read_data:
            access |= _GENERIC_READ
        share = (
            _FILE_SHARE_READ if lease else _FILE_SHARE_READ | _FILE_SHARE_WRITE | _FILE_SHARE_DELETE
        )
        flags = _FILE_FLAG_OPEN_REPARSE_POINT
        if is_directory:
            flags |= _FILE_FLAG_BACKUP_SEMANTICS
        handle = self.kernel32.CreateFileW(
            path,
            access,
            share,
            None,
            _OPEN_EXISTING,
            flags,
            None,
        )
        if self._invalid_handle(handle):
            raise WindowsSourceLeaseError("source_handle_open_failed")
        return handle

    def close(self, handle) -> None:
        if not self.kernel32.CloseHandle(handle):
            raise WindowsSourceLeaseError("source_handle_close_failed")

    def attributes(self, handle) -> int:
        details = _FileAttributeTagInfo()
        if not self.kernel32.GetFileInformationByHandleEx(
            handle,
            _FILE_ATTRIBUTE_TAG_INFO_CLASS,
            ctypes.byref(details),
            ctypes.sizeof(details),
        ):
            raise WindowsSourceLeaseError("source_attributes_unavailable")
        return details.FileAttributes

    def identity(self, handle) -> WindowsFileIdentity:
        details = _FileIdInfo()
        if not self.kernel32.GetFileInformationByHandleEx(
            handle,
            _FILE_ID_INFO_CLASS,
            ctypes.byref(details),
            ctypes.sizeof(details),
        ):
            raise WindowsSourceLeaseError("source_file_id_unavailable")
        return WindowsFileIdentity(
            volume_serial=int(details.VolumeSerialNumber),
            file_id=bytes(details.FileId),
        )

    def size(self, handle) -> int:
        value = ctypes.c_longlong()
        if not self.kernel32.GetFileSizeEx(handle, ctypes.byref(value)):
            raise WindowsSourceLeaseError("source_size_unavailable")
        if value.value < 0:
            raise WindowsSourceLeaseError("source_size_invalid")
        return int(value.value)

    def read(self, handle, size: int) -> bytes:
        result = bytearray()
        while len(result) < size:
            requested = min(64 * 1024, size - len(result))
            buffer = ctypes.create_string_buffer(requested)
            received = wintypes.DWORD()
            if not self.kernel32.ReadFile(
                handle,
                buffer,
                requested,
                ctypes.byref(received),
                None,
            ):
                raise WindowsSourceLeaseError("source_read_failed")
            if received.value == 0:
                break
            result.extend(buffer.raw[: received.value])
        return bytes(result)

    def list_directory(self, handle) -> tuple[str, ...]:
        """Enumerate names from the retained directory handle only."""

        attributes = self.attributes(handle)
        if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
            raise WindowsSourceLeaseError("source_path_reparse_point")
        if not attributes & _FILE_ATTRIBUTE_DIRECTORY:
            raise WindowsSourceLeaseError("source_directory_not_leased")
        identity_before = self.identity(handle)
        buffer_size = 64 * 1024
        buffer = ctypes.create_string_buffer(buffer_size)
        names = []
        information_class = _FILE_ID_BOTH_DIRECTORY_RESTART_INFO_CLASS
        while True:
            succeeded = self.kernel32.GetFileInformationByHandleEx(
                handle,
                information_class,
                buffer,
                buffer_size,
            )
            information_class = _FILE_ID_BOTH_DIRECTORY_INFO_CLASS
            if not succeeded:
                error = ctypes.get_last_error()
                if error == 18:  # ERROR_NO_MORE_FILES
                    break
                raise WindowsSourceLeaseError("source_directory_read_failed")

            offset = 0
            while True:
                if offset < 0 or offset + ctypes.sizeof(_FileIdBothDirectoryInfo) > buffer_size:
                    raise WindowsSourceLeaseError("source_directory_buffer_invalid")
                row = _FileIdBothDirectoryInfo.from_buffer(buffer, offset)
                name_length = int(row.FileNameLength)
                name_offset = offset + _FileIdBothDirectoryInfo.FileName.offset
                if (
                    name_length <= 0
                    or name_length % 2
                    or name_offset + name_length > buffer_size
                    or row.FileAttributes & (_FILE_ATTRIBUTE_REPARSE_POINT | _FILE_ATTRIBUTE_DEVICE)
                ):
                    raise WindowsSourceLeaseError("source_directory_entry_invalid")
                raw_name = ctypes.string_at(ctypes.addressof(buffer) + name_offset, name_length)
                try:
                    name = raw_name.decode("utf-16-le", "strict")
                except UnicodeError:
                    raise WindowsSourceLeaseError("source_directory_entry_invalid") from None
                if (
                    not name
                    or "/" in name
                    or "\\" in name
                    or ":" in name
                    or "\x00" in name
                ):
                    raise WindowsSourceLeaseError("source_directory_entry_invalid")
                if name in {".", ".."}:
                    if not row.FileAttributes & _FILE_ATTRIBUTE_DIRECTORY:
                        raise WindowsSourceLeaseError("source_directory_entry_invalid")
                else:
                    names.append(name)
                    if len(names) > 100_000:
                        raise WindowsSourceLeaseError("source_directory_entry_limit")
                next_offset = int(row.NextEntryOffset)
                if next_offset == 0:
                    break
                if (
                    next_offset % 8
                    or next_offset < _FileIdBothDirectoryInfo.FileName.offset + name_length
                    or offset + next_offset + ctypes.sizeof(_FileIdBothDirectoryInfo) > buffer_size
                ):
                    raise WindowsSourceLeaseError("source_directory_buffer_invalid")
                offset += next_offset
        if self.identity(handle) != identity_before:
            raise WindowsSourceLeaseError("source_file_identity_mismatch")
        folded = [name.casefold() for name in names]
        if len(folded) != len(set(folded)):
            raise WindowsSourceLeaseError("source_directory_case_collision")
        return tuple(names)


def _canonical_windows_absolute_path(value: object) -> str:
    try:
        raw = os.fspath(value)
    except TypeError:
        raise WindowsSourceLeaseError("source_path_invalid") from None
    if type(raw) is not str or not raw or sys.platform != "win32":
        raise WindowsSourceLeaseError("source_path_invalid")
    raw = raw.replace("/", "\\")
    if (
        len(raw) < 3
        or not raw[0].isalpha()
        or raw[1:3] != ":\\"
        or raw.startswith("\\\\")
        or any(part in {".", ".."} for part in raw[3:].split("\\") if part)
        or ":" in raw[3:]
        or any(char in raw for char in '*?"<>|')
    ):
        raise WindowsSourceLeaseError("source_path_invalid")
    for component in raw[3:].split("\\"):
        if not component:
            continue
        stem = component.split(".", 1)[0].rstrip(" .").casefold()
        if (
            component.endswith((".", " "))
            or stem in {"con", "prn", "aux", "nul"}
            or (len(stem) == 4 and stem[:3] in {"com", "lpt"} and stem[3] in "123456789")
        ):
            raise WindowsSourceLeaseError("source_path_invalid")
    normalized = os.path.normpath(os.path.abspath(raw))
    if not os.path.isabs(normalized) or len(normalized) > 32767:
        raise WindowsSourceLeaseError("source_path_invalid")
    return normalized


def _windows_path_components(path: str, *, final_is_directory: bool):
    parts = PureWindowsPath(path).parts
    if not parts or not parts[0].endswith("\\"):
        raise WindowsSourceLeaseError("source_path_invalid")
    current = PureWindowsPath(parts[0])
    yield str(current), True
    for index, part in enumerate(parts[1:]):
        current = current / part
        last = index == len(parts) - 2
        yield str(current), final_is_directory if last else True


def _lease_relative_parts(relative: object) -> tuple[str, ...]:
    if type(relative) is not str or not relative or "\\" in relative:
        raise WindowsSourceLeaseError("source_relative_path_invalid")
    path = PurePosixPath(relative)
    if (
        path.is_absolute()
        or path.as_posix() != relative
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise WindowsSourceLeaseError("source_relative_path_invalid")
    return path.parts


class WindowsSourceLease:
    """Hold path handles and read only matching file IDs and source bytes.

    ``SealedSourceTree`` retains this lease and its loader reads exact verified
    bytes through it. Every path component is opened without following its
    final reparse point; retained handles use a read-only share mask. Windows
    still permits directory attribute handles, so this is not a general path
    immutability claim. A failed close poisons the lease and preserves the
    handle for explicit retry.
    """

    def __init__(self, root: str, api: _WindowsLeaseApi):
        self.root = root
        self._api = api
        self._entries = {}
        self._handles = []
        self._closed = False
        self._poisoned = False

    @classmethod
    def acquire(cls, source_root: object, relative_paths: Sequence[str]):
        if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
            raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
        root = _canonical_windows_absolute_path(source_root)
        if type(relative_paths) not in (tuple, list) or not relative_paths:
            raise WindowsSourceLeaseError("source_lease_paths_invalid")
        if len(relative_paths) > _MAX_LEASE_PATHS:
            raise WindowsSourceLeaseError("source_lease_paths_invalid")
        relative_parts = [_lease_relative_parts(value) for value in relative_paths]
        target_keys = {
            os.path.normcase(os.path.normpath(str(PureWindowsPath(root).joinpath(*parts))))
            for parts in relative_parts
        }
        if len(target_keys) != len(relative_parts):
            raise WindowsSourceLeaseError("source_lease_paths_invalid")
        api = _WindowsLeaseApi()
        lease = cls(root, api)
        try:
            lease._retain_path(root, final_is_directory=True)
            for parts in relative_parts:
                target = str(PureWindowsPath(root).joinpath(*parts))
                lease._retain_path(target, final_is_directory=False)
            return lease
        except BaseException:
            try:
                lease.close()
            except WindowsSourceLeaseError:
                raise WindowsSourceLeaseError("source_lease_acquire_cleanup_failed") from None
            raise

    def _retain_path(self, path: str, *, final_is_directory: bool) -> None:
        for component, is_directory in _windows_path_components(
            path, final_is_directory=final_is_directory
        ):
            key = os.path.normcase(os.path.normpath(component))
            existing = self._entries.get(key)
            if existing is not None:
                if existing.is_directory != is_directory:
                    raise WindowsSourceLeaseError("source_path_kind_conflict")
                continue
            handle = self._api.open(
                component,
                is_directory=is_directory,
                lease=True,
                read_data=not is_directory,
            )
            self._handles.append(handle)
            attributes = self._api.attributes(handle)
            if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
                raise WindowsSourceLeaseError("source_path_reparse_point")
            if bool(attributes & _FILE_ATTRIBUTE_DIRECTORY) != is_directory:
                raise WindowsSourceLeaseError("source_path_kind_invalid")
            identity = self._api.identity(handle)
            size = None if is_directory else self._api.size(handle)
            entry = _WindowsLeaseEntry(component, identity, is_directory, size, handle)
            self._entries[key] = entry

    def _close_tracked_handle(self, handle) -> None:
        if not any(current == handle for current in self._handles):
            return
        try:
            self._api.close(handle)
        except Exception:
            self._poisoned = True
            _remember_pending_windows_lease(self)
            raise WindowsSourceLeaseError("source_handle_close_failed") from None
        self._handles[:] = [current for current in self._handles if current != handle]

    def _open_verified_path(
        self, path: object, expected: _WindowsLeaseEntry, *, read_data: bool = False
    ):
        if self._closed or self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        canonical = _canonical_windows_absolute_path(path)
        handle = self._api.open(
            canonical,
            is_directory=expected.is_directory,
            lease=False,
            read_data=read_data,
        )
        self._handles.append(handle)
        try:
            attributes = self._api.attributes(handle)
            if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
                raise WindowsSourceLeaseError("source_path_reparse_point")
            if bool(attributes & _FILE_ATTRIBUTE_DIRECTORY) != expected.is_directory:
                raise WindowsSourceLeaseError("source_path_kind_invalid")
            if self._api.identity(handle) != expected.identity:
                raise WindowsSourceLeaseError("source_file_identity_mismatch")
            if read_data and not expected.is_directory and self._api.size(handle) != expected.size:
                raise WindowsSourceLeaseError("source_size_changed")
            return handle
        except BaseException:
            self._close_tracked_handle(handle)
            raise

    def read_source(self, relative: str, *, expected_sha256: str) -> bytes:
        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        expected = _sha256(expected_sha256, "source_digest_invalid")
        parts = _lease_relative_parts(relative)
        target = str(PureWindowsPath(self.root).joinpath(*parts))
        components = list(_windows_path_components(target, final_is_directory=False))
        reopened_file = None
        try:
            for component, is_directory in components:
                key = os.path.normcase(os.path.normpath(component))
                entry = self._entries.get(key)
                if entry is None or entry.is_directory != is_directory:
                    raise WindowsSourceLeaseError("source_path_not_leased")
                handle = self._open_verified_path(component, entry, read_data=not is_directory)
                if is_directory:
                    self._close_tracked_handle(handle)
                else:
                    reopened_file = (handle, entry)
            if reopened_file is None:
                raise WindowsSourceLeaseError("source_file_not_leased")
            handle, entry = reopened_file
            if entry.size is None or entry.size > _MAX_SOURCE_BYTES:
                raise WindowsSourceLeaseError("source_size_invalid")
            content = self._api.read(handle, entry.size)
            if (
                len(content) != entry.size
                or self._api.identity(handle) != entry.identity
                or self._api.size(handle) != entry.size
                or not hmac.compare_digest(hashlib.sha256(content).hexdigest(), expected)
            ):
                raise WindowsSourceLeaseError("source_content_changed")
            return content
        finally:
            if reopened_file is not None:
                self._close_tracked_handle(reopened_file[0])

    def list_directory(self, relative: str) -> tuple[str, ...]:
        """List one retained directory while checking its held file identity.

        This narrow API supports exact installed-dependency inventory checks.
        The directory and its ancestors are already held by the lease with a
        share mask that denies concurrent write/delete opens. Enumeration is
        performed through that retained handle, with the file ID compared
        before and after. Reparse entries are rejected. It accepts no absolute
        or caller-selected root path.
        """

        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        parts = _lease_relative_parts(relative)
        target = str(PureWindowsPath(self.root).joinpath(*parts))
        key = os.path.normcase(os.path.normpath(target))
        expected = self._entries.get(key)
        if expected is None or not expected.is_directory:
            raise WindowsSourceLeaseError("source_directory_not_leased")

        if self._api.identity(expected.handle) != expected.identity:
            raise WindowsSourceLeaseError("source_file_identity_mismatch")
        attributes = self._api.attributes(expected.handle)
        if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
            raise WindowsSourceLeaseError("source_path_reparse_point")
        names = self._api.list_directory(expected.handle)
        if self._api.identity(expected.handle) != expected.identity:
            raise WindowsSourceLeaseError("source_file_identity_mismatch")
        folded = [name.casefold() for name in names]
        if len(folded) != len(set(folded)):
            raise WindowsSourceLeaseError("source_directory_case_collision")
        return tuple(names)

    def verify_current(self) -> None:
        """Reopen every retained file/directory and verify its identity/size."""

        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        for entry in tuple(self._entries.values()):
            handle = self._open_verified_path(
                entry.path,
                entry,
                read_data=not entry.is_directory,
            )
            self._close_tracked_handle(handle)

    def close(self) -> None:
        if self._closed:
            return
        remaining = []
        for handle in reversed(tuple(self._handles)):
            try:
                self._api.close(handle)
            except Exception:
                remaining.append(handle)
        self._handles[:] = list(reversed(remaining))
        if self._handles:
            self._poisoned = True
            _remember_pending_windows_lease(self)
            raise WindowsSourceLeaseError("source_lease_close_failed")
        self._closed = True
        self._poisoned = False
        _forget_pending_windows_lease(self)

    def __enter__(self):
        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()


def acquire_windows_source_lease(source_root: object, relative_paths: Sequence[str]):
    """Acquire a Windows deny-write/delete lease for exact relative paths."""

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
    return WindowsSourceLease.acquire(source_root, relative_paths)


def retry_pending_windows_source_lease_cleanup() -> None:
    """Retry close for lease objects retained after a failed handle close."""

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
    failed = False
    for lease in tuple(_PENDING_WINDOWS_SOURCE_LEASES):
        try:
            lease.close()
        except WindowsSourceLeaseError:
            failed = True
    if failed:
        raise WindowsSourceLeaseError("source_lease_cleanup_pending")


@dataclass(frozen=True)
class SealedSourceTree:
    candidate: str
    source_root: Path
    manifest_sha256: str
    files: Mapping[str, str]
    stdlib_paths: tuple[str, ...]
    source_lease: WindowsSourceLease

    @property
    def worker_sha256(self) -> str:
        """Return the pinned digest for the one fixed read-only worker source."""

        _require_source_lease(self)
        if self.candidate != "i13_md":
            raise SealedImportError("readonly_worker_source_unpinned")
        digest = self.files.get(_FIXED_READONLY_WORKER_RELATIVE_PATH)
        if digest is None:
            raise SealedImportError("readonly_worker_source_unpinned")
        return _sha256(digest, "readonly_worker_source_unpinned")

    def read_worker_source(self) -> bytes:
        """Read only the fixed worker bytes through the retained hash-bound lease."""

        digest = self.worker_sha256
        lease = _require_source_lease(self)
        try:
            return lease.read_source(
                _FIXED_READONLY_WORKER_RELATIVE_PATH,
                expected_sha256=digest,
            )
        except WindowsSourceLeaseError as error:
            raise SealedImportError("readonly_worker_source_unavailable") from error

    @property
    def bootstrap_sha256(self) -> str:
        """Return the pinned digest for the one fixed child bootstrap artifact."""

        _require_source_lease(self)
        if self.candidate != "i13_md":
            raise SealedImportError("readonly_bootstrap_source_unpinned")
        digest = self.files.get(_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH)
        if digest is None:
            raise SealedImportError("readonly_bootstrap_source_unpinned")
        return _sha256(digest, "readonly_bootstrap_source_unpinned")

    def read_bootstrap_source(self) -> bytes:
        """Read the fixed child bootstrap through the retained hash-bound lease."""

        digest = self.bootstrap_sha256
        lease = _require_source_lease(self)
        try:
            return lease.read_source(
                _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH,
                expected_sha256=digest,
            )
        except WindowsSourceLeaseError as error:
            raise SealedImportError("readonly_bootstrap_source_unavailable") from error

    def read_request_coordinator_source(self) -> bytes:
        """Read only the fixed service coordinator bytes through the source lease."""

        return self._read_fixed_readonly_source(
            _FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH,
            "readonly_request_coordinator_source_unpinned",
            "readonly_request_coordinator_source_unavailable",
        )

    def read_receipt_writer_source(self) -> bytes:
        """Read only the fixed service receipt-writer bytes through the source lease."""

        return self._read_fixed_readonly_source(
            _FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH,
            "readonly_receipt_writer_source_unpinned",
            "readonly_receipt_writer_source_unavailable",
        )

    def read_token_bootstrap_source(self) -> bytes:
        """Read only the fixed token-bootstrap bytes through the source lease."""

        return self._read_fixed_readonly_source(
            _FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH,
            "readonly_token_bootstrap_source_unpinned",
            "readonly_token_bootstrap_source_unavailable",
        )

    def _read_fixed_readonly_source(
        self, relative_path: str, missing_reason: str, read_reason: str
    ) -> bytes:
        _require_source_lease(self)
        if self.candidate != "i13_md" or relative_path not in _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS:
            raise SealedImportError(missing_reason)
        digest = self.files.get(relative_path)
        if digest is None:
            raise SealedImportError(missing_reason)
        try:
            return self.source_lease.read_source(relative_path, expected_sha256=digest)
        except WindowsSourceLeaseError as error:
            raise SealedImportError(read_reason) from error

    def close(self) -> None:
        self.source_lease.close()

    def __enter__(self):
        _require_source_lease(self)
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()


def _candidate_spec(candidate: object) -> CandidateSpec:
    if type(candidate) is not str or candidate not in CANDIDATES:
        raise SealedImportError("candidate_invalid")
    return CANDIDATES[candidate]


def _require_source_lease(seal: SealedSourceTree) -> WindowsSourceLease:
    if (
        type(seal) is not SealedSourceTree
        or sys.platform != "win32"
        or sys.version_info[:3] != (3, 11, 5)
    ):
        raise SealedImportError("windows_source_lease_required")
    lease = seal.source_lease
    if (
        type(lease) is not WindowsSourceLease
        or type(lease._api) is not _WindowsLeaseApi
        or lease._closed
        or lease._poisoned
        or type(lease._handles) is not list
        or not lease._handles
        or type(lease._entries) is not dict
        or type(seal.files) is not type(MappingProxyType({}))
    ):
        raise SealedImportError("source_lease_unavailable")
    try:
        root = _canonical_windows_absolute_path(seal.source_root)
        spec = _candidate_spec(seal.candidate)
        relative_paths = (spec.manifest_path,) + tuple(seal.files)
        for relative in relative_paths:
            parts = _lease_relative_parts(relative)
            path = str(PureWindowsPath(root).joinpath(*parts))
            key = os.path.normcase(os.path.normpath(path))
            entry = lease._entries.get(key)
            if entry is None or entry.is_directory or entry.size is None:
                raise SealedImportError("source_lease_unavailable")
    except (AttributeError, TypeError, WindowsSourceLeaseError):
        raise SealedImportError("source_lease_unavailable") from None
    if lease.root != root or seal.source_root != Path(root):
        raise SealedImportError("source_lease_root_mismatch")
    return lease


def _sha256(value: object, reason: str) -> str:
    if type(value) is not str or not _SHA256_RE.fullmatch(value) or value == "0" * 64:
        raise SealedImportError(reason)
    return value


def _reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise SealedImportError("manifest_duplicate_key")
        result[key] = value
    return result


def _safe_source_path(value: object) -> str:
    if type(value) is not str or not value or "\\" in value:
        raise SealedImportError("manifest_path_invalid")
    path = PurePosixPath(value)
    if (
        path.is_absolute()
        or path.as_posix() != value
        or path.suffix != ".py"
        or len(path.parts) < 2
        or path.parts[0] != "backtrader_runtime"
        or any(part in {"", ".", ".."} for part in path.parts)
        or value in _PIN_PATHS.values()
    ):
        raise SealedImportError("manifest_path_invalid")
    return value


def _safe_i13_manifest_path(value: object) -> str:
    """Accept runtime imports plus the exact fixed worker/bootstrap data paths."""

    if value in _FIXED_READONLY_DATA_RELATIVE_PATHS:
        return value
    return _safe_source_path(value)


def parse_candidate_manifest(
    candidate: object,
    raw: bytes,
    *,
    expected_manifest_sha256: object,
) -> Mapping[str, str]:
    """Parse and pin the existing candidate-specific manifest format.

    I13 uses schema 1 with a sorted ``source_files`` mapping. I15 uses its
    versioned schema with sorted ``files`` rows. Both encodings must be strict
    canonical JSON and contain only lower-case SHA-256 values.
    """

    spec = _candidate_spec(candidate)
    expected = _sha256(expected_manifest_sha256, "manifest_pin_unset")
    if type(raw) is not bytes or not raw or len(raw) > _MAX_MANIFEST_BYTES:
        raise SealedImportError("manifest_invalid")
    actual = hashlib.sha256(raw).hexdigest()
    if not hmac.compare_digest(actual, expected):
        raise SealedImportError("manifest_digest_mismatch")
    try:
        parsed = json.loads(raw.decode("utf-8"), object_pairs_hook=_reject_duplicate_keys)
    except SealedImportError:
        raise
    except (UnicodeError, ValueError, TypeError):
        raise SealedImportError("manifest_invalid") from None

    files = {}
    if candidate == "i13_md":
        if type(parsed) is not dict or set(parsed) != {"schema", "source_files"}:
            raise SealedImportError("manifest_invalid")
        if type(parsed["schema"]) is not int or parsed["schema"] != spec.manifest_schema:
            raise SealedImportError("manifest_invalid")
        rows = parsed["source_files"]
        if type(rows) is not dict or not 1 <= len(rows) <= _MAX_SOURCE_FILES:
            raise SealedImportError("manifest_invalid")
        if list(rows) != sorted(rows):
            raise SealedImportError("manifest_order_invalid")
        for path, digest in rows.items():
            files[_safe_i13_manifest_path(path)] = _sha256(digest, "manifest_invalid")
        if (
            _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH in files
            and _FIXED_READONLY_WORKER_RELATIVE_PATH not in files
        ):
            raise SealedImportError("readonly_worker_source_unpinned")
        if (
            _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH in files
            and _FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH not in files
        ):
            raise SealedImportError("readonly_dependency_helper_unpinned")
        service_role_paths = files.keys() & _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS
        if service_role_paths and service_role_paths != _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS:
            raise SealedImportError("readonly_service_role_sources_incomplete")
        if service_role_paths and (
            _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH not in files
            or _FIXED_READONLY_WORKER_RELATIVE_PATH not in files
            or _FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH not in files
        ):
            raise SealedImportError("readonly_service_role_bootstrap_unpinned")
        canonical_value = {"schema": 1, "source_files": files}
    else:
        if type(parsed) is not dict or set(parsed) != {"files", "schema"}:
            raise SealedImportError("manifest_invalid")
        if parsed["schema"] != spec.manifest_schema:
            raise SealedImportError("manifest_invalid")
        rows = parsed["files"]
        if type(rows) is not list or not 1 <= len(rows) <= _MAX_SOURCE_FILES:
            raise SealedImportError("manifest_invalid")
        previous = None
        for row in rows:
            if type(row) is not dict or set(row) != {"path", "sha256"}:
                raise SealedImportError("manifest_invalid")
            path = _safe_source_path(row["path"])
            digest = _sha256(row["sha256"], "manifest_invalid")
            if path in files:
                raise SealedImportError("manifest_duplicate_path")
            if previous is not None and path <= previous:
                raise SealedImportError("manifest_order_invalid")
            previous = path
            files[path] = digest
        canonical_value = {
            "files": [{"path": path, "sha256": digest} for path, digest in files.items()],
            "schema": spec.manifest_schema,
        }

    if not files:
        raise SealedImportError("manifest_invalid")
    if "backtrader_runtime/__init__.py" not in files:
        raise SealedImportError("runtime_package_init_unpinned")
    if spec.entrypoint.replace(".", "/") + ".py" not in files:
        raise SealedImportError("candidate_entrypoint_unpinned")
    canonical = json.dumps(
        canonical_value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")
    if raw != canonical:
        raise SealedImportError("manifest_not_canonical")
    return MappingProxyType(files)


def _has_reparse_point(details: os.stat_result) -> bool:
    return stat.S_ISLNK(details.st_mode) or bool(
        getattr(details, "st_file_attributes", 0) & _REPARSE_POINT_ATTRIBUTE
    )


def _assert_path_components(path: Path, *, final_kind: Optional[str] = None) -> None:
    if not path.is_absolute():
        raise SealedImportError("path_not_absolute")
    anchor = Path(path.anchor)
    current = anchor
    relative = path.parts[1:] if path.anchor else path.parts
    for index, part in enumerate(relative):
        current = current / part
        try:
            details = os.lstat(current)
        except OSError:
            raise SealedImportError("path_component_unavailable") from None
        if _has_reparse_point(details):
            raise SealedImportError("path_reparse_point")
        if index < len(relative) - 1 and not stat.S_ISDIR(details.st_mode):
            raise SealedImportError("path_parent_not_directory")
    if final_kind == "directory" and not stat.S_ISDIR(os.lstat(path).st_mode):
        raise SealedImportError("path_not_directory")
    if final_kind == "file" and not stat.S_ISREG(os.lstat(path).st_mode):
        raise SealedImportError("path_not_regular_file")


def _checked_read(root: Path, relative: str) -> bytes:
    if relative in _PIN_PATHS.values():
        safe = relative
    else:
        safe = _safe_source_path(relative) if relative.endswith(".py") else relative
    if type(safe) is not str or "\\" in safe:
        raise SealedImportError("source_path_invalid")
    parts = PurePosixPath(safe).parts
    if PurePosixPath(safe).is_absolute() or any(part in {"", ".", ".."} for part in parts):
        raise SealedImportError("source_path_invalid")
    current = root
    try:
        root_stat = os.lstat(root)
    except OSError:
        raise SealedImportError("source_root_unavailable") from None
    if _has_reparse_point(root_stat) or not stat.S_ISDIR(root_stat.st_mode):
        raise SealedImportError("source_root_invalid")
    for index, component in enumerate(parts):
        current = current / component
        try:
            before = os.lstat(current)
        except OSError:
            raise SealedImportError("source_file_unavailable") from None
        if _has_reparse_point(before):
            raise SealedImportError("source_path_reparse_point")
        final = index == len(parts) - 1
        if not final:
            if not stat.S_ISDIR(before.st_mode):
                raise SealedImportError("source_parent_not_directory")
            continue
        if not stat.S_ISREG(before.st_mode):
            raise SealedImportError("source_not_regular_file")
        try:
            with open(current, "rb") as stream:
                content = stream.read(_MAX_SOURCE_BYTES + 1)
            after = os.lstat(current)
        except OSError:
            raise SealedImportError("source_file_unavailable") from None
        if (
            _has_reparse_point(after)
            or not stat.S_ISREG(after.st_mode)
            or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or len(content) != after.st_size
            or len(content) > _MAX_SOURCE_BYTES
        ):
            raise SealedImportError("source_changed_during_read")
        return content
    raise SealedImportError("source_file_unavailable")


def _pyc_source_for_relative(relative: str) -> Optional[str]:
    path = PurePosixPath(relative)
    parts = path.parts
    if "__pycache__" not in parts:
        return None
    index = parts.index("__pycache__")
    if index != len(parts) - 2 or index == 0:
        raise SealedImportError("pyc_cache_layout_invalid")
    name = parts[-1]
    match = re.fullmatch(r"(.+)\.([A-Za-z0-9_-]+)\.pyc", name)
    if match is None or match.group(2) in {"", "py"}:
        raise SealedImportError("pyc_cache_layout_invalid")
    source_parts = parts[:index] + (match.group(1) + ".py",)
    return PurePosixPath(*source_parts).as_posix()


def _scan_source_inventory(
    package_root: Path,
    manifest_path: str,
    *,
    include_readonly_worker: bool = False,
    include_readonly_bootstrap: bool = False,
    include_readonly_service_roles: bool = False,
) -> set[str]:
    python_files = set()
    pyc_sources = set()
    stack = [(package_root, "backtrader_runtime")]
    while stack:
        directory, relative_directory = stack.pop()
        directory_parts = PurePosixPath(relative_directory).parts
        if "__pycache__" in directory_parts and directory_parts[-1] != "__pycache__":
            raise SealedImportError("pyc_cache_layout_invalid")
        try:
            with os.scandir(directory) as iterator:
                entries = sorted(iterator, key=lambda entry: entry.name)
        except OSError:
            raise SealedImportError("source_directory_unavailable") from None
        for entry in entries:
            relative = relative_directory + "/" + entry.name
            try:
                details = entry.stat(follow_symlinks=False)
            except OSError:
                raise SealedImportError("source_entry_unavailable") from None
            if _has_reparse_point(details):
                raise SealedImportError("source_tree_reparse_point")
            if stat.S_ISDIR(details.st_mode):
                stack.append((Path(entry.path), relative))
                continue
            if not stat.S_ISREG(details.st_mode):
                raise SealedImportError("source_entry_not_regular")
            lowered = entry.name.casefold()
            if lowered.endswith((".pyd", ".so", ".dll", ".dylib", ".pyo")):
                raise SealedImportError("source_native_artifact_invalid")
            if lowered.endswith(".pyc"):
                source = _pyc_source_for_relative(relative)
                if source is None:
                    raise SealedImportError("pyc_cache_layout_invalid")
                pyc_sources.add(source)
                continue
            if entry.name.endswith(".py"):
                python_files.add(relative)
            elif lowered.endswith(".py"):
                raise SealedImportError("source_python_suffix_invalid")
            elif entry.name.lower().endswith(".json") and relative == manifest_path:
                continue
    if not pyc_sources.issubset(python_files):
        raise SealedImportError("pyc_cache_source_missing")
    if include_readonly_worker:
        worker_path = package_root.parent.joinpath(*_FIXED_READONLY_WORKER_RELATIVE_PATH.split("/"))
        _assert_path_components(worker_path, final_kind="file")
        python_files.add(_FIXED_READONLY_WORKER_RELATIVE_PATH)
    if include_readonly_bootstrap:
        bootstrap_path = package_root.parent.joinpath(
            *_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH.split("/")
        )
        _assert_path_components(bootstrap_path, final_kind="file")
        python_files.add(_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH)
    if include_readonly_service_roles:
        for relative in sorted(_FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS):
            service_path = package_root.parent.joinpath(*relative.split("/"))
            _assert_path_components(service_path, final_kind="file")
            python_files.add(relative)
    return python_files


def validate_stdlib_roots(expected_stdlib_paths: Sequence[str]) -> tuple[str, ...]:
    if type(expected_stdlib_paths) not in (tuple, list) or not expected_stdlib_paths:
        raise SealedImportError("stdlib_roots_unset")
    normalized = []
    for value in expected_stdlib_paths:
        if type(value) is not str or not os.path.isabs(value):
            raise SealedImportError("stdlib_root_invalid")
        canonical = os.path.normcase(os.path.abspath(value))
        if any(piece in canonical.casefold() for piece in ("site-packages", "appdata")):
            raise SealedImportError("stdlib_root_invalid")
        if canonical in normalized:
            raise SealedImportError("stdlib_root_duplicate")
        if os.path.exists(value):
            _assert_path_components(Path(value))
        normalized.append(canonical)
    current = tuple(os.path.normcase(os.path.abspath(value)) for value in sys.path)
    if any(
        type(value) is not str
        or not value
        or os.path.normcase(os.path.abspath(value)) not in normalized
        for value in sys.path
    ):
        raise SealedImportError("sys_path_outside_stdlib_roots")
    if len(current) != len(normalized) or set(current) != set(normalized):
        raise SealedImportError("sys_path_stdlib_mismatch")
    return tuple(current)


def validate_fixed_venv_binding(
    *,
    venv_root: str,
    python_executable: str,
    python_sha256: str,
    python_version: str,
    venv_home: str,
    actual_executable: Optional[str] = None,
    actual_version: Optional[str] = None,
) -> None:
    """Validate the exact -S venv facts supplied by an external descriptor.

    This pure validation helper does not make its arguments trusted. The
    descriptor and its digest must be anchored outside the checkout.
    """

    for value in (venv_root, python_executable, venv_home):
        if type(value) is not str or not os.path.isabs(value):
            raise SealedImportError("venv_binding_invalid")
    expected_python_hash = _sha256(python_sha256, "venv_python_pin_invalid")
    if type(python_version) is not str or not re.fullmatch(r"3\.11\.5", python_version):
        raise SealedImportError("venv_version_pin_invalid")
    root = Path(venv_root)
    executable = Path(python_executable)
    home = Path(venv_home)
    if os.name == "nt":
        expected_executable = root / "Scripts" / "python.exe"
    else:
        expected_executable = root / "bin" / "python"

    def norm(value):
        return os.path.normcase(os.path.abspath(str(value)))

    if norm(executable) != norm(expected_executable):
        raise SealedImportError("venv_executable_path_mismatch")
    running_executable = actual_executable if actual_executable is not None else sys.executable
    if norm(running_executable) != norm(executable):
        raise SealedImportError("venv_running_executable_mismatch")
    running_version = (
        actual_version if actual_version is not None else ".".join(map(str, sys.version_info[:3]))
    )
    if running_version != python_version:
        raise SealedImportError("venv_running_version_mismatch")

    _assert_path_components(root, final_kind="directory")
    _assert_path_components(home, final_kind="directory")
    _assert_path_components(executable, final_kind="file")
    cfg_path = root / "pyvenv.cfg"
    _assert_path_components(cfg_path, final_kind="file")
    try:
        raw_cfg = cfg_path.read_bytes()
    except OSError:
        raise SealedImportError("venv_config_unavailable") from None
    if len(raw_cfg) > 16 * 1024:
        raise SealedImportError("venv_config_invalid")
    config = {}
    try:
        for line in raw_cfg.decode("utf-8").splitlines():
            if not line.strip():
                continue
            key, separator, value = line.partition("=")
            if not separator:
                raise SealedImportError("venv_config_invalid")
            key = key.strip().casefold()
            value = value.strip()
            if key in config:
                raise SealedImportError("venv_config_duplicate_key")
            config[key] = value
    except UnicodeError:
        raise SealedImportError("venv_config_invalid") from None
    if (
        config.get("include-system-site-packages", "").casefold() != "false"
        or norm(config.get("home", "")) != norm(home)
        or config.get("version") != python_version
    ):
        raise SealedImportError("venv_config_binding_mismatch")
    try:
        executable_bytes = executable.read_bytes()
    except OSError:
        raise SealedImportError("venv_python_unavailable") from None
    if not hmac.compare_digest(hashlib.sha256(executable_bytes).hexdigest(), expected_python_hash):
        raise SealedImportError("venv_python_digest_mismatch")


def seal_candidate_source_tree(
    candidate: object,
    source_root: str | Path,
    *,
    expected_manifest_sha256: object,
    expected_pin_sha256s: Mapping[str, str],
    stdlib_paths: Sequence[str],
) -> SealedSourceTree:
    """Seal source bytes with retained Windows file-ID handles and hashes.

    The external manifest digest is checked before acquiring the lease. The
    manifest and every listed/pinned source are then reopened through the lease
    and revalidated before the returned tree can be installed or imported.
    The caller owns the returned lease and must close the tree explicitly.
    """

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        raise SealedImportError("windows_source_lease_required")
    spec = _candidate_spec(candidate)
    try:
        root = Path(_canonical_windows_absolute_path(source_root))
    except WindowsSourceLeaseError:
        raise SealedImportError("source_root_invalid") from None
    _assert_path_components(root, final_kind="directory")
    package_root = root / "backtrader_runtime"
    _assert_path_components(package_root, final_kind="directory")
    if type(expected_pin_sha256s) is not dict or set(expected_pin_sha256s) != set(_PIN_PATHS):
        raise SealedImportError("pin_source_descriptor_invalid")
    pins = {
        path: _sha256(expected_pin_sha256s[key], "pin_source_descriptor_invalid")
        for key, path in _PIN_PATHS.items()
    }
    expected_digest = _sha256(expected_manifest_sha256, "manifest_pin_unset")

    # This first read is only used to learn the exact candidate file list. Its
    # bytes must already match the external manifest pin, and the leased reread
    # below repeats that pin before any tree is returned.
    initial_manifest = _checked_read(root, spec.manifest_path)
    if not hmac.compare_digest(hashlib.sha256(initial_manifest).hexdigest(), expected_digest):
        raise SealedImportError("manifest_digest_mismatch")
    manifest_files = parse_candidate_manifest(
        candidate, initial_manifest, expected_manifest_sha256=expected_digest
    )
    all_files = dict(manifest_files)
    all_files.update(pins)
    if spec.entrypoint.replace(".", "/") + ".py" not in all_files:
        raise SealedImportError("candidate_entrypoint_unpinned")
    checked_stdlib_paths = validate_stdlib_roots(stdlib_paths)

    lease_paths = (spec.manifest_path,) + tuple(sorted(all_files))
    lease = acquire_windows_source_lease(root, lease_paths)
    try:
        leased_manifest = lease.read_source(spec.manifest_path, expected_sha256=expected_digest)
        if not hmac.compare_digest(leased_manifest, initial_manifest):
            raise SealedImportError("manifest_changed_before_lease")
        verified_manifest_files = parse_candidate_manifest(
            candidate, leased_manifest, expected_manifest_sha256=expected_digest
        )
        verified_files = dict(verified_manifest_files)
        verified_files.update(pins)
        if verified_files != all_files:
            raise SealedImportError("manifest_changed_before_lease")

        if _scan_source_inventory(
            package_root,
            spec.manifest_path,
            include_readonly_worker=(_FIXED_READONLY_WORKER_RELATIVE_PATH in all_files),
            include_readonly_bootstrap=(
                _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH in all_files
            ),
            include_readonly_service_roles=bool(
                all_files.keys() & _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS
            ),
        ) != set(all_files):
            raise SealedImportError("source_inventory_mismatch")
        for relative, expected in all_files.items():
            lease.read_source(relative, expected_sha256=expected)

        return SealedSourceTree(
            candidate=candidate,
            source_root=Path(lease.root),
            manifest_sha256=expected_digest,
            files=MappingProxyType(all_files),
            stdlib_paths=checked_stdlib_paths,
            source_lease=lease,
        )
    except BaseException:
        try:
            lease.close()
        except WindowsSourceLeaseError:
            raise SealedImportError("source_lease_cleanup_failed") from None
        raise


class _SealedSourceLoader(importlib.abc.Loader):
    def __init__(
        self,
        seal: SealedSourceTree,
        finder: "SealedSourceFinder",
        fullname: str,
        relative: str,
        is_package: bool,
    ):
        self._seal = seal
        self._finder = finder
        self._fullname = fullname
        self._relative = relative
        self._is_package = is_package

    def create_module(self, spec):
        return None

    def is_package(self, fullname):
        return self._is_package

    def exec_module(self, module):
        self._finder._begin_module_execution(self, module)
        try:
            self._check_active()
            expected = self._seal.files.get(self._relative)
            if expected is None:
                raise SealedImportError("module_not_allowlisted")
            source = self._seal.source_lease.read_source(self._relative, expected_sha256=expected)
            if not hmac.compare_digest(hashlib.sha256(source).hexdigest(), expected):
                raise SealedImportError("source_digest_mismatch")
            origin = self._seal.source_root.joinpath(*PurePosixPath(self._relative).parts)
            code = compile(source, str(origin), "exec", dont_inherit=True)
            module.__file__ = str(origin)
            module.__cached__ = None
            if self._is_package:
                module.__path__ = [str(origin.parent)]
            exec(code, module.__dict__)
            self._finder._complete_module_execution(self, module)
        except BaseException:
            self._finder._abort_module_execution(self, module)
            raise

    def _check_active(self):
        _require_clean_after_install(self._seal, finder=self._finder)


class _SealedRuntimeStdlibLoader(importlib.abc.Loader):
    """Load one manifest-bound stdlib member through its runtime seal."""

    def __init__(self, runtime_seal, finder, entry):
        self._runtime_seal = runtime_seal
        self._finder = finder
        self._entry = entry
        self._fullname = entry.fullname
        self._spec = None
        self._extension_loader = (
            importlib.machinery.ExtensionFileLoader(self._fullname, entry.origin)
            if entry.kind == "extension"
            else None
        )

    def is_package(self, fullname):
        if fullname != self._fullname:
            raise ImportError("runtime_stdlib_name_mismatch")
        return self._entry.is_package

    def create_module(self, spec):
        if (
            spec is not self._spec
            or getattr(spec, "loader", None) is not self
            or getattr(spec, "origin", None) != self._entry.origin
            or self._runtime_seal is not self._finder._runtime_closure_identity
        ):
            raise ImportError("runtime_stdlib_spec_invalid")
        if self._entry.kind == "source":
            return None
        verified = self._runtime_seal.verify_stdlib_entry(self._fullname)
        if verified is not self._entry:
            raise ImportError("runtime_stdlib_entry_changed")
        return self._extension_loader.create_module(spec)

    def exec_module(self, module):
        self._finder._begin_runtime_stdlib_execution(self, module)
        try:
            _require_clean_after_install(self._finder._seal, finder=self._finder)
            verified = self._runtime_seal.verify_stdlib_entry(self._fullname)
            if verified is not self._entry:
                raise ImportError("runtime_stdlib_entry_changed")
            if self._entry.kind == "source":
                source = self._runtime_seal.read_stdlib_source(self._fullname)
                if (
                    type(source) is not bytes
                    or len(source) != self._entry.size
                    or not hmac.compare_digest(
                        hashlib.sha256(source).hexdigest(), self._entry.sha256
                    )
                ):
                    raise ImportError("runtime_stdlib_source_digest_mismatch")
                code = compile(source, self._entry.origin, "exec", dont_inherit=True)
                module.__file__ = self._entry.origin
                module.__cached__ = None
                if self._entry.is_package:
                    module.__path__ = [ntpath.dirname(self._entry.origin)]
                exec(code, module.__dict__)
            else:
                if self._extension_loader is None or self._entry.is_package:
                    raise ImportError("runtime_stdlib_extension_invalid")
                self._extension_loader.exec_module(module)
            self._finder._complete_runtime_stdlib_execution(self, module)
        except BaseException:
            self._finder._abort_runtime_stdlib_execution(self, module)
            raise


class SealedSourceFinder(importlib.abc.MetaPathFinder):
    """Own runtime imports and reject stdlib names outside the captured cache."""

    def __init__(self, seal: SealedSourceTree):
        self._seal = seal
        self._base_meta_path = tuple(sys.meta_path)
        self._base_path_hooks = tuple(sys.path_hooks)
        self._in_progress_modules = {}
        self._executed_modules = {}
        self._dependency_finder = None
        self._runtime_closure = None
        self._runtime_closure_identity = None
        self._runtime_stdlib_entries = {}
        self._runtime_stdlib_specs = {}
        self._runtime_stdlib_in_progress = {}
        self._runtime_stdlib_modules = {}
        self._fixed_role_modules = {}
        self._fixed_bootstrap_support_package = None
        self._fixed_bootstrap_support_modules = {}

    def attach_dependency_finder(self, dependency_finder) -> None:
        """Attach one fixed-root dependency finder without changing meta_path."""

        roots = getattr(dependency_finder, "top_level_roots", None)
        if (
            self._dependency_finder is not None
            or dependency_finder is None
            or type(roots) is not tuple
            or roots != _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS
            or not callable(getattr(dependency_finder, "find_spec", None))
            or not callable(getattr(dependency_finder, "owns_module", None))
            or not callable(getattr(dependency_finder, "validate_current", None))
            or not sys.meta_path
            or sys.meta_path[0] is not self
        ):
            raise SealedImportError("dependency_finder_invalid")
        _require_clean_after_install(self._seal, finder=self)
        self._dependency_finder = dependency_finder

    def detach_dependency_finder(self, dependency_finder) -> None:
        """Detach only the exact dependency finder previously attached."""

        if self._dependency_finder is not dependency_finder:
            raise SealedImportError("dependency_finder_identity_mismatch")
        self._dependency_finder = None

    def attach_runtime_closure(self, runtime_seal) -> None:
        """Attach one exact runtime seal for late stdlib imports."""

        entries = getattr(runtime_seal, "stdlib_modules", None)
        methods = (
            "stdlib_entry",
            "read_stdlib_source",
            "verify_stdlib_entry",
            "verify_current",
        )
        if (
            self._runtime_closure is not None
            or runtime_seal is None
            or type(entries) is not tuple
            or not all(callable(getattr(runtime_seal, name, None)) for name in methods)
            or not sys.meta_path
            or sys.meta_path[0] is not self
        ):
            raise SealedImportError("runtime_closure_invalid")
        _require_clean_after_install(self._seal, finder=self)
        validator = runtime_seal.verify_current
        try:
            validator()
        except BaseException:
            raise SealedImportError("runtime_closure_invalid") from None

        entries_by_name = {}
        for entry in entries:
            fullname = getattr(entry, "fullname", None)
            origin = getattr(entry, "origin", None)
            kind = getattr(entry, "kind", None)
            is_package = getattr(entry, "is_package", None)
            digest = getattr(entry, "sha256", None)
            size = getattr(entry, "size", None)
            relative_path = getattr(entry, "relative_path", None)
            root_kind = getattr(entry, "root_kind", None)
            parts = fullname.split(".") if type(fullname) is str else ()
            if (
                not parts
                or any(not part.isidentifier() for part in parts)
                or parts[0] not in sys.stdlib_module_names
                or fullname in sys.builtin_module_names
                or type(origin) is not str
                or not os.path.isabs(origin)
                or not any(_path_is_root_or_beneath(origin, root) for root in self._seal.stdlib_paths)
                or kind not in {"source", "extension"}
                or type(is_package) is not bool
                or type(digest) is not str
                or len(digest) != 64
                or any(char not in "0123456789abcdef" for char in digest)
                or type(size) is not int
                or size <= 0
                or type(relative_path) is not str
                or not relative_path
                or "\\" in relative_path
                or PurePosixPath(relative_path).is_absolute()
                or any(part in {"", ".", ".."} for part in PurePosixPath(relative_path).parts)
                or root_kind not in {"base", "venv"}
                or (kind == "source" and not origin.lower().endswith(".py"))
                or (kind == "extension" and (is_package or not origin.lower().endswith(".pyd")))
                or fullname in entries_by_name
            ):
                raise SealedImportError("runtime_stdlib_entry_invalid")
            try:
                if runtime_seal.stdlib_entry(fullname) is not entry:
                    raise SealedImportError("runtime_stdlib_entry_identity_mismatch")
                verified = runtime_seal.verify_stdlib_entry(fullname)
            except SealedImportError:
                raise
            except BaseException:
                raise SealedImportError("runtime_stdlib_entry_invalid") from None
            if verified is not entry:
                raise SealedImportError("runtime_stdlib_entry_identity_mismatch")
            entries_by_name[fullname] = entry

        # Hash-check source/extension files that were already imported by the
        # fixed bootstrap before the source finder was installed.
        for name, module in _BOOTSTRAP_MODULE_OBJECTS.items():
            if type(module) is not type(sys):
                continue
            module_spec = getattr(module, "__spec__", None)
            origin = getattr(module_spec, "origin", None)
            if type(origin) is not str or origin in {"built-in", "frozen"}:
                continue
            if not any(_path_is_root_or_beneath(origin, root) for root in self._seal.stdlib_paths):
                continue
            fullname = _MODULE_NAME_ALIASES.get(name, name)
            entry = entries_by_name.get(fullname)
            loader = getattr(module_spec, "loader", None)
            external = sys.modules.get("_frozen_importlib_external")
            expected_kind = (
                "source"
                if type(loader) is external.SourceFileLoader
                or type(loader) is sys.modules["zipimport"].zipimporter
                else "extension"
                if type(loader) is external.ExtensionFileLoader
                else None
            )
            if (
                entry is None
                or expected_kind != entry.kind
                or os.path.normcase(os.path.normpath(origin))
                != os.path.normcase(os.path.normpath(entry.origin))
            ):
                raise SealedImportError("runtime_bootstrap_stdlib_unpinned")
        self._runtime_stdlib_entries = entries_by_name
        self._runtime_closure = runtime_seal
        self._runtime_closure_identity = runtime_seal

    def detach_runtime_closure(self, runtime_seal) -> None:
        """Detach only the exact closure attached by this finder."""

        if self._runtime_closure is not runtime_seal:
            raise SealedImportError("runtime_closure_identity_mismatch")
        self._runtime_closure = None
        self._runtime_closure_identity = None

    def _begin_fixed_role_module(self, relative_path: str, module) -> None:
        """Temporarily register one verified data-only role during execution."""

        matches = [
            (name, spec)
            for name, spec in _FIXED_READONLY_ROLE_MODULES.items()
            if spec[0] == relative_path
        ]
        if relative_path == _FIXED_READONLY_TOKEN_HELPER_MODULE[0]:
            matches.append(("token_bootstrap", _FIXED_READONLY_TOKEN_HELPER_MODULE))
        if len(matches) != 1 or type(module) is not type(sys):
            raise SealedImportError("readonly_role_module_invalid")
        name, spec = matches[0]
        if name in self._fixed_role_modules or name in sys.modules:
            raise SealedImportError("readonly_role_module_already_active")
        module_spec = getattr(module, "__spec__", None)
        expected_origin = str(
            self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts)
        )
        digest = self._seal.files.get(relative_path)
        if (
            type(digest) is not str
            or module.__name__ != spec[1]
            or module_spec is None
            or module_spec.name != spec[1]
            or module_spec.loader is not None
            or module_spec.origin != expected_origin
            or module.__file__ != expected_origin
            or module.__loader__ is not None
        ):
            raise SealedImportError("readonly_role_module_invalid")
        self._fixed_role_modules[name] = (module, module_spec, relative_path, digest)

    def _owns_fixed_role_module(self, fullname, module) -> bool:
        for _role, record in self._fixed_role_modules.items():
            expected_module, expected_spec, relative_path, digest = record
            if fullname != expected_module.__name__ or module is not expected_module:
                continue
            expected_origin = str(
                self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts)
            )
            return (
                sys.modules.get(fullname) is module
                and getattr(module, "__spec__", None) is expected_spec
                and getattr(module, "__file__", None) == expected_origin
                and expected_spec.origin == expected_origin
                and self._seal.files.get(relative_path) == digest
            )
        return False

    def _begin_fixed_bootstrap_support_package(self, package, *, capability) -> None:
        """Register the one pathless package used by embedded support sources."""

        if (
            capability is not _FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN
            or type(self) is not SealedSourceFinder
            or self._seal.candidate != "i13_md"
            or self._fixed_bootstrap_support_package is not None
            or type(package) is not type(sys)
            or package.__name__ != "scripts"
            or "scripts" in sys.modules
            or any(name.startswith("scripts.") for name in sys.modules)
            or not sys.meta_path
            or sys.meta_path[0] is not self
        ):
            raise SealedImportError("bootstrap_support_package_invalid")
        _require_clean_after_install(self._seal, finder=self)
        package.__package__ = "scripts"
        package.__path__ = []
        package.__loader__ = None
        package.__file__ = None
        spec = importlib.machinery.ModuleSpec("scripts", None, is_package=True)
        spec.origin = _FIXED_BOOTSTRAP_SUPPORT_PACKAGE_ORIGIN
        spec.submodule_search_locations = []
        package.__spec__ = spec
        self._fixed_bootstrap_support_package = (package, spec)
        sys.modules["scripts"] = package

    def _load_fixed_bootstrap_support_module(
        self,
        relative_path: str,
        source: bytes,
        *,
        expected_sha256: str,
        capability,
    ):
        """Compile one exact embedded support module under the sealed scripts package."""

        fullname = _FIXED_BOOTSTRAP_SUPPORT_MODULES.get(relative_path)
        package_record = self._fixed_bootstrap_support_package
        if (
            capability is not _FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN
            or type(self) is not SealedSourceFinder
            or self._seal.candidate != "i13_md"
            or fullname is None
            or package_record is None
            or sys.modules.get("scripts") is not package_record[0]
            or getattr(package_record[0], "__spec__", None) is not package_record[1]
            or not sys.meta_path
            or sys.meta_path[0] is not self
            or fullname in sys.modules
            or fullname in self._fixed_bootstrap_support_modules
            or type(source) is not bytes
            or not source
            or type(expected_sha256) is not str
            or _SHA256_RE.fullmatch(expected_sha256) is None
        ):
            raise SealedImportError("bootstrap_support_module_binding_invalid")
        actual_sha256 = hashlib.sha256(source).hexdigest()
        if not hmac.compare_digest(actual_sha256, expected_sha256):
            raise SealedImportError("bootstrap_support_module_digest_mismatch")
        _require_clean_after_install(self._seal, finder=self)
        origin = str(self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts))
        try:
            code = compile(source, origin, "exec", dont_inherit=True)
        except (SyntaxError, UnicodeError, ValueError):
            raise SealedImportError("bootstrap_support_module_invalid") from None
        module = type(sys)(fullname)
        spec = importlib.machinery.ModuleSpec(fullname, None, origin=origin)
        spec.cached = None
        module.__file__ = origin
        module.__cached__ = None
        module.__package__ = "scripts"
        module.__loader__ = None
        module.__spec__ = spec
        module.__embedded_source_sha256__ = actual_sha256
        self._fixed_bootstrap_support_modules[fullname] = (
            module,
            spec,
            relative_path,
            actual_sha256,
            False,
        )
        sys.modules[fullname] = module
        try:
            exec(code, module.__dict__)
            if sys.modules.get(fullname) is not module or module.__spec__ is not spec:
                raise SealedImportError("bootstrap_support_module_identity_mismatch")
            self._fixed_bootstrap_support_modules[fullname] = (
                module,
                spec,
                relative_path,
                actual_sha256,
                True,
            )
            _require_clean_after_install(self._seal, finder=self)
            return module
        except BaseException:
            if sys.modules.get(fullname) is module:
                del sys.modules[fullname]
            self._fixed_bootstrap_support_modules.pop(fullname, None)
            raise

    def _owns_fixed_bootstrap_support(self, fullname, module) -> bool:
        package_record = self._fixed_bootstrap_support_package
        if fullname == "scripts":
            if package_record is None or package_record[0] is not module:
                return False
            package, spec = package_record
            return (
                sys.modules.get("scripts") is package
                and type(package) is type(sys)
                and package.__name__ == "scripts"
                and package.__package__ == "scripts"
                and package.__path__ == []
                and package.__loader__ is None
                and package.__file__ is None
                and package.__spec__ is spec
                and spec.name == "scripts"
                and spec.loader is None
                and spec.origin == _FIXED_BOOTSTRAP_SUPPORT_PACKAGE_ORIGIN
                and spec.submodule_search_locations == []
            )
        record = self._fixed_bootstrap_support_modules.get(fullname)
        if record is None or record[0] is not module:
            return False
        expected_module, expected_spec, relative_path, digest, _complete = record
        expected_origin = str(
            self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts)
        )
        return (
            fullname == _FIXED_BOOTSTRAP_SUPPORT_MODULES.get(relative_path)
            and sys.modules.get(fullname) is expected_module
            and type(module) is type(sys)
            and module.__name__ == fullname
            and module.__package__ == "scripts"
            and module.__file__ == expected_origin
            and module.__cached__ is None
            and module.__loader__ is None
            and module.__spec__ is expected_spec
            and expected_spec.name == fullname
            and expected_spec.loader is None
            and expected_spec.origin == expected_origin
            and expected_spec.cached is None
            and self._fixed_bootstrap_support_package is not None
            and sys.modules.get("scripts") is self._fixed_bootstrap_support_package[0]
            and module.__embedded_source_sha256__ == digest
            and bool(digest)
        )

    def _end_fixed_role_module(self, role: str, module) -> None:
        record = self._fixed_role_modules.get(role)
        if record is None or record[0] is not module:
            raise SealedImportError("readonly_role_module_identity_mismatch")
        fullname = record[1].name
        current = sys.modules.get(fullname)
        if current is not module:
            if fullname in sys.modules:
                del sys.modules[fullname]
            del self._fixed_role_modules[role]
            raise SealedImportError("readonly_role_module_identity_mismatch")
        del sys.modules[fullname]
        del self._fixed_role_modules[role]
        if module.__name__ != fullname or getattr(module, "__spec__", None) is not record[1]:
            raise SealedImportError("readonly_role_module_identity_mismatch")

    def _owns_runtime_stdlib_module(self, fullname, module) -> bool:
        entry = self._runtime_stdlib_entries.get(fullname)
        if entry is None:
            return False
        loader = self._runtime_stdlib_specs.get(fullname)
        in_progress = self._runtime_stdlib_in_progress.get(fullname) is module
        if loader is None:
            return False
        if not in_progress and self._runtime_stdlib_modules.get(fullname) is not module:
            return False
        spec = getattr(module, "__spec__", None)
        if (
            type(module) is not type(sys)
            or sys.modules.get(fullname) is not module
            or getattr(module, "__name__", None) != fullname
            or spec is not loader._spec
            or getattr(spec, "loader", None) is not loader
            or getattr(spec, "origin", None) != entry.origin
            or getattr(spec, "cached", None) is not None
            or getattr(module, "__loader__", None) is not loader
            or getattr(module, "__cached__", None) is not None
        ):
            return False
        module_file = getattr(module, "__file__", None)
        if module_file != entry.origin and not (in_progress and module_file is None):
            return False
        if entry.is_package:
            module_path = getattr(module, "__path__", None)
            if type(module_path) is not list or module_path != [ntpath.dirname(entry.origin)]:
                return False
        elif hasattr(module, "__path__"):
            return False
        return True

    def _begin_runtime_stdlib_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            self._runtime_closure is not loader._runtime_seal
            or self._runtime_closure_identity is not loader._runtime_seal
            or self._runtime_stdlib_specs.get(fullname) is not loader
            or sys.modules.get(fullname) is not module
            or fullname in self._runtime_stdlib_in_progress
            or not self._owns_runtime_stdlib_module_for_execution(loader, module)
        ):
            raise SealedImportError("runtime_stdlib_execution_state_invalid")
        self._runtime_stdlib_in_progress[fullname] = module

    def _owns_runtime_stdlib_module_for_execution(self, loader, module) -> bool:
        entry = self._runtime_stdlib_entries.get(loader._fullname)
        spec = getattr(module, "__spec__", None)
        return (
            entry is loader._entry
            and self._runtime_stdlib_specs.get(loader._fullname) is loader
            and type(module) is type(sys)
            and sys.modules.get(loader._fullname) is module
            and getattr(module, "__name__", None) == loader._fullname
            and spec is loader._spec
            and getattr(spec, "loader", None) is loader
            and getattr(spec, "origin", None) == entry.origin
            and getattr(spec, "cached", None) is None
            and getattr(module, "__loader__", None) is loader
            and (getattr(module, "__file__", None) in {None, entry.origin})
        )

    def _complete_runtime_stdlib_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            self._runtime_stdlib_in_progress.get(fullname) is not module
            or not self._owns_runtime_stdlib_module(loader._fullname, module)
        ):
            raise SealedImportError("runtime_stdlib_execution_state_invalid")
        del self._runtime_stdlib_in_progress[fullname]
        self._runtime_stdlib_modules[fullname] = module

    def _abort_runtime_stdlib_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if self._runtime_stdlib_in_progress.get(fullname) is module:
            del self._runtime_stdlib_in_progress[fullname]

    def _loader_matches_module(self, loader, module, *, require_file: bool) -> bool:
        fullname = loader._fullname
        expected_relative = (
            fullname.replace(".", "/") + "/__init__.py"
            if loader._is_package
            else fullname.replace(".", "/") + ".py"
        )
        expected_origin = str(
            self._seal.source_root.joinpath(*PurePosixPath(expected_relative).parts)
        )
        module_spec = getattr(module, "__spec__", None)
        return (
            type(module) is type(sys)
            and getattr(module, "__name__", None) == fullname
            and getattr(module_spec, "name", None) == fullname
            and getattr(module_spec, "loader", None) is loader
            and getattr(module_spec, "origin", None) == expected_origin
            and getattr(module_spec, "cached", None) is None
            and getattr(module, "__loader__", None) is loader
            and (
                getattr(module, "__file__", None) == expected_origin
                if require_file
                else getattr(module, "__file__", None) in {None, expected_origin}
            )
            and loader._finder is self
            and loader._seal is self._seal
            and loader._relative == expected_relative
            and expected_relative in self._seal.files
        )

    def _was_executed_or_in_progress(self, fullname: str, module: object) -> bool:
        return (
            type(self._in_progress_modules) is dict
            and type(self._executed_modules) is dict
            and (
                self._in_progress_modules.get(fullname) is module
                or self._executed_modules.get(fullname) is module
            )
        )

    def _begin_module_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            type(self._in_progress_modules) is not dict
            or type(self._executed_modules) is not dict
            or sys.modules.get(fullname) is not module
            or not self._loader_matches_module(loader, module, require_file=False)
            or fullname in self._in_progress_modules
        ):
            raise SealedImportError("sealed_module_execution_state_invalid")
        previous = self._executed_modules.get(fullname)
        if previous is not None and previous is not module:
            raise SealedImportError("sealed_module_execution_state_invalid")
        self._executed_modules.pop(fullname, None)
        self._in_progress_modules[fullname] = module

    def _complete_module_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            self._in_progress_modules.get(fullname) is not module
            or sys.modules.get(fullname) is not module
            or not self._loader_matches_module(loader, module, require_file=True)
        ):
            raise SealedImportError("sealed_module_execution_state_invalid")
        del self._in_progress_modules[fullname]
        self._executed_modules[fullname] = module

    def _abort_module_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if self._in_progress_modules.get(fullname) is module:
            del self._in_progress_modules[fullname]

    def find_spec(self, fullname, path=None, target=None):
        _require_clean_after_install(self._seal, finder=self)
        if fullname == "backtrader" or fullname.startswith("backtrader."):
            raise ModuleNotFoundError("unsealed_backtrader_namespace")
        if fullname == "site" or fullname in {"sitecustomize", "usercustomize"}:
            raise ModuleNotFoundError("site_import_blocked")
        if fullname == "backtrader_runtime" or fullname.startswith("backtrader_runtime."):
            if any(not part.isidentifier() for part in fullname.split(".")):
                raise ModuleNotFoundError("runtime_module_name_invalid")
            if fullname.endswith(".__init__"):
                raise ModuleNotFoundError("runtime_module_name_invalid")
            relative_base = fullname.replace(".", "/")
            package_relative = relative_base + "/__init__.py"
            module_relative = relative_base + ".py"
            if package_relative in self._seal.files:
                relative, is_package = package_relative, True
            elif module_relative in self._seal.files:
                relative, is_package = module_relative, False
            else:
                raise ModuleNotFoundError("runtime_module_not_allowlisted")
            loader = _SealedSourceLoader(self._seal, self, fullname, relative, is_package)
            spec = importlib.util.spec_from_loader(
                fullname,
                loader,
                origin=str(self._seal.source_root.joinpath(*PurePosixPath(relative).parts)),
                is_package=is_package,
            )
            if spec is None:
                raise SealedImportError("sealed_module_spec_unavailable")
            spec.cached = None
            if is_package:
                spec.submodule_search_locations = [
                    str(self._seal.source_root.joinpath(*PurePosixPath(relative).parts[:-1]))
                ]
            return spec

        root = fullname.partition(".")[0]
        if root in _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS:
            dependency_finder = self._dependency_finder
            if dependency_finder is None:
                raise ModuleNotFoundError("sealed_dependency_finder_unavailable")
            validator = getattr(dependency_finder, "validate_current", None)
            delegate = getattr(dependency_finder, "find_spec", None)
            if not callable(validator) or not callable(delegate):
                raise ModuleNotFoundError("sealed_dependency_finder_invalid")
            try:
                validator()
                spec = delegate(fullname, path, target)
            except BaseException:
                raise ModuleNotFoundError("sealed_dependency_unavailable") from None
            if spec is None:
                raise ModuleNotFoundError("sealed_dependency_not_allowlisted")
            return spec
        if root not in sys.stdlib_module_names and root not in sys.builtin_module_names:
            raise ModuleNotFoundError("unsealed_external_module")
        runtime_seal = self._runtime_closure
        if runtime_seal is not None:
            if runtime_seal is not self._runtime_closure_identity:
                raise ModuleNotFoundError("runtime_closure_identity_mismatch")
            entry = self._runtime_stdlib_entries.get(fullname)
            if entry is not None:
                try:
                    verified = runtime_seal.verify_stdlib_entry(fullname)
                except BaseException:
                    raise ModuleNotFoundError("runtime_stdlib_unavailable") from None
                if verified is not entry:
                    raise ModuleNotFoundError("runtime_stdlib_entry_changed")
                loader = _SealedRuntimeStdlibLoader(runtime_seal, self, entry)
                spec = importlib.util.spec_from_loader(
                    fullname,
                    loader,
                    origin=entry.origin,
                    is_package=entry.is_package,
                )
                if spec is None:
                    raise SealedImportError("runtime_stdlib_spec_unavailable")
                spec.cached = None
                if entry.is_package:
                    spec.submodule_search_locations = [ntpath.dirname(entry.origin)]
                loader._spec = spec
                self._runtime_stdlib_specs[fullname] = loader
                return spec
        if (
            fullname not in _BOOTSTRAP_MODULE_OBJECTS
            or sys.modules.get(fullname) is not _BOOTSTRAP_MODULE_OBJECTS[fullname]
        ):
            raise ModuleNotFoundError("stdlib_module_outside_bootstrap_snapshot")
        raise ModuleNotFoundError("stdlib_module_not_preloaded")


def _require_clean_after_install(
    seal: SealedSourceTree, *, finder: Optional[SealedSourceFinder] = None
) -> None:
    _require_source_lease(seal)
    expected_paths = tuple(os.path.normcase(os.path.abspath(value)) for value in sys.path)
    if expected_paths != tuple(seal.stdlib_paths):
        raise SealedImportError("sys_path_changed")
    _check_post_bootstrap_state(seal=seal, finder=finder)
    if finder is not None and (not sys.meta_path or sys.meta_path[0] is not finder):
        raise SealedImportError("sealed_finder_not_first")


def validate_clean_bootstrap_import_state() -> None:
    """Require the captured stdlib bootstrap image before any source import."""

    _check_post_bootstrap_state()
    blocked = ("backtrader", "backtrader_runtime", "sitecustomize", "usercustomize")
    if any(
        name == prefix or name.startswith(prefix + ".")
        for name in sys.modules
        for prefix in blocked
    ):
        raise SealedImportError("bootstrap_preloaded_module_invalid")
    if tuple(sys.meta_path) != _BOOTSTRAP_META_PATH:
        raise SealedImportError("meta_path_changed")


def install_sealed_source_finder(seal: SealedSourceTree) -> SealedSourceFinder:
    """Install the strict finder as sys.meta_path[0] after a fresh-state check."""

    if not isinstance(seal, SealedSourceTree):
        raise SealedImportError("source_seal_invalid")
    _require_source_lease(seal)
    if not sys.flags.isolated or not sys.flags.no_site or not sys.dont_write_bytecode:
        raise SealedImportError("isolated_startup_required")
    prefix = sys.pycache_prefix
    if type(prefix) is not str or not os.path.isabs(prefix) or os.path.exists(prefix):
        raise SealedImportError("pycache_prefix_not_fresh")
    try:
        validate_clean_bootstrap_import_state()
    except SealedImportError:
        raise
    except RuntimeError as error:
        raise SealedImportError(str(error)) from None
    blocked = ("backtrader", "backtrader_runtime", "sitecustomize", "usercustomize")
    if any(
        name == blocked_prefix or name.startswith(blocked_prefix + ".")
        for name in sys.modules
        for blocked_prefix in blocked
    ):
        raise SealedImportError("bootstrap_preloaded_module_invalid")
    if tuple(os.path.normcase(os.path.abspath(value)) for value in sys.path) != tuple(
        seal.stdlib_paths
    ):
        raise SealedImportError("sys_path_changed")
    finder = SealedSourceFinder(seal)
    sys.meta_path.insert(0, finder)
    if sys.meta_path[0] is not finder:
        raise SealedImportError("sealed_finder_install_failed")
    return finder


def import_sealed_candidate_module(seal: SealedSourceTree, finder: SealedSourceFinder):
    """Import only the fixed candidate entrypoint through its sealed loader.

    Callers must use this checked boundary rather than importing a candidate
    name directly: Python returns an existing ``sys.modules`` object without
    consulting ``sys.meta_path``.
    """

    if not isinstance(seal, SealedSourceTree) or not isinstance(finder, SealedSourceFinder):
        raise SealedImportError("source_seal_invalid")
    if finder._seal is not seal or finder not in sys.meta_path:
        raise SealedImportError("sealed_finder_invalid")
    _require_clean_after_install(seal, finder=finder)
    entrypoint = _candidate_spec(seal.candidate).entrypoint
    module = importlib.import_module(entrypoint)
    _require_clean_after_install(seal, finder=finder)
    module_spec = getattr(module, "__spec__", None)
    loader = getattr(module_spec, "loader", None)
    expected_relative = entrypoint.replace(".", "/") + ".py"
    if (
        sys.modules.get(entrypoint) is not module
        or type(loader) is not _SealedSourceLoader
        or loader._finder is not finder
        or loader._seal is not seal
        or loader._fullname != entrypoint
        or loader._relative != expected_relative
        or loader._is_package
        or getattr(module, "__cached__", None) is not None
        or getattr(module_spec, "cached", None) is not None
    ):
        raise SealedImportError("candidate_entrypoint_not_sealed")
    return module


def _open_fixed_readonly_role_module(
    seal: SealedSourceTree, finder: SealedSourceFinder, role: str
):
    """Compile one exact data-only role while the sealed finder is installed."""

    if (
        type(seal) is not SealedSourceTree
        or type(finder) is not SealedSourceFinder
        or seal.candidate != "i13_md"
        or finder._seal is not seal
        or not sys.meta_path
        or sys.meta_path[0] is not finder
    ):
        raise SealedImportError("readonly_role_dispatch_unavailable")
    if finder._dependency_finder is None:
        raise SealedImportError("readonly_role_dependency_closure_unavailable")
    if finder._runtime_closure is None:
        raise SealedImportError("readonly_role_runtime_closure_unavailable")
    if finder._runtime_closure_identity is not finder._runtime_closure:
        raise SealedImportError("readonly_role_runtime_closure_invalid")
    if role == "token_bootstrap":
        relative, module_name, _schema = _FIXED_READONLY_TOKEN_HELPER_MODULE
        if "request_coordinator" not in finder._fixed_role_modules:
            raise SealedImportError("readonly_token_helper_outside_coordinator")
    else:
        role_spec = _FIXED_READONLY_ROLE_MODULES.get(role)
        if role_spec is None:
            raise SealedImportError("readonly_role_not_fixed")
        relative, module_name, _schema, _entrypoint = role_spec
    if not _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS.issubset(seal.files):
        raise SealedImportError("readonly_service_role_sources_incomplete")
    required = {
        _FIXED_READONLY_WORKER_RELATIVE_PATH,
        _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH,
        _FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH,
    }
    if not required.issubset(seal.files):
        raise SealedImportError("readonly_service_role_bootstrap_unpinned")
    dependency_validator = getattr(finder._dependency_finder, "validate_current", None)
    runtime_validator = getattr(finder._runtime_closure, "verify_current", None)
    if (
        getattr(finder._dependency_finder, "top_level_roots", None)
        != _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS
        or not all(
            callable(getattr(finder._dependency_finder, name, None))
            for name in ("find_spec", "owns_module", "validate_current")
        )
        or not all(
            callable(getattr(finder._runtime_closure, name, None))
            for name in (
                "stdlib_entry",
                "verify_stdlib_entry",
                "read_stdlib_source",
                "verify_current",
            )
        )
        or not callable(dependency_validator)
        or not callable(runtime_validator)
    ):
        raise SealedImportError("readonly_role_closure_unavailable")
    try:
        dependency_validator()
        runtime_validator()
    except BaseException:
        raise SealedImportError("readonly_role_closure_invalid") from None
    digest = _sha256(seal.files.get(relative), "readonly_role_source_unpinned")
    _require_clean_after_install(seal, finder=finder)
    try:
        source = seal.source_lease.read_source(relative, expected_sha256=digest)
    except WindowsSourceLeaseError as error:
        raise SealedImportError("readonly_role_source_unavailable") from error
    if type(source) is not bytes or not source:
        raise SealedImportError("readonly_role_source_invalid")
    try:
        code = compile(source, str(seal.source_root.joinpath(*PurePosixPath(relative).parts)), "exec", dont_inherit=True)
    except (SyntaxError, UnicodeError, ValueError):
        raise SealedImportError("readonly_role_source_invalid") from None
    if module_name in sys.modules:
        raise SealedImportError("readonly_role_module_already_active")
    module = type(sys)(module_name)
    origin = str(seal.source_root.joinpath(*PurePosixPath(relative).parts))
    module_spec = importlib.machinery.ModuleSpec(module_name, None, origin=origin)
    module.__file__ = origin
    module.__cached__ = None
    module.__package__ = ""
    module.__loader__ = None
    module.__spec__ = module_spec
    finder._begin_fixed_role_module(relative, module)
    sys.modules[module_name] = module
    try:
        exec(code, module.__dict__)
        if sys.modules.get(module_name) is not module or module.__spec__ is not module_spec:
            raise SealedImportError("readonly_role_module_identity_mismatch")
        _require_clean_after_install(seal, finder=finder)
        return module
    except BaseException:
        if module_name in sys.modules:
            del sys.modules[module_name]
        finder._fixed_role_modules.pop(role, None)
        raise


def run_fixed_readonly_service_role(
    seal: SealedSourceTree,
    finder: SealedSourceFinder,
    role: str,
    binding: object,
) -> int:
    """Reject role dispatch until the fixed bootstrap owns its runtime adapter.

    The role sources are data-only and are not invoked through caller-supplied
    runtime objects.  The fixed bootstrap must construct the narrow OS adapter
    itself before this boundary can be enabled.
    """

    if type(role) is not str or type(binding) is not dict:
        raise SealedImportError("readonly_role_binding_invalid")
    role_spec = _FIXED_READONLY_ROLE_MODULES.get(role)
    if role_spec is None or binding.get("schema") != role_spec[2]:
        raise SealedImportError("readonly_role_binding_invalid")
    raise SealedImportError("readonly_role_runtime_factory_unavailable")


def run_fixed_readonly_token_bootstrap(
    seal: SealedSourceTree,
    finder: SealedSourceFinder,
    raw: bytes,
    *,
    request_id: str,
    nonce: str,
    owner_sid: str,
):
    """Reject token application until a fixed coordinator adapter exists."""

    if (
        type(finder) is not SealedSourceFinder
        or "request_coordinator" not in finder._fixed_role_modules
    ):
        raise SealedImportError("readonly_token_helper_outside_coordinator")
    raise SealedImportError("readonly_token_runtime_adapter_unavailable")


__all__ = [
    "CANDIDATES",
    "SealedImportError",
    "SealedSourceFinder",
    "SealedSourceTree",
    "WindowsFileIdentity",
    "WindowsSourceLease",
    "WindowsSourceLeaseError",
    "acquire_windows_source_lease",
    "install_sealed_source_finder",
    "import_sealed_candidate_module",
    "parse_candidate_manifest",
    "seal_candidate_source_tree",
    "retry_pending_windows_source_lease_cleanup",
    "validate_fixed_venv_binding",
    "validate_clean_bootstrap_import_state",
    "validate_stdlib_roots",
]

# This generated tail is part of the fixed, hash-bound bootstrap artifact.
_READONLY_BOOTSTRAP_BINDING_ENV = "BT_I13_READONLY_BOOTSTRAP_BINDING"
_READONLY_BOOTSTRAP_BINDING_SCHEMA = "ctp_i13_i15_readonly_preflight_bootstrap_binding.v3"
_READONLY_BOOTSTRAP_SUPPORT_SCHEMA = 2
_READONLY_BOOTSTRAP_SUPPORT_B85 = (
    'c-ri}Yj+z*k|4V0>^J<1GUn_IV1p3flGuiKAQG~;rbsSH+2fIUN=2YRq6MNbC_oZht^3<=MC2>-QH26Y+3ub8>9&c=S7c;nWJF{<'
    '{>T6LpX1N<;b@%Z^}V;B>(gX@Q{SuS{n=<b&!6<?(|EM81^?fPuNTQ|FiIxzAf1l0yW4a!kCRFNCY!aVclB01zezTCcA@dc`d~2F'
    '9zIQW*VhNTTUUdAe|xjPv$M6kn?8F!T<>4)Y;Qf^-s*2Z-Q3#U-rU-`TEE)be)fEGyZ`igx{iH~{+8DFo^P%{+x^lig=(725Rh@Q'
    '08mmFl+DdF-FmvSvzw$>&xc#<PuGXLJIU4V)8X#=vz_Nx{r=7n2HD)&9Be;No;^)BH@B0)_SSIlY-4AA*w>(J?`-UDE&*k>n9N7F'
    'Y1|)Y`C^v3SQ&2brrSH)yX)yrzdyK2t~Q?m0-g^B{j20z(jV^bK7E#Mu5Szhf64Au(%-$>8E)(X&>MrR=T8kN&v!RAmVlBi=IJc{'
    'n9Tb(gY4RYWcYOJ*>Go&CjE`{X}Xg<9b9d!Z(PA*Y;Wy8eR_4Z`TY5C`#DTGdA7B=(;sdO(qX!>wZ8N8`SaxIa}CMn_S5ZU>+><2'
    'y$4VLpy^^B_ivKPBpo{d^#T1?>C^tRo%MA6>2Q$lCR^#w)8P(4(oeQ`o~>{7hsn;>v*FfNnry6Z4R+G?ooAa@+q*lvo12>qHQP_O'
    'mH{-H46=`T{MYO%1|+{vCj%Fpjr7^p@ag)~o#FPgVY0Cc$hvyAyE#}-htGGC6w1@VX8LSrXJdPJyZ=0W{(OCKb+wiD2V0xl!+`+@'
    'Hre`@OZW*}^ELs5eW};$FGru!K`R<2qwyMUm2?o96BUUQ6%FD4^P4mpP14ysI^5WLa=5V*sUz5~)h=#Ed32i%7GtQCN0SVi@_y!7'
    'Hipgy(Iowl&Z7P-P3CD%eV)#;>sfMpkj#^4K1<V9?K*{Fs62`C6za}f5i}U!@A)hlj3(DnKbs6k*9)jN$|kL7bUV#vbF8p`aT=W;'
    '{M3p7<b0mM$669iXIVeZ^L7+nz=-f`u;^n$08uOoR3413(|nH557P1IiXa%@MT<$E!q*AFI?8K+x&C|DJ<!t|I9_9d5DvYlJ4-)|'
    '(vLO<^Tl*J9?@JT+2n8OEUWdiLAsWGoIu6t2!P)k0=3wCH_nnlJjCVjY1%vJ`>$yqW_XptVx&<vO(%ed8pj??BAEab;^05AP!u6i'
    'g@yX%CY|7@6I^seKaL73vdHCf{314F^wR_&e3^~0uzPwKHN?uLlMka=Hle9yv)cYI2hCRWAsLSbdO>Ll9J6BG^Eu9!=p(G+0#I$L'
    'v;<=F2(dEDpLF++@@P2AZeiN<WQ3T4qdI_V0hW65A$u=}N<WSAIc^8h@0y^ywdpJ!jz`xwa~e9&7PEc|>y(VsS&Kf2Ua=3@@Kl0-'
    '&$7k!4fF}?)gR3xIt}d_?ifKfTG3UO&2!j-Q_&4HNwN9t!>FIG%`({haxgscc{Cj_au}<h!X#_stS?pqK#kZIfMtSxI+?@nydZF>'
    'pQ}4WXFt151s-s=G=o7+4sn}IMnl}O2nqIyM?}wJG|vt0#%TgGp}jAGttAWS5%!6M>3w>KJD<A9Ca{(Dpkg)Q$jo8;!C&v*VN<Bz'
    'z8X#5y{n0JAt3PJ(<aGbNmJ~IdH^sMGXz5t6Zqd~(jPAd@CnY9fOI+|Dw10JW}Igcj56T+>fJlJzuSM!GXNlx_nXE?J353j&k$@5'
    'wm8dhFQ+Y7D0NVD4~So)EpRJjcyjxFAgwh*MH1oqjcxF<Nvdcc{4beA*%0>KB*h*EbRuwdVZZc&f)P!G)rU@}bAeJtg(TlnQ)iD('
    '!IJ|x1<^Ev&3GqwTgnN`6gM#J{_z;l_g{<A49PQ;!wmw(H9?Ei8UP`@PUpNiY_)k?kwdw*YG>i$luLxIYXbA)5D+N(90<ag;*}7&'
    '`%+RWES4(|Xo0UawIRgt=_g<gCWKl6d;e}t_c6r{l8c={t49krp|zVNS7X@7qHC=50q!vTrl>VtC+!+say7AtaXehW&}kgY3nQYH'
    'rX!HoYVz9^9G2Z}^{YR>o2I$?b(7>ba5?Cow@F|9joVTEJ((i`P`@(We3q)e^1EEX1iK{ZkCPnfuPoD_;94G~W4QydM;KaFI)!=2'
    '{c?(9i35wUsv578DWLBfZir8J7f_(9;2yW@w4#$KA|V;KqI1|xun1|bRy*jO9-aL9x_5jLpYOlwz3xVxsJ?^=Z-3aV^M)s<y|eDc'
    ';mNUTi!=sFOsuJNz4pt=*-yQ*_^fvXRe$cqr`?NJSU<?udhI1whkR4*#mULV`NdiH^xmE6y-od{_5Sah-uXqme{ynmaCqFkIPt-3'
    ')FSw&ynj5Ru%Y9AmI1~l$y~@OwI+<P-#a|Lh<`adyjU3r@^Xnk&PH>Ifs2!$ddKm7@i2$Gb>iS4etGyGy@UAd<fs>)pS(HS7k!;W'
    'XRxLImg2b-IQUHe#($RLt;MPqBf!)uotCKf1+XbVJv}@5@vQs$pnK8P6#-i3%rxpRfa6AvGM&|1QT=e93TA101AhX3))ZdW)K0If'
    'Ar5-y`)2?)%<H)O8hfv^Lx9AfE^Bt*T)g_J_p7eP?$5gJ?6h}$&^zA$HGbVaK75IoW4#Kp2u!5a@7bH<i^JDFzXiV_RprxP_q%X}'
    '0W&@LU^*Y=NHGU%$Zyb{*-wBK(?iImIXHyBV5+}T_hQfGZl&{mIO`6DX!{4O{b573Jnx<Td<eTqL1UI<e?C2vEq_#)ufa_JgX8_h'
    'uNOVsguC0(x6#J>=C-JD+C4+UQ(p1>RTso7fE_-Aa14yr6d2^jtp0X=?Rl~`y!^bo{pGj+gyoLU4-W$M&et~98vlC_t6zS%*8IHD'
    '+SvXgeu-x41O!{_QMNYaD5r;~y+Fm^=%4m)zfDKe^ta!xG=|o2djgi>|2u01-HFA<F6-C_by3hmy$FJ|4IEE0O&h$+X7pVYn#6zh'
    '&Q2t1aXr`TfN!`;<L>ePD_Dn@UD`x3on@$yU7<|VfQI`=hqz`h4v&FY{8(JE_AkgY0Fw+N#{z{a;(F%D$>Qy$<TVt}rf`koO$YqP'
    'EwKm0bU!hN6#5c!2&w_Dkx@zJij~6ZTAGuL&D8=q-4^jA$OLJ=2|D6pm|+p0z%l=e&p0Aa2;=9P(FD$HPP0Ouu3h`_O&4fp_c&(P'
    'DBH~%zZ~5HF_K67H{?gNaU%HjwZmxb92jN8UuljP*cswWuTqc-jUWr12@w(S*j3YqaRke&z=rD#XvZkO5n}w^uie*2Pja}2)~2w>'
    'l55Rax7Ga~B6H!{c(g5C4G!n8=NG-#ct&x<;i24F+js`MxqI;X@c0n#3c%U9U14i;ZD)HMD!n*6=^n&LoX>jQ1Aq{!m0oMq!N%G;'
    '+z-*eL_H98?f@fp@y^<&C_YZ-xE^llwkSQE;B^B6zz47WuBdS?Wi_YtsVMDEvdP_Tw#eP`jSX4Bh<LCM-hkxiSCz1wrMIw`IY`k_'
    'b`AWjQ=bsGBig)JjK*-lSjTw(#y|FsduNCHarfv55V`(oV_p1XN)Xjl^vo+F7J$mOb=k{9U^}QF#`~N~W#OhQ?VjSk@`|^u#ywuP'
    'p*lY39rd7a|JC8q0W06O2ku^6oE^S+BW@8{XF~&r6Y>V%;Dy%M>(6R(SoLv3%v4QsUwz-^-%ox49I29LqU4}^{39HPH|Mg>>+bna'
    'njz&&K_C7e*@#vj9SmEa8EOO7d-g|;%s_2}MO7#os9$>i_6M3cZY?~glBENj%DLLx>hIR9_4sCmtS<n5twxeobfB+=E(w&q*({qi'
    'e#Tpd{%r0ECcj?q!o@I1knR_0P1mGMDpYoGF||nqtqsy)6brp>gYK_Ad9jgt6PUF<kmqO3Xzd65uNZJNB%w~!Zz|m?6r&o&a53%S'
    'Vm!V@1v{&GjKmtM(U+)W)6PA8wr9x*uAVRg1YAw3E5vruo0`pFfyy!<FtMEM<T{=vqgmdde@m>veYzOWVX;1cq2H)ZhO4n9Ap;^p'
    'wGBuxYtl$fWK&bJ4B)!CXBlwNS-oi{OnttEkCy<Gm=BwvC{{Cs%PyNhFJrB$M?rj*^=s&X!z-za0W0{)03<(-(}`;JgJ54-Vf{%R'
    '@#Hnao`f2rjXZuXd$6jA;z>5UHFIi4-*o)mlF1#c=!_KMpX+TDkJ|0}7g|a6of@@s!1=rZ{ARr=25UZer~SKDh&05-+_{+HRK&@R'
    'Pm>v(KhvuiPjD^q3?$h-jb-^!sh8woH09H~`As&7(@$xCfy_<n6&17qMj#)_4Zy!Av;NHpxkO-t7#QMWkMq&MeC&@$sPDJF$>%C}'
    'Q2E&~bj34LuYko<2B9EM1_Rjjx%rARDxMm@x_ICu#yOrPANPc&+Anh(vUACc<SCot8uDikQ(YV%GnA0^zZL&UKTU}R=Y2XQKC)C@'
    'rSp0VjgS%`y>uEEqA%Q*&VIp$ggbx=m@Zq>7KWX_L@-B?4Q`V=03)6C@yL)$o>ZDsWZSPY5Ji&Now!#xz<43b8^%FRi|Z#CdSl@9'
    'V-lJqg;X~VU|drv@fsni3KS@+M0H@sA;G-bu`d7$Uo7L%gdUb8TyW(s08<^MgKf)sA`I=D^pjBYH}oVBRMgLsC<{9?mK8)lEse6~'
    'g8&ts#<!!KZeI!Oe0FDgmDevRh}-zwmLtsV0qI*B^~HR+_N?A)$-6{cpYctWz3&uXuT8n?_?8d`*qIft-*^L?4#uW>tq66)@=uT7'
    'xhGci%87TRV<jU==^D2wld0r;w9)m|v#Hd?@sEt62R=I|l-Cfn*lJ@4F#l{wF#l>1;Xpw#8RnG>D2W9pBgOo?LyWB^oaC|vxZ2&W'
    'QqAh{O9{g{81?7$q7EXlVH4DHK4`Dd6G!eGc7TG0d8;<ZC64F6M=0+0E!#3~Rs907I+(iC7@r~W^x0stEs2!3j8}YX?cd9mwV$1C'
    '#fDY9>07mdFRcX<AA>8TioUUqnc-@zqu}i+$;((fkg+jpx2%p$$rA+^+yGaCNYTMtJ`+Tw$F=#JNwrjSqdijJYHw_`cj|~XRl%C6'
    'sMURa0H^8R)5YgRd=z%Kjv+y2p*dZ;bhtuOi;=0z0wIHSR3vIhy*85^-A2b;wS^Wy*s~eDddE&1-S0gv8R)}3ER1ThBg1K_b8uLZ'
    'Cs9i!I0N3Rj^N*8H?VHp83^hOG@HR+LfD<@=+^FJkVE68KScQcQT9esaau*d+0(L^AlU?Y$BukqZv#-02{KT&;T|QnD9QVyQJonV'
    'NujTpk1@;(<7t|YH6@3WkqjoAmW^=E8UG&0mbHMIGZDaMLEkQ81BjLuR6!|0jVR9UGCtd3(-~ekx87oqKXk3ayf|ae@Z~0eou#i6'
    'Trag$uJkBpI?mJO%}V)7`H;e7wH8|hR#DnI6>ov%JnLmO4wr9;R<#{ruSCm-yXpp50+zD@6z5&A`UOu-!8I>n;+HIWL8~(1AiU73'
    'nzzbwaf@UOJlMe@JU*#t=@<@M4j5GzEeL?KR7N2p#pS``b}ChuX!$jpqa2jeRnSromf0-tH0mwXN$%l=kxuBW&;=qc4Rxt7hL&y@'
    'd)p!r2Yye(@F1xM5NWvBx~10i^g{+NCK7bm-z~R-v%np1Q?nCaARjXcB)BDXS4}gz$7pxVpI$8oG{s=^yT;?&tv%`WD4F+;$IN>*'
    'ITzmvv-S+9hVAXJzfA?hzIM!?rr6RCbetn;D-Uqi@=L)~m(u5sM>S33g7e?84=lqL<4HUGhpFP|9^C1<stKH+{#LY_jtaSBSc8H}'
    'a%{sXn0g);(~<f;dA6l~Suv4u(jUh|sFF9h8kr1kwd%bk^^Ix1r>!C1&KJ{h`gSy#qXoM97b<_{P9jKA+d3LRGi^XX`eE7Oc$|I2'
    '>mW^3HLXRq>pKc%BXFP&c|qpm6Wpl@z0^w+VX~m72bl)S1+8c}POkG-berVwTM@`)&8WNIi)ivjaSU`%PoAhhKJYNBidGb`q^K(U'
    'YYQ0?-(xWl>_vepN8gP2ZYmHOgzi=}9>E2p6wkCG_ZoSC%kHR?<!TU?#IyQF^mqKvrufgc_|G%?&&E3aXIuQ|*}8tl1eg$B8#GHE'
    '*D^WO(GnU>&#EHD2dV_O(6(Esx_G;Ose6GvSXgbNTD8q;)wV8!(!P2fB(U__t+%3$W~k1_W%RGn|7T&|t>!Ba*zgvQ)m-6G*x3$?'
    '$$Ru}0b-D{XJPmii<1+#$V?vub#Zuv_9bDaIIzO1IzFtg3r7=kgg7-24jQIEz(LS(<011=<B=V3ECyp!^ERXfyj_C8x|B+-y|n<U'
    'Hk-EB(C^yDgKyIDIP0tML4as<$jd-qP*f_&XG2QS^BZvmcyF{V?}3(RGpb$RQn5qAjlBrs1kD-N@EKb=vWW-1jNSrI&ZQmVbT*pw'
    'M^ki0LR5)2LJ5bV*qlc$RFuNMteY6I;xYTbht80zIbnl@E$&JhEWeAss)kZF;9A%Y2l3u&Ow)z4E>cMNY{U>|jkpvW*1rAH{Nh`&'
    'uyWgo#kO04?RF-;inv$c@kJz!wvnTVfaL-jBD_NZZPt#BCdqATF&brtOzwi%R!kKUtld$H(Tm0^T1~8sRo2XzkSe@+PPg#$NZPmL'
    'Z}+z8HQ;Ui90g5s5I{r7`m^==<>P^8=}hy*6`tS>XgWHOb_CbZfP0!iY+BYg0?O^ZOG`y+bfS*}qpt)-!=TCH_9~r4-@`SCoSOLc'
    '1Mo>N<v#?d{0^Yn^J+dG_CgkF=vg(JOTSva`7LV$MdJtQ3|Q)c{^A{q7jO_9TkafqRI;j;^c)X{?8mrKGJiz-T(G`6Md#E8RVn?%'
    '2qlg5R4QoZv?s3W_}<GhLifYb{LWLuiN%rKtK}JI+55#busi{BlxO1)spSf4$kA`VwcG7??~uR97U*Ft{a_X0Iy&##LQmetb)W~n'
    '$()`5^Sit~9Vc_xthe+XuGFo~st<qa{#9?{+G>U1iD@wClS5pOzKeWE7@rO#gAd7cw6zKCg*RdwW_56M)TpZxAViBijmHTH%PGRc'
    '9!u~afo0@jWrOw+ed!A5jsdt|oXYKFb}ifqf#_MBn1rDpf9&5Rvv}INPw9sYPH(vI^yKjPqIcHNbr(SKwl<sh7-yxfmRG)XaWsR&'
    'LtL~0hf7gNq0o|vmy1pt>t=BV*=;hKRH%sE!7`Uu5|G*4zA<bw{J+_jttEBkU{`mubl6Z+YOd6ZO|iM8bC@8jV&+BL+D!dAowM!U'
    'utXhERY{{8o13j@b8DN_2nzhRFv|KKq@NYUjNlcdC|EKY>r<~*>uNC^rVMHk_aX+ehPEW4v|+>K?Tdmw7UJzwb#j}0YHYOlUXtBe'
    'm_eL8bc2|At-ejHDSegw@-<g;o_?D1!zU>Z+kC(ce831PjL`0jPv@h-MRrc>4uAgQwy>zJOC$>klmwu8>2<e+Fv+bTYwHf-JT=(z'
    'y41Sa^3jhtX?``VTh}0eLJ6}x3Ly6+4M*e~Xm>?!dGQb<czE~f`*b!*$A$MQ+@8?(B{VJQv1~ani`oR%OtdIy;4K?Y-Cwi^nTozh'
    '^0Y^PqIG-i(N>rV63PQ72IRkl(!&WdU}SZtW(enILC-dFqbU<Ii!}lH`XjdQ&f%0@E#_%nZ$-s-d80m@?;|ONaV|!;=~4D^rTVW%'
    '*EdTW9Kq6bN&8fF2)jk)L4HBK-zsD11{H=FeEc~ZFK*LwVBM4PG0AaDn$Sv~1NpAdy{@|)_K6t$WOy{1yw9ujdpH@SpQ-{umCK;G'
    'G`qFiA0y27->uz#x{p`v62M@b7ifKdIC+z&73(5psxk+f^Wa4`zc~Prr4QoY9nPm{A|O90aq8VW@}fIDh+mvsyu$bZ@!|2y6A-}A'
    '&wum@$>xB>ei<Jq1@T|n(i%Ce05iux$9fZ>{U^gAnLw0IS})v^di?P6s!(%x+p1}w!R2-JSt_r(Pj2SR>-8pslOfKkyc+72Mf4`z'
    'hvjuwqKjA=CBmb0ay?&mZhDD3dZ5xdTn_Vam*`m%uFGo?ql2*<0!u$wKJ~)x*pZ0c4J`s*(6$!OgWbY9XT9@_?%4&a`=S>2&dxA4'
    '$VvSA<g7<6(Rp~|ne650@Z658;du^gciH%$M;h0Fd$Or>);sN<o%dp55>3@@bQ31`91U&n7}^M6*4Jb7BetBdFi>2KOkjo&r;08p'
    'Im7s2k%C6Nij(TB-ELnxo=)h0O1?@!3w}XmN~HT+8yUhGNfC#6)B1YjpgWTGLHb@TE{Y7<uu(+XR#4R&BMTb^j?NJUBx3UfUzZWd'
    'iqxyx#~XknLZ;Dr9hSAeD<r{fwQbw7>JNIZEBV4!okft@PLT$qg0TolWa3nR{cL)N@VylPD?Kzf*Ij0y`#AG)bku5%;xW-4m=5aC'
    'X=-ho(lzb+dL>t0tm0=^4#@ZJ%PZ<ESo!~oHiN|)9A4RM54Vk(sks26e~lXD^h3M<J2a?yFG)MNZUk7BZ75ZzxVJb0_KMMQX*t(z'
    '?5@#WT1T}@e_r=CCO0F0<XHtaqm;dAR>pr@|3tO0^&9B8{_?eOjxgbXws*HZnuNPxKbgQ9cB{vQ6YXmK&5^g0DR$DpA59l%JQ!5V'
    'c&fTr;p2fk9^H;`hZ#}=ysRN5hV(c*uDukzji;f!0zUSA35j8i|5x<PBO$E#`|8(^b-dg@O&!+xcU5oX5bgSUmz;vG!-3`RQ{s(P'
    'Y#1x{fDSjHY)xqS_H4Tm`Xxl3J#A2>Uc~ky+lWy5@#F^XJ&de5UTROcsyU%>IJ?0IKQa(v!}OC$j7D}I3^i}QEOK7XUga>xY}DO9'
    'S|bBQ!Re8VC?od%B@#*>5l<Imy`pXx?O=clzZzRlp}>T~nvLdh+{n}MuvLl$$2L-!@{Wh?*fPHASbaD(@hpze%+r|hIO}_9qL!Fu'
    'GU7`odYO##)G3^1qdc1w7H6|5ASRZ`*&_=_+!2?ChcuOy9&%+3rPI&-Ul6IIf6p;SYX3H!-(&-`RPWQfhTi%1do4RqEXqhf$>C@@'
    'QAhA!&8FD_$v{|f<qc~R+%y<Bps~y~7PicymwMCWKsK@Wj}_;On_$Bc5!UFdw8C|yRu33enBnFi6vqOu`asJ#twBpOJ9LG>JjVBX'
    'cwd1N2KSA12FPNIZ~OaO?NOBKcrnp&d>Pp`NJak-Jd^5x+%*7ix55?%|3V(dS%NSA(pKrk-Una&m9ElB(YE;FJ<IW4+oL>RT;UF}'
    'C;kANNZr2(1x*erx^sqUxesrXsTHJw(<E`~n|s_~QJ5m3)gk+c&#!@fjhp84mu4Grl(W~fFYX3@G#~;8VmT11H(_0+FFpO#R^1NM'
    'Sqh&k;g)G`kXqe!vrSb({H?TD`##!Sk(I3kS${F3sQn#jWVU`8SP@J}5CZ{d$l5K7v2kuCg<cF;{;8#H*p!ku6%%^9v3J?@CuG2p'
    'SIJ+q(Zmc(rg2^)dIBU497aU0TBD6diPoZxaGRJ<BkHjIXBNh$Ie1XLzA&7b)mVV*1L|PYD`yyJ1q&^-H;}Z5xnmj+Z$iy*ADm_C'
    '7>a;a7Yz#B<}+FaJ$YPe$DD1|T|raEuy$lLIE#LVTloxaCyYe3Dx63MmySs~4cWlr9)%G+|3abV+CC)BVBdl1Gj=Gj6?}Gxxh*+7'
    'kS|@dYN1uG;EPnaq${-bgb>9gGjF>BiNvlMU`^a3M)yN-vbvh}5jD-$Zy7<6oOy#ngb7n<ixajMRplt@1U89F%>AvZnzt=F^i9WF'
    '*;-()>W0>&zA2E0LJfU45NKWQ;^B6|)*BnMpH{Qx!>+COK-FVRcQdy2dlISsjuI(pP@AOy4eYwF29gkr*uF(kj%{5b*%_4u5&(Ra'
    'fhwY~O>dbgYE*vlt3B9qQ@r5ar?AAT^D(=<3`}~t^^9->Qcq)>sI3$(ej+IEIt4;TH>CZO<BPKsj2>%3#X7NT8RKqISl5OQ2mCva'
    'b&P}Xh_y_$8QiHwJ%%0;4d-fn8pS;2L^ll#FS`3by*Z7~d#}647l-@jP~qgXcWgfc*ks#!qlEem6Nj0^LUz=NWHO^v5%xtdmgI}Y'
    'Y+9maOWYLEmUdjl-<Dn!dqHkqRCJcPv9{5ac3<}wk_3dV6`C|*5b9e?PwBl?;H#!S$>JrI8Hk9EJo<!H+OF}E(W!5*ukYcKl|9%z'
    'h*r%~@$w5I{KTbI!kgOSfblYJEP;7_W8Isk*OhaLJp#cE%P(Rzv<tXc1@r{>Z(C93Gh`M+%zyY*eU8`rVmERSC6&cGjJLhL<_hz^'
    'NmhW5Z0H8IF%*c3-$z@UO*q9)=~4Ev3_72KLFw04nfhSUaj%SPg@Hf`+b!j5RAE{CDvW~pg+6I6!c)2FB)d77A`OEdDDtpZAQLjh'
    'GD_24tr)`>VfKvEvy%(B5isiurs-)Xg8`}2n-4l*{c)O1!X}(vmrQ)|h@epHvo{hEG}pKOWJ*UtRYMk{%*b~!5!uvSMymZ|I(M4A'
    'xO+w8dyQAJ!w$g1OtE#B)oig<^@e+|$z9>tUL#7H54h>HmsVKcDs}fb3R_EMWGvSZf6|?i2DJZbkDEI82bS#ogK(~5l5anS{6iS#'
    'GweC*zp~wZb(9v^+{5ZN?q^)@9LGPO@qCftyxIAs%!93uVU#VXk@=mqE&)Xe#bNO=#SRU|ODV08r~SnY$%o~>T3jDr98??sC<1{#'
    'mxV}6gRLq^wWZSM$kmrt5k0+wtsG$<?$r1dd%6rGFmOb~)Sbi_P=U8=ltHL(C#%wiNM9tZUgMJ&{|C4ctAZs*ntVOfjMBY;V7mY2'
    '?C?U^-=4h|86^K6VNTRwS+SEC?e-Pj6=D0Y)*^5of?kX$#R?>U(~<7-#0Yw=rGuiZfB=av_ow(21F0g(R}5Fc$-!nKaia)Y;U8&e'
    '%o>K86`$#)hhen}p(9>S9WI0LF1fu6mAJTuvXAg%1TId&dxppLmDZEiRwWfTMRG82Wdn~80nILni^_EcBMPrS-+fF~ZXi+@i&>Q0'
    'Mlxn;(t;hBhU!-0>GY;qMt6hYRM{!|0hIC_p>K#0*A<4F0d!*QCdm|*-nkA>DIp``)>1F8*6v~*H+j%C^)W<&?z6_&Wtb4z`a;g4'
    'F))f(WI^5}%^=3)YDg6xMo|k^Q>s%{Z{sqEP~D>y^X%cM2}dSV|4`H{8!u(FK<^1}4WsX(?PhCP-~*o`v{mZLww)o0dr22>%@7#R'
    'g3F*SdK)Gvn_eBVoopa3n(86i2&POVZThM!8Asn~Bsc`Ca$&$oiyW%Ji5=B<D>#`B{%eU&@geV#kE(<G2NmZ+449GMXx8-dAT$>&'
    '&fB*bA@dXYq2)#$C4T<VR&VZ$_C3vvm}*jb^jK<KZH8gR(4d+uiJ&lBFV@#roHMBd(e{kyZTTRSKAni+-3OFHW%(+K@&_u(EwpKX'
    'fW4O(Q(qMGRQ}L&Z=7m{p2%iw#jdFK{=rdfW5}XZqFOQi@oA4}Q9^-um<<Yo<1C4CB)3+?tpJN+Ed_P;13TRJMr|M&nLum$-Y19W'
    'LfL#OE}`BhtNKHg7~^bmjsLHv7*MsF6%`+sHmpln*lCuJq`uu7vEfCX!5%%;wsojm(YnKrsu8fLdH>}T#NU0?tr(i;Z)wxAO7#~U'
    '^VH*tTh$)A(DyZ@STS~1v0(*GV#y8=k=FcZRQ@qk<~G=CxjxC+5-Ji6_Tuag8ok+ijG(|J+XRg=a3IOBq74&(^1x9>6O6w%PUlwm'
    ';i2G~SGoYHQCxZrQkBa0pr~DP5&Bh-@D^N$PS9Z+SnrB-{mL4AD0K%ISe!xxL#@wa?1z#IRlbOb&DlmVaSunmGz{klK=Tlq3PWA-'
    '`ueAFrWh)A&a+$;yF70+SFvgd@612OmcgrGZ_a?ZMgAzZEsa7eh9%ovsns0gPM_N@RK}I^laHyID>)D=TG<qHnk#dg_vAPoBWv5R'
    'Lkfwu$BuDw3&y;V?vOp@!9cMu(odMabu=H}A<0NaXuM&TS%oMa&6TfY+xQJ1XC$PqVX8FVC<hS`#WIYq(~d4~(n$F8uqq#uoJ{S~'
    'fpO{?&2Lo99@}ORL#D#zj1{uQTzLOH8KihOkv$CB#^NxX_KAt;4UX-*`$u_%HiF6t^eP1cAufJ#v56Uq`7n7@M+N!|aOz_uD(L{z'
    'sgp$-2BW1=(%20;53cpIG3+n2rj``T5H+B4kqjQfSETl*aa}9%6SB9ONY(5+H3$6R3*~vEG%(%=<pREO?zf1MRkF-Jb#+H=qY8*&'
    '@u_oIT~~N@u2be;|6hyLa?4q2^1~!DYFqI!fPA)>y%k(KT`%FEozOArrj3Q;wX*Ro4>x3vcp%bDWjSXT6GLvSZ*Dh3c4{=4Wx|_*'
    '+;Hvoo0Rw(deNvF+trKl+5sd5;w**r@OI#Y`)}E>pip`BtW`51EYeSNRCrek!ekiF=ASIwMfkKD#&bL%`$Y=mf)5xeergDpSrvhV'
    'puem+a}sTd!^fZK8!JCOI9LS25!1~=>BKxfUxb9f>~pDzF#=m0C~Ie&++Gb55tt=vI8$oT_a?U@l1FcneuO>LPe;>vF{ja@<l30S'
    'OUI^nLT_2tc5u-NpAh0ZC_MTa;ZqKzFL=0F$4Ng$#6%dFYZfH|-lY9!xHxs>FO3K<ZNypc|GvSLjc)b`r-?0fErn6yEH=G_L*^96'
    'B_myj$q6fy!6Jc`boL(5$fvgeDEHzpRJUd9h2_&~y+j0D8jE=mtDA>2A>4;>bu`+nhju8XjkuKUFpp%gtTHT>-Xzg?QN4{>D^2c1'
    '$(!4r%Eo|P_ruIp#VPg}nvlnrsQcf^-Am4R`Rm}nMEhsG?nN&??)`%Mi|4Sx1P!p$kpgDJ=p?3^e?N(P|FM50L@J`6tS_?>X`8_B'
    'oMg*9vLz*wQ|3k{1IZ3n5yoeI3CT>;W4J7!BWkOpo`@c>+abTTZRJJg`mHIKGRh{l%yBK?&86In&R=!UL_<nZwalZ8d$sxQV^Bq8'
    'H@kRscJk)OSKJ*e)=pJoO&bDb1x{fbrA}e0uho6SR$)9f(}}}8Lwk>BTTODz5*#SuulFAyU7tr!<hSk-qViYyc{R365v*j43@310'
    '=&G8#uB4T24#9UU^=pe=9p3Nd-d3*5S~;Ygnl}Mh;uj_Y8~C)A;`v%nI;QrY#bmMCL(kG7FGEwTV7umoIkkmQ9bPURvXp?jSxnx`'
    'ppH78qmCS>#nDTzVI^^vdT-J2^k={%45te0RO#!LBL)lXRI|7Wnnl}l2$va{E0}}INfcD|O_qf}030^i&^&6HVeetXrp}v4J{gpZ'
    '?a+JH@U~6lc#+@uC-NnJ#uNF1P?!5{s#_U}>eVcH$uSG-7kOnh?@OAn(=e)*yaR@aEVr5nJed{0-+6Wu{Lxl!3ld&1fvbE+tZcoq'
    '8lA54x=_fEe=V0wJ6NAGN(?Q*ALpiNpT3p6H1C6)RS~lsDJvqR8p}hI@XnV~=n${T+`G)2!``X*EV#$=!Do3$M8nUHUny0sMw>*{'
    'C3LCCIgj2gsfR*JwaRIcy^8piMt?>9S9{CeD~os{1A@8%GDT!iyvN1%a&+S?n*_xV1!@2THKcYfuq|EcyebXQU<S{z2W`<Q2!Zx?'
    '554s8wWFaY;&s@xpX@2{mVUPn&R=O=WKg>R0^G@4TKpn1sJfkIQxX2lmcm5%l02=7K>$M(?EQh1!t-tq5)3Eas|C@LaIb~H4n}!D'
    'nJIv4wW5l95qfln<L_P)`JtCEnY&?@UC)x+7{e6{ji0R~_ETQoKd+?-94w*(|M=$cpeSDqVIh>_h0HnX2LS3uY32}9Z_}-}u^X(n'
    'Rk7Z-RS)&HAaOjid?;)B#ey=k(nM><fpK@U`(o$d8I#b~KfOHI-{8Nu5B9fME|S22jrC96=PjsuaDe|_e@g$Rzc=XL+f=$ke?NaJ'
    '0aOW9rMG5*_j`Vmj)Sp-WkFf!U>;0C)NY@@`Z1mVgx)DH2`RV_YlX2BY6bEt;gR9FP~I&RTbKFVtCTLwVlbecsyZ5O@C6}WiNzO&'
    'sg_<z6bt+}o0co5_~?2{Eu%zubm`;@?;kO6;911F{{38dmd2k$BAf%lqu9C;&;8@!A*e0qkrKC&Rb56_au+G^{1-?H`u^8s_>xbl'
    'ibu_9Y|tF2;9t^2NOU#JGWS7%_uGoTZHSz}a2x!1)_r}@z39egy`%2M;m<u00k+xnGe`6O%s?%fU-+PRzJGRjdVvq+-PbaU2j<|G'
    '4?E?pyKgRD{nY!FHD%AJx5;EQ1oT&c0q?oq@&2#z>+bR4OMJI8J<b*&{oSV3yE}Vxd~x`?7wk*D-}$Hx^wZn#0cOlAxs|P&*XK#H'
    '74BLgRJ6R=v@DoRZ2dF&@_L{<aii;xLF)gIuAwsCywgf1GQ!T_XELWphv{g7g&)$%htNxI9OvU~p2v6<H|jA#f|)*IvAgTd!XW%u'
    'Q@%mVkmg~gq%a`AS_zuGQ$#&dXkqwoX}I~BL`Fjp*C@OCD}WG;JVP(DLgDW`8RMVYwO%D#F(3BK@B3L5C?JdCDXS>YG(<a}jz{xG'
    '{fYgqoJ{T-DkSpfI%Q)~DOqGtYEdSL!PkLP?th`7EA*qYdMR?K!$f1dQlYENjKV&4v~0SuUOMbUF5L#EP0}^+ht?IZ{<3bNBSB-E'
    'Mewaa%~Ff}dM8@*Z(1RF9m2y7f<aqbT4Uf2XwhzLdMm(>N!#FGyy9z2bPU#(ShZ@9S$N$lmaRw7nPn@Yk!Og_U!wGOI=_pAHa@yd'
    'QHGzZ2UR-$o@I$N@o<6S=l1LDa0<oY4vQ9L_4;1Tjb5jhKDKC>FZEW~D+S@8zuKm8wt?8HD|#we9fqwjmuiTtK15CH&PmZ>PF_0A'
    'z0j1b+Mn1Bm450=FLC$_v&H~^u97}~&7jc(qXIVdphYQ6>fftvzh*Yr8cpPfx__I?%Ta69V9TFOlmA+vHP$elVbT&f78#w4G42&w'
    'dWs^REoS{xSQ+HSS2yG3#SN~w3vrXvC(%{li?Vbny6su#hHas4S`qJ5|Dp~{*4y-l*Sz`VF$sJuvaDgh-O3yiJZtP{K~-V8(XpU@'
    '*hY{9Xl<(3`-l3f2aA|IGMYD}6$yNPms182@hYOC%#)eDG_4;eAhg~*0ny8*sVZ%S$b8{1LMw>xRtT|8pAhE7k1(=8?qLcdmCWa}'
    'Mqn9WKib{Y1C|{iu#xQBusU{NvdS8E#;%5li$>xo`4r4Lq@rue1N);)RK7nR0SGUElZ9JLA6fBrEl-B({*w93BMJu*A$>tdhdcXL'
    ')H0dn(s6ME*V%_r`Z1cI-j=L@#MMZ4E`zmKue<v~!z=MO2T_$v7ereZGx?%BosB-Ao!I`xDFzE1j;<HNjiN<Qb(84);HP$Uh|#I>'
    'm-f}T5|bq3p1<JuG6~pt3_#s3a=dRx<FQ050SK}TDy8-8VJne667I+82!!rwn$Fra%iTg{eix>(DlZz#2X8+13C;F5>^4pY1CY*h'
    '_Vo_rfe8@)w7(#uJ+BCGxw*4zKAY9>id+fJtH1(D815F6H=#bWVK!4MLSIf;L$$X;jSEGl${l{pX7Ay43`m<C^2*)e7DgM$dG<b?'
    'C{e0%Yx%^Z(lUrfK=YEtc&^%&^udVkG(*!#bN!S(ELkus_AuT*I_w=^#4iqo4*g|Un7Ut_{M0*MfpNT+v>=xIQ63aM=q&v!EuPIl'
    '5@39@qb^YB70!ESm@t*p68C|F_Zr|{nbwaTtA+&-d?@k8CB|EFMd}E0uG{s-jn7>x>ri9wrCAw^n|gRJ#V^iIx(6|8mC!;C1O6Qz'
    'oL6Z0IX?gO{G#_7>$jq~d+_@3`0)JVtP87tE<U<A_;N3AV0T00K`Zbg<txG95iC^0y5B;biW6;hB0dE>n2sjPI`Igha50nfwy4$e'
    '&I(8;+LXH`*xLdFlLq<<y!|aDa`sbB-LEe%Nj5O|Oka`Pvq7u}*@Xr_r=8E=%)YevJtx1IJtRNW?XLNSCu?}?Y=0N{2>0f#wyajL'
    'a7#NOmaU^%-yfQ$YO^gYlLD*B5z{Iz_M&Dvhdxlqu@x%zj$L7$(5@;tFn*n)a}e5aD+>e2d8MD=^5HC{j*O3jfN+Y<2I-nq{F3^o'
    ')N|(%?nBX$_d@RSJH=9h2<=zU%ILQO)WNCEwO_)|%{+3v_?6qcTiRFgkT2crf;6z<V97~{kbas9y8(H6s_Ylt#-~`kmsJU%?zZS;'
    'SKX(^)qqlTu(OG{0$C}Y&E-=V=QiB@h3I?D&vg`!v+O-uqj^o6RRV_iT~dG#hkUqPLtqjWTFJ2(x1k!DPX%o_J<_fC$D(#Fp)!r#'
    'lJXwJg1W86*MgSbhSjaTl7b!zww3Oup!`voF-?sMVx27~N7Yo8;t7rvM<fad#C(cyfEqm`^RGmNZOga<@Ri<DuL8+ys8kU;7OlLi'
    'D+1k$SpMcx{p#;<M|>3(ZcSQl+Tz+QyY)!9*sv&q(;sFwf&|Lg{2_TiSW+m=w}M&@@wJ-#-m1|iT%wrDCOKJJkrszG<|Kg?`6$^;'
    'p=TnyU+FufI0UwBNrz?jskziDlKv32_vB94T0U7Vl>Wk07-c>qJ22tTd<+PIHUGAD`OPmC&2yFuf^vI@<pZ{RnV{h72wGl6lopD?'
    'w{>S74{<C(C>JgQR~D=3$s9#DmDffx9HD!OC1m#mlcL**<uWf|ZOU&UwmY2D+i}^*!kW2Tm0@Z*r`B14m$Ow{ol>2avH%qHZ=4as'
    'jHk1J8aFCXlq2Xx=(t<aB%7?|X&?5qqwmId1*A16=WA&Ff|5u-LGu$*0*gVpwtJ9{M^_XJ35b-?cWZjZ#g<d?G=Wx`k>ST3!b`er'
    't~y5$-lunMm?hJaqmeRtV7G*7ooUi7t$DG=9KC-Tl>`t`sWl?cd&;#UePT(sfV63jQzeltTg*{;FHCV}*<c|ID22f`x%5UtiKt$1'
    's3T@j83|@tBx=?#K*Ar^(XVT=VA+6qnw1~lbk7bByT@pIb#(IUYur>!N;-el^;AI#kv^tBVFsscRD<u(xWAm7{RBikWbviPtfIRK'
    'jV%v68`iS~(_<{vNBLIKq;|Z^+tYC}N7V*>|2Ud#Z9c$YTCrJo#E4>$5pwBzySH_T{WrE+(Z)tA+G$p`7!~9dV`+_nA9b!HZca#|'
    'u5TJH)cCE)6RBhUKWtfK{HVtfJdl+FkTXOLotUVxRB!vG88C6xL!gDf1f<~t-E@@;rj^krtg1Ztx;lfv`CV0E5Il@4st4Q(!HCQ@'
    'Ls&teS8t4+YTUVvXL|;f@9q$r-qHKORo)r?s!$8L{C;1u03JR{RASPHOVq0sxoAa6E+P=@6}y9(t?!DA6`a2AC+jWsH^dMC`3Phd'
    '6q6e?gI0K$kV>HTAn*i#<imC!GXZyK%|0F8-b($A;FPB0MQ(Hjf(v;<Ha>X@9cxZX0WG<vLy008NRb@d2ZCq1x?^T^IHwdiq6^rJ'
    'd6eH|i}3)KH=XrILQf&6GhC(OOwE+(2yh|eQU9(bUij`NP*p@{jy}RgwboCjGzq~1xG(y`dPAE6^N)pZ=%bCTvcjF>!qwmU<!5=n'
    'df$^-|7L_o1JH60iv&pyJR<>|Au<(#f}LPN*t9{JlY7;xsST=GG^h&5HaH8ZiqLl4DVpBV$Nuoz>oA`WfW=oj5yyDcv&3hk$**}I'
    'c=<}!8pgs(*(wMubElS4)r_caSv-|jm0KGRtUV;Rk1FpXq)-widbyqNp=EZe_$;l{b$=Y&87A%IklsN44Al^dANOlKs`ZHRnv};K'
    '*<<03nat;CP+YCDbSVwgw4B1-8jos>(mmdPg`t4%X@ug-VFB}#$9cqdA!slHub#1k)V<&VyWq8Y^`~%)(yBLa|9RY@n5BJ{Fmdu>'
    'oRO(;PvuYN7D1EWiXP!z#A(X5`UAUJu~uPe>HA^j=kf<U)?4ej`eVMc&cy>%eKQqrQ*6QS^Rn-CL@U3V9f3T_{|-A~n$Bcccs$oO'
    'Pf>ol1u?Q)6!*Kca=$wj`c>Fsa}^2G^a!t$DRgr!m;-TJ*v=)IgKh~+i4m$56BLuyD2>h(z)EM1B2wN@GUWKoesq)bkR!t_{ps!k'
    '4c@FJ`s@WP@CjLcuhKE$jRm@#hM_IQ8%f61X(hiFH{*P*)0P(%cW{&4>V_VN7-*(hM7NPH2#)12kp@(!AkdhznW`QCW;gk={D4jG'
    '`Uz|r;2u+us0t1OJ^hMkF*m7@!l0L13|uv6*&5*}xytd~4b@4c*{1HvT)tu;-D1Y)A<RS3JFMqo<gdFlVm<wJzq|jc7oVQ>;DdCr'
    'wY>oqeHRA!8kbcQ=>1MJCxyD_lfamKxR|Mq=ZK)(M#@@Ro;7X<h$RXkp?Xjr5F#xFH4V8xkmsY(n-Fv@MbMi1m4G7bN`<>}6Q}qg'
    'O>K!`3$NAjD%)Y4T(|_pb4~2<6?G40?Y1E%-due^j?StXtA*xQ3>id6D{Q!B;l|UJ-A7YqPr?coA6AZ)hmpRyP5NyqM#Y2Cb?PR4'
    'y-D&LpoMLDtz$>+oAi^cs#2s{^SqZ0jy*5YeSAC0$rjuvG5|*r{RR1J4zxCz+CG})9LbB5lM8$=IJK8``52|_&Oa_)T1p{S0MsC>'
    '>RDH@M?$vThAb7V8SKf*LxzlLrL(qP;PR`7F7jl+6sWqXJZW?)E&DFf<r=;mlg{?fb&V@RrtE0lz5eI8yB=^4xNG}>tDs;DwhEu*'
    '9_0@3Ch#Y?2Gj)aMf|-9Rj2<lc89i8nPr$#)tuQ-6p6BPED~#>WxUi%tYMGJ*uy`|hZ|esApE%wF%LgLZ$mPZd@RG#oM1HelQ(Dk'
    'JsAydl^~eO00kC~Y9h0=0ROLZ#Sf%CLFARuA4ZMUb!cutJ3xq>UT|&1{a2Z;Ssj06Y8Hg~!4%EUkAl|Y_ehTt0Incov)n%+T3VTW'
    'K6o#!NI5;C$r;*0+WDtqa{sYO-D5J^)la{}U_XeW6zOec=9+$%%?6`MVwBWXbi;-FQsrdYKRG!&I6OuJFNghiIQbwP<vhIwNda$B'
    '6^;;MSVZkd!ifknN9j<OqQf5jF)*=obRP-yuo+hrqpM+oo<rjzq0m8tH~z!%u+sSI;i-~bDfm%i5Q$M0@yJ>^Uaj~pDm=)aOFztf'
    'Gd<IawjKPfZCf#LgUYSVrklNwZuoCH(bnc8>$RNs!Fvfex{rq_wRq$)*t7))ML&|5NMD1|3=NPQ&d>0pQ?pc=Z=PVH`qAhL!#?Fe'
    'MAoKB|9t{es~0Hm18=8)T1|e{JsNZ%4x88Ty~`pAhCNgtUng7qa{UlJZK&7PSWj^qIZxp$kV6^tPulCN*IFImHAou&k*Q)}#|5pm'
    '_;z!GSFX0@s_n7@V}_O3R=0~sB9zE?mxTLkyLM`PZ{mjG<-$3@@)d1)5j<(3^1bLBSx#W($s{gNO+`x_6;!4JP#(SaVXn2+q^dwb'
    'AA6=vC2EN*5iJS{+H@Vd!y!0FRhx^j=X_YV25|rmVBgtatx+*m>UzAszJ4zP=xhq~kq+nrWTN_535Ft#M$wwGIG!YT=_q?56^Au7'
    'ZwNLwJ&>K(;z6Ub?gR9rG7vJqaiG4H?O5m;2p*tEKo}@|v4{-K(jPZN0UlWXXTh~hve_-R5#0p>n_4rrmh9^%h%VVYl7o{bUKZnL'
    '1p&^BU85uq?U?J9sQ<)uWBi~zLzxC~et~3gcJAN2!@RPv$(KMAJm?f$YQ?rTalpmX0dd&^a`Ng89f*UwLIB*#*dmMx|FLlTypoyY'
    'hc5-qs$j0DeKqWfJM4GDTf=p+<I1T5vL(kAAw*YjK=QV{0m$`cTCUL+ZJpRF!lTILA{2X5&O*SPD48e=>hK4$7Q#FY>Il=cMDx{a'
    '0Jcy<keUJAl&{iBN)d(~mOL1b`w!O?D?C#uZnQ{q!f|uj>lv=G$lP9EC>>YmOAFCuQNF8i%X;+iOT?dpdHa1?Gk((koAYJJ`oPrx'
    'Cio$1*s9EtcUveB8sA!2Y(?J&rrZqVSC_1mfz4v4*ypdb=zj(#^`Cs(Kl!$Q@@;==zD;`4bI1E-p*1yU<EWHW%;E<rSh1t3)@eZ~'
    'mS#47fFZIAr;eG&-Qn*Mr<7<oM$<{gW23+&qDXv|PE?@62#JIR$aF0JY{ppORWiPL#p~lGVp~y9{0QMqeF{|dnIiC1VW0@<lFMU5'
    'u9^%z9D%x6x6Him_ycWGg_6guq9)#JhfBG1q)xTa+#P)B8V3S`vzMpcg13N`*4J51_Hr0lPRliI)z$L@kyl+g+hwSzmiP2uoDe>E'
    '5j4Z8k3-(=;Y*-0W6QfLxCZ<uA>L>y`40k67A)lf*G7O`mfaX4PKmNw(N<}~q(_Co#P^`RNM>~lc-oz!o1@GxM*T#K37Utp++jNO'
    's!rAQaReK1fo~7Q9^IPwbNJ6bUQ0qZGDP3eJxnLK_fA|R=2{V{mfj&5jP&J#$(g94xgY=#v2A%y7M-jG1FW!wK%>bN;F4LKqOQz#'
    '?c|Ra>Ao>5Og=)2A`?Q1Tr92V<BhN%fvuURaKiDXh1u$kovi5qz1nuz(^MgJ61_S8>G<TAV};o^$9shv*a@DnimjVyC~Rj#sveV!'
    '{V}e2cTLF#P7E6hPDIV6)X3JhBVzGF+H$8)(vQ||x1Gt^)~8+nhaP3Ub^`KH93(3YvUe^@7{Gnn#I)0&2&PXoQCuGdU{ooC7FQr%'
    '-9Vvu>=zsH-a(Re-NJ1{2eNp3g|g2(V^EkX%0GNrt9*yxi2gki6pu<SgZs%$0^oKsMdDO&Hx(qgFO!W{o{}rsJj!f5874fD0%40;'
    '`4)vmD*(j-gLQO25W+(7ePE!TRs_NqN*)9W?@rk56v0yxuDtLF>j>ue=tKh0qDVg?;#}Ue_PhA@Ag-ujP&c%EY~6!P392BQ^1hc%'
    '*W|r#SRdhjBN&@mnoqMyp+sGJf7>*#VB0vi;7VJj()C1&;ouGm_?47w1AD4|2>jAe|EpX;q01qRyn<`>o+r*@aaKD2q3w82K$frE'
    'BOkWa3Cr)82cdf8jjxaafkgoK;ILzV7sjuo@ZT%M=5EPI+%j#XpbIMUcPe9JQ#aX1A+n)fAi7Q7W8PaHFx!cvg6k_z=|G4n$5~O#'
    '?(>765R5qrWt2EzmVFovM0jvf2e}vEdqH?r`BRj|DS;rPX#N@EYODSqD{S^ZBW8c4h}mWb#KEKnc1&X1KZ4aSutG0RdEgX#!ONP<'
    'gLUIUyPl2acl2C|u^Lwi&0RI#w>?Ue2Z<$tqGRrICxNs6?q-431+H+y+l1sXR=#>n@#0kqug+JFL2i?yKOzqKLqdqVOS;15@tPMs'
    '4L7V);k?n7J%+Pp?$a)M;E4>ItF}VzHp~GQSHvy%1I^iyaaTBuJhG&f<<u6jzqEq(w=<cKVl-hp6geV%({BS!Tp)K^6jMA_Z+?pB'
    'OZp&QVTWz;p%rnXh>j=<+ew6up}nFu{dBM_+~9328;>+Pb0XTc{}ki+t%cEPeJ{uW*K9qWi%^JOlsVYh&p8Fpk;Tz7AK5+bo|E<;'
    '{)1F=C9f^}7*s>k3L!+lx+m7xMCGdPNcX|z@@$ij>v*I)`xg{GP$hjk&1Q2EMBmCmB-AD5Nyz~H1pRfp`$w!Vl2Gz?^dg(zM7P;s'
    'F_v-pWoRhzvNRdsOAB$mlT3;zPqZj<cw!z~NRc7N%O!|We?FzqtrTXJqMgRVMgl|j=aKWNa#zUx0J)VVNgi1rYCN%t%{(C6VvpJG'
    'eFB`3aCS-(;XyH{A-53Q3bHez|FOr5NCu*)emLK$fJRAEqd}(*Ghc(5!~b{IR6>O{_7?YHquvT<g2k~!L|K2{g2fV$Fz(7jS&2oj'
    'Z^daw<guH{#L}(IFC|vhbG<4X!*?FGnwO8dq_IfV=Z$4jfcjk(CKL5~krH3H8(CPTA07ZV+!?P?+G8J%I&nVv+d5^n7}PJ{)*TvG'
    'zjP7oFXLl)`08D#1pt-qBt#cA=w_Q2&&g<-Z1HSGmfd>pDB|yYd)MHmZw1T)%XYb6pPN=%ZMna^h(z4(53lRZ@-BkrqeZ8?W$@4T'
    '3wBn&3>bF$rll)Pr)XHz;S`Q|?*Z!a3i|E0l6wr6$3<s#*(|&tz69BBHK4eK&^)VxVb<53s9~!%ZMLc;^R{JSmci~u_>!w!#7Di$'
    '+aZE1+bXiziRz!fwCR6!l|A6wkS2{?UV>LpD!iK8wM9ugx?UTY)SJ<SKO;cVBy^w7(&2b?eKWW5=4Al0Z&w?idPjE@xpK>=2;U&K'
    '_d>`1X}9sv-toQ!8%R`k?4QA^9Cw|-w_qb!E+Nwj9|+Q~QoN^7hBiyVW-)th@l>r4r=FoPuBnq3B#2R5%wkfkRX<*8R%})+alOed'
    '0G#8fKW|W5`pQEG<<8OK;orq@;ehZZ?3ra0psz^OT}xEB`~Ytd$a!A<st@#6A(FQ*u0A|Qhz_)6U=45*TIU@SHN&$g4E$?vx~f5d'
    'i*#AaL!u>x2~=zO0Kq}K^^{r#97@Bw65Q=y>XP9)TRgxBJIG;FwKNW1ZmZ3tu+L&^<#3w-KU1tkFhXJLL1yJz^RYbQqL3qjY8IwN'
    '3T+xn6I4zc3vwqdr;LG=d7b-6B5toctMs}P&#UwrNEc4jyPPAp6NVSbiNQAN)-99@gRQI!xLgJ-P83?8CAJw5liDh%JPu|U_3==W'
    'G0DmF(}@eUf8lGCh%;^*bcUquBX@y#<~5e<WgNSc7U<qU>_{MX?gNCC5{xfuVLB-{V^|e6Ia{ZaBx3i|BnMx5{T?gjqVoLUJ0Tev'
    'Q~iY7X+gMCARjyD%1PSej#iq}$L8HEsjD!lkCmXUIC+<yhfPM8mBBC1_fJlHg$aXwyq9F|V(N9IM%tb7RDUZ`$G7bF%$9Ypw=DLB'
    '2cIrIke*>@QR-vcmak(&V%KDVba<HDU@g&|H50quN{O89$da7`I||uv_;IMS+{!}WBlIHDSz>@8V01jdJGL&Y7*4_{nkE#0!i^Y0'
    '^{mX3onXqzAis>S253$O{5HOv%Hi5drxErRRhj`exE)B9!rsJf=H$Q*S-mhpwYZapV9hK6?ss<G4Hy>+pwPU~>7w3pp=$=;Yua3e'
    '<gB>DHA9S3qvn|iITkO)O+)ys?h5x<Zg8b24fRuR1)=l|D@8B0<^Jl@AUEvY@d$n$kLc0CK`r&`s4qJuE5QFa?i)eS-6LZ=pfDxY'
    'if$(*-W?BsmUSD1RJ@Gb3)F{%Mks?-WJq-4?sL<t6}NJ!-Ty=OFz>j`Y~9!}tmbtP9MxlzY)tVs548PGlgVPbBsT_2Cm_`NeNxLe'
    'nr}BQTj9Z)WnO|S0x7J<1O9-uI8MgnIMzXl>deL&IOwzP#o@`Z)X4F&^Zi%7*Iiu@0z?%SXa`lX<l9{vWlTP4R|#aNv@4wV&VD}J'
    '?^z{9njW`&pTzbTLLI6K3k;`KaY%Wq%9x$LGE<19YT(Kqq|Blp>Ri^)VS1LXNp^wRZwR9mGD}G&5r`zSxiC~wBSwd(`%+EOuGKEk'
    '4xXaKjj&O)n9S1a5pcA#bP$0gHcMuA=GCP|v;(RM3wv!!IL$`b+q-w#^A*R{lYI9sO8R(8a}}vhxDBi!TaUK?{bX(#<J9Ii$vi@w'
    'NM`{--CAV1b4rqI#3LvOV;((2<#Q@p0W*sEqPj2R)5FtVq!a@<4K_XykTo;`5{kkWArPA>*K;CQH59JN@Ll+(CqSN39c<5a(Q1<`'
    'ghUBi2F=MyTcDtJm0=%)C?BWkl({U>%3bBzcri!grDTA{>Uldlgr2iBml54^d_1W+4iR!UAd-;7hyA4E{J~O@y9BO7o)h50LaBv-'
    '<%`?2hVcW1cRQ^sJwTEnD>`-<qaRXKOG7By4N*S2o+R`v2&I74?*0*WpA7{9aK9ykWQvwoH0iuHXLv#XklDZG(Z^&oCx3qEage09'
    '8D`x@9k=p>-xmuHRn<}+J~;uH?`p#RJ-Qla7-R`w0BHY+=6`|y#=?_M3`jm9e-%r1b;q5Q|1Gb1m=_01%q0B;Cj+s1xUu!*aASwr'
    'Rp`e}<%?g_9()uSK&{+W+RtuNIzp7_1P;&s(P1>pa7@cN1)XQ;fC6}n>6C(=v9yKxO){lJD{`SJ6D|D$O2g7p4JhaWV&|$RHzCe}'
    'oh#Tlw<(+)$3#v%BPtrhhNebs0&R@Wn&^6yBFPeTM}m-xPDr66x&9o({s34&U9^vQ@*bfX&GVWVXibSi`6QX<H`)9z0#spuhkedO'
    'OO4Y7`awp+#heLHKttf58$&=jDcBXN+jfmyeq??5`l5f{CVlnyU-N9D{uU1^>Q|;<hDBF@!G%7rX}i05jqX)sIQruxN8flwvehS1'
    '1G_~$$<k9Y$~=V$oo4yy6aEzS&^b)^;bu11RS2V2omO-*6+Tui9dQ(HdU0c;xj?|Kfm9pq4;%Gb$TI;N?dmu+@)Cq=kJ6LTV;5PQ'
    '*59tLJx|t#m!EgHzx?)}z;DGr_s-6Ne+bp>uKj1S_BUv8Y5r`-->qGKUT^Jg$@cr*<AcM4?nN&?>i&B2<^p;Nr+7CO_v)2o&rxF3'
    'ePzfKg$U>Qrj6U6-deRekXZOWzeB|~+J{u{;C2wh(Z-z`!}&)7mD7U-e+g~z8PbbQ^%?FwY=%1zogso7i=<UDdsT39UuwAICkMUw'
    '<d<V)_zsVWmpfl++3P^DRerHB<7Oif>hHh?{rRx>3-XX<4GBQS6rOhXf9n2-8#^%ZdJWjr!=G{Ip7nkd9vyHHuyXn-xt)&F{K-1N'
    '37aR0Z%2b6+*olwx}9VnpU5uO(9~7BLqd1dMeoO7<HG~iOPe}rd!5t`oR#X6qRI?*);sN<ox>bY4v+EBt$*5HU$4c7$Gx+QSi3`p'
    'DT>Vxwm)pvy@q(Bdo)3~cGZ8wf7-wOhA%t6{bn$`#w~v}rP<m<N`cFA)cdi!|EoLF%flnuKB9MJ+Vvy`DA5(yY(rhdr-C>2EdGeE'
    '$b;;9NoD2M_}A<zMzBE&t=K~2YPIUIWMxD%+?l=Z!O8K_uOuNI9sc<0A{HVFE>WmQolDNxYYCMpb{XtX%W^ApsksTK*FeU$rM(7{'
    '$9cW->}M4^<muO(zMKqVOFMItm^r;E@stuEs*P#vA02{Lil<hv8lQNmhBF;b(^M7TC;3(H=#=m%k5I`q7FM?t7Miu9lUaIjzl$2h'
    'ySl{z_xmmCu=s%KgXPKLOHO8B#-euV5pt^(u5<Ysm#i-a4Isu7m`r5zj>t4pXo-GC=RdA!0v5Ro^mvevw3H?@5D>I~ijbl(G$wJ<'
    'wSU(<ZA0wfj)=R!N4r3t(g>4c6m6X;O*klEoLwT`UrhnCx-lP(1<Rh|4c=1dIqL_;*%vB*{kCno@C;YHA{P?d`o#OrO-sB&e2wQH'
    'okw#vUG^-#CxT*&$+X+;%UbXuTQpv_D#gw{dIK=gUl>+T#|t6b$)FA>o{mRGnwC$ZQpuyELVyfM&ZQ`{0?#=}D2z=a^c6znu+&M>'
    'AqZ|L@8G(koQEolRJox8s!(&f#{%X>w-|y<inQ<E2{gQWCsdmW^Ie~%A4cg%?rM&@n;bY<(VL1)LB3sxB{7B+tOXKA^T^U(2{*3`'
    'z(-CR6+l9Nj<rbLBLuS)MKTomhsk@=ERmS(#GlY^R5Dm%&Dg}5{os2+$>lb2MWz|);dF43aJ(Bz9Uwy3sd2-pn(aCv?YK`)>gsWv'
    'ZB8e^12-zAA*7)N2F@_%0i#Lf{0Y>Fj~+cKg+cB?rKaaM3#CdZ9N~v(WAj-!Ggf=J7>~*FuvpC9BQbYl^XZp*s|cQExv6hp33ML}'
    'pQ<~J(rUC@^m{r^CYm<<ES<pzk?^9Mr0KvAf(Z<+v`F$;PHz$(rb<)nC6wK=!U%l!h_ZBdvA=ky2&oMbn}=Kg!CU0<DY>46Wk|Q@'
    '-)&1*^ALqG^~PZ>r@0Lx8U5$*bibvw?`YmK10EiAX`~+)3U4yCGHV)KKs(mK?|s|ao+tsd8iPT$Qqsl~$-FTPH03hckB|QcT*ubZ'
    'oXMze7Aqz`nL7=3e?qEZ{rZ90`%iEo_eU5)_dN*m6I?0OJF`WaTZay$m7Jqf&3%d&3oN^=WJUCq-z1D$zxdWdh|v39J_sqNGgPIg'
    'gMCFT4oS7C(Q+=_u?3-FI(ex9eUGoiK&L(!1v|b6%%cC3T_GNThcS3Td(}OU-nl_+_T;?eKESsi>yz=e5n5}j@HU+%^a71a0TA*Q'
    'Q@9lK#dxl3Rf|?9LI^wQ?Cos!RHZ1JJu*#r<{DJ1>V0CzzZB2hVM8A~Mp-;q;GPt5qDgL;Tmuyx&GH8QTaGU<0kiu2rKVgw;PAB+'
    '>o|$1w#CEXvmGVfAtY9t1`jr`0fUaLcx~9<Tljbh@X+`*W^N>k)$Ak-L$%a8w)nBKV_qxHi|TXU1W&I~rZcv|)WpTaY62se)oQ&S'
    'eH-m=yK%7mX$yFod>Ue2au%>}vkBm0to2IdbhyH-3`Z88U(I2S3|bk7C0qSq$H0fe`ja}YwAToGlD;mZJh{qc54EtHyqObuRe8N7'
    'lRI<;rNmjE>uvOjX}9ZNWO^m>of@@s*g5kCOUKfD%r(#nrX2h$&p8!W{gIYK>?c5o>fgdV%rS_1>y1hd0E-Z-htx*17`24iAbNwn'
    'VqyMRcrJ+UAY+BOV#{8Mpxmkv+Dr5s$S6~Ee<@MI$TB~+UTki{K@t`Vrl{6K$=k4ec2JW^l+3OdsG0(7-~%bXbWYIBA|nGMM5&B^'
    '$O136qo|8Q@nAtp97~AKt|+e{a1esgKuZ#((3+3$BvMg|Mr(E>S*xdEOQKc8&PS`>ip$gx50o-RJT||c5ooP&i7ZTFpiMOiRZSY>'
    'zXt_sgh?ge!#Y1ip;y)l)8|~(=x?bH$GvlhD||FpgCgu}XIb{iyNlk|+hjR_!?y=1T0J!Ci}`Tv8M+1uk|+3t_$JHVcZ&IlCO7@{'
    'Aatg{>o(rN5rlE6UMn(6&{l-6imu^Z6%^<-a4i4A_da?(i);&Xb}xOd=WtYS6C{vIbiu#H8LLyg3KV+kUsi){I7-KZ+}|cN@>?}1'
    '#n=>&c`NQgYR{DmT#>6dskdfImyEkM#d4OHOu93La^ja3PF06Nw3<S~tdt)Kox-niMI>rjGJNU<^g&2e5yD|!o>4C5FVQApV*foz'
    'D7;9%$i~7@PuPC(a{88D-+`PK>e2pcROaeAd&Sk3MgT!9h-C_5K^56p(92>zafzOP*IF0;(I^taUzHOpD?}B%g<V&5W24q6Z|;XL'
    'si$yGhr5N}YD`>u!htcLVbVcSLtA28X=9s6A$)0dF<u_*o-_bxKjA3Yt$kC9+gW7bEs{RO7JDm>$fYKLBDb!$@fuD{jJMuVBFg4k'
    'Y}CA{3~$2+O|%Z#afG_yXHm3dCL5s!?3CJY%Ia0_A>}ie+yR%TqdC}^GUr~$$$86(flXRXLGUp1;%_?i$+Oa`0yqm&;-!c+iDzRA'
    'cBUsl!`xQX&`M#&zO+bhYJM5DZxdw=4^%%|1b%?An1?)$b?H5%V7(xQM1e)@h@jZfpjrim9w8ExN`-U^eD_*>si+q*OAz8_Y9<H-'
    'gWEp4T57eU4*&wZ;8(3EuvQENtGb3F6v<Dbq5u*xxCw#fZU{D{suY-Wa0iNwP-u&${_%tVI=I-2N*qmtyJ0Vi%R+@X2xn9|gkMIK'
    'tArmjxZKmYFR0}~YZfC2lXX7?`ZR|Z`ZPc6nqOS^Q#hdF=4BTo1^U@)Z)~)8D1g1HU~wFxR`>P6?smNb1uKs+uX&b|+s=Tg_#4EJ'
    '{^j&&#R^;2CF71Rwe-M~H`;w8XH=nAVxU-m_}hb0hI+EV<-uuq6uxs|Ok)Hb40y(*Stnp6i-s18XBil~%2h-FG1L%Ea3osJ4Pv}A'
    'i4coPwC_<~r0)sLI<23f`RibXo1Rs7FL;@8TH4=hH`hE(C*~vGO-+4)s@(BmC}fXiTY{|CIaC2MifPxW7k8y(|JFN&tc)-*xKSUO'
    '!x3GREL~2jNm&;QffnNn3;SI4b)y)e4)QQyR73Rb=df2*gxjH>nBu&o%1^3428-LN)L6GDxjnu^<n#j8QhA`VS>9>XTX-h+P%n~B'
    '$n!VJ`=e3kWirmwW;>mb^2A6hLW{zZjG!}U@)1vo24XegfYK?drgclV8dQHa{Md{teosJRY5BEfOb$!xXw^conCwU(=7R2c7jy6)'
    'XIG60gc68-;>SA*#W=F#8>ySmr^EaT^vQ9-Rp<ml^6oXSrWO1se9L)lkcxNgU@?Bk7k6U5?0ng>B<g}0S>a$rv_tzOHG`>Eob(ei'
    '4~lw6fvpnL!*LFnL>8ejz!)v#d=G<a;`_IJb|vjSW{KP5`xz^=&*Q`MqvM}c%Qk8?;fytr$WUH64VHR@l{JY9QgAlRW;YvMEl9%>'
    'tv928jciML8*20s0tzt6H0-Ff1u1?q&l|#`Mfe7Ni(Zdt*Yh4IuzCD30>4!J%11Hw9#e&lLDG$fUA0n|ibzfjl<QQ{`!)|Mp*U`e'
    '{t0FDV)J%m?~)iWQ#(q5VzDav2Etc{Pc8inluj16^vcmtJu~PHFzT--)Ueo>TrQ3Xt2)LNZpfydSNX|#QBu}Id|9vHVUO?PP1#&!'
    'B&!G8B90IkeJ`FB6wacxXv3sKRU7-@@XXuTt3V;GYH*uqm)DT4pSCH-IYlw8l_C57h(?}49}9XMH?W0KK-B{XSbjL%S^Hxn0SF9x'
    '*8A}R!_Ly{#W<M}b*XE@A<~_Q*qIa*k`oKf1mpc#@NCTNI+s%+PJB9b35mDz<jqT`JOf6kQJ-DGdSNnxIShVl?=|TTO50>e+eFl&'
    '0G^Yq;Y8LHFM6^H&b{GAql~_bHtaUS3AD-xglks);rrGs%(Csvcqa2S=uXZxez3NdK&9SWye=ynq#s(5`8k?o{3pI7l04NQH0TEU'
    '7uDClsJb;!aWm1aL9wo6f5MvXG#~VeNt^#6<^#~RWjtUzwLOj%L9uP7GPT9W_|&u06oDR01O$_lURk&cD@|inAa7!H0(b29r6B+|'
    'CS!oB)HZcz#`2@w2%BV5KxY2TmI0$mkaKk;_0X+g&;SuHAj*c+oeUr#1L+ZCApFtC%6?x=$wXTCr@_HL4G#WkaPUxr1NP7<Ef3fi'
    'BWqi)%FM3YenzDidj2J7gl*MeX4uxyK|^d_gG{kkc#sXy>{ZMn!amRU9M`j#a5Nhw`Zmi{BCha0%2#W7zt-Af$NYnvK2@x)^D1l~'
    'zqdtu0Q=UcaqD<*6HU)%pBaYmEoAFnd6D<19`;3N5A0s+iZAPCTC4*HcWPfRL0-Wzu#o50DMDTqdzzK4H^SBz{%Ngd<+0K^mRhUA'
    'H_Na2PV#%bExD5|cw{14XqHxxMtf!HTX11ziHI@9Z7J|czr-n<EAy~wl{y7(+Ok@66^v-7gn7X$h(Zdp7SOsXd?O%N9^;T0ctbXM'
    'Cd^+R00mDT78Gw)`%8A#osv-39>e$l=tF`h0X2g9{$SdL3NgYTLxCT>wnU3RMrR+qRy*uYW_5Yc{BWfF@I}+%*HnvX_r{?|7HiAj'
    'Lwz3(BzQl;8ryu^s+Hu2lCIXGj+gyOD9mbp>L<Uz^FNfs-i*crAW!{lGJwH`Ab`j%na{IntYXc@w;3D^JQP-)CB?3<Ud!`dL^@zi'
    '(edOHA4k)^3Z;_DPkO+RcEWd0%-?&S0^CDUg=L&)7?x0o^chB;#9n2N1s*K`sZcaY0ohT1mXf^}wo#kmiRy1U%P^>6J9_udn!~$y'
    '(a4drVQ7pNr(!QkO$UY^#E@wedXZ^5px*pOgeQQ5qR|R1P7e>L_Gq3*uU>ceVTG})$#q%~^l_3YFyY%RhCit39Fy}K6<$#6;mE}M'
    '5(=1`<O2rM6If*N3T0S<o7C~HT$4&6sRg=PU|w#5SF3sua5V|o9gYIUWN<50a|QG(j@e-Fw1w3ZrAd+;%|TJewl+cJ9tqOM)maR;'
    'pRmrsce(PYNs;>%uPy0Im8zWL6gt{DmKFh+0+uu3L_W4Vmz{O+n@+?VxoKKW12-!xZ{_7<U1^zsuuMonBYEU-Dl^vu)*>5CwIg-0'
    'CW9-1f}P5^r$t@@hH~qr0|G9Xaa|OB--*^&;)YGzGW%!?1a(c=XS0g_y(}ZS*L&cAhPe&L$g_E$`KuoN#TSZFeF?hi05@I-3oM7p'
    '2<&#NDgsP%PgX%DK`AQff^S%iL(>pe=QD_Ec=3xyP4T)eI;c;Qi8faQRzr1fmQB<v;6s{zteAp|E)eEHJqS$G=4^_<sshnt0V9dR'
    'dV4+k-dYSee_QMLnZj$cMN+F&A5Dh!mA0tpW*{Rsmz`1r5?jCTI}YkBR|2-qHiW#Ei~2y#=4u*E*`MRwVQVsl*@%-iFQ}U|HF-g^'
    '!uzz9<B&g7yYKbo-B{vdX+J!d0fnz*6M14p#5GwU;;gEbRtbK`6kOU2OOMT~(G}4!8RK*KT`c-jQ}xUPbk7FS{$1a)Zf5-s<*D5q'
    'UWgqkJ4L5*V4jG63vzQxJhF8pBVp3feXEmJO5gh@b@px_wt{HspzfYlCCtSc%OY_mG+|LT0+=g8*7>2s4%~h20ex^lNZ~JtQi2FQ'
    '%j}f}S5+Nj;AW;_)dA+QHN~9Alwnt?{g|V!Ca7e7aCbp|@jxX;4lOsi;2lxlW2j=)gEejXq{32i;Z<e%X1Xt?2%<XoQ-fhmv4xc?'
    'tWE`?cg6G*NPZyp0UQ<+X|qLI-y*Uh7NsZDmI{o6>#)DW$qYL#m*pnJW9aHwzuZ)K?lN>ji=bVAbS<VOu(`JKG)y6VpVBEfxyI&{'
    '@mmHns=M<;LyeBjcdKPl`Axz}JxkGR_J1dI6nOBXK#DeB&qZrrl2K4o7G+AR=0LWj7=l^G@u61(HFW)J;WGe*D5-NYinx}srDD}x'
    '^B)G;XpEsFYIUOEltrmHFIFTaW^bW8DKxw=!x#$;*6N37d;R(DYPW|3%w`=e+Qg>D%pP1bI^C5vhLFT=HDieI(f=c?B1&-N7)L0h'
    '9aB>n0YuAeA;fXy7iW??)(%417YoIu<#LZ<zku@`T~8>OaCSvHMXQR|GNFa~Z9y3@c;VJK09--07z!Ju3w0@#RzhV*oG<!)is0zh'
    'OmC<2yWn6_!--RIKhLr;T04uxs3C(6AG3@D3DlqJ&tD4E8Qwv}$4yH(O6RQ7H=V*gz#FNew=U%31-FD3Q}y*3!)zMCp4rSV6<p$X'
    'IV4lnfPL_Eg{&EE-OEzVA_t20wO{>y=P>Mwj%L#yn~i+6&3$}*#zDhLHmI6`{l{S*sv$-o#oH466_pU<Zv+2{un-AL5TGaTJsj%8'
    'S@vdFh7N5JFC}`<+qq!}oo(SIs9whcmh$xQ<pufl&2ok1tcpFU22*zJ$>dJw;*yz+pmKy)a+}+&h7C2D<#&aHr`@_A-!N0yP_F{R'
    'e^=W~e-U_!MQ*6`Szl&m`=IlPN?zkBJXZ}KC3PLb5~yk*h=NVz!C@>T-6xEI;pE1{2cKmhb2my<%#EBZ-W)1>h{C@&P=!hdjB3CS'
    'WWedvjbO)%uXw3a+BNZeRoJuHAe{vrpv9vvSBK#Mz9LNTlDAl&+Y4!hmL82<OTvNDjWv@xX`hWIX~W$hdtykjDN$d3-wh~@ay0|}'
    'I6E(}tLjAwtv+nlAA7@9+G*UQKfKc(4%QUIFJ=n_&GIrNg=_XvZ7O>p25oTp=sPW*2rLtdj`k3snRXY3dMie`41!4dZ^m}s2Y>=|'
    'JY}>gqa6r3j6O>mrz}ab4A}`)Vd+$b=6#?kq6fvNoN&a9&8i%BXKzrt!V*GYhYnH{;H}&Mdyxw1prW`4!t*6a#4L6Gr4yA%6CCFN'
    'vk*l!FA#-empRIHf_NP+kRDISHYP`R!$v3<5vL%zOsgx*jd)Nee(9Q3?{uQ#Y(svxCQIghd)BFX{LZyBnUNjylKwHYRY{(yC3!U5'
    '^XKNZPyvCh4Hk?EOg$BZ1b$FhV9_y)3hY=b_<@nU4dm4zmo;mPlvdHpU0RE;n^iFgHtpziGLZWj6GwUV)B=CLPYTNWWOe+qa^jIP'
    'Dy)<)wxTTnm7kNZs3r^m5TGxhRn-gb_Ew*o%eR}Cjy6doYZ0))j?EWW#wdOjo?k1KBsLcl@g`{`vGP260n#@tAw$Yu-)U0{tIkg+'
    '6SRdP^@c9Y1@{mTSgN#}bUZDDhLUYh=GJ+_OHN!o_{!Ii@ioe+9$x;zu84L9OTOupc3WX{=-FBw!~RBDe4Nf%h^u1Y%C}8;4OWE+'
    '$qogMRJ5(!-=K)Qc(k`yDgQsf@j#!;61M|S5hYH&qf7#TVoX>*uwv(xXq4=T{PlYM43Lf)$uYAepb}a~65%pm2^u0(3Kz7(kg2hi'
    'C9lvNwLM4Y6?}eoS5PF`QTc+Qel10gRBUxH@pYRp7FOh7Sb`3@S=E~*x|j32$vpY=P(@7nB%Bu^tb!38kqHka9cH%&)t4IW+{9O-'
    'K%{864ht)n>na=ES(JQ~k0>sGAA?a1;A9}ay7VN}^aM8KjaUQVbg$F7XmSjYHi<5Xuk8_q9nq5@$9XD2XmF^u_!$yl)KpZ|GOF(6'
    '(MZRI&`&0E0>UoduG99Q_NK|IIn!7jROk+OysAbb?S?uM3^Y~Y?fRtvZC~a~Xg<#2P*N5fr)|vjlrrOiIbC?vT;nRX!1S>;g|l+h'
    'criD<2?)XmxI)cuJkF4?vjMJ?sby+MlrQ=_+Or{Zel&VddCe|;^|_Pt?2?g2%GX3gNs5P_3=s~ci6n+>A+ji{32K+*$|;EZk6`SH'
    'Nt6wT_=*E^YH~fv^7*LWj(Wf=QXCC@)>Ju%ZqsCvi*$|in`BPTA0p;8jRcT9(OP}dF-Nc#>aG^PBiFMu{R<D!A(Lb%n?T_z1T|TN'
    '3>k+5`vTy`W5XQFrvsfdnO+Rg$S0eP{+31w3&<_(>6}E8%#hNvwp7e68rQ8F9jwg195LxQTIzkqV>26@K-^5`S6n$HGjQiAqr0J~'
    '#E$8pH+ay7ki`;q+H**QP4xiEG|ke?dEv;s>K6PI)kqXIs)Z*LC{aYwa6PwB04IjA^d2ZUH3fx2z=Hv>35*Ygty~VmrC^gvrcPx>'
    'tYxOubZqRxPeMpTQh!SRv~si%BId*C*qe<!XU;Oay2VO<6$SnkcGs?Vg~pp7(s?f&GrDN~7~SW)iofUu+UwM#f(U90<v<EpNjMmL'
    'h2e835~S#~oL8649d6wOo^0?Z-f#JHrb@u<2Tu$|->MV=T1UGKFawM<T6-ODC@c%G%YxESg@(l~b7uLTfH~anklw#0#Jkdfdv4A^'
    '{MrU|ji&B96&n1ECd?Covi50_ucetG>H?K^BeXke)H`)AGofx(H5_3P&NUoraCCK);J4Aq4FmY%S&`}7L`fjGpjf=s!70iuDEjkr'
    '3tGBZQK=0aF?wb6$BRL_mfr!FbGv3oKL%#5&gVmqVncN1uX_pJWPi%@yvZX~1e5d01{CJIS>{zJ=OhDymj~m<I@O&_7(#s$A{miQ'
    'F-f+g<|8<aYsp@w-}@u|$Ym*P0-4?T9Bperlp$8zN<>$ZteJ72Egfpv%I@0|&cZ5)95SdXA>BTpOyrT1?5WXOppDDBcfM}+-8&@-'
    'M^Tp;+(g>fA=5h^-HxPdHk#0o#@xy@EHX=zl*@y_>6Q66(bxQA7TJE!NMoq+Uj)EIm?;I6gIg3GvVmj`N7umAqXP5^=9C`|q`v<u'
    'y-7ZdvROf3IX$-PIcT0_q%O|mWLFaCY-+}YhE7rb!auo7Hj8R^UytnnMjqG<TdVqE`%SBRWBYCI<&(YK728XSL9!|vUY7-;IJtET'
    'Fyy<0v3M_mscI)TKkQS1vlzxT7xJQ+$`cj#ybZ;5RS)GC4;<Cr0mg}>ZpTp%L*lc&@PCKd?f5emcd<n!oO{Lugd&!_MFuWS^>Di+'
    '#cWA_USc?PVrOU2mG_xy=tftgZnZcO<XXxhX}YmGtM|mCc=FsI3fmGmmUQ<%6LybOxnrw)aJX)$+|gAsoJFUVcLXOOm|~6RQmfJr'
    'Q@;e0u6cTxWwEQx3?Akj>`bG$GvNgdiyK*#m8Fn!-V|IdRz>vS5MG8Y4?Rq~wNk$(d6w6uR*H7Y+>Gt?R*?g3$jGV0tGI$~x5+J5'
    'IGDkRwk8TV5Ucc7kwHXZ;;Moh!YHdyoxQ3OOC}6mX2WfdQatJVz9<waeysd2M(SwzxmY@8V!@DZ;l0=jZ=nwA;jAysKuzf{P_)}T'
    'r7!iWel+cJt1oLC7>%aRM<%PWY-N{aG3d(pn4+k3g}h53lTC=HD$DFr%8G>ZwiH}-Wo{g-Nr`U@dz}(RfpBxnlI@K)w#cVEM1Ga!'
    '+-1?KvR-z|dfAEROL}2eRJOCql<pW#(S%qX!|xa!@Nzh1)Bk4L4B=>$i~%r#jdW(ieVfh`%=2Y1q*NdRor8Tf-$QDzH6bVRO;G5H'
    'BC^ay4F-&M`<Dnc9O-bFlG<UW;^D82CVwRkjm6NHOW_2($LMYenW9DKCJsMWX;5^;99f1@ep6%VFUW~#oF<bsV@OJsRfIU;IwYWD'
    'RFg=wV7m!@%vsPCRO#e%06r%hk|74>ld2ujP``F6wTn?-%x`Ad;#$B)uc4xKJ9;f~9{r!}Dk7ZYl!4{WFgG0aClY5+D>06Ux0lTB'
    '*oA><2m0tDi;<S@Wa0o<LnBo)Qc<HcG_)Z3pDyOV8&u5Sot10|y;klxDmY)6#xqPOTGj640&>tP_--0{G@|2u@hYp3sP<2<niUT<'
    '@Xc$Ws7lBAt?4e!6pva=2aNguJ2VH=Z%WN+EE?#usi?FSpFz_t!&VmeO!Yi|Yd%Zu?&Lv^#VIW9QB{>C+P4QA+I<SxnH70iuX3WI'
    'fHB^r*mVOVP>PT7xS`KNNH%UT?6)|=TF!J^9;nSqW(xKs;$%8<gHtgG8fM)nFQ$ejz{oP*#0h1^SV5(Aad}Z{;(QD=GfV`qR-^u0'
    'hG_D5p`tW;0y2*g3n)qXqH~Fc#~Y#EbP3lXI<38&)lMHyIqxZEi5VIG39k)j7%Llv7{Vw-1DaI!dm0Qu)+~pF;n4$yr+W>-BD6&o'
    'AGj1els=l4D~z|E#Ss!cD~kR&%iZIRD~+G6qwBoG>f=i_S8;mM0ojqd;UR--OorlV`k?vdC4q23_Z}~himx)wD2N~G=C>0x*``{A'
    '<)&{N>(Vm08lsV@kJrC6OzQ*~UE0Ad*=v<(OWvlyVcUNo`Yq)_m|vHZ<OotzZZQODvyU<YB4S8L@xivrmb;x9hDsC31{o=y(qZ(%'
    'Pt@yt2Fp$~<(xCgRhrFWpgFDap?0h%_d;2I%Cz-C=PrxVh)%ruHY{~dSOs2zj!84!S}l(8ti))+CpdX;Ur9Hfx~p2UzdI?1Rber+'
    'uWERS27(1Deuf@2yj4|kslBYKv?Q*!suqrcZ+GH80PE7Qbij%$=o_H+Wep^(^Z5)okd`*3mFzIj%_ii>{Zo-xM%a_cknTj|fkg+o'
    'nS?w7e5Q6^0>bljoZa1$5v?$8or63W9nN#3T9)>I6b&7Njn!1-bCo9!2G_~&xOsyL(oWlt3=ecpJ1I^MYFB6iETR;x-6Rw%9cWmd'
    '=41d0J%b>NLxF5E8e;HtIZJ#vqXFol4<W8e!G2D%I!GSAAw!GYbA%DFdL@XI^V$gQ(?stzp>!rY47jyN{phq830m=FkdBi(C0k#E'
    '9CAaWM}sUCNX4lMWkPb5qei8c4Wq%`B)Nrt-n~1@lEKmFY6cSdyLZ~wLBtmVk_#fsFCs4vsjk;>4%fIU(KH*6`giRbN!_#raXeh0'
    '`~?SD!jnt@0@@sTttP)oTLJy^HtDOs(UVC1Ey#!ZmF4O$kloau^BY`5xRS;2cq#VB_*9dt@%1OUM}XexGFNY?tB{|KRi_o5&<&W3'
    'fmW%Ptk>P+!<W7Di}?Ii7r58R*y-0~60pdL2c_Ii)fxD(S+B*Xzh1mLIgWqsot+<^97oImOBHp`_Fo-d^!6{_ob@7|B&Zf+#y$-M'
    '<?DmetxYF6C{-iBG$`FzUys+<*Ud-W4rdT(cyV&kJu;P?tg5``arffzXVYI%wbNdF`1<tZ>;fxc^aJtv;OK~)YRpi(0Of!7&Q5~p'
    'rBCtxtL_=rg@yZDiarjF`ufJ^*7nZs(`V0<t3F(*z@u^h#Pc^VF3x&{McDICY|FVC0(buA<;%nWAP^e$cKRtL-{Zk}O#hwU2`e+&'
    'Q_-1N&wa6+g8ebBNllXr1CG)lA-aT&&>AsX104cLZih%lt;r_Br>pkwdiOTO49Ov`DF=^V0_oVRsVEA2+R8)-Q|vde6O;>Nd6#GC'
    'yFra~BJscg!llsm;~;3nlcl0$Bdp|bD8fqt>8avlmI5V_d`_HDZ=zXO)Z9)KWtGYma+RCIR>0dxGT9@UTtp~I1w)0uW__8CSZfVY'
    '`A9xSdZsXm>(Rvgwy`ooB@*qOJxTzt9W7$Jo^lh2tFIF=gSc1dB~KV7%Z&8Ic87LepYr?4wg4OV@X@MrG<cq5lfR|2OaKl0oUk3t'
    'dtYeI!7ZBbRzmw|S=#B~5#@!X{JBYHcmif*2WOpMatq<bj-MHJ(IBG{0k?6DLO)zaBARx{FQGjlpHmkJ_-zjr*5Yv?GD!9;zr(_S'
    '-1|*G)D3lQJkIqRGIMl{ST)IvIWSrxV3evo<~Cz{%`mfNin0K;{XjfCVS_Zakp|16OIv&skk!?dWFFeJk+R8~=h!QY?tFV?l^L0e'
    ')pYY@n3}|C<$~8T>!F}YaxD;t!Y|khe^;j7CSu4F+pbwuFaa2xVicmX*}!b?X7qiu{%Lc)bXPas4dO3Dz;=mZTPTDx!wa=*C>kfl'
    'bLxx0ywe%|Cs};L|4bI+`j_bM>_K!`|BRBs=+l?aC{BO+QWwG*eIuC>db-87<LSIEBsZ!^dkTZ%Ha1#twKwg!36>dHK_HKs6~1CN'
    'HyCb+N>RP(A=*MGb?hPe-@gB${`dd=?Y}j>0VKY#^Nl9@UNQ@LaYP7zPGBwpJYoI;D~DvnH+Z{OSMrRBjVzCt@wL~Udk(#`=^H<C'
    'E1T(sX`4t+p>!9KrE_J94#6MH$hi+>tg)#`%R?m%(~tFpK!pl0Y-}A{IQTMEj|So!c~puaR_Yqv#?WXHJYC_@!(2s0k5uni-NMa$'
    'l}=Kn5m7+`l-I0t5j!!Q`KXvWEE9HFp6*3hta$JV?Ka)fZjr6qgL>f@&JFEu&%N+{1rcSBRPz>2OvWyY9I({hG;!`FKji7R2BdE='
    'fi~raU_6e~N0p<c+@j-b_VC>40a0u@2!V9z+B|hh49;cdU!ormw-xa6bt7~Jcpqzb1=!l^(K(mx%%UlWSKkk7xN1*-)|9M8(3iwR'
    'kuZyGW&2f<K3&T@GTI3fHdr{Hd~t<u*?U@<VqyaDgO2}}C*9)Vq30HlB+2B=`WFn(?@lP>lb(Fk>3`vGJA@+^vQAYMKF*~V?cYwH'
    '%!56eu~?XYSzVG0CtOg`%21<%%+AVzG@GM}8AAbdqIE4epr^dx*5uG^FpgWS*YYDh;$P5Z7`+sCFc6DU7!*5<KMtTmJX$`LUf@NC'
    'w2OuTgVkjS3xFokBfG?j`LR3kvm3mY(r#hMN9q9n>!{CG04hNA86p@{YH`F<u`2Bt|7eyYL50b}x-sm5tI+_CpFNg;D20?Ah|Spv'
    'RaTiw83z`q^<89%OXXnu?ad{@F~v6ecVa=TB{Ze-h%p6bwPiA0gu?aOp*dfgtWx$qZ4qSVMxh5XdG@sxfQ%<BJ~yk90VLC+rJ@9|'
    'UszW2x6VfLV`yG-uXf&=V8f3T=#CdufDT8D``H*sAo&t|L8&-x^$4b-k5--4s3dFZ`bt_vT_E3~PvQ}jqsoOwO^0{pE+yiPw`n$4'
    '1G{K#2N+;x$<nfZLJN#tgw~h7-+OsAgDD|&5uh(3{=8*rh@HIU*om&olpJsO);2CJ;oR3m;LKz%O&~rS4#AQ3y&a@V<kF%lzulw0'
    'E<LlCN@S9ET}&*od^K`e5Sqgat)Q<D0ztm^TkGO?vTQHj#X5qfD+-iE<TWd3MEZX&-k)jlf@pCUFbW}}J!4Tia7ouMYu*I*{-}8s'
    'FS$Fc=clSTol5I#?S8A@N91x~A|}vm^shx|D^(hzKxR>E(k`Gm8d3dacL^K+@AmlC)nYodZWi|WJ{Jp<I|&AqOSlZS$L|l613jFQ'
    'Uyl3ni!HY@(|t0<2s}*~p&w-=J3O)Hm}TYr;vQIm0u^t?FX2|~fntiL!ai&FExYdj-`=}-w{abbga6}Gbl|fazy={wvONxMc!#E_'
    'm=lWBkEAST6rNTSXp$X)Xbc(<#W>#2zV*28M|T6HJegVN%p@ZEKI_)4TkmpWwCrkSrh}@XxcALvY$h`#KNn;Umt_Uyhm_K`2I*}8'
    'h8M<ce#pI?&QNq1aEVN6&&BCz{8{jKH${_?ilAm-eFWyP>et$8&R#+sKc7R~eVHCX9lw`!&**SSHNv|h?}ff^&U)+OAr;PW98u!E'
    'EF87EnvN>2t<JSbzjbcOMZZlC7qc&#3~C0>h6|1%n@_jFs3T+E5ntoOLHo+D5+xXs$Fgs#eyCZSbwyGY$VE9G;~`WObs1WX?a4UW'
    'f4r|~os0?>qLMO)_)?Oc!2n+X)!%v(^soH~z(iOVySCqsT!;CZq0Kj&&(X6a_}$;b1D2)ZG{l*Ccbqv^O>5L0eYUeR{6{f2>!ilJ'
    'JU=?B+O<3?F3pDKM_WzY_Jjkm3w51rh_t_>5daHzp!WUUO+tZX4wczW!o(;3M(@UGX2avXTT3+~Py4QaQqDWSn*>6(1BB6--lLf@'
    'c7O}KRFW%Tc1gtfDc?m|%aoZWhfkusz3dXMoL*&ZbkR{{@FL$>Ol!*#r_vRUytEeNl0~B8G^2FdfEGjgw@4Ibq$pDUki<7byZJO*'
    '0xI58;^ezx_UtK_LBVgg*+-!peERw4&z@46&O}v&jG!9gq=jcVQV`b!ZUFLLmEB#b8iLm5hqt@WE{v<$b+9HJ$Jmt@!y4AfOVDM{'
    '4Y5N0!>W^k`GCwO#xL$v_u~wX$Zl@`X!M|?fksXNp#q*Kl52MPAcyh?ry9_#Op&0gX5w$B)dXbc^lkwkDAE*7V5&#pn^8*0M(9+<'
    'Z`!ErxJ;M<^@!k(XP7S$IA{_>i`dDB&e}iP$Z^)6o_A7f^8FT^>KIzH5TLc`i*Oi<>)<28Q5H+f0AqUMga@~hvC-{_ECL>}-m^in'
    'volD(3h~A3v$pyXw8j3oz~JD?MF7wNnWx|J%LM&lWK6H|H7Hp1!;7wym>79N>*G&)ZS9vN(t)nM7!%ol!xc52si(v;4%xYd!DU-b'
    'YysCl@5rW1E-<=5vX@tg3zIELBDZLA39LAOCRZDYf0ROmAwWq278ahu#GrBdb}8M~5tQO12c@KSIcHwkx~#K#gaJu(4LG@)d%;Y}'
    ';+6CiT=<WGR@7q){doMMAM}BKv<Kmr`B$@!yZesdxC+*eK%(9OYV{WV@x5ZQ#wV`kL3LKJ$O#%H@MANS>_sRSy@0a0NAU`Sny`m~'
    't&yzW7jvm~q=Mf4-C#}-8G$Xv@8UJk3sB+Xak)vYHJ`0+bMhWaSF`K`v?8kS<tqH8+a<U6UjJ9?({MGX=;L36M<TX}85e)mT54mT'
    'yI#_Qx8~=7`QT!hO(wnCMo%w%n^TSL5RRjoX4MTEld>ymhH?h=l9*#tW#w^A74^#efMLRauN6Fa2HrN#+R~o(KXzAYAj1z4FKJ~i'
    '#joYz#ilC)PxoYK-x6hQzHb}19^Ecw`}6V=*jZ3pgj3I`4wDm3Es2vDrR9pIoZu-^b=!12kPe?fz%gr`(scFvk)#u%pM5Za{%!4A'
    '?QC?~`h@ej`Zya%mVHq>G6Z}W`fb-1G&LFTj$FVmM#WK7Bt9V(B7HT2OjK2^$2?rS5CkDSMH<86S&w3ueF)%q4SwrTZH?#R-6Q0e'
    'G0pNt!n?W4ZydX&QzE#4UwU?@t|#9j^ozpYL*}?{vyUQe6#NUV{q&7oq}JRHInntywbo}_Icoo5q$jSQf!x1*<9W>Ay1`vr?zh1S'
    'n`RC>V9U^|>`oroYUk@7YPVG-lk(~ct^@@T(qR?S9uMp0Zy1_{@DP7}kvvVlC*a^XH5?Nq7MPhPYOx%cVu(T0qAm~)^HvPLYs_*%'
    'yv=e+9En{1v!@SU{+GYW^1lo&|LZRwy!>x|ljVOCT0UK%af&5QX4mx_G46b9E8maW?SrRtZ6~uyN>v{)vkgeFYNUbQLnuNVU4-NS'
    '=&=G_hL{zmciH{hc2{;D=<(Gh#tyK7wO1<R9t=S5!dMq3aR>$+HI5t#>YB?e9F=)KhO@jASsg2-Cn+PrG)Nlx%XgFk0NFO&-tJS9'
    'tS-AR|Fc`So#GY~Xgh|>JQXK5()WCjY=3;VuZ!BMHs4_pQaP>udDm!ycaT@}>fmqNaJuWRXbb}(<7|$oYA;JdI-q9sNNj)n=4-Rs'
    'qCbnND8x9T)qHNcZB`t|54^@|#$d1}L88bFOA!enJ@@^FJ6{`KLFTC6aTQDZ$M2IreO-%wW@`sZaxGX)UMzB3-Fx}%3unm&2_w~+'
    'UcYQ7Ao_Ishq{HSQEzgp7Gp1sp5yXLe5`E5GS>F>w#;UTNPtR1YAT4e)%59?wr}vgaaf_DcecOjyU<_|z(MRhO-zADpHM9lH9IWd'
    'r_!IsT*=N;*B4o~gO8YP17DWdiEXwZi8q1eSfjhBDwkzr>F3Fp+if2|(KE6jr`E3HR%*>^%%aGXyG-tn%hSF}#e!3Y$_uKILp`y5'
    'uQf=+3p93yJM28|o4j+~*z)=-MQce(gd(k<Zd)>q+2IR4QxNiNLEk(9S>dne?47v&o(aBzT0(zduFd#exRv7zxcHC>a@~V}5<@c3'
    'IWjQAjLm4tJ%7j~dm?V<cGD(trl5$;V>!gfb8^L2UnByu$ig@s1{&P`Mz7cCa!e`UL*}O;b*i6oa@9fN!+*Xs0M5>ye30J8aQ7nt'
    '1lprHn7@-rK3!%Bci2jdHCi6J*yalrNF~=1E<vd`Cy`8S07jsZ`mT;Z_ux9un;pG?vysq!`$8k8);$rq(5x~uV1%deUl##-<I`(N'
    'alUaU_pUeGnb4L0(zr4rQ>D=6gszPU$(&~Q`GoVo#PbNcY5JK+J$ow75r<$0il^J=G2pc5d$G;tR_;cB$}1_tdW=j^pSu$^otsEd'
    'XQ`e1`%A8P0EEybvMW0ZQsHh_uK54@1nXl}sC8+976SdqSXa*x^ff^fw6Z5p+@(1*M&X`KPYu*_`VYJTJD!2l2%`$1<W-SRC-{o8'
    'T95x!%XVQ5JNU96%s7iGIi4;+H!WCU2(_P&HowgZu8qW~OaHSK+jmX>4Pa<b-Vf12+#X3i-bB0p++R2&UPP+)ZiI^RKbMO<dvE6^'
    '1|&`CLdz<pI~U&l7hj%T_#rsliqax-qwS02|4#njoi^`a%Y{4hAma4Q$#w#ek_KTSl$eA>Y%_RFR@?6k+2RwNfB|oN-YsL^&|Q%o'
    '9}%!LWC-=;T>a*9-2%P=h10+szpt`KP@)5?er>2=x0CrHnC_u*|1^ITr+n8A31%Z36y*i<Ptmp+1V0-#gy8qx+RxJBKyOG>(Ag#c'
    'pn)aRMHVghUDfn=?YD3>)17^;%d%_HI;2#<d3q4@2J+v6vTK%XM^;A#ioh-TpMJw<{cxr`hlz?zs<<eTlw%O<A6$v<O}Y2%@;@R#'
    'X~sDN7v-IB$uKi(bd=+*sR!g_b}iL|j(*UzoH#+*Ed#N|f`!)7Q*qi^?NpT=TYlH+DjE`1h-CjNVFe!zd7~g?t&A1c!b0pm2l;RW'
    'KZo*IQeass3;HkQiH6glS9RBnKBF`wwRfRu9qVMy2yl;AI^kc>gNH*Gq%NBV$3%WE`3vO0F|k5?@i_TL>eB=R;rCFnmDpaEX=`;9'
    '?X`qkxu&|N`Cv<#`Yc3x#dm}NkM(`XHW3{b*Zv3QHewH4U=_{pO^Y|D&AZd$?P<q#wmD>d(BWrBM-W$>%gso!z(2Oorq~PdvMU5%'
    'JAQxU6q*pg9baPFYmjL<;7(VA6>C*Z+NIpI7pKC2{Y0B`TueE_FCuWZ%s(MNZu+h=QI%Vf9kt?GQe6#C`4jtoOtag|NhS>cOnPuC'
    '`p1r$GqJ`k&3Okrs0Y)88qBC>PI{6E#xwBA7Q=-~H$Vv<x2)CLFRM`#nch@k`Ls$ShqA$19PTpzxa15`PUbTh2szPe)U7B}e%JDF'
    'Fd5gl+FQr$1Wb^Xog0>t@MDr=SP<u2z+WtvD(Mu4Ek%#v6jwLz^{p(5pSkaZm#}~`(W+c!1ND&5n1)Z<$UtKwdoAV19g3+3D*Y<`'
    '=`L5zA~V^lH<-hqvA)81x|-x$)qMpBx@AWN4piVp!?PTPwpfdJQyKPcM+#kMA(eW0b49?vP<7zle9#u#Zm%h5x_a9UgiA*TvmRdU'
    '-c04hZFhC+n)yK(SUj_C&sO4A7`S_d{C77rPGfj;zYWkrrRq&;qOw|w03wmZ&Iuo~6XE6ARAm|vw56P<ftaH4O@5oT%OFsnI>3z_'
    'a<d4Se;X_HDtPHuHko%qkl@^&JxzgIVJWCF;z({koM$edP6Ba9GT4A&#D^^EF02*l-khQW0fq!Fx`uXfL(LOeZUuf0;b2gF&1qfK'
    '#oYS6Fej=vse`u2J?j^-A;Sq)FoJ7S!S#`b?R+jg+>8ojPM3J$xCkKhpeg`A<fLa9HDvoi(gKK$(aU~U-*eE22oHq-_#m*oKK)v9'
    'VxuiaQXZMXK}ax)cNVvtTodi8c2bTaez`r22q_$I2mQ4s--cJB&|j=GkX)*j8o_E2N-3h#-FVB2MOxW8Krr^65@(vvmO=zG7|j|#'
    '_Ds6X+5nmMW<FRt34jg&5)VUN1Q0hdLV)a$T#CvI#=M$u71d6$zYxIcI?C5K*byO{Y9=T&>9d`k6w@krA0vUW{1p>sa&}oac-V?#'
    '(gc$?7>Z<Clp;N=rLoy{l{-9wh;r(L6dk>PX^=aq|9RJcuy`1E#k*E|8lSbnweOngG3?EF8`)KvZ=S@)Ra@JYe+})8hBgUj<rfYT'
    'd`ychT)Y_qNF>9wIC}%_E<9aZpiOk{+QhGL8B!^NsX?u)5}*UB6Qu^m5(zU)=_+2xU;TVa*fYFqHRfA2qTaU7dmrS<<3oo=wd7y3'
    '0jW|+cCd4>1QHJ!-P)xfjxG`y$j~ap#_^rP=>zkbP1c8vP4TS5x1*D5Ux9GmhhMr@Wg{**!oUxPe};pdo%l~@!6XdZ)9l7WnT-|f'
    'vI9k(TpV1Ecr1x(iS%>yZ>+kSjI6BZ(iULEs3Qa5r=A;W?v)6Q7?=JX7}u4|5+l`EWP$*xGQdh3@LweQ<*i4cjr=g8g+ZAw1~$c~'
    'TdRlvZe&1iNN5yiSad%}N)Y^%Sg%-wOZP7ZdU=Y#Usww>#({-t&^Iki_j48o<Ld3bjlu6?=w_SJw1yt1dWb}`Khy*uX&sZ=<l7kB'
    'E<_;GAPHm(Xespg$@#)@OPej(JkZ!`y{ty<H9FCy*1sY-)}Bi&1P4*1=h1XadB~lF&|D{-QbV=ZhrB!C?a}*#E=MkIj{JAfj7iqJ'
    '?YDV-M2XS0fg2xDG!8^r__e0|oyA@XyFQeidEeBCNBTeM_MJ*mI&rE2vE-ln7bNsfF^R^+8}<_=!6u$4sb;hCZn%m!I|GMoVDXvJ'
    '>D6#ylfDc7dJ}64`)4bgXT;7Kvu#G~nWls#x7lzQ&CpN>Vp}T}(AOB-Gn%m;Ml%YgcZfKBM<II=@oym-tDks-(XoF+d>sUcwDX(Y'
    'Oywry9UG|%X>r=oB~(E5ESF_!IFB3^VMbR<5w}b((_CBHsHFTvvqP%5v?}SDrq#3rc&1iT#%`Tn+f`Os-;h76?ACDA%uDTl;~LWT'
    '?;@=W7bvwqP0R6n>j$nCtGHz4>zxAr70WaQ6q{ZR5@$o6xq&N;0n_QMcaYeNF>n+I9=ediC{6npr@gB$9=R)V+S9U>J2Cy$cZal>'
    'tQtGNhq?*q+rA|H+1@w02U|Zlt?^uNVp(x|czOiC^xQc`WnbyNO<(_gz9{GUVtKF5&Ve8up<hBR2>;lS4lHViblS#-wBg~72v_Xz'
    '_EzM3mW$lFELWInk*o2NJ1)~LQHvLu9GFq%cl6!<0!K4sdtT2B4iYVhX%aWUs@_YMdsSx2FCl#4mrs@b-8zU~ws@+kjwL0FiXAMj'
    'ihQB+<#3)lIhZax**24gwfC5drgfYSw2&uNd(jXR_Jme|i<Mkfq<IT(0i7>qK1fPchj}5WwyLx2*JZX2AD?*RhIt`K=B;Y<_7T*d'
    'O$>r=I_|@Qg{NUHP-uubE3g>&#w9qX2d{WGotAgVW_gRDMFf+3IF5-kfL)KAaV#fElYXN25vG{Hy#L7evNWM;QTI&)n(NxQ+1>)l'
    '&DFrTz!42T)N+zolBvq^*27!dXgy@1TFrux=KLg1juTp*k?6!*jF~n>NM|A@s8OVq|7pw%VoH5$`f=Oa4-0(`y`b5Q2up;A7=|xu'
    'lp+{eAnZK9eC;JrlUHnG64#!3eGB*t-)Xi4bI7(Q0M>O45wQAO%eMh_FT9>^TbOcly1v3l7QdGdx|X3sszFnIquvH?(}fv4n_uHa'
    'SkPO~#qNFfpf>W4j+h4l`aZqaZ#?=7Vx{TlM@P(5ew)0{^La8Z%lF8hAuOlFis%2Gw7!|VsyPi#aW@bKR>L}3K}C~^c4IW$8%p$Q'
    'p^rxA`)-6Jm(@_p$z723Jv+ZOOEZ<Q=1jAB5l9fIWM$yfLw?u6$R4k#R}es9cVV7LdZ}7FGV-|vBYz@E-Q<e+6xjh6eSXlvl_rZg'
    'E(f=!sW%QbB<zZ~X*aJ*E2pYzy~9#>*vm;5lW};foz~dvGKcb-DC%Ip!@uzb4xUX=$gIES5;vIHu?TedxHQRa9+-9(N*WqP1cRX0'
    'w{f&B!8WEOA8i>h4oT)uy-aLe;&@Ix_3&uHD_L8#S+ih;6S&xXbs`uez1q|94F(h|lO0tnpu74>@Rx6ry#;dg_6g?Q4IEvYw?&Yv'
    'k>B>MSuwAXS~XCrc2tUYBdKzPDA5#QiWH9`4$`aPyqx<FGA|;A3;gx%_JzwiiO^_rM6Z@T<BIn?F*=}L2($HWd!QR+;*$Vg;yX>z'
    '1bDo-k!4EY0JnHseqbG2=q+(HakAUv9Fe0Qqkw%wmzkqJS12=G6=akK8*iI6)<;7x3MY`FdWZfsfWyqj`DHeK?@l65&=_Zt&()Hw'
    '&=X_s?swv}w!~>|;d}Ib*GjZU{60~0nOIZk!Iba!k`$%ehNhpB`q_~loJ&(EBxXvP=4H?gio3?l_f9osETk-jU9Xt(r>Ub{SMM6b'
    '3C~`?cyaji!I^U(P1vX^%$O9@I1;msJO)FXX2%o_l4^BzReTI64GqZ%-I8RytO(MSqrBZswkR7d4b#66Z5E+2s2v^Cwj=^i53f|@'
    'cdf+FOP4+tm2^!r^Ih22-fE-shX^A)uS#e%+bA)qgRex!N7V#)cc?3}Li>TS3<-ZBSJNFJ+mO;KYoq=^`jM2&-6TCFk60PwOs5dl'
    ';%XJXxGW;FC0YzYdBlmsH2r$R)w$Fi6tZ-4vVKd!tlfHz{$!xmU*vk4BCw?YI~Odd(o5j^;h*Nn1A;&+Ju{6`u9k=e<bGmlnWxgq'
    'Xu3bc&-3tv8iA#^S(nN(IRlLlWti1;++nSTFwuMp<hqB3-2v5KwFwAMf?8<tPZ1!d@Msv7L~DS7S|7jmY&SHu3P|h9;%vhG``5K*'
    'bNw1L1Ud6NQWBo<3$}f$1#tbUu4UGiFdQh2l!gauW4#B%OqV3%DGetGb1iL)8cQv)7|x`aRO#6qGTFTdEyXxrVexkcU8BCTz{e3E'
    'PoxmEx8{-S#gEj}X=QnfSgkj$2hC3jKui%@6-Y_Kn*TfO&|OvNVeJm*ULpWJ;Xn>g%?3(o+G%DpuT1++D%S7$t}D&ra6AXXx^-8~'
    '((HEf^_MW;q&tYT%`S^)wGG1GBKn?|ka9QEkLz_D;JG~kj_RjwbP!);LUB~UF=h^_xp&C^nLLlPXUX;S!&tQDlu`*lu=x)jE2z)+'
    'UveK)<ftPxd>|1{ab3(t{_CxS!sQEsQQ`QE^!xrWcyc5BFaML?&`AH&Z>ALbBR96vdrEPsBXth`RU}K$$Ve9-Xag+uNae8~bm9sc'
    'I8g~bO+KqNElb($WpTYKSCvD~#At8j49JSJfyv+vr89-#120#_RGFM8cUqVMWCuvjc<u6d>oSv;1EOQc+QjRSQrgu)RdWAzJ^+Dq'
    'emk5el$mIU;D|CV@=~!u)#kh3?$US{{ZI-G?CkiU@~=aU)@{*3G*5W|$3a>gyQq=$YEgc?Kd0>Dz{Sg)PI3=|4e9s$US&p+1LAs-'
    '&2M^&8JkJs#iuSxmeA!hg+9;sNdR*m6spzT6$PH?K-?jHmPyOwC~eEyJz>^LPW-lKOh&A}DZUzumSu!pHMbXxY1bkX@O1~`8Zh4Q'
    'B99GvD299BS2JeTYSKR7Q@SNaiU}DlZ9Rxx6V0Ao&nxT5dTEoq>?~wO<JQ49zb9CUM0lJw)NyIO!JrP2RW$DT>e?w{p_|q;@)lQL'
    '+sLb$@+hNwCmT^SdF_P8>3Hw_@TY?oDkt-%a;*nbkW!b=PSrJ#$e=EvS;SoSS}*k(UCdBweO1EBAUx8Hp(w~aN^Cfpmq;2%KES#-'
    'gau8W$4MAucJ7-AM~wP}_@_f>TPFC47ksiesVaZ*to|nPic*_D7%rwfmEO=A36<RNXMQyj-mCe9$b|CwEVbH**r|I`i-<&)#`$@~'
    'e2}D#C#h6%5#48(;)5L0V=Q3^3xlUJTTPd}NX{g&mbVvum6_dLsXia~RHUorZqQR+=AKHvP|2r!C4%KuAI#8Z?&n(M6K$7R%<+>)'
    'pV&!x7c__%=Sj8cd^e%E425Vzd_riYgQV9F`ihBep~T~j$hw*VzgbQ{<dd{qcq}*FSB;*37<tfbfK%{}GSfx&cgN(!&%U~ZMv^T0'
    '@cF<_l;F51vtnI5?kX)Z6^~ZcGx@VsSlam(NtZK_Y-U!>Qc<qn^jQss68t3C$|OrTLRxJtSt0Mr{!MzV%EL){vyy3S$aLi0J9GAT'
    '@9^QwL|8&L$>!)V#g^vc8V(s2Bf6Q_P|1TL6jc3f`m?`#H%yYlWpcZ!mXfp1jQzueWYtNQHyM>45`_S8%qQA6hcpwY@zTUt$TXEW'
    'NA}zmS})w6U_;)$8^E7-!A00Gj`i-HZI*+z(qQK|Ir%C95NO#r696}x;-L3<;!7?@s*XVM>=OJ5p#vZE6jvnBgny^mmoSSQQu!Vl'
    'aUjG^$>X<>8B4W_^fM{vZPN*yOoSgq(Yx<pwvNehvAyU1z+Gbn=&ip@fb=_7R!leVl(98K{&i&_ot0t`4sITVW0MCetZATwka#V@'
    'qPFJch_es^fkWkL6>clH3X6NDET?>j@H(*!CKiqB#W*2f_o!mEYYJosq2lO^dNL$Cn*JpSL}L`^p|j&!<OZBLLC4wQzu<|c%rFHx'
    'pY*!jK_4q(MEnw&MvN??*<%p0+{m$t183wG8L@d}p;+idQkX`|9oOU~YCA-vV)EMKG$mVVI}Ujfgu6GpYN|UCDgGi-BcWxq7rOyg'
    'WEZW<^D(B&rRu48z9239-rD)QMO@q>UTw9GY!L^xcD`$Z{g)uDfHhBrvi=w40=LWHwcUdlRKMEsj*feV=i%X<nVL{0a4@~O{f{(C'
    '$JghMudaQkj@Fa4Xc&*c9|V@;r&5LguOY8}JGk^AP~<!t5h#j}F(|fn9F6EA1Kub$Y}I3F{VLLi@A{jUnZ$Q}?E2Ln!wu*R?aq2k'
    'v<&NezA<X=dcJW|;ij#{K?!aX-yKhv9jarFg_c5{jGd7*7qz6B#vs}RlSiTL4%mYX4LK1I)v3V&)?CqQj+j!DMb8ToMj5j2=y!^L'
    '=r`R`=>DReMA$)ukI7Py>cM~2@sdV#svGRuWQqx1E8vT|-E~l^jVE>MD=8!(U(oA092I4DY<G8b%(~ow!|*vr<6L$Ns_u;xD%&4m'
    '_W`wS&=XZHVz=27zQO&p+4a<lNMQeLLnS~0ZCEjo&BiyF*Vd{<Q6qoj9|=|}Cb>;W$}|QEb1c@4L2`zU7}}4%NYE7cN+A*n$=i@E'
    '$Jva%Rp>s4#6(PO3GEG`kYR<x6ufUKt;0mv6#7qAR0=PlFy?G=|1Eu(mUsDLYYK-nWyxnDoN6l}j*GVfrd*+jc6m?TC|gK*hoa2*'
    '1}+=A5iYAGyd$<~N<!$oz|4%NuaD0UUmm0{_l^%=9Gsn}XFu-A$Ur~usqENqPDdx3`bjJF>_8O$^WgME%-JHv9Spac!7GC*E4O~B'
    'lj4<+JCxnGU4~cA?)soL)ubYlFp$cDbpYxWYR8(7!JQL}<BVhNn{R)(FNto-PHiS)_0<tkpu75r5Y!Dp9(U6BWFB6N`n{;&9xP$1'
    '+<HHRE-wyAUR;U_*afV`KP>&|=^^UU!kVdJy`3v>fIv=Iu@XNYtS047ZdScfHpH8pE)0xZ1=d1-%nfKA!>8DQIeNF-Z#*?Ozii-*'
    '4dJ1eS;as<>y2acC}UvHdQAiGS?r4XR!M#tM)IxE_sP=3S)L4W^|)B)z%bE<6^0|1BXO_c$hbI$1E{g4k)aX|z<LzrZ%m!fi2sn8'
    'WZ?NZxw_(-5P*k^E%|=l;h|2->qOp7;#KfPJKTBp<Z$P!WSXtuNa-2;P~>;;JmZ@xy~nT{J&v<7c>~;Ic~>QSuMV*=)-=Bbo-U&|'
    'mNe3pDD;S-i&X2O!#-kE85rK`z2s_zN0ngA25ga)%40a%WzLT_v+im|)v6*;kjA?MBi`a|o8C*d0zF{lqW+`2OfEr$f#C}zaKMPI'
    ';0=IbX9)fe*q%6nd@|_3z1_ORurV?iTmlpDA>#_v44rJL7!cYSvNR>`7#0c>4Virbv2Iy)@{jpq4Ez=w9*WuDStWjzy~l8QnEyVR'
    'lmr=Q4n()8Zk$EmWFHE+ya@PQRSJXyfIdiH070?|7Y3<V1z#9^3A0eNWMEI2`MJ9R!M_752IQR#eLcRoG6*OEvTSy*!9HJbu?~5#'
    '#9QLH6`BJ%@$B+uQLe6U5*QUaBIAW6&=!?o$t3#dYynjwE*`9Fc2!)j#02Psn=Rf`X=PysN7D|U*y73A^S=z_dMm+t0fx_4%K>x+'
    '4tEUA0L^dmB`zI~UE=km$gXE)wFCfGtMNF`;pB%MN+!kgplR?%{=2N?zi5rb;G*)DQd^-_l|QPV23!f18=~KZYT~*}sV0bPqRqZ|'
    'f7R1EP@yV=1bQyZaS8uALme(W#)IUX^0Ie2RG{nR=qNorK0i49Y40dKJJ>%tetw3YHp8c1S<Y9eghV3|)<iGg%R*nORt2SkP&s<N'
    ')M8H2Ff;udA_evopRM1y3QSQ^?Z=+|4R+ld-(*OJ@&&e;&Q`ZQdSBJgC_;6I=@ut0w0<^b(^<z(klg*i1Z5vd32c|bR(nE-F-u9p'
    '>B}|=KPKNYy<*rW1SUeh9EFbg4SXcRSxx~f;hrFEM;o<HN)|}p1v6Cerg2Ep=lHjE47)lk32XcbAMikktMcff@!V8KEHdF24Q=mt'
    'GaSfuT0)woi*5G0^l+qtHm73&r<BKv)Ks^3W+gzD^;;vj=={Cr>YU!eiuTj1A+Mde5BP`s(O&$>-HvX)nj-**>YT-i*hu(BJhcKD'
    'd-5J@+&h$ygM3`XcD{8*R{1^{Lahj*KtEO+`S|@z)msT`O#fb9_N>hg67d@BCfye(v(t+A`M0hpB+jo)sve%*<Z4=GOTlvjdUmN7'
    'JX&Y4c=Um{GK}o&hunX`2Z`}~1IUVN6s4CXy{-79YQ_GZ2?>YKpy!J*yjtDn5^e-cm@n5hc30B`k0TOb(fA3zy!vJXsxlXVtOhOa'
    'mUM{t1`+)&HSt5b!9D@<Gdtjq3+w_rBJ#m6GB8d2WC7jC<~hE_Ncy#=hV}!SxP?PPnscd`6#2l@n=8-eTbYwbs7&%15XrH&)=AEV'
    'a=#G)%@ngm{Ek-1WYPc(+#EtpAW~u665J^O=L#`UG*%$H%aLms|JSNmP+CVTBfu`*irsfn+Wc;q9CBSKSckfGg8VWcb(QD>&eL*s'
    'y)`8-j++ws7l2v`@B0jMG9}B5dfm-{hqx)`-zFup0(VG2#?u@ct>y^Hj_D>udmyLTjLs@A7Gl(UWc{abnoC#(U@<Z)i(6zJ3{*FB'
    '^AJxi#}qF>#rI>^zcF@LD$;-J4js_@l4uX2IKoOF618rEo^g*(Wdr1P^V>OKL^;oZqe%3tz`*7s&I~wfp#uRf6<-SMsA6Uz1vsZG'
    'R_{qX6Ey3ORWb#^31475C5@tVTCnjFS#No0JW4JBr?_qh?S{z8>Vs745l%Iz#zRsMTmvRD<ZaR7knSjF6H&gF*&xlJ076d+xTgzb'
    '6p3dx;G_tT5QvaRMRh$YenGzFb#|N-4)O@zy~7vr-8*iLh<S%%i99%QnJ;Od0^77=Q{>oL7z7X?188Ot3w}U=!JcV#Dy4C9)};}M'
    'l&lOOMkIEfqH)AY{;?w21YSxT_02a=V|L)VJI)q}%qR)bd58oVo+N4r9!$wG3%-8jr0~oS9lT)3deRqo=2A_rQ%S-N28)8d&D)Bv'
    'Mk*)N=>Y6n6_hTE-WTI~DA%N7wndjw5H$NWo|n_98lSTlP(4XClUf?c#229?Y#HWZLlG9b;lrb`hcl5_5F^ICK-?ZvjFi6?gb`i-'
    'z!C^Lp*6t%1jR6)KyxL?>@5w<m9V#0ph|-iN78Nq<hH^hEWufh0X@EzM9*G`ai<H+SoVGfbS1VBbv6R6TCM7AS<d0c6R5YeRze@c'
    'm0)j3qBl5*y9^f;2F@ZE$w17vBZiIaog=eD8E7fCu|+t86wW_8p0@MvN_g#oNcxX_#`Vg@b@sSI&9$n`u-W4J!;|sd<VimJPyhj^'
    'EmpH^Ufl?P3uOE?RAwK_v2#aoh+P(Eb)q`9oZL-zm6Qn+C>K&)4m~Py@u*T<e#@oP<$#08Xf+ZSj@OqF;ao&`K*?y7ghey95?KV}'
    'onnuGoH8!wKvd|fG8NPG=AtmkL!gMaAqlcph7zZ5ca^YAXTtv~X697=M_IcB7eG3+CivN0k@yq8loeOiz<m4_bzg5i&?CGY$A|$3'
    'AF^JwnZiKv_^Cl79Y-J?)q~y|M%i4-_VOVbxbM3|5R74f+G^*r`k#j(F~2t$F!ZTAqQi=P6=&J-S(n4D@tAwq2{2%%6Y?#^I>eD0'
    '>=-u7%_v)3KKm34!Ewozg{SH}Nk1g6_|<|5Zp4QU)3jm}i=t{>ymlDdWZc^pz2I_miTbr^%nq<#h^JmN1$5Rw9rS9v;&<pkyg9pJ'
    '*3Dte)?wmE5R{KMGja`$i2G_co?_H?Z3fM5Ww0Wt@~<`c(O^RqJyNBCj)I_RY`0CzVTlu{2ZE4j5c>K7mP|>ie1Sq;8#SAxB=2GJ'
    'tr4X#YKcrzm3B&8oz~szl}g7DV1&M95l?V{Y;m{+xxeyE09B<K5qKe%x!$j#vt<TE;&BkWZ8f{p&OAWB4j%yB2CQ(imFBnnP+lR!'
    'llQ2B=w`Pwza-zIIbd6<%8kWRu?_g=fA3;pamjb~lD``zQR{}a5fF1zCeYHj*%K%$G@KqQYehN<>2^1$w3XpX5mo3wpiVhYLv0lH'
    'Q)8*wABda>s+qL@ynTBifQU^|Q!-So#7t8V;>`}+noaGh6Sd+F*(JKS8uUXg$(q!<rWf`?*&-+?>?Q+{T=IbaB(_R4g%=A*(WDXw'
    'KxVG(uY{Xg9j!P+o&5)V*fTAWpkg7(uF;^qBw2;6qC&r=Ot126g)(gq<ZG$jvW&&3GD29R4iq)NAP1Y4Wnp<GVeKv}Sk+X_m|R`K'
    'l32ry>O5^Xro%*w=UnT6bxO?3)#N%STe^rt^U;ul*s$A8wwNTe=qs%S8^BbkdBxF4J-V9fU@v6|d-pDa<S;t=2PbzW+H4c98Hd}*'
    'v&FO^3oM5ck!H10+HBGT0*I6#PAep7Su5XBr9cnX5Efvf(Ytp{mR2()`D3ZMQtC2k4j{uMTeR6baRKK{cY;cT3H1^p*tf#@@t%N!'
    'r<)u;IbrqMs>-$M-A9V#xwOaUALqs5UiuI6h@>?~<2t-UGohc*&vrs5k2VlTvHY5~7D}r$Fti8*QV0#SWIr&69AKW@@%uqykO7rE'
    'drK%8w5@{Q$9sI2D>`O4i_sr(f_(DFcchqy!51sSgi2p%rJ9v1gv(T1U*n}RwucA6Hqr$6OkAw?f#}G3D{Ksb4GKRXcD#@-rL4u&'
    'UX@nOGeP5(d=t@HwBhRI#kD;O-6!3@0sZDFR42cxSol_XhEu!3yt}B#C{|rHep_QLlkY`?*eES_X^$QB&-7xe1Q|ssC2Y1-@m9_A'
    'OIz@|Gdm`mN1xGvvg>Y1S5*D%a%91Wuf?+H{s-#$*}Oo|IIk-a*o|Av$~`FWhCjE(MAXl0HEnYUX8YLu=Ht<@aie9MT^r54$t~s)'
    'rJvd>X5AmFq@DcH)NIvI4l7`j;$G@6zgeSMV4GTO7zagC4SoQOoP`bYz1dXS{Oj68q<XVSOi=gQ#6(`Rp|%R>TVm$g)!(CnwmF<9'
    '{>R1*G;B4266ot1d6K&|bt_*a9*3w3dr8?f@T4VeiYO+fXvgizRVvi;>xRr3Xw!4zbdY1A|8^oFY5o!akNrt<KckQ^?<-s#v>rKs'
    '`!TH%9o9%9z2C#tWR1lC*0i+HdSw08)C(`nNd2p(bx;d6szdCSgW2k;QQZv)gEzdgRtu_EosC*A!PcdX)K7z8CK`eLBjexUhSp^r'
    'dB246Pg-|)<oxYKOq-Ex>iUALk&^V1V{K*6<OotM-2QB85rLWnXfi*fcwu^^fbw3k`WU(Z%~6@ror&y%14=qhSvuwo(R23T9c3ST'
    '+rw?`9G7gFyX-&y)=+C_6vi|k@K1eS)@+~p(A2J&T=(Kd8B8A6OfW+6ZsydSKiiSOaQS$nExWtSj3Jp`y@H5mR+yXi)9SiO^&`;N'
    'Jb^Q6Zyk)X0c5h{B2LEk)Lnbwo-I;1BTEs%^$M4|UDYDs1s-Z+`Y6XTtBCcfZk;+HI3CM}7sw);Raf~!$$mgEQ&v~>!j2bv)qB$='
    'iZoc+`&_whDP@!NF`F#PIq6lHS$_9UTO90*>XG@V_c0|5W7a!(b|Hq(%i$v6q#3~=YD!0FvE8BX-AL<L2TSFUE^0;G!h_D>o};!6'
    'pcoKpDUtl`vt%#fBU$8t8l)o=0^?-0Ah#Fg7%Kf~5|$;|$Yi>fex?v*Qm~vkFRKDQv$V#~aC(&ZIPA1OOCJ{QXMM~@AuZDL8ZO~6'
    'w*B)#LLSB9R<Qli5+Irxd4=O4<}4&r`8{hH&RX%wA4{{nwqQ8WJl(*D`zN`5LTKs=7d4E}v_uQaG>=D<8ZG2Mjnp?%tU&Swo4|KO'
    'dep-jE%e5h%Wmyl&!DL4-JD?3f&lo*_l2M}w0-}A`3!2vMtpov+hKQv`>fsXv^(G+smf%Q7ZfFCxlqo87b^L5W;187OVm@7WQMdK'
    'HS{XL&URN#&Xr~3vRvNmT6BTO^1U|A@Cf0YjLW#q?v<bMZGL+R<iZ(>9Q`SAp5Clsni9cHxa4e1Ic)J-5C1ovd<%t3yS>y=li;R2'
    '57JF`*f1+?)p%C+nS%S~$Kn=HvmmUySDw{Fa{gc33)3UI4R=i3$wjpV;zP(9q6HjAOpL2wX-Zan&L$HyZUG6qF~$-vi|$T{c~`Ec'
    'lca)aXBb66H8Upq;%v!D$1-~c{)fGr@yuG}OOZret2d0JiuqvoL)ni4BN_VQXyFm!h5f$DFjdT!@iHU9)d$n=)mH<w6rxx%)*H9J'
    'n~He~+!cGB<WKBCSbLTS0qZ~r8xnME9y_RGv9^LgY;eISXxUaAW>>(5rIUqxrfnFAmorjMsOP@9*i0|j>>Rq$;(IU&VL1O4IT_n?'
    '2HUYT#V-`hVl((|LvO*IcuuTf1ri&E>(tj|JG4nrJ^%M;$<2nNcE%5bpt#a)#OA{z)$7j#!`AXwF8q+Yqcn$XaqkL)l%b7__YZKA'
    '=vFa7Z>a9TSE<Ncm_@X@t3M*^)rC;dJV2bWbyVU;B%RIF`WRFrqj%cRFS@4^%c2YLy@j>>!<O3G!+FShU0{cyViv^pb)6j#$z|*B'
    '$XBXm-KTJUZZuc-fSC29MR1_U?{CD|J<{n)&%YG?s@PtME-S&aEv{l`sKUd$o_bN5nW-RLOxNhDX6;U$$Tp}-Ahw{@s>3&bj`)kz'
    'ZNYv;qFPfIU4jZ@Wk(jnu(Ma%a=ZNpZQRcvr0vd9E!7zEZn%Sn0^3KPmfK286b)M@mnFL-y41qZ&%+uO-WvL@wz{lZrI^n(w$Uwx'
    'ubbRlkWAHI{LLp_Up4X>`7lZioC-6ovinL*W5n#S_~eM;M%e9VGMpAgA!Nqx^Cc!Q!R#M)x*TG@LDFVl$b4wJGT80}CRRH(Ws|wK'
    'zj#_7qiMwM+~QmW*rjH$_T`qtYO+MUy|YeTbO=?3+TBv^P<*yIubOpu=WjmY+SA9-e62Nn4TI8ed^hY-Yq_uo({gXbN21}<FcziT'
    '!TqV!CrzGSyKytaT>EdSJzL{!Vh0PIaol4pR6fgJR#X!ZkJIx8X%ma*b&8nI8oC56X_4r=&=~~b<yzC)f!+s$9i|!OsW-S=ZSPmj'
    '9c#X4O?Pem`{oPSt?!+kUr{|ZTC%p&9Q0c~2yztlJQr7{W}%t5iaUj+9Bl8V--+vn#5Lx|T1Q(;%9d$gY;&B)rL6&f*dS^3SG5Uk'
    '^+st$T)kc`sB5UtTI4l!3?Z0pNM3zN{7zpVkG_U%5vFemX=1`&L?NG{dVG(cvf2Ol^L?E2jS|iWnv@<yOYM<8iE9H>)utw@hb?kV'
    'gH)ptsvgxJfbLP1r)h&~W$kLG_cVv~41LYJgchFZCTu5&8eldz!mMYAX=RLA%OJD9QReXtCF|*}AIUQDh`8<|kk8CFGxeC*JfBUn'
    '8P#LJ;iN*&W$x=sove+7?U1h)=^SK>Z~r$pKW#+r9*EV>D8dx!l6V+d;Y`;a?9=ihEe&3c#;y&g_pr9D8EkD9z&qZyCN9%PIr3gj'
    'Oq7wP803;--A#_94rKl14^eA})xe3FvcB1lpz@QSrUSlQU;_3ZL{0!Kz&zQS7xP@Cbm!Yg8PciV_$-Hi$$ajdNEb-XbzX^F`CNTS'
    'q$0RmV9taEXTitZp&xdVs|AMeSAf#D878?!Afne3avTLF?xoQ>)eYJL$XSXL3Kt*Pk5A+-P^*G3x8%;tQSHS-*4ssQK%S=R;8?QY'
    'oJ`?R(7Nox!qqU@GfEur{tA&YfxHcYPhcNbN@TDl)0!m&G8h<l$qSIKh=<R~p+IEX6yE79Ck{KurOuTs5(xqVRh8insfr~zWgrC2'
    'T;$gU$UF;5lZ>f*ImNopPs;h1$Jv6))}fQM0AfcKOG*CY?BrOS46gMWpu42{5;E!kKsqf_(n+0SB3mtQ%0;of7is({Wk8y8Q3=3x'
    'kzAj0QnHJjO7%ac6#eqAzhf@&+9CjpT>h)d$8c-ahibW4jhB9{fU#8r;0~@UO}JTkfW6uMpsq#$-0xS1uMX1Vy_W~+tJ8xQhd(2!'
    '?EdX<!@nVJ{0*-&U@gFM3$D-BDG)ovZurMIFXqdw4?A1k&YP3dzZ{&VXZt@Myxb!r_;Q{WJI~<%zoL38*d?7W@~dfaeY2Dj8DG`m'
    'hn;Tc#VIae-2v$6sXylX;W2*r>-hoJF!=h*<nv@_`{|eTO|0<b_4%vU=eo@^*@pWb9UTAp{73cq%T7wb`Qi187tmS#y#1%IJL&1c'
    '-gEbhyNWN8z_?!|J00x)e_mrHufyl?PkNoG`c#3Hl)7)XxBirEU0wY0?CGz6`%ic!)8mul{exC5&w?YKZS8FJ{-0fJe(}Xt|CgP?'
    '&R4(kU(~IW9-N+@z)nt2{&H|k+lC=_w*MqQ9G;|y$NMKQUmYEs<EK9%4Adtq!+Lo9XZro$<nJ#}P7l)Od*^tdPoI4$e<qObpBx__'
    '?4KVzhi_j!`^x(E!|SuZQkNb1^NYhHK+%))^u@{RW9;&@lfKzIJWo%4_zxH*-Ns}-;wLPW2FHxQe1xL~fSey59i@Bw=Z8Px!k>Qi'
    'C)n-t*RPHa_xH{L=kS2`_V*9YsPe_fZT=5*q*>pb9-gaRcwY$#_Rh~w4}W;gC?K1B1M4~a>+$}NrzgjU|9K$3?9ewrtJ4#lFa;bq'
    '{cC!3_!1_04gh{}a{6-b{1B*`9BGHz(_}A>_Wqon{B&@7wD;;2L2mowmtsL?lNX1lfLH{|!{f8_J-{3}+&5x+{Kk8RCO-(Es@?5~'
    '7UzG3|9T0H_WpceewX(GcmML_d9ck>(FV`N{C!*XrIR~7czFWw-9I`!I6k)y;G0f*0%(;U{Co%}NVxS(>{0<7a01|U<beIhz2oN+'
    '7Kg__9-P`MfZK<WI>1CT1;*MS!uMDv+>x4Ka#6%o-t)3T0=g?}vEef(-%uD$<`|c6VO6qgv{fj8(r8yIC%lRU68Xx-+(X#o9&GYC'
    'UXio&)7SgwZ~^vVPsayGXS<X-_AO^xyWmpjGK=;bqKPL&Q}<ydvwX_=CUoivolyHUpJbxAP%+)2LXjqSf>~eaS!I8XmL*EoE<6I;'
    '#S}(VE)0oTw)Kw-{4bzO>BTSGgRh_cs`YKLa6_pPw;q*r%n<Mb80(99#H(}A&UKl#s+jcP|E;8Vfrw8d7k8rBmSz5Nxq|-%QjNRA'
    '0T55J+sop5RjvR;z+^2j)!;mzf@pDVBpZ|fg~?rL3es<YR5r4~=0<2@sa+}zTug=)AScLiTiyQKo!tvFDa|t!jHdalN6jh8-p;>~'
    'a|ZtXcKZTL$#r+S@p(k{VL1k74gzLenn~anzxs^$by8dx7>s=-ro+@{yo|=#sQDi-Bzb`{7tg%*NU~@3cIN`u-P=jN`!4zN8#wo5'
    'C!vC+Mmaw<k81hsDYx{defv~Exn_PDn0mI=1?B<HhRYc9vaOVis6!FgK;l0fDh6AUkdhi0i@CnA%t-2DvBniC+KfEJ*TeNif{%i0'
    'H#-gW6xzBf1{GLI1)I3HkEfJ4CrZ|w3(qFC<$WMimfXikO!eR?#wA=!F2do#UjYXNLKj>SNEcUiApQi9@#q=KF`+!3Sa5td<S0NW'
    'iM@uC)$QD=%uWMgoZMoGbtNlOEMP4YDh5|Bs!^{yK+VK%w~sm1v3g=kS6{Rw@3?f9%|^BY4oixYwWLd}Tlo#H2duwa6{<Lw9EVUb'
    '$e3KGlNG+=c;532B<ddhw|JeGIwie$s5wFWq!=%)pLdmi-*ma_f7bcH{j}dapZUzfcdi+2htRGM0lhUCvfH=ZI;KlM@wBA^lwhKI'
    '$OeA#mU@c}1A)1~{pUXK5P^_lBC<Q}8i<3aB4ybfm*AOko9|sotTi^6wml2u@y$ktA-fw+avud1)<YY*71J`CIJW|a7&wMPLMA%Q'
    '^rkG|k0SVGcN4%Zi2+@XrocE%G9p2EeS0b4OG?>w`~4x-SG@BTgqvN6ctRNCBF2VxPT}EqS8|5>mYV2d=dVZHA}%RJ^r#LlBIhP}'
    'A}#>m2!a1hrdUDIvjOVe0kZz5g)A{KD=AsDyb}fq*37i*;<131TES$l?Jf^_PV`XzQ%lRE4R|Y)8VqAmy5U3CL!(5N;z8c0A4oI;'
    '&6tD))JB^wbBg+2?R&uMw3;NNDBaYdt?o)C5gj?x&9i$XLAE!L0*<YKqgv0bbMDeju=IJGZkPvj4kn*{$fxBT$>c9OJBpZlH!;<K'
    'nz(cqtZd|?hGz7?)^~}L-Cg5C87-`(K_lyLZuhGYh6rvpFH3|%F5ODiDVqyK5`RAA1!{vfvIsTlFNX7M{Jz)y{ty@{a}9kE7R0|L'
    'RpOV6sglGH*?vQsWE^M=dBp@VOy$)Cxb~$6IU?mR5={m!LJTYn7`UhX>!z^hl~Lh=%3q+qlyaGG<qAm_HgVZZr>k4ryP!_=&sb}<'
    'MQW=5?zoj(bSE1U7uIVSp2q3XKpesue%Ax=Wii7X;tqrbj>m4HzqJsO_vpVL_}tPM;fF(f`Yxd7e;7<`Sin@*%bR2*Z~SUz+<EHo'
    'cGq9QMgQ%#QsIap(6}uYkAHqzGR4zMAgL?iSVMRz4+GZ{I-#Nr-ARg>EU@liQjq%T(n<uzz&T!+NHa2C7e<|tzOueDK$t88$mk+l'
    'x7+<m^kVZdHijKNv8|ooS_WdYI+N5VEY<-%;qS=%KO1>tk7_--wtZ*C)u2xjdD)1;(qup-q<lRs@fdZax>%af|F9){I8Hy5AS}#1'
    'mmaFJBUA}PyONb3bE=x7c2x*%m^Ow@;%xK5M))^H?9wgb4T`!L%VGO)#%&WmIHfH0x=6OwJ-<W05<FJ`Go10Wr@LryuK|-Wo&XL!'
    'ujw=cg2Ds!`|B)GEQ1(*xdcu>2+L59SXm9xKZf-4vt@S;WaZl7ZheE$j>K->6tm|?N4>6G4BYTll^Yuz>D(ocskM_U&E|y_qaIM;'
    'Da~p=UZDp_iaGs@%M}ntehjR$B%Z-i;BroCLwAnxA_Q~R`$_e>F3Q?kH*b#H7oo$)+OtXM$$|Mngq~KVtQaFIyJV9sy%%(Rp}Oz|'
    'c|dh!!X|hK?qJ*b7F~~gHkp@rF_PqYNiPIeEcx@n@xkfgKHI)`v6KoIddX!xGh1O_q1B&F<4^df{nG<9soSRK-uA~Y`$NM{kcy>&'
    '#Ne9P|CxmC>hQZ^OlRxFWP<4gyU%xD_4dB~_RsMD-=6)oum1hZuk`QjkH740fAjHI{-rwvSlnhyv!uNbeqNt>8iw?YzN-u1+JO*^'
    'ly}bX=+#drhtGR~3zAJf09HPG3ay<>BES4AT@v9T{Q=$OMr!TDeg5eTuxoaGCT`Ai1&Q<0|Lu)A)-YRKGohAVgrv;S(A$4=c78hW'
    'zdQ$N<GKD_K=9QGmG$a5;O{p#e0_9s{Abbb!djtxI*dd8;pF7VIdedUe^_m3z@A;cgGcNkh7OV)^$uR%FY>FN9;+YyLbLQY7OS%H'
    'RD{aw2s&~9&{061)t)ANVjXA1p{*8X`3fojS|>+&th%!!;(h>s?eppnoQBi6j~`|)@A$ae<>Blmhh9GtM`CuslQEi$a=r%j8`bO*'
    'fm>en{09AjangfClo>Q$IX%I^;ggJ0^&T2F1aAJ^)W0t11-n9j&rEh?(*AsJ|A-6$>?w*BsJ4{xReG;lp0G-GXlcysx2401>Uy1j'
    'C#Js>)8C2d@5Ho`m|iV%gNEt`J%@biFS|(PoK)-rr;J9OSVC`$?2zj`t$`{;^NhnI{PhL=7-(nRQ3dHAk52aYjxIv&12=|SyDOA='
    'aeBIQ&*@?Ua2<hC<oXs62V6&|bTU8(^Z@)GQT0~+7#Z>{OZAhxAB*do=Wu(@VXXeZ`gBy@sV~ZLz)jVIYj96lHe#&NC#^j2oW+UN'
    'sd|G3kWt(~mtmFJqFB<DHEnn?O|9S+S~Rsm;UAk+CR+VDUy2YJ1WaW&Y@q$D25F|;avlADk){{UF6-V8afwyqUJML98%_LG@k=4G'
    'BKBROM67{<53wc+8AO9-Z$Ib$sYSZ?1X!|`mqTf!5OT#NjB<w)qe+B_5pXZec7fxfx67po+`QLtPJQj4hJMN7XLp-&dsgi>pWci3'
    'CBxlN{DR8lmgJw7VZv)4f8dAIZqy7h-LwwJjU^GSryd^MG`uz<@q()f`c3ylo$I!`uWo>y>gsCiG!sZDJlB@+caYjA0KoDF-Rzge'
    '472PBDTT`UVucHIln#m~YwOdLQIWSU%`?v4jUh&n;YQ}j7C3E@$r(8S&~?CP33v*6DCA{A%qyI@#4S$gNQ>D}z<WHHQE^mtw`+%M'
    'hklmFy+FiN#Dq4$a;8BggEPh4--=S+m8#Kzmu?~gBFG$LL`0DFj{?vsxNk`CPH*y$y`8WB1>B-6(bPK55SW5$(H2+0GKCJX)>%rH'
    '#*t&7Q&v)zoq}snC#6Dc0SH?Rd>x=-Mz(s9ui`z4gsoViAo{)jd=T0^Bb`CHBgi)}tHlU^0{xo;2))LBpx{8)!|}pr0)?|YOzJp!'
    'r<$?K?Lp(JWtxdy+?J{l+LJ=(8>+dr7UoKF9`*}S*?;6ogyVwNB5`4h;{)Cq6=|f*a%k;v>~u~`c-^ykL8Ju#q{jT4*HjW6+gpgg'
    '>GK)svvS&?IVmNZ;3)CJf4>M0YiyU6sQz-=8Rs%`4Jgh6f*hQi)ke<lN&f3}AD3`$<7HZY$QM)el$a0`8E%Y*w0128TFfnK5MPC8'
    'zQ(#G-kGxSZd}R@4>Hf!SR*xFV}<Ng08&^5m&>drj93>tOpLPoK=CsvB}C$~LL*^w*A25VCP--Co);q>DB$*B?llQSxXT}MFQbdU'
    'BGW-ETG2Sxl_NQ#2xB%D%aXx4(PJIBnwE=tBoCym;qQ5Q75O4UPh0JmMY3$U#AGhfxkNx|1lpLSi%?P#JGk8oq!jR5uP%KGH`a_c'
    '4KsJ^@o=-t{JNNtEqA{3v#T}7C>Xj18jxkMKqj5KfZZX|klBP{Wdlin>fgm+HYoS8)M3o22xGP~1o>rI90P?PlF=>!&Hvv()1G}X'
    'rj-^0(+vej{CCWERg7=*<xM%!EUNY9TW&l}t~?KL=Lz04kv>E$W}Uo5Yr#rCv$aMvQ*IF}(m*q52jP;X?2=k4liHYiuYK-qtG|p+'
    'mPY5o`&z5{GK0dT`im%>#mRCDTOGAQw1pz70h!N_QX(V-ISJk)Q4<Scd0CcAz};*vd2bC+kvS$1ooC0ntJFutL_T?S_?%)DBT5Qn'
    '$rCY`UEWqK*UfR$`=u*`KnzxRkaYF_)hGSaufk*}6^#OBVq#1g?{3`0FaNnwP_g9>gV(naP0Now7P)ho`b7GfT)kewr#GSYVa<QN'
    '<+slI`!D;A?U$xKG6ao~y^OS?cDYqYBngU&rXkXDNNDTAVg5&+>A+E;I5Jcu^{g+1wpiRFF3ZyIxX_ENxk*BUwd&vEFOF(#oU*?U'
    'M}8gn97iCxjn_!J89Ett>e~g<>cpnE66gFgiDb)>A1FnRZWYLj<Il6>|Fj)jjhUpXRX59Yl^GWOnuN*nowF_Z!b0IPj-s(}=U0C@'
    '{^Gr@oj$vT@2<-py1|f$FRl|u1g#Vv+79VgSmShhALN0Xy%Ws4+kfb8&?7}A1FhLj?Tyr|D7|r(tQ2|O6g@S;6wb-B{^5jqmY4wO'
    'sdLne%iJNlSYZqGqSg`;-U@IvYPe7$Oos(NIg8ct60ibh53f#-zG6(Gh!yA#2x5Ii_+Un~-N;%^`94^1Qz%VVz<te@B6&dWRTyvu'
    'WK?%W^U*%^SQ(>2V$i3OC>o~KtS<0*M%g!6fSGezY2*4Xt6*X_b-MyBx?&chJTWKJq@rM3W^L{%!ux)!m~By&aL&{zbU+F6vNjv+'
    '830WEimRHpv^i!%_i#h4zN~9&73eZD4g^dCx)q5twIhj_p~Yy1y*_GRFpb;oxp80W4Ler2=TG5a29CsXEBnc#4G*LSPbY6qubPY;'
    'DoBEBS0NHwDe>b?RxDqXi!+dWruhlSmo@p)B-?!ggOzk~9Y{#2T_neIIfuB6?j|HxsZxAdpciSW-$6CabNS72>j?FWi(<9TSdZ5r'
    '=2gY*`!yp51TX75dZ4V={h}UJO<pd-BN+8jhy%@uF$1AM4m;+qq1Oc9o`a12#v_TlmTf+T?Y=Dc5NIgC<$s`C*2v-a*SMu>858e<'
    '>J_?YV07}eTD8+vIXv3a?Ar2&Jj;d8^5Klb2#RtR?p5b~<+@e7e_up~Y=gf_6)rk?#8X2A2xlliDU#EG_B`nSHZTC(UyJDb7a{!G'
    '8ROe8U8u%Y<2&YzCYv?k<fCoAbuRsot;*n$f`ABEc2VD<*4V<Jn*?C;uV*MV9VF>Thk+KU^G6ZJ+K@GU0i{Xcv>8?D#~A|sV~C^T'
    'kg=9Dc^Mh<s5GT}>VAXKKqbG>nZ;}lN-W){c46Ct9;2SD)d%NX#Kvr*YlfG#?&T3SPl|TKa3sX~5Aq0-qeRpMfc~p&D!@(2S4Df)'
    '9@&M|bX%ED!uaVABj2^-G1h%sROE$aEE>bO4er;$k`wqU@FLhFj1%t5M%-NVp|i$o)~DlUJTAZ%+Kd4MZ_T>AU26tMA7D&FX;+ZM'
    'jmX32UA5LdZgT#DpoDR^St7JCV?Zm`{inrME?yDDd<TtMNp?6M$#Ze7gDY&hvby^2ULb2LZZEZV)&L|uOPCxac8>pkO!~Jug?ey3'
    '@C;Qd-N1#my{$0dQ=w(t$qKm&_^Z=W)mNkc4EX9;3O>W2Dc*gfztDR*UT<w;s)BkHm8(S$i0|Hs`itxP^o*duPo!G4%2q@rkx(7I'
    'H6}5NW<;mxZ4Uy?`;X&0QIx->inaB`I$tTCHtG5Zi72vzlJ$xY0LrKKiWF}u=$c4AymKKE@VLq_-Ta|P@1^{CyM2LNjhvxwcU~P#'
    'D>w4M;KMhDI1go}@^*|kblsacYRAXb)c<PM`jPECG$+^j^F6vFmL6xF111Q%q^e=^!OBE0ifJoTkI$QU)qMOmj(KSC+u4U|>5J*y'
    '88i#2L$`c&<7#8iFVrut0k2<$p7}Il_wj8<bnL$&MQfT5KxiPI<W@9A*A<ZZkG2fsVhdTG9{t9vt$7D^kpuifq?U?xZt4}6qlDRp'
    '(D+ViMH;8gl&UpSdLPcVp|t<lcEV1xCDl2UO^IzIAOfasXP9-4>EQ<x-igC?ib{JHjTU7A!Z)b}iK``V>yoz3$(oO+!ELCLXQ53*'
    '=XLT=wx9S9LWm_kgrIL4R7o%+4WO@vZ&(o>w3RwMvYy-QV{yB>RoJJak3zNYtN<=r+4pjUPX#bvHp%W#ONnbV?gi#yyj)#f;U(|C'
    '-KE7{tnuDF7Cc4PQA$CN%5q%CCz~m9cfw`h8|KYFE*Dvgn-iLoN-sp!zM2CKFDzIZT9~+Nn44N1NwgMtSOIFSv_EiMAHoiE9B?pd'
    'w4kr4wfAUbyOP%prz`azQe$H&vts<8^Hu^4#|*cGC^c`U3MvV4GWZT?N0(-z?;xLAbDaWzSuV3_T?1eR-uoKcSMaM+>|1SHcy5Ob'
    '{ZWVLjXkOBTn9qArrNf>u(#XNw191Uo#xABSr@GKc;5Ce+f5B@*H(!R{hCIE4rZkr-(^Up0k%=%@kF?QK-F|%5oicuuK;5BDL`VW'
    'z#+^g@HlU8{sySqPnSQt#9CmYLb|&Afr^R3k8W@Bf$CEm%qBDIPw;^w1=3_8D{;yM4uTYT9(1P9Tu?s~2|(u_-N2LSyVwQCwOVid'
    'z||UqzZfMu|Nndr>y6$XT>jhM!3Y*aG+vgh-w#VW>S2tnU(2Tbx)#=p+&V%wqSA69$CYE90;>;Zq-otQNejYRb05$Z29S!=N^wxC'
    'fGtOD%halVk&u9^FX@PeW|eZD<qnNPlTy`RKfzyxA@=}F(o?h={rW~UJr#xX>T`Y=T4tmYp%Fsvwo=O|HPGE$EJCUo?Gc@ox<hJ('
    'f#%Zu0C>Nbgr+tRh9mCV_$fE~Gus;L+NQQ2PHm5x(0!`|?6Bu9dk|XSpk^ukwH%%0k-}|hJnmq2F>4BM2vXUbTInuk#B*5+e38Ab'
    'eEY4w(`+>x-{eSjaFF!x<z<Sg1n%R*<?7yaEem-*Q6t0Ad5lwJ2%Iphs^WTfi(W0|B?WeFG?dy4Zus_rV^EsG)~m5DcXT*Z5?L4B'
    'b+fO55m1BMV#YWrZm7L3-^H+IG&<r30UI7YEWM70W+4<Xh{aV=hmOu5i*kxF@HklAh74UV>*Yz>%&w5is~xpSCgm2K(kfo#SyHc0'
    'M?3julPRn)y)A*(V(pjR<Z4=GMicdAgfwHQ{xq^l83l&iFm25?>k31hWsCNhNVrO`$0ro8!cQmQ#85w2=U7xir{?0M2C#u?ahWgR'
    'nojSNNtvrR1GbrDs&F1xG8(GEUQmQM6U8UvvRq6M3CqP3Q7mnXs#gFLGRfvkOwuNkG@&F=EHG!A!EIm+4sVL*5qqOD7}EC&QRU#|'
    'MFI`R?}xCPTo6Y?$IdFvOqANNOEQTGF3ZXNfHE1v!BVrUa<$mPo}x;SmXblPEIx`-PMlCKv=7D*U13kg$(zU739C+`ERXpiQrGH1'
    'W)*$cS2J}p`!Qk6Fj3iQWga7an2_EAlSf2`ho)d4ffV+ws9e91rwi3_^^&=*QPVZZ1Nx+-uWW1N&O>yi@Ajqa>)DiKo1X6aI62;k'
    'q{b7xdBTz01MoPs+R&y#KKTHtn_*F1VeUT-iD(EedMLs8ceLhDW^Pt%57impK-o|~xiyLg5^0YOk^#bCJH0x?UxB>`oW=JebwFW>'
    'eM9&-CD}Gg;pFEwYOf7glkiN-@%!2{Wqts8VyQp&m17<niw@D_Z?RCbT6OTf@D8640J(~4n&<N#aDu(<;r8|pCHKUC4)m4W3ZO*4'
    '-~Y`pc^xb8dM9cdg!?Ttc#a2E{z*a;OfOViU)@7vM)<g{u_0|;$OXO=3;BtTX>8mWQToPq+Jz9cS*|O4w|72XYf^JRn@{PfGvbix'
    'KPsLeOLSeI@Joz<Vxw@m>^zpDcvB^Dzuv>{@lpl|aFNJtvTxy6*@Tn|fR;|`pJW|&jarNph!mI&kimXXKnN!6djOkl<<;|)Oz~Q!'
    'j*R_3Ub<%BZB_Gp45H6iN~tLEQI@6IHA#lZC@3kHg-9U>*C&5?BmvK*OJ<*;)Rqi=RTB9dJr0R7E)m*L$h4=u9!*@Q{kGA-*yvyu'
    'YPR=lY<6TpD=2Vi3>o=9*<EzYKm+emgv(LWUkwGPjl_3`l8UdiGOc=<N%qm6I!!Pv6VdSS$q8vbxVA+Oa?ia?fWL)B7bXen{yyX)'
    'FW34u)ll4umpj&KRK9nAiKQG`!x3oA+xFZw7#xS?!N*9KmciugV{s81q)qs^L7cf)t1wGaTZW}A;d&YMO9*x%mps1XJ3C*0vx{|J'
    '*>~ai<UD<WdDM1cjS7J<b!5hxz?gNI4%Al@x0AgBowWidp4uvk9YtLgu`t&cpQazPyf!D@vLNB5`-|)xvu9G`SJc^bO?I?9NV+yJ'
    'MZXxh((OkQ?MeMOn?Z4SPeN=0sswCp1YQ(mBGZDi2-i|o53D$<l<!;T4)YGCmAkW>j>)B7f)JMPRk?6fT{|pWNBE@jpS#Rc3_1pz'
    ';}(?2KhDYcZ{#=SELENGyOqu=@!fH_Lw*HUM8*K%P%c-+bm>|Hz7^F^l)fDm)5Ws#7?w{^Xx!p|8Y*9`SM@@wMgy=6rlf-Qfu?p&'
    's<^rpP9QdFu(2L@<EoV+W<RW9jfoEm4f`D@fmX0|Me8aOGV@|F4P?E=n5{Q%v&SlN+W5QcBDwKErU&PRx1IXvdPR}>&{;EUq&+jL'
    'mbHsiU%<^QW_a+kDj7wPY%8$^8~Cl~gohZTJk&TM>295F7xM=Y88tv>^Y@X&uc12f(L@4`KBDQ#tApe8;OE1$^TXpmhh|ch>4D^&'
    'zT7*CC6uk3NpD*nznxlvp<$hfX!$*$1oH0U&p))zUT_I;ecy?)i9UlUnL-tyZ^U8!@cQhpDl&_9uNcMtV_=FGm8J3VRus4Cp+35p'
    '^>((m2W;vY=f$*VA?}l8C*9uO#{V~!(svn1o`^{kFB>;1wgS1hogQKNKvJe?(hYZ%md?^nx1PQT7Fhaj6m{bXKj4%H$<EWA2WPYO'
    'j@z%lXcY{pO}t~Z45r*UqZZ+mJG%GdrQ9*bTqEU<?iDNg=;YZk_?P}CEh8X2iH&UuXK|oHA<p!1))Gj!(Nwac6OP?>!V_imI5EQE'
    '@Nwy`r?{gvGX+1Io|?sn|Nby#dmW82k$P5FPxN3Wr5&RZ)eYI0F%-&|faKXqVL|*!X5?#n2y~lF;0ToxEtJkn_%*+D>%N9j5aGLH'
    'UK6(Yyj)F}#avo_s<7GTtpVEn14ttmq6+-LSbc-hryb<~ryVXm<~8?N8kz|9fX*Lxwx9m*M`^j^2AkUd_ycco>7dgxpAER^KuT1#'
    'Ihhi^MEy_h<kI*E`D(gH+@q5)>c4H1=mur18~#u12eDTKa0^w+gE*iYbPS@^2)yyiP{<M#k!-0!-RnlGBq5vfJepZ2&E{e?ODUCo'
    'ivF*`TF&B+-EgUE7K_K_?Jdk=n`?y@^fDX2&)si9>u-Z?w_29-G}J}~BT{2o{*XJd(UIN!jh6euJ@V~ac-yRC#tYq_w645rrFT7D'
    'u?sfW!{RCcR0N$olLf5)Scw=%bP|Klm?E3(?303Ln%)a9Z1h<c#^l@VKDk8uvQQ&c!d#Qd=*VOWvJLq_XB<6=q9jbkIK!}}L<mD3'
    'mz|KOWjRl7R~30SgTPTPa$c6XU@;}RNONI>N`Sn8mIdpL|D(Kwk@rQ3ZJ^SKzKeW5&Bo+8Ro)gjNyg5nc<k`kqFi0G|1`~aw?LvG'
    'S17%;g~^!toeDs;T&yr?0smD@X<1c1&(I~EhI;odZdQKxj{U)vTXtpS7$Z-3E+{w@Bbf*SePN9m$<)G@3I~!+)rJPi3=OVyqzMe3'
    'eT$1@-Jgmdn|&zX!>j-dD)!5c>&nR@;i*Usbjinoz=e-+M0hZ~FbQTlIj)(V&F(d1(F%OY_1Y?O{lBcrDIB=EM8l5dXfAV}i33+!'
    '?V3v7n|qctS_2yVr#JPT#<VHCgiv%_uvSLAiwb>nyKSu6M`9b+>vK?|6oli!iJi407(=m&O&cC1PGFx(R1}|dh?}#2>KXb<dLFb2'
    'RlEr!@xOKMJ+;moktbmk`CWIEj=Lf{Y9vA8dG#7y3_>w7{}6sfok(iINYJN7B6S?m*jd|W$W0NmW=6u$Sb=-0R#g+kX<nZC7|uY;'
    'cnD{I9oYC;zc&O-EPZ(Jwm5;Lu&i3h4Wb|2yoR+<GBK@=&{@g5tW1`I?GwU{wSU8^?U1ePE@a&fvT&c$<b4K|f_N{E4&y~`eb^D)'
    '!?L7@lvc1c$rr^3^?Z}QUOk1%7c-w}Kdzp)=LTOc;l)L!rKo#=nob|E(R*Mh96d0N0>9PKNr2oa_^U*kPUo}a#{wwhf_wx7_^z@s'
    'GMO{xzc{p#oK`3f&IsvKtXn5=p%9uOMgk^HQ(#%rRGEXj>`i*M|Kq{SJt01HU+(>!^6%tcYX1D@<n%8Gr|HS-^H;CW?a!|1TK+D&'
    '*i*!Xmu`$g$nQoSSzS}qW_g^ZLAFS?sg=28qv#EV1{WQ40AbGyVrj)Qs?M#vx}x}w!<}bO4tKs{NnlIy2NX*SR|sSfiU7SWCoAnM'
    'w8*akOLCN1NU+J0{i8!+wZs<8%3h<Q5*J71uF&%oZv5HvzYHh<Enniwfxo@UJ`^Re`-jU!c%@dl&@iJH2sIy`jPE8-^4W)CQBs_6'
    'hhj!QkYoVN4&LiAF~l6@DN6ECIpS;fWlMlOL911To>n<<KYa6F-7jy-S%<(4UA|4OviJEGOH8867&RBk-m62J0+v6)AXOwaAOI|?'
    'n_`}b$EPBI<qF(_&8<L+zzq56`Hz&0R@<2W<K&0*=<w|P-8+H+BL@l?bD&Nr%;4b>kl(%g%i+;cdU8yC_K!}^4nP>eRRFdvV3p*2'
    'Ec|*CRis0To*;9<P#uv~hq|ohx&m!7g%hPESh2n0Jm+P#+~Tz*I=;ShB}9#3@_Ghu46>9kp+q}?8NN6igo~01D;Az)x0l8Bs$5m*'
    '9|mh!<S0IOD47JkLm<1ZW+Ln!+Eh3SAubNECH%3Jj7IPlFZ0$NU>Te}kg!Ps!@SS)d6jT7895TKM-ejpD<)Y3_)KyF+-wQkFRvI{'
    'sH)kT61K^cWubqVoPyLiWAp-<4#oii8sN_uTy_ZX#cWFkB=g$t#T8oI50ib^kMteCDN(|cO>v`@l&d?;22=wS#K$-C<>A|H#Pdsm'
    'I*c#hl8oI^A=`K{bH<Jg4tp`tkzXLab20D5YEEBqZI{Bk9ndHfPQ)F!7sC!copck^^lAmim;*r<QU<93XmM4iBY#_>dw55QGidIV'
    'f1!Cp{<~DaRyiQxQvbQSl;vl{FR*b~JJ$D>KVX;+t%=8%>ycJh{)RI8cnVmp8>pYS1vJJ35+C<w_k%<#hX%>>0`tm9{m>ve$0X<i'
    '6znBhwH3sEVAR?d{2a%r!t=NfGy_P*+3Pd3wH-W1XQGeW{GTt?=hw%F`&fba;P|J*)05+u2gm2S;g{Rno%G=6bLyX-o$sBVzkY?)'
    'Iq+RPGn#&bt<{*vC+VBR<L4)D`13bBXNL!Pk-k0y@%uU3uFv#jJJ_V2+{wmI;s2k<8jD(5Zu_Sl8b(+UsMJX6p}JblQ(CamK|z6g'
    'nk7m`$)BvIKkS_y?qj{_lh?=SF61=c>Daam^IWz&R<0`(IIw=?T22r4PmcG|>EaCk^&A2CY<svZ9ZHReOXPD&aj6*HzW`wqN-rd#'
    '6rCy+ZIlBM6>{{*$(Nj;GR@)&T5DTiF$r>qFkez}pe_O}St5!eYG3O=^GQaT9i>3Vmk1UcU`X_WXwxaia;K@v-h}cs%L<&jNzmGq'
    'Xzi}8mK93bK;}u3e|r6)8eRzQ?tmlbZ-mCbD`L=tef$F&u`Pz7bSj>aea<}sayzQnl$8QD_Y-<hY@u_y)RADCOA=AAj#z=*6ublU'
    'zGeDZ63I;XQPDu6d_B8L6J`L2y*AA#GZ|xMfC&Rf*oDQ<+Y)SMCW=Ac2Smv+8~B3FjT9_Y!WvrPM}<@-<$2Q+PA+H5#cGT%hCre8'
    's>r94Dz)50d)@J6*Y&(IGB@_R)A?zxGSC=4Tj;XoG<=>{@0aDgvE6yGB$xZTR+GD*>(@28`)gB!pU;Ya<c*`WY4r0xX1f3hWl=Sb'
    '*S_hCVmjTEoMK~RtddyY=<e*MyklZuHuTz!FXfRwt!<}|9@{w{T*`eC^%H%o-_6-_aySFI$sFCQv&!vQ_G{5l$c2%17s0!5@N=u%'
    '(CeNt-;UKXVG8Ry^#=qAbxudXUv|A<roOQNS+mP{)z-X|H^SGh2`uNtnl-eV+$qn!CLH7O;_Zx0!gFrD=H9En=9XV62gBEZa_8`T'
    '9$~_Ajd$a8TF$QV|E)zsKX~@m>qD(t+^3iDtlh3|QAq)e>RG-Nq(Y5e!Qbi9?!&3s*XpxJf|S_4+(ON|_O2*5%YDPJuNFm#aaH?x'
    'V)Y}Qfp9xnfqZgZ+c<dshbJj9atEhpYo0llpE;2saYQ!F9j$_AM^1<9b~-@=?7E$Bb?2C&3*^pq7Pn>}T3hQr!4rtH-fJGn4_Q@='
    '2?33|!AKArZ@aan!%`B`AeJ~tN?89gzbzN{-t`S&HQe_0jbG*2duxW*74b1mebgki?Q6(kSh!j9IL<MRwj^zhRE=8yh4gFf+TRov'
    'P|u>AtT~U}Z=D&j{j2Oce~|&hE^)nvEO7@uzr2BjSwys{F%5h!nDBhk*y}<{kC`lA-s4aaRq{`jF)OYT`s63C5u)L?Wv&#S;BFx_'
    '(U!h;bO{a_eoDU&k}mzPm8VphL9rS}WK>x>LRjg-5^0y!P|}CVD4xcUaH87~1^|oQwsDP-Nh48>mOGpgV<+$pMtgpA)a%MG0FhOd'
    'r*Jiw>}@u(9sP7T9qIzPQhHtZ!bN@0rXU3;dJi_uPQY(s@h}u$=Y{TFv>33tB&}H^-k|bojE7cU0O{ZnYBF53UvF#Z|DRR9xc}GP'
    '@@CZ|TI_C3^c2MKO$(@aF{RGe+K)Amsr^U=njfdINBu^e!*Ha++NJ>!u>SNM(6>IaLy!XsAk6=uzAV34qH3#C+^|+kGXlr?tcy+d'
    '(i$wU=Mw==XP8d_4rh<+*Ol44=SE<T!=^QOpXcb**#_gHIbT|irI%zmHL2dGWX|NCYrf!C*TB~4sQqq%6mBik-Z)XMwIjA)kK$s('
    '&slsquK{;1T8-BlFH~Pa$R24Wa<ta#_;bEI_*j61F$u1u{S*Iy_c*YIru7T<Tn^DOLNx+m8m+kZY+l$wsYYOi$;fAu575+O<h$MO'
    '5oR1$jw9K039ExM*&+*yGOFh@G`7r3ETOnUKZ479N>8^%J=vM2S}XC%0|W%Q8DBt<Uz!92+0K5K_eeMS=Ha!;e&?DV#5L8QPRm;+'
    '2YJvfQ`aE{bXq7!))u$UaJfp!`=bZH?2_BVTe8cd>D9iB<R8VwZOJ1Ddkl+Zep~hW1E3oBqiJ?~Imr_IZI}N0?e@iRoK^W%Ii2)G'
    '>?&&~;MV<ZyF2_l+}K|CmtRM}{MsF|?9hXe2GqMx)>HK-8o$LF`pFmAA4V{Z-jWSrPrTKvASX{zB9s*!a{DTqj&M-#sW>L7P$7qp'
    'xBTA(kl}E6F<_gu4JA<p4ZYb66^ZnGPrCTQ(vghsCc%dAyVVZh8*B%^2X!tuk#am=;>u-Cc>K~9r`VH4%$8zL-&s7H-S=q9dA3-Z'
    'fgEx|{2l*|hm7Y&f8%M=KhVtx*ZP=C!dZc)&pCN~c3BZP00GyWCI6U@S4+G$DMsL=m+***2%D}AZaA*c*6l@5BLfid_h!3>j^Rxg'
    'RWYlU7&(g<a*#{_Is4=chhJ~9iVLdXr!L*r?uKwTNrt@=<BLl|0D*t`m3<uYoKvXF8fn&>Nh`w=WSXW}ne>PX2*u`%TYI?z{g`$-'
    'C+Hfj)nFz8)2h&#miP$<41Ma3=!9cm1p+jD)*9DH&eq2}H4WbBB<JKS_Xf3gp(~mdGdjsny(pYxm`x@<p4N#U*4^L2q7lh7++?MJ'
    ';6fbCf6(LGVoOdKvV8i1Fb$9r49uO#r|G{?kw#ICqFUlyS_f2&@Gg5RLK_O1u<LTd58_2CW>+Qp=eINtF^rWbkeQ7qs@&684i=+%'
    'rMBL7M)ZrB83z~M_r9TWq4YlLfM1I$YKJD5@p4ZCQ{&*6L&t*C*Q`>7ey<#|sbb4|(U@gFe&v*0p@AlsOLF2S=e}y0&pA$%>l2}q'
    '`yZ?1?xvjPTLP<+%hd$le?XIoExlN7gx`lUv8;#1Mxuwg5NpKl1vdr9YoniSbz<{S)GpAYQ!-c<7!EO0o3qefWS$@5cFP^$Rgu}}'
    '%zO<#`qvn$b(dk#3O&?L8)D1`PgM?zVkubpTNhMCL}8$vF)MWOB1Q-MrL(S{d;Q{jt|_4G+_A<>*zd&BIs__@nj5t<z=pw<tHM6<'
    'yY1zxQ0ZN%T4Km-)&sEhz06OMd=zRpFJ&#IfDWY8X8i=9%Kq!K^ONU?d&fie0!_=s9FX3+QAEr8oz~B(_xRE!cwbDXDSC8Lz6YW*'
    '@<#YRvGm`OELga$z)=|C(2Bn_xKBInz2ASJfm@%DKG1g!QcwehzDf6?t@fYL1D<i<h>krZwJ3)KsW2;OH;}rgfrwBTaD{6O6G16i'
    'gyL*r0FFrMVUTdAD5gw9?0ZZ{$|<N=nBAnCiYIGd{?;9M>Okfg%*WaY#xxeRYx5EMJMS_2*(mQ2DAegX6&sDEwmn5S(JHMZ9(EfH'
    'Va%@ca5Fr6;Vh6X7TLYuD&#`Wxu8{K(MUtqX+y5~BOQ%0JUv3KNxu^=wPFx)r-fdp15N0HIBB<*h!X1|gJtYqyvk@N{_OOzj{;iR'
    'KSW!LL$NxD-=aI`6XFe9KiNGZbzgBR|JRP22pr8TR^<YlcAL#&UoD6Gx;Ch3^5JaRj5G}D9rVNfA`g&>zxSznb7uJ+|IxEbq7p=8'
    'EMctf1O*mqoNpmz*PfMlG`yUPR(&N4UxS4at>*68Hp<JP63n%z;w?9r5Np23KNRJv62&M-BF&~%w8Av=^#Z%?2UBC!rNxSE2F}J='
    '5Y~m*5E|`)pej5BnXJ%`V^sxwObFFqXata#0`9Y9PXwt7%C{wk=Rzt)WyimZAQw*i;S2;1{}x?eRl%EsYh~c&3fPDwV-B^du2xfV'
    '>xR*CE9!bu0usM~kG`e>3BS#K4N$TuPB;`TJe2(;g^T1hvuajMlXwEc>1%5fUFyUaElQn*);~zL*S>+RHnv8_NVN%>Mp1+pM$f5f'
    'pceTUH`s&&CRt&sCcks^=u8>VIXK^N-K(J&?qOPDtXgBgUCz>)Gmi_c^@8aJmw~KS@v9K#OgvicTxIb%slP=E=uQhFU{fev#mgs5'
    '#J{XdnS72&mY9#CzqeUyu!qqly&Os5*Ck6LFTto*l^d>Jq?f-geyT}Bq(OXq07SAeaTJ)ptO+v%=Q&c#8#y&2EtK<nYTT0%tE`E9'
    'MAU1<mI%cS9=&KxIwyy$`F>43cM<RueLOhWdA2D_$o737Vv4B{==WIQ3o`;Pn?CssVEW3~Sm1$2sDAl4P!-H!Dnp{{s`n9hNe)Py'
    '3Gxa6a-(vZP%%<e8EKx9(VkOk*wy=L4<raSlk)4b)dBv}e;d_3w7P1-|CkbsUZ#OQdI5&?*f4GwMIEI^ZBevnhH3}vYCT4Kp?RYT'
    'ts9bAM*&x(wFyejah**~^MJZW-v!e)PtjwkQR~hU;<&b*btUO1J$yGH5k@NB>8bi5L9~gO%VY+{ETD~up1*BNs1bI95`FvQj_7z='
    '7#mt5Oc;{VF4ww9UO;h*zFS-bg|z2P6`N&VnVK3aE|%yE3DiJSRQn8p9=-;8it7EXa>n_h(7MF=#NZL5R7P9X&1yNpf_He%Ak?Ea'
    'ir9~GwgyR!um~FvkJiZJae$u=jp|Uy+jf9PY<B5?zvYi|JPntat@efj7;jRw6!uqf3)$)qhrHEIzK|)nhSVXw$v^gXzU~|OBpmaS'
    'GL5~Y?15X;;wq<1uG&T>*nQ+~DCJu@{a|E}le|++lAx%mrllE1rhhZt(R?GH;hkpcKUo*}kTJB0*XqsQq~yDUIy}+U;4L}-qD4gq'
    'GL_wKVDbQ%YRQ@noVVg1jsf9<*gpEA*A}4fpKxWsan5_;)rCsUMh>pUC<g4wHoxBftUOgMH!5v3;dS|skZi?NL&;WZk8mnI&T6GR'
    '7flOx8?h?_zPBDW1P0?(yI?e292k;yo@<IYS#A@i32O}uGH#w;f6ULKZVvzm&itt9k>d>B^1$UJ*tsV>=g|o^0`-3K&qRMVwu7~w'
    'Oj{n(RL4Ca5&6?(Vl`Q_2?%^Sn^eL-P20j7(wwybIVbTPMQ@<SPP?`nZA<ktb{XoS?|~8$DN8F45@Z7e(4!j+c+jk7?`QCWA?M=w'
    '%B1>}_G6R(?Z4uEFIO`@SWZGdcy^uB(O1Ao&KAwf<_TjM(xd<q=2NX(fQ5Ugy&YRa)j-1Hc9e5!rSPnAb!yK$#kHKargIc5C|A1)'
    '#u`p<w}#u;`g?FD3Uh&CJ1XB^bfnt*8RqTH+lDV>^jY2fGO0@?dB3i?8>%;DT)235y;Si4hQ@IlrBrZ-Yp&D`?iUd@|ASW`{xx_-'
    '2aU%aZqaXl(}MF#Y>iG|r-Me{QC5(C)o;1Fc4!`3YE<g+D5T-my!+UAxgPFeVF=PkZj4T}Yugl~Tqy~Q>$|UsZ(OpmEwUlpt7)Fk'
    'dsvNfd$|2{K;<dnUjzMwZFvWz7!u+2moJv)JM9(RiM=f?)Yr@ex7T2s_EhvBHkHiYx>|ab*h99nUD%p*V;7q%)6F46wmxf}!jMYr'
    'lBHCSDb&@oBv<R%JNli+xrPsT8oFLS+RzxHk!;iARfyC4_?I<qX8aZKVy(i&v(^}52#YnYc;UWv^jZ#T8(;&kf>%Rw{gFLGr4N|3'
    '9*GSxvjO|$4O=eqoSp`%_!q@0^FoGOsGIp<6pIjkzYg)k2tG=nQqLY!*R>HGF_cEg#kNv|oKvb^KO{90<LY!YSz5pE6=_Yx!!%Qq'
    '2bVMqnk3v<R8x+ksC2FFYkm}>QpF~Ij#x)P2AH4(<|=Dp>0FaxD7A|{BO*l}VoiQ{rS08Ymbb;&O7^bGl8CJD-zM+g$=zW^#Tl}g'
    'f*rs-^^}bxqV<ggI(#09W$>c}L_US^*ZHEj%@#t*7WIp_`xG<ST0wP~mXl(mUMSvg&@EpqT6UY2sqQJFOgK5aWVO8z4;gck%8HV~'
    ';;0xLLQ3j^D2Z}$(G*KT%!dzVFKo!Bx|~KJ&`;?zF{cY=4hW6?o#{{%E}0v3xig3JgOKseO9@h|%3B;a2Jto;6KWdib9Y1Q%)A4k'
    'GgrW}y-=FL5E?AKnr7DlkdOh|Z!QY~^#bRO<Wl}TvtinQ@G_B~n-=4xy~GEv#LRCIMnwbp))=>Wmo`?ZaUvn|{z1q`5mP`6(c}1i'
    'eqZ(MHT7$%euqZv^*aIS!lfY%mz?|-1a0ZX#&93|FtUZ>N!CIoRYFVIr^A(5wZe?wv3$}ZxJxxPazI&`emIPPimy?@;mZ<Mb(c>h'
    '4ymFlqUPKmq0tKdo-K<pMG9g?!!6rZ^ch)H^N&lektR!7alv9$Zt7ceSW!X?J<zcJ6_;B!22{nWL@gM>O7mUE<>+w}_=+>#CzSTY'
    'i(d;+?NN}Jd!P(n26AL}kis?oI_<5$owh+78wF7>5}D^+g;DgD7;KNqT&&n<m1oKFKk;!ds@}JJX}x}~(aTMsY^+TsV{5xMh3spt'
    '&AS=a+H_7hy*62pQQhH!t&ENx%*^IQmau5D2F=XGVt|8TZ}d3$gZ9NMk@Sdv;&c!`S>sx0!=j=(3VDy(g@)^IM&g{D4#Ah)%^(q7'
    '!viMP$s`n)Zlyj!fhCrSD`-WFE>dS6X~@>m52f+8oqc+njAo=>^O!~9eW}qo;!R!8J9k`di~k1oBfP%1B4f3|BzBLr!stA20&5mI'
    'K>`U!`jL2XR|VSW;2LvjjWIysR(hI3r405>8*=Y54N0ghkD);KR0R}ls2^Z_c(G=r?f=NBWU_@!nvj&T%1AYIMmxMp@`Ccu0Jp#)'
    'p2!d^^4koyF}oJIW(NGSKgp{xFeWnFfiu=+K80_T@1SJnPPp6A*i>BtN6eIlz+O!IYsHTOr`n|K!aAp>%r@-Yr}f4T2k@x#m2tg0'
    '$rltpWw-`L*pq;1xP5}@us)Lg44g#`l5Hp0%>vWI1Kyfrg75|!KIO55lbauoaCo*h#_GMtUT!CR{F;i`sU-o!QC<+4B?Ie=4Je3~'
    '94&(*_h$2Jdp$OO+f*xVJANqQ`g?yk8i#F|>mqj@-8L}KXjVrh>LM>b30~UE_k8o4QN&Fj<vw>kCzEjUd9u^@b<~f5iz~_o-x3d_'
    'spDJYU$otJ{8K~C+jvLwn!7;uZ+YW5BK4L#Qh!sQg!tEoUod^F(aR;8d{R=r=1njp+u-9KA|w%pF>r&X`K*a|2;=eRwY@qI@F!|>'
    '`yP4&*SUoaH?ih68bzh+`<s_Ce0u9#P5*j^$7~p){-QRwcwE=5y35<<0yke`PRNf%)91=A!nZnpmp8c2GB+zJ3s6Cdvc4)XKg0>2'
    'j&FGg{DU)SdrT-^TyH2+nml{@Z(sl0!&2cc%aW?qIlDFI^Y~9EwYk5xShieF^^VeLF#o#~RlynT()=TKaLU@onhuRpw!`tIUb?s*'
    'x@B|(r`T;g6PZDPqlP-=6%o%{RIBT?)EO<rzfP@RkF(l9nvpOdMfv6ApYkAHq_58o&d#4R**go2V^}2<+y0nXmPV!is((}>3sa?*'
    '{fcira}E7<2IQK|;Su#d)*6zoUU)<e3MVbL$o1;uQ@Rh254<^Nug_jlZdI?vKUJI8$A|kT&kxdr<DU*sPmW(69G{0;t1PX?HG`M#'
    ';4IQ!jDCEQzBxR8e)6UU?X<Ot@(cs|72|9wG)I>pgiSJF52Uq-^@SPyd8d>&&TyQ}K;219IyTQ(>4fR#;gPw?R@GAImt^vMp<a53'
    'B1oPum3he*jv(EMyvr<B8gyq+Un8Xc2G?ss!||v($!DC)vK6*9@(dR>s1X*7$KdfLg8<2mH>4XB|Li?MHJiGt@pg95qEU`wgfP{!'
    '{SC#Spvz-Cz_<k(tb+>mM%H?EvJs8iqtavWuWO-I3)ET@y&6$$Ei~H%)iz+_tu)&kFyS?k4;aTSkjX|yvSiDAaN*@fG{1)2AnrkU'
    '$?!nu;;lx7yMQBx9_wORy-57k<8PODni|E4<oaTV6*RLcPRmGmZz9F;MwrDMg_)BJGuoSF@u2cN3T*M+$uGQtESHgAC`B{`p%)P2'
    '{J2pk@V!<I7<Hnq_rDfk1k{StA{*khO>1Io+Gsm`wSUw#+|o@vMBCFcgVE#UE@}!!i0I2LXAwW@-15|JoBPOX-kAPK^k^~{w^(rS'
    'nn^DZJ5Bfh%4-t;^7}3MUx4bJhv91+SA%%!B=+mn;-&vNjEhZp*a8RZ@y{2>bMkc&*N4GPKGbq1E*c?^jy*KkQPUX;He9Z*Z_Iqt'
    'wwsMe!Lux;&=v&L3F0&!_!?m<o8N=xJMdZZmpq@7qJZ`+y<E7`n}h(&k&SOqp->7ZR>G%m1H<WBO2A4^r^0~%-CdG9bX(O=5z6bU'
    'nS76iokx1WYHsuzw|Tvryw)vlp1j__$w5H}-{A1z?!ytxC>jBs;zbn~F3L+-`09Rn<G|)KacV>KQ!19)-<Xt5c&bt-G*B5;5EB5i'
    'r_MmiIaGNuQ!JW@>N7E*Vss*fd~%m9$2XJm+Pz{jI+1*xaU^KYD1|Og@c2zi@^vzcdp)5<7*yhG=&}Q8>+r?L!N5mKSX`68<8iVR'
    'kAlStnqd&EEaBy-tqWKPKg~?2Rr^Ig&S9CAu0@@Hgq15CJAAHjH8LJcN{MtFaA=X*64F49m5&dlBJZFh-2sjD!z9^*)v}BA6H)g-'
    'ggC@T%QM`WL0UO&+v*nWa4oKh5jc=9P*SdliqBAHo>J|FEs?;Ad>UcC*=jyqKS7H;4L9q5?38;A8mFZ#NKftr9Xp)#2iE79$)R3%'
    '(_T{(-dt2d!X$xC>)PP(2T+uJ+LTtOc~IW~7gn8qmh2(s<savSya~Hss^S`O7$3M=qKW>1mQ^vyBfJ1r>H-8-eyY=HHpf&POJpX{'
    '&T-9-vwG!^!U{y#fR-ilH2o27y?d_?Ic*}6oGQD=&>?ZPod+24BAFBuXDqD?f}YX<j&CiF^PYsbyG1sivwJYigE3@C60+sMqeCh_'
    'Xp5YiRUF_Yo)0=BL;qPN3ZcO@qLL^AhW|<mGGFHXT_QJ<WnV=&!G?r2KFhl4NFF=8$w2*e5`DMJbrEjckiDY4Qot)<!~~@wWmt4q'
    '!J1v}Hln$8q5&S(kps&T%Wosoj)WEFt#YKTk&LFT+NBAYA`K<QvwFE@=<<tHmqsA~P7E42xvV0Z5k3VX{X=dPJ3q6=J2oFgwDA!('
    'g!19U_4M$9j?3Fzr8#VIh1NH<@CMt|A$842p1csG0G0yfA=&<aQ~jTJ)q~4gyO?de1=M7scJW^{B~041qU}0(Om8u*q4p5}<*!!E'
    'RJ!Jks=Yil#l@Toy<&q3C1ME*9#V+75f-gV5xdu);*#UsmYp-^w<>z8MS-;n+%{FVZ769wXcw}qSyjK4eQf$Z4?4|ktH-X&GROhW'
    '-2N>fIgRvhgBm5}s7^=k0ddrzv3H?5imUI9NMMubd1>06mp`O|GqPh_wS$Z-<8ZijX~q5fEP960()WY$_ja)Bm79dT(Ak6aewzo9'
    'QTyJz-~q_ZU#&AnE0}DO(HfBatKs%qd9A|{{Z1nF<suZj?~^Nhtf;%ax(8(gaK{RE+#YUY7MgGm{F1)h`#C*5*grYmKRh}}&+uQ*'
    '&+4-Z{Dig_;oRY#Pr6XB45SqZAp++q7deKVC5~cSeLybuZnt~N%P8mBf30#pu8Q*X<R9nLVq7ez_X&qLla7fI57U^CaRRfx*_C2q'
    '_^p?P`P0%AeWOyq#kZU?EsBLAQDE15Q==c~G~nw+=l=uIpVn;'
)
_READONLY_BOOTSTRAP_SUPPORT_SHA256 = "4219a1df80d3566a47a954b6e62f51d6f8def052ad8ef01a988baa016df12697"
_READONLY_BOOTSTRAP_SUPPORT_PATHS = (
    "scripts/ctp_i13_i15_guardian_deployment_anchor.py",
    "scripts/ctp_i13_i15_parent_launcher.py",
    "scripts/ctp_i13_i15_runtime_closure.py",
    "scripts/ctp_i13_i15_outer_watchdog.py",
    "scripts/ctp_i13_i15_worker_output_channel.py",
    "scripts/ctp_i13_i15_windows_job_backend.py",
)
_READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES = 4 * 1024 * 1024
_READONLY_BOOTSTRAP_MAX_WORKER_OUTPUT_BYTES = 63 * 1024
_READONLY_BOOTSTRAP_ZERO_SHA256 = "0" * 64


def _readonly_bootstrap_fail(reason):
    sys.stderr.write("readonly_preflight_rejected:" + reason + "\n")
    sys.stderr.flush()
    return 78


def _readonly_bootstrap_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate")
        result[key] = value
    return result


def _readonly_bootstrap_digest(value):
    return (
        type(value) is str
        and len(value) == 64
        and value != _READONLY_BOOTSTRAP_ZERO_SHA256
        and all(char in "0123456789abcdef" for char in value)
    )


def _readonly_bootstrap_binding():
    expected_env_names = {
        "path",
        "systemroot",
        "windir",
        _READONLY_BOOTSTRAP_BINDING_ENV.casefold(),
    }
    folded_env = {}
    for name, value in os.environ.items():
        folded = name.casefold()
        if folded in folded_env:
            raise ValueError("environment")
        folded_env[folded] = value
    if set(folded_env) != expected_env_names:
        raise ValueError("environment")
    raw_text = folded_env[_READONLY_BOOTSTRAP_BINDING_ENV.casefold()]
    if type(raw_text) is not str or not raw_text or len(raw_text) > 4096:
        raise ValueError("binding_size")
    raw = raw_text.encode("ascii", "strict")
    wire_binding = json.loads(raw.decode("ascii"), object_pairs_hook=_readonly_bootstrap_pairs)
    if type(wire_binding) is not dict:
        raise ValueError("binding_fields")
    worker_schema = "ctp_i13_i15_readonly_preflight_bootstrap_binding.v3"
    coordinator_schema = "ctp_i13_i15_readonly_request_coordinator_binding.v1"
    receipt_schema = "ctp_i13_i15_readonly_receipt_writer_binding.v1"
    if wire_binding.get("schema") == worker_schema:
        expected_keys = {
            "schema",
            "deployment_descriptor_sha256",
            "source_manifest_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "dependency_manifest_sha256",
            "runtime_manifest_sha256",
            "python_sha256",
            "deadline_monotonic_ns",
            "request_id",
            "worker_output",
        }
        if set(wire_binding) != expected_keys:
            raise ValueError("binding_fields")
        binding = dict(wire_binding)
        binding["_readonly_role"] = "worker"
        binding["_readonly_role_binding"] = wire_binding
    elif wire_binding.get("schema") == coordinator_schema:
        if set(wire_binding) != {
            "schema", "request_id", "deadline_monotonic_ns", "deployment", "identities",
            "supervisor_output_channel", "token_control_channel",
        }:
            raise ValueError("binding_fields")
        deployment = wire_binding["deployment"]
        if type(deployment) is not dict or set(deployment) != {
            "descriptor_sha256", "source_manifest_sha256", "runtime_manifest_sha256",
            "dependency_manifest_sha256", "python_sha256", "i13_pin_sha256", "i15_pin_sha256",
            "bootstrap_sha256", "worker_sha256", "coordinator_sha256",
            "receipt_writer_sha256", "token_bootstrap_sha256",
        }:
            raise ValueError("deployment_binding")
        binding = {
            "schema": wire_binding["schema"],
            "_readonly_role": "coordinator",
            "_readonly_role_binding": wire_binding,
            "deployment_descriptor_sha256": deployment.get("descriptor_sha256"),
            "source_manifest_sha256": deployment.get("source_manifest_sha256"),
            "i13_pin_sha256": deployment.get("i13_pin_sha256"),
            "i15_pin_sha256": deployment.get("i15_pin_sha256"),
            "bootstrap_sha256": deployment.get("bootstrap_sha256"),
            "worker_sha256": deployment.get("worker_sha256"),
            "dependency_manifest_sha256": deployment.get("dependency_manifest_sha256"),
            "runtime_manifest_sha256": deployment.get("runtime_manifest_sha256"),
            "python_sha256": deployment.get("python_sha256"),
            "deadline_monotonic_ns": wire_binding["deadline_monotonic_ns"],
            "request_id": wire_binding["request_id"],
            "_deployment": dict(deployment),
        }
    elif wire_binding.get("schema") == receipt_schema:
        expected_keys = {
            "schema",
            "request_id",
            "deadline_monotonic_ns",
            "deployment",
            "work_result",
            "coordinator_job",
            "receipt_output_channel",
        }
        if set(wire_binding) != expected_keys:
            raise ValueError("binding_fields")
        deployment = wire_binding["deployment"]
        deployment_keys = {
            "descriptor_sha256",
            "source_manifest_sha256",
            "runtime_manifest_sha256",
            "dependency_manifest_sha256",
            "python_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "coordinator_sha256",
            "receipt_writer_sha256",
            "token_bootstrap_sha256",
        }
        if type(deployment) is not dict or set(deployment) != deployment_keys:
            raise ValueError("deployment_binding")
        channel = wire_binding["receipt_output_channel"]
        if type(channel) is not dict or set(channel) != {"nonce", "server_pid"}:
            raise ValueError("receipt_output_binding")
        binding = {
            "schema": wire_binding["schema"],
            "_readonly_role": "receipt_writer",
            "_readonly_role_binding": wire_binding,
            "deployment_descriptor_sha256": deployment["descriptor_sha256"],
            "source_manifest_sha256": deployment["source_manifest_sha256"],
            "i13_pin_sha256": deployment["i13_pin_sha256"],
            "i15_pin_sha256": deployment["i15_pin_sha256"],
            "bootstrap_sha256": deployment["bootstrap_sha256"],
            "worker_sha256": deployment["worker_sha256"],
            "dependency_manifest_sha256": deployment["dependency_manifest_sha256"],
            "runtime_manifest_sha256": deployment["runtime_manifest_sha256"],
            "python_sha256": deployment["python_sha256"],
            "deadline_monotonic_ns": wire_binding["deadline_monotonic_ns"],
            "request_id": wire_binding["request_id"],
            "receipt_output_channel": channel,
            "_deployment": deployment,
        }
        if any(not _readonly_bootstrap_digest(value) for value in deployment.values()):
            raise ValueError("deployment_digest")
        if (
            type(channel["nonce"]) is not str
            or len(channel["nonce"]) != 32
            or channel["nonce"] == "0" * 32
            or any(char not in "0123456789abcdef" for char in channel["nonce"])
            or type(channel["server_pid"]) is not int
            or channel["server_pid"] <= 0
            or channel["server_pid"] > 0xFFFFFFFF
        ):
            raise ValueError("receipt_output_binding")
    else:
        raise ValueError("binding_schema")
    # Compare canonical wire bytes before adding private in-process aliases.
    canonical_wire = json.dumps(
        wire_binding, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    )
    if canonical_wire.encode("ascii") != raw:
        raise ValueError("binding_canonical")
    if binding["_readonly_role"] == "worker":
        if binding["schema"] != _READONLY_BOOTSTRAP_BINDING_SCHEMA:
            raise ValueError("binding_canonical")
        for name in expected_keys - {"schema", "deadline_monotonic_ns", "request_id", "worker_output"}:
            if not _readonly_bootstrap_digest(binding[name]):
                raise ValueError("binding_digest")
    elif binding["_readonly_role"] == "receipt_writer":
        for name in (
            "deployment_descriptor_sha256",
            "source_manifest_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "dependency_manifest_sha256",
            "runtime_manifest_sha256",
            "python_sha256",
        ):
            if not _readonly_bootstrap_digest(binding[name]):
                raise ValueError("binding_digest")
    else:
        for name in (
            "deployment_descriptor_sha256",
            "source_manifest_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "dependency_manifest_sha256",
            "runtime_manifest_sha256",
            "python_sha256",
        ):
            if not _readonly_bootstrap_digest(binding[name]):
                raise ValueError("binding_digest")
    request_id = binding["request_id"]
    if (
        type(request_id) is not str
        or len(request_id) != 32
        or request_id == "0" * 32
        or any(char not in "0123456789abcdef" for char in request_id)
    ):
        raise ValueError("request_id")
    if binding["_readonly_role"] == "worker":
        worker_output = binding["worker_output"]
        if type(worker_output) is not dict or set(worker_output) != {"nonce", "server_pid"}:
            raise ValueError("worker_output_binding")
        nonce = worker_output["nonce"]
        server_pid = worker_output["server_pid"]
        if (
            type(nonce) is not str
            or len(nonce) != 32
            or nonce == "0" * 32
            or any(char not in "0123456789abcdef" for char in nonce)
            or type(server_pid) is not int
            or server_pid <= 0
            or server_pid > 0xFFFFFFFF
        ):
            raise ValueError("worker_output_binding")
    deadline = binding["deadline_monotonic_ns"]
    if type(deadline) is not int or deadline <= 0 or time.monotonic_ns() >= deadline:
        raise ValueError("deadline")
    return binding, folded_env


def _readonly_bootstrap_support():
    try:
        compressed = base64.b85decode(_READONLY_BOOTSTRAP_SUPPORT_B85.encode("ascii"))
        raw = zlib.decompress(compressed)
    except BaseException:
        raise ValueError("embedded_support_encoding") from None
    if (
        not raw
        or len(raw) > _READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES
        or hashlib.sha256(raw).hexdigest() != _READONLY_BOOTSTRAP_SUPPORT_SHA256
    ):
        raise ValueError("embedded_support_digest")
    if type(raw) is not bytes or len(raw) < 4:
        raise ValueError("embedded_support_schema")
    header_size = int.from_bytes(raw[:4], "big", signed=False)
    if header_size <= 0 or header_size > 64 * 1024 or 4 + header_size > len(raw):
        raise ValueError("embedded_support_schema")
    try:
        value = json.loads(
            raw[4 : 4 + header_size].decode("ascii", "strict"),
            object_pairs_hook=_readonly_bootstrap_pairs,
        )
    except (UnicodeError, ValueError, json.JSONDecodeError):
        raise ValueError("embedded_support_schema") from None
    if (
        type(value) is not dict
        or set(value) != {"schema", "files"}
        or value["schema"] != _READONLY_BOOTSTRAP_SUPPORT_SCHEMA
    ):
        raise ValueError("embedded_support_schema")
    rows = value["files"]
    if type(rows) is not list or len(rows) != len(_READONLY_BOOTSTRAP_SUPPORT_PATHS):
        raise ValueError("embedded_support_files")
    sources = {}
    digests = {}
    cursor = 4 + header_size
    for expected_path, row in zip(_READONLY_BOOTSTRAP_SUPPORT_PATHS, rows):
        if type(row) is not dict or set(row) != {"path", "sha256", "size"}:
            raise ValueError("embedded_support_row")
        size = row["size"]
        if (
            row["path"] != expected_path
            or not _readonly_bootstrap_digest(row["sha256"])
            or type(size) is not int
            or size <= 0
            or size > _READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES
            or cursor + size > len(raw)
        ):
            raise ValueError("embedded_support_binding")
        source = raw[cursor : cursor + size]
        cursor += size
        if hashlib.sha256(source).hexdigest() != row["sha256"]:
            raise ValueError("embedded_support_source_digest")
        source.decode("utf-8", "strict")
        sources[expected_path] = source
        digests[expected_path] = row["sha256"]
    if cursor != len(raw):
        raise ValueError("embedded_support_trailing_bytes")
    return sources, digests


def _readonly_bootstrap_exec_support(sources, relative_path, name):
    source = sources[relative_path]
    namespace = {"__name__": name, "__file__": "<fixed-embedded-source>"}
    exec(compile(source, "<fixed-embedded-source>", "exec", dont_inherit=True), namespace)
    return namespace


def _readonly_bootstrap_exec_support_modules(sources, digests, finder):
    fixed_paths = (
        "scripts/ctp_i13_i15_outer_watchdog.py",
        "scripts/ctp_i13_i15_worker_output_channel.py",
        "scripts/ctp_i13_i15_windows_job_backend.py",
    )
    if (
        any(name == "scripts" or name.startswith("scripts.") for name in sys.modules)
        or type(finder) is not SealedSourceFinder
    ):
        raise ValueError("bootstrap_support_import_state_invalid")
    package = type(sys)("scripts")
    finder._begin_fixed_bootstrap_support_package(
        package, capability=_FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN
    )
    modules = {}
    for relative_path in fixed_paths:
        module = finder._load_fixed_bootstrap_support_module(
            relative_path,
            sources[relative_path],
            expected_sha256=digests[relative_path],
            capability=_FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN,
        )
        modules[relative_path] = module
    return modules


def _readonly_bootstrap_architecture():
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    get_process = kernel32.GetCurrentProcess
    get_process.argtypes = []
    get_process.restype = ctypes.c_void_p
    query_arch = getattr(kernel32, "IsWow64Process2", None)
    if query_arch is None:
        raise ValueError("architecture_unavailable")
    query_arch.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ushort), ctypes.POINTER(ctypes.c_ushort)]
    query_arch.restype = ctypes.c_int
    process_machine = ctypes.c_ushort()
    native_machine = ctypes.c_ushort()
    if not query_arch(
        get_process(), ctypes.byref(process_machine), ctypes.byref(native_machine)
    ):
        raise ValueError("architecture_unavailable")
    machine = process_machine.value or native_machine.value
    if machine == 0x8664:
        return "AMD64"
    if machine == 0xAA64:
        return "ARM64"
    if machine == 0x014C:
        return "x86"
    return "unknown"


def _readonly_bootstrap_token_sid():
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    token = ctypes.c_void_p()
    open_token = advapi32.OpenProcessToken
    open_token.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p)]
    open_token.restype = ctypes.c_int
    get_process = kernel32.GetCurrentProcess
    get_process.argtypes = []
    get_process.restype = ctypes.c_void_p
    if not open_token(get_process(), 0x0008, ctypes.byref(token)):
        raise ValueError("token_unavailable")
    try:
        get_info = advapi32.GetTokenInformation
        get_info.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
        get_info.restype = ctypes.c_int
        required = ctypes.c_uint32()
        get_info(token, 1, None, 0, ctypes.byref(required))
        if required.value <= 0 or required.value > 65536:
            raise ValueError("token_unavailable")
        buffer = ctypes.create_string_buffer(required.value)
        if not get_info(token, 1, buffer, required.value, ctypes.byref(required)):
            raise ValueError("token_unavailable")
        class _SidAndAttributes(ctypes.Structure):
            _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", ctypes.c_uint32)]
        user = _SidAndAttributes.from_buffer(buffer)
        if not user.Sid:
            raise ValueError("token_unavailable")
        sid_text = ctypes.c_wchar_p()
        convert = advapi32.ConvertSidToStringSidW
        convert.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)]
        convert.restype = ctypes.c_int
        if not convert(user.Sid, ctypes.byref(sid_text)):
            raise ValueError("token_unavailable")
        try:
            value = sid_text.value
            if type(value) is not str or not value:
                raise ValueError("token_unavailable")
            return value
        finally:
            local_free = kernel32.LocalFree
            local_free.argtypes = [ctypes.c_void_p]
            local_free.restype = ctypes.c_void_p
            local_free(ctypes.cast(sid_text, ctypes.c_void_p))
    finally:
        close = kernel32.CloseHandle
        close.argtypes = [ctypes.c_void_p]
        close.restype = ctypes.c_int
        close(token)


def _readonly_bootstrap_retain_paths(anchor_ns, root, files, directories):
    root = anchor_ns["_canonical_windows_path"](root, "runtime_root_invalid")
    if type(files) not in (tuple, list) or type(directories) not in (tuple, list):
        raise ValueError("runtime_path_set_invalid")
    protected_type = anchor_ns["_ProtectedWindowsPaths"]
    protected = protected_type(frozenset({anchor_ns["_SYSTEM_SID"], anchor_ns["_ADMINISTRATORS_SID"]}))
    try:
        protected.add_paths(
            (root,),
            directory_paths=frozenset({root}),
            listable_directory_paths=frozenset({root}),
        )
        for relative in directories:
            if type(relative) is not str or "\\" in relative:
                raise ValueError("runtime_path_set_invalid")
            if relative == "":
                continue
            relative_path = PurePosixPath(relative)
            if (
                relative_path.as_posix() != relative
                or relative_path.is_absolute()
                or any(part in {"", ".", ".."} for part in relative_path.parts)
            ):
                raise ValueError("runtime_path_set_invalid")
            path = ntpath.join(root, *relative.split("/"))
            protected.add_paths(
                (path,),
                directory_paths=frozenset({path}),
                listable_directory_paths=frozenset({path}),
            )
        for relative in files:
            if type(relative) is not str or not relative or "\\" in relative:
                raise ValueError("runtime_path_set_invalid")
            relative_path = PurePosixPath(relative)
            if (
                relative_path.as_posix() != relative
                or relative_path.is_absolute()
                or any(part in {"", ".", ".."} for part in relative_path.parts)
            ):
                raise ValueError("runtime_path_set_invalid")
            path = ntpath.join(root, *relative.split("/"))
            protected.add_paths((path,))
        return anchor_ns["_RetainedDependencyPaths"](root, protected)
    except BaseException:
        try:
            protected.close()
        except BaseException:
            pass
        raise


def _readonly_bootstrap_run_receipt_writer(
    binding,
    *,
    raw_binding,
    anchor_ns,
    descriptor,
    parent_facts,
    source_seal,
    source_finder,
    dependency_seal,
    runtime_seal,
    anchor_paths,
    support_modules,
):
    """Run only the sealed receipt-writer role with a fixed protected root."""

    if (
        binding.get("_readonly_role") != "receipt_writer"
        or type(raw_binding) is not dict
        or raw_binding.get("schema") != "ctp_i13_i15_readonly_receipt_writer_binding.v1"
        or type(source_finder) is not SealedSourceFinder
        or source_finder._seal is not source_seal
        or source_finder._runtime_closure is not runtime_seal
        or source_finder._dependency_finder is None
    ):
        raise ValueError("receipt_writer_runtime_unavailable")

    role_module = None
    receipt_paths = None
    runtime = None
    try:
        role_module = _open_fixed_readonly_role_module(
            source_seal, source_finder, "receipt_writer"
        )
        parsed_binding = role_module.parse_receipt_writer_binding(raw_binding)
        if (
            parsed_binding.request_id != binding["request_id"]
            or parsed_binding.deadline_monotonic_ns != binding["deadline_monotonic_ns"]
            or dict(parsed_binding.deployment) != binding["_deployment"]
        ):
            raise ValueError("receipt_writer_binding_mismatch")

        expected_deployment = {
            "descriptor_sha256": descriptor.descriptor_sha256,
            "source_manifest_sha256": source_seal.manifest_sha256,
            "runtime_manifest_sha256": runtime_seal.manifest_sha256,
            "dependency_manifest_sha256": dependency_seal.manifest_sha256,
            "python_sha256": descriptor.python_sha256,
            "i13_pin_sha256": parent_facts.candidates["i13_md"]["pin_sha256"],
            "i15_pin_sha256": parent_facts.candidates["i15_td"]["pin_sha256"],
            "bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
            ),
            "worker_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_worker.py"
            ),
            "coordinator_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_request_coordinator.py"
            ),
            "receipt_writer_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_receipt_writer.py"
            ),
            "token_bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_token_bootstrap.py"
            ),
        }
        if any(type(value) is not str or not _readonly_bootstrap_digest(value) for value in expected_deployment.values()):
            raise ValueError("receipt_writer_deployment_incomplete")
        if dict(parsed_binding.deployment) != expected_deployment:
            raise ValueError("receipt_writer_deployment_mismatch")

        support_path = "scripts/ctp_i13_i15_worker_output_channel.py"
        output_channel_module = support_modules.get(support_path)
        if (
            output_channel_module is None
            or not source_finder._owns_fixed_bootstrap_support(
                "scripts.ctp_i13_i15_worker_output_channel", output_channel_module
            )
            or sys.modules.get("scripts.ctp_i13_i15_worker_output_channel")
            is not output_channel_module
        ):
            raise ValueError("receipt_writer_output_channel_unavailable")

        now_ns = time.monotonic_ns()
        if type(now_ns) is not int or now_ns >= parsed_binding.deadline_monotonic_ns:
            raise ValueError("deadline")

        program_data = anchor_ns["_program_data_path"]()
        fixed_root, _descriptor_path, _auth_key_path, _dependency_path, _runtime_path, receipt_root = (
            anchor_ns["_fixed_paths"](program_data)
        )
        expected_fixed_root = ntpath.join(
            program_data, *anchor_ns["FIXED_PROGRAMDATA_RELATIVE"].parts
        )
        if ntpath.normcase(ntpath.normpath(fixed_root)) != ntpath.normcase(
            ntpath.normpath(expected_fixed_root)
        ):
            raise ValueError("receipt_root_binding")

        integrity_sids = frozenset(
            {anchor_ns["_SYSTEM_SID"], anchor_ns["_ADMINISTRATORS_SID"]}
        )
        receipt_paths = anchor_ns["_ProtectedWindowsPaths"](integrity_sids)
        receipt_paths.add_paths(
            (receipt_root,),
            directory_paths=frozenset({receipt_root}),
            writable_paths=frozenset({receipt_root}),
            writer_sids_by_path={
                receipt_root: frozenset(
                    {
                        anchor_ns["_SYSTEM_SID"],
                        anchor_ns["_ADMINISTRATORS_SID"],
                        descriptor.service_sid,
                    }
                )
            },
        )
        if time.monotonic_ns() >= parsed_binding.deadline_monotonic_ns:
            raise ValueError("deadline")

        class _FixedReceiptWriterRuntime:
            __slots__ = (
                "_created",
                "_creation_started",
                "_execution_close_attempted",
                "_execution_close_errors",
                "_output_started",
                "_closed",
            )

            def __init__(self):
                self._created = False
                self._creation_started = False
                self._execution_close_attempted = False
                self._execution_close_errors = ()
                self._output_started = False
                self._closed = False

            def _check_deadline(self):
                now = time.monotonic_ns()
                if type(now) is not int or now < 0 or now >= parsed_binding.deadline_monotonic_ns:
                    raise ValueError("deadline")

            def _verify_current(self):
                self._check_deadline()
                if self._execution_close_attempted:
                    raise ValueError("execution_leases_already_closed")
                _require_clean_after_install(source_seal, finder=source_finder)
                source_seal.source_lease.verify_current()
                dependency_seal.verify_current()
                runtime_seal.verify_current()
                anchor_paths.verify_current()
                receipt_paths.verify_current()
                descriptor_raw = anchor_paths.read_file(
                    ntpath.join(
                        program_data,
                        *anchor_ns["FIXED_PROGRAMDATA_RELATIVE"].parts,
                        anchor_ns["FIXED_DESCRIPTOR_NAME"],
                    ),
                    max_bytes=anchor_ns["_MAX_DESCRIPTOR_BYTES"],
                )
                if hashlib.sha256(descriptor_raw).hexdigest() != descriptor.descriptor_sha256:
                    raise ValueError("deployment_changed")
                _require_clean_after_install(source_seal, finder=source_finder)
                self._check_deadline()

            def monotonic_ns(self):
                return time.monotonic_ns()

            def verify_deployment(self, deployment):
                if (
                    self._closed
                    or self._execution_close_attempted
                    or dict(deployment) != expected_deployment
                ):
                    raise ValueError("deployment_binding_mismatch")
                self._verify_current()

            def close_execution(self):
                if self._closed or self._execution_close_attempted:
                    raise ValueError("execution_close_reentry")
                self._execution_close_attempted = True
                errors = []
                if source_finder._runtime_closure is runtime_seal:
                    try:
                        source_finder.detach_runtime_closure(runtime_seal)
                    except Exception:
                        errors.append("runtime_closure_detach_failed")
                if source_finder._dependency_finder is not None:
                    dependency_finder_value = source_finder._dependency_finder
                    try:
                        source_finder.detach_dependency_finder(dependency_finder_value)
                    except Exception:
                        errors.append("dependency_finder_detach_failed")
                for name, close in (
                    ("runtime_closure_close_failed", runtime_seal.close),
                    ("dependency_seal_close_failed", dependency_seal.close),
                    ("source_seal_close_failed", source_seal.close),
                    ("anchor_paths_close_failed", anchor_paths.close),
                ):
                    try:
                        close()
                    except Exception:
                        errors.append(name)
                self._execution_close_errors = tuple(errors)
                self._check_deadline()
                if errors:
                    raise ValueError("deployment_execution_lease_close_failed")

            def persist_fixed_receipt(self, request_id, raw):
                if (
                    self._closed
                    or self._creation_started
                    or not self._execution_close_attempted
                    or request_id != parsed_binding.request_id
                    or type(raw) is not bytes
                    or not raw
                    or len(raw) > 64 * 1024
                ):
                    raise ValueError("receipt_write_binding_invalid")
                self._creation_started = True
                self._check_deadline()
                if dict(parsed_binding.deployment) != expected_deployment:
                    raise ValueError("deployment_binding_mismatch")
                receipt_paths.verify_current()
                created_path = receipt_paths.create_new_receipt(
                    receipt_root, parsed_binding.request_id, raw
                )
                target_path = ntpath.join(receipt_root, parsed_binding.request_id + ".json")
                if ntpath.normcase(ntpath.normpath(created_path)) != ntpath.normcase(
                    ntpath.normpath(target_path)
                ):
                    raise ValueError("receipt_target_mismatch")
                self._check_deadline()
                receipt_paths.add_paths((target_path,))
                readback = receipt_paths.read_file(target_path, max_bytes=64 * 1024)
                if readback != raw:
                    raise ValueError("receipt_readback_mismatch")
                self._check_deadline()
                self._created = True

            def write_supervisor_output(self, binding_value, output):
                if (
                    self._closed
                    or self._output_started
                    or not self._execution_close_attempted
                ):
                    raise ValueError("receipt_output_reentry")
                if (
                    type(binding_value) is not type(parsed_binding)
                    or binding_value != parsed_binding
                ):
                    raise ValueError("receipt_output_binding_mismatch")
                self._output_started = True
                self._check_deadline()
                receipt_paths.verify_current()
                self._check_deadline()
                nonce = parsed_binding.receipt_output_channel["nonce"]
                server_pid = parsed_binding.receipt_output_channel["server_pid"]
                frame_body = role_module.encode_receipt_writer_frame(
                    dict(output), request_id=parsed_binding.request_id, nonce=nonce
                )
                if type(frame_body) is not bytes or not frame_body or len(frame_body) > 64 * 1024:
                    raise ValueError("receipt_output_frame_size_invalid")
                frame = len(frame_body).to_bytes(4, "big", signed=False) + frame_body
                output_channel_module._write_bounded_frame(
                    frame,
                    nonce=nonce,
                    expected_server_pid=server_pid,
                    deadline_monotonic_ns=parsed_binding.deadline_monotonic_ns,
                )

            def close(self):
                if self._closed:
                    return
                self._closed = True
                errors = []
                try:
                    receipt_paths.close()
                except BaseException:
                    errors.append("receipt_path_close_failed")
                try:
                    source_finder._end_fixed_role_module("receipt_writer", role_module)
                except BaseException:
                    errors.append("receipt_role_unload_failed")
                if errors:
                    raise ValueError(";".join(errors))

        runtime = _FixedReceiptWriterRuntime()
        result = role_module.main(raw_binding, runtime)
        if type(result) is not int or result not in {0, 2}:
            raise ValueError("receipt_writer_result_invalid")
        return result
    finally:
        if runtime is not None:
            runtime.close()
        else:
            cleanup_error = None
            if receipt_paths is not None:
                try:
                    receipt_paths.close()
                except BaseException:
                    cleanup_error = True
            if role_module is not None:
                try:
                    source_finder._end_fixed_role_module("receipt_writer", role_module)
                except BaseException:
                    cleanup_error = True
            if cleanup_error:
                raise ValueError("receipt_writer_cleanup_failed")


def _readonly_bootstrap_run_coordinator(
    binding,
    *,
    raw_binding,
    descriptor,
    parent_facts,
    source_seal,
    source_finder,
    dependency_seal,
    runtime_seal,
    anchor_paths,
    support_modules,
):
    """Run the fixed coordinator from its retained source bytes."""

    if (
        binding.get("_readonly_role") != "coordinator"
        or type(raw_binding) is not dict
        or raw_binding.get("schema")
        != "ctp_i13_i15_readonly_request_coordinator_binding.v1"
        or type(source_finder) is not SealedSourceFinder
        or source_finder._seal is not source_seal
        or source_finder._runtime_closure is not runtime_seal
        or source_finder._dependency_finder is None
    ):
        raise ValueError("coordinator_runtime_unavailable")
    coordinator_module = None
    token_module = None
    runtime = None
    try:
        coordinator_module = _open_fixed_readonly_role_module(
            source_seal, source_finder, "request_coordinator"
        )
        token_module = _open_fixed_readonly_role_module(
            source_seal, source_finder, "token_bootstrap"
        )
        parsed = coordinator_module.parse_coordinator_binding(raw_binding)
        expected = {
            "descriptor_sha256": descriptor.descriptor_sha256,
            "source_manifest_sha256": source_seal.manifest_sha256,
            "runtime_manifest_sha256": runtime_seal.manifest_sha256,
            "dependency_manifest_sha256": dependency_seal.manifest_sha256,
            "python_sha256": descriptor.python_sha256,
            "i13_pin_sha256": parent_facts.candidates["i13_md"]["pin_sha256"],
            "i15_pin_sha256": parent_facts.candidates["i15_td"]["pin_sha256"],
            "bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
            ),
            "worker_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_worker.py"
            ),
            "coordinator_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_request_coordinator.py"
            ),
            "receipt_writer_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_receipt_writer.py"
            ),
            "token_bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_token_bootstrap.py"
            ),
        }
        if (
            any(not _readonly_bootstrap_digest(value) for value in expected.values())
            or dict(parsed.deployment) != expected
            or parsed.request_id != binding["request_id"]
            or parsed.deadline_monotonic_ns != binding["deadline_monotonic_ns"]
        ):
            raise ValueError("coordinator_deployment_binding")
        output_channel_module = support_modules.get(
            "scripts/ctp_i13_i15_worker_output_channel.py"
        )
        if (
            output_channel_module is None
            or not source_finder._owns_fixed_bootstrap_support(
                "scripts.ctp_i13_i15_worker_output_channel", output_channel_module
            )
            or sys.modules.get("scripts.ctp_i13_i15_worker_output_channel")
            is not output_channel_module
        ):
            raise ValueError("coordinator_output_channel_unavailable")
        runtime = coordinator_module.BootstrapCoordinatorRuntime(
            parsed,
            descriptor=descriptor,
            parent_facts=parent_facts,
            source_seal=source_seal,
            source_finder=source_finder,
            dependency_seal=dependency_seal,
            runtime_seal=runtime_seal,
            anchor_paths=anchor_paths,
            support_modules=support_modules,
            token_module=token_module,
            output_channel_module=output_channel_module,
            expected_deployment=expected,
        )
        result = coordinator_module.main(raw_binding, runtime)
        if type(result) is not int or result not in {0, 2}:
            raise ValueError("coordinator_result_invalid")
        return result
    finally:
        if runtime is not None:
            runtime.close()
        if token_module is not None:
            source_finder._end_fixed_role_module("token_bootstrap", token_module)
        if coordinator_module is not None:
            source_finder._end_fixed_role_module("request_coordinator", coordinator_module)


def _readonly_bootstrap_detach_runtime_closure(source_finder, expected_seal):
    active = source_finder._runtime_closure
    if active is None:
        return
    if active is not expected_seal:
        raise ValueError("runtime_closure_replaced")
    source_finder.detach_runtime_closure(expected_seal)


def _readonly_bootstrap_detach_dependency_finder(source_finder, expected_finder):
    active = source_finder._dependency_finder
    if active is None:
        return
    if active is not expected_finder:
        raise ValueError("dependency_finder_replaced")
    source_finder.detach_dependency_finder(expected_finder)


def _readonly_bootstrap_run():
    stage = "binding"
    anchor_paths = None
    source_seal = None
    source_finder = None
    dependency_seal = None
    dependency_finder = None
    runtime_seal = None
    support_modules = None
    result = 78
    try:
        binding, env = _readonly_bootstrap_binding()
        if len(sys.argv) != 1:
            raise ValueError("argv")
        script_path = ntpath.normcase(ntpath.normpath(os.path.abspath(__file__)))
        bootstrap_relative = "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
        source_root = ntpath.dirname(ntpath.dirname(script_path))
        if not ntpath.isabs(source_root) or ":" not in source_root[:3]:
            raise ValueError("source_root")
        if script_path != ntpath.normcase(ntpath.normpath(ntpath.join(source_root, bootstrap_relative))):
            raise ValueError("bootstrap_path")
        if ntpath.normcase(ntpath.normpath(env["path"])) != ntpath.normcase(
            ntpath.normpath(ntpath.dirname(sys.executable))
        ):
            raise ValueError("process_path")
        if not env["systemroot"] or env["systemroot"] != env["windir"]:
            raise ValueError("system_root")
        if type(sys.argv[0]) is not str or ntpath.normcase(ntpath.normpath(os.path.abspath(sys.argv[0]))) != script_path:
            raise ValueError("argv")
        if time.monotonic_ns() >= binding["deadline_monotonic_ns"]:
            raise ValueError("deadline")

        stage = "embedded_source"
        sources, support_sha256s = _readonly_bootstrap_support()
        anchor_ns = _readonly_bootstrap_exec_support(
            sources,
            "scripts/ctp_i13_i15_guardian_deployment_anchor.py",
            "_i13_fixed_deployment_anchor",
        )
        parent_ns = _readonly_bootstrap_exec_support(
            sources,
            "scripts/ctp_i13_i15_parent_launcher.py",
            "_i13_fixed_parent_launcher",
        )
        runtime_ns = _readonly_bootstrap_exec_support(
            sources,
            "scripts/ctp_i13_i15_runtime_closure.py",
            "_i13_fixed_runtime_closure",
        )
        stage = "deployment_descriptor"
        program_data = anchor_ns["_program_data_path"]()
        fixed_root = ntpath.join(program_data, *anchor_ns["FIXED_PROGRAMDATA_RELATIVE"].parts)
        descriptor_path = ntpath.join(fixed_root, anchor_ns["FIXED_DESCRIPTOR_NAME"])
        dependency_path = ntpath.join(fixed_root, anchor_ns["FIXED_DEPENDENCY_MANIFEST_NAME"])
        runtime_path = ntpath.join(fixed_root, anchor_ns["FIXED_RUNTIME_MANIFEST_NAME"])
        integrity_sids = frozenset({anchor_ns["_SYSTEM_SID"], anchor_ns["_ADMINISTRATORS_SID"]})
        anchor_paths = anchor_ns["_ProtectedWindowsPaths"](integrity_sids)
        anchor_paths.add_paths((descriptor_path, dependency_path, runtime_path))
        descriptor_raw = anchor_paths.read_file(
            descriptor_path, max_bytes=anchor_ns["_MAX_DESCRIPTOR_BYTES"]
        )
        descriptor = anchor_ns["_parse_deployment_descriptor"](
            descriptor_raw,
            expected_sha256=anchor_ns["GUARDIAN_DEPLOYMENT_DESCRIPTOR_SHA256"],
            expected_worker_dependency_sha256=anchor_ns["WORKER_DEPENDENCY_MANIFEST_SHA256"],
            expected_runtime_manifest_sha256=anchor_ns["RUNTIME_MANIFEST_SHA256"],
        )
        anchor_paths.verify_current()
        if (
            descriptor.descriptor_sha256 != binding["deployment_descriptor_sha256"]
            or descriptor.source_manifest_sha256 != binding["source_manifest_sha256"]
            or descriptor.worker_dependency_manifest_sha256 != binding["dependency_manifest_sha256"]
            or descriptor.runtime_manifest_sha256 != binding["runtime_manifest_sha256"]
            or descriptor.python_sha256 != binding["python_sha256"]
            or descriptor.worker_sha256 != binding["worker_sha256"]
            or ntpath.normcase(descriptor.source_root) != ntpath.normcase(source_root)
            or _readonly_bootstrap_token_sid()
            != (
                descriptor.client_sid
                if binding["_readonly_role"] == "worker"
                else descriptor.service_sid
            )
        ):
            raise ValueError("deployment_binding")

        stage = "parent_descriptor"
        parent_descriptor = parent_ns["ExternallyPinnedDescriptor"](
            raw_bytes=descriptor.parent_trust_raw,
            sha256=descriptor.parent_trust_sha256,
            external_anchor_id="ctp-i13-i15-guardian-deployment-v2",
        )
        parent_facts = parent_ns["parse_trust_descriptor"](parent_descriptor)
        if (
            ntpath.normcase(parent_facts.source_root) != ntpath.normcase(source_root)
            or ntpath.normcase(parent_facts.python_executable)
            != ntpath.normcase(descriptor.python_executable)
            or parent_facts.python_sha256 != descriptor.python_sha256
            or parent_facts.python_version != descriptor.python_version
            or parent_facts.python_architecture != descriptor.python_architecture
            or parent_facts.candidates["i13_md"]["manifest_sha256"]
            != descriptor.source_manifest_sha256
            or parent_facts.candidates["i13_md"]["pin_sha256"] != binding["i13_pin_sha256"]
            or parent_facts.candidates["i15_td"]["pin_sha256"] != binding["i15_pin_sha256"]
        ):
            raise ValueError("parent_binding")
        actual_version = ".".join(str(part) for part in sys.version_info[:3])
        actual_architecture = _readonly_bootstrap_architecture()
        plan = parent_ns["preflight_parent_launch"](
            parent_descriptor,
            candidate="i13_md",
            captured_launcher_bytes=sources["scripts/ctp_i13_i15_parent_launcher.py"],
            actual_executable=os.path.abspath(sys.executable),
            actual_version=actual_version,
            actual_architecture=actual_architecture,
            actual_sys_path=tuple(sys.path),
        )
        if (
            ntpath.normcase(plan.source_root) != ntpath.normcase(source_root)
            or plan.manifest_sha256 != binding["source_manifest_sha256"]
            or plan.python_sha256 != binding["python_sha256"]
        ):
            raise ValueError("parent_plan")
        expected_pycache_prefix = ntpath.join(
            parent_facts.python_home, "disabled-bytecode-cache"
        )
        if (
            not ntpath.isabs(expected_pycache_prefix)
            or ntpath.normcase(ntpath.normpath(sys.pycache_prefix))
            != ntpath.normcase(ntpath.normpath(expected_pycache_prefix))
            or os.path.exists(expected_pycache_prefix)
        ):
            raise ValueError("pycache_prefix_binding")

        stage = "source_seal"
        source_seal = seal_candidate_source_tree(
            "i13_md",
            source_root,
            expected_manifest_sha256=plan.manifest_sha256,
            expected_pin_sha256s=dict(plan.pin_source_sha256s),
            stdlib_paths=plan.stdlib_paths,
        )
        if (
            source_seal.files.get(bootstrap_relative) != binding["bootstrap_sha256"]
            or source_seal.files.get("scripts/ctp_i13_i15_readonly_preflight_worker.py")
            != binding["worker_sha256"]
            or source_seal.source_lease.read_source(
                bootstrap_relative, expected_sha256=binding["bootstrap_sha256"]
            )
            != open(__file__, "rb").read()
        ):
            raise ValueError("bootstrap_source_binding")
        if binding["_readonly_role"] in {"coordinator", "receipt_writer"}:
            role_source_digests = {
                "scripts/ctp_i13_i15_readonly_request_coordinator.py": binding[
                    "_deployment"
                ]["coordinator_sha256"],
                "scripts/ctp_i13_i15_readonly_receipt_writer.py": binding[
                    "_deployment"
                ]["receipt_writer_sha256"],
                "scripts/ctp_i13_i15_readonly_token_bootstrap.py": binding[
                    "_deployment"
                ]["token_bootstrap_sha256"],
            }
            if any(source_seal.files.get(path) != digest for path, digest in role_source_digests.items()):
                raise ValueError("service_role_source_binding")
        source_finder = install_sealed_source_finder(source_seal)

        stage = "dependency_seal"
        from backtrader_runtime import ctp_i13_worker_dependency_seal as dependency_api

        dependency_raw = dependency_api.read_fixed_worker_dependency_manifest(
            lambda: anchor_paths.read_file(dependency_path, max_bytes=1024 * 1024),
            expected_sha256=binding["dependency_manifest_sha256"],
        )
        dependency_root = ntpath.join(
            ntpath.dirname(ntpath.dirname(os.path.abspath(sys.executable))),
            "Lib",
            "site-packages",
        )
        if ntpath.normcase(dependency_root) != ntpath.normcase(
            ntpath.join(parent_facts.venv_root, "Lib", "site-packages")
        ):
            raise ValueError("dependency_root")
        dependency_seal = dependency_api.seal_worker_dependencies(
            dependency_raw,
            expected_manifest_sha256=binding["dependency_manifest_sha256"],
            python_executable=sys.executable,
            retain_paths=lambda files, directories: _readonly_bootstrap_retain_paths(
                anchor_ns, dependency_root, files, directories
            ),
        )
        if dependency_seal.manifest_sha256 != binding["dependency_manifest_sha256"]:
            raise ValueError("dependency_manifest_binding")
        dependency_finder = dependency_api.install_worker_dependency_finder(dependency_seal)

        stage = "runtime_seal"
        runtime_raw = anchor_paths.read_file(runtime_path, max_bytes=4 * 1024 * 1024)
        if hashlib.sha256(runtime_raw).hexdigest() != binding["runtime_manifest_sha256"]:
            raise ValueError("runtime_manifest_digest")
        descriptor_facts = {
            "python_executable": parent_facts.python_executable,
            "python_sha256": parent_facts.python_sha256,
            "python_version": parent_facts.python_version,
            "python_architecture": parent_facts.python_architecture,
            "python_home": parent_facts.python_home,
            "venv_root": parent_facts.venv_root,
            "pyvenv_cfg_sha256": parent_facts.pyvenv_cfg_sha256,
            "stdlib_paths": parent_facts.stdlib_paths,
        }
        process_facts = runtime_ns["capture_runtime_process_facts"]()
        runtime_seal = runtime_ns["seal_runtime_closure"](
            runtime_raw,
            expected_manifest_sha256=binding["runtime_manifest_sha256"],
            descriptor_facts=descriptor_facts,
            process_facts=process_facts,
            dependency_seal=dependency_seal,
            retain_paths=lambda root_kind, files, directories: _readonly_bootstrap_retain_paths(
                anchor_ns,
                parent_facts.python_home if root_kind == "base" else parent_facts.venv_root,
                files,
                directories,
            ),
        )
        source_finder.attach_runtime_closure(runtime_seal)
        source_seal.source_lease.verify_current()
        dependency_seal.verify_current()
        runtime_seal.verify_current()
        anchor_paths.verify_current()
        if time.monotonic_ns() >= binding["deadline_monotonic_ns"]:
            raise ValueError("deadline")

        stage = "embedded_process_support"
        support_modules = _readonly_bootstrap_exec_support_modules(
            sources, support_sha256s, source_finder
        )
        if binding["_readonly_role"] == "coordinator":
            stage = "coordinator"
            result = _readonly_bootstrap_run_coordinator(
                binding,
                raw_binding=binding["_readonly_role_binding"],
                descriptor=descriptor,
                parent_facts=parent_facts,
                source_seal=source_seal,
                source_finder=source_finder,
                dependency_seal=dependency_seal,
                runtime_seal=runtime_seal,
                anchor_paths=anchor_paths,
                support_modules=support_modules,
            )
        elif binding["_readonly_role"] == "receipt_writer":
            stage = "receipt_writer"
            result = _readonly_bootstrap_run_receipt_writer(
                binding,
                raw_binding=binding["_readonly_role_binding"],
                anchor_ns=anchor_ns,
                descriptor=descriptor,
                parent_facts=parent_facts,
                source_seal=source_seal,
                source_finder=source_finder,
                dependency_seal=dependency_seal,
                runtime_seal=runtime_seal,
                anchor_paths=anchor_paths,
                support_modules=support_modules,
            )
        elif binding["_readonly_role"] == "worker":
            output_channel_module = support_modules[
                "scripts/ctp_i13_i15_worker_output_channel.py"
            ]

            stage = "worker_source"
            worker_relative = "scripts/ctp_i13_i15_readonly_preflight_worker.py"
            worker_source = source_seal.source_lease.read_source(
                worker_relative, expected_sha256=binding["worker_sha256"]
            )
            worker_namespace = {
                "__name__": "_i13_fixed_readonly_preflight_worker",
                "__file__": ntpath.join(source_root, *worker_relative.split("/")),
            }
            exec(compile(worker_source, worker_namespace["__file__"], "exec", dont_inherit=True), worker_namespace)
            stage = "worker_run"
            class _BoundedWorkerOutput:
                __slots__ = ("_data",)

                def __init__(self):
                    self._data = bytearray()

                def write(self, text):
                    if type(text) is not str:
                        raise TypeError("worker_stdout_type")
                    encoded = text.encode("ascii", "strict")
                    if len(self._data) + len(encoded) > _READONLY_BOOTSTRAP_MAX_WORKER_OUTPUT_BYTES:
                        raise ValueError("worker_stdout_limit")
                    self._data.extend(encoded)
                    return len(text)

                def flush(self):
                    return None

                @property
                def encoding(self):
                    return "ascii"

                @property
                def errors(self):
                    return "strict"

                def isatty(self):
                    return False

                def writable(self):
                    return True

                def getvalue(self):
                    return bytes(self._data)

            worker_output_buffer = _BoundedWorkerOutput()
            original_stdout = sys.stdout
            sys.stdout = worker_output_buffer
            try:
                worker_result = worker_namespace["main"]()
                if sys.stdout is not worker_output_buffer:
                    raise ValueError("worker_stdout_replaced")
                worker_output_raw = worker_output_buffer.getvalue()
            finally:
                sys.stdout = original_stdout
            if type(worker_result) is not int or worker_result != 0:
                raise ValueError("worker_result")
            stage = "worker_output_channel"
            output_channel_module.write_worker_output_frame(
                worker_output_raw,
                request_id=binding["request_id"],
                nonce=binding["worker_output"]["nonce"],
                expected_server_pid=binding["worker_output"]["server_pid"],
                deadline_monotonic_ns=binding["deadline_monotonic_ns"],
            )
            result = worker_result
        else:
            raise ValueError("readonly_role_runtime_unavailable")
    except BaseException:
        result = _readonly_bootstrap_fail(stage)
    finally:
        cleanup_failed = False
        if runtime_seal is not None and source_finder is not None:
            try:
                _readonly_bootstrap_detach_runtime_closure(source_finder, runtime_seal)
            except BaseException:
                cleanup_failed = True
        if runtime_seal is not None:
            try:
                runtime_seal.close()
            except BaseException:
                cleanup_failed = True
        if dependency_finder is not None and source_finder is not None:
            try:
                _readonly_bootstrap_detach_dependency_finder(
                    source_finder, dependency_finder
                )
            except BaseException:
                cleanup_failed = True
        if dependency_seal is not None:
            try:
                dependency_seal.close()
            except BaseException:
                cleanup_failed = True
        if source_seal is not None:
            try:
                source_seal.close()
            except BaseException:
                cleanup_failed = True
        if anchor_paths is not None:
            try:
                anchor_paths.close()
            except BaseException:
                cleanup_failed = True
        if cleanup_failed:
            result = _readonly_bootstrap_fail("lease_cleanup")
    return result


raise SystemExit(_readonly_bootstrap_run())
