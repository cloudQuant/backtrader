import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
payload = [
    "g1_win_lazy_probe.cpp",
    "g1_win_lazy_probe.exe",
    "g1_win_lazy_probe.obj",
    "build_r7t.bat",
    "build_r7t.errorlevel",
    "build_r7t.log",
    "run_r7_scenarios.py",
    "r7_scenarios.json",
    "r7t_scenario_runner.stdout.log",
    "r7_receipt.json",
    "R7T_FINDINGS.md",
    "r7t_environment.txt",
    "make_r7t_manifest.py",
]

def describe(name):
    data = (root / name).read_bytes()
    return {"sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}

files = {name: describe(name) for name in payload}
hash_list = {
    "candidate": "R7 teardown-r2 Windows inert lazy-custodian evidence",
    "hash_algorithm": "SHA-256",
    "payloads": files,
}
hash_list_path = root / "r7_payload_hashes.json"
hash_list_path.write_text(json.dumps(hash_list, indent=2, sort_keys=True) + "\n", encoding="utf-8")
files["r7_payload_hashes.json"] = describe("r7_payload_hashes.json")

manifest = {
    "manifest_version": 1,
    "candidate": "R7 teardown-r2 Windows inert lazy-custodian evidence",
    "disposition": "REJECTED / G1 CLOSED",
    "scope": "fresh D:\\temp directory; no source-repository changes, CTP/provider/credentials/private config/SCM service/default route",
    "files": files,
}
manifest_path = root / "r7t_manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
manifest_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
(root / "r7t_manifest.sha256").write_text(manifest_hash + "  r7t_manifest.json\n", encoding="ascii")

scenarios = json.loads((root / "r7_scenarios.json").read_text(encoding="utf-8"))
by_mode = {item["mode"]: item for item in scenarios}
sync = by_mode["admission-sync"]
overlapped = by_mode["admission-overlapped"]
descendant = by_mode["descendant_join"]
normal = by_mode["normal"]
receipt = json.loads((root / "r7_receipt.json").read_text(encoding="utf-8"))
checks = []
for name, metadata in files.items():
    checks.append({"file": name, "ok": describe(name) == metadata})
checks.extend(
    [
        {"check": "nine scenarios", "ok": len(scenarios) == 9},
        {"check": "all outer runner processes completed", "ok": all(not row["outer_timeout"] and row["process_exit"] == 0 for row in scenarios)},
        {"check": "baseline exact exit+empty+release", "ok": normal["result"]["exact_exit_and_job_empty"] and normal["cleanup"]["exact_exit_and_job_empty_after_cleanup"] and normal["cleanup"]["controls_released_after_exact_cleanup"]},
        {"check": "descendant Job count 3 to empty", "ok": descendant["result"]["active_before_terminate"] == 3 and descendant["result"]["active_after_terminate"] == 0 and descendant["cleanup"]["job_active_after_cleanup"] == 0},
        {"check": "sync admission blocked and exceeded request budget", "ok": sync["result"]["caller_blocked_at_deadline"] and sync["result"]["elapsed_ms"] > 1800 and sync["result"]["caller_watchdog_terminated_caller"]},
        {"check": "sync UNKNOWN controls retained then cleanup exact", "ok": sync["result"]["controls_retained_at_unknown"] and sync["cleanup"]["exact_exit_and_job_empty_after_cleanup"] and sync["cleanup"]["controls_released_after_exact_cleanup"]},
        {"check": "overlapped pending I/O explicitly unknown", "ok": "cancel_completed=0" in overlapped["result"]["caller_output"] and overlapped["result"]["status"] == "UNKNOWN"},
        {"check": "overlapped UNKNOWN worker controls retained then cleanup exact", "ok": overlapped["result"]["controls_retained_at_unknown"] and overlapped["cleanup"]["exact_exit_and_job_empty_after_cleanup"] and overlapped["cleanup"]["controls_released_after_exact_cleanup"]},
        {"check": "receipt remains rejected", "ok": receipt["disposition"].startswith("REJECTED / G1 CLOSED")},
    ]
)
print(json.dumps({"manifest_sha256": manifest_hash, "payload_count": len(files), "checks": checks, "all_ok": all(c["ok"] for c in checks)}, sort_keys=True))
if not all(c["ok"] for c in checks):
    raise SystemExit(1)
