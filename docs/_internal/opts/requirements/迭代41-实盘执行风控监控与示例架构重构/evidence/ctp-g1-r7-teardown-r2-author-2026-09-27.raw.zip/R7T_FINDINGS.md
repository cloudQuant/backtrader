# R7 teardown-r2 Windows inert lazy-custodian evidence

**Disposition: REJECTED; G1 remains closed.** This is a separate temp-only continuation that preserves the original R7 archive. It changes no repository files and uses no CTP, provider, credentials, private configuration, SCM service, or default route.

## What the native experiment observed

- The actual Windows worker process was created suspended with `PROC_THREAD_ATTRIBUTE_JOB_LIST`. Before resume, the custodian observed one active process in its Job. It then verified exact `IsProcessInJob` membership, worker READY, connected named-pipe IPC, and pre-owned process/thread/Job handles before admitting the test request.
- Normal execution completed with worker exit code 0, Job count 0, and release after proof. Request-stage tests performed inert successful `CreateProcessW`, `CreatePipe`, `OpenProcessToken(TOKEN_QUERY)` on the worker's own token, event receipt creation, and a real infinite join wait before inducing an in-Job stall. The descendant case observed three Job processes and reached ActiveProcesses 0 after termination. The stalled workers exited `0xE1000001`; controls were released after exact exit and empty proof.
- At the UNKNOWN decision in synchronous admission, the separate caller process was still blocked at the 1800ms deadline. The harness killed its caller Job and retained the worker Job/process/thread handles. Internal end-to-end elapsed was 1828ms; the caller did not return normally. After recording that decision, teardown sent the worker a synchronous shutdown, observed exit code 0 and Job ActiveProcesses 0, then released its controls. Cleanup after the decision does not repair the missed request deadline.
- Overlapped admission emitted UNKNOWN with `cancel_completed=0` and caller exit code 54. At that decision the worker Job/process/thread controls were retained. The later cleanup line confirms worker exit 0, Job ActiveProcesses 0, and release after proof. The caller-side pending I/O still had no retained reaper/context; this is not safe-return evidence for a persistent request handler.

## Deadline boundary ledger and limits

- Pre-request warmup includes Job creation/configuration, pipe creation/connection, `CreateProcessW`, Job query/membership checks, resume, and waiting for READY. These setup calls were outside the request budget. There is no request-during-not-ready test.
- The request boundary's real synchronous admission operation (`WriteFile` to a full/no-reader connected named pipe) was deliberately blocked and missed its deadline. Overlapped admission did not complete cancellation by the recorded timeout.
- Worker command delivery is synchronous `WriteExactSync` over its pre-created anonymous pipe. Worker stage output uses synchronous `WriteExactSync`; response framing uses overlapped I/O. Custodian cleanup uses synchronous `TerminateJobObject`, bounded `WaitForSingleObject`, `QueryInformationJobObject` polling, and post-proof `CloseHandle`. After the UNKNOWN decision, teardown uses synchronous shutdown `WriteFile`, bounded wait, optional Job termination, Job query, then release. These calls returned in this run but were not individually fault-injected to hang.
- The custodian and its caller-deadline observer are the same native harness process. The outer Python process watchdog has no duplicated Job handle; it is not an independent OS custodian. Any assertion of hard bounded return across synchronous Win32 calls remains unsupported.

## Reproduction

From this directory, run `build_r7t.bat` in the available Visual Studio x64 environment, then run `python run_r7_scenarios.py`. The frozen scenario set has nine runs and records both the caller-facing decision and the subsequent cleanup result.
