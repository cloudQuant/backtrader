from __future__ import annotations
import ast, csv, hashlib, json, re, shutil, sqlite3, zipfile
from pathlib import Path

qa=Path(r'D:\temp\iteration41-bm58-independent-qa-20260927')
repo=Path(r'D:\source_code\backtrader')
evidence=repo/'docs'/'_internal'/'opts'/'requirements'/'迭代41-实盘执行风控监控与示例架构重构'/'evidence'
author_packet=evidence/'bm58-two-client-capacity-2026-09-27'
author_zip=evidence/'bm58-two-client-capacity-2026-09-27.raw.zip'
author_report=evidence/'bm58-two-client-capacity-2026-09-27.md'
canonical=evidence/'bm58-two-client-capacity-independent-qa-2026-09-27'

EXPECTED={
 'author_zip':'9363d92ecdda7527a12feb5e7357793458047067f137f336a795c3859a948272',
 'author_manifest':'9426567739623296a95b78cd7c288a38f96764d0c7f38e4e1a45d26e88ac5adb',
 'source':'b1f02883d706c6d5449c5483a9a67fc32dae99f903c16fd2738e5e1b278759b1',
 'test':'20db109b2525bf507d20277c8674f6459b64a1a4da9f3c5383a858ffc8b2fabb',
}
def digest_bytes(data:bytes)->str: return hashlib.sha256(data).hexdigest()
def digest(path:Path)->str: return digest_bytes(path.read_bytes())
def run_result(name:str)->dict:
    return json.loads((qa/name/'result.json').read_text(encoding='utf-8'))
def db_counts(name:str)->dict:
    db=qa/name/'authority.sqlite3'
    con=sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True)
    try:
        counts={t:int(con.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]) for t in ('clients','intents','request_attempts','backpressure_samples')}
        counts['complete']=int(con.execute("SELECT COUNT(*) FROM intents WHERE state='COMPLETE'").fetchone()[0])
        counts['incomplete']=int(con.execute("SELECT COUNT(*) FROM intents WHERE state!='COMPLETE'").fetchone()[0])
        counts['duplicates']=int(con.execute("SELECT COUNT(*) FROM request_attempts WHERE kind='DUPLICATE'").fetchone()[0])
        counts['accepted_attempts']=int(con.execute("SELECT COUNT(*) FROM request_attempts WHERE kind='ACCEPTED'").fetchone()[0])
        counts['outstanding']=int(con.execute("SELECT COUNT(*) FROM intents WHERE state IN ('PENDING','CLAIMED')").fetchone()[0])
        counts['max_backlog']=int(con.execute('SELECT peak_backlog FROM run_state WHERE singleton=1').fetchone()[0])
        counts['pressure_wait_ns']=int(con.execute('SELECT COALESCE(SUM(wait_ns),0) FROM backpressure_samples').fetchone()[0])
        counts['pressure_polls']=int(con.execute('SELECT COALESCE(SUM(polls),0) FROM backpressure_samples').fetchone()[0])
        counts['journal_mode']=str(con.execute('PRAGMA journal_mode').fetchone()[0])
        return counts
    finally: con.close()

# Recheck author evidence manifest and every ZIP member declared in it.
raw=zipfile.ZipFile(author_zip,'r')
if raw.testzip() is not None: raise SystemExit('author raw ZIP CRC failure')
manifest=json.loads(raw.read('evidence-manifest.json'))
manifest_hash=digest(author_packet/'evidence-manifest.json')
if manifest_hash!=EXPECTED['author_manifest']: raise SystemExit('author manifest SHA mismatch')
zip_members=set(raw.namelist())
verified=[]
for item in manifest['files']:
    member=item['path'].replace('\\','/')
    if member not in zip_members: raise SystemExit('manifest member missing '+member)
    payload=raw.read(member)
    if len(payload)!=item['size_bytes'] or digest_bytes(payload)!=item['sha256']:
        raise SystemExit('manifest payload hash/size mismatch '+member)
    verified.append({'path':member,'size_bytes':len(payload),'sha256':digest_bytes(payload)})
if len(verified)!=16: raise SystemExit(f'expected 16 author payloads, got {len(verified)}')

source_rel='source/run_iteration41_actor_capacity_benchmark.py'
test_rel='source/test_run_iteration41_actor_capacity_benchmark.py'
source_sha=digest_bytes(raw.read(source_rel)); test_sha=digest_bytes(raw.read(test_rel))
source_main=repo/'scripts'/'run_iteration41_actor_capacity_benchmark.py'
test_main=repo/'tests'/'unit'/'scripts'/'test_run_iteration41_actor_capacity_benchmark.py'
source_copy=qa/'scripts'/'run_iteration41_actor_capacity_benchmark.py'
test_copy=qa/'tests'/'unit'/'scripts'/'test_run_iteration41_actor_capacity_benchmark.py'
if digest(source_main)!=EXPECTED['source'] or digest(source_copy)!=EXPECTED['source'] or source_sha!=EXPECTED['source']:
    raise SystemExit('harness source hash mismatch across main/copy/ZIP')
if digest(test_main)!=EXPECTED['test'] or digest(test_copy)!=EXPECTED['test'] or test_sha!=EXPECTED['test']:
    raise SystemExit('focused test hash mismatch across main/copy/ZIP')

# Static import surface check: diagnostic is stdlib-only and does not import SDK/native/network modules.
module=ast.parse(source_copy.read_text(encoding='utf-8'))
imports=[]
for node in ast.walk(module):
    if isinstance(node,ast.Import): imports.extend(alias.name for alias in node.names)
    elif isinstance(node,ast.ImportFrom): imports.append(node.module or '')
forbidden=('socket','requests','urllib','http','ctypes','bt_api_py','bt_api_ctp','backtrader','backtrader_runtime')
for name in imports:
    if any(name==item or name.startswith(item+'.') for item in forbidden):
        raise SystemExit('forbidden import '+name)

runs={}
for name,expected_planned,expected_duplicates,expect_pressure in (
 ('smoke-default-final',20,2,False),('pressure-40x1-actual',40,0,True),('pressure-40x1-final',40,0,True)):
    result=run_result(name); metrics=result['metrics']; counts=db_counts(name)
    if result['status']!='FAKE_LOCAL_DIAGNOSTIC' or result['acceptance_status']!='NOT_ACCEPTED' or result['run_status']!='PASS': raise SystemExit(name+': disposition mismatch')
    if len(result['clients'])!=2 or sorted(row['client_id'] for row in result['clients'])!=[0,1]: raise SystemExit(name+': two-client identity mismatch')
    planned=metrics['input_intents_planned']
    if planned!=expected_planned or metrics['accepted_unique_intents']!=planned or metrics['completed_intents']!=planned: raise SystemExit(name+': intent conservation failed')
    if metrics['duplicate_attempts']!=expected_duplicates or metrics['expected_duplicate_attempts']!=expected_duplicates: raise SystemExit(name+': duplicate count mismatch')
    if metrics['input_attempts_recorded']!=planned+expected_duplicates: raise SystemExit(name+': request-attempt conservation mismatch')
    if metrics['lost_intents']!=0 or metrics['accepted_but_incomplete_intents']!=0 or metrics['outstanding_at_end']!=0: raise SystemExit(name+': loss/drain invariant failed')
    if metrics['fake_provider_calls']!=planned: raise SystemExit(name+': fake completion count mismatch')
    if (metrics['provider_dispatches'],metrics['native_api_calls'],metrics['network_calls'])!=(0,0,0): raise SystemExit(name+': fake-only counters mismatch')
    if counts['clients']!=2 or counts['intents']!=planned or counts['complete']!=planned or counts['incomplete']!=0 or counts['outstanding']!=0 or counts['duplicates']!=expected_duplicates or counts['accepted_attempts']!=planned or counts['journal_mode'].lower()!='wal': raise SystemExit(name+': SQLite state mismatch')
    if metrics['peak_backlog']!=counts['max_backlog'] or counts['max_backlog']>result['profile']['max_outstanding']: raise SystemExit(name+': backlog bound mismatch')
    if expect_pressure:
        if metrics['backpressure_events']<=0 or metrics['backpressure_wait_ns']<=0 or counts['pressure_wait_ns']!=metrics['backpressure_wait_ns'] or counts['pressure_polls']!=metrics['backpressure_polls'] or counts['backpressure_samples']!=metrics['backpressure_events']: raise SystemExit(name+': pressure accounting mismatch')
    elif metrics['backpressure_events']!=0 or counts['backpressure_samples']!=0:
        raise SystemExit(name+': unexpected pressure in ordinary smoke')
    runs[name]={'status':result['run_status'],'profile':result['profile'],'metrics':metrics,'sqlite_counts':counts}
raw.close()

report_text=author_report.read_text(encoding='utf-8')
report_test_hash=re.search(r'focused test SHA-256 is `([0-9a-f]+)`',report_text).group(1)
if report_test_hash==EXPECTED['test']: raise SystemExit('expected documented author-report SHA typo was not reproduced')
report_path_sha=digest(author_report)

static_summary={
 'source_imports':imports,
 'forbidden_import_prefixes_checked':list(forbidden),
 'result_counter_note':'provider_dispatches/native_api_calls/network_calls are emitted as literal zero fields; no instrumentation of OS-level sockets/provider APIs. The source import/static surface is inert, but output zeros alone are not an external side-effect monitor.',
 'no_sdk_native_or_runtime_imports':True,
}
audit={
 'schema':'iteration41.bm58_independent_qa_output_audit.v1',
 'status':'FAKE_LOCAL_DIAGNOSTIC','acceptance_status':'NOT_ACCEPTED',
 'author_artifact':{
  'raw_zip_sha256':digest(author_zip),'expected_raw_zip_sha256':EXPECTED['author_zip'],'zip_testzip':None,
  'manifest_sha256':manifest_hash,'expected_manifest_sha256':EXPECTED['author_manifest'],'manifest_payloads_verified':len(verified),'payloads':verified,
  'harness_sha256_main_copy_zip':source_sha,'focused_test_sha256_main_copy_zip':test_sha,
  'author_report_path':str(author_report),'author_report_sha256':report_path_sha,
  'author_report_test_hash_as_written':report_test_hash,
  'author_report_test_hash_erratum':{'written':report_test_hash,'verified':EXPECTED['test'],'finding':'The report has a test-file SHA typo; main file, manifest, and raw ZIP agree on the verified value. Author evidence was left unchanged.'},
 },
 'independent_pytest':'4 passed in 11.41s (CPython 3.11.5, plugin autoload disabled)',
 'static_surface':static_summary,
 'runs':runs,
 'limitations':['Only a benchmark-owned local SQLite WAL table and two spawned local clients.','Fake provider is local sleep plus deterministic digest; it is not actor-server, Store, provider, SDK, native, account, credentials, or network evidence.','The 30-minute capacity profile was not run.','Zero external-call counters are emitted constants and are not OS-level call tracing.','The two repeated 40/s pressure runs have scheduling-dependent timings; both completed all 40 planned intents with 39 pressure events and zero outstanding. Run-specific timing values are preserved separately.'],
}
(qa/'output-audit.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

report='''# BM58 two-client harness — independent QA (2026-09-27, r2)

## Disposition

**FAKE_LOCAL_DIAGNOSTIC / NOT_ACCEPTED.** This verifies a small local SQLite/WAL benchmark harness only. It is not actor-server, Store, runtime, CTP, provider, SDK, native API, account, credential, network, deployment, or production-capacity acceptance. The explicit 30-minute profile was not run.

## Frozen source and author packet

The author raw ZIP is SHA-256 `9363d92ecdda7527a12feb5e7357793458047067f137f336a795c3859a948272` (`testzip=None`). I independently checked the author evidence manifest SHA `9426567739623296a95b78cd7c288a38f96764d0c7f38e4e1a45d26e88ac5adb` and all 16 declared payloads. The main-tree harness, QA copy, and ZIP member have the same SHA `b1f02883d706c6d5449c5483a9a67fc32dae99f903c16fd2738e5e1b278759b1`. The main-tree focused test, QA copy, and ZIP member agree at `20db109b2525bf507d20277c8674f6459b64a1a4da9f3c5383a858ffc8b2fabb`.

**Erratum retained, author evidence unmodified:** the author summary `.md` records test hash `20db109b2525bf507d20277c8674f6459b64a1a4da9f3c5383a858ffcb8f2fabb`; the correct hash is `...ffc8b2fabb`. The frozen main test file, machine evidence manifest, and ZIP payload all agree on the correct value.

The independent focused suite passed **4/4** on CPython 3.11.5 (plugin autoload disabled). Static AST review found only standard-library imports and no SDK, native, Backtrader runtime, socket, HTTP, or request client imports. The output fields `provider_dispatches`, `native_api_calls`, and `network_calls` are constants in the harness; they are not OS-level instrumentation. No provider or network attempt is made by the reviewed source.

## Independent runs and conservation

| Run | Planned / accepted / completed | Attempts / duplicates | Lost / incomplete / outstanding | Peak / configured bound | Backpressure | Elapsed / extension | Result |
|---|---:|---:|---:|---:|---:|---:|---|
| Default smoke, 10/s × 2 s | 20 / 20 / 20 | 22 / 2 (expected 2) | 0 / 0 / 0 | 1 / 256 | 0 events | 1.925 s / 0 s | PASS |
| Pressure run A, 40/s × 1 s, fake latency 100 ms, bound 1 | 40 / 40 / 40 | 40 / 0 | 0 / 0 / 0 | 1 / 1 | 39 events, 8.375 s wait, 3,158 polls | 4.956 s / 3.831 s | PASS |
| Pressure run B, same settings | 40 / 40 / 40 | 40 / 0 | 0 / 0 / 0 | 1 / 1 | 39 events, 7.218 s wait, 3,104 polls | 4.675 s / 3.550 s | PASS |

For each run, raw SQLite state independently matches JSON: two client rows, all planned unique intents completed exactly once, `request_attempts = planned + duplicate attempts`, WAL mode, and zero outstanding. Fake completion calls equal completed intents. The pressure samples reconcile row-for-row and sum to each run's reported wait/poll counts. Run A and B are separate executions; their wait and elapsed totals vary with local process scheduling. Both show that the configured one-second input was accepted/completed over multiple seconds, so neither establishes 40/s sustained throughput. Both result files retain `FAKE_LOCAL_DIAGNOSTIC / NOT_ACCEPTED`.

**Timing reconciliation:** the earlier progress message's 8.375 s is pressure run A (`pressure-40x1-actual`); the first archive/report's 7.218 s is pressure run B (`pressure-40x1-final`). They are not contradictory measurements of one run. Revision r2 retains both raw run directories and the previous r1 packet/report/receipt; the author evidence was not changed. The initial run's result JSON, SQLite, and CSV are preserved; the compact console summary is derived from that result because the first invocation was not redirected to a separate shell log.

## Archive

The r2 independent raw ZIP includes the complete author raw packet, exact source/test copy, verification and audit scripts, full focused pytest output, raw SQLite/CSV/JSON and command/log records for both pressure runs and the default smoke, plus the prior r1 packet and r1 report/receipt/index. `archive-verification.json` records archive SHA, each member size/hash, and `testzip=None`.
'''
(qa/'independent-qa-report.md').write_text(report,encoding='utf-8',newline='\n')

# Build the independent raw archive with author and QA raw evidence.
payloads=[]
def add(label,path):
    if not path.is_file(): raise SystemExit('missing archive payload '+str(path))
    payloads.append((label,path))
add('audit_independent_outputs.py',qa/'audit_independent_outputs.py')
add('input-verification.json',qa/'input-verification.json')
add('independent-pytest.log',qa/'independent-pytest.log')
add('source/run_iteration41_actor_capacity_benchmark.py',source_copy)
add('source/test_run_iteration41_actor_capacity_benchmark.py',test_copy)
add('independent/independent-qa-report.md',qa/'independent-qa-report.md')
add('independent/output-audit.json',qa/'output-audit.json')
for name,run_name in [('smoke-default-final','smoke-default-final'),('pressure-40x1-actual','pressure-40x1-actual'),('pressure-40x1-final','pressure-40x1-final')]:
    add(f'independent/{name}.command.txt',qa/f'{name}.command.txt')
    add(f'independent/{name}.log',qa/f'{name}.log')
    for file in sorted((qa/run_name).iterdir()):
        if file.is_file(): add(f'independent/{name}/{file.name}',file)
for file in sorted(author_packet.iterdir()):
    if file.is_file(): add('author-packet/'+file.name,file)
add('author-packet.raw.zip',author_zip)
add('author-summary.md',author_report)
add('prior-r1/bm58-independent-qa.raw.zip',qa/'bm58-independent-qa-r1.raw.zip')
for name in ('independent-qa-report-r1.md','independent-qa-receipt-r1.json','output-audit-r1.json','archive-verification-r1.json'):
    add('prior-r1/'+name,qa/name)
add('independent/pressure-run-timing-reconciliation.md',qa/'pressure-run-timing-reconciliation.md')

archive=qa/'bm58-independent-qa-r2.raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for member,path in payloads: z.write(path,member)
with zipfile.ZipFile(archive,'r') as z:
    bad=z.testzip()
    if bad is not None: raise SystemExit('independent ZIP CRC failure '+str(bad))
    members={i.filename:{'size_bytes':i.file_size,'sha256':digest_bytes(z.read(i.filename))} for i in z.infolist()}
archive_verification={'archive':archive.name,'archive_sha256':digest(archive),'archive_bytes':archive.stat().st_size,'zip_testzip':None,'member_count':len(members),'members':members}
(qa/'archive-verification.json').write_text(json.dumps(archive_verification,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt={
 'schema':'iteration41.bm58_independent_qa_receipt.v2',
 'date':'2026-09-27','classification':'FAKE_LOCAL_DIAGNOSTIC','acceptance_status':'NOT_ACCEPTED',
 'archive_sha256':archive_verification['archive_sha256'],'archive_bytes':archive_verification['archive_bytes'],'archive_member_count':archive_verification['member_count'],'zip_testzip':None,
 'report_sha256':digest(qa/'independent-qa-report.md'),'output_audit_sha256':digest(qa/'output-audit.json'),
 'author_raw_zip_sha256':digest(author_zip),'author_manifest_sha256':manifest_hash,
 'source_sha256':source_sha,'test_sha256':test_sha,
 'independent_pytest':'4 passed in 11.41s; CPython 3.11.5; plugin autoload disabled',
 'run_summaries':{name:{'planned':v['metrics']['input_intents_planned'],'accepted':v['metrics']['accepted_unique_intents'],'completed':v['metrics']['completed_intents'],'duplicates':v['metrics']['duplicate_attempts'],'lost':v['metrics']['lost_intents'],'outstanding':v['metrics']['outstanding_at_end'],'backpressure_events':v['metrics']['backpressure_events'],'run_status':v['status']} for name,v in runs.items()},
 'author_report_test_sha_erratum':{'written':report_test_hash,'verified':EXPECTED['test'],'author_file_modified':False},
 'pressure_timing_reconciliation':{'run_A':'pressure-40x1-actual; wait_ns=8375000000; polls=3158; elapsed=4.956; extension=3.831','run_B':'pressure-40x1-final; wait_ns=7218000000; polls=3104; elapsed=4.675; extension=3.55','interpretation':'separate executions, scheduling-dependent timings; both 40/40 complete and 39 backpressure events'},
 'limits':audit['limitations'],
}
(qa/'independent-qa-receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
# Receipt/report/audit are also represented as separate canonical artifacts.
canonical.mkdir(parents=True,exist_ok=True)
for name in ('independent-qa-report.md','independent-qa-receipt.json','output-audit.json','archive-verification.json','bm58-independent-qa-r2.raw.zip'):
    shutil.copy2(qa/name,canonical/name)
print(json.dumps({'canonical':str(canonical),'archive_sha256':archive_verification['archive_sha256'],'archive_bytes':archive_verification['archive_bytes'],'archive_members':len(members),'author_manifest_payloads_verified':len(verified),'report_sha256':receipt['report_sha256'],'receipt_sha256':digest(qa/'independent-qa-receipt.json')},indent=2))
