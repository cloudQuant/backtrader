# Cancellation-control r3 独立 QA 回执

日期：2026-09-27（Asia/Singapore）
结论：`LOCAL_FAKE_CONTRACT_CHECKS_PASS_WITH_POST_READBACK_TOCTOU / NOT_PRODUCTION_ACCEPTANCE`

## 冻结与副本完整性

- 冻结 payload：`D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927`
- `payload-manifest.json` SHA-256：`65af6f048a1148182b35a18b8998f738a306d83b5d33352bd469c809c3a8d28f`，与委托值一致；154/154 文件大小和 SHA-256 一致，未发现未列入 manifest 的 payload 文件。
- 证据目录：`D:\temp\iteration41-cancel-control-r3-evidence-20260927`
- `evidence-manifest.json` SHA-256：`210394a328c01695c8616189314715157ca5879a715881d378ee6c9ee07cb391`，与委托值一致；112/112 证据项大小和 SHA-256 一致。
- 独立 QA 副本：`D:\temp\iteration41-cancel-control-r3-independent-qa-20260927\payload-copy`；按 payload manifest 再验 154/154 一致。
- 冻结树、证据树和主仓均未编辑。测试运行、探针和全部生成的 SQLite 数据库都写在上述独立 QA 目录。

验证记录：`manifest-verification.json/.log`、`copy-verification.json`。

## 复跑范围和测试数

在独立副本中运行冻结树唯一测试模块：

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
python -B -m pytest --noconftest -p no:cacheprovider --basetemp=<QA-dir>\pytest-tmp tests/test_cancellation_dispatch_resolution_control.py -q
```

结果：**15 passed**（8.62s）。任务说明提到“原 23 项”，但此冻结 payload 仅列出一个 pytest 模块：12 个 test 函数加两个参数化展开共 15 项；随附作者 `focused-tests.log` 与 `focused-tests-r1.log` 也都记为 15 passed。这里没有 23 项可收集，因此本回执不声称复跑了 23 项；已复跑 manifest 中全部可用 pytest 项。

作者 `r3_four_negative_probe.py` 复制到 QA 目录、只改成指向独立副本和独立输出目录后复跑，五个记录场景都与作者结果一致。额外独立探针又覆盖了 readback 后 expiry、首次 RELEASED readback 后删除、RELEASED replay readback 后删除和另一个进程的 readback 后删除。

## 代码审查：过期边界、readback 与双锁

候选源码：`payload-copy\bt_api_py\runtime_plugins\cancellation_control.py`。

- `release_cancel_freeze()` 在 authorizer 返回后重新检查 expiry（`1241-1256`）；在 outbox readback 后、写 RELEASED 审计前检查（`1341-1369`）；在写 RELEASED 审计后、清最后锁前再检查（`1371-1409`）。过期时采用 fail-closed 路径：恢复 unknown 与 release-progress 两个 risk freeze，审计标记 expired，避免保留 `released_at`。
- 首次 release 先保留 release-progress 锁，再写 `cancellation_freeze_release_prepared`。`_verify_release_prepared_monitor_fact()` 对 `monitor.sqlite3` 使用 `mode=ro`，按 event id 读取并逐字段比较 fingerprint、scope、event type、data JSON 和 occurred_at（`1697-1759`）。append 后、readback 前删除事件会被拒绝；失败路径 `_reassert_after_failed_release()` 重新激活两锁（`2010-2032`）。
- RELEASED replay 在移除最后 release-progress 锁前也重新核对这个 monitor 事件（`_resume_released_command():1618-1695`）。缺失/损坏发生在 readback 之前会被拒绝。
- **边界：readback 是一次只读查询，不是之后流程的持久锁或跨库事务。** SQLite read connection 在查询结束后关闭。monitor outbox、control audit、risk latch、execution/fake journal 分属不同 SQLite 数据库；readback 后到最终 risk latch 操作之间没有对 monitor row 的 re-read、写保护租约或跨库原子提交。

## 负测结果与 TOCTOU 复现

1. **删除发生在 readback 前**：作者测试 `test_first_release_rejects_monitor_event_deleted_after_append`（`tests/...:623-664`）及作者 probe 均拒绝，错误 `CANCELLATION_CONTROL_MONITOR_OUTBOX_UNCONFIRMED`。命令审计保持 pending，`release_applied_at` 已记录，monitor event 缺失，unknown 与 release-progress 两锁都 active；控制端口关闭重开后两锁仍 active。
2. **删除发生在 readback 后、首次 RELEASED 清锁前**：独立探针在成功的精确 readback 后、调用最终 `risk_gate.resolve_freeze(progress_cause)` 前触发第二 SQLite writer 删除行。调用仍返回 `released=true`；control audit 为 `released` 且 `released_at` 非空；monitor event 已不存在；unknown 和 release-progress 两锁都 inactive。独立跨进程探针由 PID `42256` 的另一个本机 Python 进程打开独立 monitor SQLite DB、删除 1 行并退出 0，结果相同。它证明：**只要同进程代码或另一个有该 DB 文件写权限的进程能在此窗口写 monitor DB，就能让 audit 显示 RELEASED、monitor fact 消失且两锁清除。** 这不是远程利用证明；当前切片没有建立文件 ACL/进程隔离边界，任意进程执行权限、相同用户 DB 写权限仍是前置条件。
3. **RELEASED replay 的 readback 后删除**：先完成一次正常 release，再仅恢复 release-progress 锁模拟 audit 已提交、进程在最后清锁前中断；replay 的只读核对成功后删除 monitor row。replay 仍返回 `released=true, idempotent=true`，audit 保持 released、monitor event 缺失，release-progress 锁被清除。恢复分支有同一 read-then-clear 窗口。
4. **expiry 在 readback 后、写 RELEASED 前**：探针在 exact readback 成功后推进测试时钟。结果 `CANCELLATION_CONTROL_COMMAND_EXPIRED`；audit `expired`、`released_at=null`、prepared monitor event 保留；unknown 和 release-progress 两锁均 active。
5. **authorizer callback 返回时已过期**：作者场景与测试在 callback 返回后命中 `1245` 检查；审计 expired、无 release-applied timestamp、无 release event；unknown active，release-progress 尚未设置。
6. **expiry 在 RELEASED 审计已提交后、最终锁移除前**：作者场景命中 `1380` 检查；审计最终 expired、`released_at=null`，prepared monitor event 保留，两锁 active。
7. **CTP-labeled fake scope**：将执行 scope 的 `provider` 伪标为 `ctp`，在 authorizer 调用之前因 `CANCELLATION_DISPATCH_RESOLUTION_AUTHORITY_REQUIRED` 被拒；authorizer 调用数 0、release command audit 不存在、unknown active、release-progress inactive。
8. **wrong-account fake authority**：注册表不含该账号，构造 `ManagedFakeProviderJournalAuthority` 时抛 `FakeDispatchJournalError`；authority DB 未创建，unknown active、release-progress inactive。也检查了 provider/strategy 不匹配参数化用例。

追加 readback TOCTOU 的日志：`post_readback_toctou_probe.log`、`cross_process_toctou_probe.log`。所有 55 个独立 SQLite 数据库通过只读 `PRAGMA quick_check`；结果见 `sqlite-integrity.json/.log`。

## 来源与分类限制

pytest 断言包 origin：`bt_api_execution`、`bt_api_risk`、`bt_api_base`、`bt_api_monitor` 来自测试文件固定的其他本地 source roots；`bt_api_py` fake authority 来自本 QA 独立副本。作者 probe 输出了这些路径。测试仍是 `simulation/replay/offline` 的合成 execution/risk/monitor 和 fake provider journal；authorizer 是注入的本地回调，不是经过认证的真实操作员授权。

没有导入 CTP SDK/SWIG/native 模块，没有账号、凭据、网络、真实 provider 或默认 route；无外部订单/取消副作用。本回执只接受 local fake composition contract。它**不构成 G4、F14、原生 CTP、SimNow、production 或部署安全 PASS**。

### 关键来源行

- Expiry/首次 release 顺序：`cancellation_control.py:1241-1263, 1325-1409`
- replay readback 在最终清锁前：`cancellation_control.py:1618-1695`
- read-only exact event readback：`cancellation_control.py:1697-1759`
- 失败时两锁 reassert：`cancellation_control.py:2010-2032`
- exact offline fake allowlist 与构造前检查：`fake_dispatch_authority.py:25-78, 241-272`
- CTP label/账号负测：`test_cancellation_dispatch_resolution_control.py:669-748`
- append 后、readback 前删除与重开双锁检查：`test_cancellation_dispatch_resolution_control.py:623-664`

### 本地测试依赖 provenance

测试模块断言并加载以下本地 source roots（这些 roots 不属于 r3 payload manifest，故单独记录 origin）：

- execution `D:\temp\iteration41_v20_r3_cancel_terminal_candidate_20260927\src\bt_api_execution\__init__.py` SHA-256 `1b1c68ac33e3dbae4fc57bf5b3c3ba79fe226ad6e6a6aa21b968f6ebbc20e8fd`
- risk `D:\temp\iteration41_risk_cancel_resolution_20260927\src\bt_api_risk\__init__.py` SHA-256 `3914399361d5956171cbbd71f728b8d5eb64b7695342ee97d19185cd1e8e21d7`
- base source root `D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base`，Git HEAD `3de0fa4f6cfe8d1973e9f4b9b47b01254259524f`，工作树干净；module init SHA-256 `c0c14cfa1e39a79fef8126a85e82cd7b41d5662e683ff11932fcc58add8116b4`
- monitor source root `D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_monitor`，Git HEAD `8498ca7d4f551eff8e7c5ff7deffa418dee5752a`，工作树干净；module init SHA-256 `c493f444c1f57c0e6df71e6213425b3d84e0ad5fa989d6cdf087c533d9317454`
- fake authority comes from the independently verified payload copy; its SHA-256 is `ff31893935aed8ac7944c5f720eb46553298cf593553dbbe64ad74583b89dc06`.

Python runtime: 3.11.5. All source/support roots were only read; bytecode writing was disabled.
