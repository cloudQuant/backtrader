import json,re
from pathlib import Path
qa=Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927')
manifest=json.loads((qa/'manifest-verification.json').read_text(encoding='utf-8'))
copy=json.loads((qa/'copy-verification.json').read_text(encoding='utf-8'))
focused=(qa/'focused-tests-independent.log').read_text(encoding='utf-8',errors='replace')
neg=json.loads((qa/'negative-probe-independent.log').read_text(encoding='utf-8'))
toc=json.loads((qa/'post_readback_toctou_probe.log').read_text(encoding='utf-8'))
ext=json.loads((qa/'cross_process_toctou_probe.log').read_text(encoding='utf-8'))
db=json.loads((qa/'sqlite-integrity.json').read_text(encoding='utf-8'))
assert manifest['payload_verified']==154 and manifest['evidence_verified']==112
assert not manifest['payload_mismatches'] and not manifest['payload_unlisted_files'] and not manifest['evidence_mismatches']
assert copy['verified']==154 and not copy['errors'] and not copy['unlisted']
match=re.search(r'\b(\d+) passed\b',focused); assert match
pytest_count=int(match.group(1)); assert pytest_count==15
assert neg['append_commit_then_delete']['audit_status']=='pending' and neg['append_commit_then_delete']['unknown_freeze_active'] and neg['append_commit_then_delete']['release_progress_freeze_active']
assert neg['authorization_callback_expiry']['audit_status']=='expired' and neg['authorization_callback_expiry']['release_applied_at'] is None and neg['authorization_callback_expiry']['unknown_freeze_active']
assert neg['expiry_after_release_audit_commit']['audit_status']=='expired' and neg['expiry_after_release_audit_commit']['released_at'] is None and neg['expiry_after_release_audit_commit']['unknown_freeze_active'] and neg['expiry_after_release_audit_commit']['release_progress_freeze_active']
assert neg['ctp_labeled_execution_scope']['authorizer_calls']==0 and not neg['ctp_labeled_execution_scope']['control_audit_command_exists'] and neg['ctp_labeled_execution_scope']['unknown_freeze_active']
assert neg['wrong_account_scope']['rejection']=='FakeDispatchJournalError' and not neg['wrong_account_scope']['authority_database_created'] and neg['wrong_account_scope']['unknown_freeze_active']
first=toc['first_release_post_readback_delete']; replay=toc['released_replay_post_readback_delete']; pre=toc['expiry_after_readback_before_released']
assert first['returned_released'] and first['audit_status']=='released' and not first['monitor_event_present'] and not first['unknown_lock_active'] and not first['release_progress_lock_active']
assert replay['returned_released'] and replay['returned_idempotent'] and replay['audit_status']=='released' and not replay['monitor_event_present'] and not replay['release_progress_lock_active']
assert pre['error']=='CANCELLATION_CONTROL_COMMAND_EXPIRED' and pre['audit_status']=='expired' and pre['released_at'] is None and pre['monitor_event_present'] and pre['unknown_lock_active'] and pre['release_progress_lock_active']
assert ext['result_released'] and ext['audit_status']=='released' and ext['writer_returncode']==0 and not ext['event_present_after_return'] and not ext['unknown_lock_active'] and not ext['release_progress_lock_active']
assert ext['trace'][0]['event_present'] is True and ext['trace'][1]['row_before_delete'] is True and ext['trace'][1]['deleted_rows']==1 and ext['trace'][1]['row_after_delete'] is False
assert db['integrity_ok'] and db['database_count']==55
summary={
 'schema':'iteration41_cancel_control_r3_independent_qa_summary.v1',
 'payload_manifest_sha256':manifest['payload_manifest_sha256'],
 'evidence_manifest_sha256':manifest['evidence_manifest_sha256'],
 'payload_files_verified':manifest['payload_verified'],
 'evidence_items_verified':manifest['evidence_verified'],
 'independent_copy_payload_files_verified':copy['verified'],
 'frozen_pytest_cases_collected_and_passed':pytest_count,
 'requested_pytest_count':23,
 'requested_count_present_in_frozen_manifest':False,
 'author_negative_probe_scenarios_replayed':5,
 'post_readback_negative_probes':{
   'same_process_first_release':True,
   'released_replay':True,
   'separate_process_writer':True,
   'expiry_after_readback_before_released':True
 },
 'separate_process_writer_pid':ext['trace'][1]['writer_pid'],
 'monitor_event_deleted_after_exact_readback':True,
 'release_still_reported_released_after_post_readback_delete':True,
 'both_risk_locks_cleared_after_post_readback_delete':True,
 'sqlite_databases_quick_checked':db['database_count'],
 'sqlite_integrity_ok':db['integrity_ok'],
 'ctp_provider_or_network_calls':0,
 'real_ctp_imported':False,
 'g4_f14_production_acceptance':False,
 'receipt':'D:\\temp\\iteration41-cancel-control-r3-independent-qa-20260927\\independent-qa-receipt.md'
}
(qa/'independent-qa-summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,sort_keys=True,indent=2))
