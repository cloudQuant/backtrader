import json, sqlite3, sys, time
from pathlib import Path

database, event_id, gate_path, done_path = map(Path, sys.argv[1:5])
deadline = time.monotonic() + 10
while not gate_path.exists():
    if time.monotonic() >= deadline:
        raise SystemExit('gate_timeout')
    time.sleep(0.005)
with sqlite3.connect(database) as connection:
    before = connection.execute('SELECT event_type FROM monitor_outbox_events WHERE event_id = ?', (str(event_id),)).fetchone()
    cursor = connection.execute('DELETE FROM monitor_outbox_events WHERE event_id = ?', (str(event_id),))
    connection.commit()
    after = connection.execute('SELECT event_type FROM monitor_outbox_events WHERE event_id = ?', (str(event_id),)).fetchone()
done_path.write_text(json.dumps({'row_before_delete': before is not None, 'deleted_rows': cursor.rowcount, 'row_after_delete': after is not None}, sort_keys=True)+'\n', encoding='utf-8')
