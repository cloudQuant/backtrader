import hashlib, json, os, sys
from pathlib import Path

freeze=Path(r'D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927')
evidence=Path(r'D:\temp\iteration41-cancel-control-r3-evidence-20260927')
qa=Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927')
expected_payload='65af6f048a1148182b35a18b8998f738a306d83b5d33352bd469c809c3a8d28f'
expected_evidence='210394a328c01695c8616189314715157ca5879a715881d378ee6c9ee07cb391'

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()

def inside(path, root):
    try: path.resolve().relative_to(root.resolve()); return True
    except ValueError: return False

payload_path=freeze/'payload-manifest.json'
evidence_path=evidence/'evidence-manifest.json'
payload_raw=payload_path.read_bytes(); evidence_raw=evidence_path.read_bytes()
manifest_result={
 'payload_manifest_sha256':sha(payload_path),
 'payload_manifest_expected_sha256':expected_payload,
 'evidence_manifest_sha256':sha(evidence_path),
 'evidence_manifest_expected_sha256':expected_evidence,
 'payload_entries':0,'payload_verified':0,'payload_mismatches':[],
 'payload_unlisted_files':[],'evidence_entries':0,'evidence_verified':0,'evidence_mismatches':[],
}
if manifest_result['payload_manifest_sha256'] != expected_payload: raise SystemExit('payload manifest SHA mismatch')
if manifest_result['evidence_manifest_sha256'] != expected_evidence: raise SystemExit('evidence manifest SHA mismatch')
payload=json.loads(payload_raw)
manifest_result['payload_entries']=len(payload)
listed=set()
for item in payload:
    rel=Path(item['path'])
    target=freeze/rel
    if not inside(target,freeze):
        manifest_result['payload_mismatches'].append({'path':item['path'],'error':'path_escape'}); continue
    listed.add(os.path.normcase(os.path.normpath(item['path'])))
    if not target.is_file():
        manifest_result['payload_mismatches'].append({'path':item['path'],'error':'missing'}); continue
    actual_size=target.stat().st_size
    actual_sha=sha(target)
    if actual_size != item['size'] or actual_sha != item['sha256']:
        manifest_result['payload_mismatches'].append({'path':item['path'],'expected_size':item['size'],'actual_size':actual_size,'expected_sha256':item['sha256'],'actual_sha256':actual_sha})
    else: manifest_result['payload_verified'] += 1
actual_files=[p for p in freeze.rglob('*') if p.is_file() and p != payload_path]
for p in actual_files:
    rel=os.path.normcase(os.path.normpath(str(p.relative_to(freeze))))
    if rel not in listed: manifest_result['payload_unlisted_files'].append(str(p))

edoc=json.loads(evidence_raw)
manifest_result['evidence_entries']=len(edoc['entries'])
allowed_roots=[evidence,freeze,Path(r'D:\temp\iteration41_cancel_control_r2_audit_20260927')]
for item in edoc['entries']:
    target=Path(item['path'])
    if not any(inside(target,root) for root in allowed_roots):
        manifest_result['evidence_mismatches'].append({'path':item['path'],'error':'path_outside_review_roots'}); continue
    if not target.is_file():
        manifest_result['evidence_mismatches'].append({'path':item['path'],'error':'missing'}); continue
    actual_size=target.stat().st_size
    actual_sha=sha(target)
    if actual_size != item['bytes'] or actual_sha != item['sha256']:
        manifest_result['evidence_mismatches'].append({'path':item['path'],'expected_size':item['bytes'],'actual_size':actual_size,'expected_sha256':item['sha256'],'actual_sha256':actual_sha})
    else: manifest_result['evidence_verified'] += 1

out=qa/'manifest-verification.json'
out.write_text(json.dumps(manifest_result,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest_result,sort_keys=True,indent=2))
if manifest_result['payload_mismatches'] or manifest_result['payload_unlisted_files'] or manifest_result['evidence_mismatches']:
    raise SystemExit(1)
