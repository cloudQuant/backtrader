import json, sqlite3, sys
from pathlib import Path

qa = Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927')
snapshot = qa / 'payload-copy'
sys.path.insert(0, str(snapshot / 'tests'))
import test_cancellation_dispatch_resolution_control as t
from bt_api_py.runtime_plugins.catalog import RuntimePluginError


def event(path, event_id):
    with sqlite3.connect(path) as c:
        return c.execute('SELECT event_type, fingerprint, data_json FROM monitor_outbox_events WHERE event_id = ?', (event_id,)).fetchone()


def snapshot_state(f, event_id):
    audit = f.control.audit.get_command(f.command.command_id)
    active = f.active()
    return {
        'audit_status': None if audit is None else audit.status.value,
        'release_applied_at': None if audit is None else audit.release_applied_at,
        'released_at': None if audit is None else audit.released_at,
        'monitor_event_present': event(f.runtime.state_directory / 'monitor.sqlite3', event_id) is not None,
        'unknown_lock_active': f.unknown_cause in active,
        'release_progress_lock_active': f.progress_cause in active,
        'cancel_state': f.cancel_facade.get(f.cancel.cancel_id).state.value,
        'state_database_names': sorted(p.name for p in f.runtime.state_directory.glob('*.sqlite3')),
    }


def fresh(name):
    root = qa / 'post-readback-state' / name
    root.mkdir(parents=True)
    return root, t._Fixture(root)

results = {}

# First-release race: deletion is performed only in the call that removes the final latch,
# after the exact read-only monitor readback has already returned successfully.
root, f = fresh('first-release-delete-after-readback')
event_id = 'cancel-freeze-release:' + f.command.command_id
trace = []
original_verify = f.control._verify_release_prepared_monitor_fact
original_resolve = f.runtime.risk_gate.resolve_freeze

def verify_first(*args, **kwargs):
    result = original_verify(*args, **kwargs)
    trace.append({'step': 'exact_readback_returned', 'row_present': event(f.runtime.state_directory / 'monitor.sqlite3', event_id) is not None})
    return result

def delete_at_final_latch(scope, cause_id):
    if cause_id == f.progress_cause:
        before = event(f.runtime.state_directory / 'monitor.sqlite3', event_id)
        with sqlite3.connect(f.runtime.state_directory / 'monitor.sqlite3') as c:
            deleted = c.execute('DELETE FROM monitor_outbox_events WHERE event_id = ?', (event_id,)).rowcount
        trace.append({'step': 'delete_before_final_latch_clear', 'readback_previously_passed': bool(trace and trace[-1]['step'] == 'exact_readback_returned'), 'row_present_immediately_before_delete': before is not None, 'deleted_rows': deleted, 'row_present_after_delete': event(f.runtime.state_directory / 'monitor.sqlite3', event_id) is not None})
    return original_resolve(scope, cause_id)

f.control._verify_release_prepared_monitor_fact = verify_first
f.runtime.risk_gate.resolve_freeze = delete_at_final_latch
try:
    result = t._release(f)
    results['first_release_post_readback_delete'] = {
        'returned_released': result.released,
        'returned_idempotent': result.idempotent,
        'error': None,
        'trace': trace,
        **snapshot_state(f, event_id),
    }
except RuntimePluginError as e:
    results['first_release_post_readback_delete'] = {'error': e.code, 'trace': trace, **snapshot_state(f, event_id)}
finally:
    f.close()

# RELEASED replay cutpoint: restore only the in-progress latch to model a crash after the
# RELEASED audit commit but before the final latch removal. Delete only after replay readback.
root, f = fresh('released-replay-delete-after-readback')
event_id = 'cancel-freeze-release:' + f.command.command_id
first = t._release(f)
f.runtime.risk_gate.freeze(f.runtime.risk_scope, f.progress_cause, f.progress_cause)
trace = [{'step': 'replay_cutpoint', 'initial_release': first.released, 'progress_lock_reasserted': f.progress_cause in f.active()}]
original_verify = f.control._verify_release_prepared_monitor_fact

def verify_replay_then_delete(*args, **kwargs):
    result = original_verify(*args, **kwargs)
    before = event(f.runtime.state_directory / 'monitor.sqlite3', event_id)
    with sqlite3.connect(f.runtime.state_directory / 'monitor.sqlite3') as c:
        deleted = c.execute('DELETE FROM monitor_outbox_events WHERE event_id = ?', (event_id,)).rowcount
    trace.append({'step': 'replay_readback_then_delete', 'row_present_at_readback_return': before is not None, 'deleted_rows': deleted, 'row_present_after_delete': event(f.runtime.state_directory / 'monitor.sqlite3', event_id) is not None})
    return result

f.control._verify_release_prepared_monitor_fact = verify_replay_then_delete
try:
    replay = f.control.release_cancel_freeze(f.command)
    results['released_replay_post_readback_delete'] = {
        'returned_released': replay.released,
        'returned_idempotent': replay.idempotent,
        'error': None,
        'trace': trace,
        **snapshot_state(f, event_id),
    }
except RuntimePluginError as e:
    results['released_replay_post_readback_delete'] = {'error': e.code, 'trace': trace, **snapshot_state(f, event_id)}
finally:
    f.close()

# Expiry at the explicit pre-RELEASED fence, after append and successful readback.
root, f = fresh('expiry-after-readback-before-released')
event_id = 'cancel-freeze-release:' + f.command.command_id
trace = []
original_verify = f.control._verify_release_prepared_monitor_fact

def verify_then_expire(*args, **kwargs):
    result = original_verify(*args, **kwargs)
    trace.append({'step': 'exact_readback_returned', 'row_present': event(f.runtime.state_directory / 'monitor.sqlite3', event_id) is not None})
    f.now = f.command.expires_at + 0.01
    return result

f.control._verify_release_prepared_monitor_fact = verify_then_expire
try:
    t._release(f)
    results['expiry_after_readback_before_released'] = {'unexpected_success': True, 'trace': trace, **snapshot_state(f, event_id)}
except RuntimePluginError as e:
    results['expiry_after_readback_before_released'] = {'error': e.code, 'trace': trace, **snapshot_state(f, event_id)}
finally:
    f.close()

print(json.dumps(results, indent=2, sort_keys=True))
