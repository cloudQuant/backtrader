import json,sqlite3
from pathlib import Path
qa=Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927')
roots=[qa/'probe-output',qa/'post-readback-state',qa/'external-process-toctou-state']
rows=[]
for root in roots:
 for p in sorted(root.rglob('*.sqlite3')):
  uri=p.resolve().as_uri()+'?mode=ro'
  with sqlite3.connect(uri,uri=True,timeout=2) as c:
   result=c.execute('PRAGMA quick_check').fetchone()[0]
   tables=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
  rows.append({'path':str(p),'quick_check':result,'tables':tables})
summary={'database_count':len(rows),'integrity_ok':all(x['quick_check']=='ok' for x in rows),'databases':rows}
(qa/'sqlite-integrity.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'database_count':len(rows),'integrity_ok':summary['integrity_ok'],'bad':[x for x in rows if x['quick_check']!='ok']},sort_keys=True,indent=2))
if not summary['integrity_ok']: raise SystemExit(1)
