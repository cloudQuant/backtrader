from __future__ import annotations
import hashlib
import pathlib
import sys
import zipfile

qa = pathlib.Path(sys.argv[1])
out = pathlib.Path(sys.argv[2])
if out.exists():
    raise SystemExit(f'refusing to overwrite existing archive: {out}')
checksums: dict[str, str] = {}
for line in (qa / 'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
    digest, name = line.split('  ', 1)
    if not pathlib.Path(name).is_absolute():
        checksums[name.replace('\\', '/')] = digest.lower()
files = sorted(p for p in qa.iterdir() if p.is_file())
for dirname in ('post-readback-state', 'external-process-toctou-state'):
    files.extend(sorted(p for p in (qa / dirname).rglob('*') if p.is_file()))
expected = {p.relative_to(qa).as_posix() for p in files if p.name != 'SHA256SUMS.txt'}
if expected != set(checksums):
    raise SystemExit(f'checksum/file-set mismatch: missing={sorted(expected-set(checksums))}; extra={sorted(set(checksums)-expected)}')
with zipfile.ZipFile(out, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for p in files:
        zf.write(p, 'cancel-control-r3-independent-qa/' + p.relative_to(qa).as_posix())
with zipfile.ZipFile(out, 'r') as zf:
    bad_member = zf.testzip()
    if bad_member:
        raise SystemExit(f'zip CRC failure: {bad_member}')
    names = zf.namelist()
    member_hashes = 0
    for info in zf.infolist():
        rel = info.filename.split('/', 1)[1]
        if rel == 'SHA256SUMS.txt':
            continue
        actual = hashlib.sha256(zf.read(info.filename)).hexdigest()
        if actual != checksums.get(rel):
            raise SystemExit(f'member hash mismatch: {rel}: {actual}')
        member_hashes += 1
    print(f'zip_testzip=OK')
    print(f'members={len(names)} hashed_members={member_hashes}')
    print(f'bytes={out.stat().st_size}')
    print(f'sha256={hashlib.sha256(out.read_bytes()).hexdigest()}')
