import json, subprocess, sys
from pathlib import Path

qa=Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927')
snapshot=qa/'payload-copy'
sys.path.insert(0,str(snapshot/'tests'))
import test_cancellation_dispatch_resolution_control as t
from bt_api_py.runtime_plugins.catalog import RuntimePluginError

root=qa/'external-process-toctou-state'
root.mkdir(parents=True)
f=t._Fixture(root)
event_id='cancel-freeze-release:'+f.command.command_id
db=f.runtime.state_directory/'monitor.sqlite3'
gate=root/'external-writer-go'
done=root/'external-writer-result.json'
writer=qa/'monitor_outbox_external_writer.py'
child=subprocess.Popen([sys.executable,'-I','-S','-B',str(writer),str(db),event_id,str(gate),str(done)],cwd=str(qa),stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
trace=[]
verify=f.control._verify_release_prepared_monitor_fact
resolve=f.runtime.risk_gate.resolve_freeze

def verify_then_signal(*args,**kwargs):
    result=verify(*args,**kwargs)
    trace.append({'step':'readback_passed','event_present':t.sqlite3.connect(db).execute('SELECT 1 FROM monitor_outbox_events WHERE event_id = ?', (event_id,)).fetchone() is not None})
    return result

def signal_external_writer_before_final_latch(scope,cause):
    if cause==f.progress_cause:
        if not trace or not trace[-1]['step']=='readback_passed' or not trace[-1]['event_present']:
            raise RuntimeError('readback_not_observed_before_writer')
        gate.write_text('delete after readback',encoding='utf-8')
        rc=child.wait(timeout=5)
        if rc != 0 or not done.is_file():
            raise RuntimeError('external_writer_failed:'+str(child.stderr.read().decode(errors='replace')))
        writer_result=json.loads(done.read_text(encoding='utf-8'))
        trace.append({'step':'separate_process_deleted_after_readback_before_latch_clear','writer_pid':child.pid,**writer_result})
    return resolve(scope,cause)

f.control._verify_release_prepared_monitor_fact=verify_then_signal
f.runtime.risk_gate.resolve_freeze=signal_external_writer_before_final_latch
try:
    result=t._release(f)
    audit=f.control.audit.get_command(f.command.command_id)
    active=f.active()
    with t.sqlite3.connect(db) as c:
        event_present=c.execute('SELECT 1 FROM monitor_outbox_events WHERE event_id = ?', (event_id,)).fetchone() is not None
    output={
      'result_released':result.released,
      'audit_status':None if audit is None else audit.status.value,
      'released_at':None if audit is None else audit.released_at,
      'event_present_after_return':event_present,
      'unknown_lock_active':f.unknown_cause in active,
      'release_progress_lock_active':f.progress_cause in active,
      'trace':trace,
      'writer_returncode':child.returncode,
      'fake_only':True,
      'native_or_provider_calls':0
    }
    print(json.dumps(output,sort_keys=True,indent=2))
finally:
    if child.poll() is None:
        child.terminate()
        child.wait(timeout=5)
    f.close()
