import hashlib,json,os
from pathlib import Path
root=Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927\payload-copy')
entries=json.loads((root/'payload-manifest.json').read_text(encoding='utf-8'))
errors=[]
for e in entries:
 p=root/Path(e['path'])
 try: p.resolve().relative_to(root.resolve())
 except ValueError: errors.append((e['path'],'escape')); continue
 if not p.is_file(): errors.append((e['path'],'missing')); continue
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if p.stat().st_size != e['size'] or h != e['sha256']:
  errors.append((e['path'],'mismatch',p.stat().st_size,h,e['size'],e['sha256']))
listed={os.path.normcase(os.path.normpath(e['path'])) for e in entries}
actual=[p for p in root.rglob('*') if p.is_file() and p.name!='payload-manifest.json']
unlisted=[str(p.relative_to(root)) for p in actual if os.path.normcase(os.path.normpath(str(p.relative_to(root)))) not in listed]
result={'entries':len(entries),'verified':len(entries)-len(errors),'errors':errors,'unlisted':unlisted}
Path(r'D:\temp\iteration41-cancel-control-r3-independent-qa-20260927\copy-verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,sort_keys=True,indent=2))
if errors or unlisted: raise SystemExit(1)
