from __future__ import annotations
import base64,csv,hashlib,importlib,importlib.metadata,importlib.util,io,json,os,sys,zipfile
from pathlib import Path
from urllib.parse import urlparse
VEN=Path(r"D:\q\unified-v20r2-consumer-20260927").resolve()
SITE=(VEN/"Lib"/"site-packages").resolve()
WHEELHOUSE=Path(r"D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse")
EXPLICIT={
 "bt_api_ctp":Path(r"D:\q\lazy-ctp-build-e\wheelhouse-e\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl"),
 "bt_api_py":Path(r"D:\q\pwa\bt_api_py-0.15.5-py3-none-any.whl"),
 "bt_api_execution":Path(r"D:\q\unified-v20r2-wheelhouse-20260927\bt_api_execution-0.2.0-py3-none-any.whl"),
 "bt_api_base":Path(r"D:\temp\iteration41-capability-artifacts-20260926\wheels\base-a\bt_api_base-0.15.4-py3-none-any.whl"),
 "bt_api_risk":Path(r"D:\temp\iteration41-capability-risk-version-fix-20260926\wheels\risk-a\bt_api_risk-0.1.0-py3-none-any.whl"),
 "bt_api_monitor":Path(r"D:\temp\iteration41-capability-artifacts-20260926\wheels\monitor-a\bt_api_monitor-0.1.0-py3-none-any.whl"),
}
EXPECTED={"bt_api_ctp":"2.0.4+iteration41.i9","bt_api_py":"0.15.5","bt_api_execution":"0.2.0","bt_api_base":"0.15.4","bt_api_risk":"0.1.0","bt_api_monitor":"0.1.0"}
def canon(name): return name.lower().replace('_','-').replace('.','-')
def digest(raw): return hashlib.sha256(raw).hexdigest()
def wheel_meta(path):
 with zipfile.ZipFile(path) as z:
  name=next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))
  text=z.read(name).decode('utf-8','replace')
  pkg=next(x.split(': ',1)[1] for x in text.splitlines() if x.startswith('Name: '))
  version=next(x.split(': ',1)[1] for x in text.splitlines() if x.startswith('Version: '))
 return canon(pkg),version
wheel_index={}
for p in WHEELHOUSE.glob('*.whl'):
 key=wheel_meta(p)
 wheel_index.setdefault(key,p)
for p in EXPLICIT.values():
 key=wheel_meta(p)
 wheel_index[key]=p
for name,path in EXPLICIT.items():
 if not path.is_file(): raise AssertionError(f"explicit wheel absent: {path}")
 pkg,version=wheel_meta(path)
 if pkg!=canon(name) or version!=EXPECTED[name]: raise AssertionError(f"explicit metadata mismatch: {name} {pkg} {version}")

cfg=(VEN/"pyvenv.cfg").read_text(encoding='utf-8')
if 'include-system-site-packages = false' not in cfg: raise AssertionError('system site packages enabled')
if Path(sys.prefix).resolve()!=VEN: raise AssertionError(f"wrong sys.prefix: {sys.prefix}")
site_paths=[Path(p).resolve() for p in sys.path if 'site-packages' in p.casefold()]
if site_paths != [SITE]: raise AssertionError(f"unexpected sys.path site roots: {site_paths}")

native_attempts=[]
class BlockCtpNative:
 def find_spec(self,fullname,path=None,target=None):
  if fullname in {'bt_api_ctp.ctp._ctp','_ctp'}:
   native_attempts.append(fullname)
   raise ModuleNotFoundError(f"blocked during package-origin check: {fullname}")
sys.meta_path.insert(0,BlockCtpNative())
modules={}
for name in ('bt_api_ctp','bt_api_py','bt_api_execution','bt_api_base','bt_api_risk','bt_api_monitor'):
 module=importlib.import_module(name)
 origin=Path(module.__file__).resolve()
 if SITE not in origin.parents: raise AssertionError(f"module not from this venv: {name} -> {origin}")
 modules[name]={"file":str(origin),"version":importlib.metadata.version(name)}
 if modules[name]['version']!=EXPECTED[name]: raise AssertionError(f"wrong installed metadata version for {name}: {modules[name]}")

records=[]
record_total=0
unhashed_generated_rows=[]
source_wheel_missing=[]
for dist in importlib.metadata.distributions(path=[str(SITE)]):
 name=dist.metadata.get('Name')
 version=dist.version
 if not name: raise AssertionError(f"distribution missing Name metadata: {dist}")
 key=(canon(name),version)
 dist_info=Path(dist._path)
 record_file=dist_info/'RECORD'
 if not record_file.is_file(): raise AssertionError(f"RECORD missing: {name} {version}")
 record_raw=record_file.read_bytes()
 checked=0
 record_paths=set()
 source_path=wheel_index.get(key)
 source_zip=zipfile.ZipFile(source_path) if source_path else None
 if source_zip is None and canon(name) not in {'pip','setuptools'}: source_wheel_missing.append({"name":name,"version":version})
 for row in csv.reader(io.StringIO(record_raw.decode('utf-8'))):
  if len(row)!=3: raise AssertionError(f"malformed installed RECORD row for {name}")
  relative,hash_spec,size_spec=row
  record_paths.add(relative)
  if not hash_spec and not size_spec:
   target=Path(dist.locate_file(relative)).resolve()
   if SITE not in target.parents or not target.is_file(): raise AssertionError(f"unhashed RECORD path absent/outside venv: {name}:{relative}")
   if not relative.endswith('.dist-info/RECORD'):
    if not relative.endswith('.pyc') or '__pycache__/' not in relative.replace('\\','/'):
     raise AssertionError(f"unexpected unhashed RECORD row: {name}:{relative}")
    unhashed_generated_rows.append({"name":name,"relative_path":relative,"size":target.stat().st_size,"classification":"pip-generated pyc; RECORD intentionally unhashed"})
   continue
  target=Path(dist.locate_file(relative))
  if not target.is_file(): raise AssertionError(f"RECORD file absent: {name}:{relative}")
  raw=target.read_bytes()
  algorithm,encoded=hash_spec.split('=',1)
  if algorithm!='sha256': raise AssertionError(f"unexpected RECORD algorithm {algorithm}")
  expected=base64.urlsafe_b64decode(encoded+'='*((-len(encoded))%4))
  if hashlib.sha256(raw).digest()!=expected or len(raw)!=int(size_spec): raise AssertionError(f"installed RECORD mismatch {name}:{relative}")
  if source_zip and relative in source_zip.namelist() and source_zip.read(relative)!=raw:
   raise AssertionError(f"installed bytes differ from source wheel {name}:{relative}")
  checked+=1
 source_member_count=0
 if source_zip:
  source_members=[member for member in source_zip.namelist() if not member.endswith('/')]
  for member in source_members:
   if member.endswith('.dist-info/RECORD'):
    continue
   if member not in record_paths:
    raise AssertionError(f"source wheel member missing from installed RECORD: {name}:{member}")
   installed=Path(dist.locate_file(member))
   if not installed.is_file() or installed.read_bytes()!=source_zip.read(member):
    raise AssertionError(f"installed wheel payload mismatch: {name}:{member}")
  source_member_count=len(source_members)
  source_zip.close()
 record_total+=checked
 direct_raw=dist.read_text('direct_url.json')
 direct=None
 if direct_raw:
  direct=json.loads(direct_raw)
  archive=(direct.get('archive_info') or {}).get('hashes') or {}
  if 'sha256' in archive and source_path and archive['sha256']!=digest(source_path.read_bytes()):
   raise AssertionError(f"direct_url wheel digest differs for {name}")
 records.append({"name":name,"version":version,"record_path":str(record_file),"record_sha256":digest(record_raw),"verified_hashed_rows":checked,"source_wheel":str(source_path) if source_path else None,"source_wheel_sha256":digest(source_path.read_bytes()) if source_path else None,"source_wheel_payload_members":source_member_count,"direct_url":direct})
if source_wheel_missing: raise AssertionError(f"installed non-tool wheels missing from source wheel index: {source_wheel_missing}")
install_log=(Path(r"D:\temp\iteration41-unified-v20r2-consumer-20260927")/"consumer-install.log").read_text(encoding='utf-8-sig').splitlines()
processing_wheels=[line[len('Processing '):].split(' (from ',1)[0].lower().replace('/','\\') for line in install_log if line.startswith('Processing ')]
selected_wheels=[d['source_wheel'].lower().replace('/','\\') for d in records if d['source_wheel']]
if sorted(processing_wheels)!=sorted(selected_wheels): raise AssertionError('pip Processing wheel paths differ from the source-wheel inventory')
for name,version in EXPECTED.items():
 if (canon(name),version) not in wheel_index: raise AssertionError(f"no pinned source wheel for {name}")

native_modules=[]
for name,module in tuple(sys.modules.items()):
 file=getattr(module,'__file__',None)
 if file and str(file).lower().endswith(('.pyd','.dll','.so','.dylib')):
  native_modules.append({"name":name,"file":str(file)})
if any(item['name']=='bt_api_ctp.ctp._ctp' for item in native_modules): raise AssertionError('CTP native extension loaded')
unhashed_summary={"count":len(unhashed_generated_rows),"sha256":digest(json.dumps(unhashed_generated_rows,sort_keys=True,separators=(',',':')).encode()),"samples":unhashed_generated_rows[:8]}
result={"result":"PASS","python":sys.version,"python_executable":sys.executable,"sys_prefix":sys.prefix,"include_system_site_packages":False,"site_package_root":str(SITE),"site_packages_sys_path":[str(p) for p in site_paths],"modules":modules,"native_ctp_attempts_blocked":native_attempts,"loaded_extension_modules":native_modules,"distribution_count":len(records),"record_verified_rows":record_total,"unhashed_generated_rows":unhashed_summary,"install_processing_wheels_count":len(processing_wheels),"source_wheel_missing":source_wheel_missing,"record_distributions":records}
print(json.dumps(result,sort_keys=True))
