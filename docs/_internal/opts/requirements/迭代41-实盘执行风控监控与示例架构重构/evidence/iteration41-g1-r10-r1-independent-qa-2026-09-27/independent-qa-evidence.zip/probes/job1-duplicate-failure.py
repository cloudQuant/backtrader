from pathlib import Path
import json, os, subprocess, sys
payload=Path(r'D:\temp\iteration41-g1-r10-r1-independent-qa-20260927\payload')
sys.path.insert(0,str(payload))
import run_r10_trials_r10_frozen as api
exe=payload/'r10_custodian.exe'
go=api.create_go_event()
startup=subprocess.STARTUPINFO()
startup.lpAttributeList={'handle_list':[go]}
try:
 p=subprocess.Popen([str(exe),'--outer-run','p05','0',str(go),sys.executable],cwd=payload,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,close_fds=True,startupinfo=startup)
 out,_=p.communicate(timeout=5)
 print(json.dumps({'exit_code':p.returncode,'output':out.decode('utf-8','replace'),'expected_no_supervisor':'R10_OUTER_JOB_READY' not in out.decode('utf-8','replace'),'expected_no_ready':'R10_READY' not in out.decode('utf-8','replace')},indent=2))
except subprocess.TimeoutExpired:
 p.kill(); out,_=p.communicate(timeout=2)
 print(json.dumps({'timeout':True,'output':out.decode('utf-8','replace')},indent=2))
finally:
 api.K32.CloseHandle(api.HANDLE(go))