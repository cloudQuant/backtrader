from pathlib import Path
import json, sys
payload=Path(r'D:\temp\iteration41-g1-r10-r1-independent-qa-20260927\payload')
sys.path.insert(0,str(payload))
import run_r10_r1_trials as harness
row=harness.run_trial('outer-job',stuck_expected=True)
print(json.dumps(row,indent=2,sort_keys=True))