from pathlib import Path
import hashlib,sys
qa=Path(__file__).resolve().parent
payload=qa/'payload'
exe=payload/'r10_custodian.exe'
expected='829d7956c1acd2c70184d549bfcff39d4f107881189f256b83becebaa26368aa'
actual=hashlib.sha256(exe.read_bytes()).hexdigest()
if actual!=expected: raise SystemExit(f'pinned binary hash mismatch: {actual}')
sys.path.insert(0,str(payload))
import run_r10_r1_trials as harness
harness.r10.build=lambda:{'exit_code':0,'exe_exists':True,'exe_sha256':actual,'output':'No rebuild: using ZIP-hash-verified frozen executable.'}
harness.main()