from __future__ import annotations
import hashlib, json, zipfile, csv, io, xml.etree.ElementTree as ET
from pathlib import Path

out = Path(r'D:\temp\iteration41-g5-v22-wheel-consumer-20260927')
root = Path(r'D:\temp\iteration41_v22_g5_crash_recovery_r3r3_candidate_20260927')
manifest = Path(r'D:\temp\iteration41_v22_g5_crash_recovery_qa_20260927\V22-CANDIDATE-MANIFEST.json')
base_manifest = root / 'COMPOSITE-SOURCE-MANIFEST.json'
v21_receipt = Path(r'D:\temp\g5-v21-finalizer-evidence-20260927\final-receipt-v21.json')
crash_log = Path(r'D:\temp\iteration41-g5-r3-crash-claim-repro\run.log')
consumer = Path(r'D:\q\unified-g5-v22-probe-consumer-20260927')
wheel_a = out / 'buildA2' / 'wheelhouse' / 'bt_api_execution-0.2.2.dev0+v22.8244038ab975-py3-none-any.whl'
wheel_b = out / 'buildB2' / 'wheelhouse' / wheel_a.name

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()
def evidence_file(label: str, p: Path) -> dict:
    return {'label': label, 'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}

def wheel_inventory(p: Path) -> dict:
    with zipfile.ZipFile(p) as z:
        names = sorted(z.namelist())
        recs = [n for n in names if n.endswith('.dist-info/RECORD')]
        assert len(recs) == 1
        rows = list(csv.reader(io.StringIO(z.read(recs[0]).decode('utf-8'))))
        assert len(rows) == len(names)
        hashed = 0
        for name, digest, size in rows:
            data = z.read(name)
            if size:
                assert int(size) == len(data), name
            if digest:
                algo, encoded = digest.split('=',1)
                assert algo == 'sha256'
                actual = __import__('base64').urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('=')
                assert actual == encoded, name
                hashed += 1
            else:
                assert name == recs[0]
        return {'sha256':sha(p),'bytes':p.stat().st_size,'members':len(names),'record_rows':len(rows),
                'record_hashed_rows':hashed,'record_unhashed_self':recs[0],'names':names}

freeze = json.loads((out/'v22-freeze-verification.json').read_text(encoding='utf-8'))
builds = json.loads((out/'v22-probe-build-receipt-r2.json').read_text(encoding='utf-8'))
installed = json.loads((out/'installed-wheel-verification-r2.json').read_text(encoding='utf-8'))
assert sha(manifest) == '8244038ab975f30de6c0ba56c140f033ddd5b5ce5fb3cabc9e60abb7bf24066d'
assert freeze['candidate_manifest_sha256'] == sha(manifest)
assert freeze['candidate_status'] == 'SOURCE_ONLY_CANDIDATE_NOT_G5_ACCEPTANCE'
assert freeze['probe_version'] == '0.2.2.dev0+v22.8244038ab975'
assert builds['byte_identical'] is True and builds['manifest_sha256'] == sha(manifest)
wa, wb = wheel_inventory(wheel_a), wheel_inventory(wheel_b)
assert wa == wb
assert wa['sha256'] == 'bfa0583be8f97cc62f979b5848d7b798d440789617bf3dec813be53641d0702a'
assert installed['system_site_packages'] is False and len(installed['packages']) == 11

focused = ET.parse(out/'v22-process-exit-focused-r2-junit.xml').getroot()
full_compatible = ET.parse(out/'v22-full-compatible-installed-wheel-junit.xml').getroot()
full_raw = ET.parse(out/'v22-full-installed-wheel-junit.xml').getroot()
# Count JUnit test results and exact failures rather than trusting the shell summary.
def junit_summary(rootxml):
    cases=list(rootxml.iter('testcase'))
    failures=[]; skipped=0
    for case in cases:
        if case.find('failure') is not None or case.find('error') is not None:
            failures.append({'classname':case.attrib.get('classname'), 'name':case.attrib.get('name')})
        if case.find('skipped') is not None: skipped += 1
    return {'cases':len(cases),'failures':failures,'skipped':skipped,'passed':len(cases)-len(failures)-skipped}
focus_summary=junit_summary(focused)
compat_summary=junit_summary(full_compatible)
raw_summary=junit_summary(full_raw)
assert focus_summary['cases']==20 and focus_summary['passed']==20 and not focus_summary['failures']
assert compat_summary['cases']==309 and compat_summary['passed']==309 and compat_summary['skipped']==0 and not compat_summary['failures']
assert raw_summary['cases']==311 and raw_summary['passed']==309 and len(raw_summary['failures'])==2

files = [
 ('receipt_finalizer',out/'finalize_v22_receipt.py'),('candidate_manifest',manifest),('base_composite_manifest',base_manifest),
 ('candidate_freeze_verifier',out/'verify_v22_freeze.py'),('candidate_freeze_verification',out/'v22-freeze-verification.json'),
 ('build_runner',out/'build_v22_probe_wheels_r2.py'),('build_receipt',out/'v22-probe-build-receipt-r2.json'),
 ('build_A_log',out/'buildA2'/'wheelhouse-build.log'),('build_A_transform',out/'buildA2'/'wheelhouse-transform.json'),
 ('build_B_log',out/'buildB2'/'wheelhouse-build.log'),('build_B_transform',out/'buildB2'/'wheelhouse-transform.json'),
 ('probe_wheel_A',wheel_a),('probe_wheel_B',wheel_b),
 ('wheel_map',out/'wheel-map-v22-probe.json'),('consumer_installed_verifier',out/'installed-wheel-verification-r2.json'),
 ('consumer_install_log',out/'consumer-install.log'),('test_wheel_direct_install_log',out/'test-wheels-direct-install.log'),
 ('pip_check_log',out/'pip-check.log'),('venv_config',consumer/'pyvenv.cfg'),
 ('pytest_runner',out/'run_installed_pytest.py'),('native_block_guard',Path(r'D:\temp\g5-r3-test-guard\sitecustomize.py')),
 ('focused_log',out/'v22-process-exit-focused-final.log'),('focused_junit',out/'v22-process-exit-focused-r2-junit.xml'),
 ('raw_full_log',out/'v22-full-installed-wheel-r2.log'),('raw_full_junit',out/'v22-full-installed-wheel-junit.xml'),
 ('compatible_full_log',out/'v22-full-compatible-installed-wheel.log'),('compatible_full_junit',out/'v22-full-compatible-installed-wheel-junit.xml'),
 ('v21_receipt',v21_receipt),('pre_v22_crash_before_req_log',crash_log),
]
receipt = {
 'schema':'iteration41-g5-v22-strict-wheel-consumer-receipt.v1',
 'candidate':{
  'root':str(root),'manifest_path':str(manifest),'manifest_sha256':sha(manifest),
  'candidate_status':freeze['candidate_status'],'source_distribution_version':freeze['source_distribution_version_only'],
  'probe_version':freeze['probe_version'],'baseline_composite_manifest_sha256':freeze['base_composite_manifest_sha256'],
  'r3r3_manifest_sha256':freeze['r3r3_manifest_sha256'],'v21_manifest_sha256':freeze['v21_manifest_sha256'],
  'verified_base_entries':freeze['base_source_entries_verified'],'verified_delta_entries':freeze['delta_entries_verified'],
  'changed_base_entries':freeze['changed_base_entries'],'new_entries':freeze['new_entries'],
  'manifested_source_files_modified':False,
  'unmanifested_test_cache_dirs_present_after_runs':[str(root/'src'/'bt_api_execution'/'__pycache__'),str(root/'tests'/'__pycache__'),str(root/'.pytest_cache')],
  'cache_note':'These are pytest-generated cache artifacts outside the frozen source manifest; all declared source entries remain hash-matched. They are not packaged into the wheel.',
  'probe_transform':'disposable staging only: pyproject version 0.2.0 -> 0.2.2.dev0+v22.8244038ab975; unmanifested README metadata reference removed; product package code unchanged'
 },
 'double_build':{'builds':builds['builds'],'wheel_A':wa,'wheel_B':wb,'byte_identical':True,
                 'release_identity':'isolated V22 probe only; not the planned 0.2.2 release'},
 'installed_consumer':{
  'venv':str(consumer),'python':'CPython 3.11.5','include_system_site_packages':False,
  'pip_check':'No broken requirements found.','package_count':len(installed['packages']),
  'packages':installed['packages'],'wheel_map_sha256':sha(out/'wheel-map-v22-probe.json'),
  'verification_json_sha256':sha(out/'installed-wheel-verification-r2.json'),
  'native_guard':'BlockCTPNative active via test-only sitecustomize; no _ctp module loaded',
  'native_provider_account_or_private_config':'not used'
 },
 'tests':{
  'focused_process_exit':{'result':'20 passed','junit':str(out/'v22-process-exit-focused-r2-junit.xml'),'summary':focus_summary,
   'coverage':['exact persisted process/family/session/writer/command identity binding','mismatched identity and bool process-id rejection','default-closed recovery and generic finalization rejection','rollback on proof/audit insert failure','V21 CLAIMED without process binding migrates to UNKNOWN and permanent fence']},
  'full_unfiltered':{'result':'309 passed, 2 failed','summary':raw_summary,
   'meaning':'raw complete suite retained; two tests require real native Trader logged-in identity and fail under the native import guard'},
  'full_source_only_compatible':{'result':'309 passed, 2 deselected','collected_before_exact_deselection':311,'deselected_count':2,'summary':compat_summary,
   'exact_deselected':['tests/test_ctp_callback_source_bridge.py::test_close_wakes_real_trader_client_poll_and_discards_its_result','tests/test_ctp_callback_source_bridge.py::test_close_discards_real_sdk_event_dequeued_before_close_wins'],
   'reason':'these two tests require real native Trader login evidence; no native extension was loaded in this fake-only run'}
 },
 'commands':{
  'build':'C:\\Anaconda3\\python.exe -m pip wheel --no-index --no-deps --no-build-isolation --wheel-dir <isolated-A-or-B-wheelhouse> <isolated-manifest-staged-source>',
  'verify_installed':'<consumer>\\Scripts\\python.exe -I <run_g5_wheel_qa.py> verify-installed --wheel-map <wheel-map-v22-probe.json> --output <installed-verification.json>',
  'pip_check':'<consumer>\\Scripts\\python.exe -m pip check',
  'focused':'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1; PYTHONPATH=<native-block-guard>; <consumer>\\Scripts\\python.exe -s <run_installed_pytest.py> focused',
  'full_unfiltered':'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1; PYTHONPATH=<native-block-guard>; <consumer>\\Scripts\\python.exe -s <run_installed_pytest.py> full',
  'full_compatible':'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1; PYTHONPATH=<native-block-guard>; <consumer>\\Scripts\\python.exe -s <run_installed_pytest.py> full-compatible'
 },
 'blockers':{
  'g5_status':'BLOCKED',
  'crash_before_native_req':'V21 evidence remains: process restart/reopen left CLAIMED native_call_inflight=1 with no call receipt, ACTIVE callback/family owner; successor claim rejected. This raw failure log is retained in the artifact list.',
  'v22_recovery_scope':'V22 exercises an injected fake process-exit verifier and transactional Store capability only. It has no production Windows supervisor verifier or code pin; fake proof tests do not establish OS process death or a deployable recovery authority.',
  'no_replay':'legacy CLAIMED rows without process generation migrate to UNKNOWN and remain permanently fenced; no resend/successor path is added.',
  'deployment':'no stable 0.2.2 pin, no real CTP/native/provider session, no account, no live route acceptance'
 },
 'evidence_files':[evidence_file(label,path) for label,path in files]
}
receipt_path=out/'final-receipt-v22.json'
receipt_path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
(out/'final-receipt-v22.sha256').write_text(sha(receipt_path)+'  final-receipt-v22.json\n',encoding='ascii')
print(json.dumps({'receipt':str(receipt_path),'receipt_sha256':sha(receipt_path),'artifact_count':len(files),
                  'wheel_sha256':wa['sha256'],'focused':focus_summary,'raw_full':raw_summary,
                  'compatible_full':compat_summary,'pip_check':'clean','native_loaded':False},indent=2))
