import json, os, sys
from pathlib import Path
import importlib.util

venv = Path(r'D:\q\unified-g5-v22-probe-consumer-20260927').resolve()
root = Path(r'D:\temp\iteration41_v22_g5_crash_recovery_r3r3_candidate_20260927').resolve()
evidence = Path(r'D:\temp\iteration41-g5-v22-wheel-consumer-20260927')
kind = sys.argv[1]
if kind not in ('focused', 'full', 'full-compatible'):
    raise SystemExit('expected focused, full, or full-compatible')
if Path(sys.prefix).resolve() != venv:
    raise SystemExit(f'wrong venv: {sys.prefix}')
if 'include-system-site-packages = false' not in (venv / 'pyvenv.cfg').read_text(encoding='utf-8').lower():
    raise SystemExit('system site packages are enabled')
global_site = (Path(sys.base_prefix) / 'Lib' / 'site-packages').resolve()
resolved_sys_path=[]
for item in sys.path:
    if not item:
        continue
    p=Path(item)
    try:
        rp=p.resolve()
    except OSError:
        continue
    resolved_sys_path.append(str(rp))
    if rp == global_site or rp.is_relative_to(global_site):
        raise SystemExit(f'global site-packages present on sys.path: {rp}')
import bt_api_execution
origin=Path(bt_api_execution.__file__).resolve()
site=(venv/'Lib'/'site-packages').resolve()
if not origin.is_relative_to(site):
    raise SystemExit(f'bt_api_execution did not load from installed venv: {origin}')
if 'bt_api_ctp.ctp._ctp' in sys.modules:
    raise SystemExit('native CTP module already loaded')
if not any(type(f).__name__ == 'BlockCTPNative' for f in sys.meta_path):
    raise SystemExit('native CTP import guard is not active')
plugins=[]
if kind == 'focused':
    targets=[str(root/'tests'/'test_ctp_process_exit_recovery_v22.py')]
    junit=evidence/'v22-process-exit-focused-r2-junit.xml'
else:
    targets=[str(root/'tests')]
    if kind == 'full-compatible':
        native_test=(root/'tests'/'test_ctp_callback_source_bridge.py').resolve()
        exact_names={
            'test_close_wakes_real_trader_client_poll_and_discards_its_result',
            'test_close_discards_real_sdk_event_dequeued_before_close_wins',
        }
        class DeselectOnlyNativeLoginCases:
            deselected=[]
            def pytest_collection_modifyitems(self, session, config, items):
                kept=[]
                for item in items:
                    if Path(str(item.path)).resolve() == native_test and item.originalname in exact_names:
                        self.deselected.append(item.nodeid)
                    else:
                        kept.append(item)
                if len(self.deselected) != 2:
                    raise RuntimeError(f'expected exact two native-only cases, found {self.deselected!r}')
                items[:] = kept
                config.hook.pytest_deselected(items=self.deselected)
                print('EXACT_NATIVE_ONLY_DESELECTS=' + json.dumps(self.deselected,sort_keys=True))
        plugins=[DeselectOnlyNativeLoginCases()]
    junit=evidence/('v22-full-compatible-installed-wheel-junit.xml' if kind == 'full-compatible' else 'v22-full-installed-wheel-r2-junit.xml')
print(json.dumps({'phase':kind,'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,
                  'global_site_packages_on_sys_path':False,'bt_api_execution_origin':str(origin),
                  'ctp_native_guard':'BlockCTPNative active','ctp_native_loaded':False,
                  'targets':targets},sort_keys=True))
import pytest
args=['--noconftest','-q','--tb=short','-p','pytest_asyncio.plugin',f'--junitxml={junit}',*targets]
raise SystemExit(pytest.main(args,plugins=plugins))
