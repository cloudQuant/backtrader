from importlib.abc import MetaPathFinder
import sys
class BlockCTPNative(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_ctp.ctp._ctp':
            raise ModuleNotFoundError('native extension blocked for fake-only run')
        return None
sys.meta_path.insert(0, BlockCTPNative())
