from __future__ import annotations
import base64, csv, hashlib, io, json, os, re, shutil, subprocess, zipfile
from email.parser import BytesParser
from pathlib import Path

EVIDENCE = Path(r'D:\temp\iteration41-g5-v22-wheel-consumer-20260927')
VERIFY = json.loads((EVIDENCE / 'v22-freeze-verification.json').read_text(encoding='utf-8'))
ROOT = Path(VERIFY['candidate_root'])
EXPECTED_MANIFEST = '8244038ab975f30de6c0ba56c140f033ddd5b5ce5fb3cabc9e60abb7bf24066d'
MANIFEST = Path(r'D:\temp\iteration41_v22_g5_crash_recovery_qa_20260927\V22-CANDIDATE-MANIFEST.json')
PYTHON = Path(r'C:\Anaconda3\python.exe')
PROBE_VERSION = '0.2.2.dev0+v22.' + EXPECTED_MANIFEST[:12]


def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def file_sha(p: Path) -> str: return sha(p.read_bytes())

def verify_record(z: zipfile.ZipFile) -> dict:
    records=[n for n in z.namelist() if n.endswith('.dist-info/RECORD')]
    if len(records)!=1: raise ValueError(f'bad RECORD count: {records}')
    rows=list(csv.reader(io.StringIO(z.read(records[0]).decode('utf-8'))))
    seen=set(); hashed=0; unhashed=[]
    for row in rows:
        if len(row)!=3: raise ValueError('bad RECORD row')
        name,hfield,size=row
        if name in seen: raise ValueError(f'duplicate RECORD path: {name}')
        seen.add(name); data=z.read(name)
        if size and int(size)!=len(data): raise ValueError(f'RECORD size mismatch: {name}')
        if not hfield: unhashed.append(name); continue
        algo,enc=hfield.split('=',1)
        if algo!='sha256': raise ValueError(f'unsupported RECORD hash {algo}')
        actual=base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode('ascii').rstrip('=')
        if actual!=enc: raise ValueError(f'RECORD hash mismatch: {name}')
        hashed+=1
    if unhashed != [records[0]] or set(z.namelist()) != seen:
        raise ValueError('RECORD does not cover exact wheel member set')
    return {'record':records[0],'rows':len(rows),'hashed_rows_verified':hashed,'unhashed_self':unhashed[0]}

def wheel_report(path: Path, stage: Path) -> dict:
    raw=path.read_bytes()
    with zipfile.ZipFile(path) as z:
        rec=verify_record(z)
        names=set(z.namelist())
        metadata_name=next(n for n in names if n.endswith('.dist-info/METADATA'))
        metadata_bytes=z.read(metadata_name)
        meta=BytesParser().parsebytes(metadata_bytes)
        if meta['Name'].lower().replace('_','-') != 'bt-api-execution': raise ValueError('wheel name mismatch')
        if meta['Version'] != PROBE_VERSION: raise ValueError(f'probe version mismatch: {meta["Version"]}')
        expected={p.relative_to(stage/'src').as_posix() for p in (stage/'src'/'bt_api_execution').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
        actual={n for n in names if n.startswith('bt_api_execution/')}
        if actual != expected:
            raise ValueError(f'wheel/package source inventory mismatch; missing={sorted(expected-actual)}, extra={sorted(actual-expected)}')
        mismatches=[]
        for rel in sorted(expected):
            if (stage/'src'/Path(*rel.split('/'))).read_bytes()!=z.read(rel): mismatches.append(rel)
        if mismatches: raise ValueError(f'wheel differs from staged package source: {mismatches}')
    return {'path':str(path),'sha256':sha(raw),'bytes':len(raw),'version':PROBE_VERSION,
            'record':rec,'package_files_equal':len(expected),'metadata_sha256':sha(metadata_bytes)}

def build_one(label: str, output: Path) -> dict:
    if output.exists() and any(output.iterdir()): raise ValueError(f'output path is not empty: {output}')
    stage=output.parent/(output.name+'-source')
    if stage.exists(): raise ValueError(f'stage already exists: {stage}')
    output.mkdir(parents=True,exist_ok=True)
    stage.mkdir(parents=True)
    rows=VERIFY['verified_entries']
    for row in rows:
        rel=Path(*row['path'].split('/'))
        src=ROOT/rel; dst=stage/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(src,dst)
        if file_sha(dst)!=row['sha256']: raise ValueError(f'copy mismatch: {row["path"]}')
    pyproject=stage/'pyproject.toml'
    original=pyproject.read_text(encoding='utf-8')
    if original.count('version = "0.2.0"') != 1: raise ValueError('expected one frozen project version field')
    transformed=original.replace('version = "0.2.0"',f'version = "{PROBE_VERSION}"',1)
    # README.md is not in the frozen source inventory. Drop the readme metadata reference
    # only in this disposable probe staging tree rather than import unmanifested bytes.
    if 'readme = "README.md"\n' in transformed:
        transformed=transformed.replace('readme = "README.md"\n','',1)
    pyproject.write_text(transformed,encoding='utf-8',newline='\n')
    transform={'label':label,'probe_version':PROBE_VERSION,'original_pyproject_sha256':sha(original.encode()),
               'staged_pyproject_sha256':file_sha(pyproject),'changes':['version 0.2.0 -> '+PROBE_VERSION,
               'removed unmanifested README.md metadata reference from disposable staging copy']}
    (output.parent/(output.name+'-transform.json')).write_text(json.dumps(transform,indent=2)+'\n',encoding='utf-8')
    env=os.environ.copy()
    env.update({'SOURCE_DATE_EPOCH':'1790452042','PYTHONHASHSEED':'0','PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1'})
    cmd=[str(PYTHON),'-m','pip','wheel','--no-index','--no-deps','--no-build-isolation','--wheel-dir',str(output),str(stage)]
    cp=subprocess.run(cmd,cwd=str(output.parent),env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=output.parent/(output.name+'-build.log'); log.write_text(cp.stdout,encoding='utf-8')
    if cp.returncode: raise RuntimeError(f'{label} build failed rc={cp.returncode}; see {log}')
    wheels=list(output.glob('*.whl'))
    if len(wheels)!=1: raise ValueError(f'{label} must emit exactly one wheel, found {wheels}')
    report=wheel_report(wheels[0],stage)
    report.update({'label':label,'returncode':cp.returncode,'command':cmd,'cwd':str(output.parent),
                   'build_log':str(log),'build_log_sha256':file_sha(log),'staging_root':str(stage),
                   'staged_pyproject_sha256':transform['staged_pyproject_sha256']})
    return report

if file_sha(MANIFEST)!=EXPECTED_MANIFEST: raise ValueError('candidate manifest changed after verification')
if file_sha(ROOT/'COMPOSITE-SOURCE-MANIFEST.json') != '00577665667a33c9a7d62d331c0cad99b0b660790d0b475d0bd8c1b6caa6e2dd': raise ValueError('frozen composite changed')
if not PYTHON.is_file(): raise FileNotFoundError(PYTHON)
base=EVIDENCE/'buildA2'/'wheelhouse'
other=EVIDENCE/'buildB2'/'wheelhouse'
a=build_one('A',base)
b=build_one('B',other)
if a['sha256'] != b['sha256']:
    with zipfile.ZipFile(a['path']) as za, zipfile.ZipFile(b['path']) as zb:
        na,nb=set(za.namelist()),set(zb.namelist())
        changed=[n for n in sorted(na&nb) if za.read(n)!=zb.read(n)]
    raise RuntimeError(f'non-reproducible probe wheels: A={a["sha256"]} B={b["sha256"]}; changed={changed}')
result={'schema':'g5-v22-probe-wheel-build.v1','manifest_sha256':EXPECTED_MANIFEST,'probe_version':PROBE_VERSION,
        'source_manifest_verified_entries':len(VERIFY['verified_entries']),'source_pyproject_sha256':json.loads(MANIFEST.read_text())['pyproject_sha256'],
        'builds':[a,b],'byte_identical':True,'release_identity':'isolated probe only; not planned final 0.2.2'}
out=EVIDENCE/'v22-probe-build-receipt-r2.json'
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'probe_version':PROBE_VERSION,'wheel_sha256':a['sha256'],'wheel_bytes':a['bytes'],
                  'record_rows':a['record']['rows'],'source_package_files':a['package_files_equal'],
                  'builds_byte_identical':True,'receipt':str(out)},indent=2))
