import hashlib, json
from pathlib import Path, PurePosixPath

root = Path(r'D:\temp\iteration41_v22_g5_crash_recovery_r3r3_candidate_20260927')
manifest_path = Path(r'D:\temp\iteration41_v22_g5_crash_recovery_qa_20260927\V22-CANDIDATE-MANIFEST.json')
base_manifest_path = root / 'COMPOSITE-SOURCE-MANIFEST.json'
expected_manifest_sha = '8244038ab975f30de6c0ba56c140f033ddd5b5ce5fb3cabc9e60abb7bf24066d'
expected_base_composite_sha = '00577665667a33c9a7d62d331c0cad99b0b660790d0b475d0bd8c1b6caa6e2dd'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def checked(root, rel):
    q=PurePosixPath(rel)
    if q.is_absolute() or '\\' in rel or ':' in rel or any(x in ('','.','..') for x in q.parts):
        raise ValueError(f'unsafe relative path {rel!r}')
    p=root.joinpath(*q.parts)
    if p.is_symlink() or not p.resolve(strict=True).is_relative_to(root.resolve(strict=True)) or not p.is_file():
        raise ValueError(f'unsafe/missing file {rel!r}')
    cur=root
    for part in q.parts:
        cur=cur/part
        if cur.is_symlink(): raise ValueError(f'symlink in path {rel!r}')
    return p

raw=manifest_path.read_bytes()
actual=hashlib.sha256(raw).hexdigest()
if actual != expected_manifest_sha: raise ValueError(f'V22 candidate manifest digest mismatch: {actual}')
doc=json.loads(raw)
if doc['candidate_path'].casefold() != str(root).casefold(): raise ValueError('candidate path mismatch')
if doc['candidate_status'] != 'SOURCE_ONLY_CANDIDATE_NOT_G5_ACCEPTANCE': raise ValueError('unexpected candidate status')
if doc['distribution_version'] != '0.2.0': raise ValueError('unexpected frozen source version')
if sha(base_manifest_path) != expected_base_composite_sha: raise ValueError('composite manifest mismatch')
composite=json.loads(base_manifest_path.read_text(encoding='utf-8'))
if composite['source_only'] is not True or composite['version'] != '0.2.0': raise ValueError('base composite identity mismatch')
base_rows={r['path']:r for r in composite['source_files']}
if len(base_rows) != len(composite['source_files']): raise ValueError('duplicate path in base source manifest')
delta={r['path']:r for r in doc['delta_files']}
if len(delta) != len(doc['delta_files']): raise ValueError('duplicate path in V22 delta list')
if sha(checked(root,'pyproject.toml')) != doc['pyproject_sha256']: raise ValueError('pyproject digest mismatch')
if doc['base']['composite_manifest_sha256'] != expected_base_composite_sha or doc['base']['declared_composite_manifest_sha256'] != expected_base_composite_sha: raise ValueError('V22 base manifest binding mismatch')
if doc['base']['cancel_input_manifest_sha256'] != composite['cancel_input_manifest_sha256'] or doc['base']['v21_handoff_input_manifest_sha256'] != composite['handoff_input_manifest_sha256']: raise ValueError('base input pins mismatch')
verified=[]
for rel,row in base_rows.items():
    path=checked(root,rel)
    v22=delta.get(rel)
    expect=row['sha256'] if v22 is None else v22['sha256']
    size=row['bytes'] if v22 is None else v22['bytes']
    if path.stat().st_size != size or sha(path) != expect: raise ValueError(f'base/delta mismatch for {rel}')
    if v22 is not None and v22.get('base_sha256') != row['sha256']: raise ValueError(f'wrong base SHA in delta for {rel}')
    verified.append({'path':rel,'bytes':size,'sha256':expect,'changed':v22 is not None})
new=[]
for rel,row in delta.items():
    if rel in base_rows: continue
    path=checked(root,rel)
    if row.get('base_sha256') is not None: raise ValueError(f'new delta has non-null base SHA: {rel}')
    if path.stat().st_size != row['bytes'] or sha(path) != row['sha256']: raise ValueError(f'new delta mismatch: {rel}')
    new.append({'path':rel,'bytes':row['bytes'],'sha256':row['sha256'],'changed':True})
expected_paths=set(base_rows)|set(delta)
if set(r['path'] for r in verified+new) != expected_paths: raise ValueError('source inventory mismatch')
result={
 'schema':'g5-v22-freeze-verification.v1',
 'candidate_manifest_sha256':actual,
 'candidate_root':str(root),
 'candidate_status':doc['candidate_status'],
 'source_distribution_version_only':'0.2.0',
 'probe_version':'0.2.2.dev0+v22.'+actual[:12],
 'base_composite_manifest_sha256':expected_base_composite_sha,
 'r3r3_manifest_sha256':composite['cancel_input_manifest_sha256'],
 'v21_manifest_sha256':composite['handoff_input_manifest_sha256'],
 'base_source_entries_verified':len(verified),
 'delta_entries_verified':len(delta),
 'changed_base_entries':sum(bool(r['changed']) for r in verified),
 'new_entries':new,
 'delta_files':delta,
 'verified_entries':verified+new,
 'limits':doc['limits'],
}
out=Path(r'D:\temp\iteration41-g5-v22-wheel-consumer-20260927\v22-freeze-verification.json')
out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('verified_entries','delta_files','limits')},indent=2))
