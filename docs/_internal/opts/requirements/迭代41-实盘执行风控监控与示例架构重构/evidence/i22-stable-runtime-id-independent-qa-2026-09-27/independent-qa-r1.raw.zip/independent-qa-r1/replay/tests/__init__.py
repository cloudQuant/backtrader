"""Backtrader test suite."""
