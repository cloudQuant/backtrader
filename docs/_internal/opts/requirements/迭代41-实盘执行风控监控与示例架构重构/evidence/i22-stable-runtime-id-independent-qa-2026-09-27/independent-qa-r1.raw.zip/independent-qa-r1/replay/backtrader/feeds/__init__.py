#!/usr/bin/env python
"""Data Feeds Module - Data source implementations.

This module provides data feed implementations for various data sources
including CSV files, pandas DataFrames, Yahoo Finance, Quandl, InfluxDB,
and the unified bt_api_py live interface.

Data Feed Types:
    - CSV Feeds: GenericCSVData, BTCSV, MT4CSV, SierraChart, VChartCSV
    - Pandas: PandasData for pandas DataFrame integration
    - Online: Yahoo Finance, Quandl, BtApiFeed
    - Utilities: Chainer, RollOver for data manipulation

Example:
    Loading data from a CSV file:
    >>> data = bt.feeds.GenericCSVData(
    ...     dataname='data.csv',
    ...     datetime=0,
    ...     open=1,
    ...     high=2,
    ...     low=3,
    ...     close=4,
    ...     volume=5
    ... )
    >>> cerebro.adddata(data)
"""

import os as _os

from .barrier import BarBarrierPolicy as BarBarrierPolicy
from .barrier import BarBarrierReason as BarBarrierReason
from .barrier import BarBarrierResult as BarBarrierResult
from .barrier import BarEvidence as BarEvidence
from .barrier import BarLeg as BarLeg
from .barrier import ClockMapping as ClockMapping
from .barrier import MinuteDecisionInput as MinuteDecisionInput
from .barrier import MultiLegBarBarrier as MultiLegBarBarrier
from .barrier import QuoteCutoffResult as QuoteCutoffResult
from .barrier import validate_quote_against_bar as validate_quote_against_bar
from .ctpcohort import CtpCohortLeg as CtpCohortLeg
from .ctpcohort import CtpCohortNow as CtpCohortNow
from .ctpcohort import CtpCohortPolicy as CtpCohortPolicy
from .ctpcohort import CtpCohortReason as CtpCohortReason
from .ctpcohort import CtpCohortResult as CtpCohortResult
from .ctpcohort import CtpQuoteCohort as CtpQuoteCohort
from .ctpcohort import CtpQuoteCohortValidator as CtpQuoteCohortValidator
from .ctpcohort import CtpQuoteEvidence as CtpQuoteEvidence
from .ctpcohort import CtpQuoteValidation as CtpQuoteValidation
from .ctpcohort import validate_ctp_quote as validate_ctp_quote

if _os.environ.get("BACKTRADER_LIGHT_IMPORT", "").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}:
    from .btapifeed import BtApiFeed as BtApiFeed
else:
    from .btapifeed import BtApiFeed as BtApiFeed
    from .btcsv import *
    from .chainer import Chainer as Chainer
    from .cryptohftdata import CryptoHFTData as CryptoHFTData
    from .csvgeneric import *
    from .influxfeed import *
    from .mixed_channel import MixedChannel as MixedChannel
    from .mixed_channel import build_mixed_channel as build_mixed_channel
    from .mt4csv import *
    from .pandafeed import *
    from .quandl import *
    from .rollover import RollOver as RollOver
    from .sierrachart import *
    from .vchart import *
    from .vchartcsv import *
    from .vchartfile import VChartFile as VChartFile
    from .yahoo import *
