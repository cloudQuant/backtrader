from __future__ import annotations

import os
import socket
import sys
from importlib.abc import MetaPathFinder
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
blocked_imports = []
network_attempts = []

class NativeSdkBlocker(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_py" or fullname.startswith("bt_api_py.") or fullname == "_ctp" or fullname.startswith("_ctp."):
            blocked_imports.append(fullname)
            raise ModuleNotFoundError("isolated QA blocks CTP SDK/native imports")
        return None

sys.meta_path.insert(0, NativeSdkBlocker())
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
sys.path.insert(0, str(ROOT))

import pytest

def deny_network(*args, **kwargs):
    network_attempts.append((args, kwargs))
    raise AssertionError("isolated QA blocks network access")

socket.create_connection = deny_network
socket.socket.connect = deny_network
socket.socket.connect_ex = deny_network

result = pytest.main([
    "-q",
    "-p", "no:asyncio",
    str(ROOT / "tests/unit/stores/test_i22_missing_runtime_id_side_effects_probe.py::test_missing_runtime_id_rejects_before_binding_lookup_reservation_or_mutation"),
    "--tb=short",
    "--junitxml",
    str(ROOT / "evidence/qa-missing-runtime-id-side-effects.junit.xml"),
])
print(f"pytest_exit_code={int(result)}")
print(f"blocked_sdk_import_attempts={blocked_imports}")
print(f"network_attempts={len(network_attempts)}")
if int(result) != 0 or blocked_imports or network_attempts:
    raise SystemExit(int(result) or 1)
if any(name == "bt_api_py" or name.startswith("bt_api_py.") or name == "_ctp" or name.startswith("_ctp.") for name in sys.modules):
    raise SystemExit("native SDK module remained loaded")
print("native_sdk_modules_loaded=0")
print("guarded_focused_test=PASS")

