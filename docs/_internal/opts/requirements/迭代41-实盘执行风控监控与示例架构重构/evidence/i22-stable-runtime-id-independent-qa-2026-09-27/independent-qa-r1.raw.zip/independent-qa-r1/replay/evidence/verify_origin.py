import importlib.abc
import sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
blocked = []
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_py' or fullname.startswith('bt_api_py.') or fullname == '_ctp' or fullname.startswith('_ctp.'):
            blocked.append(fullname)
            raise ModuleNotFoundError('QA blocks CTP SDK/native import')
        return None
sys.meta_path.insert(0, Block())
sys.path.insert(0, str(root))
import backtrader.stores.btapistore as module
assert Path(module.__file__).resolve() == (root / 'backtrader/stores/btapistore.py').resolve(), module.__file__
assert not blocked, blocked
assert not any(x == 'bt_api_py' or x.startswith('bt_api_py.') or x == '_ctp' or x.startswith('_ctp.') for x in sys.modules)
print('module_file=' + str(Path(module.__file__).resolve()))
print('expected_file=' + str((root / 'backtrader/stores/btapistore.py').resolve()))
print('blocked_sdk_import_attempts=' + repr(blocked))
print('native_sdk_modules_loaded=0')
