import hashlib, json, shutil, subprocess
from pathlib import Path

source_root=Path(r"D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r2b")
author=Path(r"D:\temp\iteration41-r2b-i22-stable-runtime-id-migration-20260927")
main=Path(r"D:\source_code\backtrader")
out=Path(r"D:\temp\iteration41-r2b-i22-stable-runtime-id-migration-independent-qa-20260927")
replay=out/"replay"
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
shutil.copytree(source_root/"backtrader",replay/"backtrader",
                ignore=shutil.ignore_patterns("__pycache__",".pytest_cache"))
shutil.copytree(author/"tests",replay/"tests",
                ignore=shutil.ignore_patterns("__pycache__",".pytest_cache"))
shutil.copy2(main/"pytest.ini",replay/"pytest.ini")
test=replay/"tests"/"unit"/"stores"/"test_btapistore_iteration22.py"
shutil.copy2(main/"tests"/"unit"/"stores"/"test_btapistore_iteration22.py",test)
baseline_hash=sha(test)
if baseline_hash!="30EEAA2C9816E6D0792E801A6EA2A8960CC1BCAA3728679111318E5178AFA49D":
    raise AssertionError(f"unexpected baseline I22 test hash {baseline_hash}")
base_store_hash=sha(replay/"backtrader"/"stores"/"btapistore.py")
if base_store_hash!="24F8199E199BBE84BBB113C3EDBBEE9E71D4736FDD8573297E24EAD3298F2518":
    raise AssertionError(f"unexpected r2b base Store hash {base_store_hash}")
patch=author/"i22-stable-runtime-id-migration.patch"
if sha(patch)!="7CAB249E4943EF867BC683803BDDBF60AC1F2DC8AAE5B9EE34DBAF3E7751DF36":
    raise AssertionError("author patch SHA mismatch")
for args in (["--check"],[]):
    subprocess.run(["git","-c","core.autocrlf=false","-C",str(replay),"apply",*args,str(patch)],check=True)
after_store=sha(replay/"backtrader"/"stores"/"btapistore.py")
after_test=sha(test)
expected_store="75E6292E53F5FB8F70194114BDD5544D8FEB00FAAC9AA543A620C480F5AC7AD5"
expected_test="64337E4FA3552121D4E3D85FDEF828B57E2F671057CD4B6AC387EC0E63E3D655"
if (after_store,after_test)!=(expected_store,expected_test):
    raise AssertionError(f"replay output differs: {(after_store,after_test)}")
evidence=replay/"evidence"
evidence.mkdir()
shutil.copy2(author/"evidence"/"run_candidate_guarded.py",evidence/"run_candidate_guarded.py")
result={"replay_root":str(replay),"r2b_base_store_sha256":base_store_hash,
 "baseline_i22_test_sha256":baseline_hash,"migration_patch_sha256":sha(patch),
 "replayed_store_sha256":after_store,"replayed_test_sha256":after_test,
 "matches_author_snapshot":True,"patch_check_and_apply":"PASS"}
(out/"replay-result.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result,indent=2))
