#!/usr/bin/env python
"""Heikin Ashi Filter Module - Heikin Ashi candlestick filter.

This module provides the HeikinAshi filter for remodeling price
data into Heikin Ashi candlesticks.

Classes:
    HeikinAshi: Creates Heikin Ashi candlesticks.

Example:
    >>> data = bt.feeds.GenericCSVData(dataname='data.csv')
    >>> data.addfilter(bt.filters.HeikinAshi())
    >>> cerebro.adddata(data)
"""

__all__ = ["HeikinAshi"]


class HeikinAshi:
    """
    The filter remodels the open, high, low, close to make HeikinAshi
    candlesticks

    See:
      - https://en.wikipedia.org/wiki/Candlestick_chart#Heikin_Ashi_candlesticks
      - http://stockcharts.com/school/doku.php?id=chart_school:chart_analysis:heikin_ashi

    """

    def __init__(self, data):
        """Initialize the HeikinAshi filter.

        Args:
            data: The data feed to apply the filter to.
                  No specific parameters are required.
        """

    def __call__(self, data):
        """Convert standard OHLC data to Heikin Ashi candlesticks.

        This method transforms the OHLC data into Heikin Ashi format, which
        uses the average of open, high, low, and close for the close price,
        and averages the previous close and open for the current open price.

        Args:
            data: The data feed containing OHLC values to convert.

        Returns:
            bool: False (the length of data stream is unaltered).
        """
        o, h, low, c = data.open[0], data.high[0], data.low[0], data.close[0]

        data.close[0] = ha_close0 = (o + h + low + c) / 4.0

        if len(data) > 1:
            data.open[0] = ha_open0 = (data.open[-1] + data.close[-1]) / 2.0
            data.high[0] = max(ha_open0, ha_close0, h)
            data.low[0] = min(ha_open0, ha_close0, low)

        else:  # len is 1, no lookback is possible
            data.open[0] = ha_open0 = (o + c) / 2.0

        return False  # length of data stream is unaltered
