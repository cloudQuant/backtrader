import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
files=[
'receipt.md','prepare_replay.py','prepare-replay.log','replay-result.json','focused-run.log','legacy-semantics-probe.log','missing-runtime-id-side-effects-probe.log','module-origin.log',
'inputs/i22-stable-runtime-id-migration.patch','inputs/candidate-SHA256SUMS.txt','inputs/candidate-report.md',
'replay/backtrader/stores/btapistore.py','replay/tests/unit/stores/test_btapistore_iteration22.py','replay/tests/unit/stores/test_i22_legacy_semantics_probe.py','replay/tests/unit/stores/test_i22_missing_runtime_id_side_effects_probe.py',
'replay/evidence/run_candidate_guarded.py','replay/evidence/run_legacy_semantics_probe.py','replay/evidence/run_missing_runtime_id_side_effects_probe.py','replay/evidence/verify_origin.py',
'replay/evidence/candidate-i22-stable-runtime-id.junit.xml','replay/evidence/qa-legacy-semantics-probe.junit.xml','replay/evidence/qa-missing-runtime-id-side-effects.junit.xml'
]
entries=[]
for rel in files:
    p=root/rel; b=p.read_bytes(); entries.append({'path':rel.replace('\\','/'),'size':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()})
manifest={
 'title':'Independent QA receipt: I22 stable runtime-ID migration',
 'verdict':'PARTIAL / NEEDS_REVISION',
 'candidate_root':r'D:\temp\iteration41-r2b-i22-stable-runtime-id-migration-20260927',
 'candidate_index_sha256':'008D84C4AF60145460B771A1DC76D2FEA795841A71C7CC1163F1438F5CD803BD',
 'candidate_patch_sha256':'7CAB249E4943EF867BC683803BDDBF60AC1F2DC8AAE5B9EE34DBAF3E7751DF36',
 'base_store_sha256':'24F8199E199BBE84BBB113C3EDBBEE9E71D4736FDD8573297E24EAD3298F2518',
 'baseline_test_sha256':'30EEAA2C9816E6D0792E801A6EA2A8960CC1BCAA3728679111318E5178AFA49D',
 'candidate_store_sha256':'75E6292E53F5FB8F70194114BDD5544D8FEB00FAAC9AA543A620C480F5AC7AD5',
 'candidate_test_sha256':'64337E4FA3552121D4E3D85FDEF828B57E2F671057CD4B6AC387EC0E63E3D655',
 'candidate_focus':{'passed':1,'failed':0,'warnings':1,'sdk_import_attempts':0,'network_attempts':0,'native_sdk_modules_loaded':0},
 'qa_actual_method_probe':{'passed':1,'failed':0,'asserts':['durable binding lookup count is zero','reservation count is zero','framework_order.info remains empty']},
 'baseline_test_replay':{'result':'fixture setup failed before semantic assertions','reason':'new Store constructor rejects with external account actor unavailable'},
 'semantic_coverage_finding':'Candidate replacement retains pure ID-shape validation but removes the actual _sdk_order_request no-lookup/no-reservation/no-framework-mutation assertions. Independent fake actual-method probe passes against candidate source; candidate test itself does not retain the regression coverage.',
 'artifacts':entries
}
out=root/'qa-manifest.json'; out.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(out)
print(hashlib.sha256(out.read_bytes()).hexdigest().upper())
