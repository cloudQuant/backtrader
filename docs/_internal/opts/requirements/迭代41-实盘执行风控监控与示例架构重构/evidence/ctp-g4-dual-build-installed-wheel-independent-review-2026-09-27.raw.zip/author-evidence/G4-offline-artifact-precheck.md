# G4 offline native artifact precheck — 2026-09-27

## Scope

Offline source/build/import verification only for SDK commit `9976bcbbbe331ee77e2d90e05da08472259a625a`. No configuration or credentials were read; no native API object was constructed; no `Req*`, front connection, login, provider, or network operation was performed. This does not accept native Join/Release or close behavior.

## Clean sources

Detached worktrees:

- `D:\temp\g4-ctp-9976-build-a`
- `D:\temp\g4-ctp-9976-build-b`

Both report HEAD `9976bcbbbe331ee77e2d90e05da08472259a625a`, `git status --short --untracked-files=all` empty, and `core.autocrlf=true`. The audited source inputs have identical bytes across both worktrees and CRLF-only checkout line endings (zero bare LF/CR): `setup.py` SHA256 `5028884daae7d977882b7dcbf0782fa8d0de843f9c4bbd98527cd502497d86e7`; `pyproject.toml` `6295d10501ce71fd3aafcc2be2d2b28274bb82d6ca0e94230757d972976669a5`; `src/bt_api_ctp/ctp/ctp_wrap.cpp` `5b985c12976a406ae3ebe0084693cace584615b69cd4f2d48af57ff5995a031b`; pinned `ThostFtdcTraderApi.h` `e52c2cb7a8c17571d47848ea0a946679f9c2e12b5c9f4057188707a15d1546b0`.

The source package pins CTP API 6.7.7. Relevant native binaries: MD DLL `72a833786836ce6e6026bc0c19a06bd3c1b0279cb1ea9df0297b1c2916cad98b`; Trader DLL `d79cc036fc90733a30cee8e8e30bdea17b346333c69413f33d44ebc7a96b1fad`; SWIG-generated wrapper SHA above.

## Build result

The independent wheels are at:

- `D:\temp\g4-ctp-9976-output-a\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl`
- `D:\temp\g4-ctp-9976-output-b\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl`

Both are 5,553,848 bytes, SHA256 `36e82015c96d11caa9b2c8eb0c1903ac3f4f36405bab5fed46d9a20d2b6fe5da`, and have 86 identical zip members with byte-identical contents. Build B log: `D:\temp\g4-ctp-9976-logs\build-b.log`. Wheel member comparison: `D:\temp\g4-ctp-9976-logs\build-comparison.json`.

Build inputs/toolchain: Python 3.11.5 x64; VS 2022 Community 17.12.3; MSVC tools 14.42.34433 / compiler 19.42.34435 / linker 14.42.34435; Windows SDK 10.0.26100.0. `cl.exe` SHA256 `3e761c082f491950ed5565f198f2113a8043897ce4d8084e37de8e0fee43202a`; `link.exe` `f627ee8b9983af24d4b5ab6efab25f4a3be7a02bb09253aa2f5abab3c1fb2c6b`; `dumpbin.exe` `374dd98765368a4d7f7962565e2063b8232a60ae43b729b8cd79cfb79210579b`. Builds used `--no-index --no-deps --no-build-isolation`, `SOURCE_DATE_EPOCH=1790362300`, `PYTHONHASHSEED=0`, `CL=/Brepro`, `LINK=/Brepro`; committed generated `ctp_wrap.cpp` was compiled directly (installed SWIG version is not a build input).

## VS bootstrap diagnostic

The exact recurring bootstrap lines are:

```
[ERROR:VsDevCmd.bat] Script "vsdevcmd\ext\Failed" could not be found.
[ERROR:VsDevCmd.bat] *** VsDevCmd.bat encountered errors. Environment may be incomplete and/or incorrect. ***
```

`vsenv-debug.log` shows `vswhere` first emitted `Failed to create temp directory "C:\Users\yunji\AppData\Local\Temp\conda-<RANDOM>\"`, then found VS 17.12.3. The wrapper returned `CALL_EXIT=0`; core and extension initialization (including `ext\vcvars.bat`) completed; `VCINSTALLDIR`, `VCToolsVersion`, `WindowsSDKVersion`, compiler and linker were set. Build B log contains actual `cl.exe` and `link.exe` invocations and ends `Successfully built bt_api_ctp`. Independent output identity and compiler-version evidence support that the required compilation environment was present for this artifact. The malformed VS bootstrap status remains an environment trust limitation; do not describe the shell initialization as clean or infer general VS health from this build.

## Fresh isolated consumer

Installed wheel A with `--no-index --no-deps` into no-system venv `D:\temp\g4-ctp-9976-venv-a`; ran `python -I offline_native_audit.py`. Result saved at `D:\temp\g4-ctp-9976-logs\installed-audit.json`.

- 166 RECORD entries; all 88 entries with hashes verified.
- All 85 non-RECORD wheel payload files byte-equal to installed bytes.
- `_ctp.cp311-win_amd64.pyd` imported from that venv, SHA256 `78630bad60cbae8961bb42e786f0fbf8c8be39bec61379228d6bb8667754c84f`.
- Static Trader and MD API version functions both returned `v6.7.7_20240607 15:51:36.7347`.
- Windows loader paths for both CTP DLLs exactly matched the installed wheel package files and their hashes matched the vendored 6.7.7 DLLs above.
- High-level client module was not imported; API call list is empty.
- `pip check` reports only that `bt-api-base` is absent. This is expected from a deliberate no-dependency offline artifact install; it is not a complete SDK integration consumer.

Commands/results are in `D:\temp\g4-ctp-9976-logs\pip-check.txt` and the audit JSON. The consumer verifies binary identity/import only; it does not exercise native construction, Join, Release, or provider lifecycle.

### Complete offline dependency closure

After the initial artifact-only `pip check` correctly reported the missing `bt-api-base`, the exact accepted base wheel was found and installed into the same no-system consumer: `D:\temp\iteration41-capability-artifacts-20260926\wheels\base-a\bt_api_base-0.15.4-py3-none-any.whl`, SHA256 `cfe3507e1324f675454c41c37cd09ff72c8947c5254e9496e97c373cb8f3b369`. Its pinned dependencies were installed offline from `D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse`; no SDK wheel rebuild occurred. `pip check` now reports `No broken requirements found` (exit 0), saved to `D:\temp\g4-ctp-9976-logs\pip-check-with-base-deps.txt`. Final import/RECORD/DLL audit after base install remains successful; see `D:\temp\g4-ctp-9976-logs\installed-audit-final.json`.
