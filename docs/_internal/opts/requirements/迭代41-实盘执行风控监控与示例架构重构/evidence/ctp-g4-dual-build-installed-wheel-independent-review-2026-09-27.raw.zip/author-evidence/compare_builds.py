from pathlib import Path
import hashlib, json, zipfile
wa=Path(r'D:\temp\g4-ctp-9976-output-a\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl')
wb=Path(r'D:\temp\g4-ctp-9976-output-b\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl')
files=['setup.py','pyproject.toml','src/bt_api_ctp/ctp/ctp_wrap.cpp','src/bt_api_ctp/ctp/api/6.7.7/windows/ThostFtdcTraderApi.h']
roots=[Path(r'D:\temp\g4-ctp-9976-build-a'),Path(r'D:\temp\g4-ctp-9976-build-b')]
source={}
for f in files:
    vals=[]
    for root in roots:
        b=(root/f).read_bytes()
        vals.append({'root':str(root),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'crlf':b.count(b'\r\n'),'bare_lf':b.count(b'\n')-b.count(b'\r\n'),'bare_cr':b.count(b'\r')-b.count(b'\r\n')})
    assert vals[0]['sha256']==vals[1]['sha256']
    source[f]=vals
with zipfile.ZipFile(wa) as a, zipfile.ZipFile(wb) as b:
    na=sorted(a.namelist()); nb=sorted(b.namelist())
    assert na==nb
    diffs=[n for n in na if a.read(n)!=b.read(n)]
    assert not diffs, diffs
result={'wheel_a_sha256':hashlib.sha256(wa.read_bytes()).hexdigest(),'wheel_b_sha256':hashlib.sha256(wb.read_bytes()).hexdigest(),'wheel_a_size':wa.stat().st_size,'wheel_b_size':wb.stat().st_size,'member_count':len(na),'member_bytes_identical':True,'source':source}
print(json.dumps(result,indent=2))
