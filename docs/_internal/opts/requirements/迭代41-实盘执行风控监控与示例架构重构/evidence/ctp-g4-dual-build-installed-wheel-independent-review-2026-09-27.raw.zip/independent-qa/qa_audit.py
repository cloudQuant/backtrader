from __future__ import annotations
import base64, csv, hashlib, importlib.metadata as md, importlib.machinery, importlib.util, json, os, platform, subprocess, sys, sysconfig, zipfile
from pathlib import Path, PurePosixPath

A = Path(r'D:\temp\g4-ctp-9976-output-a\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl')
B = Path(r'D:\temp\g4-ctp-9976-output-b\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl')
ROOTS = [Path(r'D:\temp\g4-ctp-9976-build-a'), Path(r'D:\temp\g4-ctp-9976-build-b')]
EXPECTED = '9976bcbbbe331ee77e2d90e05da08472259a625a'

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def source_audit():
    roots=[]
    files=['setup.py','pyproject.toml','src/bt_api_ctp/ctp/ctp_wrap.cpp','src/bt_api_ctp/ctp/api/6.7.7/windows/ThostFtdcTraderApi.h','src/bt_api_ctp/ctp/thostmduserapi_se.dll','src/bt_api_ctp/ctp/thosttraderapi_se.dll']
    for root in ROOTS:
        head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
        status=subprocess.check_output(['git','-C',str(root),'status','--porcelain=v1','--untracked-files=all'],text=True)
        autocrlf=subprocess.check_output(['git','-C',str(root),'config','--get','core.autocrlf'],text=True).strip()
        items={}
        for rel in files:
            p=root/rel
            b=p.read_bytes()
            items[rel]={'sha256':sha(p),'bytes':len(b),'exists':True}
            if rel.endswith(('.cpp','.h','.py','.toml')):
                items[rel]['crlf_count']=b.count(b'\r\n')
                items[rel]['bare_lf_count']=b.count(b'\n')-b.count(b'\r\n')
                items[rel]['bare_cr_count']=b.count(b'\r')-b.count(b'\r\n')
        roots.append({'root':str(root),'head':head,'status_porcelain':status,'clean':not status,'core_autocrlf':autocrlf,'files':items})
    with zipfile.ZipFile(A) as za, zipfile.ZipFile(B) as zb:
        names_a=sorted(za.namelist()); names_b=sorted(zb.namelist())
        equal_members=names_a==names_b and all(za.read(n)==zb.read(n) for n in names_a)
        member_count=len(names_a)
    return {'expected_head':EXPECTED,'roots':roots,'all_roots_at_expected_head':all(x['head']==EXPECTED for x in roots),'all_worktrees_clean':all(x['clean'] for x in roots),'same_audited_source_hashes':all(roots[0]['files'][k]['sha256']==roots[1]['files'][k]['sha256'] for k in roots[0]['files']),'wheels':{'A':{'path':str(A),'size':A.stat().st_size,'sha256':sha(A)},'B':{'path':str(B),'size':B.stat().st_size,'sha256':sha(B)},'member_count':member_count,'member_names_and_contents_equal':equal_members}}

def installed_audit(wheel: Path):
    dist=md.distribution('bt-api-ctp')
    site=Path(next(p for p in sys.path if p.endswith('site-packages'))).resolve()
    venv=Path(sys.prefix).resolve()
    spec=importlib.util.find_spec('bt_api_ctp')
    record=dist.read_text('RECORD')
    rows=list(csv.reader(record.splitlines()))
    record_hashes=0; record_unhashed=[]; bad=[]
    for row in rows:
        name,hash_field,size_field=row
        target=Path(dist.locate_file(PurePosixPath(name)))
        if not target.exists():
            bad.append({'path':name,'error':'missing'})
            continue
        if size_field and target.stat().st_size!=int(size_field):
            bad.append({'path':name,'error':'size mismatch'})
        if hash_field:
            algorithm, encoded=hash_field.split('=',1)
            digest=hashlib.new(algorithm,target.read_bytes()).digest()
            actual=base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
            if actual!=encoded: bad.append({'path':name,'error':'hash mismatch'})
            else: record_hashes+=1
        else:
            record_unhashed.append(name)
    with zipfile.ZipFile(wheel) as z:
        wheel_names=sorted(z.namelist())
        payload=[]; mismatch=[]
        for name in wheel_names:
            if name.endswith('.dist-info/RECORD'):
                continue
            payload.append(name)
            target=Path(dist.locate_file(PurePosixPath(name)))
            if not target.is_file() or target.read_bytes()!=z.read(name): mismatch.append(name)
    ext_rel=next(n for n in wheel_names if n.startswith('bt_api_ctp/ctp/_ctp') and n.endswith('.pyd'))
    extension=Path(dist.locate_file(PurePosixPath(ext_rel))).resolve()
    import ctypes
    import ctypes.wintypes as wt
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetModuleHandleW.argtypes=[wt.LPCWSTR]; kernel.GetModuleHandleW.restype=wt.HMODULE
    kernel.GetModuleFileNameW.argtypes=[wt.HMODULE,wt.LPWSTR,wt.DWORD]; kernel.GetModuleFileNameW.restype=wt.DWORD
    def loaded_path(name):
        handle=kernel.GetModuleHandleW(name)
        if not handle: return None
        buf=ctypes.create_unicode_buffer(32768)
        n=kernel.GetModuleFileNameW(handle,buf,len(buf))
        if not n: return None
        return str(Path(buf.value).resolve())
    # Import the installed native module by its exact site-packages path. This loads
    # the extension and dependent DLLs only; no CTP API function or API object is called.
    dll_cookie=os.add_dll_directory(str(extension.parent))
    try:
        native_spec=importlib.util.spec_from_file_location('_ctp',str(extension))
        native=importlib.util.module_from_spec(native_spec)
        native_spec.loader.exec_module(native)
    finally:
        dll_cookie.close()
    mapped={}
    for dll in ('thostmduserapi_se.dll','thosttraderapi_se.dll'):
        path=loaded_path(dll)
        mapped[dll]={'path':path,'sha256':sha(Path(path)) if path else None}
    return {'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'sys_prefix':str(venv),'base_prefix':sys.base_prefix,'site_packages':str(site),'system_site_packages_visible':any('site-packages' in p.lower() and not str(Path(p).resolve()).startswith(str(venv)) for p in sys.path if p),'distribution':{'name':dist.metadata['Name'],'version':dist.version,'root':str(Path(dist.locate_file('')).resolve()),'package_spec_origin':spec.origin if spec else None},'wheel_path':str(wheel),'wheel_sha256':sha(wheel),'installed_record_entries':len(rows),'record_hashed_entries_verified':record_hashes,'record_unhashed_entries':record_unhashed,'record_errors':bad,'wheel_payload_entries':len(payload),'wheel_payload_install_mismatches':mismatch,'extension_path':str(extension),'extension_sha256':sha(extension),'native_module_loaded_path':str(Path(native.__file__).resolve()),'mapped_vendor_dlls':mapped,'ctp_api_calls_invoked':[],'api_objects_constructed':False,'high_level_client_imported':False,'py_debug_config':sysconfig.get_config_var('Py_DEBUG'),'has_totalrefcount':hasattr(sys,'gettotalrefcount'),'supported_tags_contains_wheel_tag':None}

mode=sys.argv[1]
if mode=='source': out=source_audit()
elif mode=='installed': out=installed_audit(Path(sys.argv[2]))
else: raise SystemExit('mode must be source or installed')
print(json.dumps(out,indent=2,sort_keys=True))
