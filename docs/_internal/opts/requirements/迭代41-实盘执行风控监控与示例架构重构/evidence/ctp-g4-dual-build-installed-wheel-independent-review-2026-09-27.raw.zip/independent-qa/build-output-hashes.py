from pathlib import Path
import hashlib,json
roots=[Path(r'D:\temp\g4-ctp-9976-build-a'),Path(r'D:\temp\g4-ctp-9976-build-b')]
out=[]
for r in roots:
 p=r/'build/lib.win-amd64-3.11/bt_api_ctp/ctp/_ctp.cp311-win_amd64.pyd'
 objs=list((r/'build/temp.win-amd64-3.11').rglob('ctp_wrap.obj'))
 out.append({'root':str(r),'pyd':str(p),'pyd_size':p.stat().st_size,'pyd_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'objs':[{'path':str(o),'size':o.stat().st_size,'sha256':hashlib.sha256(o.read_bytes()).hexdigest()} for o in objs]})
print(json.dumps(out,indent=2))
