import json
import os
import sys
import time
from pathlib import Path

repo_root = Path(r"D:\source_code\backtrader")
sys.path.insert(0, str(repo_root))
from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand, run_outer_watchdog
from scripts.ctp_i13_i15_windows_job_backend import WindowsJobBackend

root = Path(sys.argv[1]).resolve()
child = root / "blocked_call_child.py"
python = Path(sys.executable)
env = {
    "SystemRoot": os.environ.get("SystemRoot", r"C:\Windows"),
    "WINDIR": os.environ.get("WINDIR", r"C:\Windows"),
    "TEMP": os.environ.get("TEMP", r"C:\Windows\Temp"),
    "TMP": os.environ.get("TMP", r"C:\Windows\Temp"),
    "PATH": r"C:\Windows\System32",
}
expected_markers = {
    "register": "blocked_in_register_spi",
    "release": "blocked_in_release",
}
results = []
for mode, expected_marker in expected_markers.items():
    marker = root / f"{mode}.entered"
    now = time.monotonic()
    command = FixedOuterCommand(
        [str(python), "-B", "-I", str(child), mode, str(marker)],
        str(root),
        env,
    )
    result = run_outer_watchdog(
        command,
        backend=WindowsJobBackend(no_inherited_handles=True),
        deadline_monotonic=now + 6.0,
        stop_deadline_monotonic=now + 1.5,
        poll_interval_seconds=0.02,
    )
    row = {
        "scenario": mode,
        "marker": marker.read_text(encoding="ascii") if marker.exists() else None,
        "state": result.state,
        "reason": result.reason,
        "process_created": result.evidence.process_created,
        "job_assignment_observed": result.evidence.job_assignment_observed,
        "launcher_resumed": result.evidence.launcher_resumed,
        "launcher_exit_observed": result.evidence.launcher_exit_observed,
        "launcher_exit_code": result.evidence.launcher_exit_code,
        "job_termination_requested": result.evidence.job_termination_requested,
        "job_termination_call_succeeded": result.evidence.job_termination_call_succeeded,
        "job_empty_observed": result.evidence.job_empty_observed,
        "containment": result.evidence.containment,
        "controls_retained": result.evidence.controls_retained,
    }
    results.append(row)
    required = (
        row["marker"] == expected_marker
        and row["state"] == "timed_out"
        and row["reason"] == "outer_worker_deadline_exceeded"
        and row["process_created"] is True
        and row["job_assignment_observed"] is True
        and row["launcher_resumed"] is True
        and row["launcher_exit_observed"] is True
        and row["launcher_exit_code"] == 0xEE13
        and row["job_termination_requested"] is True
        and row["job_termination_call_succeeded"] is True
        and row["job_empty_observed"] is True
        and row["containment"] == "verified"
        and row["controls_retained"] is False
    )
    if not required:
        raise SystemExit(f"containment assertion failed: {row}")
(root / "job_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
print(json.dumps(results, indent=2))