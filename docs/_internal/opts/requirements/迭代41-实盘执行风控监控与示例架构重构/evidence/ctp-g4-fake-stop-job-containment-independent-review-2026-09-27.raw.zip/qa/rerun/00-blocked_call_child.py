import sys
import threading
from pathlib import Path

scenario, marker_path = sys.argv[1:]
expected = {
    "register": "blocked_in_register_spi",
    "release": "blocked_in_release",
}
if scenario not in expected:
    raise SystemExit(3)
Path(marker_path).write_text(expected[scenario], encoding="ascii")
threading.Event().wait()