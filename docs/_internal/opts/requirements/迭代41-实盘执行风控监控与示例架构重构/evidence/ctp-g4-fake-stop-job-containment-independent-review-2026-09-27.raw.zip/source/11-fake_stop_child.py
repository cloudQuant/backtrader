import sys
import threading
from pathlib import Path

scenario, marker_path, sdk_src = sys.argv[1:]
sys.path.insert(0, sdk_src)
from bt_api_ctp.ctp.client import MdClient

marker = Path(marker_path)
class FakeApi:
    def RegisterSpi(self, spi):
        if scenario == "register" and spi is None:
            marker.write_text("blocked_in_register_spi", encoding="ascii")
            threading.Event().wait()
    def Release(self):
        if scenario == "release":
            marker.write_text("blocked_in_release", encoding="ascii")
            threading.Event().wait()

api = FakeApi()
client = MdClient("tcp://unused", "unused", "unused", "unused")
client._api = api
client._spi = object()
if scenario == "register":
    client._native_init_started = True
    client._join_active = True
elif scenario != "release":
    raise SystemExit(3)
client.stop_and_wait(timeout=0.01)
raise SystemExit(4)
