import json
import os
import sys
import time
from pathlib import Path

repo_root = Path(r"D:\source_code\backtrader")
sys.path.insert(0, str(repo_root))
from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand, run_outer_watchdog
from scripts.ctp_i13_i15_windows_job_backend import WindowsJobBackend

root = Path(sys.argv[1])
child = root / "fake_stop_child.py"
sdk_src = Path(r"D:\q\g4-md-id-zero-e75\src")
python = Path(sys.executable)
env = {
    "SystemRoot": os.environ.get("SystemRoot", r"C:\Windows"),
    "WINDIR": os.environ.get("WINDIR", r"C:\Windows"),
    "TEMP": os.environ.get("TEMP", r"C:\Windows\Temp"),
    "TMP": os.environ.get("TMP", r"C:\Windows\Temp"),
    "PATH": os.environ.get("PATH", r"C:\Windows\System32"),
}
results = []
for mode in ("register", "release"):
    marker = root / f"{mode}.entered"
    try:
        marker.unlink()
    except FileNotFoundError:
        pass
    now = time.monotonic()
    deadline = now + 6.0
    command = FixedOuterCommand(
        [str(python), "-B", "-I", str(child), mode, str(marker), str(sdk_src)],
        str(root),
        env,
    )
    result = run_outer_watchdog(
        command,
        backend=WindowsJobBackend(no_inherited_handles=True),
        deadline_monotonic=deadline,
        stop_deadline_monotonic=now + 1.5,
        poll_interval_seconds=0.02,
    )
    results.append({
        "scenario": mode,
        "marker": marker.read_text(encoding="ascii") if marker.exists() else None,
        "state": result.state,
        "reason": result.reason,
        "process_created": result.evidence.process_created,
        "job_assignment_observed": result.evidence.job_assignment_observed,
        "launcher_resumed": result.evidence.launcher_resumed,
        "launcher_exit_observed": result.evidence.launcher_exit_observed,
        "launcher_exit_code": result.evidence.launcher_exit_code,
        "job_termination_requested": result.evidence.job_termination_requested,
        "job_termination_call_succeeded": result.evidence.job_termination_call_succeeded,
        "job_empty_observed": result.evidence.job_empty_observed,
        "containment": result.evidence.containment,
        "controls_retained": result.evidence.controls_retained,
    })
(root / "job_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
print(json.dumps(results, indent=2))
