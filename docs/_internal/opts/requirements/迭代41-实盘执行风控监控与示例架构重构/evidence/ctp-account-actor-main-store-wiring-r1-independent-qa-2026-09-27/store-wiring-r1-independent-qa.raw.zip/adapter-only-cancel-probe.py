from __future__ import annotations
import sys
from pathlib import Path
from types import SimpleNamespace

candidate = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-r1-independent-qa-20260927\candidate-copy')
sys.path.insert(0, str(candidate))
from backtrader.stores.btapistore import BtApiStore, BtApiStoreError

class ApiTrap:
    def __init__(self): self.reads=[]
    def __getattr__(self, name):
        self.reads.append(name)
        raise AssertionError('API read: '+name)

class Adapter:
    def __init__(self): self.cancel_calls=0; self.local_dispatch_calls=0
    def submit_order(self, order, legacy_dispatch): return {'status':'projected'}
    def cancel_order(self, order_or_ref, dataname, legacy_dispatch):
        self.cancel_calls += 1
        return legacy_dispatch(order_or_ref)

api=ApiTrap(); adapter=Adapter()
store=BtApiStore(provider='btapi', api=api, managed_execution_adapter=adapter)
try:
    store.cancel_order(SimpleNamespace(ref=41))
except BtApiStoreError as exc:
    assert 'forbids local legacy dispatch' in str(exc), str(exc)
else:
    raise AssertionError('adapter closure unexpectedly dispatched locally')
assert adapter.cancel_calls == 1
assert api.reads == []

api2=ApiTrap(); adapter2=Adapter()
store2=BtApiStore(provider='btapi', api=api2, managed_execution_adapter=adapter2)
store2._config['exchange_type']='CTP'
try:
    store2.cancel_order(SimpleNamespace(ref=42))
except BtApiStoreError as exc:
    assert 'changed or became routable' in str(exc), str(exc)
else:
    raise AssertionError('mutated CTP route unexpectedly reached adapter')
assert adapter2.cancel_calls == 0
assert api2.reads == []
print('PASS cancel closure rejects local fallback; mutation-to-CTP is rejected before adapter invocation; API trap reads=0')
