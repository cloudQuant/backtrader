from pathlib import Path
import hashlib, json, shutil, zipfile

qa = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-r1-independent-qa-20260927')
author = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r1')
candidate = qa / 'candidate-copy'
canonical = Path(r'D:\source_code\backtrader\docs\_internal\opts\requirements\迭代41-实盘执行风控监控与示例架构重构\evidence\ctp-account-actor-main-store-wiring-r1-independent-qa-2026-09-27')

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest().upper()

def relfiles(paths):
    return {label: sha(path) for label,path in paths}

payloads = [
 ('freeze_r1_qa.py', qa/'freeze_r1_qa.py'),
 ('freeze-verification.json', qa/'freeze-verification.json'),
 ('patch-replay.log', qa/'patch-replay.log'),
 ('focus-14.log', qa/'focus-14.log'),
 ('focus-21.log', qa/'focus-21.log'),
 ('legacy-30-candidate.log', qa/'legacy-30-candidate.log'),
 ('legacy-30-exact-base.log', qa/'legacy-30-exact-base.log'),
 ('api-cls-positive-probe.log', qa/'api-cls-positive-probe.log'),
 ('adapter-only-cancel-probe.log', qa/'adapter-only-cancel-probe.log'),
 ('verify_copy_r1.py', qa/'verify_copy_r1.py'),
 ('make_base_copy.py', qa/'make_base_copy.py'),
 ('api-cls-positive-probe.py', qa/'api-cls-positive-probe.py'),
 ('adapter-only-cancel-probe.py', qa/'adapter-only-cancel-probe.py'),
 ('input/candidate-manifest.json', author/'evidence'/'candidate-manifest.json'),
 ('input/r1-apply.patch', author/'evidence'/'r1-apply.patch'),
 ('input/author-qa-report.md', author/'evidence'/'qa-report.md'),
 ('input/legacy-ctp-compatibility-exclusions.txt', author/'evidence'/'r1-legacy-ctp-compatibility-exclusions.txt'),
 ('candidate/backtrader/stores/btapistore.py', candidate/'backtrader'/'stores'/'btapistore.py'),
 ('base/backtrader/stores/btapistore.py', candidate/'input-sources'/'btapistore.py'),
 ('candidate/backtrader/stores/ctp_account_actor_port.py', candidate/'backtrader'/'stores'/'ctp_account_actor_port.py'),
 ('candidate/tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py', candidate/'tests'/'unit'/'stores'/'test_ctp_account_actor_store_wiring_candidate.py'),
 ('candidate/tests/unit/stores/test_managed_ctp_store_adapter.py', candidate/'tests'/'unit'/'stores'/'test_managed_ctp_store_adapter.py'),
]
missing=[str(p) for _,p in payloads if not p.is_file()]
if missing: raise SystemExit('missing archive payloads: '+repr(missing))

source_hashes = {
 'candidate_store': sha(candidate/'backtrader'/'stores'/'btapistore.py'),
 'base_store': sha(candidate/'input-sources'/'btapistore.py'),
 'actor_port': sha(candidate/'backtrader'/'stores'/'ctp_account_actor_port.py'),
 'focus_test': sha(candidate/'tests'/'unit'/'stores'/'test_ctp_account_actor_store_wiring_candidate.py'),
 'legacy_test': sha(candidate/'tests'/'unit'/'stores'/'test_managed_ctp_store_adapter.py'),
 'patch': sha(author/'evidence'/'r1-apply.patch'),
 'candidate_manifest': sha(author/'evidence'/'candidate-manifest.json'),
}
expected = {
 'candidate_store':'A25EDC57D4A4AC225B1B152A2672FF2B108B3C497CEF05CD46A8FB22C1E586B8',
 'actor_port':'19F5935BC6AABCDE178F60F62619757B01FA51B99FF5389120A8404E00E70372',
 'patch':'B164D083AA4D4BD3A6DC325582C4EE82E0042945360C98A63CA3EC9212ABCC58',
 'candidate_manifest':'ADA5018781A7417206B88E3D934D59A67A77BEAB0C5E09E002A0E8F89A16ADE4',
}
for key, want in expected.items():
    if source_hashes[key] != want: raise SystemExit(f'{key} mismatch: {source_hashes[key]} != {want}')

report = '''# Store wiring r1 — independent QA (2026-09-27)

## Scope and disposition

Independent read-only review of the frozen author candidate at `D:\\temp\\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r1`. The frozen manifest SHA-256 is `ada5018781a7417206b88e3d934d59a67a77beab0c5e09e002a0e8f89a16ade4`; all 629 manifested files (9,932,064 bytes) matched in the isolated QA copy. No production source, main worktree, provider, credentials, SDK, network, or CTP route was used.

**Disposition: candidate-only / no-write plumbing; not accepted as production/account authority.** Exact-base patch replay reproduced the candidate's three changed outputs byte-for-byte. New route/actor focus passed 14/14, and its managed-execution + live guard focus passed 21/21. The exact same legacy Store set is 30/30 on the base but only 9/30 on r1; all 21 candidate failures are the old CTP-local-SDK constructor tests stopping at the intended fail-closed `external_account_actor_unavailable` gate. This is a real compatibility exclusion, not a test-runner failure.

## Independent probes

- An explicit known `OKX` constructor with injected `api_cls` remains compatible: the fake class was constructed and connected once; SDK/native modules stayed absent. Unknown / CTP constructors with property traps were rejected without reading API properties.
- A `BT_STORE_PROVIDER=ib_web_gateway` environment rewrite plus forwarding/CTP route, API `__getattr__` trap, credential `str`/truthiness traps, and autostart rejected before provider/environment override helpers, SDK resolution, credential access, or API access.
- Nested CTP and gateway/forwarding route cases are covered by the 14/21 focus. The adapter-only `btapi` route stays ambiguous; projection-only access remains inert. Its legacy dispatch closure rejects; mutation to CTP is rejected before adapter/API calls (reads=0, calls=0).
- Scope caveat: the injected adapter is caller-supplied code. Its own projection callback can execute arbitrary caller code; these probes show the candidate does not classify it as authenticated NON_CTP or dispatch the local CTP SDK through that closure. They do not sandbox an adapter or prove that arbitrary external side effects are impossible.
- The local actor replay receipt remains fake/local evidence. It does not provide cross-process replay authority, identity, provider acknowledgement, or admission.

## Test and patch evidence

| Check | Result |
|---|---:|
| Frozen payload verification | 629 / 629 files, 9,932,064 bytes |
| Exact-base canonical patch replay | all 3 outputs byte-exact |
| Candidate focused boundary/live guard | 14 passed, 1 existing Quandl deprecation warning |
| Candidate boundary + managed adapter + guard | 21 passed, 1 same warning |
| Legacy 30-test set, exact base | 30 passed |
| Same legacy set, candidate r1 | 9 passed, 21 failed at fail-closed local CTP SDK constructor boundary |
| Explicit OKX `api_cls` inert positive | PASS; fake constructor=1, connect=1 |
| Adapter-only cancel + route mutation traps | PASS; API reads=0, adapter calls=0 |

The warning is the existing `backtrader.feeds.quandl` deprecation. No Ruff result is represented as broader project cleanliness; the author reports Ruff success for its applicable candidate files.

## Reproduction boundary

The archived raw package retains the frozen author manifest/patch, candidate and base Store inputs, relevant actor/test sources, all independent command logs, and probe scripts. Candidate manifest verification and exact-base patch replay are separately recorded. The 21 compatibility failures are retained in full. Results apply only to this isolated local fake candidate and do not enable CTP, SDK, network, account, or default-route use.
'''
(qa/'independent-qa-report.md').write_text(report,encoding='utf-8',newline='\n')

receipt = {
 'title':'Iteration41 CTP Account Actor Store Wiring r1 independent QA',
 'date':'2026-09-27',
 'classification':'CANDIDATE_ONLY_NO_WRITE_LOCAL_FAKE',
 'production_ctp_authority':False,
 'source_root':str(author),
 'qa_root':str(qa),
 'manifest_sha256':source_hashes['candidate_manifest'],
 'manifest_verified_files':629,
 'manifest_verified_bytes':9932064,
 'canonical_patch_sha256':source_hashes['patch'],
 'source_hashes':source_hashes,
 'results':{
  'focus_boundary_live_guard':'14 passed; 1 existing Quandl deprecation warning',
  'focus_managed_adapter_guard':'21 passed; 1 existing Quandl deprecation warning',
  'exact_base_legacy_30':'30 passed',
  'candidate_legacy_30':'9 passed, 21 failed; each failure blocks at external_account_actor_unavailable in the direct CTP-local-SDK constructor path',
  'okx_api_cls_positive':'pass; fake constructor=1, connect=1; no SDK/native import',
  'adapter_only_cancel_mutation':'pass; local fallback rejected, route mutation rejected before adapter invocation, API reads=0',
 },
 'limitations':['Caller-supplied adapter callback is arbitrary code and not sandboxed.','Fake/local actor receipt cannot elevate account/provider admission.','Does not establish G4/G1/F14/production acceptance or default-route availability.'],
 'payload_hashes':relfiles(payloads),
}
(qa/'independent-qa-receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

# Frozen raw ZIP: logs, scripts, decisive candidate/base inputs and author freeze evidence.
archive = qa/'store-wiring-r1-independent-qa.raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for label,path in payloads:
        z.write(path,label)
    z.write(qa/'independent-qa-report.md','independent-qa-report.md')
    z.write(qa/'independent-qa-receipt.json','independent-qa-receipt.json')
with zipfile.ZipFile(archive,'r') as z:
    bad=z.testzip()
    if bad is not None: raise SystemExit(f'ZIP CRC failure: {bad}')
    members={i.filename:{'size':i.file_size,'sha256':hashlib.sha256(z.read(i.filename)).hexdigest().upper()} for i in z.infolist()}
archive_verification={
 'archive':archive.name,
 'archive_sha256':sha(archive),
 'archive_bytes':archive.stat().st_size,
 'zip_testzip':None,
 'member_count':len(members),
 'members':members,
}
(qa/'archive-verification.json').write_text(json.dumps(archive_verification,indent=2)+'\n',encoding='utf-8',newline='\n')

canonical.mkdir(parents=True,exist_ok=True)
for name in ['independent-qa-report.md','independent-qa-receipt.json','store-wiring-r1-independent-qa.raw.zip','archive-verification.json']:
    shutil.copy2(qa/name,canonical/name)
print(json.dumps({'canonical':str(canonical),'archive':archive_verification['archive_sha256'],'bytes':archive_verification['archive_bytes'],'members':len(members),'manifest':source_hashes['candidate_manifest'],'patch':source_hashes['patch']},indent=2))

