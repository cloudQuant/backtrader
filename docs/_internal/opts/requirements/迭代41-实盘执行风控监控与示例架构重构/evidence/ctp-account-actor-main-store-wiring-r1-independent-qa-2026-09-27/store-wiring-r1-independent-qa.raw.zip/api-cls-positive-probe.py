from __future__ import annotations
import sys
from pathlib import Path

candidate = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-r1-independent-qa-20260927\candidate-copy')
sys.path.insert(0, str(candidate))
from backtrader.stores import btapistore as store_module
from backtrader.stores.btapistore import BtApiStore
from backtrader.stores.ctp_account_actor_port import RouteKind

class InertInjectedClient:
    init_calls = []
    connect_calls = 0
    def __init__(self, **kwargs):
        type(self).init_calls.append(dict(kwargs))
    def connect(self):
        type(self).connect_calls += 1

store_module._resolve_bt_api_client = lambda *a, **k: (_ for _ in ()).throw(AssertionError('resolver must not run'))
store = BtApiStore(provider='okx', api_cls=InertInjectedClient, config={'exchange_type':'OKX'}, autostart=False)
assert store._candidate_route_kind is RouteKind.NON_CTP
assert store._api_cls is InertInjectedClient
assert InertInjectedClient.init_calls == []
assert 'bt_api_py' not in sys.modules and 'bt_api_ctp' not in sys.modules
api = store._ensure_api_ready()
assert isinstance(api, InertInjectedClient)
assert InertInjectedClient.init_calls == [{'exchange_type':'OKX'}]
assert InertInjectedClient.connect_calls == 1
assert store._connected is True
assert 'bt_api_py' not in sys.modules and 'bt_api_ctp' not in sys.modules
print('PASS explicit OKX api_cls constructor/store connect boundary; fake constructor=1, fake connect=1, SDK/native modules absent')
