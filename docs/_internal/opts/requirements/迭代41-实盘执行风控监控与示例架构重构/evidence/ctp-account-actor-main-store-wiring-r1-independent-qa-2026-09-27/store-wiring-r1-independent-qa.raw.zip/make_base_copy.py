from pathlib import Path
import shutil
qa = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-r1-independent-qa-20260927')
src = qa / 'candidate-copy'
dst = qa / 'base-regression-copy'
if dst.exists():
    raise SystemExit(f'already exists: {dst}')
shutil.copytree(src, dst, ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '.ruff_cache'))
base = dst / 'input-sources' / 'btapistore.py'
store = dst / 'backtrader' / 'stores' / 'btapistore.py'
store.write_bytes(base.read_bytes())
actor = dst / 'backtrader' / 'stores' / 'ctp_account_actor_port.py'
actor.unlink(missing_ok=True)
print('restored exact base Store', len(base.read_bytes()), 'bytes')
