from __future__ import annotations
import hashlib, json, shutil
from pathlib import Path, PurePosixPath

candidate = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r1')
qa = Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-r1-independent-qa-20260927')
expected_manifest = 'ada5018781a7417206b88e3d934d59a67a77beab0c5e09e002a0e8f89a16ade4'
expected_patch = 'b164d083aa4d4bd3a6dc325582c4ee82e0042945360c98a63ca3ec9212abcc58'
expected_base = 'dba2989252db76fe010fbee7caacdcdba34a9b951e3702724156482b67fae826'
manifest_path = candidate / 'evidence' / 'candidate-manifest.json'
manifest_bytes = manifest_path.read_bytes()
manifest_sha = hashlib.sha256(manifest_bytes).hexdigest()
if manifest_sha != expected_manifest:
    raise SystemExit(f'manifest SHA mismatch: {manifest_sha}')
patch_path = candidate / 'evidence' / 'r1-apply.patch'
patch_sha = hashlib.sha256(patch_path.read_bytes()).hexdigest()
if patch_sha != expected_patch:
    raise SystemExit(f'patch SHA mismatch: {patch_sha}')
manifest = json.loads(manifest_bytes)
if manifest.get('base_store_sha256') != expected_base:
    raise SystemExit('manifest base Store identity mismatch')
root = candidate.resolve()
destination = qa / 'candidate-copy'
if destination.exists():
    raise SystemExit(f'destination already exists: {destination}')
seen = set()
total = 0
for row in manifest['files']:
    raw = row['path'].replace('\\', '/')
    rel = PurePosixPath(raw)
    if rel.is_absolute() or '..' in rel.parts:
        raise SystemExit(f'unsafe manifest path {raw}')
    source = candidate.joinpath(*rel.parts)
    if not source.is_file() or source.resolve().is_relative_to(root) is False:
        raise SystemExit(f'missing/out-of-root payload {raw}')
    data = source.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if len(data) != row['size_bytes'] or digest != row['sha256']:
        raise SystemExit(f'payload mismatch {raw}')
    if raw in seen:
        raise SystemExit(f'duplicate manifest member {raw}')
    seen.add(raw)
    output = destination.joinpath(*rel.parts)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)
    total += len(data)
if len(seen) != len(manifest['files']):
    raise SystemExit('payload cardinality mismatch')
base_path = candidate / 'input-sources' / 'btapistore.py'
base_sha = hashlib.sha256(base_path.read_bytes()).hexdigest()
if base_sha != expected_base:
    raise SystemExit(f'exact input base mismatch {base_sha}')
expected = {
    'candidate_store_sha256':manifest['candidate_store_sha256'],
    'candidate_actor_module_sha256':manifest['candidate_actor_module_sha256'],
    'candidate_test_sha256':manifest['candidate_test_sha256'],
}
observed = {
    'candidate_store_sha256':hashlib.sha256((destination/'backtrader/stores/btapistore.py').read_bytes()).hexdigest(),
    'candidate_actor_module_sha256':hashlib.sha256((destination/'backtrader/stores/ctp_account_actor_port.py').read_bytes()).hexdigest(),
    'candidate_test_sha256':hashlib.sha256((destination/'tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py').read_bytes()).hexdigest(),
}
if expected != observed:
    raise SystemExit(f'critical candidate source mismatch expected={expected}, observed={observed}')
input_dir = qa / 'inputs'
input_dir.mkdir()
shutil.copy2(manifest_path, input_dir/'candidate-manifest.json')
shutil.copy2(patch_path, input_dir/'r1-apply.patch')
shutil.copy2(candidate/'evidence'/'qa-report.md', input_dir/'author-qa-report.md')
shutil.copy2(candidate/'evidence'/'r1-legacy-ctp-compatibility-exclusions.txt', input_dir/'r1-legacy-ctp-compatibility-exclusions.txt')
current_main_sha = hashlib.sha256(Path(r'D:\source_code\backtrader\backtrader\stores\btapistore.py').read_bytes()).hexdigest()
result = {
    'schema':'r1-independent-freeze-check.v1',
    'manifest_sha256':manifest_sha,
    'manifest_payload_count':len(seen),
    'manifest_payload_total_bytes':total,
    'patch_sha256':patch_sha,
    'expected_base_sha256':expected_base,
    'frozen_input_base_sha256':base_sha,
    'current_main_store_sha256':current_main_sha,
    'current_main_matches_frozen_base':current_main_sha == expected_base,
    'critical_source_hashes_expected':expected,
    'critical_source_hashes_observed':observed,
    'candidate_copy':str(destination),
}
(qa/'freeze-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
