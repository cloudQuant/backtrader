import importlib, json, pathlib, sys
root=pathlib.Path.cwd().resolve()
mods=['scripts.ctp_i13_i15_windows_guardian_service','scripts.ctp_i13_i15_readonly_request_coordinator','scripts.ctp_i13_i15_parent_launcher','scripts.ctp_i13_i15_windows_guardian','scripts.ctp_i13_i15_outer_watchdog','scripts.ctp_i13_i15_windows_job_backend','scripts.ctp_i13_i15_worker_output_channel','scripts.ctp_i13_i15_readonly_receipt_writer','scripts.ctp_i13_i15_readonly_token_bootstrap','scripts.ctp_i13_i15_guardian_deployment_anchor','scripts.ctp_i13_i15_runtime_closure','scripts.ctp_i13_i15_sealed_import','backtrader_runtime.ctp_i13_worker_dependency_seal']
rows=[]
for name in mods:
 m=importlib.import_module(name)
 p=pathlib.Path(m.__file__).resolve()
 assert p.is_relative_to(root), (name,str(p),str(root))
 rows.append({'module':name,'file':str(p)})
print(json.dumps({'cwd':str(root),'python':sys.executable,'modules':rows,'all_origins_within_qa_copy':True},indent=2))
