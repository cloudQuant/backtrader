import json, pathlib, sys
import pytest
root=pathlib.Path.cwd().resolve()
args=['--noconftest','tests/unit/scripts/test_ctp_i13_i15_windows_guardian_service.py','tests/unit/scripts/test_ctp_i13_i15_readonly_roles.py','-q','--tb=short']
code=int(pytest.main(args))
origins=[]
for name,module in sorted(sys.modules.items()):
 if name.startswith('scripts.ctp_i13_i15_') or name=='backtrader_runtime.ctp_i13_worker_dependency_seal':
  path=getattr(module,'__file__',None)
  if path:
   resolved=pathlib.Path(path).resolve()
   assert resolved.is_relative_to(root), (name,str(resolved),str(root))
   origins.append({'module':name,'path':str(resolved)})
tests=[]
for name,module in sorted(sys.modules.items()):
 path=getattr(module,'__file__',None)
 if path and pathlib.Path(path).name in {'test_ctp_i13_i15_windows_guardian_service.py','test_ctp_i13_i15_readonly_roles.py'}:
  resolved=pathlib.Path(path).resolve(); assert resolved.is_relative_to(root),(name,str(resolved))
  tests.append({'module':name,'path':str(resolved)})
assert len(tests)==2,tests
result={'pytest_exit':code,'cwd':str(root),'test_modules':tests,'local_script_module_count':len(origins),'script_module_origins':origins,'all_imported_candidate_origins_within_qa_copy':True}
(root/'pytest-origin-evidence.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
raise SystemExit(code)
