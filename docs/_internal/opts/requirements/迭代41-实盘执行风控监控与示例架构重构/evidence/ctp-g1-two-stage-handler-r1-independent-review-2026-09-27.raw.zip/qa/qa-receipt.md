# Independent G1 two-stage handler QA

- Input manifest SHA256: `ad3addd84fcd1eb7085068540b4e3a01f3da08ac56218fa34c2d3aa488992480` (expected hash matched).
- QA copy: `D:\temp\iteration41-g1-two-stage-handler-qa-20260927`; all candidate tests and 10 imported candidate script modules resolved from this copy.
- Focus suite: 68 passed twice; separate requested stage/deadline focus: 6 passed and 3 passed.
- Verified manifest files and supplemental import-closure bytes/hashes are in `qa-input-verification.json`; run logs and hashes are in `qa-receipt.json`.

## Findings

- Job1 cleanup missing prevented Job2 creation. Job2 cleanup uncertainty, absolute-deadline crossing, and channel close failure all stayed fail-closed in fake tests.
- Caller IPC timeout is distinct from the service hard deadline. A blocked synchronous backend call is not interrupted by that deadline; process death is what closes its job in the fake test.
- `sealed_import.run_fixed_readonly_service_role` still rejects execution with `readonly_role_runtime_factory_unavailable`; token adapter also refuses. The two-stage candidate does not demonstrate an executable coordinator bootstrap.
- Synchronous channel/token/role setup occurs before the stage outer watchdog; receipt-lease close occurs synchronously afterward. There is no end-to-end hard bound for these setup/cleanup calls.
- Duplicate receipt replacement is prevented by CREATE_NEW, but the snapshot has no dedicated repeated-request replay integration test.

This remains fake-only and does not pass G1 or prove installed service, protected ACL deployment, hard-deadline containment, CTP/native/provider behavior, or a working coordinator bootstrap.
