import hashlib
import json
from pathlib import Path

qa = Path(r"D:\temp\iteration41-action-authority-independent-v2-qa-20260926")
freeze = Path(r"D:\temp\iteration41-action-admission-defer-v2-freeze-20260926")
execution = Path(r"D:\temp\iteration41_v18_cancel_postcondition_r0")
sdk = Path(r"D:\q\e")
parent = Path(r"D:\bt_api_py_codex_i9_integrated_20260926")
main = Path(r"D:\source_code\backtrader")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def entry(path, label):
    return {"label": label, "path": str(path), "sha256": sha(path)}

frozen_paths = [
    freeze / "manifest.json", freeze / "focus.junit.xml", freeze / "focus.log", freeze / "module-origins.txt", freeze / "ruff.log",
    freeze / "backtrader_runtime/ctp_managed_action_authority.py",
    freeze / "backtrader_runtime/ctp_managed_action_scope_resolver.py",
    freeze / "backtrader_runtime/ctp_i9_account_session_candidate.py",
    freeze / "tests/unit/runtime/test_ctp_managed_action_authority.py",
    freeze / "tests/unit/runtime/test_ctp_managed_action_scope_resolver.py",
    freeze / "tests/integration/test_iteration41_ctp_i9_account_session_candidate.py",
]
independent_paths = [
    qa / "independent-focus.junit.xml", qa / "independent-focus.log",
    qa / "v18-real-store-binding-negative.py", qa / "v18-real-store-binding-negative.log",
    qa / "v18-real-store-binding-negative-runner-order-error.log",
    qa / "module-origins-independent.txt", qa / "source-provenance-independent.txt",
    qa / "ruff-production-check.log", qa / "ruff-all-check.log", qa / "ruff-format-check.log",
    qa / "harness/backtrader_runtime/__init__.py", qa / "build_independent_manifest.py",
    qa / "metadata-source-derived/bt_api_execution-0.2.0.dist-info/METADATA",
]
all_files = [entry(p, "frozen-candidate" if p in frozen_paths else "independent-qa") for p in frozen_paths + independent_paths]
review = {
    "classification": "Independent source-only review of frozen v2 action authority/defer slice; not deployment approval",
    "reviewed_at_local_date": "2026-09-26",
    "frozen_candidate": {
        "root": str(freeze),
        "manifest_sha256": sha(freeze / "manifest.json"),
        "files": [entry(p, str(p.relative_to(freeze))) for p in frozen_paths[5:]],
    },
    "dependencies": {
        "execution_root": str(execution),
        "execution_manifest_sha256": "0372771FBB91D3A6C6CC8D859EB4C68B6BBE65368A8672A8312F4AE9FA6E46B1",
        "execution_source_head": "bb2cd24cdaf9fb64f6b95010ee8619b0c6a35589",
        "execution_store_sha256": "25980518E1B7AAE5CE13E3531AB854771AB5D036DF0209CDDDE08508124E8206",
        "execution_pyproject_version": "0.2.0",
        "execution_metadata": "QA-only METADATA shim generated from that source pyproject; not installed",
        "sdk_root": str(sdk),
        "sdk_head": "29f8ff171f61a71038328a7067e0909bf44774b2",
        "sdk_worktree": "clean",
        "sdk_source_version": "2.0.4+iteration41.i9",
        "sdk_client_sha256": "BF915128C41DA83EFDFF517E3EA711C43D7555406BD831A0DFCD775B64840D1C",
        "sdk_callback_ingress_sha256": "A49465DC36AD4A60AB6A81CDE58FD8963AB230BE740D3832A792DC0184F48002",
        "parent_root": str(parent),
        "parent_head": "76d5e0e60883263e0e79b67df321e7053ed46179",
        "parent_version": "0.15.5",
        "parent_gitlink_changes": ["bt_api_ctp", "bt_api_execution", "bt_api_monitor", "bt_api_risk"],
        "parent_python_source_clean": True,
        "base_version": "0.15.4",
        "base_source": str(parent / "bt_api/bt_api_base/src"),
    },
    "pytest": {
        "result": "75 passed, 0 failed, 0 errors, 0 skipped; 1 runtime warning",
        "command": "python -m pytest -q --noconftest -p no:cacheprovider tests/unit/runtime/test_ctp_managed_action_authority.py tests/unit/runtime/test_ctp_managed_action_scope_resolver.py tests/integration/test_iteration41_ctp_i9_account_session_candidate.py --tb=short --junitxml=<QA_DIR>\\independent-focus.junit.xml",
        "python": r"D:\temp\iteration41-main-source-qa-20260926\venv\Scripts\python.exe",
        "warning": "pytest-asyncio unset fixture loop-scope deprecation; SDK emits warning that no compatible Windows _ctp binary is present",
        "native_module_loaded": False,
        "provider_or_network": False,
    },
    "real_v18_store_counterexample": {
        "source": "Actual V18 SQLite Store r0 and frozen v2 authority/resolver; source-only synthetic config/session and ephemeral signed permits",
        "action_digest_bound_to_staged_row": True,
        "negative_cases": [
            "session broker differs from sealed config",
            "session user differs from sealed config",
            "request BrokerID differs",
            "request InvestorID differs",
            "request UserID differs",
            "request InstrumentID differs",
            "request ExchangeID differs",
            "request CombHedgeFlag differs",
        ],
        "negative_outcome": "Each exact signed-permit attempt rejected with ContractValidationError before claim; durable row READY, owner ACTIVE, native dispatches 0",
        "positive_control": "matching sealed config/session claim succeeds; row CLAIMED, owner ACTIVE, native dispatches 0",
        "limitations": [
            "This tests source-only Store claim admission, not the post-claim final native call or its freshness mutation window.",
            "It is not a production config, key, revocation service, external writer fence, or provider session.",
            "No SDK Req was sent; source-only execution metadata shim is not wheel acceptance.",
        ],
    },
    "ruff": {
        "production_modules": "ruff check passed on the three frozen production modules",
        "all_six_files": "one E731 at frozen integration test line 975: local lambda assignment in test; not changed",
        "format": "ruff format --check passed; 6 files already formatted",
        "tool": r"C:\anaconda3\Scripts\ruff.exe 0.16.2",
        "config": r"D:\source_code\backtrader\pyproject.toml",
    },
    "runner_order_error": "A supplemental assertion initially read the command before stage and got None; preserved in a separate diagnostic log, assertion moved after queue receipt; successful rerun then covered the signed matrix.",
    "artifacts": all_files,
}
(qa / "independent-review.json").write_text(json.dumps(review, indent=2, sort_keys=True) + "\n", encoding="utf-8")
manifest = {
    "classification": "Frozen independent v2 review artifact manifest; paths are local evidence paths",
    "candidate_manifest_sha256": sha(freeze / "manifest.json"),
    "independent_review_sha256": sha(qa / "independent-review.json"),
    "artifacts": all_files + [entry(qa / "independent-review.json", "independent-review-summary")],
}
(qa / "runner-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print("candidate_manifest=" + sha(freeze / "manifest.json"))
print("independent_review=" + sha(qa / "independent-review.json"))
print("runner_manifest=" + sha(qa / "runner-manifest.json"))
print("files=" + str(len(manifest["artifacts"])))