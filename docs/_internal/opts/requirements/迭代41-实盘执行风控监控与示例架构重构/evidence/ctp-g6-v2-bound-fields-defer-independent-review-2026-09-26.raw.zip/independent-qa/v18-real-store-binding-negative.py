import hashlib
import importlib.util
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

from bt_api_execution.contracts import ExecutionScope, payload_sha256
from bt_api_execution.ctp_callback_session import CtpCallbackSessionStoreAdapter
from bt_api_execution.store import SqliteExecutionStore
from backtrader_runtime.ctp_managed_action_authority import (
    CtpManagedActionAuthorityAdapter,
    CtpManagedActionPermitV1,
    CtpManagedActionRevocationSnapshot,
    CtpManagedActionWriterFenceSnapshot,
    CtpPinnedEd25519ActionKey,
    PinnedEd25519CtpActionPermitVerifier,
)
from backtrader_runtime.ctp_managed_action_scope_resolver import (
    SealedCtpManagedActionScopeResolverV1,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

FREEZE = Path(r"D:\temp\iteration41-action-admission-defer-v2-freeze-20260926")
SDK_INGRESS = Path(r"D:\q\e\src\bt_api_ctp\ctp\callback_ingress.py")
TEST_HELPERS = FREEZE / "tests/unit/runtime/test_ctp_managed_action_scope_resolver.py"


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


st = _load("frozen_scope_test_helpers_v2", TEST_HELPERS)
ingress = _load("sdk29_callback_ingress_leaf_v2", SDK_INGRESS)


class PermitSource:
    def __init__(self, permit):
        self.permit = permit

    def read_permit(self, permit_id):
        return self.permit if permit_id == self.permit.permit_id else None


class RevocationSource:
    def __init__(self, snapshot):
        self.snapshot = snapshot

    def read_revocation(self, _permit):
        return self.snapshot


class FenceSource:
    def __init__(self, snapshot):
        self.snapshot = snapshot

    def read_active_fence(self, _scope):
        return self.snapshot


class Clock:
    def __init__(self, now_ns):
        self.value = now_ns

    def now_ns(self):
        return self.value


def _run_case(root: Path, label: str, *, bad_session: str | None, bad_payload: str | None, expect_claim: bool = False):
    document = st._config_document()
    private = document["ctp"]
    runtime_dir = root / (label + "-runtime")
    st._protected_config(runtime_dir, document)
    registry, registration = st._registry(runtime_dir)
    scope = st._execution_scope(private, "simnow")
    store = SqliteExecutionStore(root / (label + ".sqlite3"))
    try:
        lease = store.acquire_or_renew_lease(scope, "independent-qa-" + label, ttl_ns=60_000_000_000)
        owner = store.create_ctp_callback_session_owner(scope, writer_lease=lease)

        def ack(**kwargs):
            return ingress.CtpTraderCallbackIngressAckV2(
                owner_id=kwargs["owner_id"],
                sequence=kwargs["sequence"],
                digest=kwargs["digest"],
                commit_state=kwargs["commit_state"],
                high_watermark=kwargs["high_watermark"],
            )

        session_adapter = CtpCallbackSessionStoreAdapter(
            store, scope, owner, lease, ack, ingress.CtpTraderCallbackIngressRecordV2
        )
        tags = ingress.CtpTraderCallbackSourceTagsV2(
            "independent.source." + label,
            "e" * 32,
            "independent.api." + label,
            "independent.spi." + label,
            1,
            0,
        )
        broker = "wrong-broker" if bad_session == "BrokerID" else private["broker_id"]
        user = "wrong-user" if bad_session == "UserID" else private["user_id"]

        def append(name, sequence, args, generation):
            record = ingress.build_callback_ingress_record_v2(
                owner_intent_id=owner.owner_intent_id,
                callback_name=name,
                source_phase=ingress.CtpTraderCallbackPhase.PRE_LOGIN,
                source_tags=tags,
                connection_generation=generation,
                source_sequence=sequence,
                callback_monotonic_ns=time.monotonic_ns(),
                args=args,
            )
            session_adapter.sink.append(record)

        append("OnFrontConnected", 1, (), 0)
        append(
            "OnRspAuthenticate",
            2,
            (SimpleNamespace(BrokerID=broker, UserID=user), SimpleNamespace(ErrorID=0), 1, True),
            0,
        )
        append(
            "OnRspUserLogin",
            3,
            (
                SimpleNamespace(
                    BrokerID=broker,
                    UserID=user,
                    TradingDay=scope.trading_day,
                    FrontID=5,
                    SessionID=7,
                    MaxOrderRef="0",
                ),
                SimpleNamespace(ErrorID=0),
                2,
                True,
            ),
            1,
        )
        observation = SimpleNamespace(
            broker_id=broker,
            user_id=user,
            trading_day=scope.trading_day,
            connection_generation=1,
            request_id=2,
        )
        active = session_adapter.bind_session(
            owner, observation=observation, source_tags=tags, high_watermark=3
        )
        session_payload = store._ctp_callback_session_binding_payload(active)

        intent = "intent." + label
        runtime_id = "bt-managed-v1:" + hashlib.sha256(intent.encode("ascii")).hexdigest()
        legacy_scope = ExecutionScope(
            "CTP", "simulation", scope.account_ref, "strategy.legacy.qa", "20260925"
        )
        source_digests = (
            ("backtrader_prototype", hashlib.sha256(b"synthetic prototype").hexdigest()),
            ("sdk_jsonl", hashlib.sha256(b"synthetic sdk fixture").hexdigest()),
        )
        from bt_api_execution.store import CtpOrderRefLegacyMapping, CtpOrderRefSeedProof

        mapping = CtpOrderRefLegacyMapping(
            source_name="backtrader_prototype",
            account_key=scope.account_key,
            trading_day="20260925",
            scope_key=legacy_scope.key,
            managed_intent_id="legacy." + label,
            runtime_order_id="bt-managed-v1:" + hashlib.sha256(("legacy." + label).encode()).hexdigest(),
            order_ref="000000000012",
        )
        proof = CtpOrderRefSeedProof(
            trading_day=scope.trading_day,
            native_max_order_ref="000000000017",
            legacy_ledger_max_order_ref="000000000012",
            legacy_ledger_sha256=payload_sha256(dict(source_digests)),
            account_key=scope.account_key,
            scope_key=scope.key,
            session_generation_id=active.session_generation_id,
            native_front_id=active.dispatch_front_id,
            native_session_id=active.dispatch_session_id,
            existing_native_order_refs=("000000000016", "000000000017"),
            legacy_source_sha256=source_digests,
            legacy_mappings=(mapping,),
        )
        reservation = store.seed_ctp_order_ref_and_reserve_identity(
            scope, proof, intent, runtime_id, writer_lease=lease
        )

        request = {
            "OrderRef": reservation.order_ref,
            "BrokerID": private["broker_id"],
            "InvestorID": private["user_id"],
            "UserID": private["user_id"],
            "InstrumentID": private["instrument_id"],
            "ExchangeID": private["exchange_id"],
            "Direction": "0",
            "CombOffsetFlag": "0",
            "CombHedgeFlag": private["hedge_flag"],
            "OrderPriceType": "2",
            "LimitPrice": 100.0,
            "VolumeTotalOriginal": 1,
            "TimeCondition": "3",
        }
        if bad_payload is not None:
            request[bad_payload] = {
                "BrokerID": "other-broker",
                "InvestorID": "other-user",
                "UserID": "other-user",
                "InstrumentID": "cu9999",
                "ExchangeID": "DCE",
                "CombHedgeFlag": "2",
            }[bad_payload]

        command_id = "command." + label
        permit_id = "permit." + label
        request_digest = payload_sha256(request)
        session_digest = payload_sha256(session_payload)
        current_scope = st._sim_policy(registration)
        resolver = SealedCtpManagedActionScopeResolverV1(
            registry, registration, current_scope, st.FRONT_A, scope
        )
        scope_facts = resolver._baseline
        correlation = SimpleNamespace(
            version=2,
            account_key=scope.account_key,
            scope_key=scope.key,
            trading_day=scope.trading_day,
            operation="SUBMIT",
            command_id=command_id,
            request_payload_sha256=request_digest,
            reservation_managed_intent_id=intent,
            managed_action_id=intent,
            runtime_order_id=runtime_id,
            order_ref=reservation.order_ref,
            cancel_target_exchange_id=None,
            cancel_target_order_sys_id=None,
            cancel_target_front_id=None,
            cancel_target_session_id=None,
            approval_use_id=permit_id,
            approval_digest="0" * 64,
            session_binding_sha256=session_digest,
            session_generation_id=active.session_generation_id,
            dispatch_front_id=active.dispatch_front_id,
            dispatch_session_id=active.dispatch_session_id,
            native_request_id=53,
            native_action_ref=None,
            native_request_payload_sha256=request_digest,
        )
        draft = SimpleNamespace(
            correlation_key=correlation,
            account_key=scope.account_key,
            scope_key=scope.key,
            trading_day=scope.trading_day,
            operation="SUBMIT",
            command_id=command_id,
            request_payload=request,
            request_payload_sha256=request_digest,
            native_request_payload=request,
            native_request_payload_sha256=request_digest,
            reservation_managed_intent_id=intent,
            order_ref=reservation.order_ref,
            cancel_target_order_ref=None,
            cancel_target_exchange_id=None,
            cancel_target_order_sys_id=None,
            cancel_target_front_id=None,
            cancel_target_session_id=None,
            session_binding_sha256=session_digest,
        )
        action_digest = CtpManagedActionAuthorityAdapter._action_digest(draft, scope_facts)
        now = time.time_ns()
        private_key = Ed25519PrivateKey.generate()
        public_bytes = private_key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        pin = CtpPinnedEd25519ActionKey(
            "qa.issuer", "qa.key", "ctp-i9-store-claim", public_bytes,
            now - 10_000_000_000, now + 10_000_000_000,
        )
        claims = dict(
            permit_id=permit_id,
            issuer="qa.issuer",
            key_id="qa.key",
            audience="ctp-i9-store-claim",
            environment=scope_facts.environment,
            mode=scope_facts.mode,
            preset=scope_facts.preset,
            scope_sha256=scope_facts.digest,
            action_sha256=action_digest,
            issued_at_ns=now - 1_000_000_000,
            expires_at_ns=now + 4_000_000_000,
            revocation_epoch=1,
            fence_id="qa.fence",
            fence_epoch=1,
            fence_owner_id="qa.owner",
            nonce="qa.nonce." + label,
            signature_hex="0" * 128,
        )
        unsigned = CtpManagedActionPermitV1(**claims)
        permit = CtpManagedActionPermitV1(
            **dict(claims, signature_hex=private_key.sign(unsigned.signed_payload()).hex())
        )
        revocation = CtpManagedActionRevocationSnapshot(
            permit_id=permit_id,
            key_id="qa.key",
            epoch=1,
            revoked=False,
            key_active=True,
            observed_at_ns=now - 1_000_000,
            valid_until_ns=now + 2_000_000_000,
            source_digest_sha256="4" * 64,
        )
        fence = CtpManagedActionWriterFenceSnapshot(
            fence_id="qa.fence",
            owner_id="qa.owner",
            account_fingerprint_sha256=scope_facts.account_fingerprint_sha256,
            environment=scope_facts.environment,
            mode=scope_facts.mode,
            epoch=1,
            observed_at_ns=now - 1_000_000,
            expires_at_ns=now + 3_000_000_000,
            source_digest_sha256="5" * 64,
        )
        signature_verifier = PinnedEd25519CtpActionPermitVerifier((pin,))
        signature_verifier.verify(permit, now_ns=now)
        authority = CtpManagedActionAuthorityAdapter(
            store=store,
            scope=scope,
            owner_handle=owner,
            writer_lease=lease,
            scope_resolver=resolver,
            permit_source=PermitSource(permit),
            signature_verifier=signature_verifier,
            revocation_source=RevocationSource(revocation),
            fence_source=FenceSource(fence),
            trusted_clock=Clock(now),
        )
        store.stage_ctp_dispatch_command(
            scope,
            command_id,
            "SUBMIT",
            request,
            approval_use_id=permit_id,
            approval_digest=permit.digest,
            session_binding=session_payload,
            writer_lease=lease,
            managed_intent_id=intent,
            order_ref=reservation.order_ref,
            session_generation_id=active.session_generation_id,
            dispatch_front_id=active.dispatch_front_id,
            dispatch_session_id=active.dispatch_session_id,
            native_request_id=53,
            local_queue_receipt_id="a" * 32,
        )
        store.record_ctp_dispatch_queue_receipt(
            scope,
            command_id,
            {"kind": "command_receipt", "command": "submit", "receipt_id": "a" * 32, "queued": True},
            writer_lease=lease,
        )
        stored_before_claim = store.read_ctp_dispatch_command(scope, command_id)
        assert CtpManagedActionAuthorityAdapter._action_digest(stored_before_claim, scope_facts) == action_digest

        claim = None
        claim_outcome = "CLAIMED"
        try:
            claim = store.claim_ctp_dispatch_command_for_session(
                scope,
                command_id,
                owner_handle=owner,
                writer_lease=lease,
                authority_verifier=authority,
                required_local_queue_receipt_id="a" * 32,
            )
            if claim is None:
                claim_outcome = "NO_CLAIM"
            else:
                claim_outcome = "CLAIMED"
        except Exception as exc:
            claim_outcome = type(exc).__name__

        persisted = store.read_ctp_dispatch_command(scope, command_id)
        if expect_claim:
            assert claim_outcome == "CLAIMED" and claim is not None, (label, claim_outcome)
            assert persisted.status == "CLAIMED", (label, claim_outcome, persisted.status)
        else:
            assert claim_outcome != "CLAIMED", (label, claim_outcome)
            assert persisted.status == "READY", (label, claim_outcome, persisted.status)
        owner_row = store._connection.execute(
            "SELECT owner_state FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id = ?",
            (owner.owner_intent_id,),
        ).fetchone()
        print(f"{label}: claim={claim_outcome}; row={persisted.status}; owner={owner_row[0]}; native_dispatches=0")
    finally:
        store.close()


with tempfile.TemporaryDirectory(prefix="action-authority-v2-store-qa-") as temp:
    root = Path(temp)
    cases = [("session-broker-mismatch", "BrokerID", None), ("session-user-mismatch", "UserID", None)]
    cases.extend(("request-" + field.lower(), None, field) for field in (
        "BrokerID", "InvestorID", "UserID", "InstrumentID", "ExchangeID", "CombHedgeFlag"
    ))
    for label, bad_session, bad_payload in cases:
        _run_case(root, label, bad_session=bad_session, bad_payload=bad_payload)
    _run_case(root, "valid-config-control", bad_session=None, bad_payload=None, expect_claim=True)
print("ALL_NEGATIVE_STORE_CLAIMS_REMAIN_READY; VALID_CONFIG_CONTROL_CLAIMED")

