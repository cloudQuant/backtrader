"""QA-only loader that executes the current project package init with the frozen modules first."""
from pathlib import Path as _Path
_frozen_runtime = r"D:\temp\iteration41-action-admission-defer-v2-freeze-20260926\backtrader_runtime"
_project_runtime = r"D:\source_code\backtrader\backtrader_runtime"
__path__ = [_frozen_runtime, _project_runtime]
_project_init = _Path(_project_runtime) / "__init__.py"
exec(compile(_project_init.read_text(encoding="utf-8"), str(_project_init), "exec"), globals())
__path__ = [_frozen_runtime, _project_runtime]
