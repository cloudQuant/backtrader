import importlib.util
import json
import sys
from importlib.abc import MetaPathFinder
from pathlib import Path

class BlockCTPNative(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_ctp.ctp._ctp':
            raise ModuleNotFoundError('native extension blocked for fake evidence')
        return None

sys.meta_path.insert(0, BlockCTPNative())
repo = Path(r'D:\work\backtrader-g5-cancel-issuer')
site = Path(r'D:\q\unified-v20r3-consumer-20260927\Lib\site-packages')
sys.path[:0] = [str(repo), str(site)]
spec = importlib.util.spec_from_file_location('g5_test_candidate', repo / 'tests/integration/test_iteration41_ctp_i9_account_session_candidate.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
import pytest
mp = pytest.MonkeyPatch()
db_path = str(Path(r'D:\temp\iteration41-g5-r3-poison-repro-v3') / 'ctp-i9-dispatch.sqlite3')
candidate, store, reserve, make_prepared, _ = mod._source_candidate_fixture(Path(r'D:\temp\iteration41-g5-r3-poison-repro-v3'), mp)
prepared = make_prepared(reserve('g5-poison-repro-v3'))
candidate.stage_and_queue(prepared)
def deny(*_args, **_kwargs):
    raise RuntimeError('synthetic final admission denial')
candidate._native_call_admission = deny
try:
    candidate.dispatch_next()
except BaseException as exc:
    outcome = {'raised_type': type(exc).__name__, 'raised': str(exc)}
row = store._connection.execute('SELECT status,native_call_inflight,unknown_reason FROM ctp_dispatch_commands WHERE command_id=?', (prepared.command_id,)).fetchone()
owner = store._connection.execute('SELECT owner_state,poison_code FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id=?', (candidate.owner_handle.owner_intent_id,)).fetchone()
family = store._connection.execute('SELECT owner_state FROM ctp_account_family_owners WHERE family_key=?', (store._ctp_account_family_key(candidate._scope),)).fetchone()
outcome.update({'same_process_command': list(row), 'same_process_owner': list(owner), 'same_process_family_owner': None if family is None else family[0], 'api_order_calls': [call for call in mod._FakeTraderApiFactory.instances[-1].calls if isinstance(call, tuple) and call[0] in {'ReqOrderInsert','ReqOrderAction'}], 'db_path': db_path})
candidate.stop()
store.close()
types = mod._candidate_types_or_skip()
reopened = types[1](db_path)
command = reopened.read_ctp_dispatch_command(candidate._scope, prepared.command_id)
owner2 = reopened._connection.execute('SELECT owner_state,poison_code FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id=?', (candidate.owner_handle.owner_intent_id,)).fetchone()
family2 = reopened._connection.execute('SELECT owner_state FROM ctp_account_family_owners WHERE family_key=?', (reopened._ctp_account_family_key(candidate._scope),)).fetchone()
reopened_row = reopened._connection.execute('SELECT status,native_call_inflight,unknown_reason FROM ctp_dispatch_commands WHERE command_id=?', (prepared.command_id,)).fetchone()
outcome.update({'reopened_command': command.status, 'reopened_command_row': list(reopened_row), 'reopened_owner': list(owner2), 'reopened_family_owner': None if family2 is None else family2[0]})
try:
    reopened.acquire_ctp_account_family_owner(candidate._scope)
except BaseException as exc:
    outcome['new_owner_result'] = type(exc).__name__
else:
    outcome['new_owner_result'] = 'unexpectedly_acquired'
reopened.close()
mp.undo()
print(json.dumps(outcome, sort_keys=True))
