import hashlib, importlib.util, sys, tempfile, time, uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from bt_api_execution.contracts import ExecutionScope, payload_sha256
from bt_api_execution.ctp_callback_session import CtpCallbackSessionStoreAdapter
from bt_api_execution.store import SqliteExecutionStore
from backtrader_runtime import ctp_managed_action_authority as auth
from backtrader_runtime.ctp_managed_action_scope_resolver import SealedCtpManagedActionScopeResolverV1, ctp_managed_account_ref_v1

ROOT=Path(r'D:\source_code\backtrader')
SDK_INGRESS=Path(r'D:\bt_api_ctp_i13_g5_manual_candidate_20260926\src\bt_api_ctp\ctp\callback_ingress.py')
SCOPE_TEST=ROOT/'tests/unit/runtime/test_ctp_managed_action_scope_resolver.py'
spec=importlib.util.spec_from_file_location('scope_test_qa',SCOPE_TEST)
st=importlib.util.module_from_spec(spec); sys.modules[spec.name]=st; spec.loader.exec_module(st)
spec=importlib.util.spec_from_file_location('sdk_ingress_qa',SDK_INGRESS)
ing=importlib.util.module_from_spec(spec); sys.modules[spec.name]=ing; spec.loader.exec_module(ing)

class PermitSource:
 def __init__(self,p): self.p=p
 def read_permit(self,permit_id): return self.p if permit_id==self.p.permit_id else None
class RevSource:
 def __init__(self,s): self.s=s
 def read_revocation(self,_permit): return self.s
class FenceSource:
 def __init__(self,s): self.s=s
 def read_active_fence(self,_scope): return self.s
class Clock:
 def __init__(self,n): self.n=n
 def now_ns(self): return self.n

def setup_case(root, suffix, *, login_matches, payload_matches):
 doc=st._config_document()
 config=doc['ctp']
 runtime_dir=root/(suffix+'-runtime')
 st._protected_config(runtime_dir,doc)
 registry,registration=st._registry(runtime_dir)
 execution_scope=st._execution_scope(config,'simnow')
 store=SqliteExecutionStore(root/f'{suffix}.sqlite3')
 lease=store.acquire_or_renew_lease(execution_scope,f'qa-owner-{suffix}',ttl_ns=60_000_000_000)
 owner=store.create_ctp_callback_session_owner(execution_scope,writer_lease=lease)
 ack=lambda **kw: ing.CtpTraderCallbackIngressAckV2(owner_id=kw['owner_id'],sequence=kw['sequence'],digest=kw['digest'],commit_state=kw['commit_state'],high_watermark=kw['high_watermark'])
 session_adapter=CtpCallbackSessionStoreAdapter(store,execution_scope,owner,lease,ack,ing.CtpTraderCallbackIngressRecordV2)
 tags=ing.CtpTraderCallbackSourceTagsV2('src.instance.'+suffix,'e'*32,'src.api.'+suffix,'src.spi.'+suffix,1,0)
 broker=config['broker_id'] if login_matches else 'wrong-broker'
 user=config['user_id'] if login_matches else 'wrong-user'
 def append(name,seq,args,generation):
  rec=ing.build_callback_ingress_record_v2(owner_intent_id=owner.owner_intent_id,callback_name=name,source_phase=ing.CtpTraderCallbackPhase.PRE_LOGIN,source_tags=tags,connection_generation=generation,source_sequence=seq,callback_monotonic_ns=time.monotonic_ns(),args=args)
  session_adapter.sink.append(rec)
 append('OnFrontConnected',1,(),0)
 append('OnRspAuthenticate',2,(SimpleNamespace(BrokerID=broker,UserID=user),SimpleNamespace(ErrorID=0),1,True),0)
 append('OnRspUserLogin',3,(SimpleNamespace(BrokerID=broker,UserID=user,TradingDay=execution_scope.trading_day,FrontID=5,SessionID=7,MaxOrderRef='0'),SimpleNamespace(ErrorID=0),2,True),1)
 observation=SimpleNamespace(broker_id=broker,user_id=user,trading_day=execution_scope.trading_day,connection_generation=1,request_id=2)
 active=session_adapter.bind_session(owner,observation=observation,source_tags=tags,high_watermark=3)
 facts=store.read_ctp_callback_session_context_facts(owner)

 # Seed a fake, local OrderRef high-water mark, then reserve exactly one intent.
 intent='intent.qa.'+suffix
 runtime_id='bt-managed-v1:'+hashlib.sha256(intent.encode('ascii')).hexdigest()
 legacy_scope=ExecutionScope('ctp','simnow',execution_scope.account_ref,'strategy.legacy.qa','20260925')
 sources=(('backtrader_prototype',hashlib.sha256(b'fake prototype').hexdigest()),('sdk_jsonl',hashlib.sha256(b'fake sdk source').hexdigest()))
 mapping=store.__class__.__module__
 from bt_api_execution.store import CtpOrderRefLegacyMapping,CtpOrderRefSeedProof
 legacy=CtpOrderRefLegacyMapping(source_name='backtrader_prototype',account_key=execution_scope.account_key,trading_day='20260925',scope_key=legacy_scope.key,managed_intent_id='legacy.qa.'+suffix,runtime_order_id='bt-managed-v1:'+hashlib.sha256(('legacy.qa.'+suffix).encode()).hexdigest(),order_ref='000000000012')
 proof=CtpOrderRefSeedProof(trading_day=execution_scope.trading_day,native_max_order_ref='000000000017',legacy_ledger_max_order_ref='000000000012',legacy_ledger_sha256=payload_sha256(dict(sources)),account_key=execution_scope.account_key,scope_key=execution_scope.key,session_generation_id=active.session_generation_id,native_front_id=active.dispatch_front_id,native_session_id=active.dispatch_session_id,existing_native_order_refs=('000000000016','000000000017'),legacy_source_sha256=sources,legacy_mappings=(legacy,))
 reservation=store.seed_ctp_order_ref_and_reserve_identity(execution_scope,proof,intent,runtime_id,writer_lease=lease)

 request={
  'OrderRef':reservation.order_ref,
  'BrokerID':broker if payload_matches else 'other-broker',
  'InvestorID':user if payload_matches else 'other-user',
  'UserID':user if payload_matches else 'other-user',
  'InstrumentID':config['instrument_id'] if payload_matches else 'cu9999',
  'ExchangeID':'SHFE' if payload_matches else 'DCE',
  'Direction':'0','CombOffsetFlag':'0','CombHedgeFlag':'1',
  'OrderPriceType':'2','LimitPrice':100.0,'VolumeTotalOriginal':1,'TimeCondition':'3',
 }
 command_id='command.qa.'+suffix
 permit_id='permit.qa.'+suffix
 native_request_id=53
 session_payload=store._ctp_callback_session_binding_payload(active)
 session_digest=payload_sha256(session_payload)
 request_digest=payload_sha256(request)
 scope_resolver=SealedCtpManagedActionScopeResolverV1(registry,registration,st._sim_policy(registration),st.FRONT_A,execution_scope)
 scope_facts=scope_resolver._baseline
 corr=SimpleNamespace(version=2,account_key=execution_scope.account_key,scope_key=execution_scope.key,trading_day=execution_scope.trading_day,operation='SUBMIT',command_id=command_id,request_payload_sha256=request_digest,reservation_managed_intent_id=intent,managed_action_id=intent,runtime_order_id=runtime_id,order_ref=reservation.order_ref,cancel_target_exchange_id=None,cancel_target_order_sys_id=None,cancel_target_front_id=None,cancel_target_session_id=None,approval_use_id=permit_id,approval_digest='0'*64,session_binding_sha256=session_digest,session_generation_id=active.session_generation_id,dispatch_front_id=active.dispatch_front_id,dispatch_session_id=active.dispatch_session_id,native_request_id=native_request_id,native_action_ref=None,native_request_payload_sha256=request_digest)
 draft=SimpleNamespace(correlation_key=corr,account_key=execution_scope.account_key,scope_key=execution_scope.key,trading_day=execution_scope.trading_day,operation='SUBMIT',command_id=command_id,request_payload=request,request_payload_sha256=request_digest,native_request_payload=request,native_request_payload_sha256=request_digest,reservation_managed_intent_id=intent,order_ref=reservation.order_ref,cancel_target_order_ref=None,cancel_target_exchange_id=None,cancel_target_order_sys_id=None,cancel_target_front_id=None,cancel_target_session_id=None,session_binding_sha256=session_digest)
 action_digest=auth.CtpManagedActionAuthorityAdapter._action_digest(draft,scope_facts)
 now=time.time_ns()
 from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
 from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
 private=Ed25519PrivateKey.generate(); public=private.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
 key=auth.CtpPinnedEd25519ActionKey('qa.issuer','qa.key','ctp-i9-store-claim',public,now-10_000_000_000,now+10_000_000_000)
 kwargs=dict(permit_id=permit_id,issuer='qa.issuer',key_id='qa.key',audience='ctp-i9-store-claim',environment=scope_facts.environment,mode=scope_facts.mode,preset=scope_facts.preset,scope_sha256=scope_facts.digest,action_sha256=action_digest,issued_at_ns=now-1_000_000_000,expires_at_ns=now+4_000_000_000,revocation_epoch=1,fence_id='qa.fence',fence_epoch=1,fence_owner_id='qa.owner',nonce='qa.nonce.'+suffix,signature_hex='0'*128)
 unsigned=auth.CtpManagedActionPermitV1(**kwargs)
 permit=auth.CtpManagedActionPermitV1(**dict(kwargs,signature_hex=private.sign(unsigned.signed_payload()).hex()))
 rev=auth.CtpManagedActionRevocationSnapshot(permit_id=permit_id,key_id='qa.key',epoch=1,revoked=False,key_active=True,observed_at_ns=now-1_000_000,valid_until_ns=now+2_000_000_000,source_digest_sha256='4'*64)
 fence=auth.CtpManagedActionWriterFenceSnapshot(fence_id='qa.fence',owner_id='qa.owner',account_fingerprint_sha256=scope_facts.account_fingerprint_sha256,environment=scope_facts.environment,mode=scope_facts.mode,epoch=1,observed_at_ns=now-1_000_000,expires_at_ns=now+3_000_000_000,source_digest_sha256='5'*64)
 verifier=auth.PinnedEd25519CtpActionPermitVerifier((key,))
 action_adapter=auth.CtpManagedActionAuthorityAdapter(store=store,scope=execution_scope,owner_handle=owner,writer_lease=lease,scope_resolver=scope_resolver,permit_source=PermitSource(permit),signature_verifier=verifier,revocation_source=RevSource(rev),fence_source=FenceSource(fence),trusted_clock=Clock(now))
 store.stage_ctp_dispatch_command(execution_scope,command_id,'SUBMIT',request,approval_use_id=permit_id,approval_digest=permit.digest,session_binding=session_payload,writer_lease=lease,managed_intent_id=intent,order_ref=reservation.order_ref,session_generation_id=active.session_generation_id,dispatch_front_id=active.dispatch_front_id,dispatch_session_id=active.dispatch_session_id,native_request_id=native_request_id,local_queue_receipt_id='a'*32)
 store.record_ctp_dispatch_queue_receipt(execution_scope,command_id,{'kind':'command_receipt','command':'submit','receipt_id':'a'*32,'queued':True},writer_lease=lease)
 command=store.read_ctp_dispatch_command(execution_scope,command_id)
 return locals()

with tempfile.TemporaryDirectory(prefix='action-authority-real-store-') as td:
 root=Path(td)
 # Real Store stages and the concrete sealed-config resolver signs a command whose
 # login account and contract fields differ from its protected synthetic config.
 bad=setup_case(root,'misbinding',login_matches=False,payload_matches=False)
 checked=bad['action_adapter'].verify_action(bad['command'],now_ns=time.time_ns())
 assert type(checked).__name__=='CtpDispatchAuthority'
 assert bad['facts'][1:] != (bad['config']['broker_id'],bad['config']['user_id'])
 claim=bad['store'].claim_ctp_dispatch_command_for_session(bad['execution_scope'],bad['command_id'],owner_handle=bad['owner'],writer_lease=bad['lease'],authority_verifier=bad['action_adapter'],required_local_queue_receipt_id='a'*32)
 assert claim is not None and claim.command.status=='CLAIMED'
 print('MISBINDING_COUNTEREXAMPLE: actual V17 Store staged and session-claimed a signed request with mismatched login BrokerID/UserID and wrong InstrumentID/ExchangeID; native SDK calls=0')
 bad['store'].close()

 # Test transaction time after the actual adapter returns its freshness-capped
 # authority. Each run gets a separate real Store/account owner.
 for label, delay in [('before',100_000_000),('after',250_000_001)]:
  case=setup_case(root,label,login_matches=True,payload_matches=True)
  t0=time.time_ns()
  # Snapshot observation is tied to t0 just before the Store calls the verifier.
  case['action_adapter']._revocation_source.s=auth.CtpManagedActionRevocationSnapshot(permit_id=case['permit'].permit_id,key_id=case['permit'].key_id,epoch=1,revoked=False,key_active=True,observed_at_ns=t0-1_000_000,valid_until_ns=t0+2_000_000_000,source_digest_sha256='6'*64)
  case['action_adapter']._fence_source.s=auth.CtpManagedActionWriterFenceSnapshot(fence_id='qa.fence',owner_id='qa.owner',account_fingerprint_sha256=case['scope_facts'].account_fingerprint_sha256,environment=case['scope_facts'].environment,mode=case['scope_facts'].mode,epoch=1,observed_at_ns=t0-1_000_000,expires_at_ns=t0+3_000_000_000,source_digest_sha256='7'*64)
  case['action_adapter']._trusted_clock.n=t0
  times=iter([t0,t0,t0,t0+delay])
  original_time_ns=time.time_ns
  with patch.object(time,'time_ns',lambda: next(times,t0+delay)):
   try:
    claim=case['store'].claim_ctp_dispatch_command_for_session(case['execution_scope'],case['command_id'],owner_handle=case['owner'],writer_lease=case['lease'],authority_verifier=case['action_adapter'],required_local_queue_receipt_id='a'*32)
    outcome='CLAIMED' if claim is not None else 'NONE'
   except Exception as exc:
    outcome=type(exc).__name__+': '+str(exc)
  state=case['store'].read_ctp_dispatch_command(case['execution_scope'],case['command_id']).status
  if label=='before':
   assert outcome=='CLAIMED' and state=='CLAIMED', (outcome,state)
  else:
   assert outcome.startswith('ContractValidationError: CTP dispatch authority is expired'), (outcome,state)
   assert state=='READY', state
  print(f'FRESHNESS_{label.upper()}: cutoff=t0+249ms; claim_delay={delay}ns; result={outcome}; row={state}; fake native dispatches=0')
  case['store'].close()

