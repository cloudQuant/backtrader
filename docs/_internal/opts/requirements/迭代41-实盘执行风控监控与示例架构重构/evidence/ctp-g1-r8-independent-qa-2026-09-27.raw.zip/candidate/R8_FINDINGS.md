# R8 Windows inert custodian probe findings

Status: REJECTED / G1 CLOSED. This is a local inert prototype, not an integration backend or acceptance claim.

Reviewer checklist SHA-256: `ba9c16e90be9f3ff96a181a53755eb40e26c29e4cb41e176ed174333ca4cb816` (expected `ba9c16e90be9f3ff96a181a53755eb40e26c29e4cb41e176ed174333ca4cb816`).
Native source SHA-256: `c843712eb3e999b88790f0adb18848cd6d2341db5f2efeb19a8eee3a32a80dce`.
Trial log: `r8_trials.json` SHA-256 `4c412a14af1cb5fe5ea5f6ff39f23d7952187e5f60bc2015f70d0098af6cf58a`.

## Process custody exercised

The external Python runner received a duplicated outer kill-on-close Job handle. The native supervisor, caller, custodian, and worker were distinct processes; the worker Job/process/thread handles were inherited by the custodian before READY and retained by the supervisor. The outer Job kill probe terminated the entire process tree and observed ActiveProcesses=0 plus signaled retained process handles.

Normal short work reached a caller result with worker exit code 0, worker Job ActiveProcesses=0, custodian exit, and controls released only after the exact worker proof. Not-ready worker/custodian cases rejected. Worker setup, Join, custodian, and cleanup stalls returned UNKNOWN while controls were held; the supervisor then killed the relevant Jobs and observed worker exit plus Job empty. A one-descendant case observed multiple worker Job members before termination and zero afterward.

## Deadline counterexample

The synchronous 2 MiB caller admission write remained blocked beyond the 1200 ms request deadline: the trial records `caller_api_returned=false`, `caller_blocked_at_deadline=true`, and caller decision after cleanup at 1234 ms. The independent supervisor terminated the caller Job; that later termination is not a successful caller return. This is a fail-closed counterexample, not a pass. The overlapped probe returned UNKNOWN at 1016 ms with `io_pending=1`; the caller-process reaper thread owned the pipe handle, OVERLAPPED, event, and 2 MiB buffer until CancelIoEx succeeded and the final completion reported error 995 (`ERROR_OPERATION_ABORTED`). This was not an independently surviving reaper process, and delayed completion plus cancellation-error races were not injected.

## Synchronous boundaries and scope

The trial log records observed integer-millisecond durations for CreateJobObject, CreatePipe, CreateProcessW, AssignProcessToJobObject, ResumeThread, CreateNamedPipeW, CreateFileW, ConnectNamedPipe, Job queries/termination, process waits, and CloseHandle. These samples are not upper bounds. Setup and prewarm occurred before admission and outside request D; READY was required before GO. The inner worker Job assignment was post-CreateProcessW but before ResumeThread while the new process was suspended. The outer inherited Job was already active at process creation, and the external runner held a duplicate control handle once the launcher emitted OUTER_JOB_CONTROL_READY.

Whole-command caller deadline remains unproven. The Python runner calls synchronous subprocess.Popen; before it returns, Python has neither the launcher process handle nor a duplicated outer Job handle. After Popen, the harness waits with an 8-second watchdog, not D=1200 ms. The OUTER_JOB_CONTROL_READY marker is only emitted after CreateJobObject/OpenProcess/DuplicateHandle return, and the separate outer kill probe proved 31 ms termination-to-Job-empty only after this control existed. The experiment did not inject hangs in Python CreateProcessW/Popen, native CreateProcessW before/after child creation, ResumeThread, pipe setup, QueryInformationJobObject, TerminateJobObject, CancelIoEx, or CloseHandle. The current evidence therefore does not prove whole-command caller return by D or exact Job-empty proof when a synchronous control operation hangs. The checklist's untested P02/P03/P04/P08-P11/P13-P15/P17-P21 gaps remain; see the machine-readable coverage map.

No CTP/provider/config/credentials/service/default route was involved. No repository files were modified.
