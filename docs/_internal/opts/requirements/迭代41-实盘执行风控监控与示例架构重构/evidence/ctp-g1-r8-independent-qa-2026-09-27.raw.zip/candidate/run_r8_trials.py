import ctypes
import hashlib
import json
import msvcrt
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXE = ROOT / "r8_custodian.exe"
CHECKLIST_SOURCE = Path(r"D:\temp\iteration41-g1-r8-reaper-review-20260927\R8_REAPER_REVIEW_CHECKLIST.md")
CHECKLIST_COPY = ROOT / "R8_REAPER_REVIEW_CHECKLIST.md"
EXPECTED_CHECKLIST_SHA = "ba9c16e90be9f3ff96a181a53755eb40e26c29e4cb41e176ed174333ca4cb816"
BUILD_BAT = ROOT / "build_r8.bat"
BUILD_LOG = ROOT / "r8_build.log"
TRIALS = ROOT / "r8_trials.json"
NOTES = ROOT / "R8_FINDINGS.md"
MANIFEST = ROOT / "r8_manifest.json"
RECEIPT = ROOT / "r8_receipt.json"

K32 = ctypes.WinDLL("kernel32", use_last_error=True)
HANDLE = ctypes.c_void_p
BOOL = ctypes.c_int
DWORD = ctypes.c_uint32
LPDWORD = ctypes.POINTER(DWORD)


class JobBasicAccounting(ctypes.Structure):
    _fields_ = [
        ("TotalUserTime", ctypes.c_int64),
        ("TotalKernelTime", ctypes.c_int64),
        ("ThisPeriodTotalUserTime", ctypes.c_int64),
        ("ThisPeriodTotalKernelTime", ctypes.c_int64),
        ("TotalPageFaultCount", DWORD),
        ("TotalProcesses", DWORD),
        ("ActiveProcesses", DWORD),
        ("TotalTerminatedProcesses", DWORD),
    ]


class FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", DWORD), ("dwHighDateTime", DWORD)]


K32.PeekNamedPipe.argtypes = [HANDLE, ctypes.c_void_p, DWORD, LPDWORD, LPDWORD, LPDWORD]
K32.PeekNamedPipe.restype = BOOL
K32.OpenProcess.argtypes = [DWORD, BOOL, DWORD]
K32.OpenProcess.restype = HANDLE
K32.QueryInformationJobObject.argtypes = [HANDLE, ctypes.c_int, ctypes.c_void_p, DWORD, LPDWORD]
K32.QueryInformationJobObject.restype = BOOL
K32.TerminateJobObject.argtypes = [HANDLE, DWORD]
K32.TerminateJobObject.restype = BOOL
K32.WaitForSingleObject.argtypes = [HANDLE, DWORD]
K32.WaitForSingleObject.restype = DWORD
K32.GetProcessTimes.argtypes = [HANDLE, ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME)]
K32.GetProcessTimes.restype = BOOL
K32.CloseHandle.argtypes = [HANDLE]
K32.CloseHandle.restype = BOOL

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SYNCHRONIZE = 0x00100000
JOB_OBJECT_QUERY = 0x0004
JOB_OBJECT_TERMINATE = 0x0008
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def job_active(handle_value: int):
    info = JobBasicAccounting()
    ok = K32.QueryInformationJobObject(HANDLE(handle_value), 1, ctypes.byref(info), ctypes.sizeof(info), None)
    if not ok:
        return None, ctypes.get_last_error()
    return int(info.ActiveProcesses), 0


def peek_read(proc, timeout_s: float, until_marker: str = "") -> bytes:
    fd = proc.stdout.fileno()
    os_handle = HANDLE(msvcrt.get_osfhandle(fd))
    out = bytearray()
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        available = DWORD()
        ok = K32.PeekNamedPipe(os_handle, None, 0, None, ctypes.byref(available), None)
        if ok and available.value:
            out.extend(os.read(fd, min(int(available.value), 65536)))
            if until_marker and until_marker.encode("ascii") in out:
                return bytes(out)
            continue
        if proc.poll() is not None:
            break
        time.sleep(0.003)
    return bytes(out)


def parse_marker(line: str, name: str) -> dict:
    result = {"marker": name}
    for key, value in re.findall(r"([A-Za-z_]+)=([^\s]+)", line):
        if value.isdigit():
            result[key] = int(value)
        else:
            result[key] = value
    return result


def open_pid_facts(pid: int):
    handle = K32.OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None, ctypes.get_last_error()
    creation = FILETIME()
    exit_time, kernel_time, user_time = FILETIME(), FILETIME(), FILETIME()
    ok = K32.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time), ctypes.byref(kernel_time), ctypes.byref(user_time))
    if not ok:
        e = ctypes.get_last_error()
        K32.CloseHandle(handle)
        return None, e
    created = (int(creation.dwHighDateTime) << 32) | int(creation.dwLowDateTime)
    return {"pid": pid, "creation_time_100ns": created, "handle": handle}, 0


def build():
    vcvars = r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
    tmp = ROOT / ".tmp"
    tmp.mkdir(exist_ok=True)
    bat = "\r\n".join(
        [
            "@echo off",
            f'set "TEMP={tmp}"',
            f'set "TMP={tmp}"',
            f'call "{vcvars}" >NUL',
            "cl /nologo /std:c++17 /EHsc /O2 /W4 /Fe:r8_custodian.exe r8_custodian.cpp",
            "exit /b %ERRORLEVEL%",
            "",
        ]
    )
    BUILD_BAT.write_text(bat, encoding="ascii", newline="")
    p = subprocess.run(["cmd.exe", "/d", "/c", str(BUILD_BAT)], cwd=ROOT, capture_output=True, timeout=90)
    raw = p.stdout + p.stderr
    BUILD_LOG.write_bytes(raw)
    return {"exit_code": p.returncode, "output": raw.decode("utf-8", errors="replace"), "exe_exists": EXE.exists(),
            "exe_sha256": sha256(EXE) if EXE.exists() else None}


def run_mode(mode: str):
    p = subprocess.Popen([str(EXE), "--outer-run", mode, str(os.getpid())], cwd=ROOT,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
    try:
        output, _ = p.communicate(timeout=8.0)
    except subprocess.TimeoutExpired as exc:
        # If the wrapper has emitted its early control marker, this caller can kill
        # the outer Job even while later native setup is blocked.
        captured = exc.output or b""
        partial = (captured + peek_read(p, 0.01)).decode("utf-8", errors="replace")
        marker = next((line for line in partial.splitlines() if line.startswith("OUTER_JOB_CONTROL_READY ")), "")
        marker_name = "OUTER_JOB_CONTROL_READY"
        if not marker:
            marker = next((line for line in partial.splitlines() if line.startswith("OUTER_JOB_READY ")), "")
            marker_name = "OUTER_JOB_READY"
        remote = parse_marker(marker, marker_name).get("external_job_handle") if marker else None
        outer_kill = None
        if remote:
            before, _ = job_active(remote)
            start = time.monotonic_ns()
            term_ok = bool(K32.TerminateJobObject(HANDLE(remote), 0xE8FF0001))
            term_error = 0 if term_ok else ctypes.get_last_error()
            stop = time.monotonic() + 2.0
            after = None
            while time.monotonic() < stop:
                after, err = job_active(remote)
                if after == 0:
                    break
                time.sleep(0.005)
            outer_kill = {"active_before": before, "terminate_returned": term_ok, "terminate_error": term_error,
                          "active_after": after, "terminate_elapsed_ns": time.monotonic_ns() - start,
                          "source": "external runner duplicated Job handle"}
            K32.CloseHandle(HANDLE(remote))
        p.kill()
        tail, _ = p.communicate(timeout=4.0)
        return {"mode": mode, "runner_timeout": True, "partial_output": partial + tail.decode("utf-8", errors="replace"),
                "outer_job_kill": outer_kill}
    text = output.decode("utf-8", errors="replace")
    marker_line = next((line for line in text.splitlines() if line.startswith("OUTER_JOB_CONTROL_READY ")), "")
    marker_name = "OUTER_JOB_CONTROL_READY"
    if not marker_line:
        marker_line = next((line for line in text.splitlines() if line.startswith("OUTER_JOB_READY ")), "")
        marker_name = "OUTER_JOB_READY"
    marker = parse_marker(marker_line, marker_name) if marker_line else {}
    remote = marker.get("external_job_handle")
    active_after = active_error = None
    if remote:
        active_after, active_error = job_active(remote)
        K32.CloseHandle(HANDLE(remote))
    scenario_line = next((line for line in reversed(text.splitlines()) if line.startswith("{")), "")
    scenario = json.loads(scenario_line) if scenario_line else None
    return {"mode": mode, "runner_timeout": False, "exit_code": p.returncode, "outer_marker": marker,
            "outer_job_active_after_process_exit": active_after, "outer_job_query_error": active_error,
            "raw_output": text, "scenario": scenario}


def run_outer_job_kill_probe():
    p = subprocess.Popen([str(EXE), "--outer-run", "block", str(os.getpid())], cwd=ROOT,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
    partial = peek_read(p, 6.0, "SUPERVISOR_REQUEST_BARRIER").decode("utf-8", errors="replace")
    lines = partial.splitlines()
    outer_line = next((line for line in lines if line.startswith("OUTER_JOB_CONTROL_READY ")), "")
    outer_name = "OUTER_JOB_CONTROL_READY"
    if not outer_line:
        outer_line = next((line for line in lines if line.startswith("OUTER_JOB_READY ")), "")
        outer_name = "OUTER_JOB_READY"
    barrier_line = next((line for line in lines if line.startswith("SUPERVISOR_REQUEST_BARRIER ")), "")
    outer = parse_marker(outer_line, outer_name) if outer_line else {}
    barrier = parse_marker(barrier_line, "SUPERVISOR_REQUEST_BARRIER") if barrier_line else {}
    remote = outer.get("external_job_handle")
    identities = {}
    opened = []
    for role in ("child", "worker", "custodian", "caller"):
        key = "child_pid" if role == "child" else role + "_pid"
        pid = outer.get(key) if role == "child" else barrier.get(key)
        if pid:
            facts, error = open_pid_facts(pid)
            identities[role] = facts if facts else {"pid": pid, "open_error": error}
            if facts:
                opened.append((role, facts["handle"]))
    before, before_error = job_active(remote) if remote else (None, 6)
    t0 = time.monotonic_ns()
    term = bool(remote and K32.TerminateJobObject(HANDLE(remote), 0xE8FF0002))
    term_error = 0 if term else ctypes.get_last_error()
    waits = {}
    for role, handle in opened:
        waits[role] = K32.WaitForSingleObject(HANDLE(handle), 2000)
    after = None
    qerr = 0
    deadline = time.monotonic() + 2.0
    while remote and time.monotonic() < deadline:
        after, qerr = job_active(remote)
        if after == 0:
            break
        time.sleep(0.005)
    elapsed = time.monotonic_ns() - t0
    p.wait(timeout=4.0)
    tail = b""
    try:
        tail = os.read(p.stdout.fileno(), 65536)
    except OSError:
        pass
    for _, handle in opened:
        K32.CloseHandle(HANDLE(handle))
    if remote:
        K32.CloseHandle(HANDLE(remote))
    return {"ready_markers": lines, "outer_marker": outer, "request_barrier": barrier,
            "external_reaper_pid": os.getpid(), "process_identities": {
                role: {k: v for k, v in facts.items() if k != "handle"} for role, facts in identities.items()},
            "active_before": before, "active_query_error_before": before_error,
            "terminate_job_returned": term, "terminate_job_error": term_error,
            "process_wait_results": waits, "wait_object_0": WAIT_OBJECT_0,
            "outer_job_active_after": after, "outer_job_query_error_after": qerr,
            "terminate_and_empty_elapsed_ns": elapsed, "launcher_exit_code": p.returncode,
            "tail_output": tail.decode("utf-8", errors="replace")}


def main():
    if os.name != "nt":
        raise SystemExit("This probe requires Windows.")
    shutil.copyfile(CHECKLIST_SOURCE, CHECKLIST_COPY)
    checklist_hash = sha256(CHECKLIST_COPY)
    build_result = build()
    if not EXE.exists():
        raise SystemExit("Native build did not create executable; see r8_build.log")
    modes = ["normal", "prewarm-not-ready", "custodian-not-ready", "block", "worker-join-block",
             "cleanup-block", "worker-write-block", "admission-sync", "admission-overlapped", "descendant"]
    rows = [run_mode(mode) for mode in modes]
    outer_kill = run_outer_job_kill_probe()
    assertions = []
    by_mode = {r["mode"]: r for r in rows}

    def check(name, condition, evidence):
        assertions.append({"name": name, "pass": bool(condition), "evidence": evidence})

    check("checklist_hash_matches_parent", checklist_hash == EXPECTED_CHECKLIST_SHA, checklist_hash)
    normal = by_mode["normal"].get("scenario") or {}
    check("normal_exact_exit_job_empty_release", normal.get("status") == "SUCCEEDED" and
          normal.get("worker_exact_exit_and_job_empty") and normal.get("controls_released_after_exact_proof"), normal)
    check("normal_outer_job_drained", by_mode["normal"].get("outer_job_active_after_process_exit") == 0, by_mode["normal"])
    for mode in ("prewarm-not-ready", "custodian-not-ready"):
        s = by_mode[mode].get("scenario") or {}
        check(f"{mode}_rejects_without_success", s.get("status") == "REJECTED_NOT_READY" and not s.get("request_admitted", False), s)
    for mode in ("block", "worker-join-block", "cleanup-block", "worker-write-block"):
        s = by_mode[mode].get("scenario") or {}
        check(f"{mode}_unknown_retains_then_proves_cleanup", s.get("status") == "UNKNOWN" and
              s.get("controls_retained_at_unknown") and s.get("worker_exact_exit_and_job_empty"), s)
    sync = by_mode["admission-sync"].get("scenario") or {}
    check("sync_admission_is_counterexample", sync.get("status") == "UNKNOWN" and
          not sync.get("caller_api_returned") and sync.get("caller_blocked_at_deadline") and
          sync.get("caller_watchdog_terminated") and sync.get("caller_decision_ms", 0) >= 1200, sync)
    overlap = by_mode["admission-overlapped"].get("scenario") or {}
    api_line = overlap.get("caller_api_line", "")
    check("overlapped_unknown_has_pending_owner_and_drains", overlap.get("status") == "UNKNOWN" and
          "io_pending=1" in api_line and "owner_thread_id=" in api_line and "CANCEL_RESULT issued=" in api_line and
          "REAPER_DONE io_complete=1" in api_line, overlap)
    desc = by_mode["descendant"].get("scenario") or {}
    check("descendant_is_job_member_then_job_empty", desc.get("worker_job_active_before_supervisor_cleanup", 0) >= 2 and
          desc.get("worker_exact_exit_and_job_empty"), desc)
    check("external_duplicate_outer_job_kills_whole_tree", outer_kill.get("terminate_job_returned") and
          outer_kill.get("outer_job_active_after") == 0 and all(v == WAIT_OBJECT_0 for v in outer_kill.get("process_wait_results", {}).values()), outer_kill)

    failures = [a for a in assertions if not a["pass"]]
    review_coverage = {
        "P01": "partial: custodian-not-ready rejects; startup itself was prewarmed; no admitted request before ready",
        "P02": "not tested: actual CreateProcessW call-before blocking shim not injected",
        "P03": "not tested: actual process-created/API-return-blocked shim not injected; outer Job inheritance was observed for live descendants",
        "P04": "partial: suspended child assignment before ResumeThread observed; ResumeThread hang injection not performed",
        "P05": "FAIL observed: synchronous 2 MiB admission write exceeded 1200ms; parent had to terminate caller Job",
        "P06": "partial: overlapped caller write pending at API return with caller-side reaper thread ownership; Connect/read/body pending not tested",
        "P07": "partial: CancelIoEx and final completion recorded; deterministic delayed completion after successful cancel not injected",
        "P08": "not tested: CancelIoEx ERROR_NOT_FOUND completion race not injected",
        "P09": "not tested: cancellation errors/no completion not injected",
        "P10": "not tested: I/O owner-death with live peer not injected",
        "P11": "not tested: malformed/short/extra frames not included in this minimal prototype",
        "P12": "partial: worker plus one child observed in worker Job; grandchild/breakaway variants not tested",
        "P13": "partial: parent independently queries its Job handle; injected false-zero/query failure not tested",
        "P14": "partial: worker setup/Join/cleanup stalls were terminated by separate supervisor; native Terminate/Query/Close API hangs not injected",
        "P15": "not tested: delayed Job-zero query and post-D cleanup distinction not injected",
        "P16": "partial: normal exact response and hanging worker/no response tested; frame-before-empty race not separately gated",
        "P17": "partial: one supervisor absolute request deadline; setup calls are pre-admission and separately timed, not part of request D",
        "P18": "partial: UNKNOWN on response timeout; caller disconnect while server continues not separately injected",
        "P19": "partial: custodian Job kill and outer Job kill observed; reaper death with duplicated request Job survivor not tested",
        "P20": "not tested: concurrent/reused request slots not included",
        "P21": "partial: normal timely control passes; delayed-late-success suppression after D not separately gated",
    }
    trials = {
        "candidate": "R8 independent Windows lazy custodian inert prototype",
        "status": "REJECTED_G1_CLOSED",
        "platform": {"system": platform.platform(), "windows_version": list(sys.getwindowsversion()), "python": sys.version},
        "build": build_result,
        "checklist_sha256": checklist_hash,
        "scenarios": rows,
        "outer_job_kill_probe": outer_kill,
        "assertions": assertions,
        "failed_assertions": failures,
        "review_checklist_coverage": review_coverage,
        "limitations": [
            "The sync admission negative proves caller API did not return by D; watchdog process termination is not a successful bounded API return.",
            "The independent Python runner held a duplicated outer Job handle and could terminate/query the whole inert process tree. It did not hold the inner worker Job handle or prove inner worker exit details if the native supervisor itself blocks.",
            "The top-level Python subprocess.Popen call synchronously invokes CreateProcessW before Python receives a process handle or the native launcher can duplicate the outer Job handle into the runner; this setup is outside the request D and was not shim-blocked.",
            "The runner's outer communicate watchdog is 8 seconds after Popen returns, not the 1200 ms request budget. Its later Job termination is recovery evidence, not proof of caller return by D.",
            "The native launcher duplicates its outer Job handle to the Python runner only after CreateJobObject, OpenProcess, and DuplicateHandle return. The early control marker then precedes launcher assignment/pipe/child setup; the marker cannot cover hangs before it is emitted.",
            "CreateNamedPipeW, CreateFileW, ConnectNamedPipe, ResumeThread, Job query, TerminateJobObject, CancelIoEx, and CloseHandle are synchronous and were not shim-blocked at their pre-call/post-effect points.",
            "All prewarm work happened before request D; not-ready cases rejected, but a service startup hard deadline is not accepted by this test.",
            "OVERLAPPED cancellation/reaper evidence is one inert pipe write. The owner is a reaper thread in the caller process, not an independently surviving process; it does not establish all connect/read/write/cancellation error paths or IOCP behavior.",
            "The logged Win32 setup/query/terminate/wait/close durations are observed integer-millisecond samples only; zero or short samples do not bound a call that can hang synchronously.",
            "No CTP, native provider, service installation, protected configuration, credential, network route, default preflight, or repository source was accessed or changed.",
        ],
        "decision": "G1 remains closed; this prototype is evidence only and is not an acceptance claim.",
    }
    TRIALS.write_text(json.dumps(trials, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    findings = [
        "# R8 Windows inert custodian probe findings",
        "",
        "Status: REJECTED / G1 CLOSED. This is a local inert prototype, not an integration backend or acceptance claim.",
        "",
        f"Reviewer checklist SHA-256: `{checklist_hash}` (expected `{EXPECTED_CHECKLIST_SHA}`).",
        f"Native source SHA-256: `{sha256(ROOT / 'r8_custodian.cpp')}`.",
        f"Trial log: `{TRIALS.name}` SHA-256 `{sha256(TRIALS)}`.",
        "",
        "## Process custody exercised",
        "",
        "The external Python runner received a duplicated outer kill-on-close Job handle. The native supervisor, caller, custodian, and worker were distinct processes; the worker Job/process/thread handles were inherited by the custodian before READY and retained by the supervisor. The outer Job kill probe terminated the entire process tree and observed ActiveProcesses=0 plus signaled retained process handles.",
        "",
        "Normal short work reached a caller result with worker exit code 0, worker Job ActiveProcesses=0, custodian exit, and controls released only after the exact worker proof. Not-ready worker/custodian cases rejected. Worker setup, Join, custodian, and cleanup stalls returned UNKNOWN while controls were held; the supervisor then killed the relevant Jobs and observed worker exit plus Job empty. A one-descendant case observed multiple worker Job members before termination and zero afterward.",
        "",
        "## Deadline counterexample",
        "",
        "The synchronous 2 MiB caller admission write remained blocked beyond the 1200 ms request deadline: the trial records `caller_api_returned=false`, `caller_blocked_at_deadline=true`, and caller decision after cleanup at 1234 ms. The independent supervisor terminated the caller Job; that later termination is not a successful caller return. This is a fail-closed counterexample, not a pass. The overlapped probe returned UNKNOWN at 1016 ms with `io_pending=1`; the caller-process reaper thread owned the pipe handle, OVERLAPPED, event, and 2 MiB buffer until CancelIoEx succeeded and the final completion reported error 995 (`ERROR_OPERATION_ABORTED`). This was not an independently surviving reaper process, and delayed completion plus cancellation-error races were not injected.",
        "",
        "## Synchronous boundaries and scope",
        "",
        "The trial log records observed integer-millisecond durations for CreateJobObject, CreatePipe, CreateProcessW, AssignProcessToJobObject, ResumeThread, CreateNamedPipeW, CreateFileW, ConnectNamedPipe, Job queries/termination, process waits, and CloseHandle. These samples are not upper bounds. Setup and prewarm occurred before admission and outside request D; READY was required before GO. The inner worker Job assignment was post-CreateProcessW but before ResumeThread while the new process was suspended. The outer inherited Job was already active at process creation, and the external runner held a duplicate control handle once the launcher emitted OUTER_JOB_CONTROL_READY.",
        "",
        "Whole-command caller deadline remains unproven. The Python runner calls synchronous subprocess.Popen; before it returns, Python has neither the launcher process handle nor a duplicated outer Job handle. After Popen, the harness waits with an 8-second watchdog, not D=1200 ms. The OUTER_JOB_CONTROL_READY marker is only emitted after CreateJobObject/OpenProcess/DuplicateHandle return, and the separate outer kill probe proved 31 ms termination-to-Job-empty only after this control existed. The experiment did not inject hangs in Python CreateProcessW/Popen, native CreateProcessW before/after child creation, ResumeThread, pipe setup, QueryInformationJobObject, TerminateJobObject, CancelIoEx, or CloseHandle. The current evidence therefore does not prove whole-command caller return by D or exact Job-empty proof when a synchronous control operation hangs. The checklist's untested P02/P03/P04/P08-P11/P13-P15/P17-P21 gaps remain; see the machine-readable coverage map.",
        "",
        "No CTP/provider/config/credentials/service/default route was involved. No repository files were modified.",
    ]
    NOTES.write_text("\n".join(findings) + "\n", encoding="utf-8")
    payload_names = ["g1_r8_probe.cpp", "r8_custodian.cpp", "r8_custodian.obj", "r8_custodian.exe", "run_r8_trials.py", "build_r8.bat",
                     "r8_build.log", "r8_trials.json", "R8_FINDINGS.md", "R8_REAPER_REVIEW_CHECKLIST.md"]
    manifest = {"candidate": "R8 independent Windows lazy custodian inert prototype",
                "status": "REJECTED_G1_CLOSED", "payload_sha256": {n: sha256(ROOT / n) for n in payload_names},
                "decision": "Synchronous admission caller did not return by the absolute request deadline; untested native blocking boundaries remain.",
                "assertion_count": len(assertions), "failed_assertions": failures,
                "checklist_sha256": checklist_hash}
    MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    manifest_hash = sha256(MANIFEST)
    (ROOT / "r8_manifest.sha256").write_text(f"{manifest_hash}  r8_manifest.json\n", encoding="ascii")
    receipt = {"manifest": "r8_manifest.json", "manifest_sha256": manifest_hash,
               "status": "REJECTED_G1_CLOSED", "decision": manifest["decision"],
               "checklist_sha256": checklist_hash, "trials_sha256": sha256(TRIALS),
               "source_sha256": sha256(ROOT / "r8_custodian.cpp"),
               "no_repo_changes": True, "no_provider_or_credentials": True}
    RECEIPT.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    receipt_hash = sha256(RECEIPT)
    (ROOT / "r8_receipt.sha256").write_text(f"{receipt_hash}  r8_receipt.json\n", encoding="ascii")
    print(json.dumps({"manifest_sha256": manifest_hash, "receipt_sha256": receipt_hash,
                      "source_sha256": sha256(ROOT / "r8_custodian.cpp"),
                      "trials_sha256": sha256(TRIALS), "assertions": len(assertions),
                      "failed_assertions": len(failures), "decision": trials["decision"]}, indent=2))


if __name__ == "__main__":
    main()
