#define NOMINMAX
#include <windows.h>
#include <processthreadsapi.h>
#include <stdint.h>
#include <sddl.h>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>

static const DWORD kKilledExit = 0xE1000001;
static const DWORD kCallerKilledExit = 0xE1000002;

std::wstring ModulePath() {
    std::vector<wchar_t> buf(32768);
    DWORD n = GetModuleFileNameW(nullptr, buf.data(), (DWORD)buf.size());
    return n ? std::wstring(buf.data(), n) : L"";
}
std::wstring Quote(const std::wstring& s) {
    return L"\"" + s + L"\"";
}
std::wstring HandleArg(HANDLE h) {
    std::wstringstream ss;
    ss << (unsigned long long)(uintptr_t)h;
    return ss.str();
}
HANDLE ParseHandle(const wchar_t* s) {
    return (HANDLE)(uintptr_t)_wcstoui64(s, nullptr, 10);
}
void SetInherit(HANDLE h, bool yes) {
    SetHandleInformation(h, HANDLE_FLAG_INHERIT, yes ? HANDLE_FLAG_INHERIT : 0);
}
bool ValidHandle(HANDLE h) {
    DWORD flags = 0;
    return h && h != INVALID_HANDLE_VALUE && GetHandleInformation(h, &flags);
}
std::string WinErr(const char* where) {
    std::ostringstream s;
    s << where << " winerr=" << GetLastError();
    return s.str();
}
bool WriteExactSync(HANDLE h, const void* data, DWORD size) {
    const char* p = (const char*)data;
    DWORD doneTotal = 0;
    while (doneTotal < size) {
        DWORD done = 0;
        if (!WriteFile(h, p + doneTotal, size - doneTotal, &done, nullptr) || !done) return false;
        doneTotal += done;
    }
    return true;
}
bool ReadLineBlocking(HANDLE h, std::string& out) {
    out.clear();
    for (;;) {
        char c = 0;
        DWORD got = 0;
        if (!ReadFile(h, &c, 1, &got, nullptr) || !got) return false;
        if (c == '\n') return true;
        if (c != '\r') out.push_back(c);
        if (out.size() > 4096) return false;
    }
}
bool ReadLineDeadline(HANDLE h, ULONGLONG deadline, std::string& out) {
    out.clear();
    while (GetTickCount64() < deadline) {
        DWORD avail = 0;
        if (!PeekNamedPipe(h, nullptr, 0, nullptr, &avail, nullptr)) return false;
        if (!avail) { Sleep(1); continue; }
        char c = 0;
        DWORD got = 0;
        if (!ReadFile(h, &c, 1, &got, nullptr) || !got) return false;
        if (c == '\n') return true;
        if (c != '\r') out.push_back(c);
        if (out.size() > 4096) return false;
    }
    return false;
}
bool WritePipeOverlapped(HANDLE h, const void* data, DWORD size, DWORD timeoutMs, DWORD* writtenOut = nullptr) {
    OVERLAPPED ov{};
    ov.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!ov.hEvent) return false;
    DWORD done = 0;
    BOOL ok = WriteFile(h, data, size, &done, &ov);
    if (!ok && GetLastError() == ERROR_IO_PENDING) {
        DWORD wait = WaitForSingleObject(ov.hEvent, timeoutMs);
        if (wait == WAIT_OBJECT_0) {
            ok = GetOverlappedResult(h, &ov, &done, FALSE);
        } else {
            CancelIoEx(h, &ov);
            WaitForSingleObject(ov.hEvent, 250);
            DWORD ignored = 0;
            GetOverlappedResult(h, &ov, &ignored, FALSE);
            CloseHandle(ov.hEvent);
            return false;
        }
    }
    if (writtenOut) *writtenOut = done;
    CloseHandle(ov.hEvent);
    return ok != FALSE && done == size;
}
bool ReadPipeOverlapped(HANDLE h, void* data, DWORD size, DWORD timeoutMs) {
    OVERLAPPED ov{};
    ov.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!ov.hEvent) return false;
    DWORD done = 0;
    BOOL ok = ReadFile(h, data, size, &done, &ov);
    if (!ok && GetLastError() == ERROR_IO_PENDING) {
        DWORD wait = WaitForSingleObject(ov.hEvent, timeoutMs);
        if (wait == WAIT_OBJECT_0) {
            ok = GetOverlappedResult(h, &ov, &done, FALSE);
        } else {
            CancelIoEx(h, &ov);
            WaitForSingleObject(ov.hEvent, 250);
            DWORD ignored = 0;
            GetOverlappedResult(h, &ov, &ignored, FALSE);
            CloseHandle(ov.hEvent);
            return false;
        }
    }
    CloseHandle(ov.hEvent);
    return ok != FALSE && done == size;
}
bool WriteFrame(HANDLE pipe, const std::string& s, DWORD timeoutMs = 1000) {
    DWORD n = (DWORD)s.size();
    return WritePipeOverlapped(pipe, &n, sizeof(n), timeoutMs) &&
           WritePipeOverlapped(pipe, s.data(), n, timeoutMs);
}
bool ReadFrame(HANDLE pipe, std::string& s, DWORD timeoutMs) {
    DWORD n = 0;
    if (!ReadPipeOverlapped(pipe, &n, sizeof(n), timeoutMs) || n > 4 * 1024 * 1024) return false;
    s.assign(n, '\0');
    if (!n) return true;
    return ReadPipeOverlapped(pipe, &s[0], n, timeoutMs);
}

bool CreateExtended(
    const std::wstring& command,
    const std::vector<HANDLE>& inheritHandles,
    HANDLE jobToAssign,
    HANDLE stdIn,
    HANDLE stdOut,
    PROCESS_INFORMATION& pi,
    DWORD extraFlags = 0
) {
    STARTUPINFOEXW sx{};
    sx.StartupInfo.cb = sizeof(sx);
    if (stdIn || stdOut) {
        sx.StartupInfo.dwFlags |= STARTF_USESTDHANDLES;
        sx.StartupInfo.hStdInput = stdIn ? stdIn : GetStdHandle(STD_INPUT_HANDLE);
        sx.StartupInfo.hStdOutput = stdOut ? stdOut : GetStdHandle(STD_OUTPUT_HANDLE);
        sx.StartupInfo.hStdError = stdOut ? stdOut : GetStdHandle(STD_ERROR_HANDLE);
    }
    SIZE_T bytes = 0;
    DWORD attrs = (DWORD)(!inheritHandles.empty()) + (DWORD)(jobToAssign != nullptr);
    if (!attrs) {
        std::vector<wchar_t> mutableCmd(command.begin(), command.end());
        mutableCmd.push_back(L'\0');
        STARTUPINFOW si = sx.StartupInfo;
        return CreateProcessW(nullptr, mutableCmd.data(), nullptr, nullptr, FALSE, extraFlags,
                              nullptr, nullptr, &si, &pi) != FALSE;
    }
    InitializeProcThreadAttributeList(nullptr, attrs, 0, &bytes);
    std::vector<unsigned char> storage(bytes);
    sx.lpAttributeList = (LPPROC_THREAD_ATTRIBUTE_LIST)storage.data();
    if (!InitializeProcThreadAttributeList(sx.lpAttributeList, attrs, 0, &bytes)) return false;
    bool ok = true;
    if (!inheritHandles.empty()) {
        ok = UpdateProcThreadAttribute(
            sx.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
            (void*)inheritHandles.data(), inheritHandles.size() * sizeof(HANDLE), nullptr, nullptr) != FALSE;
    }
    HANDLE jobs[1] = { jobToAssign };
    if (ok && jobToAssign) {
        ok = UpdateProcThreadAttribute(
            sx.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_JOB_LIST,
            jobs, sizeof(jobs), nullptr, nullptr) != FALSE;
    }
    std::vector<wchar_t> mutableCmd(command.begin(), command.end());
    mutableCmd.push_back(L'\0');
    if (ok) {
        ok = CreateProcessW(nullptr, mutableCmd.data(), nullptr, nullptr,
                            !inheritHandles.empty(), extraFlags | EXTENDED_STARTUPINFO_PRESENT,
                            nullptr, nullptr, &sx.StartupInfo, &pi) != FALSE;
    }
    DeleteProcThreadAttributeList(sx.lpAttributeList);
    return ok;
}

HANDLE CreateJob() {
    HANDLE job = CreateJobObjectW(nullptr, nullptr);
    if (!job) return nullptr;
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (!SetInformationJobObject(job, JobObjectExtendedLimitInformation, &limits, sizeof(limits))) {
        CloseHandle(job);
        return nullptr;
    }
    return job;
}
bool QueryActive(HANDLE job, DWORD& active) {
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION info{};
    if (!QueryInformationJobObject(job, JobObjectBasicAccountingInformation, &info, sizeof(info), nullptr)) return false;
    active = info.ActiveProcesses;
    return true;
}
bool IsInJob(HANDLE process, HANDLE job, bool& answer) {
    BOOL inJob = FALSE;
    if (!IsProcessInJob(process, job, &inJob)) return false;
    answer = inJob != FALSE;
    return true;
}

int SleeperMain() {
    Sleep(INFINITE);
    return 0;
}
int WorkerMain(int argc, wchar_t** argv) {
    BOOL inJob = FALSE;
    if (!IsProcessInJob(GetCurrentProcess(), nullptr, &inJob)) return 41;
    bool startupBlock = argc >= 3 && std::wstring(argv[2]) == L"startup-block";
    bool ignoreRequests = argc >= 3 && std::wstring(argv[2]) == L"ignore-requests";
    if (startupBlock) Sleep(INFINITE);
    std::ostringstream ready;
    ready << "WORKER_READY in_job=" << (inJob ? 1 : 0) << "\n";
    std::string readyText = ready.str();
    if (!WriteExactSync(GetStdHandle(STD_OUTPUT_HANDLE), readyText.data(), (DWORD)readyText.size())) return 42;
    if (ignoreRequests) Sleep(INFINITE);
    std::string command;
    if (!ReadLineBlocking(GetStdHandle(STD_INPUT_HANDLE), command)) return 43;
    if (command == "success" || command == "shutdown") {
        std::string done = command == "success" ? "DONE\n" : "BYE\n";
        WriteExactSync(GetStdHandle(STD_OUTPUT_HANDLE), done.data(), (DWORD)done.size());
        return 0;
    }
    if (command == "descendant_join") {
        SECURITY_ATTRIBUTES sa{ sizeof(sa), nullptr, TRUE };
        HANDLE childReady = CreateEventW(&sa, TRUE, FALSE, nullptr);
        if (!childReady) return 44;
        std::wstring exe = ModulePath();
        std::wstring childCmd = Quote(exe) + L" --spawner " + HandleArg(childReady);
        PROCESS_INFORMATION child{};
        bool made = CreateExtended(childCmd, { childReady }, nullptr, nullptr, nullptr, child);
        SetHandleInformation(childReady, HANDLE_FLAG_INHERIT, 0);
        if (!made) { CloseHandle(childReady); return 45; }
        CloseHandle(child.hThread);
        CloseHandle(child.hProcess);
        DWORD wait = WaitForSingleObject(childReady, 3000);
        CloseHandle(childReady);
        if (wait != WAIT_OBJECT_0) return 46;
        DWORD active = 0;
        std::ostringstream status;
        status << "DESCENDANTS_READY active_query_local_unavailable\n";
        std::string msg = status.str();
        WriteExactSync(GetStdHandle(STD_OUTPUT_HANDLE), msg.data(), (DWORD)msg.size());
        Sleep(INFINITE);
        return 0;
    }
    if (command.rfind("block:", 0) == 0) {
        std::string stage = command.substr(6);
        HANDLE setupHandle = nullptr;
        PROCESS_INFORMATION child{};
        if (stage == "create_process" || stage == "join") {
            std::wstring exe = ModulePath();
            std::wstring childCmd = Quote(exe) + L" --sleeper";
            if (!CreateExtended(childCmd, {}, nullptr, nullptr, nullptr, child)) return 48;
            if (stage == "create_process") {
                CloseHandle(child.hThread);
                setupHandle = child.hProcess;
            }
        } else if (stage == "pipe") {
            HANDLE r = nullptr, w = nullptr;
            if (!CreatePipe(&r, &w, nullptr, 0)) return 49;
            CloseHandle(w);
            setupHandle = r;
        } else if (stage == "token") {
            if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &setupHandle)) return 50;
        } else if (stage == "receipt") {
            setupHandle = CreateEventW(nullptr, TRUE, FALSE, nullptr);
            if (!setupHandle || !SetEvent(setupHandle)) return 51;
        }
        std::string msg = "STAGE_READY:" + stage + "\n";
        WriteExactSync(GetStdHandle(STD_OUTPUT_HANDLE), msg.data(), (DWORD)msg.size());
        if (stage == "join") {
            WaitForSingleObject(child.hProcess, INFINITE);
            return 0;
        }
        Sleep(INFINITE);
        if (setupHandle) CloseHandle(setupHandle);
        return 0;
    }
    return 47;
}
int CallerMain(int argc, wchar_t** argv) {
    if (argc < 8) return 51;
    HANDLE pipe = ParseHandle(argv[2]);
    HANDLE go = ParseHandle(argv[3]);
    HANDLE ready = ParseHandle(argv[4]);
    HANDLE modeOut = ParseHandle(argv[5]);
    DWORD timeoutMs = (DWORD)_wtoi(argv[6]);
    std::wstring mode = argv[7];
    SetEvent(ready);
    if (WaitForSingleObject(go, INFINITE) != WAIT_OBJECT_0) return 52;
    if (mode == L"admission-sync") {
        std::vector<char> payload(2 * 1024 * 1024, 'X');
        DWORD wrote = 0;
        BOOL ok = WriteFile(pipe, payload.data(), (DWORD)payload.size(), &wrote, nullptr);
        std::string s = ok ? "SYNC_WRITE_RETURNED\n" : "SYNC_WRITE_FAILED\n";
        WriteExactSync(modeOut, s.data(), (DWORD)s.size());
        return 53;
    }
    if (mode == L"admission-overlapped") {
        std::vector<char> payload(2 * 1024 * 1024, 'X');
        OVERLAPPED ov{};
        ov.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        DWORD wrote = 0;
        BOOL ok = WriteFile(pipe, payload.data(), (DWORD)payload.size(), &wrote, &ov);
        if (!ok && GetLastError() == ERROR_IO_PENDING) {
            DWORD wait = WaitForSingleObject(ov.hEvent, timeoutMs);
            if (wait != WAIT_OBJECT_0) {
                CancelIoEx(pipe, &ov);
                DWORD cancelWait = WaitForSingleObject(ov.hEvent, 300);
                DWORD finalBytes = 0;
                BOOL completed = cancelWait == WAIT_OBJECT_0 && GetOverlappedResult(pipe, &ov, &finalBytes, FALSE);
                std::ostringstream s;
                s << "UNKNOWN overlapped_pending=1 cancel_completed=" << (completed ? 1 : 0) << "\n";
                std::string text = s.str();
                WriteExactSync(modeOut, text.data(), (DWORD)text.size());
                CloseHandle(ov.hEvent);
                return completed ? 0 : 54;
            }
            ok = GetOverlappedResult(pipe, &ov, &wrote, FALSE);
        }
        std::string s = ok ? "UNEXPECTED_WRITE_COMPLETED\n" : "UNKNOWN_WRITE_FAILED\n";
        WriteExactSync(modeOut, s.data(), (DWORD)s.size());
        CloseHandle(ov.hEvent);
        return ok ? 55 : 0;
    }
    std::string request = mode == L"normal" ? "success" :
                          mode == L"descendant_join" ? "descendant_join" :
                          "block:" + std::string(mode.begin(), mode.end());
    if (!WriteFrame(pipe, request, timeoutMs)) return 56;
    std::string response;
    if (!ReadFrame(pipe, response, timeoutMs + 1200)) return 57;
    std::string out = response + "\n";
    WriteExactSync(modeOut, out.data(), (DWORD)out.size());
    return 0;
}

struct CallerIoContext {
    HANDLE pipe = nullptr;
    HANDLE begin = nullptr;
    HANDLE submitted = nullptr;
    HANDLE done = nullptr;
    HANDLE ioEvent = nullptr;
    OVERLAPPED ov{};
    std::vector<char> payload;
    DWORD transferred = 0;
    DWORD error = 0;
    BOOL success = FALSE;
};

DWORD WINAPI CallerIoReaper(void* raw) {
    CallerIoContext* ctx = (CallerIoContext*)raw;
    WaitForSingleObject(ctx->begin, INFINITE);
    ctx->ioEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!ctx->ioEvent) {
        ctx->error = GetLastError();
        SetEvent(ctx->submitted);
        SetEvent(ctx->done);
        return 1;
    }
    ctx->ov = {};
    ctx->ov.hEvent = ctx->ioEvent;
    BOOL ok = WriteFile(ctx->pipe, ctx->payload.data(), (DWORD)ctx->payload.size(),
                        &ctx->transferred, &ctx->ov);
    DWORD err = ok ? ERROR_SUCCESS : GetLastError();
    SetEvent(ctx->submitted);
    if (!ok && err == ERROR_IO_PENDING) {
        DWORD wait = WaitForSingleObject(ctx->ioEvent, INFINITE);
        if (wait == WAIT_OBJECT_0) {
            ctx->success = GetOverlappedResult(ctx->pipe, &ctx->ov, &ctx->transferred, FALSE);
            if (!ctx->success) ctx->error = GetLastError();
        } else {
            ctx->error = GetLastError();
        }
    } else {
        ctx->success = ok;
        ctx->error = err;
    }
    SetEvent(ctx->done);
    return 0;
}

int CallerMainR8(int argc, wchar_t** argv) {
    if (argc < 10) return 71;
    HANDLE pipe = ParseHandle(argv[2]);
    HANDLE go = ParseHandle(argv[3]);
    HANDLE callerReady = ParseHandle(argv[4]);
    HANDLE custodianReady = ParseHandle(argv[5]);
    HANDLE modeOut = ParseHandle(argv[6]);
    DWORD timeoutMs = (DWORD)_wtoi(argv[8]);
    std::wstring mode = argv[9];
    CallerIoContext io;
    HANDLE reaperThread = nullptr;
    if (mode == L"admission-overlapped") {
        io.pipe = pipe;
        io.begin = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        io.submitted = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        io.done = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        io.payload.assign(2 * 1024 * 1024, 'X');
        if (!io.begin || !io.submitted || !io.done) return 72;
        reaperThread = CreateThread(nullptr, 0, CallerIoReaper, &io, 0, nullptr);
        if (!reaperThread) return 73;
    }
    SetEvent(callerReady);
    if (WaitForSingleObject(go, INFINITE) != WAIT_OBJECT_0) return 74;
    ULONGLONG start = GetTickCount64();
    if (mode == L"not-ready" && WaitForSingleObject(custodianReady, 0) != WAIT_OBJECT_0) {
        const char* rejected = "API_RETURN status=REJECTED_NOT_READY\n";
        WriteExactSync(modeOut, rejected, (DWORD)strlen(rejected));
        return 0;
    }
    if (mode == L"admission-sync") {
        std::vector<char> payload(2 * 1024 * 1024, 'X');
        DWORD wrote = 0;
        BOOL ok = WriteFile(pipe, payload.data(), (DWORD)payload.size(), &wrote, nullptr);
        std::string s = ok ? "API_RETURN status=SYNC_WRITE_RETURNED\n" : "API_RETURN status=UNKNOWN_SYNC_WRITE_FAILED\n";
        WriteExactSync(modeOut, s.data(), (DWORD)s.size());
        return ok ? 75 : 0;
    }
    if (mode == L"admission-overlapped") {
        SetEvent(io.begin);
        DWORD submitted = WaitForSingleObject(io.submitted, 1000);
        if (submitted != WAIT_OBJECT_0) {
            const char* unknown = "API_RETURN status=UNKNOWN submit_not_observed\n";
            WriteExactSync(modeOut, unknown, (DWORD)strlen(unknown));
            WaitForSingleObject(reaperThread, INFINITE);
            return 0;
        }
        DWORD ioWait = WaitForSingleObject(io.done, timeoutMs);
        bool apiReturnedUnknown = ioWait != WAIT_OBJECT_0;
        BOOL cancelIssued = FALSE;
        BOOL cancelCompleted = FALSE;
        if (apiReturnedUnknown) {
            cancelIssued = CancelIoEx(pipe, &io.ov);
            cancelCompleted = WaitForSingleObject(io.done, 0) == WAIT_OBJECT_0;
        }
        ULONGLONG apiElapsed = GetTickCount64() - start;
        std::ostringstream s;
        s << "API_RETURN status=" << (apiReturnedUnknown ? "UNKNOWN" : "SENT")
          << " elapsed_ms=" << apiElapsed << " io_pending=" << (cancelCompleted ? 0 : 1)
          << " cancel_issued=" << (cancelIssued ? 1 : 0) << " cancel_completed=" << (cancelCompleted ? 1 : 0) << "\n";
        std::string out = s.str();
        WriteExactSync(modeOut, out.data(), (DWORD)out.size());
        // Caller API has returned, but the reaper retains OVERLAPPED, event and buffer
        // until the custodian endpoint closes or the operation completes.
        WaitForSingleObject(reaperThread, INFINITE);
        std::ostringstream done;
        done << "REAPER_DONE io_complete=1 success=" << (io.success ? 1 : 0)
             << " error=" << io.error << " bytes=" << io.transferred << "\n";
        std::string doneText = done.str();
        WriteExactSync(modeOut, doneText.data(), (DWORD)doneText.size());
        CloseHandle(reaperThread);
        CloseHandle(io.begin);
        CloseHandle(io.submitted);
        CloseHandle(io.done);
        if (io.ioEvent) CloseHandle(io.ioEvent);
        return 0;
    }
    std::string request = mode == L"normal" ? "success" :
                          mode == L"descendant_join" ? "descendant_join" :
                          mode == L"custodian-cleanup-block" ? "block:join" :
                          "block:" + std::string(mode.begin(), mode.end());
    if (!WriteFrame(pipe, request, 500)) {
        std::string out = "API_RETURN status=UNKNOWN send_failed elapsed_ms=" +
            std::to_string(GetTickCount64() - start) + "\n";
        WriteExactSync(modeOut, out.data(), (DWORD)out.size());
        return 0;
    }
    std::string response;
    DWORD responseBudget = mode == L"custodian-block" || mode == L"custodian-write-block" ||
        mode == L"custodian-cleanup-block" ? 900 : timeoutMs;
    if (!ReadFrame(pipe, response, responseBudget)) {
        std::string out = "API_RETURN status=UNKNOWN response_timeout elapsed_ms=" +
            std::to_string(GetTickCount64() - start) + "\n";
        WriteExactSync(modeOut, out.data(), (DWORD)out.size());
        return 0;
    }
    std::string out = "API_RETURN status=" + response + " elapsed_ms=" +
        std::to_string(GetTickCount64() - start) + "\n";
    WriteExactSync(modeOut, out.data(), (DWORD)out.size());
    return 0;
}

struct Handles {
    HANDLE workerJob = nullptr;
    PROCESS_INFORMATION worker{};
    HANDLE workerInRead = nullptr;
    HANDLE workerInWrite = nullptr;
    HANDLE workerOutRead = nullptr;
    HANDLE workerOutWrite = nullptr;
    HANDLE callerJob = nullptr;
    PROCESS_INFORMATION caller{};
    HANDLE requestPipeServer = nullptr;
    HANDLE requestPipeClient = nullptr;
    HANDLE goEvent = nullptr;
    HANDLE readyEvent = nullptr;
    HANDLE callerOutRead = nullptr;
    HANDLE callerOutWrite = nullptr;
};
void CloseIf(HANDLE& h) { if (h && h != INVALID_HANDLE_VALUE) { CloseHandle(h); h = nullptr; } }
void CloseProcessInfo(PROCESS_INFORMATION& pi) {
    CloseIf(pi.hThread);
    CloseIf(pi.hProcess);
}
bool CreateAnonymousPipe(HANDLE& readH, HANDLE& writeH, HANDLE& parentRead, HANDLE& parentWrite) {
    SECURITY_ATTRIBUTES sa{ sizeof(sa), nullptr, TRUE };
    if (!CreatePipe(&readH, &writeH, &sa, 4096)) return false;
    parentRead = readH;
    parentWrite = writeH;
    return true;
}
bool StartWorker(Handles& h, const std::wstring& exe, std::string& readyMsg,
                 HANDLE suppliedJob = nullptr, const std::wstring& workerMode = L"",
                 bool waitReady = true) {
    SECURITY_ATTRIBUTES sa{ sizeof(sa), nullptr, TRUE };
    HANDLE inRead = nullptr, inWrite = nullptr, outRead = nullptr, outWrite = nullptr;
    if (!CreatePipe(&inRead, &inWrite, &sa, 4096)) return false;
    if (!CreatePipe(&outRead, &outWrite, &sa, 4096)) return false;
    SetInherit(inWrite, false);
    SetInherit(outRead, false);
    h.workerJob = suppliedJob ? suppliedJob : CreateJob();
    if (!h.workerJob) return false;
    h.workerInRead = inRead;
    h.workerInWrite = inWrite;
    h.workerOutRead = outRead;
    h.workerOutWrite = outWrite;
    std::wstring cmd = Quote(exe) + L" --worker";
    if (!workerMode.empty()) cmd += L" " + workerMode;
    if (!CreateExtended(cmd, { inRead, outWrite }, h.workerJob, inRead, outWrite, h.worker, CREATE_SUSPENDED)) return false;
    CloseIf(h.workerInRead);
    CloseIf(h.workerOutWrite);
    DWORD active = 0;
    if (!QueryActive(h.workerJob, active) || active != 1) return false;
    if (ResumeThread(h.worker.hThread) == (DWORD)-1) return false;
    BOOL nativeInJob = FALSE;
    if (!IsProcessInJob(h.worker.hProcess, h.workerJob, &nativeInJob) || !nativeInJob) return false;
    if (!waitReady) return true;
    if (!ReadLineDeadline(h.workerOutRead, GetTickCount64() + 3000, readyMsg)) return false;
    if (readyMsg != "WORKER_READY in_job=1") return false;
    return QueryActive(h.workerJob, active) && active == 1;
}
bool StartCaller(Handles& h, const std::wstring& exe, const std::wstring& mode, bool overlappedPipe) {
    std::wstring name = L"\\\\.\\pipe\\g1-r7-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64());
    h.requestPipeServer = CreateNamedPipeW(
        name.c_str(),
        PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
        PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
        1, 4096, 4096, 0, nullptr
    );
    if (h.requestPipeServer == INVALID_HANDLE_VALUE) return false;
    SECURITY_ATTRIBUTES sa{ sizeof(sa), nullptr, TRUE };
    DWORD flags = (overlappedPipe || mode != L"admission-sync") ? FILE_FLAG_OVERLAPPED : 0;
    h.requestPipeClient = CreateFileW(name.c_str(), GENERIC_READ | GENERIC_WRITE, 0, &sa, OPEN_EXISTING, flags, nullptr);
    if (h.requestPipeClient == INVALID_HANDLE_VALUE) return false;
    OVERLAPPED connect{};
    connect.hEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    BOOL c = ConnectNamedPipe(h.requestPipeServer, &connect);
    DWORD ce = GetLastError();
    if (!c && ce != ERROR_IO_PENDING && ce != ERROR_PIPE_CONNECTED) return false;
    if (ce == ERROR_IO_PENDING && WaitForSingleObject(connect.hEvent, 1000) != WAIT_OBJECT_0) return false;
    CloseHandle(connect.hEvent);

    SECURITY_ATTRIBUTES evsa{ sizeof(evsa), nullptr, TRUE };
    h.goEvent = CreateEventW(&evsa, TRUE, FALSE, nullptr);
    h.readyEvent = CreateEventW(&evsa, TRUE, FALSE, nullptr);
    if (!h.goEvent || !h.readyEvent) return false;
    SECURITY_ATTRIBUTES outSa{ sizeof(outSa), nullptr, TRUE };
    if (!CreatePipe(&h.callerOutRead, &h.callerOutWrite, &outSa, 4096)) return false;
    SetInherit(h.callerOutRead, false);
    h.callerJob = CreateJob();
    if (!h.callerJob) return false;
    std::wstring cmd = Quote(exe) + L" --caller " + HandleArg(h.requestPipeClient) + L" " +
        HandleArg(h.goEvent) + L" " + HandleArg(h.readyEvent) + L" " +
        HandleArg(h.callerOutWrite) + L" 500 " + mode;
    std::vector<HANDLE> inherit = { h.requestPipeClient, h.goEvent, h.readyEvent, h.callerOutWrite };
    if (!CreateExtended(cmd, inherit, h.callerJob, h.callerOutWrite, h.callerOutWrite, h.caller, CREATE_SUSPENDED)) return false;
    CloseIf(h.callerOutWrite);
    DWORD active = 0;
    if (!QueryActive(h.callerJob, active) || active != 1) return false;
    if (ResumeThread(h.caller.hThread) == (DWORD)-1) return false;
    return WaitForSingleObject(h.readyEvent, 2000) == WAIT_OBJECT_0;
}

int Harness(const std::wstring& mode) {
    Handles h;
    std::wstring exe = ModulePath();
    std::string workerReady;
    if (!StartWorker(h, exe, workerReady)) {
        std::cout << "{\"setup\":\"worker_not_ready\",\"error\":\"" << WinErr("StartWorker") << "\"}" << std::endl;
        return 2;
    }
    bool pipeOverlapped = mode != L"admission-sync";
    if (!StartCaller(h, exe, mode, pipeOverlapped)) {
        std::cout << "{\"setup\":\"caller_or_ipc_not_ready\",\"error\":\"" << WinErr("StartCaller") << "\"}" << std::endl;
        return 3;
    }
    DWORD jobActiveReady = 0, callerActiveReady = 0;
    bool callerReady = WaitForSingleObject(h.readyEvent, 0) == WAIT_OBJECT_0;
    bool workerHandleValid = ValidHandle(h.worker.hProcess) && ValidHandle(h.worker.hThread) && ValidHandle(h.workerJob);
    if (!callerReady || !workerHandleValid || !QueryActive(h.workerJob, jobActiveReady) || jobActiveReady != 1 ||
        !QueryActive(h.callerJob, callerActiveReady) || callerActiveReady != 1) {
        std::cout << "{\"setup\":\"ready_barrier_failed\"}" << std::endl;
        return 4;
    }
    std::string requestMode(mode.begin(), mode.end());
    ULONGLONG start = GetTickCount64();
    SetEvent(h.goEvent);
    const DWORD callerBudget = 1800;
    const DWORD workBudget = 500;
    const DWORD cleanupBudget = 1100;
    bool requestAccepted = false;
    bool stageReady = false;
    bool timedOut = false;
    bool callerBlockedAtDeadline = false;
    bool callerKilled = false;
    bool cleanupExact = false;
    bool controlsRetainedAtDecision = false;
    bool controlsReleased = false;
    bool descendantCase = mode == L"descendant_join";
    DWORD activeBeforeKill = 0, activeAfterKill = 0, workerExit = STILL_ACTIVE;
    DWORD callerExit = STILL_ACTIVE;
    ULONGLONG terminateStart = 0, terminateMs = 0;
    std::string workerMessage;
    std::string callerOutput;
    std::string resultStatus = "UNKNOWN";
    std::string error = "";

    if (mode == L"admission-sync" || mode == L"admission-overlapped") {
        DWORD wait = WaitForSingleObject(h.caller.hProcess, callerBudget);
        if (wait == WAIT_TIMEOUT) {
            callerBlockedAtDeadline = true;
            controlsRetainedAtDecision = ValidHandle(h.workerJob) && ValidHandle(h.worker.hProcess) &&
                QueryActive(h.workerJob, activeAfterKill) && activeAfterKill == 1;
            TerminateJobObject(h.callerJob, kCallerKilledExit);
            callerKilled = true;
            WaitForSingleObject(h.caller.hProcess, 500);
            GetExitCodeProcess(h.caller.hProcess, &callerExit);
            if (ReadLineDeadline(h.callerOutRead, GetTickCount64() + 100, callerOutput)) {}
            resultStatus = "UNKNOWN";
        } else if (wait == WAIT_OBJECT_0) {
            ReadLineDeadline(h.callerOutRead, GetTickCount64() + 100, callerOutput);
            GetExitCodeProcess(h.caller.hProcess, &callerExit);
            resultStatus = callerOutput.rfind("UNKNOWN", 0) == 0 ? "UNKNOWN" : "ADMISSION_WRITE_RETURNED";
            DWORD active = 0;
            controlsRetainedAtDecision = ValidHandle(h.workerJob) && QueryActive(h.workerJob, active) && active == 1;
        } else {
            error = WinErr("WaitForSingleObject(caller)");
        }
        if (mode == L"admission-sync" && !callerBlockedAtDeadline) error = "synchronous admission unexpectedly returned";
        if (mode == L"admission-overlapped" && callerBlockedAtDeadline) error = "overlapped admission caller exceeded deadline";
    } else {
        std::string request;
        if (!ReadFrame(h.requestPipeServer, request, workBudget)) {
            error = "request_not_received_before_work_deadline";
        } else {
            requestAccepted = true;
            std::string workerCmd = request + "\n";
            if (!WriteExactSync(h.workerInWrite, workerCmd.data(), (DWORD)workerCmd.size())) {
                error = WinErr("write worker request");
            } else if (!ReadLineDeadline(h.workerOutRead, start + workBudget, workerMessage)) {
                error = "worker_stage_not_observed";
            } else if (workerMessage == "DONE") {
                ULONGLONG remain = start + callerBudget > GetTickCount64() ?
                    start + callerBudget - GetTickCount64() : 0;
                DWORD wait = WaitForSingleObject(h.worker.hProcess, (DWORD)remain);
                if (wait == WAIT_OBJECT_0) {
                    GetExitCodeProcess(h.worker.hProcess, &workerExit);
                    bool jobCountRead = QueryActive(h.workerJob, activeAfterKill);
                    cleanupExact = workerExit == 0 && jobCountRead && activeAfterKill == 0;
                    resultStatus = cleanupExact ? "SUCCEEDED" : "UNKNOWN";
                } else {
                    error = "normal_worker_exit_deadline";
                }
            } else if (workerMessage.rfind("STAGE_READY:", 0) == 0 || workerMessage == "DESCENDANTS_READY active_query_local_unavailable") {
                stageReady = true;
                QueryActive(h.workerJob, activeBeforeKill);
                DWORD expectedActive = descendantCase ? 3 :
                    ((mode == L"create_process" || mode == L"join") ? 2 : 1);
                if (activeBeforeKill != expectedActive) {
                    error = "job_process_count_expected_" + std::to_string(expectedActive);
                }
                ULONGLONG now = GetTickCount64();
                if (now < start + workBudget) Sleep((DWORD)(start + workBudget - now));
                terminateStart = GetTickCount64();
                BOOL term = TerminateJobObject(h.workerJob, kKilledExit);
                terminateMs = GetTickCount64() - terminateStart;
                if (!term) {
                    error = WinErr("TerminateJobObject");
                } else {
                    ULONGLONG cleanupDeadline = start + callerBudget;
                    DWORD remain = cleanupDeadline > GetTickCount64() ? (DWORD)(cleanupDeadline - GetTickCount64()) : 0;
                    DWORD wait = WaitForSingleObject(h.worker.hProcess, remain);
                    if (wait == WAIT_OBJECT_0) {
                        GetExitCodeProcess(h.worker.hProcess, &workerExit);
                        ULONGLONG queryDeadline = start + callerBudget;
                        bool jobEmptyObserved = false;
                        do {
                            if (!QueryActive(h.workerJob, activeAfterKill)) { error = WinErr("QueryInformationJobObject"); break; }
                            if (activeAfterKill == 0) { jobEmptyObserved = true; break; }
                            Sleep(1);
                        } while (GetTickCount64() < queryDeadline);
                        cleanupExact = jobEmptyObserved && workerExit == kKilledExit;
                        resultStatus = cleanupExact ? "DEADLINE_EXCEEDED" : "UNKNOWN";
                    } else {
                        error = "worker_exit_not_observed";
                    }
                }
            } else {
                error = "unexpected_worker_message:" + workerMessage;
            }
        }
        if (cleanupExact) {
            controlsReleased = true;
            CloseIf(h.workerInWrite);
            CloseIf(h.workerOutRead);
            CloseProcessInfo(h.worker);
            CloseIf(h.workerJob);
        } else {
            controlsRetainedAtDecision = ValidHandle(h.workerJob) && ValidHandle(h.worker.hProcess);
        }
        std::ostringstream response;
        response << "status=" << resultStatus << ";accepted=" << (requestAccepted ? 1 : 0)
                 << ";worker_exit=" << workerExit << ";active_after=" << activeAfterKill
                 << ";exact=" << (cleanupExact ? 1 : 0) << ";released=" << (controlsReleased ? 1 : 0);
        std::string responseText = response.str();
        if (!WriteFrame(h.requestPipeServer, responseText, 500)) error = "response_pipe_write_failed";
        DWORD callerWait = WaitForSingleObject(h.caller.hProcess, callerBudget);
        if (callerWait == WAIT_TIMEOUT) {
            callerBlockedAtDeadline = true;
            TerminateJobObject(h.callerJob, kCallerKilledExit);
            callerKilled = true;
            resultStatus = "UNKNOWN";
        } else {
            ReadLineDeadline(h.callerOutRead, GetTickCount64() + 100, callerOutput);
            GetExitCodeProcess(h.caller.hProcess, &callerExit);
        }
    }

    ULONGLONG elapsed = GetTickCount64() - start;
    DWORD finalActive = 0;
    if (ValidHandle(h.workerJob)) QueryActive(h.workerJob, finalActive);
    bool controlsValidAtSnapshot = ValidHandle(h.workerJob) && ValidHandle(h.worker.hProcess) && ValidHandle(h.worker.hThread);
    std::cout << "{";
    std::cout << "\"mode\":\"" << requestMode << "\",";
    std::cout << "\"ready_barrier\":{\"worker_in_job\":true,\"job_active_before_request\":" << jobActiveReady
              << ",\"caller_ipc_connected\":true,\"caller_ready\":" << (callerReady ? "true" : "false")
              << ",\"worker_process_handle_preowned\":true,\"worker_thread_handle_preowned\":true},";
    std::cout << "\"status\":\"" << resultStatus << "\",";
    std::cout << "\"request_accepted\":" << (requestAccepted ? "true" : "false") << ",";
    std::cout << "\"caller_blocked_at_deadline\":" << (callerBlockedAtDeadline ? "true" : "false") << ",";
    std::cout << "\"caller_watchdog_terminated_caller\":" << (callerKilled ? "true" : "false") << ",";
    std::cout << "\"caller_exit_code\":" << callerExit << ",";
    std::cout << "\"caller_output\":\"" << callerOutput << "\",";
    std::cout << "\"worker_message\":\"" << workerMessage << "\",";
    std::cout << "\"active_before_terminate\":" << activeBeforeKill << ",";
    std::cout << "\"active_after_terminate\":" << activeAfterKill << ",";
    std::cout << "\"active_after_scenario\":" << finalActive << ",";
    std::cout << "\"worker_exit_code\":" << workerExit << ",";
    std::cout << "\"terminate_job_ms\":" << terminateMs << ",";
    std::cout << "\"exact_exit_and_job_empty\":" << (cleanupExact ? "true" : "false") << ",";
    std::cout << "\"controls_retained_at_unknown\":" << (controlsRetainedAtDecision ? "true" : "false") << ",";
    std::cout << "\"controls_released_after_exact_proof\":" << (controlsReleased ? "true" : "false") << ",";
    std::cout << "\"controls_still_valid_at_snapshot\":" << (controlsValidAtSnapshot ? "true" : "false") << ",";
    std::cout << "\"elapsed_ms\":" << elapsed << ",";
    std::cout << "\"error\":\"" << error << "\"";
    std::cout << "}" << std::endl;

    // Test teardown. Any still-owned execution Job is explicitly drained only after the
    // caller-facing decision was recorded; controls remain valid through UNKNOWN.
    bool teardownShutdownSent = false;
    bool teardownForcedTerminate = false;
    DWORD teardownWaitResult = WAIT_FAILED;
    DWORD teardownExitCode = workerExit;
    DWORD teardownActive = activeAfterKill;
    bool teardownExact = cleanupExact;
    bool teardownControlsReleased = controlsReleased;
    if (ValidHandle(h.workerJob)) {
        DWORD active = 0;
        if (QueryActive(h.workerJob, active) && active > 0) {
            teardownShutdownSent = WriteExactSync(h.workerInWrite, "shutdown\n", 9);
            teardownWaitResult = WaitForSingleObject(h.worker.hProcess, 500);
            if (teardownWaitResult != WAIT_OBJECT_0 && QueryActive(h.workerJob, active) && active > 0) {
                teardownForcedTerminate = TerminateJobObject(h.workerJob, kKilledExit) != FALSE;
                teardownWaitResult = WaitForSingleObject(h.worker.hProcess, 500);
            }
        }
        GetExitCodeProcess(h.worker.hProcess, &teardownExitCode);
        if (!QueryActive(h.workerJob, teardownActive)) teardownActive = (DWORD)-1;
        teardownExact = teardownExitCode != STILL_ACTIVE && teardownActive == 0;
        if (teardownExact) {
            CloseIf(h.workerInWrite);
            CloseIf(h.workerOutRead);
            CloseProcessInfo(h.worker);
            CloseIf(h.workerJob);
            teardownControlsReleased = true;
        }
    }
    std::cout << "{\"teardown\":{"
              << "\"shutdown_write_sent\":" << (teardownShutdownSent ? "true" : "false") << ","
              << "\"forced_terminate_used\":" << (teardownForcedTerminate ? "true" : "false") << ","
              << "\"process_wait_result\":" << teardownWaitResult << ","
              << "\"worker_exit_code\":" << teardownExitCode << ","
              << "\"job_active_after_cleanup\":" << teardownActive << ","
              << "\"exact_exit_and_job_empty_after_cleanup\":" << (teardownExact ? "true" : "false") << ","
              << "\"controls_released_after_exact_cleanup\":" << (teardownControlsReleased ? "true" : "false") << ","
              << "\"handles_retained_if_cleanup_unknown\":" << ((ValidHandle(h.workerJob) && ValidHandle(h.worker.hProcess)) ? "true" : "false")
              << "}}" << std::endl;
    CloseProcessInfo(h.caller);
    CloseIf(h.requestPipeClient);
    CloseIf(h.requestPipeServer);
    CloseIf(h.callerJob);
    CloseIf(h.goEvent);
    CloseIf(h.readyEvent);
    CloseIf(h.callerOutRead);
    if (teardownExact) {
        CloseIf(h.workerInWrite);
        CloseIf(h.workerOutRead);
        CloseProcessInfo(h.worker);
        CloseIf(h.workerJob);
    }
    return error.empty() ? 0 : 5;
}

int wmain(int argc, wchar_t** argv) {
    if (argc >= 2 && std::wstring(argv[1]) == L"--worker") return WorkerMain();
    if (argc >= 2 && std::wstring(argv[1]) == L"--sleeper") return SleeperMain();
    if (argc >= 3 && std::wstring(argv[1]) == L"--spawner") {
        HANDLE event = ParseHandle(argv[2]);
        std::wstring exe = ModulePath();
        std::wstring cmd = Quote(exe) + L" --sleeper";
        PROCESS_INFORMATION pi{};
        if (!CreateExtended(cmd, {}, nullptr, nullptr, nullptr, pi)) return 61;
        if (WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0) return 62;
        SetEvent(event);
        CloseProcessInfo(pi);
        Sleep(INFINITE);
        return 0;
    }
    if (argc >= 8 && std::wstring(argv[1]) == L"--caller") return CallerMain(argc, argv);
    if (argc >= 2) return Harness(argv[1]);
    std::wcerr << L"usage: g1_win_lazy_probe.exe <normal|create_process|pipe|token|receipt|join|descendant_join|admission-sync|admission-overlapped>" << std::endl;
    return 1;
}
