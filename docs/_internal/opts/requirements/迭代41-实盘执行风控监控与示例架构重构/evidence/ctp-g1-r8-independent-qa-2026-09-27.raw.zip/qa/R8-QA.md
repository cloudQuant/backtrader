# R8 independent QA — Windows inert custodian

Date: 2026-09-27  
Disposition: **REJECTED / G1 CLOSED**. This is an inert local replay only. Ordinary preflight and the default route remain closed.

## Frozen identity

Frozen candidate: `D:\temp\iteration41-g1-r8-independent-custodian-20260927`. Manifest SHA-256 `f1ce63cf08ec620c7a4ca09fac55bc26a7553f88796cfb3e2a768f7bb008cdeb` (expected `f1ce63cf08ec620c7a4ca09fac55bc26a7553f88796cfb3e2a768f7bb008cdeb`); frozen author receipt SHA-256 `66b556a7dc7a17613cc7d87b34fa0168876058c9b881d68186cba8c6c81df2d1`. Manifest/sidecar and receipt/sidecar agree. All **10/10** payload hashes and sizes verified before copy and in the isolated `frozen-inputs` copy. Custodian source SHA-256 `c843712eb3e999b88790f0adb18848cd6d2341db5f2efeb19a8eee3a32a80dce`, probe source SHA-256 `f1959f9f6a4246bbdd186a965cca192ea80ce16255976d1245833b4783995e49`, frozen EXE SHA-256 `a6a1270cd4a5a868f6a8ee51c14fbcc1b463906e45488a7f92676ac070aac9a0`, OBJ SHA-256 `77c12781cc9d742153d53ab7d2986944239ad13366e0c33cff39abb4f7954c3e`. Independent rebuild exit 0 used the same source SHA; its EXE SHA-256 `2ea1b5659d634515b5ae1d3e4984a2722b16a749c0b33cb04a291d1452cb61b2` is recorded separately.

## Replay results

Environment: CPython `3.11.5 | packaged by Anaconda, Inc. | (main, Sep 11 2023, 13:26:23) [MSC v.1916 64 bit (AMD64)]`; Windows API version `[10, 0, 26200, 2, '']`. The frozen manifest-bound `r8_trials.json` contains **13 assertion predicates, 0 failed**, covering 10 named modes plus the separate outer-Job kill probe. The isolated replay independently reproduced **13/13 predicates, 0 failed**. A passing P05 predicate means the harness detected the deadline counterexample; it does not mean the deadline was met.

- **Frozen P05 synchronous admission:** D = 1200 ms; final manifest-bound trial decision at **1218 ms**. `caller_api_returned=false`, `caller_blocked_at_deadline=true`, and watchdog termination was needed. It ended UNKNOWN after cleanup; no bounded caller return was proved. My separate replay observed 1234 ms with the same false/blocked/watchdog facts. The frozen author narrative `R8_FINDINGS.md` says 1,234 ms; that is stale relative to its own final structured trial at 1,218 ms, so this review uses the structured trial as the frozen measurement.
- **Overlapped I/O and ownership:** frozen trial returned UNKNOWN at 1031 ms with `io_pending=1` at API return (`elapsed_ms=1015`). `CancelIoEx` was issued successfully (`error=0`), then `io_pending_after=0`; the completion was consumed as `ERROR_OPERATION_ABORTED` (995), zero bytes. Owner process PID `12112` equals caller PID `12112`; owner thread `36048` differs from API thread `32304`. Independent replay observed the same pending → successful cancel → error-995 completion path (API decision 1015 ms). The reaper is a thread in the caller process, not an independent reaper process.
- **Caller-death lifetime:** not established. The overlapped scenario consumes completion before caller process exit. The outer Job kill scenario has no pending OVERLAPPED. `IoReaper` is created as a thread in the caller and cannot survive caller process termination; the evidence does not show another process retaining the pipe handle, `OVERLAPPED`, event, and buffer or observing completion after caller death. No caller-death-with-pending-I/O/live-peer case was replayable from this candidate.
- **Duplicated outer Job kill:** frozen trial starts with 5 active members; external runner's duplicated Job handle successfully terminates the Job; ActiveProcesses reaches 0 in 16 ms and retained caller/custodian/worker handles all return `WAIT_OBJECT_0`. Independent replay repeated this: 5 → 0 in 15 ms. The frozen `R8_FINDINGS.md` says 31 ms; the manifest-bound structured trial records 16 ms.

## Deadline and startup ordering

The source starts request D only after worker/custodian/caller readiness and named-pipe setup (`r8_custodian.cpp:367-461`; `requestStart` at line 454, then GO). The outer launcher duplicates its Job handle to the Python runner and emits `OUTER_JOB_CONTROL_READY` before assigning itself to that Job (`:571-580`); it then creates/resumes the child and emits `OUTER_JOB_READY` (`:594-601`). Trial output orders these markers before `SUPERVISOR_REQUEST_BARRIER`; `prewarm_ms` is recorded before GO. Thus prewarm/setup and handle transfer are outside request D.

Whole-command startup remains unbounded. Python calls synchronous `subprocess.Popen` (`run_r8_trials.py:157`) before it receives the launcher process handle or duplicated outer Job handle. Native `CreateJobObjectW`/`OpenProcess`/`DuplicateHandle` run before the control-ready marker, and launcher Job assignment follows that marker. No shim injected hangs at these boundaries. The runner's 8-second wrapper watchdog begins only after `Popen` returns, not at D=1,200 ms. The prototype proves neither bounded whole-command startup nor the supervisor's synchronous setup/API calls.

## Code review and remaining gaps

`IoReaper` is `CreateThread`-backed in the caller (`r8_custodian.cpp:233-251, 293-316`): it owns the pipe, `OVERLAPPED`, event, and buffer through `GetOverlappedResult`; handles are closed only after thread completion. This is correct ownership for the tested in-process drain, but not durable ownership after caller death. Normal success and the worker/custodian stall paths only released worker controls after exact exit and Job-empty evidence; the outer Job kill is separately verified by its duplicated handle.

Not tested by candidate injections: CreateProcessW before/after-creation blocking (P02/P03); ResumeThread hang (P04); connect/read/body pending (P06); delayed completion or cancellation-error races, including `ERROR_NOT_FOUND` (P07-P09); pending-I/O owner death with live peer (P10); malformed frames (P11); query failure/false-zero and delayed cleanup-call cases (P13-P15); caller disconnect (P18); a separate reaper dying while request Job survives (P19); concurrent/reused slots (P20); and late-success suppression after D (P21). These remain unverified, not passed.

No CTP, credentials, SDK/native provider, external service, network route, private config, or default preflight was accessed. **G1 remains CLOSED.**

## Evidence

- Frozen final trials: `frozen-inputs/r8_trials.json`, SHA-256 `4c412a14af1cb5fe5ea5f6ff39f23d7952187e5f60bc2015f70d0098af6cf58a`.
- Independent trials: `run/r8_trials.json`, SHA-256 `5cc7fccda36e7ff9065118931e73223231883d683ee0d234d850b2193cb3de96`.
- Replay console: `r8-replay-console.log`, SHA-256 `244a25a8a3b50c020e39f51ecd2f72329bb9fa1cf90052bdd657969bb60a76cd`; exit `0`.
- QA machine receipt: `R8-QA-receipt.json` (hash emitted after report creation).
- Frozen inputs and original receipt remain separately preserved under `frozen-inputs/`; independent build artifacts are under `run/`.
