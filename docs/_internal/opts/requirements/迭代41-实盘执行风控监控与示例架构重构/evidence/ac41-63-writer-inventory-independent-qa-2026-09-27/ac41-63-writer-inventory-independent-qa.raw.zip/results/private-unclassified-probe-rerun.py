import builtins, importlib.util, io, json, sys
from pathlib import Path
repo = Path(r'D:\temp\iteration41-writer-inventory-independent-qa-20260927\repo')
collector_path = repo / 'scripts' / 'collect_iteration41_writer_inventory.py'
spec = importlib.util.spec_from_file_location('iteration41_inventory_isolated_probe_rerun', collector_path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
synthetic = Path(r'D:\temp\iteration41-writer-inventory-independent-qa-20260927\synthetic-source-rerun')
(synthetic / 'examples' / 'known').mkdir(parents=True)
(synthetic / 'examples' / 'new-unreviewed' / 'nested').mkdir(parents=True)
private_root = synthetic / 'examples' / '013_3_sa_midfreq_simnow' / 'runtime-ctp-private'
state = private_root / 'state'
state.mkdir(parents=True)
secret = 'SYNTHETIC_PRIVATE_SENTINEL_DO_NOT_EMIT_83d04b2'
(private_root / 'config.yaml').write_text('synthetic: ' + secret, encoding='utf-8')
(state / 'private_sentinel.py').write_text('# ' + secret + "\napi.cancel_order('private')\n", encoding='utf-8')
(synthetic / 'new_root_script.py').write_text('pass\n', encoding='utf-8')
protected_reads = []
def protected(value):
    try: return 'runtime-ctp-private' in str(value).replace('\\', '/').lower()
    except Exception: return False
orig_read_text, orig_path_open = Path.read_text, Path.open
orig_builtin_open, orig_io_open = builtins.open, io.open
def deny(kind, value):
    if protected(value):
        protected_reads.append((kind, str(value)))
        raise AssertionError('synthetic private sentinel read')
def path_read_text(self, *args, **kwargs):
    deny('Path.read_text', self); return orig_read_text(self, *args, **kwargs)
def path_open(self, *args, **kwargs):
    deny('Path.open', self); return orig_path_open(self, *args, **kwargs)
def builtin_open(file, *args, **kwargs):
    deny('open', file); return orig_builtin_open(file, *args, **kwargs)
def io_open(file, *args, **kwargs):
    deny('io.open', file); return orig_io_open(file, *args, **kwargs)
Path.read_text, Path.open = path_read_text, path_open
builtins.open, io.open = builtin_open, io_open
try: report = module.collect_inventory(synthetic)
finally:
    Path.read_text, Path.open = orig_read_text, orig_path_open
    builtins.open, io.open = orig_builtin_open, orig_io_open
unclassified = {item['path'] for item in report['source_path_coverage']['unclassified_paths']}
expected = {'examples/new-unreviewed', 'examples/new-unreviewed/nested', 'new_root_script.py'}
assert expected <= unclassified, (expected, unclassified)
assert report['source_path_coverage']['status'] == 'UNCLASSIFIED_PATHS_PRESENT'
assert not protected_reads, protected_reads
assert not any('private_sentinel.py' in path for path in report['files_scanned'])
serialized = json.dumps(report, sort_keys=True)
assert secret not in serialized
assert 'runtime-ctp-private/state/private_sentinel.py' not in serialized
for forbidden in ('backtrader', '_ctp', 'bt_api_py'):
    assert not any(name == forbidden or name.startswith(forbidden + '.') for name in sys.modules), forbidden
print(json.dumps({'status':'PASS','unclassified_expected_paths':sorted(expected),'private_open_attempts':len(protected_reads),'secret_leaked':secret in serialized,'private_file_in_scanned':any('private_sentinel.py' in p for p in report['files_scanned']),'forbidden_modules_loaded':[]},sort_keys=True))
