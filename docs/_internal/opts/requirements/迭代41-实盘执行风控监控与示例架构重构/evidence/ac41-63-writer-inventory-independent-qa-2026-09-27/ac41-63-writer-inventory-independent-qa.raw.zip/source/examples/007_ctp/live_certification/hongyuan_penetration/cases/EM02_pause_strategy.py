#!/usr/bin/env python
"""EM02: Verify that the system can suspend trading by pausing strategy execution"""
from __future__ import annotations

import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_SUITE = _HERE.parent
_REPO = _SUITE.parents[2]
for _p in (_SUITE, _REPO):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from common import config as cfg, helpers
from common.result import CaseTimer
from common.runtime import started_store, create_cerebro, run_with_timeout, live_seed_bar

import backtrader as bt

CASE_META = {
    "case_id": "EM02",
    "case_name": "验证系统可通过暂停策略执行方式暂停交易",
    "category": "应急处理",
    "optional": False,
}


def run(report_dir):
    """Run EM02 pause strategy test case.

    Args:
        report_dir: Directory for test reports and logs.
    """
    env_key = cfg.get_env_key()
    symbol = cfg.get_order_symbol()
    log_dir = str(report_dir / "logs")

    with CaseTimer(CASE_META["case_id"], CASE_META["case_name"], env_key) as timer:
        try:
            with started_store(env_key, stop_on_exit=False) as (store, config, ek):
                cerebro = create_cerebro(
                    store,
                    symbol=symbol,
                    bar_seconds=5,
                    with_trade_logger=True,
                    log_dir=log_dir,
                    historical_bars=[live_seed_bar(store, symbol)],
                )

                class PauseStrategy(bt.Strategy):
                    """Strategy for testing pause functionality via runstop."""

                    def __init__(self):
                        """Initialize pause strategy."""
                        self.bar_count = 0
                        self.paused = False
                        self.paused_event_seen = False
                        self.orders_after_pause = 0

                    def notify_store(self, msg, *args, **kwargs):
                        """Stop only after the pause event has been drained.

                        Calling ``cerebro.runstop()`` in the same ``next()`` as
                        ``pause_strategy()`` skips the store-event drain, so the
                        ``strategy_trading_paused`` evidence never reaches the
                        TradeLogger.  Stopping here keeps the evidence.
                        """
                        event = kwargs.get("event")
                        if (
                            isinstance(event, dict)
                            and event.get("event_type") == "strategy_trading_paused"
                        ):
                            self.paused_event_seen = True
                            self.cerebro.runstop()

                    def next(self):
                        """Process bar and trigger pause after first bar."""
                        self.bar_count += 1

                        if not self.paused:
                            if hasattr(self.cerebro.broker, "pause_strategy"):
                                self.cerebro.broker.pause_strategy(reason="EM02_test")
                            print("  调用 broker.pause_strategy() 暂停策略执行")
                            self.paused = True
                            return

                        if self.paused:
                            self.orders_after_pause += 1

                cerebro.addstrategy(PauseStrategy)
                results = run_with_timeout(cerebro, timeout_seconds=60)

                strat = results[0] if results else None
                if not strat or strat.bar_count <= 0:
                    return timer.blocked_result("未能通过种子 bar 触发暂停逻辑")

                if strat.paused:
                    print("✓ 策略已通过 cerebro.runstop() 暂停")
                    print(f"  暂停后未再执行 next: orders_after_pause={strat.orders_after_pause}")
                    # No event list is declared here: ``strategy_trading_paused``
                    # must be observed in the framework logs written by
                    # broker.pause_strategy().
                    return timer.pass_result(
                        evidence=helpers.collect_evidence_files(log_dir),
                        details={
                            "bars_before_pause": strat.bar_count,
                            "paused": True,
                            "strategy_id": type(strat).__name__,
                            "reason": "EM02_test",
                        },
                    )

                return timer.blocked_result("策略未执行到暂停点")

        except Exception as exc:
            return timer.fail_result(str(exc), evidence=helpers.collect_evidence_files(log_dir))


if __name__ == "__main__":
    from common.runtime import case_main
    case_main(run, CASE_META)
