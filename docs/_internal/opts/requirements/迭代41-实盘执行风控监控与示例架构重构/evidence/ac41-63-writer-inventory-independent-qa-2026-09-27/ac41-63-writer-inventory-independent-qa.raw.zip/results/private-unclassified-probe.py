import builtins, importlib.util, io, json, sys
from pathlib import Path

repo = Path(r'D:\temp\iteration41-writer-inventory-independent-qa-20260927\repo')
collector_path = repo / 'scripts' / 'collect_iteration41_writer_inventory.py'
spec = importlib.util.spec_from_file_location('iteration41_inventory_isolated_probe', collector_path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

synthetic = Path(r'D:\temp\iteration41-writer-inventory-independent-qa-20260927\synthetic-source')
(synthetic / 'examples' / 'known').mkdir(parents=True)
(synthetic / 'examples' / 'new-unreviewed' / 'nested').mkdir(parents=True)
private_root = synthetic / 'examples' / '013_3_sa_midfreq_simnow' / 'runtime-ctp-private'
state = private_root / 'state'
state.mkdir(parents=True)
secret = 'SYNTHETIC_PRIVATE_SENTINEL_DO_NOT_EMIT_83d04b2'
(private_root / 'config.yaml').write_text('synthetic: ' + secret, encoding='utf-8')
(state / 'private_sentinel.py').write_text("# " + secret + "\napi.cancel_order('private')\n", encoding='utf-8')
(synthetic / 'new_root_script.py').write_text('pass\n', encoding='utf-8')

protected_reads = []
def is_protected(value):
    try:
        path = str(value).replace('\\', '/').lower()
    except Exception:
        return False
    return 'runtime-ctp-private' in path

orig_path_read_text = Path.read_text
orig_path_open = Path.open
orig_builtin_open = builtins.open
orig_io_open = io.open

def deny_path_read_text(self, *args, **kwargs):
    if is_protected(self):
        protected_reads.append(('Path.read_text', str(self)))
        raise AssertionError('private sentinel read')
    return orig_path_read_text(self, *args, **kwargs)

def deny_path_open(self, *args, **kwargs):
    if is_protected(self):
        protected_reads.append(('Path.open', str(self)))
        raise AssertionError('private sentinel open')
    return orig_path_open(self, *args, **kwargs)

def deny_builtin_open(file, *args, **kwargs):
    if is_protected(file):
        protected_reads.append(('open', str(file)))
        raise AssertionError('private sentinel open')
    return orig_builtin_open(file, *args, **kwargs)

def deny_io_open(file, *args, **kwargs):
    if is_protected(file):
        protected_reads.append(('io.open', str(file)))
        raise AssertionError('private sentinel open')
    return orig_io_open(file, *args, **kwargs)

Path.read_text = deny_path_read_text
Path.open = deny_path_open
builtins.open = deny_builtin_open
io.open = deny_io_open
try:
    report = module.collect_inventory(synthetic)
finally:
    Path.read_text = orig_path_read_text
    Path.open = orig_path_open
    builtins.open = orig_builtin_open
    io.open = orig_io_open

unclassified = {item['path'] for item in report['source_path_coverage']['unclassified_paths']}
expected_new_paths = {'examples/new-unreviewed', 'examples/new-unreviewed/nested', 'new_root_script.py'}
assert expected_new_paths <= unclassified, (expected_new_paths, unclassified)
assert report['source_path_coverage']['status'] == 'UNCLASSIFIED_PATHS_PRESENT'
assert not protected_reads, protected_reads
assert not any('private_sentinel.py' in path for path in report['files_scanned'])
serialized = json.dumps(report, sort_keys=True)
assert secret not in serialized
assert 'runtime-ctp-private/state/private_sentinel.py' not in serialized
print(json.dumps({
  'status': 'PASS',
  'unclassified_expected_paths': sorted(expected_new_paths),
  'private_file_open_attempts': len(protected_reads),
  'private_sentinel_in_serialized_output': secret in serialized,
  'private_sentinel_path_in_files_scanned': any('private_sentinel.py' in path for path in report['files_scanned']),
  'files_scanned': report['counts']['files_scanned'],
}, sort_keys=True))
