@echo off
set TEMP=D:\q\tha
set TMP=D:\q\tha
@echo off
set SOURCE_DATE_EPOCH=1790424377
set PYTHONHASHSEED=0
set PYTHONUTF8=1
set TZ=UTC
set PIP_NO_INDEX=1
set PIP_CONFIG_FILE=NUL
set LINK=/Brepro
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x64
if errorlevel 1 exit /b %errorlevel%
set DISTUTILS_USE_SDK=1
set MSSdk=1
set LINK=/Brepro
set PIP_CONFIG_FILE=NUL
python -m pip wheel --no-deps --no-build-isolation --no-cache-dir --no-index --wheel-dir D:\q\wh18a .
exit /b %errorlevel%

