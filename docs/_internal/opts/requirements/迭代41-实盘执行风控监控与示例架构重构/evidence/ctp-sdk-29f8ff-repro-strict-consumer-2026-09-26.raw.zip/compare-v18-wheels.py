import csv
import hashlib
import zipfile
from pathlib import Path

a = Path(r"D:\q\wh18a\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl")
b = Path(r"D:\q\wh18b\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl")
rows = []
with zipfile.ZipFile(a) as left, zipfile.ZipFile(b) as right:
    left_names = {name for name in left.namelist() if not name.endswith("/")}
    right_names = {name for name in right.namelist() if not name.endswith("/")}
    for name in sorted(left_names | right_names):
        x = left.read(name) if name in left_names else None
        y = right.read(name) if name in right_names else None
        rows.append({
            "member": name,
            "a_size": "" if x is None else len(x),
            "a_sha256": "" if x is None else hashlib.sha256(x).hexdigest(),
            "b_size": "" if y is None else len(y),
            "b_sha256": "" if y is None else hashlib.sha256(y).hexdigest(),
            "byte_equal": x == y,
        })
out = Path(r"D:\q\logs\sdk-wheel-entry-comparison-v18.csv")
with out.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=rows[0].keys(), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
diff = [row for row in rows if not row["byte_equal"]]
ha = hashlib.sha256(a.read_bytes()).hexdigest()
hb = hashlib.sha256(b.read_bytes()).hexdigest()
summary = Path(r"D:\q\logs\wheel-comparison-v18.txt")
summary.write_text(
    f"A={a}\nA_SHA256={ha}\nB={b}\nB_SHA256={hb}\nMEMBERS={len(rows)}\nDIFFERING={len(diff)}\nENTRY_CSV={out}\n",
    encoding="utf-8",
)
print(summary.read_text(encoding="utf-8"), end="")
for row in diff:
    print(f"DIFF {row['member']}")
if diff:
    raise SystemExit(1)