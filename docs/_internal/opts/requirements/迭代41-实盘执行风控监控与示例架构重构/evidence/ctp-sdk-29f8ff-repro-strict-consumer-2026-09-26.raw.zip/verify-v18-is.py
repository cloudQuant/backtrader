import base64
import builtins
import csv
import hashlib
import json
from importlib.metadata import distribution
from pathlib import Path
import sys
import zipfile

assert sys.flags.isolated == 1 and sys.flags.no_site == 1, sys.flags
orig_import = builtins.__import__
def block_native(name, globals=None, locals=None, fromlist=(), level=0):
    package = (globals or {}).get("__package__", "")
    relative = level > 0 and name in ("", "_ctp") and "_ctp" in fromlist and package == "bt_api_ctp.ctp"
    if name.endswith("._ctp") or relative:
        raise ImportError("native CTP import blocked in -I -S verification")
    return orig_import(name, globals, locals, fromlist, level)
builtins.__import__ = block_native
root = Path(sys.executable).resolve().parents[1]
site_root = root / "Lib" / "site-packages"
assert site_root.is_dir()
assert all("site-packages" not in entry.lower() for entry in sys.path)
sys.path.insert(0, str(site_root))
assert sum(Path(entry).resolve() == site_root.resolve() for entry in sys.path if entry) == 1
import yaml
import bt_api_base
import bt_api_ctp
from bt_api_ctp.ctp import _ctp_base
assert not _ctp_base.is_ctp_native_loaded()
for name, module in (("yaml", yaml), ("bt_api_base", bt_api_base), ("bt_api_ctp", bt_api_ctp)):
    origin = Path(module.__file__).resolve()
    assert site_root.resolve() in origin.parents, (name, origin)
    print(f"origin {name}={origin}")
expected = {
    "bt_api_base": (Path(r"D:\temp\iteration41-capability-artifacts-20260926\wheels\base-a\bt_api_base-0.15.4-py3-none-any.whl"), "cfe3507e1324f675454c41c37cd09ff72c8947c5254e9496e97c373cb8f3b369"),
    "bt_api_ctp": (Path(r"D:\q\wh18a\bt_api_ctp-2.0.4+iteration41.i9-cp311-cp311-win_amd64.whl"), "dc0aaac0063262d38db27535ea7b7bf4d221a9938dea851198b71e690772571f"),
    "pyyaml": (Path(r"D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse\pyyaml-6.0.1-cp311-cp311-win_amd64.whl"), "c36925f66ff721ba790842b990c8093e64a0621350eafb0e225f2363d3323b48"),
}
audit_rows = []
for project, (wheel, wanted) in expected.items():
    wheel_hash = hashlib.sha256(wheel.read_bytes()).hexdigest()
    if wanted is not None:
        assert wheel_hash == wanted, (project, wheel_hash)
    dist = distribution(project)
    direct_path = dist.locate_file(f"{dist.metadata['Name'].replace('-', '_')}-{dist.version}.dist-info/direct_url.json")
    if project in expected:
        direct = json.loads(Path(direct_path).read_text(encoding="utf-8"))
        assert direct["archive_info"]["hashes"]["sha256"] == wheel_hash, (project, direct)
        print(f"direct_url {project} sha256={wheel_hash}")
    with zipfile.ZipFile(wheel) as archive:
        record_name = next(n for n in archive.namelist() if n.endswith(".dist-info/RECORD"))
        count = 0
        for row in csv.reader(archive.read(record_name).decode("utf-8").splitlines()):
            rel, digest, size = row
            installed = Path(dist.locate_file(rel))
            data = installed.read_bytes()
            actual_digest = ""
            if size:
                assert len(data) == int(size), (project, rel)
            if digest:
                alg, encoded = digest.split("=", 1)
                actual = base64.urlsafe_b64encode(hashlib.new(alg, data).digest()).rstrip(b"=").decode("ascii")
                assert actual == encoded, (project, rel)
                actual_digest = actual
            audit_rows.append({
                "project": project,
                "kind": "RECORD",
                "path": rel,
                "expected_digest": digest,
                "actual_digest": actual_digest,
                "expected_size": size,
                "actual_size": len(data),
                "equal": True,
            })
            count += 1
        for member in archive.namelist():
            if member.endswith(".dist-info/RECORD"):
                continue
            installed_payload = Path(dist.locate_file(member)).read_bytes()
            wheel_payload = archive.read(member)
            assert installed_payload == wheel_payload, (project, member)
            audit_rows.append({
                "project": project,
                "kind": "WHEEL_PAYLOAD",
                "path": member,
                "expected_digest": hashlib.sha256(wheel_payload).hexdigest(),
                "actual_digest": hashlib.sha256(installed_payload).hexdigest(),
                "expected_size": len(wheel_payload),
                "actual_size": len(installed_payload),
                "equal": True,
            })
    print(f"record_and_payload {project} rows={count} verified wheel_sha256={wheel_hash}")
audit_path = Path(r"D:\q\logs\installed-record-verification-v18.csv")
if audit_path.exists():
    raise RuntimeError(f"refusing to overwrite existing audit report: {audit_path}")
with audit_path.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=audit_rows[0].keys(), lineterminator="\n")
    writer.writeheader()
    writer.writerows(audit_rows)
print(f"record_file_report={audit_path} rows={len(audit_rows)}")
print(f"isolated={sys.flags.isolated == 1} no_site={sys.flags.no_site == 1} native_loaded=False dependency_root={site_root}")

