"""Candidate single-database CTP OrderRef and OrderActionRef authority.

This module is an offline integration candidate. It extends one exact
SqliteExecutionStore database and reuses that store's transaction lock,
connection, order identity reservation, command table, and writer lease. It is
not a provider adapter or write authorization.
"""
from __future__ import annotations

import re
import sqlite3
import time
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional

from .contracts import ExecutionScope
from .errors import ContractValidationError, DurableStoreError, IntentConflictError
from .store import (
    CtpCancelTarget,
    CtpDispatchCommand,
    CtpOrderIdentityReservation,
    CtpOrderRefSeedProof,
    CtpOrderTargetProjectionHandle,
    SqliteExecutionStore,
    WriterLease,
)

_ORDER_REF = re.compile(r"^[0-9]{12}$", re.ASCII)
_ACTION_ID = re.compile(r"^[A-Za-z0-9._:-]{1,128}$", re.ASCII)
_MAX_ACTION_REF = 2_147_483_647


@dataclass(frozen=True)
class CtpActionRefSeedProof:
    """Caller-supplied legacy action watermark; it is not trusted native proof."""

    trading_day: str
    legacy_ledger_max_action_ref: int
    legacy_ledger_sha256: str


@dataclass(frozen=True)
class LegacyCtpOrderMapping:
    """One exact old runtime-order to native OrderRef mapping to import."""

    managed_intent_id: str
    runtime_order_id: str
    order_ref: str


@dataclass(frozen=True)
class CtpActionIdentityReservation:
    """Durable action identity tied to the exact reserved order and account."""

    account_key: str
    trading_day: str
    scope_key: str
    managed_action_id: str
    managed_intent_id: str
    runtime_order_id: str
    order_ref: str
    native_action_ref: int
    created_at_ns: int


class CtpIdentityAuthorityError(ValueError):
    """Redacted error raised when the shared identity ledger is unavailable."""


class CtpUnifiedOrderActionAuthority:
    """Order and cancel identity interface backed by one SDK SQLite store.

    OrderRef allocation delegates to the SDK's transactionally serialized
    reservation API. ActionRef rows are added to that same SQLite connection,
    and cancel commands are staged in its existing command table with the
    reserved ActionRef included in the immutable request payload/hash.
    """

    def __init__(self, store: SqliteExecutionStore) -> None:
        if type(store) is not SqliteExecutionStore:
            raise CtpIdentityAuthorityError("exact SDK SQLite execution store is required")
        self.store = store
        try:
            with store._transaction() as cursor:
                cursor.executescript(
                    """
                    CREATE TABLE IF NOT EXISTS ctp_action_ref_watermarks (
                        account_key TEXT NOT NULL,
                        trading_day TEXT NOT NULL,
                        legacy_ledger_max_action_ref INTEGER NOT NULL
                            CHECK(legacy_ledger_max_action_ref BETWEEN 0 AND 2147483647),
                        legacy_ledger_sha256 TEXT NOT NULL
                            CHECK(length(legacy_ledger_sha256) = 64),
                        updated_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(account_key, trading_day)
                    );
                    CREATE TABLE IF NOT EXISTS ctp_action_identity_reservations (
                        account_key TEXT NOT NULL,
                        trading_day TEXT NOT NULL,
                        scope_key TEXT NOT NULL,
                        managed_action_id TEXT NOT NULL,
                        managed_intent_id TEXT NOT NULL,
                        runtime_order_id TEXT NOT NULL,
                        order_ref TEXT NOT NULL
                            CHECK(length(order_ref) = 12 AND order_ref NOT GLOB '*[^0-9]*'),
                        native_action_ref INTEGER NOT NULL
                            CHECK(native_action_ref BETWEEN 1 AND 2147483647),
                        created_at_ns INTEGER NOT NULL,
                        PRIMARY KEY(account_key, scope_key, managed_action_id),
                        UNIQUE(account_key, native_action_ref),
                        FOREIGN KEY(account_key, scope_key, managed_intent_id)
                            REFERENCES ctp_order_identity_reservations(
                                account_key, scope_key, managed_intent_id
                            )
                    );
                    CREATE INDEX IF NOT EXISTS ctp_action_identity_order
                        ON ctp_action_identity_reservations(
                            account_key, scope_key, trading_day, order_ref
                        );
                    """
                )
        except Exception as error:
            raise CtpIdentityAuthorityError("shared CTP identity schema is unavailable") from error

    @staticmethod
    def _scope(scope: ExecutionScope) -> tuple[str, str, str]:
        return SqliteExecutionStore._validate_ctp_order_identity_scope(scope)

    @staticmethod
    def _validate_action_id(value: str) -> str:
        if type(value) is not str or not _ACTION_ID.fullmatch(value):
            raise ContractValidationError("invalid managed_action_id")
        return value

    @staticmethod
    def _validate_action_seed(scope: ExecutionScope, proof: CtpActionRefSeedProof) -> None:
        if type(proof) is not CtpActionRefSeedProof or proof.trading_day != scope.trading_day:
            raise ContractValidationError("invalid CTP ActionRef seed proof")
        if (
            type(proof.legacy_ledger_max_action_ref) is not int
            or not 0 <= proof.legacy_ledger_max_action_ref <= _MAX_ACTION_REF
            or type(proof.legacy_ledger_sha256) is not str
            or len(proof.legacy_ledger_sha256) != 64
            or any(char not in "0123456789abcdef" for char in proof.legacy_ledger_sha256)
        ):
            raise ContractValidationError("invalid CTP ActionRef seed watermark")

    @staticmethod
    def _validate_order_mapping(value: LegacyCtpOrderMapping) -> None:
        if type(value) is not LegacyCtpOrderMapping:
            raise ContractValidationError("legacy CTP mapping must be typed")
        SqliteExecutionStore._validate_command_identifier(
            value.managed_intent_id, "managed_intent_id"
        )
        if (
            type(value.runtime_order_id) is not str
            or not value.runtime_order_id.startswith("bt-managed-v1:")
            or len(value.runtime_order_id) != len("bt-managed-v1:") + 64
            or any(char not in "0123456789abcdef" for char in value.runtime_order_id[14:])
        ):
            raise ContractValidationError("invalid legacy runtime_order_id")
        if type(value.order_ref) is not str or not _ORDER_REF.fullmatch(value.order_ref):
            raise ContractValidationError("invalid legacy OrderRef")

    def import_legacy_order_mappings(
        self,
        scope: ExecutionScope,
        proof: CtpOrderRefSeedProof,
        mappings: Iterable[LegacyCtpOrderMapping],
        *,
        writer_lease: WriterLease,
    ) -> tuple[CtpOrderIdentityReservation, ...]:
        """Import exact legacy bindings and watermark in one SQLite transaction.

        A mapping above the asserted legacy maximum, an incomplete/duplicate
        mapping, or a watermark rollback rejects the whole batch. The digest and
        maxima are caller assertions, not verified native account evidence.
        """

        account_key, trading_day, scope_key = self._scope(scope)
        if type(proof) is not CtpOrderRefSeedProof or proof.trading_day != trading_day:
            raise ContractValidationError("invalid CTP OrderRef legacy seed")
        self.store._validate_ctp_order_ref(proof.native_max_order_ref, "native MaxOrderRef")
        self.store._validate_ctp_order_ref(
            proof.legacy_ledger_max_order_ref, "legacy ledger MaxOrderRef"
        )
        self.store._validate_sha256(proof.legacy_ledger_sha256, "legacy ledger digest")
        rows = tuple(mappings)
        if not rows:
            raise ContractValidationError("legacy OrderRef import must contain mappings")
        for row in rows:
            self._validate_order_mapping(row)
            if int(row.order_ref) > int(proof.legacy_ledger_max_order_ref):
                raise ContractValidationError("legacy OrderRef exceeds imported ledger watermark")
        intents = [row.managed_intent_id for row in rows]
        runtimes = [row.runtime_order_id for row in rows]
        refs = [row.order_ref for row in rows]
        if len(set(intents)) != len(rows) or len(set(runtimes)) != len(rows) or len(set(refs)) != len(rows):
            raise ContractValidationError("duplicate identity in legacy OrderRef import")
        now_ns = time.time_ns()
        result: list[CtpOrderIdentityReservation] = []
        try:
            with self.store._transaction() as cursor:
                self.store._assert_active_writer_lease(cursor, scope, writer_lease)
                watermark = cursor.execute(
                    """SELECT native_max_order_ref, legacy_ledger_max_order_ref
                       FROM ctp_order_ref_watermarks
                       WHERE account_key = ? AND trading_day = ?""",
                    (account_key, trading_day),
                ).fetchone()
                if watermark is not None and (
                    int(proof.native_max_order_ref) < int(watermark["native_max_order_ref"])
                    or int(proof.legacy_ledger_max_order_ref)
                    < int(watermark["legacy_ledger_max_order_ref"])
                ):
                    raise IntentConflictError("CTP OrderRef seed watermark cannot move backward")
                cursor.execute(
                    """INSERT INTO ctp_order_ref_watermarks(
                           account_key, trading_day, native_max_order_ref,
                           legacy_ledger_max_order_ref, legacy_ledger_sha256, updated_at_ns
                       ) VALUES (?, ?, ?, ?, ?, ?)
                       ON CONFLICT(account_key, trading_day) DO UPDATE SET
                           native_max_order_ref = excluded.native_max_order_ref,
                           legacy_ledger_max_order_ref = excluded.legacy_ledger_max_order_ref,
                           legacy_ledger_sha256 = excluded.legacy_ledger_sha256,
                           updated_at_ns = excluded.updated_at_ns""",
                    (account_key, trading_day, proof.native_max_order_ref,
                     proof.legacy_ledger_max_order_ref, proof.legacy_ledger_sha256, now_ns),
                )
                for item in rows:
                    existing = cursor.execute(
                        """SELECT account_key, trading_day, scope_key, managed_intent_id,
                                  runtime_order_id, order_ref, created_at_ns
                           FROM ctp_order_identity_reservations
                           WHERE account_key = ? AND scope_key = ? AND managed_intent_id = ?""",
                        (account_key, scope_key, item.managed_intent_id),
                    ).fetchone()
                    if existing is not None:
                        if (str(existing["trading_day"]), str(existing["runtime_order_id"]),
                                str(existing["order_ref"])) != (
                                trading_day, item.runtime_order_id, item.order_ref):
                            raise IntentConflictError("legacy OrderRef mapping conflicts with authority")
                    else:
                        cursor.execute(
                            """INSERT INTO ctp_order_identity_reservations(
                                   account_key, trading_day, scope_key, managed_intent_id,
                                   runtime_order_id, order_ref, created_at_ns
                               ) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                            (account_key, trading_day, scope_key, item.managed_intent_id,
                             item.runtime_order_id, item.order_ref, now_ns),
                        )
                    row = cursor.execute(
                        """SELECT account_key, trading_day, scope_key, managed_intent_id,
                                  runtime_order_id, order_ref, created_at_ns
                           FROM ctp_order_identity_reservations
                           WHERE account_key = ? AND scope_key = ? AND managed_intent_id = ?""",
                        (account_key, scope_key, item.managed_intent_id),
                    ).fetchone()
                    if row is None:
                        raise DurableStoreError("legacy OrderRef import readback is missing")
                    result.append(self.store._ctp_order_identity_from_row(row))
        except (ContractValidationError, IntentConflictError, DurableStoreError):
            raise
        except sqlite3.IntegrityError as error:
            raise IntentConflictError("legacy OrderRef mapping conflicts with authority") from error
        except Exception as error:
            raise DurableStoreError("legacy OrderRef import failed") from error
        return tuple(result)

    def reserve_submit_order_identity(
        self,
        scope: ExecutionScope,
        proof: CtpOrderRefSeedProof,
        managed_intent_id: str,
        runtime_order_id: str,
        *,
        writer_lease: WriterLease,
    ) -> CtpOrderIdentityReservation:
        """Reserve/read back the sole 12-digit OrderRef from the SDK store."""

        account_key, trading_day, scope_key = self._scope(scope)
        if type(proof) is not CtpOrderRefSeedProof or proof.trading_day != trading_day:
            raise ContractValidationError("invalid CTP OrderRef seed proof")
        reserved = self.store.seed_ctp_order_ref_and_reserve_identity(
            scope, proof, managed_intent_id, runtime_order_id, writer_lease=writer_lease
        )
        current = self.store.read_ctp_order_identity(scope, managed_intent_id)
        if (
            type(reserved) is not CtpOrderIdentityReservation
            or current != reserved
            or (reserved.account_key, reserved.trading_day, reserved.scope_key,
                reserved.managed_intent_id, reserved.runtime_order_id) != (
                account_key, trading_day, scope_key, managed_intent_id, runtime_order_id)
            or type(reserved.order_ref) is not str
            or not _ORDER_REF.fullmatch(reserved.order_ref)
        ):
            raise CtpIdentityAuthorityError("OrderRef reservation readback conflicts")
        return reserved

    @staticmethod
    def _action_from_row(row: sqlite3.Row) -> CtpActionIdentityReservation:
        return CtpActionIdentityReservation(
            account_key=str(row["account_key"]),
            trading_day=str(row["trading_day"]),
            scope_key=str(row["scope_key"]),
            managed_action_id=str(row["managed_action_id"]),
            managed_intent_id=str(row["managed_intent_id"]),
            runtime_order_id=str(row["runtime_order_id"]),
            order_ref=str(row["order_ref"]),
            native_action_ref=int(row["native_action_ref"]),
            created_at_ns=int(row["created_at_ns"]),
        )

    @staticmethod
    def _validate_action_reservation(
        reservation: CtpActionIdentityReservation,
        *,
        account_key: str,
        trading_day: str,
        scope_key: str,
        managed_action_id: str,
    ) -> None:
        if (
            type(reservation) is not CtpActionIdentityReservation
            or (reservation.account_key, reservation.trading_day, reservation.scope_key,
                reservation.managed_action_id) != (
                account_key, trading_day, scope_key, managed_action_id
            )
            or type(reservation.managed_intent_id) is not str
            or not reservation.managed_intent_id
            or type(reservation.runtime_order_id) is not str
            or not reservation.runtime_order_id.startswith("bt-managed-v1:")
            or not _ORDER_REF.fullmatch(reservation.order_ref)
            or type(reservation.native_action_ref) is not int
            or not 1 <= reservation.native_action_ref <= _MAX_ACTION_REF
            or type(reservation.created_at_ns) is not int
            or reservation.created_at_ns <= 0
        ):
            raise DurableStoreError("stored CTP ActionRef identity is malformed")

    def read_cancel_action_identity(
        self, scope: ExecutionScope, managed_action_id: str
    ) -> Optional[CtpActionIdentityReservation]:
        account_key, trading_day, scope_key = self._scope(scope)
        self._validate_action_id(managed_action_id)
        try:
            with self.store._lock:
                row = self.store._connection.execute(
                    """SELECT * FROM ctp_action_identity_reservations
                       WHERE account_key = ? AND trading_day = ? AND scope_key = ?
                         AND managed_action_id = ?""",
                    (account_key, trading_day, scope_key, managed_action_id),
                ).fetchone()
        except sqlite3.Error as error:
            raise DurableStoreError("unable to read CTP ActionRef identity") from error
        if row is None:
            return None
        reservation = self._action_from_row(row)
        self._validate_action_reservation(
            reservation,
            account_key=account_key,
            trading_day=trading_day,
            scope_key=scope_key,
            managed_action_id=managed_action_id,
        )
        return reservation

    def reserve_cancel_action_identity(
        self,
        scope: ExecutionScope,
        managed_action_id: str,
        managed_intent_id: str,
        runtime_order_id: str,
        order_ref: str,
        *,
        legacy_seed: Optional[CtpActionRefSeedProof],
        writer_lease: WriterLease,
    ) -> CtpActionIdentityReservation:
        """Reserve one durable positive ActionRef tied to an existing order.

        ActionRef uses the CTP signed-int field range and is monotonically
        allocated account-wide. Because the SDK snapshot has no ActionRef
        watermark API, a first reservation requires an explicit legacy floor.
        That floor is only caller-supplied collision evidence.
        """

        account_key, trading_day, scope_key = self._scope(scope)
        self._validate_action_id(managed_action_id)
        self.store._validate_command_identifier(managed_intent_id, "managed_intent_id")
        if (
            type(runtime_order_id) is not str
            or not runtime_order_id.startswith("bt-managed-v1:")
            or len(runtime_order_id) != len("bt-managed-v1:") + 64
            or any(char not in "0123456789abcdef" for char in runtime_order_id[14:])
        ):
            raise ContractValidationError("invalid runtime_order_id")
        if type(order_ref) is not str or not _ORDER_REF.fullmatch(order_ref):
            raise ContractValidationError("invalid reserved OrderRef")
        self._validate_action_seed(scope, legacy_seed) if legacy_seed is not None else None
        now_ns = time.time_ns()
        try:
            with self.store._transaction() as cursor:
                self.store._assert_active_writer_lease(cursor, scope, writer_lease)
                existing = cursor.execute(
                    """SELECT * FROM ctp_action_identity_reservations
                       WHERE account_key = ? AND scope_key = ? AND managed_action_id = ?""",
                    (account_key, scope_key, managed_action_id),
                ).fetchone()
                if existing is not None:
                    current = self._action_from_row(existing)
                    if (current.trading_day, current.managed_intent_id,
                            current.runtime_order_id, current.order_ref) != (
                            trading_day, managed_intent_id, runtime_order_id, order_ref):
                        raise IntentConflictError("managed CTP action identity conflicts with reservation")
                    return current
                if legacy_seed is None:
                    raise ContractValidationError("CTP ActionRef requires a legacy seed before reservation")
                order_row = cursor.execute(
                    """SELECT trading_day, runtime_order_id, order_ref
                       FROM ctp_order_identity_reservations
                       WHERE account_key = ? AND scope_key = ? AND managed_intent_id = ?""",
                    (account_key, scope_key, managed_intent_id),
                ).fetchone()
                if order_row is None or (str(order_row["trading_day"]),
                        str(order_row["runtime_order_id"]), str(order_row["order_ref"])) != (
                        trading_day, runtime_order_id, order_ref):
                    raise ContractValidationError("ActionRef target differs from reserved OrderRef identity")
                watermark = cursor.execute(
                    """SELECT legacy_ledger_max_action_ref, legacy_ledger_sha256
                       FROM ctp_action_ref_watermarks
                       WHERE account_key = ? AND trading_day = ?""",
                    (account_key, trading_day),
                ).fetchone()
                if watermark is not None and legacy_seed.legacy_ledger_max_action_ref < int(
                    watermark["legacy_ledger_max_action_ref"]
                ):
                    raise IntentConflictError("CTP ActionRef seed watermark cannot move backward")
                if watermark is None or (
                    int(watermark["legacy_ledger_max_action_ref"])
                    != legacy_seed.legacy_ledger_max_action_ref
                    or str(watermark["legacy_ledger_sha256"]) != legacy_seed.legacy_ledger_sha256
                ):
                    cursor.execute(
                        """INSERT INTO ctp_action_ref_watermarks(
                               account_key, trading_day, legacy_ledger_max_action_ref,
                               legacy_ledger_sha256, updated_at_ns
                           ) VALUES (?, ?, ?, ?, ?)
                           ON CONFLICT(account_key, trading_day) DO UPDATE SET
                               legacy_ledger_max_action_ref = excluded.legacy_ledger_max_action_ref,
                               legacy_ledger_sha256 = excluded.legacy_ledger_sha256,
                               updated_at_ns = excluded.updated_at_ns""",
                        (account_key, trading_day, legacy_seed.legacy_ledger_max_action_ref,
                         legacy_seed.legacy_ledger_sha256, now_ns),
                    )
                latest = cursor.execute(
                    "SELECT MAX(native_action_ref) AS value FROM ctp_action_identity_reservations "
                    "WHERE account_key = ?",
                    (account_key,),
                ).fetchone()
                next_ref = max(
                    legacy_seed.legacy_ledger_max_action_ref,
                    0 if latest is None or latest["value"] is None else int(latest["value"]),
                ) + 1
                if next_ref > _MAX_ACTION_REF:
                    raise DurableStoreError("CTP ActionRef sequence is exhausted")
                cursor.execute(
                    """INSERT INTO ctp_action_identity_reservations(
                           account_key, trading_day, scope_key, managed_action_id,
                           managed_intent_id, runtime_order_id, order_ref,
                           native_action_ref, created_at_ns
                       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (account_key, trading_day, scope_key, managed_action_id,
                     managed_intent_id, runtime_order_id, order_ref, next_ref, now_ns),
                )
                row = cursor.execute(
                    """SELECT * FROM ctp_action_identity_reservations
                       WHERE account_key = ? AND scope_key = ? AND managed_action_id = ?""",
                    (account_key, scope_key, managed_action_id),
                ).fetchone()
                if row is None:
                    raise DurableStoreError("ActionRef reservation readback is missing")
                result = self._action_from_row(row)
        except (ContractValidationError, IntentConflictError, DurableStoreError):
            raise
        except sqlite3.IntegrityError as error:
            raise IntentConflictError("CTP ActionRef identity conflicts with authority") from error
        except Exception as error:
            raise DurableStoreError("unable to reserve CTP ActionRef") from error
        current = self.read_cancel_action_identity(scope, managed_action_id)
        if current != result:
            raise CtpIdentityAuthorityError("ActionRef reservation readback conflicts")
        return result

    def stage_cancel_command(
        self,
        scope: ExecutionScope,
        managed_action_id: str,
        command_id: str,
        request_payload: Mapping[str, Any],
        *,
        target: CtpCancelTarget,
        cancel_target_projection: CtpOrderTargetProjectionHandle | None = None,
        approval_use_id: str,
        approval_digest: str,
        session_binding: Mapping[str, Any],
        writer_lease: WriterLease,
    ) -> CtpDispatchCommand:
        """Persist one cancel command with the reserved ActionRef in its hash."""

        if not isinstance(request_payload, Mapping):
            raise ContractValidationError("CTP cancel request payload must be a mapping")
        if "OrderActionRef" in request_payload:
            raise ContractValidationError("caller-supplied OrderActionRef is forbidden")
        action = self.read_cancel_action_identity(scope, managed_action_id)
        if action is None:
            raise ContractValidationError("cancel action has no durable ActionRef reservation")
        if action.order_ref != target.order_ref:
            raise ContractValidationError("cancel target differs from reserved ActionRef order")
        if type(cancel_target_projection) is not CtpOrderTargetProjectionHandle:
            raise ContractValidationError("typed CTP target projection handle is required")
        projection_reader = getattr(self.store, "read_ctp_order_target_projection", None)
        if not callable(projection_reader):
            raise ContractValidationError("same-store CTP target readback is unavailable")
        projection = cancel_target_projection.projection
        if projection_reader(scope, cancel_target_projection) != projection:
            raise ContractValidationError("same-store CTP target projection readback differs")
        logical = dict(request_payload)
        expected = {
            "OrderRef": target.order_ref,
            "ExchangeID": target.exchange_id,
            "OrderSysID": target.order_sys_id,
            "FrontID": target.front_id,
            "SessionID": target.session_id,
        }
        for key, value in expected.items():
            if type(logical.get(key)) is not type(value) or logical.get(key) != value:
                raise ContractValidationError("cancel target differs from reserved identity: " + key)
        logical["OrderActionRef"] = action.native_action_ref
        command = self.store.stage_ctp_dispatch_command(
            scope,
            command_id,
            "CANCEL",
            logical,
            approval_use_id=approval_use_id,
            approval_digest=approval_digest,
            session_binding=session_binding,
            writer_lease=writer_lease,
            cancel_target=target,
            cancel_target_projection=cancel_target_projection,
        )
        durable = self.store.read_ctp_dispatch_command(scope, command.command_id)
        if (
            durable != command
            or durable is None
            or durable.request_payload.get("OrderActionRef") != action.native_action_ref
            or durable.request_payload.get("OrderRef") != action.order_ref
            or durable.reservation_managed_intent_id != action.managed_intent_id
            or durable.cancel_target_order_ref != target.order_ref
            or durable.cancel_target_exchange_id != target.exchange_id
            or durable.cancel_target_order_sys_id != target.order_sys_id
            or durable.cancel_target_front_id != target.front_id
            or durable.cancel_target_session_id != target.session_id
            or durable.request_payload_sha256 != command.request_payload_sha256
        ):
            raise CtpIdentityAuthorityError("staged cancel command identity readback conflicts")
        return durable


__all__ = [
    "CtpActionIdentityReservation",
    "CtpActionRefSeedProof",
    "CtpIdentityAuthorityError",
    "CtpUnifiedOrderActionAuthority",
    "LegacyCtpOrderMapping",
]

