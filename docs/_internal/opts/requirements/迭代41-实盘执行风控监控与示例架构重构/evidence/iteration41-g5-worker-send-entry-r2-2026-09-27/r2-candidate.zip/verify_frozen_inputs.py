from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(r"D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate")
manifest = json.loads((ROOT / "frozen-input-manifest.json").read_text(encoding="utf-8"))
missing = []
changed = []
ignored_generated = []
for item in manifest:
    relative = Path(item["path"])
    if "__pycache__" in relative.parts:
        # The archived manifest predates execution of these inputs in this
        # interpreter. Bytecode is runtime-generated and is never source
        # integrity evidence; Python may replace or remove it during import.
        ignored_generated.append(item["path"])
        continue
    path = ROOT / relative
    if not path.is_file():
        missing.append(item["path"])
        continue
    if sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        changed.append(item["path"])

print(
    f"manifest_entries={len(manifest)} source_entries={len(manifest) - len(ignored_generated)} "
    f"ignored_generated_entries={len(ignored_generated)} missing={len(missing)} changed={len(changed)}"
)
for path in missing:
    print("missing=" + path)
for path in changed:
    print("changed=" + path)
if missing or changed:
    raise SystemExit(1)
