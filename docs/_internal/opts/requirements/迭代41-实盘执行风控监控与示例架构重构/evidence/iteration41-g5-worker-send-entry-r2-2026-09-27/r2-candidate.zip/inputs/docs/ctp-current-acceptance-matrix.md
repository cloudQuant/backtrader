# CTP 同配置当前开发与 QA 验收矩阵

[V23 唯一版本安装探针独立 QA](evidence/ctp-v23-disposable-installed-wheel-independent-qa-2026-09-27.md)从 44 份冻结文件重建出两份字节相同的临时 wheel；隔离安装的焦点/全包分别为 `186 passed / 2 skipped`、`322 passed / 2 skipped`，来源与 RECORD 核验通过。原始 guard 把本机 loopback 误挡导致 12 项 setup/teardown 错误，修正后原始失败日志仍保留。仅接受本地 wheel 与假模型消费；G1/G5 和默认 CTP 写入不变。[R9 Windows 惰性服务独立重放](evidence/iteration41-g1-r9-windows-inert-custodian-independent-qa-2026-09-27.md)确认 caller 死亡后 broker 完成 pending I/O 取消及两个 Job 清空，但三项同步截止仍晚 3–4 ms；P14 未测，G1 与普通预检仍关闭。

[G6-S 结算确认假候选独立 QA](evidence/ctp-g6s-settlement-attestation-independent-review-2026-09-27/review.md)复跑冻结 `75 passed`，隔离补测 ConfirmDate-only 行形状后 `77 passed`，缺失请求来源时保持零写入。干净 G4-r2 SDK 已有请求 filter 读回参数；旧缺失结论只适用于另一份脏源码。[冻结清单路径更正](evidence/ctp-g6s-settlement-attestation-author-candidate-2026-09-27.md)确认 r1 中文矩阵路径有效、无 U+FFFD；旧哈希只是矩阵后续编辑前的内容记录。SDK 来源封印、真实回调及主 runtime 准入尚未验，G6-S/G7-S 继续关闭。

**2026-09-27 独立负测补记：** [parent 撤单控制端 r3 独立 QA](evidence/ctp-parent-cancel-control-r3-independent-review-2026-09-27.md)核验冻结 payload/evidence `154/154`、`112/112`，独立副本 `15 passed`，但有 monitor DB 写权限的另一进程可在精确读回后、最终清锁前删除事件；首次 release 与 RELEASED replay 仍返回成功，两个风险锁被清除。[r4 离线桥接复核](evidence/ctp-parent-cancel-control-r4-independent-review-2026-09-27.md)在三原节点与五文件焦点分别 `3/3`、`73/73` 通过，普通 SQLite DELETE 被挡，但同用户可删除 trigger 后删行；CTP UNKNOWN 冻结仍不可解除。G1 双阶段 [r3](evidence/ctp-g1-two-stage-r3-independent-review-2026-09-27.md) 的 `83+4+1` 项 fake 检查修正了 exit-2 错误分类；[r4](evidence/ctp-g1-two-stage-r4-independent-review-2026-09-27.md) 独立核验 bootstrap 静态大小与摘要门。真实 Windows R7 和 teardown-r2 各重放 9 个 inert 场景，同步准入仍超过 1800 ms 截止，overlapped 取消无持久 I/O reaper，G1 继续关闭。[SimNow 与 production 最短关键路径独立审阅](evidence/ctp-simnow-production-shortest-path-independent-review-2026-09-27.md)整理了仍需外部主体证明的门槛。上述检查不含 provider 或真实账号。

[G4 typed lifecycle receipt r1 独立审查](evidence/ctp-native-lifecycle-receipt-r1-independent-rejection-2026-09-27.md)在作者三文件 `65 passed` 后发现 Trader receipt 的原生 API generation、epoch、source ID 与同一 API/SPI 当前代次不一致，fake 终态仍报 `clean=True`；r1 拒绝。[r2 独立源码 QA](evidence/ctp-native-lifecycle-receipt-r2-independent-review-2026-09-27.md)三文件 `66 passed`，blocked-Init exact-object 与异常负例验证同代次标签。此候选源不同于 e75 wheel，不提供受监督的真实 native close，G4 继续 `BLOCKED`。

[G4 r2 唯一探针 wheel 独立复核](evidence/ctp-g4-r2-disposable-wheel-independent-review-2026-09-27.md)确认干净 29f8 基线加两项冻结覆盖、两次隔离构建 wheel 字节相同、RECORD/无系统包安装来源正确，安装后 66 项 fake 测试通过。`_ctp` 导入被刻意拦截，真实 DLL 未加载；中间 OBJ 不同、诊断 `cl /Bv` 退出 2 与两类测试警告均保留。仅接受探针制品/离线消费，原生 Join/Release、监督链和默认 SDK pin 仍未通过。

[V23 G1 native-owner 进程绑定源码候选](evidence/ctp-execution-v23-g1-native-owner-process-binding-author-candidate-2026-09-27.md)及[独立 QA](evidence/ctp-execution-v23-g1-owner-binding-independent-review-2026-09-27.md)核验 44/44 冻结 payload、`20 passed` 焦点与 `322 passed / 2 skipped` 全包。旧无进程绑定的 CLAIMED 行迁至 UNKNOWN/POISONED；未配 native-owner adapter 的 READY 行也持久冻结且不触发通用 sender。测试只用假 attestor，未证明 OS 进程/Job 所有权；发行 metadata 仍为与旧包冲突的 `bt_api_execution 0.2.0`。[版本与 pin 迁移映射](evidence/ctp-v23-composite-version-pin-migration-map-2026-09-27.md)仍是只读清单，未形成最终合流 wheel。G5、安装发布及真实 CTP 写入继续关闭。

[G1 R8 独立 Windows 惰性重放](evidence/ctp-g1-r8-independent-review-2026-09-27.md)核验冻结 10/10 payload，并复跑 13/13 个候选预期断言。同步 2 MiB admission 的决定分别在 D=1200 ms 后的 1218 ms（冻结）和 1234 ms（独立）才出现；overlapped reaper 仍属于 caller PID，caller 死亡时 pending I/O 未验。整命令启动及 Job handle 转移在 request D 外，G1 与普通 native `preflight` 保持关闭。

[G1 R9 预启动服务拓扑](evidence/g1-r9-design-index-2026-09-27.md)已归档为只读设计：caller 只提交有界 ticket，独立 I/O broker 与常驻 reaper 分别持有 OVERLAPPED 和 Job/进程句柄，Job1 empty 后才允许 Job2，全部使用同一截止。若唯一 reaper 卡在终止、查询或关闭调用，仍无 Job-empty 证明；此设计未部署、未运行完整 Windows 负测，不改变 G1 关闭裁决。

[G6-P 外部账户 actor 调用图审计](evidence/ctp-g6p-account-actor-architecture-audit-2026-09-27.md)以冻结源码列出 Store legacy submit/cancel 回退、旧 gateway 默认同进程 CTP runtime、SDK direct Req 三类旁路；新 gateway/ZMQ 只有本地路由/静态 peer ACL，没有跨主机 epoch 或共同账户快照。严格 F14 与 production 因此仍 `BLOCKED / LIVE_NO_GO`，该只读审计不构成服务实现或部署验收。

[AccountActorPort r2 独立负测](evidence/ctp-account-actor-port-r2-independent-rejection-2026-09-27.md)在 9/9 冻结 payload、15 项 fake 正例后拒绝接入：未知 provider 可在候选 harness 中回退本地客户端，嵌套 CTP 路由漏判，注入对象在拒绝前被读取；其收据只核 command ID，不能拒绝旧 epoch、错账户和重复 intent。主仓 Store 的 legacy 路由仅经静态审阅，未执行真实报撤单。G6-P 外部主体和共同账户快照仍缺，严格 F14 与 production 保持关闭。

[AccountActorPort r3-r1 独立 QA](evidence/ctp-account-actor-port-r3-r1-independent-review-2026-09-27.md)在 9/9 冻结文件及 24 项 fake 测试下修正未知 provider、原始 API 注入及两层嵌套 CTP 路由分类，拒绝前不再读取注入对象属性；只接受隔离 classifier/harness 合同。收据仍只核 command ID，旧 epoch、错账户和重放仍可进入假端口；主仓尚未接入此门，G6-P 不变。

[G6-P 外部 actor 独立威胁模型与验收路径](evidence/ctp-g6p-account-actor-independent-review-2026-09-27.md)核验 r2 候选与主仓调用面，要求服务端唯一凭据/网络出口、跨主机单调 epoch 与撤销、同一权威版本的资金/全账户委托/成交/持仓快照、服务内最终派发。公开 CTP 的独立查询终包无法提供共同版本；这份只读设计与 15 项 fake 检查均不构成部署证据，G6-P 保持阻断。

**2026-09-27 最新局部证据，裁决不变：** [R3r3+V21 合流源码独立 QA](evidence/ctp-r3r3-v21-composite-source-independent-review-2026-09-27.md)为 `290 passed / 2 SDK-import skipped`，仍未解决 CLAIMED 后进程崩溃的 G5 证明。[parent 撤单控制端 r2](evidence/ctp-parent-cancel-control-r2-independent-review-2026-09-27.md)独立 `23 passed`，后续首次释放回调/读回审计发现缺口，主桥接原有三项正例尚未复跑通过。[G1 双阶段 handler r1](evidence/ctp-g1-two-stage-handler-r1-independent-review-2026-09-27.md)仅 fake 编排通过，[r5 同步创建反例](evidence/ctp-g1-r5-prestarted-host-feasibility-rejection-2026-09-27.md)及[r6 同步入列反例](evidence/ctp-g1-r6-warmed-worker-custodian-rejection-2026-09-27.md)否定整命令 hard deadline。[G6-P/G8-P 实盘路径审计及合成已验签负测](evidence/ctp-g6p-g8p-production-path-audit-2026-09-27.md)保持零 dispatch，外部账户 actor 仍缺。因此普通 `preflight`、SimNow 写入与 production live 均保持关闭。

[主仓 runtime 测试模块隔离修复及全量复跑](evidence/ctp-runtime-yaml-test-isolation-2026-09-27.md)由 root 验证 `1957 passed / 30 skipped / 2 xfailed`，一项既有 pytest 配置警告；该结果只覆盖当前主树的离线单元测试，不替代上述各门证据。

**最新阻断：** [V20 r2 单账户绑定](evidence/ctp-execution-v20-r2-account-binding-independent-review-2026-09-27.md)仅局部独立通过，永久 owner 尚不能安全 clean-close 交接。[Execution R3r2 撤单 claim](evidence/ctp-execution-r3r2-cancel-claim-independent-review-2026-09-27.md)独立接受精确回执和整数 0 的 fail-closed 行为；主桥接 offline 撤单必须先取得 risk dispatch claim，ACKED 后的风险 latch 只能用专用可信终态证明解除。G1 output-channel [r3 伪造 Job-empty 反例](evidence/ctp-g1-output-channel-r3-independent-rejection-2026-09-27.md)由 [r4 本地 helper](evidence/ctp-g1-output-channel-r4-independent-review-2026-09-27.md)限定修复，[r6 post-resume](evidence/ctp-g1-output-channel-r6-post-resume-independent-review-2026-09-27.md)独立 56 项通过；完整双 Job 服务监督链仍待验收。真实交易门均未通过。

**当前增量裁决：** [V20 r0 结构反例和安全重启审计](evidence/ctp-v20-schema-counterexample-and-clean-handoff-audit-2026-09-26.md)已归档，Execution r1 仍被拒绝；r2 独立接受单账户实例绑定。[主仓共享工厂 r1](evidence/ctp-v20-shared-account-runtime-r1-independent-review-2026-09-27.md)独立 84 passed / 2 expected xfailed，只接受未注册 source bundle。[Guardian 编排前切片](evidence/ctp-g1-guardian-preorchestration-independent-review-2026-09-26.md)独立 41 项服务测试与 1 项 parent gate 通过；整命令监督、Session0 token 转换与受保护部署未通过。[G6 r4a](evidence/ctp-claimed-authority-r4a-expiry-independent-review-2026-09-27.md)独立 100 项接受离线有界时差修复，不构成真实写入许可。所有真实交易门保持原状态。

**状态快照：2026-09-27。** 本页把现行 CTP 配置、只读会话与 F14 写入门整理成可执行的开发/QA 顺序。[迭代计划](迭代计划.md)定义准入与政策，本矩阵记录逐门操作状态，[正式验收文档](验收文档.md)列出测试标准；证据更新后须同步这三处，冲突时不得自行将任一状态升级为 PASS。

本次并行实施的本地测试和阻断项另见[2026-09-26 检查点](evidence/iteration41-parallel-checkpoint-2026-09-26.md)；其中标为待复跑、待 hosted CI 或待真实账号的项目不得计入本矩阵的 PASS。

**后续源码切片：** [G6 v2 字段绑定与 READY 延后重试](evidence/ctp-g6-v2-bound-fields-defer-independent-review-2026-09-26.md)独立通过 75 项，八个具有有效签名但不匹配 sealed config 的请求/session 均在真实 V18 Store claim 前拒绝；最后原生调用时的许可时效、撤销及外部 fence 尚在后续开发。V19 r0 的账户 UNKNOWN 撤单 gate 已在 live-bridge 接管用例通过，但独立 QA 随后复现正常释放后租约编号复用的 ABA；r1 修复待独立验收。共享候选的[唯一历史账本路径切换合同](evidence/ctp-v19-account-ledger-cutover-design-2026-09-26.md)已明确，尚不提供自动历史迁移或真实写入。下面各历史制品和测试数字仅适用于其记录的源码时点。

当前裁决为 `LOCAL_OFFLINE_CONTRACTS / NO_WRITE / LIVE_NO_GO`。离线合同、TCP 可达、受监督进程 containment、一个查询流的终包或本地 outbox 回执，都不能单独记作真实 CTP 会话、F14、SimNow 写入或 production PASS。F14 继续执行严格门槛。ADR-41-16 的 SimNow 操作性声明例外仍为 `PROPOSED`、未批准、未实施、未登记；不得按豁免处理。

[V19 r1 独立 Store 核心复验](evidence/ctp-execution-v19-r1-independent-review-2026-09-26.md)随后接受了上述租约 ABA 的限定修复，包含真实 close/reopen 及旧租约 mutation/release 拒绝；固定账本工厂和 clean-close owner handoff 不在该验收内。主仓扩大桥接回归为 63 passed / 4 failed，正在处理；[G1 anchor/Guardian 后续审查](evidence/ctp-g1-anchor-r5-guardian-r1-r2-independent-review-2026-09-26.md)也未关闭部署门。

**目标操作合同：** SimNow 写入验收后，生产账号沿用同一个受保护 `config.yaml`、同一个 `ctp:` 字段结构和同一个受管 CTP 执行 runner。操作者先结束旧 session，再编辑该文件的 `runtime.mode/preset`、账号认证、MD/TD 候选及合约范围，并以同一 runtime identity 和 runner 实现重新启动新 session；活动 session 不热切换。后端不因 set 名称或时间另选环境，也不要求创建生产专用 runner 或第二份配置。QA 须用同一 runner identity 与同一路径证明 stop/edit/restart 后两模式分别解析、封存和准入；旧 SimNow 审批、会话及账本范围不得跨账号/模式复用。当前默认 runner/write admission 尚未实现，此段是验收目标，不是已可下单的说明。

共享 runner 的具体代码接缝、实施顺序与两模式 QA 用例见[CTP 同配置共享 runner 开发与验收合同](CTP同配置共享Runner开发与验收.md)。

## 当前边界

| 能力 | 当前可证明的状态 | QA 记录标签 |
| --- | --- | --- |
| 单一配置与模式解析 | SimNow 与未来 production 共用 `examples/013_3_sa_midfreq_simnow/runtime-ctp-private/config.yaml` 及 canonical `ctp:` 字段。共享 parser 和 fail-closed 负测有离线合同；共享 CTP runner 的 live-mode dispatch/admission 尚不存在。 | `LOCAL_CONTRACT_ONLY` |
| 通用 profile dispatch / CTP managed selector | 通用 dispatch 只接受无 secrets、网络、外部写、managed capability 和审批的 replay/backtest；独立审核及 synthetic CLI run 已通过。新非授权 mode scope 可从同一 canonical `ctp:` 路径将 synthetic simulation/live 两 profile 绑定到同一 runner identity，但不授予 session。合成 SimNow `receipt_required` profile 可在显式 fake 依赖下进入 session，逐动作重封 config；默认 013_3 sandbox 的 `deny`/no runner 与 live unavailable 仍拒绝。最后检查到 native 调用的并发 config mutation 是 P2 上线门。 | `LOCAL_FAKE_ONLY / NO_WRITE` |
| 配置前置选择 | 单对按配置原样使用；多对只在 sealed `ctp.front_pairs` 的 1–8 组成对候选内做有界、无凭据 TCP 探测。MD 与 TD 各须达到重复采样的严格多数（当前三次采样为各至少 2/3）才参与比较，分数为两端成功样本中位延迟的较大值；最低分胜出，平分按配置顺序。诊断入口复核分数和最快候选。无可达整对则拒绝。不得发现配置外地址，也不得按 set、时钟、日历、TradingDay 或服务时段切换。 | `TRANSPORT_ONLY` |
| 最近记录的前置观察 | [2026-09-25 前置复查](evidence/ctp-configured-front-check-2026-09-25.md)：15:55 UTC 的五组显式候选中，零基索引 3 双端各 3/3，按两端各至少 2/3 的新传输门槛被选中；其余四组均 0/3。15:40 UTC 旧门槛的无 pair 结果保留为历史证据。传输结果须运行前重新检查，不能据此宣称账号就绪。 | `TRANSPORT_ONLY / PAIR_3` |
| SimNow TD/MD 会话 | I11 MD-only 身份未验证、matching tick/TradingDay 未确认、Join pending；I12 TD-only 在 SDK artifact 阶段拒绝，未观察 login，queries 未验证，close 未尝试。两次 one-shot marker 都已消耗且不可重试；I14 同配置 TD→MD 方案仍是待实现设计。 | `NOT_ACCEPTED` |
| Native close | `Join` pending 曾在真实受监督观察中出现；供应商对精确 Windows 6.7.7 的退出/回调静止合同未确认。进程退出、Job empty、Python `stop()` 返回都不证明 native `Join`/`Release` 完成。 | `BLOCKED` |
| F14 写入账本、writer fence 与 outbox | 有非授权的离线合同和 fake 候选；`2.0.4+iteration41.i9` CTP 队列租约 wheel 满足总工程版本范围、双构建一致，隔离安装后 10 项队列 fake 和 2 项真实 `TraderClient` + fake API 桥接通过，但未进入默认 pin。默认 CTP Store 仍绑定 fail-closed placeholder。唯一 active authority/cutover、可信回调来源、跨用户/主机账户 fence、共同账户快照、真实逐动作审批与 provider ACK 尚未验收。 | `BLOCKED / NO_WRITE` |
| Production | 目标是未来在同一受保护配置中结束旧 session 后改 mode/preset 和账户、前置、合约字段，再以同一 runtime identity/受管 CTP runner 实现重启新 session；不支持活动 session 热切换，不维护第二份 production config 或 production 专用 runner。当前没有注册共享写入 runner，配置变化和重启本身都不会授权网络、下单或撤单。 | `NOT_RUN / LIVE_NO_GO` |

[Native Join/Release fail-closed 源码候选](evidence/ctp-native-join-fail-closed-source-candidate-2026-09-26.md)的 MD/TD 纯 fake 测试各经独立复核，总计 31 项通过：并发 observer 只允许一次 Join，Release 异常后保留退休对象与 pending 栅栏，重复调用不再次 Release。隔离 CTP 子模块另把 Feed Ref guard 与 Join 完整祖先链无冲突合成，受影响 fake 测试 255 项通过；父 SDK Gitlink 和默认 pin 未指向此合成源码。候选尚未构建或经真实前置观察；供应商生命周期语义与有序 native close 仍未证实，G4 继续 `BLOCKED`。

[G4 假阻塞 Job containment 独立复核](evidence/ctp-g4-fake-stop-job-containment-independent-review-2026-09-27.md)证明在本机假 `RegisterSpi(None)`/`Release()` 阻塞子进程里，外层 Windows Job 可终止并观察 Job 清空；这不是 clean native close。当前 SDK 的 `stop_and_wait(timeout)` 在开始计时 Join 前同步进入这些关闭调用，不能单靠它约束整次关闭。更宽的 SDK 焦点保留一项并发 cleanup 断言失败；没有真实 mapped DLL、同代次原生 Join/Release 或已接线服务回执，G4 仍 `BLOCKED`。

[G4 fake cleanup 测试同步修复](evidence/ctp-g4-cleanup-test-sync-independent-review-2026-09-27.md)随后用假 API 完成事件等待关闭旧并发测试竞态，root 独立复跑 56 项通过。该修复仅修改隔离测试，未修改 e75 生产 SDK；早先失败日志仍归档，G4 原生正面证据仍缺。

**新增离线实现边界（2026-09-26）：** `ctp_shared_managed_runner.py` 为两种模式实现同一路径的非授权准备层，复验两个 profile 的同一 runner identity、模式专属配置/审批摘要和精确所选 pair；对象完整性与从当前文件重封的 freshness 分开检查，后者仍有最终检查至原生调用的竞态。`ctp_shared_managed_runtime.py` 在同一入口按配置模式分派：合成 SimNow 可以注入 fake opener；live 因缺真实生产 session/账本 authority 在探测和读取凭据前拒绝。共享公开 context 不绑定密码/AuthCode 的私密轮换，真实动作必须由底层逐动作凭据绑定校验。

`ctp_f14_external_admission.py` 只定义外部账户写者栅栏与共同快照的逐动作接口，没有受信 authority 或调用接线；`ctp_simnow_operational_window.py` 只定义未获批准的 G6-S 有界窗口、逐动作许可与单流查询观察，固定不声明账户级排他、共同快照或写授权。`backtrader/stores/ctp_managed_projection_bridge.py` 只定义单一 outbox 投影桥，当前 SimNow session 缺匹配端口并在构造时拒绝。Store 的 `_sdk_order_request()` 与独立执行库的 reservation 仍有两个 `OrderRef` 来源，尚无共同事务/可信 reservation port；managed submit/cancel 因此在二次分配和派发前硬拒绝。Store managed 队列已经能在 worker 可见前落同一 typed receipt；但没有可信 caller 接入，v1 bridge 仍先 dispatch 后记 receipt，不能解除 hard reject。

Windows `ctp_config_action_linearization.py` 仍是未集成的本机诊断候选，现把公开名称改为 `ConfigPathReadLease` / `acquire_config_path_read_lease`，避免误称动作线性化。常规写/替换/重命名及非固定驱动器/硬链接的定向负测通过；另一个 `FILE_WRITE_ATTRIBUTES` 句柄在 fake native-action 窗口成功给被租约持有的配置文件设置自定义 reparse tag，证明单靠该共享租约不足以线性化最后重封与原生调用。新增 Python fake race 负测在两种动作的最后重封返回后改写合成配置，确认当前 submit/cancel 仍能进入 native adapter；预期结果为 `2 xfailed`，只记录当前 TOCTOU，不声称跨平台文件系统行为或通过验收，详见[配置动作租约及 Python dispatch 负测](evidence/ctp-config-action-lease-negative-2026-09-26.md)。未来须由受信执行边界同时控制配置/路径变更和唯一原生动作；目前只有类型合同，没有 broker 或 route。以上均不改变默认 `NO_WRITE / LIVE_NO_GO`。本轮主仓 runtime 回归 `1804 passed, 27 skipped, 1 existing warning`，Store 广域回归 `667 passed`，相关 Broker/集成 `23 passed`；SimNow 有界许可/strict F14 合同 `74 passed`，共享入口/配置候选 `26 passed, 1 skipped`。这些均属离线检查，不替代真实 provider 或写入验收。

[独立执行库单 worker 候选证据](evidence/ctp-execution-single-worker-candidate-2026-09-25.md)的后续 source-only commit 为 `b676fe6`：同一 SQLite 行的 queue receipt→claim→一次 sender 合同有 fake 测试；任何 claim 后裸 `REJECTED` 均转为 `UNKNOWN`，不相信 sender 自称无发送。它没有解决跨包 `OrderRef` 双来源，也没有 wheel 或真实发送，不能单独关闭 G5/G6。

Store/outbox 接口复核：新 `CtpManagedDispatchBinding` 已把稳定 `command_id`、OrderRef、审批使用、会话代次、RequestID/ActionRef、精确撤单目标和本地 receipt ID 定为完整 typed DTO；`BtApiStore` 的 managed queue 能在 worker 可见前持久化回执，并拒绝缺失 dispatcher 的旧通用发送。它仍未与独立执行库 SQLite 同一分配器、claim→native send→receipt/UNKNOWN worker 接通；现有 v1 adapter 仍先调用 `sdk_dispatch` 再记 queue receipt，因此受管下单/撤单硬拒绝不得解除。开发须先建立唯一持久派单权威、改用 v2 handoff 并淘汰 v1 顺序，再把 Store/Broker 投影接入；不得在现有队列外另写一份 outbox 记录充当“恢复证明”。

三 wheel [I9 artifact-set 离线候选](evidence/ctp-i9-execution-artifact-set-2026-09-26.md)在无 system-site 的隔离 venv 校验了 base、CTP I9、execution 0.2.0 的本地 wheel 与安装来源；其 Join 修改仍只是另一个源码候选，没有进入该 wheel。I13/I15 父级信任根仍缺独立 source pin/manifest 与外部 review receipt，现有预检显式拒绝 unset pin；不得以本地自签 pin 替代。

后续隔离的 `bt_api_ctp-2.0.4+iteration41.i9.join1` 把 I9 与 Join/Feed Ref 源码合成，Windows CPython 3.11 两个独立根构建为相同 wheel SHA-256 `8d2d845501f43939704c9e6c61610ec1747d613a4e07485245bbb006c8242fbe`。离线 fake 焦点 `254 passed, 1 deselected`；新建无 system-site 的三轮子环境核对 base/CTP/execution 来源和全部依赖 RECORD，补齐已缓存依赖闭包后 `pip check` 通过，未加载 `_ctp`。**此 wheel 与 G5 query-target 源码候选不兼容**：缺 `bt_api_ctp.order_action` 的 `CtpOrderActionEvidence`/回调历史，以及 `_QuerySource.request_filters`；不能用它运行该观察或接通撤单。I13 相关 API 仍只在另一候选源码中，统一来源、受信 pin、真实 native close 和默认路由都没有通过。

I13 ancestry 与 join1 的只读三路合并在 `client.py` 有 14 处原生生命周期/回调来源冲突；`get_order_action_evidence` 需要这些回调历史，不能只复制 DTO。后续在隔离源码候选中已人工合成 Join、managed cancel 和 query getter 回读并通过 fake 焦点；certificate/login observation、bounded stop、credential scope 和队列生命周期接口仍在逐片合成与独立审查。没有统一 wheel/pin，也未解除实际调用门；[本轮检查点](evidence/iteration41-parallel-checkpoint-2026-09-26.md)保留精确来源与测试范围。

[I13 MD 值脱敏源码候选](evidence/ctp-i13-md-value-free-source-review-2026-09-26.md)的 14 条目在独立 Windows clean checkout 与 Git blob 字节核验一致；它是范围有限的 SDK 源码审阅清单，不是父启动器需要的完整运行时 manifest，且无候选 `_ctp.pyd`、wheel、源码 pin 或真实诊断。不能用历史另一份扩展的 fake 测试替它报告通过，更不能据此推断真实账号错误或登录就绪。

**Windows inert guardian 增量（2026-09-26）：** 当前未登记的 `request_inert_guardian` 向预启动 AF_PIPE 服务发送固定 sleep probe，descriptor 绑定源码、解释器和固定回执目录；它不是普通 CTP preflight 启动器。历史五模块 `77 passed` 已由七模块外层 supervisor 的 `84 passed` 检查点补充：owner 死亡后独立 supervisor 按同一 monotonic deadline 请求终止 Job，观察 service/child 退出，但回执可能晚于 deadline。最新 pipe 服务加入 protected 当前用户 DACL 与 handle 回读、远程客户端拒绝、两实例上限、HMAC 和请求消息各自 SID 检查，最终 service 文件作者与根代理独立复跑均 `11 passed`。完整 launcher/setup 仍未置于受监督 Job，descriptor 外部信任、回执目录 ACL/完整发布、全命令硬截止、native close 和普通 preflight 接线仍未验收；G1/G4 不通过。详见[本轮检查点](evidence/iteration41-parallel-checkpoint-2026-09-26.md)。

[G1 服务端截止假负例](evidence/ctp-g1-service-deadline-fake-counterexample-2026-09-27.md)进一步复现：worker Job 已空后同步 `create_receipt` 可超过请求 deadline 和外部 250 ms 等待仍阻塞 handler，放行后返回 `observed`；未写迟到响应。root 用源副本独立复跑。该 fake seam 不证明真实 SCM 进程行为，但足以拒绝当前整命令硬截止声明；独立 host supervisor、两阶段 Job 和真实部署仍待实现。

**新增离线审查边界（2026-09-25）：** I13 MD-only 与 I15 TD-only 候选的受监督子进程已增加 `-I -S -B`、固定虚拟环境安装根和从已校验源码直接编译的导入方式；这些改动只处理子进程。当前调用它们的父进程会在源码核验前普通导入 runtime 模块，可能先执行同版本有效缓存。未登记的 stdlib-only sealed-import 离线切片现在将 Windows file-ID lease 接入 manifest seal 与 source loader；loader 编译经句柄身份和 hash 核验的同一份 bytes，且 checked import 拒绝伪造合法 spec 但未执行的缓存模块。9 项 fake 测试通过；外部 launcher、完整依赖闭包和来源 pin 未完成，因此真实一次性诊断仍列为 P1 阻断。两候选的源码 pin 均未启用，真实 marker、凭据和 provider 未使用；须完成完整父信任根与独立复核。执行侧另有隔离的 OrderRef 持久水位、源回调队列租约与桥接候选；它们不解决 F14 的账户级 writer fence、共同快照、正式三制品 pin 或真实逐动作审批，不能上升为报撤单准入。

日常允许的离线入口是 `bt-runtime doctor --strategy-dir examples/013_3_sa_midfreq_simnow/runtime-ctp-private`。013_3 的 doctor 以兼容性追加的 `operator_actions` 列出离线检查、TCP-only 前置检查、禁用的原生预检、不可用的 run/live；同一文件改为 live 时明确标为配置请求且 `authorization: not_granted`，旧 `next_actions` 保持兼容。`bt-runtime check-ctp-fronts --strategy-dir ...` 只提供配置候选的传输证据；它校验配置文件，但不调用凭据 resolver、不导入 CTP SDK、不登录。普通 `bt-runtime preflight --strategy-dir ...` 当前 fail-closed/不可作为 provider 命令；须先实现并独立验收覆盖父级探测、setup、child、native close 和清理的有界 Windows Job supervisor。I11/I12 监督尝试不解锁该 CLI。

[G5 I9 OrderRef/Store/SDK 离线复核](evidence/ctp-i9-orderref-bridge-audit-2026-09-26.md)将只读 reservation 镜像、当前架构 CTP Feed 源码候选与 Store 的精确类型/同 Store 检查分开记录。Store 负测、8 元组 guard 与真实 I9 源码的 fake stage/queue smoke 共 4 项通过；当前 pinned parent 的无会话旧入口经真实 DirectBackend→Feed 拼接，在 capability 门前拒绝且原生计数为零。子模块 `0609b05` 的 12 位 Ref 必填与原样透传经离线复核；隔离父仓 `7fe53a0` 仅更新 Gitlink，但没有受信 wheel 或默认 pin。独立审计确认 managed fake transport 仍可不用 I9 mirror 接受合法 Ref，普通 Python import 也会优先加载 site-packages CTP；源码路径测试不能代替安装来源验证。隔离 SDK `decd7600` 已在源码中让 managed 请求与镜像字段精确匹配，相关 fake 合同 403 passed、2 skipped；该提交的镜像来源可通过类名/模块名伪造；隔离后续 `5744d3c` 已改用 exact I9 0.2.0 类对象并通过 29 项独立负测，但版本元数据和导入文件尚无受信 wheel/RECORD/origin 证明。已安装受信 I9 wheel 的同一 worker、唯一 OrderRef 权威、forwarding/wire 身份传递、原生请求绑定及取消目标来源仍无完整证明，G5 为 `NOT_PASSED`。

转发层的历史 P1 负测依次发现空白 CTP venue 可绕客户端、`UNKNOWN___FUTURE` 等可跨 venue 送入 CTP adapter，以及直接构造 `OrderRouter` 时无 scope 仍放行。隔离源码 `c33ce478`、`e6cd73b`、`2fec245` 分别修补客户端、ZMQ 服务端和直接 Router/嵌入式入口；最新 exact-commit 独立 fake 复核 132 项通过，规范声明为 CTP 的 adapter 在三类命令、别名、直接 wire、跨账号和无 scope 情形下均为零 adapter 调用。该修复**仍只信 adapter 自报的静态 venue/account**：能把 CTP 实现伪装成 SIM 的同进程自定义 adapter 仍可被写入；ZMQ peer/token 认证缺失，客户端能力查询对部分别名也会误报。QA 应继续要求代码受信的 adapter/账号绑定或该 CTP 转发端固定零写；这些 source-only 负测不关闭 G5。详见上链证据。

隔离父 SDK 合成 `da228691` 已把上述转发补丁与 CTP 子模块 `9976bcbb` 的 Feed Ref 必填和 Join 源码链放在同一棵源码树；精确路径下父仓 fake 469 passed/21 async skipped、子模块 255 passed，独立 reviewer 又复跑 Feed/callback 18、Router scope 107、I9 consumer 29 项。原转发提交在该分支中为补丁等价 cherry-pick，并非精确祖先。`bt_api_execution` Gitlink 仍指向无包源码的初始提交；此合成没有 wheel、真实 native close、受信 I9 权威或默认写路由，G5 继续未通过。

另一条隔离父仓 `c4407b09` 仅把 execution Gitlink 快进到 I9 `b676fe6` 源码，保留 `installable=false` 和默认拒写。I9 子包 fake 133 passed/2 skipped、CTP 255 passed；父仓扩展测试 640 passed/2 skipped/19 failed，其中 5 个旧 arming fixture 未建立 I9 identity binding、14 个当前 risk pin 不含 `AccountScope`，两组失败在更新 execution Gitlink 前已复现。I9 全包另有 38 项 Ruff finding。该候选没有安装元数据、受信 wheel/RECORD/origin 或写入权威；不得因 Gitlink 指向 `0.2.0` 源码而将 G5 升级。

Risk 子包不能只选最早带 `AccountScope` 的 `7343430`：它缺当前 dispatch evidence/authority/resolution API，且旧 generic resolver 可清派发中的冻结状态。独立源码审查找到首个同时具备 typed proof 与禁止 generic 清 `dispatch-inflight` 的后继 `dce2c84d`；即便更新此 pin，父 runtime_plugins 仍须改为提交精确 journal proof 给 `resolve_dispatch_freeze`，不得以更新依赖掩盖旧通用调用。当前 14 个 fake-dispatch 失败继续保持未通过。

后续独立父仓 source-only 集成候选 `5de97235` 已将 I9 child 指向仅作质量整理的 `5579807`、risk 指向 `dce2c84`、monitor 指向干净的 `8498ca7`，并在父层增加 typed proof/authority fence 解析；五个旧 arming fixture 已改为先消费 fake I9 reservation，未放宽生产 guard。用上述精确干净源码路径（base=`3de0fa4`、CTP=`9976bcbb`）重跑父仓非网络 contract 加 fake journal：`1039 passed, 7 skipped, 7 warnings`；risk 子包 `159 passed`、monitor `40 passed`、I9 `133 passed, 2 skipped`。此前 `c4407b09` 的 19 项失败是旧候选历史结果，并未追溯修改。独立 risk 代码审查未找到绕过 journal authority 清除 `dispatch-inflight` 的路径；monitor 后继的独立源码审查确认其 durable outbox 对本地 fake 事实有提交/回读合同，但 control ledger 信任调用方自报的 issuer/authorization，不能当生产鉴权边界，consumer 也须按 event ID 去重。该组合仍无受信 wheel/RECORD/import-origin、共享远端可获取的全部 Gitlink、原生会话或可信撤单目标 issuer；execution 子模块的 `installable=false` 也未改变。以上只更新离线开发证据，**G5 仍未通过，默认 `NO_WRITE / LIVE_NO_GO`**；详情见 [G5 I9 源码审计](evidence/ctp-i9-orderref-bridge-audit-2026-09-26.md)。

G5 新的独立执行子包 `c10ccf5f` 增加持久撤单目标投影与单次消费合同，并把 stage/claim 新鲜度复核移至事务锁内、authority verifier 返回后及 stage 返回前；本地完整子包 `141 passed, 2 skipped`，父仓 source-only 集成 `097a98a7` 的非网络合同与 fake journal `1039 passed, 7 skipped`。独立审查确认其 verifier 仍为注入信任边界，原生查询证据尚不能独立绑定同 Store I9 reservation 与一条 OPEN/PARTIAL 订单，因此没有可信 pre-cancel issuer，也未接默认路由。**G5 继续 NOT_PASSED、NO_WRITE / LIVE_NO_GO。**详见 [G5 I9 源码审计](evidence/ctp-i9-orderref-bridge-audit-2026-09-26.md)。

[R3r2 安装 wheel G5 假链反例](evidence/ctp-g5-r3r2-poisoned-claim-independent-rejection-2026-09-27.md)进一步确认：合成最终准入拒绝时零原生 Req，family owner 已 POISONED 并在重启后拒绝新 owner，但旧命令仍 CLAIMED/inflight，无法写显式 UNKNOWN 回执。独立新 SQLite 与安装 CTP RECORD 核验通过；更宽组合仍有 18 项失败。原作者 JSON 中 Execution wheel SHA 多写一字符，v2 勘误核对了原统一消费者与当前字节。V21 专用终态化和全套复测未完成，G5 仍未通过。

[I13 完整运行时 Python 清单候选](evidence/ctp-i13-runtime-source-manifest-candidate-2026-09-26.md)涵盖当前脏工作树的 91 个源码文件并通过父 launcher 的格式解析；父启动器的离线 seam 现也核对 seal 返回的源码根与有序标准库路径，关闭失败明确拒绝，三组相关 fake 测试 42 项通过。但受信 manifest 路径仍不存在、代码 pin 全零，外部 descriptor、真实 Windows Job、SDK wheel/native 扩展和外部 review 均未绑定；它不能解除 G1 或用于真实只读重试。

[隔离 I13/I15 源码快照候选](evidence/ctp-i13-i15-source-snapshot-candidate-2026-09-26.md)把当时的 91 个源码文件逐字节固定于本机干净提交 `64c271bf`，post-G5 两种 schema 的 manifest 正验通过、单文件破坏负验拒绝；零差异结论仅对应该快照时点，后续主仓 managed allocation reader 等修改不在其中。它仅在本机，runtime manifest 路径仍缺、I13/I15 pin stub 均按设计拒绝，且没有 wheel/origin、受验完整 guardian 链、原生生命周期或外部审查；**G1 继续 NOT_PASSED**。

[I13/I15 outer watchdog 合同](evidence/ctp-i13-i15-outer-watchdog-contract-2026-09-26.md)与[独立 Windows Job 后端候选](evidence/ctp-i13-i15-windows-job-backend-2026-09-26.md)合计 28 项本地测试通过，其中一项仅启动无网络 Python 子进程；异常/超时结果要在长生命周期 custodian 确认接管句柄后才标记 `controls_retained=true`。即使 CreateProcessW 只返回非零线程句柄，也必须托管该线程句柄、Job 与 attribute backing，并保持 UNKNOWN，不能宣称子进程已退出。后端仍未接入受信源码清单、外部 descriptor、隔离解释器、marker、普通 CLI 或 CTP SDK；Python/native 调用自身也没有独立宿主提供的硬性整条命令截止保证。它是开发候选，**G1 仍未通过**，不得据此启动真实账号诊断。

[进程外 supervisor 缺口与验收合同](evidence/ctp-i13-i15-out-of-process-supervisor-gap-2026-09-26.md)明确当前 custodian 仅存在于调用它的进程内，无法在该进程挂死或退出后独立维持和核验控制句柄。后续必须由受信 guardian、长生命周期 Job 宿主和完整 parent launcher 三层共同使用一个绝对截止；本地 wrapper/fake 测试不能替代该宿主验收。

写入口静态清单现覆盖 014/015 历史 CTP 示例，扫描 281 个文件、210 个 writer 候选、49 个动态调用点，零解析错误；259 个发现项的处置验证均保持 `REVIEW_REQUIRED / NOT_AVAILABLE`，不授予可执行路由。见[候选清单](evidence/live-execution-inventory-candidates.json)和[处置清单](evidence/live-execution-writer-dispositions.json)。

## 依赖顺序与验收矩阵

依赖按分支关闭：G0–G5 是共同前置；SimNow 有界操作性验收走 G6-S→G7-S，strict F14/production 另须 G6-P，严格 SimNow 声明才可走 G7-P，生产走 G8-P。任一所需门失败、未知或缺证据时停止该分支，不得用后阶段 fake 或配置结果倒推通过。G7-S 的有限结果不关闭 G6-P，也不解锁生产。

| 门 | 开发/QA 步骤 | PASS 所需证据 | 失败 / 当前状态 |
| --- | --- | --- | --- |
| G0 配置与传输 | 使用合成文件测试 schema、seal、单对/多对互斥、候选上限/去重、坏字段拒绝、Git 忽略与权限检查。需要查看现场传输时，只运行 `doctor` 和 `check-ctp-fronts`，保存脱敏候选索引、采样结果、配置摘要和交易/结算两个写计数。 | 只有配置中显式列出的整对参与选择；选择规则符合上表；私密值不出现在 stdout、日志、receipt、CI 或 Git index。TCP 结果明确标 `TRANSPORT_ONLY`、`provider_login_started=false`、SDK 未导入、交易/结算写入为 0。 | 配置外回退、set/time 规则、单端点可达仍选中、原值泄漏或将 TCP 写成登录 PASS，均拒绝。现场索引 3 的可达性是历史时点结果。 |
| G1 固定制品与有界监督 | 在新、独立的一次性只读尝试前，核验精确 SDK wheel、installed RECORD/import origin、隔离解释器和代码 pin；验证整条命令总预算确实覆盖父级探测、setup、child、close 与 Job 清理。每个尝试用新 ID/marker；已消耗 marker 不重置。 | 可复现的制品身份和 supervisor receipt；预算超时或 close 不确定时 Job containment 证据与 fail-closed 结果；前置 TCP socket 仅在凭据前使用且仅触达配置候选，凭据 resolver/SDK 只在全部适用的来源、制品、配置门通过后调用。 | 普通 CLI preflight 仍不可用。I11/I12 marker 已消耗；未登记的 inert guardian 与独立外层 Job supervisor 在 owner 死亡后验证了 deadline 时请求终止和 child 清理；最新[完整七模块复验](evidence/ctp-inert-supervisor-95-review-2026-09-26.md)为 `95 passed`，保留此前 `93/2` 等失败记录，且回执仍可能晚于 deadline。同步进程/Win32 创建、supervisor 自身卡住、受信 descriptor/ACL、来源 pin、native close 和普通命令整链仍缺，不能保证硬性总截止。 |
| G2 SimNow TD 只读 | 仅在 G1 关闭后，用独立受监督 TD child 重封同一 sealed config，并核对 config/registration digest、候选索引及精确 MD/TD pair。先确认身份，再执行合同要求的七类终态只读查询；不构造 MD client。 | 脱敏回执证明同一账户、TradingDay、连接代次和精确过滤范围；每条请求都有匹配的原生终态证据；scope 字段不完整或不一致时标 `unverified` 并失败；写入与结算计数为 0；TD native close 完整通过后才可开始 MD。 | I12 结果为 `sdk_artifact/runtime_policy_rejected`，login 未观察、查询均 unverified、close 未尝试，marker 已消耗。历史七项查询的终包不替代当前尝试，也不证明共同账户快照。 |
| G3 SimNow MD 只读 | 仅在 TD 查询和 close 均通过后，用另一受监督 child 重封并复核同一配置摘要与 pair，不重新选路。核验 login 原生提交返回、身份字段、精确合约订阅提交与匹配 ACK、首个匹配 tick 和同交易日证据。 | 各同步提交返回精确 `int 0` 后才能公布成功；登录回调身份与配置/会话精确匹配；订阅 ACK 对应所选合约和请求；首 tick 与同交易日正面观察均存在。ACK 单独不够。 | I11 虽观察到订阅 ACK，但身份仍 `identity_unverified`，tick/TradingDay 为 null，Join pending；不得记 MD 或 TD→MD 完整会话通过。I11 marker 已消耗。 |
| G4 MD/TD 原生关闭 | 分别验收 TD、MD close receipt 与创建时相同的 session generation；先确认 SDK/native API 生命周期与供应商对精确 DLL/header 的合同一致，再接入受管运行时。 | receipt 正面证明要求的 `Join` 返回、`Release` 完成和观察线程退出；没有活动 callback；父 Job 也正常清空。所有事实均匹配同一个会话代次。 | 任一 Join pending、Release 未证实、receipt 缺失/矛盾、异常或超时均为失败，保留账户 lease 并停止后续阶段。Job empty、进程退出或 `client_stop_returned=true` 均不替代 native close。 |
| G5 唯一账本与 OrderRef | 先按 D41-01/D41-19 用 ADR 冻结一个 active order authority 和 cutover；目标为独立 `bt_api_execution` SQLite。以 fake client 验证稳定 runtime intent/order/action identity、登录 `MaxOrderRef` 导入、持久 reservation-before-intent、12 位 `OrderRef` 分配、cancel action 到目标订单映射、HedgeFlag 原样传递及损坏 journal 拒绝。逐项核对 Store 命令、SDK outbox、原生请求及回调是否共用同一个持久 command ID。 | 所有 submit/cancel ID 均在同一权威账本中唯一、持久、可重启读回；旧映射导入无冲突且有审计；reservation 不复用；runtime ID 不截断构造 `OrderRef`/`OrderActionRef`；未确认账本/映射前 native dispatch 计数为 0。Store 不另持有可独立发送的第二队列权威。 | ADR 未冻结或出现两个 journal authority、Backtrader `OrderBase.ref` 被用作恢复主键、MaxOrderRef 未核验、映射/文件持久性未证实，均阻断。单独 resolver 测试不等于此门 PASS。 |
| G6-S SimNow 本机执行门 | 仅在 G0–G5 通过后，以 fake/隔离环境验证同一 OrderRef/command 权威、worker 回执栅栏、第二本机 writer 拒绝、逐动作操作窗口许可、当前账户/交易日结算查询、真实来源查询合同、重复/迟到/错账户回调、崩溃切点与 UNKNOWN 不重派。 | `CtpSimNowOperationalWindowPermit`（或经审查的等价类型）与 strict 外部 fence 不可互换；一行账本在发送前持久化 reservation/claim/queue receipt；本机 lease 连续持有；所有不明状态冻结；只报告单流查询和 `UNVERSIONED_QUIESCENCE_CHECK`，跨主机/手动写者排他与共同快照明确 `UNPROVEN`。 | 当前 S permit/真实 callback/唯一 OrderRef 接线未实现，`LOCAL_FAKE_ONLY / NO_WRITE`。不得用 fake strict fence、CTP `bIsLast`、两轮相等或配置字段伪造通过。 |
| G6-P 外部账户控制 | 对拟声明 strict F14 或 production 写入的精确账户/动作，由独立认证服务提供账户级跨主机 writer fence、撤销/转移语义，以及资金、全账户委托、成交、持仓同版本完整快照；测试旁路客户端、旧 epoch、断线与接管。 | 信任根/服务身份、签名或等效认证、共同版本和覆盖范围、逐动作 claim 及最后 dispatch 栅栏均可复核；本地租约和 SimNow S receipt 不能替代。 | 已审公开 CTP 查询接口不提供这些原语；当前无受信 authority 或网关，`F14_STRICT_BLOCKED / LIVE_NO_GO`。 |
| G7-S 真实 SimNow 最小报撤单 | 仅在 G0–G5、G6-S、实际 TD/MD/Join 和当前账户/TradingDay 结算就绪均通过后，在同一受保护 config 的固定合约范围内执行一笔风险受限、仍有可撤余量的限价单：报单→原生订单确认→精确撤单→剩余量终态及订单/成交/持仓/资金回查。先做取消正例；成交正例须待独立平仓路径完成后另做。真实强杀不作为最小真测前置；离线故障注入仍必须覆盖。 | 脱敏证据能对应每次请求、OrderRef、ActionRef、session、callback、查询及数量守恒；审批和本机 lease 始终有效；无未知状态、外来订单或不明敞口；native Join/Release 干净完成。结果只能记 `SIMNOW_OPERATIONAL_ATTESTATION_TESTED`，并注明跨主机写者排他/共同快照未证实。 | 当前 `NOT_RUN / NO_WRITE`；官方 7×24 不提供结算，若配置选中而无真实结算查询则零写结束，不按时间/set 自动切换。全成订单不能充当成功撤单；未知结果不得自动重试。 |
| G7-P strict SimNow F14（可选） | 仅在 G6-P 的外部账户级 fence 与同版本完整快照也对同一 SimNow 账户成立时，重做 G7-S 的逐动作验收并由独立 QA 审核严格外部证据。 | 可单独标 `F14_SIMNOW_ACCEPTED`，范围仅限该 SimNow 账户/窗口，不向 production 继承。 | 当前没有外部 authority；G7-S 结果不能升级成 G7-P。 |
| G8-P 同文件 production | 只用临时目录与合成字段证明 canonical `ctp:` 文件从 `simulation/sandbox` 切至 `live/managed_live_direct` 后仍由同一个受管 CTP runner 解析；旧 SimNow 许可、审批、会话、账本范围全失效。真实生产仅在独立生产制品/账号/session/风控/监控、G5、G6-P、真实权限与恢复验收后开放。 | 操作者届时只改同一受保护 config 的 mode/preset、账号认证、前置和合约；代码复用同一实现但重新办理生产准入，不能复用 SimNow 收据；每步有脱敏审计与失败零写证据。 | 当前默认 live route unavailable，缺生产 session、统一持久账本及外部控制；配置变化在凭据、SDK、网络和写入前拒绝，`NOT_RUN / LIVE_NO_GO`。 |

[G6-P/G8-P 外部账户控制服务合同审计](evidence/ctp-g6p-g8p-external-account-control-service-contract-review-2026-09-26.md)列出可复用的本地接口、服务端最终 dispatch 栅栏、同版本全账户快照和跨主机/旁路验收计划；它是设计审查，没有外部服务或 production 正验，不改变上表状态。

2026-09-26 新增的 `backtrader_runtime/ctp_f14_signed_receipt_contract.py` 是离线、非授权的
canonical receipt 合同验证候选；它要求调用方注入 issuer/key/audience pins，并提供可用注入
公钥与 SHA-256 pin 校验真实 Ed25519 签名的本地 verifier，只返回 receipt-shape observation。
它没有受信生产服务 pin、服务端 actor、跨主机或服务端 replay/epoch ledger、admission handle 或
executor/native dispatch；验签不能证明真实账户排他或快照来源。此项不改变
G6-P `BLOCKED / LIVE_NO_GO`、G8-P `NOT_RUN / LIVE_NO_GO` 或默认 `NO_WRITE`。
显式注入的本机 SQLite observation fence 可跨进程和重启拒绝重放，但 ACL/owner 未验收且不是服务端 fence。
此离线 slice 的 focused fake 与临时 Ed25519 密钥测试 `25 passed`，兼容 venv 复跑无 warning；Ruff 检查通过。

G5/G6-S 的新增负测必须区分三个状态：发送前已持久化 `queued=false` 才是本地拒绝；发送 claim 之后任何裸 `REJECTED` 或未知异常都须落 `UNKNOWN` 并停止重派；`QUEUED` 只表示本地队列接纳。受管 CTP 的公开裸 `enqueue_cancel` 在 recovery armed/unarmed 两种状态都须于请求构造和 worker 启动前拒绝，heap、SDK cancel、原生写入计数均为 0。真实 Store worker 只有在同一 SQLite 行已持久化确切 queue receipt 后才可看见命令；写入失败不能通知 worker。重复 worker、重启和多连接均须保持同一 OrderRef 与至多一次 native send，不得凭任意 sender payload 自称“无发送”而解除冻结。

G7-S 先验收成功撤单，成交另作需具备平仓/归零路径的正例；依据是 [SimNow 官方 CTP Mini API 手册](https://www.simnow.com.cn/DocumentDown/api_3/5_2_4/CTPIIMini_API_Ver1.0.pdf)把“已成交或已撤单”“报单全部成交”列为撤单失败的常见原因。两类正例均须受相同逐动作风控和账户对账门约束，不能为了取得撤单回执扩大订单量或敞口。[SimNow 官方产品说明](https://www.simnow.com.cn/product.action)明确第二套 7×24 环境仅提供 API 测试而不提供结算等服务；当前运行时仍只按配置前置和连通性选路，G7-S 的结算/资金验收必须以该次账户的实际正面证据为准，不能由端点名称或 TCP 连接推断通过。

[7×24 与结算就绪门槛审查](evidence/ctp-settlement-readiness-gate-audit-2026-09-25.md)确认：当前 managed TD readiness 要求当前账户/TradingDay 的真实结算确认查询记录，7×24 官方产品能力未承诺该记录。即使配置中的 7×24 pair 因 TCP 延迟最低而被选中，也只能继续做连接/只读 API 诊断；缺少该真实记录时写入门必须保持关闭。完整 G7 应由操作者在同一受保护 `config.yaml` 显式配置具备结算服务的正常环境，并重新完成全部会话和账户门；代码不根据地址、set 标签或时间自动切换。

[MD 回调源码复核](evidence/ctp-md-callback-source-audit-2026-09-25.md)已把 I2 的请求 ID 不匹配与 I4/I6 后续身份未验证分开；目前没有足以确认账号错误的证据。G3 下一轮先用隔离 C++/SWIG director fake 验证 borrowed-pointer 与字段形状，再考虑任何新的受监督只读观察。此源码审计不改变 G1～G4 的阻断状态。

**Windows MD ABI/制品归属（2026-09-26）：** I2/I4/I6/I7 已审计源码与 wheel payload 均指向 full CTP v6.7.7 MD DLL/header/SWIG 组合，哈希一致，未见 Mini 1.7.0 混入；这只排除已审计 payload 内的混装可能。四次 child 的 `thostmduserapi_se.dll` 实际 mapped-module receipt、官方归档及官方 SHA-256 均缺失，因此不能证明运行时实际 DLL，也不能解释 request ID、空身份字段或 Join pending。根因未定，G1–G4 阻断不变。详见 [I2/I4/I6/I7 Windows MD ABI/制品归属离线核对](evidence/ctp-i2-i4-i6-i7-windows-abi-artifact-audit-2026-09-26.md)。

[已映射模块身份回执候选](evidence/ctp-mapped-module-identity-candidate-2026-09-26.md)在隔离本地提交 `a3b3fd89` 中提供当前进程模块表的 pathless/文件身份接缝，16 项 fake 测试通过；尚未在真实受监督 child 内调用 Windows API，也不能排除路径重解析到网络、并发改写、映射后文件替换或内存中字节差异。G1 通过前不接诊断入口，MD 根因仍未定。

候选代码变更后的本地最低复测集只使用合成配置和 fake dependency；在仓库根目录运行并保存精确 revision、完整命令、退出码及脱敏日志。该结果只能记 `LOCAL_CONTRACT_PASS`：

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = "1"
python -m pytest -q -p no:asyncio --tb=short `
  tests/unit/runtime/test_runtime_config.py `
  tests/unit/runtime/test_ctp_private_config_setup.py `
  tests/unit/runtime/test_ctp_private_runtime_git_hygiene.py `
  tests/unit/runtime/test_ctp_front_pair_probe.py `
  tests/unit/runtime/test_ctp_configured_front_check.py `
  tests/unit/runtime/test_ctp_simnow_readonly_runtime.py `
  tests/unit/runtime/test_ctp_simnow_native_readiness.py `
  tests/unit/runtime/test_ctp_managed_reconciliation.py `
  tests/unit/runtime/test_ctp_queue_receipt.py `
  tests/unit/runtime/test_ctp_simulation_execution.py `
  tests/unit/stores/test_managed_ctp_store_adapter.py
```

若涉及 `bt_api_execution`，还须在其冻结候选及隔离环境上单独复跑 SDK 的账本、callback/outbox 与崩溃恢复焦点集，并记录独立制品来源；不要把另一个工作树或旧 wheel 的数字并入主仓结果。此处列出的本地集不包含 provider/真实账号步骤，也不解锁任何已消耗的一次性 marker。

## 可接受的状态跃迁

| 标签 | 可写入条件 |
| --- | --- |
| `LOCAL_CONTRACT_PASS` | 精确 revision 的 fake/schema 测试通过；明确注明未访问 provider，不能抬升为会话或写入结果。 |
| `TRANSPORT_ONLY` | 配置候选中有完整 MD/TD TCP reachability；明确注明时点、候选索引、采样和零认证/SDK/写入。 |
| `SIMNOW_READ_ONLY_ACCEPTED` | G1–G4 每项均有同一代码/制品/配置摘要/pair 的正面原生证据；未知与历史回执不计入。 |
| `SIMNOW_OPERATIONAL_ATTESTATION_TESTED` | 仅当 [ADR-41-16 option B](ADR-41-16-simnow-f14-writer-fence-proposal.md) 获正式批准、G0–G5/G6-S/G7-S 对具名 SimNow 账户和窗口逐项验收通过，才可记录一次有界操作性结果；账户级跨主机排他与共同快照仍为 `UNPROVEN`，不等于 F14 或生产 PASS。当前 `NOT_RUN`。 |
| `F14_SIMNOW_WRITE_ACCEPTED` | 只有严格 F14、G5/G6-P/G7-P 全部完成，且服务端账户覆盖/共同快照/账户级 writer fence 经独立 QA 验证后，才能申请裁决；不能由 S 级结果、自签收据或本文件宣布通过。 |
| `PRODUCTION_ACCEPTED` | 另一个独立生产阶段完成同文件 fail-closed 与正向 route、账户/制品/会话、审批、risk/monitor、服务端 fence、恢复及真实证据验收；不得由 SimNow PASS 自动继承。 |

发现任何配置/账户/候选/制品变化、原生状态未知、回调无法同源关联、账本冲突、超时、进程异常退出、非预期写入或日志脱敏失败，立即标记当前门失败/未知、停止后续门并保留冻结；不得复位已消耗的一次性 marker。S 与 strict F14 状态分别依据[唯一决策 ADR](ADR-41-16-simnow-f14-writer-fence-proposal.md)、[计划中的 F14 顺序和外部依赖](迭代计划.md)、[验收门槛](验收文档.md)及本目录的增量证据更新。

## 相关证据与操作文档

- [I13/I15 外层父进程信任根设计与离线切片](evidence/ctp-i13-i15-parent-launcher-trust-root-design-2026-09-25.md)：pre-import stdlib launcher、stdlib pycache 旁路、PyYAML origin pin、volume/file-ID source lease 与 no-system venv 的设计；manifest/source loader lease 与 inert launcher 已有未登记的离线切片，受信生产入口和完整制品 pin 仍未验收，不授权真实只读尝试。
- [I13/I15 惰性进程独立截止监督切片](evidence/ctp-i13-i15-inert-deadline-supervisor-process-slice-2026-09-26.md)：owner 死亡后的 outer Job 终止请求与回执时点分离，只是 inert Windows 进程证据，G1 未通过。
- [配置与运行模式规格](配置与运行模式规格.md)：唯一配置路径、canonical `ctp:` 和 front-pair 规则。
- [实施状态与验收快照](实施状态与验收快照.md)：当前 `NO_WRITE / LIVE_NO_GO`、普通 `preflight` fail-closed 状态。
- [开发与 QA 交接清单](开发与QA交接清单.md)：F14、Store/CTP typed handoff 与真实账号阶段证据要求。
- [前置传输复查](evidence/ctp-configured-front-check-2026-09-25.md)：同一配置的脱敏 TCP 观察。
- [I11 MD-only 诊断](evidence/ctp-i11-md-diagnostic-2026-09-25.md)及[I12 TD-only 诊断](evidence/ctp-i12-td-only-diagnostic-2026-09-25.md)：已消耗的一次性只读尝试结果。
- [I14 TD→MD 设计](evidence/ctp-i14-combined-readonly-plan-2026-09-25.md)：当前仍待实现的只读验收候选。
- [Native Join 源码审查](evidence/ctp-native-join-source-review-2026-09-25.md)：已证实源码顺序、未证实根因和待厂商确认问题。
- [离线写入边界增量证据](evidence/ctp-offline-write-boundary-progress-2026-09-25.md)：当前 managed handoff、outbox、回调、账户 fence 与账本边界。
- [ADR-41-16 F14 writer-fence 提案](ADR-41-16-simnow-f14-writer-fence-proposal.md)：`PROPOSED` 的未批准选项；严格 F14 仍是当前决定。
