from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
research = root.parent
manifest_path = root / "candidate-output-manifest.json"
manifest_sha_path = root / "candidate-output-manifest.sha256"
zip_path = research / "r2-candidate.zip"
receipt_path = research / "evidence/r2-candidate-archive-verification.json"
if zip_path.exists():
    raise SystemExit(f"Refusing to overwrite frozen archive: {zip_path}")

excluded_dirs = {"__pycache__", ".pytest_cache"}
excluded_names = {manifest_path.name, manifest_sha_path.name}
def is_generated_cache(path: Path) -> bool:
    return any(part in excluded_dirs for part in path.relative_to(root).parts) or path.suffix == ".pyc"

def digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()

files = sorted(
    (path for path in root.rglob("*") if path.is_file()
     and path.name not in excluded_names and not is_generated_cache(path)),
    key=lambda path: path.relative_to(root).as_posix(),
)
records = [
    {
        "path": path.relative_to(root).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": digest(path),
    }
    for path in files
]
manifest = {
    "format": "iteration41-g5-send-entry-r2-candidate.v1",
    "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "status": "R2_FAIL_CLOSED / G5 NOT ACCEPTED",
    "base_r1_candidate_zip_sha256": "c75cba6adcf7db95e420d0d4cfafac39e7179eb6db985cce5096a4c49237d268",
    "base_r1_output_manifest_sha256": "5ddb3ca53bff3d61d287846a5feeaa8814fa9d211da109dd05f527c534351fbf",
    "files_count": len(records),
    "files": records,
    "excluded_generated_cache_files": sum(
        1 for path in root.rglob("*") if path.is_file() and is_generated_cache(path)
    ),
    "verification": {
        "r2_implementation_focus": "18 passed",
        "frozen_sdk_candidate_source": "53 passed / 4 failed",
        "frozen_sdk_baseline_source": "57 passed / 0 failed",
        "ruff_select_E4_E7_E9_F_I": "passed",
        "py_compile": "passed",
        "r1_expected_red_regressions_preserved": 3,
        "r1_regression_evidence_copy_hashes_match": True,
        "r2_patch_replay": "git apply --check and apply passed; modified file SHA-256 matches exact",
        "native_sdk_calls": 0,
    },
    "known_sdk_candidate_failures": [
        {
            "count": 3,
            "cause": "legacy tests assert schema version 5 after the frozen candidate adds schema version 6",
            "test_names": [
                "test_v4_execution_store_migrates_to_command_outbox_v5",
                "test_v2_execution_store_adds_nullable_cumulative_commission_column",
                "test_v3_execution_store_adds_ctp_order_identity_reservations",
            ],
        },
        {
            "count": 1,
            "cause": "legacy direct CANCEL fixture omits the exact typed target projection required by schema 6",
            "test_name": "test_cancel_command_binds_orderref_exchange_system_order_and_session_ids",
        },
    ],
    "limitations": [
        "No trusted native target-projection producer/readback; the default verifier rejects.",
        "No trusted time authority or reviewed/pinned SDK send entry exists; the code-owned port always rejects before native entry.",
        "Prepared/session binding does not supply current connection_generation or OS process_generation proof.",
        "Caller-supplied seed assertions remain non-authorizing; there is no trusted MaxOrderActionRef watermark/cutover.",
        "The candidate ActionRef allocator must not be mixed with V21's separate allocator starting at 1.",
        "The Backtrader caller bridge/main patch remains on R1 sender-taking API and is not integrated; mismatch fails closed.",
        "No real SDK, network, account, order, cancel, session, or live route was exercised or authorized.",
    ],
}
manifest_path.write_text(
    json.dumps(manifest, ensure_ascii=True, sort_keys=True, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
manifest_hash = digest(manifest_path)
manifest_sha_path.write_text(
    f"{manifest_hash}  {manifest_path.name}\n", encoding="ascii", newline="\n"
)

archive_files = sorted(
    (path for path in root.rglob("*") if path.is_file() and not is_generated_cache(path)),
    key=lambda path: path.relative_to(root).as_posix(),
)
with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in archive_files:
        archive.write(path, arcname=path.relative_to(root).as_posix())
with zipfile.ZipFile(zip_path, "r") as archive:
    bad_member = archive.testzip()
    names = set(archive.namelist())
expected_names = {path.relative_to(root).as_posix() for path in archive_files}
if bad_member is not None or names != expected_names:
    raise SystemExit(f"ZIP verification failed: bad_member={bad_member!r}, names_match={names == expected_names}")

receipt = {
    "format": "iteration41-g5-send-entry-r2-archive-verification.v1",
    "candidate_root": str(root),
    "zip_path": str(zip_path),
    "zip_sha256": digest(zip_path),
    "zip_bytes": zip_path.stat().st_size,
    "zip_member_count": len(names),
    "zip_crc_bad_member": bad_member,
    "zip_member_set_matches_candidate_files": True,
    "manifest_sha256": manifest_hash,
    "manifest_file_count": len(records),
    "candidate_files_including_manifest_and_sha": len(archive_files),
    "r1_evidence_copy_receipt": "evidence/r1-send-entry-regressions-copy-verification.json",
    "status": "R2_FAIL_CLOSED / G5 NOT ACCEPTED",
}
receipt_path.parent.mkdir(parents=True, exist_ok=True)
receipt_path.write_text(
    json.dumps(receipt, ensure_ascii=True, sort_keys=True, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
zip_sha_path = zip_path.with_suffix(zip_path.suffix + ".sha256")
zip_sha_path.write_text(f"{receipt['zip_sha256']}  {zip_path.name}\n", encoding="ascii", newline="\n")
print(json.dumps(receipt, ensure_ascii=True, sort_keys=True, indent=2))