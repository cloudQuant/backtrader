from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from itertools import count
from queue import Queue

import pytest
from bt_api_execution import (
    ContractValidationError,
    CtpCancelTarget,
    CtpDispatchReceipt,
    CtpOrderRefSeedProof,
    CtpVerifiedOrderTargetProjection,
    DurableStoreError,
    ExecutionScope,
    IntentConflictError,
    SqliteExecutionStore,
)
from bt_api_execution.contracts import payload_sha256
from bt_api_execution.ctp_identity_authority import (
    CtpActionRefSeedProof,
    CtpIdentityAuthorityError,
    CtpUnifiedOrderActionAuthority,
    LegacyCtpOrderMapping,
)


def _scope() -> ExecutionScope:
    return ExecutionScope("CTP", "simulation", "g5-account", "strategy.g5", "20260927")


def _runtime_id(value: str) -> str:
    return "bt-managed-v1:" + sha256(value.encode("ascii")).hexdigest()


def _order_seed(*, native: str = "000000000010", legacy: str = "000000000012"):
    return CtpOrderRefSeedProof(
        trading_day="20260927",
        native_max_order_ref=native,
        legacy_ledger_max_order_ref=legacy,
        legacy_ledger_sha256=sha256(b"frozen synthetic legacy OrderRef ledger").hexdigest(),
    )


def _action_seed(max_ref: int = 41):
    return CtpActionRefSeedProof(
        trading_day="20260927",
        legacy_ledger_max_action_ref=max_ref,
        legacy_ledger_sha256=sha256(b"frozen synthetic legacy ActionRef ledger").hexdigest(),
    )


def _open(path):
    store = SqliteExecutionStore(path)
    authority = CtpUnifiedOrderActionAuthority(store)
    scope = _scope()
    lease = store.acquire_or_renew_lease(scope, "g5-test-owner", ttl_ns=120_000_000_000)
    return store, authority, scope, lease


def _reserve_order(authority, scope, lease, intent="intent-1", token=None, proof=None):
    return authority.reserve_submit_order_identity(
        scope,
        proof or _order_seed(),
        intent,
        _runtime_id(token or intent),
        writer_lease=lease,
    )


def _cancel_target(order_ref: str) -> CtpCancelTarget:
    return CtpCancelTarget(order_ref, "SHFE", "SYS-8842", 17, 29)


def _request(target: CtpCancelTarget):
    return {
        "InstrumentID": "rb2710",
        "OrderRef": target.order_ref,
        "ExchangeID": target.exchange_id,
        "OrderSysID": target.order_sys_id,
        "FrontID": target.front_id,
        "SessionID": target.session_id,
        "ActionFlag": "0",
        "LimitPrice": 0.0,
        "VolumeChange": 0,
    }


class _SyntheticNativeOrderQueryEvidence:
    """Test-only stand-in, not provider or native SDK query evidence."""

    instrument_id = "rb2710"
    exchange_id = "SHFE"
    order_sys_id = "SYS-8842"
    session_generation_id = "synthetic-session-generation"
    query_front_id = 17
    query_session_id = 29
    front_id = 17
    session_id = 29

    def __init__(self):
        self.query_request_id = next(_SYNTHETIC_QUERY_REQUEST_IDS)


_SYNTHETIC_QUERY_REQUEST_IDS = count(71)


class _SyntheticOrderQueryVerifier:
    """Test-only verifier for exercising Store durability and consumption."""

    def verify_order_target(self, scope, reservation, evidence, *, now_ns):
        if type(evidence) is not _SyntheticNativeOrderQueryEvidence:
            raise ContractValidationError("synthetic typed query evidence required")
        return CtpVerifiedOrderTargetProjection(
            account_key=reservation.account_key,
            scope_key=reservation.scope_key,
            trading_day=reservation.trading_day,
            managed_intent_id=reservation.managed_intent_id,
            runtime_order_id=reservation.runtime_order_id,
            order_ref=reservation.order_ref,
            account_fingerprint_sha256=sha256(b"synthetic account").hexdigest(),
            registration_digest=sha256(b"synthetic registration").hexdigest(),
            instrument_id=evidence.instrument_id,
            exchange_id=evidence.exchange_id,
            session_generation_id=evidence.session_generation_id,
            connection_generation=1,
            query_front_id=evidence.query_front_id,
            query_session_id=evidence.query_session_id,
            query_request_id=evidence.query_request_id,
            query_filters_sha256=sha256(b"synthetic filters").hexdigest(),
            query_records_sha256=sha256(b"synthetic records").hexdigest(),
            source_evidence_sha256=sha256(b"synthetic source evidence").hexdigest(),
            query_record_count=1,
            query_match_count=1,
            query_complete=True,
            query_terminal=True,
            query_timed_out=False,
            query_error_id=0,
            late_callback_count=0,
            order_sys_id=evidence.order_sys_id,
            front_id=evidence.front_id,
            session_id=evidence.session_id,
            provider_state="OPEN",
            quantity=1,
            traded_quantity=0,
            remaining_quantity=1,
            verifier_id="test-only.synthetic-order-query-verifier",
            verified_at_ns=now_ns,
            expires_at_ns=now_ns + 5_000_000_000,
        )


def _projection(store, scope, order):
    return store.issue_ctp_order_target_projection(
        scope,
        order.managed_intent_id,
        _SyntheticNativeOrderQueryEvidence(),
        verifier=_SyntheticOrderQueryVerifier(),
    )


def _queue_receipt(command, outcome="QUEUED"):
    return CtpDispatchReceipt(
        receipt_type="ctp_dispatch_receipt.v1",
        command_id=command.command_id,
        account_key=command.account_key,
        scope_key=command.scope_key,
        trading_day=command.trading_day,
        operation=command.operation,
        request_payload_sha256=command.request_payload_sha256,
        reservation_managed_intent_id=command.reservation_managed_intent_id,
        order_ref=command.order_ref,
        cancel_target_order_ref=command.cancel_target_order_ref,
        cancel_target_exchange_id=command.cancel_target_exchange_id,
        cancel_target_order_sys_id=command.cancel_target_order_sys_id,
        cancel_target_front_id=command.cancel_target_front_id,
        cancel_target_session_id=command.cancel_target_session_id,
        approval_use_id=command.approval_use_id,
        approval_digest=command.approval_digest,
        session_binding_sha256=command.session_binding_sha256,
        outcome=outcome,
        native_receipt_payload={"local_queue_code": 0, "provider_ack": False},
    )


def _stage_cancel(authority, store, scope, lease, action, command_id="cancel-1"):
    order = store.read_ctp_order_identity(scope, action.managed_intent_id)
    assert order is not None
    target = _cancel_target(action.order_ref)
    return authority.stage_cancel_command(
        scope,
        action.managed_action_id,
        command_id,
        _request(target),
        target=target,
        cancel_target_projection=_projection(store, scope, order),
        approval_use_id="approval-" + command_id,
        approval_digest=sha256(b"synthetic approval digest").hexdigest(),
        session_binding={
            "session_generation_id": "synthetic-session-generation",
            "dispatch_front_id": 17,
            "dispatch_session_id": 29,
            "session": "opaque",
        },
        writer_lease=lease,
    )


def test_order_reservation_readback_survives_restart_and_concurrent_connections(tmp_path):
    path = tmp_path / "single-authority.sqlite3"
    store, authority, scope, lease = _open(path)
    first = _reserve_order(authority, scope, lease)
    assert first.order_ref == "000000000013"
    store.close()

    reopened, authority2, scope2, lease2 = _open(path)
    try:
        assert authority2.reserve_submit_order_identity(
            scope2, _order_seed(), "intent-1", _runtime_id("intent-1"), writer_lease=lease2
        ) == first
        stores = [SqliteExecutionStore(path) for _ in range(8)]
        authorities = [CtpUnifiedOrderActionAuthority(item) for item in stores]
        try:
            def reserve(index):
                return _reserve_order(
                    authorities[index], scope2, lease2,
                    intent=f"parallel-{index}", token=f"parallel-{index}"
                ).order_ref

            with ThreadPoolExecutor(max_workers=len(stores)) as pool:
                refs = tuple(pool.map(reserve, range(len(stores))))
            assert sorted(refs) == [f"{value:012d}" for value in range(14, 22)]
        finally:
            for item in stores:
                item.close()
    finally:
        reopened.close()


def test_legacy_mappings_import_atomically_and_conflicts_do_not_overwrite(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "legacy.sqlite3")
    try:
        proof = _order_seed(native="000000000019", legacy="000000000021")
        mappings = (
            LegacyCtpOrderMapping("old-one", _runtime_id("old-one"), "000000000006"),
            LegacyCtpOrderMapping("old-two", _runtime_id("old-two"), "000000000021"),
        )
        imported = authority.import_legacy_order_mappings(
            scope, proof, mappings, writer_lease=lease
        )
        assert tuple(row.order_ref for row in imported) == (
            "000000000006", "000000000021"
        )
        assert store.read_ctp_order_identity(scope, "old-one") == imported[0]
        next_row = _reserve_order(
            authority, scope, lease, intent="new-after-import", token="new-after-import",
            proof=proof,
        )
        assert next_row.order_ref == "000000000022"

        with pytest.raises(IntentConflictError, match="legacy OrderRef mapping conflicts"):
            authority.import_legacy_order_mappings(
                scope,
                proof,
                (LegacyCtpOrderMapping("old-one", _runtime_id("changed"), "000000000006"),),
                writer_lease=lease,
            )
        assert store.read_ctp_order_identity(scope, "old-one") == imported[0]

        before = store._connection.execute(
            "SELECT COUNT(*) FROM ctp_order_identity_reservations"
        ).fetchone()[0]
        with pytest.raises(Exception, match="duplicate identity"):
            authority.import_legacy_order_mappings(
                scope,
                proof,
                (
                    LegacyCtpOrderMapping("dup", _runtime_id("dup-1"), "000000000020"),
                    LegacyCtpOrderMapping("dup", _runtime_id("dup-2"), "000000000021"),
                ),
                writer_lease=lease,
            )
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_order_identity_reservations"
        ).fetchone()[0] == before
    finally:
        store.close()


def test_max_order_ref_floor_and_twelve_digit_exhaustion_fail_closed(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "max-order-ref.sqlite3")
    try:
        last = _reserve_order(
            authority, scope, lease, intent="last", token="last",
            proof=_order_seed(native="999999999998", legacy="000000000000"),
        )
        assert last.order_ref == "999999999999"
        with pytest.raises(DurableStoreError, match="sequence is exhausted"):
            _reserve_order(
                authority, scope, lease, intent="overflow", token="overflow",
                proof=_order_seed(native="999999999998", legacy="000000000000"),
            )
        with pytest.raises(Exception, match="invalid native MaxOrderRef"):
            bad = _order_seed(native="1000000000000", legacy="000000000000")
            _reserve_order(authority, scope, lease, intent="bad", token="bad", proof=bad)
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_order_identity_reservations"
        ).fetchone()[0] == 1
    finally:
        store.close()


def test_order_and_action_refs_are_distinct_stable_and_restart_safe(tmp_path):
    path = tmp_path / "action-restart.sqlite3"
    store, authority, scope, lease = _open(path)
    order = _reserve_order(authority, scope, lease)
    first = authority.reserve_cancel_action_identity(
        scope, "cancel-action-1", "intent-1", _runtime_id("intent-1"), order.order_ref,
        legacy_seed=_action_seed(41), writer_lease=lease,
    )
    assert order.order_ref == "000000000013"
    assert first.native_action_ref == 42
    assert first.native_action_ref != 53  # synthetic CTP RequestID in the contract fixture
    store.close()

    reopened, authority2, scope2, lease2 = _open(path)
    try:
        assert authority2.read_cancel_action_identity(scope2, "cancel-action-1") == first
        assert authority2.reserve_cancel_action_identity(
            scope2, "cancel-action-1", "intent-1", _runtime_id("intent-1"), order.order_ref,
            legacy_seed=None, writer_lease=lease2,
        ) == first
        second = authority2.reserve_cancel_action_identity(
            scope2, "cancel-action-2", "intent-1", _runtime_id("intent-1"), order.order_ref,
            legacy_seed=_action_seed(41), writer_lease=lease2,
        )
        assert second.native_action_ref == 43
    finally:
        reopened.close()


def test_action_reservation_is_concurrent_unique_and_rejects_conflicting_order(tmp_path):
    path = tmp_path / "action-concurrency.sqlite3"
    store, authority, scope, lease = _open(path)
    order = _reserve_order(authority, scope, lease)
    stores = [SqliteExecutionStore(path) for _ in range(8)]
    authorities = [CtpUnifiedOrderActionAuthority(item) for item in stores]
    try:
        def reserve(index):
            return authorities[index].reserve_cancel_action_identity(
                scope,
                f"cancel-{index}",
                "intent-1",
                _runtime_id("intent-1"),
                order.order_ref,
                legacy_seed=_action_seed(41),
                writer_lease=lease,
            ).native_action_ref

        with ThreadPoolExecutor(max_workers=len(stores)) as pool:
            refs = tuple(pool.map(reserve, range(len(stores))))
        assert sorted(refs) == list(range(42, 50))
        with pytest.raises(IntentConflictError, match="action identity conflicts"):
            authority.reserve_cancel_action_identity(
                scope,
                "cancel-0",
                "intent-1",
                _runtime_id("intent-1"),
                "000000000099",
                legacy_seed=None,
                writer_lease=lease,
            )
    finally:
        for item in stores:
            item.close()
        store.close()


def test_action_ref_range_seed_and_foreign_order_are_checked(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "action-range.sqlite3")
    order = _reserve_order(authority, scope, lease)
    try:
        with pytest.raises(Exception, match="requires a legacy seed"):
            authority.reserve_cancel_action_identity(
                scope, "no-seed", "intent-1", _runtime_id("intent-1"), order.order_ref,
                legacy_seed=None, writer_lease=lease,
            )
        with pytest.raises(Exception, match="ActionRef target differs"):
            authority.reserve_cancel_action_identity(
                scope, "wrong-order", "intent-1", _runtime_id("intent-1"), "000000000099",
                legacy_seed=_action_seed(), writer_lease=lease,
            )
        with pytest.raises(Exception, match="sequence is exhausted"):
            authority.reserve_cancel_action_identity(
                scope, "overflow", "intent-1", _runtime_id("intent-1"), order.order_ref,
                legacy_seed=_action_seed(2_147_483_647), writer_lease=lease,
            )
        with pytest.raises(Exception, match="invalid CTP ActionRef seed watermark"):
            authority.reserve_cancel_action_identity(
                scope, "bool-seed", "intent-1", _runtime_id("intent-1"), order.order_ref,
                legacy_seed=CtpActionRefSeedProof("20260927", True, sha256(b"x").hexdigest()),
                writer_lease=lease,
            )
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_action_identity_reservations"
        ).fetchone()[0] == 0
    finally:
        store.close()


def test_cancel_action_ref_is_in_same_immutable_command_and_queue_receipt_echo(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "cancel-stage.sqlite3")
    try:
        order = _reserve_order(authority, scope, lease)
        action = authority.reserve_cancel_action_identity(
            scope, "cancel-action", "intent-1", _runtime_id("intent-1"), order.order_ref,
            legacy_seed=_action_seed(41), writer_lease=lease,
        )
        target = _cancel_target(order.order_ref)
        with pytest.raises(Exception, match="caller-supplied OrderActionRef"):
            authority.stage_cancel_command(
                scope, action.managed_action_id, "bad-cancel",
                {**_request(target), "OrderActionRef": 99}, target=target,
                approval_use_id="approval-bad", approval_digest=sha256(b"a").hexdigest(),
                session_binding={"session_generation": 3}, writer_lease=lease,
            )

        target_projection = _projection(store, scope, order)
        command = authority.stage_cancel_command(
            scope, action.managed_action_id, "cancel-good", _request(target), target=target,
            cancel_target_projection=target_projection,
            approval_use_id="approval-good", approval_digest=sha256(b"approval").hexdigest(),
            session_binding={
                "session_generation_id": "synthetic-session-generation",
                "dispatch_front_id": 17,
                "dispatch_session_id": 29,
                "session": "opaque",
            },
            writer_lease=lease,
        )
        assert command.request_payload["OrderRef"] == order.order_ref
        assert command.request_payload["OrderActionRef"] == action.native_action_ref
        assert command.request_payload_sha256 == payload_sha256(dict(command.request_payload))
        assert "OrderActionRef" in command.request_payload
        repeated = authority.stage_cancel_command(
            scope, action.managed_action_id, "cancel-good", _request(target), target=target,
            cancel_target_projection=target_projection,
            approval_use_id="approval-good", approval_digest=sha256(b"approval").hexdigest(),
            session_binding={
                "session_generation_id": "synthetic-session-generation",
                "dispatch_front_id": 17,
                "dispatch_session_id": 29,
                "session": "opaque",
            },
            writer_lease=lease,
        )
        assert repeated == command
        with pytest.raises(IntentConflictError, match="already consumed"):
            authority.stage_cancel_command(
                scope, action.managed_action_id, "cancel-reuse-projection", _request(target),
                target=target, cancel_target_projection=target_projection,
                approval_use_id="approval-reuse-projection",
                approval_digest=sha256(b"approval-reuse").hexdigest(),
                session_binding={
                    "session_generation_id": "synthetic-session-generation",
                    "dispatch_front_id": 17,
                    "dispatch_session_id": 29,
                    "session": "opaque",
                },
                writer_lease=lease,
            )

        claimed = store.claim_ctp_dispatch_command(scope, command.command_id, writer_lease=lease)
        assert claimed is not None and claimed.status == "CLAIMED"
        queue = Queue()
        sender_calls = []

        def receiver():
            visible = queue.get(timeout=3)
            persisted = store.read_ctp_dispatch_command(scope, visible.command_id)
            assert persisted is not None and persisted.status == "COMPLETED"
            assert persisted.native_receipt_payload == {
                "local_queue_code": 0, "provider_ack": False
            }
            assert persisted.request_payload["OrderActionRef"] == action.native_action_ref
            sender_calls.append((persisted.command_id, persisted.request_payload["OrderActionRef"]))

        thread = threading.Thread(target=receiver)
        thread.start()
        receipt = _queue_receipt(claimed)
        completed = store.complete_ctp_dispatch_command(scope, receipt, writer_lease=lease)
        assert completed.status == "COMPLETED"
        durable_receipt = store.read_ctp_dispatch_command(scope, command.command_id)
        assert durable_receipt == completed
        # Publish only after the exact local QUEUED receipt and command echo are durable.
        queue.put(durable_receipt)
        thread.join(timeout=4)
        assert not thread.is_alive()
        assert sender_calls == [("cancel-good", action.native_action_ref)]
        assert completed.native_receipt_payload["provider_ack"] is False

        wrong_receipt = _queue_receipt(claimed)
        wrong_receipt = CtpDispatchReceipt(
            **{
                **wrong_receipt.__dict__,
                "request_payload_sha256": "0" * 64,
            }
        )
        with pytest.raises(Exception, match="receipt echo does not match"):
            store.complete_ctp_dispatch_command(scope, wrong_receipt, writer_lease=lease)
    finally:
        store.close()


def test_receipt_persistence_failure_keeps_async_worker_unpublished(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "receipt-failure.sqlite3")
    try:
        order = _reserve_order(authority, scope, lease)
        action = authority.reserve_cancel_action_identity(
            scope, "cancel-fail", "intent-1", _runtime_id("intent-1"), order.order_ref,
            legacy_seed=_action_seed(41), writer_lease=lease,
        )
        command = _stage_cancel(authority, store, scope, lease, action, "cancel-fail-command")
        claimed = store.claim_ctp_dispatch_command(scope, command.command_id, writer_lease=lease)
        assert claimed is not None
        store._connection.execute(
            """CREATE TRIGGER reject_cancel_receipt
               BEFORE UPDATE OF status ON ctp_dispatch_commands
               BEGIN SELECT RAISE(ABORT, 'injected queue receipt persistence failure'); END"""
        )
        published = Queue()
        native_sends = []
        receipt = _queue_receipt(claimed)
        with pytest.raises(DurableStoreError):
            store.complete_ctp_dispatch_command(scope, receipt, writer_lease=lease)
        assert published.empty()
        assert native_sends == []
        row = store.read_ctp_dispatch_command(scope, command.command_id)
        assert row is not None and row.status == "CLAIMED"
        assert row.completion_echo_sha256 is None
    finally:
        store.close()


def test_unknown_queue_disposition_survives_restart_and_blocks_replay(tmp_path):
    path = tmp_path / "unknown-restart.sqlite3"
    store, authority, scope, lease = _open(path)
    order = _reserve_order(authority, scope, lease)
    action = authority.reserve_cancel_action_identity(
        scope, "cancel-unknown", "intent-1", _runtime_id("intent-1"), order.order_ref,
        legacy_seed=_action_seed(41), writer_lease=lease,
    )
    command = _stage_cancel(authority, store, scope, lease, action, "cancel-unknown-command")
    claimed = store.claim_ctp_dispatch_command(scope, command.command_id, writer_lease=lease)
    assert claimed is not None
    unknown = store.complete_ctp_dispatch_command(
        scope, _queue_receipt(claimed, outcome="UNKNOWN"), writer_lease=lease
    )
    assert unknown.status == "UNKNOWN"
    store.close()

    reopened, authority2, scope2, lease2 = _open(path)
    try:
        assert authority2.read_cancel_action_identity(scope2, "cancel-unknown") == action
        assert reopened.claim_ctp_dispatch_command(
            scope2, command.command_id, writer_lease=lease2
        ) is None
        next_action = authority2.reserve_cancel_action_identity(
            scope2,
            "cancel-after-unknown",
            "intent-1",
            _runtime_id("intent-1"),
            order.order_ref,
            legacy_seed=_action_seed(41),
            writer_lease=lease2,
        )
        next_command = _stage_cancel(
            authority2, reopened, scope2, lease2, next_action, "cancel-after-unknown-command"
        )
        with pytest.raises(Exception, match="unresolved CTP dispatch command"):
            reopened.claim_ctp_dispatch_command(
                scope2, next_command.command_id, writer_lease=lease2
            )
    finally:
        reopened.close()


def test_action_authority_rejects_a_second_database_or_untyped_store(tmp_path):
    class StoreProxy:
        def __init__(self, inner):
            self.inner = inner

    store = SqliteExecutionStore(tmp_path / "proxy.sqlite3")
    try:
        with pytest.raises(CtpIdentityAuthorityError, match="exact SDK SQLite"):
            CtpUnifiedOrderActionAuthority(StoreProxy(store))
    finally:
        store.close()
