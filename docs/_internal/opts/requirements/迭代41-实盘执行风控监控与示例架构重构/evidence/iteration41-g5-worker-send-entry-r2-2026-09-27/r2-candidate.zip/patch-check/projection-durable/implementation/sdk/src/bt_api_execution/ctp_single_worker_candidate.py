"""Offline CTP single-worker handoff candidate for the G5 ActionRef seam.

This is a fake-only adapter over the exact same ``SqliteExecutionStore`` and
``CtpUnifiedOrderActionAuthority`` used by the OrderRef/ActionRef candidate.
It has no provider imports, does not start a worker thread, and is not wired to
the SDK facade or a runtime registry.

The worker keyword contract deliberately keeps ``cancel_target_projection``
and adds the typed ``action_identity``. A caller-supplied ActionRef is never
accepted in the logical request. The worker verifies the durable ActionRef,
stages the matching command, persists a separate local handoff receipt, then
claims the command before calling the injected fake sender. A claimed command
that loses its writer generation becomes UNKNOWN and is never replayed.
"""
from __future__ import annotations

import inspect
import json
import re
import time
from collections.abc import Mapping
from dataclasses import dataclass
from hashlib import sha256
from types import MappingProxyType
from typing import Any, Literal, Protocol

from .contracts import ExecutionScope, canonical_json, payload_sha256
from .ctp_identity_authority import (
    CtpActionIdentityReservation,
    CtpUnifiedOrderActionAuthority,
)
from .errors import ContractValidationError, InvalidStateTransition
from .store import (
    CtpCancelTarget,
    CtpDispatchCommand,
    CtpDispatchReceipt,
    CtpOrderIdentityReservation,
    CtpOrderTargetProjectionHandle,
    CtpVerifiedOrderTargetProjection,
    SqliteExecutionStore,
    WriterLease,
)

_HEX_32 = re.compile(r"^[0-9a-f]{32}$", re.ASCII)
_HEX_64 = re.compile(r"^[0-9a-f]{64}$", re.ASCII)
_RUNTIME_ID = re.compile(r"^bt-managed-v1:[0-9a-f]{64}$", re.ASCII)
_TARGET_PROJECTION_MAX_TTL_NS = 5_000_000_000


def stable_managed_command_id(
    operation: Literal["submit", "cancel"],
    managed_intent_id: str,
    runtime_order_id: str,
    managed_cancel_intent_id: str | None = None,
) -> str:
    """Match Backtrader's stable command key used by its source-only builder."""

    if operation not in {"submit", "cancel"}:
        raise ContractValidationError("invalid managed CTP operation")
    if type(managed_intent_id) is not str or not managed_intent_id.isascii():
        raise ContractValidationError("invalid managed CTP intent")
    if type(runtime_order_id) is not str or not _RUNTIME_ID.fullmatch(runtime_order_id):
        raise ContractValidationError("invalid managed CTP runtime order id")
    cancel_id = managed_cancel_intent_id or ""
    if type(cancel_id) is not str or not cancel_id.isascii():
        raise ContractValidationError("invalid managed CTP cancel intent")
    material = (
        f"backtrader.ctp.managed-outbox.v1\0{operation}\0{managed_intent_id}"
        f"\0{runtime_order_id}\0{cancel_id}"
    )
    return "ctp-outbox-v1:" + sha256(material.encode("ascii")).hexdigest()


@dataclass(frozen=True, slots=True)
class CtpManagedPreparedDispatch:
    """Detached Store request and exact OrderRef reservation for one action."""

    operation: Literal["submit", "cancel"]
    command_id: str
    managed_intent_id: str
    runtime_order_id: str
    order_ref: str
    request_payload: Mapping[str, Any]
    order_ref_reservation: CtpOrderIdentityReservation
    approval_use_id: str
    approval_digest: str
    session_binding: Mapping[str, Any]
    session_generation_id: str
    dispatch_front_id: int
    dispatch_session_id: int
    native_request_id: int
    local_queue_receipt_id: str
    managed_cancel_intent_id: str | None = None
    cancel_target_exchange_id: str | None = None
    cancel_target_order_sys_id: str | None = None
    cancel_target_front_id: int | None = None
    cancel_target_session_id: int | None = None

    def __post_init__(self) -> None:
        if self.operation not in {"submit", "cancel"}:
            raise ContractValidationError("invalid managed CTP operation")
        if type(self.order_ref_reservation) is not CtpOrderIdentityReservation:
            raise ContractValidationError("typed same-store OrderRef reservation is required")
        if self.command_id != stable_managed_command_id(
            self.operation,
            self.managed_intent_id,
            self.runtime_order_id,
            self.managed_cancel_intent_id,
        ):
            raise ContractValidationError("managed CTP command id differs from identity")
        if (
            type(self.runtime_order_id) is not str
            or not _RUNTIME_ID.fullmatch(self.runtime_order_id)
            or type(self.order_ref) is not str
            or not re.fullmatch(r"[0-9]{12}", self.order_ref, re.ASCII)
        ):
            raise ContractValidationError("invalid managed CTP order identity")
        if (
            self.order_ref_reservation.managed_intent_id != self.managed_intent_id
            or self.order_ref_reservation.runtime_order_id != self.runtime_order_id
            or self.order_ref_reservation.order_ref != self.order_ref
        ):
            raise ContractValidationError("prepared OrderRef differs from its reservation")
        if not isinstance(self.request_payload, Mapping) or not self.request_payload:
            raise ContractValidationError("managed CTP request payload is required")
        if "OrderActionRef" in self.request_payload:
            raise ContractValidationError("logical CTP request cannot supply OrderActionRef")
        if not _HEX_32.fullmatch(self.local_queue_receipt_id):
            raise ContractValidationError("invalid local queue receipt id")
        if not _HEX_64.fullmatch(self.approval_digest):
            raise ContractValidationError("invalid approval digest")
        if not isinstance(self.approval_use_id, str) or not self.approval_use_id:
            raise ContractValidationError("approval use id is required")
        if not isinstance(self.session_binding, Mapping) or not self.session_binding:
            raise ContractValidationError("session binding is required")
        if (
            type(self.native_request_id) is not int
            or not 1 <= self.native_request_id <= 2_147_483_647
        ):
            raise ContractValidationError("invalid native RequestID")
        for value, name in (
            (self.dispatch_front_id, "dispatch FrontID"),
            (self.dispatch_session_id, "dispatch SessionID"),
        ):
            if type(value) is not int or not 1 <= value <= 2_147_483_647:
                raise ContractValidationError("invalid " + name)
        session = dict(self.session_binding)
        expected_session = {
            "session_generation_id": self.session_generation_id,
            "dispatch_front_id": self.dispatch_front_id,
            "dispatch_session_id": self.dispatch_session_id,
        }
        if any(session.get(key) != value for key, value in expected_session.items()):
            raise ContractValidationError("prepared session binding differs")
        if self.operation == "submit":
            if self.managed_cancel_intent_id is not None or any(
                value is not None
                for value in (
                    self.cancel_target_exchange_id,
                    self.cancel_target_order_sys_id,
                    self.cancel_target_front_id,
                    self.cancel_target_session_id,
                )
            ):
                raise ContractValidationError("submit cannot carry cancel identity")
        elif (
            type(self.managed_cancel_intent_id) is not str
            or not self.managed_cancel_intent_id
            or self.managed_cancel_intent_id == self.managed_intent_id
            or type(self.cancel_target_exchange_id) is not str
            or not self.cancel_target_exchange_id
            or type(self.cancel_target_order_sys_id) is not str
            or not self.cancel_target_order_sys_id
            or type(self.cancel_target_front_id) is not int
            or self.cancel_target_front_id <= 0
            or type(self.cancel_target_session_id) is not int
            or self.cancel_target_session_id <= 0
        ):
            raise ContractValidationError("cancel requires a complete exact target")
        object.__setattr__(self, "request_payload", MappingProxyType(dict(self.request_payload)))
        object.__setattr__(self, "session_binding", MappingProxyType(session))


@dataclass(frozen=True, slots=True)
class CtpManagedDispatchBinding:
    """Exact Store-to-worker echo; queue status is local and non-authorizing."""

    operation: Literal["submit", "cancel"]
    command_id: str
    account_key: str
    scope_key: str
    trading_day: str
    managed_intent_id: str
    runtime_order_id: str
    managed_action_id: str
    order_ref: str
    cancel_target_order_ref: str | None
    request_payload_sha256: str
    request_payload: Mapping[str, Any]
    native_request_payload_sha256: str
    native_request_payload: Mapping[str, Any]
    approval_use_id: str
    approval_digest: str
    session_binding_sha256: str
    session_binding: Mapping[str, Any]
    session_generation_id: str
    dispatch_front_id: int
    dispatch_session_id: int
    native_request_id: int
    native_action_ref: int | None
    local_queue_receipt_id: str
    order_ref_reservation_created_at_ns: int
    local_queue_receipt_queued: bool | None = None
    managed_cancel_intent_id: str | None = None
    cancel_target_exchange_id: str | None = None
    cancel_target_order_sys_id: str | None = None
    cancel_target_front_id: int | None = None
    cancel_target_session_id: int | None = None
    version: int = 2

    @property
    def managed_action_identity(self) -> str:
        return self.managed_action_id

    def to_payload(self) -> dict[str, Any]:
        """Return the frozen Backtrader binding echo shape."""

        return {
            "version": self.version,
            "operation": self.operation,
            "command_id": self.command_id,
            "account_key": self.account_key,
            "scope_key": self.scope_key,
            "trading_day": self.trading_day,
            "managed_intent_id": self.managed_intent_id,
            "runtime_order_id": self.runtime_order_id,
            "managed_action_id": self.managed_action_id,
            "order_ref": self.order_ref,
            "cancel_target_order_ref": self.cancel_target_order_ref,
            "request_payload_sha256": self.request_payload_sha256,
            "request_payload": dict(self.request_payload),
            "native_request_payload_sha256": self.native_request_payload_sha256,
            "native_request_payload": dict(self.native_request_payload),
            "approval_use_id": self.approval_use_id,
            "approval_digest": self.approval_digest,
            "session_binding_sha256": self.session_binding_sha256,
            "session_binding": dict(self.session_binding),
            "session_generation_id": self.session_generation_id,
            "dispatch_front_id": self.dispatch_front_id,
            "dispatch_session_id": self.dispatch_session_id,
            "native_request_id": self.native_request_id,
            "native_action_ref": self.native_action_ref,
            "local_queue_receipt_id": self.local_queue_receipt_id,
            "order_ref_reservation_created_at_ns": self.order_ref_reservation_created_at_ns,
            "local_queue_receipt_queued": self.local_queue_receipt_queued,
            "managed_cancel_intent_id": self.managed_cancel_intent_id,
            "cancel_target_exchange_id": self.cancel_target_exchange_id,
            "cancel_target_order_sys_id": self.cancel_target_order_sys_id,
            "cancel_target_front_id": self.cancel_target_front_id,
            "cancel_target_session_id": self.cancel_target_session_id,
        }


@dataclass(frozen=True, slots=True)
class CtpManagedQueueReceipt:
    """Typed local queue receipt. It says nothing about provider acceptance."""

    command_id: str
    request_payload_sha256: str
    operation: Literal["SUBMIT", "CANCEL"]
    receipt_id: str
    queued: bool

    def __post_init__(self) -> None:
        if (
            not self.command_id
            or not _HEX_64.fullmatch(self.request_payload_sha256)
            or self.operation not in {"SUBMIT", "CANCEL"}
            or not _HEX_32.fullmatch(self.receipt_id)
            or type(self.queued) is not bool
        ):
            raise ContractValidationError("invalid typed local queue receipt")


@dataclass(frozen=True, slots=True)
class CtpNativeDispatchResult:
    """Fake sender result; this is never a native provider acknowledgement."""

    outcome: Literal["QUEUED", "REJECTED", "UNKNOWN"]
    receipt_payload: Mapping[str, Any]

    def __post_init__(self) -> None:
        if self.outcome not in {"QUEUED", "REJECTED", "UNKNOWN"}:
            raise ContractValidationError("invalid fake CTP sender outcome")
        if not isinstance(self.receipt_payload, Mapping):
            raise ContractValidationError("fake CTP sender receipt must be a mapping")


class CtpNativeDispatchSender(Protocol):
    def __call__(
        self, command: CtpDispatchCommand
    ) -> CtpNativeDispatchResult:
        """Observe one already-claimed command in the SDK fake."""


@dataclass(frozen=True, slots=True)
class CtpWorkerDispatchResult:
    """Durable worker disposition, explicitly without provider order state."""

    command: CtpDispatchCommand
    worker_state: Literal["READY", "QUEUED", "REJECTED", "CLAIMED", "COMPLETED", "UNKNOWN"]
    sender_called: bool


class CtpManagedSingleWorkerCandidate:
    """Same-store fake worker with a strict typed ActionRef keyword contract."""

    def __init__(
        self,
        store: SqliteExecutionStore,
        scope: ExecutionScope,
        writer_lease: WriterLease,
        identity_authority: CtpUnifiedOrderActionAuthority,
    ) -> None:
        if (
            type(store) is not SqliteExecutionStore
            or type(scope) is not ExecutionScope
            or type(writer_lease) is not WriterLease
            or type(identity_authority) is not CtpUnifiedOrderActionAuthority
            or identity_authority.store is not store
            or writer_lease.scope_key != scope.account_key
        ):
            raise ContractValidationError("exact same-store CTP worker binding is required")
        self._store = store
        self._scope = scope
        self._writer_lease = writer_lease
        self._identity_authority = identity_authority
        with store._transaction() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS g5_ctp_worker_handoffs (
                    account_key TEXT NOT NULL,
                    scope_key TEXT NOT NULL,
                    command_id TEXT NOT NULL,
                    operation TEXT NOT NULL CHECK(operation IN ('SUBMIT', 'CANCEL')),
                    request_payload_sha256 TEXT NOT NULL,
                    action_identity_json TEXT,
                    action_ref INTEGER,
                    state TEXT NOT NULL CHECK(state IN (
                        'STAGED', 'QUEUED', 'REJECTED', 'CLAIMED', 'COMPLETED', 'UNKNOWN'
                    )),
                    queue_receipt_json TEXT,
                    queue_receipt_sha256 TEXT,
                    updated_at_ns INTEGER NOT NULL,
                    PRIMARY KEY(account_key, command_id),
                    UNIQUE(account_key, action_ref),
                    FOREIGN KEY(account_key, command_id)
                        REFERENCES ctp_dispatch_commands(account_key, command_id)
                )
                """
            )

    def stage_prepared_dispatch(
        self,
        prepared: CtpManagedPreparedDispatch,
        *,
        cancel_target_projection: Any = None,
        action_identity: CtpActionIdentityReservation | None = None,
    ) -> CtpManagedDispatchBinding:
        """Stage an exact typed action, retaining the pre-existing target kwarg."""

        if type(prepared) is not CtpManagedPreparedDispatch:
            raise ContractValidationError("typed managed CTP prepared dispatch is required")
        reservation = self._store.read_ctp_order_identity(
            self._scope, prepared.managed_intent_id
        )
        if (
            type(reservation) is not CtpOrderIdentityReservation
            or reservation != prepared.order_ref_reservation
            or reservation.runtime_order_id != prepared.runtime_order_id
            or reservation.order_ref != prepared.order_ref
        ):
            raise ContractValidationError("prepared OrderRef differs from same-store readback")
        if prepared.request_payload.get("OrderRef") != reservation.order_ref:
            raise ContractValidationError("prepared request OrderRef differs from reservation")
        if "OrderActionRef" in prepared.request_payload:
            raise ContractValidationError("logical request cannot supply native ActionRef")

        if prepared.operation == "submit":
            if action_identity is not None or cancel_target_projection is not None:
                raise ContractValidationError("submit cannot carry cancel-only authority")
            command = self._store.stage_ctp_dispatch_command(
                self._scope,
                prepared.command_id,
                "SUBMIT",
                prepared.request_payload,
                approval_use_id=prepared.approval_use_id,
                approval_digest=prepared.approval_digest,
                session_binding=prepared.session_binding,
                writer_lease=self._writer_lease,
                managed_intent_id=prepared.managed_intent_id,
                order_ref=prepared.order_ref,
            )
        else:
            self._read_and_validate_cancel_target_projection(
                prepared, reservation, cancel_target_projection
            )
            if type(action_identity) is not CtpActionIdentityReservation:
                raise ContractValidationError("cancel requires typed Store-issued ActionRef identity")
            expected_action = self._identity_authority.read_cancel_action_identity(
                self._scope, prepared.managed_cancel_intent_id
            )
            if expected_action != action_identity or (
                action_identity.account_key != reservation.account_key
                or action_identity.trading_day != reservation.trading_day
                or action_identity.scope_key != reservation.scope_key
                or action_identity.managed_action_id != prepared.managed_cancel_intent_id
                or action_identity.managed_intent_id != prepared.managed_intent_id
                or action_identity.runtime_order_id != prepared.runtime_order_id
                or action_identity.order_ref != prepared.order_ref
            ):
                raise ContractValidationError("typed ActionRef identity differs from same-store row")
            target = CtpCancelTarget(
                prepared.order_ref,
                prepared.cancel_target_exchange_id or "",
                prepared.cancel_target_order_sys_id or "",
                prepared.cancel_target_front_id or 0,
                prepared.cancel_target_session_id or 0,
            )
            command = self._identity_authority.stage_cancel_command(
                self._scope,
                action_identity.managed_action_id,
                prepared.command_id,
                prepared.request_payload,
                target=target,
                cancel_target_projection=cancel_target_projection,
                approval_use_id=prepared.approval_use_id,
                approval_digest=prepared.approval_digest,
                session_binding=prepared.session_binding,
                writer_lease=self._writer_lease,
            )

        durable = self._store.read_ctp_dispatch_command(self._scope, prepared.command_id)
        expected_native = dict(prepared.request_payload)
        if action_identity is not None:
            expected_native["OrderActionRef"] = action_identity.native_action_ref
        if (
            type(durable) is not CtpDispatchCommand
            or durable != command
            or durable.request_payload != expected_native
            or durable.request_payload_sha256 != payload_sha256(expected_native)
            or durable.operation != prepared.operation.upper()
        ):
            raise ContractValidationError("staged command does not echo typed Store identity")
        self._record_staged_handoff(durable, action_identity)
        binding = self._binding(prepared, durable, action_identity, reservation)
        self._read_and_require_binding(prepared.command_id, binding)
        return binding

    @staticmethod
    def _projection_payload(projection: Any) -> Mapping[str, Any]:
        to_payload = getattr(projection, "to_payload", None)
        if not callable(to_payload):
            raise ContractValidationError("typed CTP target projection payload is required")
        payload = to_payload()
        if not isinstance(payload, Mapping) or not payload:
            raise ContractValidationError("typed CTP target projection payload is invalid")
        return payload

    def _read_and_validate_cancel_target_projection(
        self,
        prepared: CtpManagedPreparedDispatch,
        reservation: CtpOrderIdentityReservation,
        handle: Any,
    ) -> Any:
        """Require the retained cancel handle to read back from this exact Store.

        The parent builder already obtains this handle from its Store verifier.
        The worker repeats the same-store readback at its own boundary so a
        mismatched or stale target cannot be hidden by an ActionRef handoff.
        """

        if (
            type(handle) is not CtpOrderTargetProjectionHandle
            or type(getattr(handle, "projection_id", None)) is not str
            or not re.fullmatch(r"[0-9a-f]{32}", handle.projection_id, re.ASCII)
            or type(getattr(handle, "projection_sha256", None)) is not str
            or not _HEX_64.fullmatch(handle.projection_sha256)
            or getattr(handle, "projection", None) is None
        ):
            raise ContractValidationError("typed same-store CTP target handle is required")
        projection = handle.projection
        if type(projection) is not CtpVerifiedOrderTargetProjection:
            raise ContractValidationError("typed verified CTP target projection is required")
        payload = self._projection_payload(projection)
        if payload_sha256(payload) != handle.projection_sha256:
            raise ContractValidationError("CTP target projection handle digest differs")

        readback_method = getattr(self._store, "read_ctp_order_target_projection", None)
        if not callable(readback_method):
            raise ContractValidationError("same-store CTP target readback is unavailable")
        readback = readback_method(self._scope, handle)
        if readback != projection:
            raise ContractValidationError("same-store CTP target projection readback differs")

        text_fields = {
            "account_key": reservation.account_key,
            "scope_key": reservation.scope_key,
            "trading_day": reservation.trading_day,
            "managed_intent_id": reservation.managed_intent_id,
            "runtime_order_id": reservation.runtime_order_id,
            "order_ref": reservation.order_ref,
            "session_generation_id": prepared.session_generation_id,
            "instrument_id": prepared.request_payload.get("InstrumentID"),
            "exchange_id": prepared.cancel_target_exchange_id,
            "order_sys_id": prepared.cancel_target_order_sys_id,
        }
        for name, expected in text_fields.items():
            value = getattr(projection, name, None)
            if type(value) is not str or value != expected:
                raise ContractValidationError("CTP target projection differs: " + name)
        int_fields = {
            "query_front_id": prepared.dispatch_front_id,
            "query_session_id": prepared.dispatch_session_id,
            "front_id": prepared.cancel_target_front_id,
            "session_id": prepared.cancel_target_session_id,
            "query_request_id": None,
            "verified_at_ns": None,
            "expires_at_ns": None,
            "query_record_count": None,
            "query_match_count": 1,
            "late_callback_count": 0,
            "quantity": None,
            "traded_quantity": None,
            "remaining_quantity": None,
        }
        for name, expected in int_fields.items():
            value = getattr(projection, name, None)
            if type(value) is not int or (expected is not None and value != expected):
                raise ContractValidationError("CTP target projection differs: " + name)
            if name not in {"late_callback_count"} and value <= 0:
                if name == "traded_quantity":
                    continue
                raise ContractValidationError("invalid CTP target projection field: " + name)
        if (
            projection.provider_state not in {"OPEN", "PARTIAL"}
            or projection.query_complete is not True
            or projection.query_terminal is not True
            or projection.query_timed_out is not False
            or projection.query_error_id not in (None, 0)
            or type(projection.query_error_id) not in (int, type(None))
            or projection.expires_at_ns <= self._store._monotonic_now_ns()
            or projection.expires_at_ns <= projection.verified_at_ns
            or projection.expires_at_ns - projection.verified_at_ns
            > _TARGET_PROJECTION_MAX_TTL_NS
            or projection.remaining_quantity
            != projection.quantity - projection.traded_quantity
            or projection.remaining_quantity <= 0
            or not 0 <= projection.traded_quantity < projection.quantity
            or (projection.provider_state == "OPEN" and projection.traded_quantity != 0)
            or (projection.provider_state == "PARTIAL" and projection.traded_quantity == 0)
        ):
            raise ContractValidationError("CTP target projection is incomplete, stale, or inconsistent")
        return projection

    def _record_staged_handoff(
        self,
        command: CtpDispatchCommand,
        action_identity: CtpActionIdentityReservation | None,
    ) -> None:
        identity_json = (
            None
            if action_identity is None
            else canonical_json(action_identity.__dict__)
        )
        action_ref = None if action_identity is None else action_identity.native_action_ref
        now_ns = time.time_ns()
        with self._store._transaction() as cursor:
            existing = cursor.execute(
                """SELECT operation, request_payload_sha256, action_identity_json, action_ref
                   FROM g5_ctp_worker_handoffs WHERE account_key = ? AND command_id = ?""",
                (command.account_key, command.command_id),
            ).fetchone()
            expected = (
                command.operation,
                command.request_payload_sha256,
                identity_json,
                action_ref,
            )
            if existing is not None:
                current = (
                    str(existing["operation"]),
                    str(existing["request_payload_sha256"]),
                    None if existing["action_identity_json"] is None else str(existing["action_identity_json"]),
                    None if existing["action_ref"] is None else int(existing["action_ref"]),
                )
                if current != expected:
                    raise ContractValidationError("worker handoff conflicts with durable identity")
                return
            cursor.execute(
                """INSERT INTO g5_ctp_worker_handoffs(
                       account_key, scope_key, command_id, operation,
                       request_payload_sha256, action_identity_json, action_ref,
                       state, updated_at_ns
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, 'STAGED', ?)""",
                (
                    command.account_key,
                    command.scope_key,
                    command.command_id,
                    command.operation,
                    command.request_payload_sha256,
                    identity_json,
                    action_ref,
                    now_ns,
                ),
            )

    def record_managed_queue_receipt(
        self,
        command_id: str,
        binding: CtpManagedDispatchBinding,
        queue_receipt: CtpManagedQueueReceipt,
    ) -> CtpManagedDispatchBinding:
        """Persist local receipt before any sender call; duplicates must echo."""

        command, prepared, reservation, action = self._read_and_require_binding(
            command_id, binding
        )
        if type(queue_receipt) is not CtpManagedQueueReceipt or (
            queue_receipt.command_id != command_id
            or queue_receipt.request_payload_sha256 != command.request_payload_sha256
            or queue_receipt.operation != command.operation
        ):
            raise ContractValidationError("local queue receipt differs from staged command")
        receipt_json = canonical_json(
            {
                "command_id": queue_receipt.command_id,
                "request_payload_sha256": queue_receipt.request_payload_sha256,
                "operation": queue_receipt.operation,
                "receipt_id": queue_receipt.receipt_id,
                "queued": queue_receipt.queued,
            }
        )
        receipt_digest = sha256(receipt_json.encode("ascii")).hexdigest()
        next_state = "QUEUED" if queue_receipt.queued else "REJECTED"
        now_ns = time.time_ns()
        with self._store._transaction() as cursor:
            row = cursor.execute(
                """SELECT state, queue_receipt_json, queue_receipt_sha256
                   FROM g5_ctp_worker_handoffs WHERE account_key = ? AND command_id = ?""",
                (command.account_key, command_id),
            ).fetchone()
            if row is None:
                raise ContractValidationError("worker handoff row is missing")
            if row["queue_receipt_json"] is not None:
                if (
                    str(row["queue_receipt_json"]) != receipt_json
                    or str(row["queue_receipt_sha256"]) != receipt_digest
                ):
                    raise ContractValidationError("worker handoff already has another receipt")
                return self._binding_with_queue_state(binding, queue_receipt.queued)
            if str(row["state"]) != "STAGED":
                raise InvalidStateTransition("worker handoff is no longer awaiting a receipt")
            cursor.execute(
                """UPDATE g5_ctp_worker_handoffs
                   SET state = ?, queue_receipt_json = ?, queue_receipt_sha256 = ?, updated_at_ns = ?
                   WHERE account_key = ? AND command_id = ? AND state = 'STAGED'""",
                (
                    next_state,
                    receipt_json,
                    receipt_digest,
                    now_ns,
                    command.account_key,
                    command_id,
                ),
            )
            if cursor.rowcount != 1:
                raise InvalidStateTransition("worker handoff receipt transition changed")
        if not queue_receipt.queued:
            claimed = self._store.claim_ctp_dispatch_command(
                self._scope, command_id, writer_lease=self._writer_lease
            )
            if claimed is None:
                raise InvalidStateTransition("rejected queue receipt could not claim command")
            self._complete_receipt(claimed, "REJECTED", "local_queue_rejected")
            self._set_state(command_id, "REJECTED")
        current = self._store.read_ctp_dispatch_command(self._scope, command_id)
        if current is None:
            raise ContractValidationError("durable command disappeared after queue receipt")
        return self._binding(prepared, current, action, reservation, queue_state=queue_receipt.queued)

    def dispatch_managed_command(
        self,
        command_id: str,
        binding: CtpManagedDispatchBinding,
        sender: CtpNativeDispatchSender,
    ) -> CtpWorkerDispatchResult:
        """Claim once, send to the injected fake, and make uncertainty terminal."""

        command, _prepared, _reservation, _action = self._read_and_require_binding(
            command_id, binding
        )
        if not callable(sender):
            raise ContractValidationError("one SDK fake sender is required")
        if inspect.iscoroutinefunction(sender) or inspect.iscoroutinefunction(
            getattr(sender, "__call__", None)
        ):
            raise ContractValidationError(
                "awaitable SDK sender is unsupported without a send-entry fence"
            )
        handoff = self._read_handoff(command)
        state = str(handoff["state"])
        if command.status == "UNKNOWN":
            self._set_state(command_id, "UNKNOWN")
            return CtpWorkerDispatchResult(command, "UNKNOWN", False)
        if command.status == "COMPLETED":
            self._set_state(command_id, "COMPLETED")
            return CtpWorkerDispatchResult(command, "COMPLETED", False)
        if state in {"REJECTED", "UNKNOWN", "COMPLETED", "CLAIMED"}:
            return CtpWorkerDispatchResult(command, state, False)
        if state != "QUEUED":
            raise ContractValidationError("local queue receipt is not durably accepted")

        claimed = self._store.claim_ctp_dispatch_command(
            self._scope, command_id, writer_lease=self._writer_lease
        )
        if claimed is None:
            latest = self._store.read_ctp_dispatch_command(self._scope, command_id)
            if latest is None:
                raise ContractValidationError("durable command disappeared before claim")
            if latest.status in {"CLAIMED", "UNKNOWN", "COMPLETED"}:
                current_state = "UNKNOWN" if latest.status == "UNKNOWN" else latest.status
                if current_state in {"UNKNOWN", "COMPLETED"}:
                    self._set_state(command_id, current_state)
                return CtpWorkerDispatchResult(latest, current_state, False)
            raise InvalidStateTransition("worker could not claim staged command")
        # A crash after the SQLite claim but before this marker is still safe:
        # recovery fences the Store row to UNKNOWN, and no sender was called.
        self._set_state(command_id, "CLAIMED", from_states={"QUEUED"})
        if claimed.operation == "CANCEL":
            try:
                self._store.require_fresh_ctp_cancel_target_for_dispatch(
                    self._scope, command_id
                )
            except Exception:  # noqa: BLE001 - fail closed after the durable claim
                completed = self._complete_receipt(
                    claimed, "UNKNOWN", "target_projection_expired_before_sender"
                )
                self._set_state(command_id, "UNKNOWN", from_states={"CLAIMED"})
                return CtpWorkerDispatchResult(completed, "UNKNOWN", False)
        outcome = "UNKNOWN"
        try:
            result = sender(claimed)
            if inspect.isawaitable(result):
                close = getattr(result, "close", None)
                if callable(close):
                    close()
                raise ContractValidationError(
                    "awaitable SDK sender is unsupported without a send-entry fence"
                )
            if type(result) is not CtpNativeDispatchResult:
                raise ContractValidationError("SDK fake returned an untyped dispatch receipt")
            if result.outcome == "QUEUED":
                outcome = "QUEUED"
                # Validate, then discard arbitrary sender data. The durable
                # receipt stores only the fixed local outcome marker below.
                self._safe_receipt_payload(result.receipt_payload)
            else:
                # Sender rejection after the claim cannot prove zero native send.
                outcome = "UNKNOWN"
        except Exception:  # noqa: BLE001 - after claim, sender errors are ambiguous
            # Do not persist exception text: it may contain sensitive details.
            outcome = "UNKNOWN"
        self._complete_receipt(claimed, outcome, "sdk_fake_dispatch")
        state_after = "UNKNOWN" if outcome == "UNKNOWN" else "COMPLETED"
        self._set_state(command_id, state_after, from_states={"CLAIMED"})
        completed = self._store.read_ctp_dispatch_command(self._scope, command_id)
        if completed is None:
            raise ContractValidationError("durable command disappeared after sender receipt")
        return CtpWorkerDispatchResult(completed, state_after, True)

    def recover_claimed_after_restart(self) -> tuple[CtpDispatchCommand, ...]:
        """Convert old-generation claims into UNKNOWN and prohibit replay."""

        recovered = self._store.recover_claimed_ctp_dispatch_commands(
            self._scope, writer_lease=self._writer_lease
        )
        for command in recovered:
            self._set_state(command.command_id, "UNKNOWN")
        return recovered

    def _complete_receipt(
        self, command: CtpDispatchCommand, outcome: str, kind: str
    ) -> CtpDispatchCommand:
        receipt = CtpDispatchReceipt(
            receipt_type="ctp_dispatch_receipt.v1",
            command_id=command.command_id,
            account_key=command.account_key,
            scope_key=command.scope_key,
            trading_day=command.trading_day,
            operation=command.operation,
            request_payload_sha256=command.request_payload_sha256,
            reservation_managed_intent_id=command.reservation_managed_intent_id,
            order_ref=command.order_ref,
            cancel_target_order_ref=command.cancel_target_order_ref,
            cancel_target_exchange_id=command.cancel_target_exchange_id,
            cancel_target_order_sys_id=command.cancel_target_order_sys_id,
            cancel_target_front_id=command.cancel_target_front_id,
            cancel_target_session_id=command.cancel_target_session_id,
            approval_use_id=command.approval_use_id,
            approval_digest=command.approval_digest,
            session_binding_sha256=command.session_binding_sha256,
            outcome=outcome,
            native_receipt_payload={"kind": kind, "outcome": outcome},
        )
        return self._store.complete_ctp_dispatch_command(
            self._scope, receipt, writer_lease=self._writer_lease
        )

    @staticmethod
    def _safe_receipt_payload(value: Mapping[str, Any]) -> Mapping[str, Any]:
        try:
            decoded = json.loads(canonical_json(dict(value)))
        except (TypeError, ValueError) as error:
            raise ContractValidationError("SDK fake receipt is not canonical JSON") from error
        if not decoded or not isinstance(decoded, dict):
            raise ContractValidationError("SDK fake receipt is empty")
        SqliteExecutionStore._reject_sensitive_command_fields(decoded)
        return decoded

    def _binding(
        self,
        prepared: CtpManagedPreparedDispatch,
        command: CtpDispatchCommand,
        action: CtpActionIdentityReservation | None,
        reservation: CtpOrderIdentityReservation,
        *,
        queue_state: bool | None = None,
    ) -> CtpManagedDispatchBinding:
        logical = dict(prepared.request_payload)
        native = dict(command.request_payload)
        action_ref = None if action is None else action.native_action_ref
        if action_ref is not None and native.get("OrderActionRef") != action_ref:
            raise ContractValidationError("worker ActionRef differs from staged command")
        return CtpManagedDispatchBinding(
            operation=prepared.operation,
            command_id=prepared.command_id,
            account_key=command.account_key,
            scope_key=command.scope_key,
            trading_day=command.trading_day,
            managed_intent_id=prepared.managed_intent_id,
            runtime_order_id=prepared.runtime_order_id,
            managed_action_id=(
                prepared.managed_cancel_intent_id
                if prepared.operation == "cancel"
                else prepared.managed_intent_id
            ),
            order_ref=prepared.order_ref,
            cancel_target_order_ref=(
                prepared.order_ref if prepared.operation == "cancel" else None
            ),
            request_payload_sha256=payload_sha256(logical),
            request_payload=MappingProxyType(logical),
            native_request_payload_sha256=payload_sha256(native),
            native_request_payload=MappingProxyType(native),
            approval_use_id=command.approval_use_id,
            approval_digest=command.approval_digest,
            session_binding_sha256=command.session_binding_sha256,
            session_binding=MappingProxyType(dict(command.session_binding)),
            session_generation_id=prepared.session_generation_id,
            dispatch_front_id=prepared.dispatch_front_id,
            dispatch_session_id=prepared.dispatch_session_id,
            native_request_id=prepared.native_request_id,
            native_action_ref=action_ref,
            local_queue_receipt_id=prepared.local_queue_receipt_id,
            order_ref_reservation_created_at_ns=reservation.created_at_ns,
            local_queue_receipt_queued=queue_state,
            managed_cancel_intent_id=prepared.managed_cancel_intent_id,
            cancel_target_exchange_id=prepared.cancel_target_exchange_id,
            cancel_target_order_sys_id=prepared.cancel_target_order_sys_id,
            cancel_target_front_id=prepared.cancel_target_front_id,
            cancel_target_session_id=prepared.cancel_target_session_id,
        )

    @staticmethod
    def _binding_with_queue_state(
        binding: CtpManagedDispatchBinding, queued: bool
    ) -> CtpManagedDispatchBinding:
        values = binding.to_payload()
        values["local_queue_receipt_queued"] = queued
        return CtpManagedDispatchBinding(**values)

    def _read_and_require_binding(
        self, command_id: str, binding: CtpManagedDispatchBinding
    ) -> tuple[
        CtpDispatchCommand,
        CtpManagedPreparedDispatch,
        CtpOrderIdentityReservation,
        CtpActionIdentityReservation | None,
    ]:
        if type(binding) is not CtpManagedDispatchBinding or binding.command_id != command_id:
            raise ContractValidationError("typed worker binding does not match command")
        command = self._store.read_ctp_dispatch_command(self._scope, command_id)
        if type(command) is not CtpDispatchCommand:
            raise ContractValidationError("durable worker command is missing")
        handoff = self._read_handoff(command)
        reservation = self._store.read_ctp_order_identity(
            self._scope, binding.managed_intent_id
        )
        if type(reservation) is not CtpOrderIdentityReservation:
            raise ContractValidationError("durable OrderRef reservation is missing")
        action = None
        if command.operation == "CANCEL":
            action = self._identity_authority.read_cancel_action_identity(
                self._scope, binding.managed_action_id
            )
            if type(action) is not CtpActionIdentityReservation:
                raise ContractValidationError("durable ActionRef identity is missing")
            if (
                action.native_action_ref != binding.native_action_ref
                or action.order_ref != binding.order_ref
                or command.request_payload.get("OrderActionRef") != action.native_action_ref
                or int(handoff["action_ref"]) != action.native_action_ref
            ):
                raise ContractValidationError("worker ActionRef readback differs")
        prepared = self._prepared_from_binding(binding, action, reservation)
        expected = self._binding(prepared, command, action, reservation)
        if binding.to_payload() | {"local_queue_receipt_queued": None} != expected.to_payload():
            # Queue state is the only field allowed to advance after staging.
            comparable = binding.to_payload()
            comparable["local_queue_receipt_queued"] = None
            if comparable != expected.to_payload():
                raise ContractValidationError("worker binding differs from durable Store readback")
        return command, prepared, reservation, action

    def _prepared_from_binding(
        self,
        binding: CtpManagedDispatchBinding,
        action: CtpActionIdentityReservation | None,
        reservation: CtpOrderIdentityReservation,
    ) -> CtpManagedPreparedDispatch:
        return CtpManagedPreparedDispatch(
            operation=binding.operation,
            command_id=binding.command_id,
            managed_intent_id=binding.managed_intent_id,
            runtime_order_id=binding.runtime_order_id,
            order_ref=binding.order_ref,
            request_payload=dict(binding.request_payload),
            order_ref_reservation=reservation,
            approval_use_id=binding.approval_use_id,
            approval_digest=binding.approval_digest,
            session_binding=dict(binding.session_binding),
            session_generation_id=binding.session_generation_id,
            dispatch_front_id=binding.dispatch_front_id,
            dispatch_session_id=binding.dispatch_session_id,
            native_request_id=binding.native_request_id,
            local_queue_receipt_id=binding.local_queue_receipt_id,
            managed_cancel_intent_id=(None if action is None else action.managed_action_id),
            cancel_target_exchange_id=binding.cancel_target_exchange_id,
            cancel_target_order_sys_id=binding.cancel_target_order_sys_id,
            cancel_target_front_id=binding.cancel_target_front_id,
            cancel_target_session_id=binding.cancel_target_session_id,
        )

    def _read_handoff(self, command: CtpDispatchCommand):
        with self._store._lock:
            row = self._store._connection.execute(
                """SELECT * FROM g5_ctp_worker_handoffs
                   WHERE account_key = ? AND command_id = ?""",
                (command.account_key, command.command_id),
            ).fetchone()
        if row is None or (
            str(row["scope_key"]) != command.scope_key
            or str(row["operation"]) != command.operation
            or str(row["request_payload_sha256"]) != command.request_payload_sha256
        ):
            raise ContractValidationError("same-store worker handoff readback differs")
        return row

    def _set_state(
        self,
        command_id: str,
        state: str,
        *,
        from_states: set[str] | None = None,
    ) -> None:
        allowed = from_states or {"STAGED", "QUEUED", "REJECTED", "CLAIMED", "COMPLETED", "UNKNOWN"}
        placeholders = ",".join("?" for _ in allowed)
        with self._store._transaction() as cursor:
            cursor.execute(
                f"""UPDATE g5_ctp_worker_handoffs SET state = ?, updated_at_ns = ?
                    WHERE account_key = ? AND command_id = ? AND state IN ({placeholders})""",
                (
                    state,
                    time.time_ns(),
                    self._scope.account_key,
                    command_id,
                    *sorted(allowed),
                ),
            )
            if cursor.rowcount != 1:
                current = cursor.execute(
                    "SELECT state FROM g5_ctp_worker_handoffs WHERE account_key = ? AND command_id = ?",
                    (self._scope.account_key, command_id),
                ).fetchone()
                if current is None or str(current["state"]) != state:
                    raise InvalidStateTransition("worker handoff state changed")


__all__ = [
    "CtpManagedDispatchBinding",
    "CtpManagedPreparedDispatch",
    "CtpManagedQueueReceipt",
    "CtpManagedSingleWorkerCandidate",
    "CtpNativeDispatchResult",
    "CtpNativeDispatchSender",
    "CtpWorkerDispatchResult",
    "stable_managed_command_id",
]
