from __future__ import annotations

from hashlib import sha256

import pytest
from backtrader_bridge.ctp_order_action_bridge import (
    CtpOrderActionAuthorityBridge,
    CtpOrderActionBridgeError,
)
from bt_api_execution import (
    CtpCancelTarget,
    CtpDispatchReceipt,
    CtpOrderRefSeedProof,
    CtpVerifiedOrderTargetProjection,
    ExecutionScope,
    SqliteExecutionStore,
)
from bt_api_execution.ctp_identity_authority import (
    CtpActionRefSeedProof,
    CtpUnifiedOrderActionAuthority,
)


def _scope():
    return ExecutionScope("CTP", "simulation", "g5-bridge", "strategy.bridge", "20260927")


def _runtime():
    return "bt-managed-v1:" + sha256(b"bridge-runtime-order").hexdigest()


def _order_seed():
    return CtpOrderRefSeedProof(
        "20260927", "000000000010", "000000000012", sha256(b"old-order-ledger").hexdigest()
    )


def _action_seed():
    return CtpActionRefSeedProof("20260927", 9, sha256(b"old-action-ledger").hexdigest())


class FakeSameStoreWorker:
    def __init__(self, store, scope, lease, *, outcome="QUEUED"):
        self._store = store
        self._scope = scope
        self._lease = lease
        self._outcome = outcome
        self.dispatch_calls = []

    def stage_prepared_dispatch(self, _prepared):
        raise AssertionError("the bridge stages directly through the shared identity authority")

    def record_managed_queue_receipt(self, command_id, _binding, queue_receipt):
        command = self._store.read_ctp_dispatch_command(self._scope, command_id)
        assert command is not None
        claimed = self._store.claim_ctp_dispatch_command(
            self._scope, command_id, writer_lease=self._lease
        )
        assert claimed == command or (claimed is not None and claimed.command_id == command_id)
        receipt = CtpDispatchReceipt(
            receipt_type="ctp_dispatch_receipt.v1",
            command_id=command.command_id,
            account_key=command.account_key,
            scope_key=command.scope_key,
            trading_day=command.trading_day,
            operation=command.operation,
            request_payload_sha256=command.request_payload_sha256,
            reservation_managed_intent_id=command.reservation_managed_intent_id,
            order_ref=command.order_ref,
            cancel_target_order_ref=command.cancel_target_order_ref,
            cancel_target_exchange_id=command.cancel_target_exchange_id,
            cancel_target_order_sys_id=command.cancel_target_order_sys_id,
            cancel_target_front_id=command.cancel_target_front_id,
            cancel_target_session_id=command.cancel_target_session_id,
            approval_use_id=command.approval_use_id,
            approval_digest=command.approval_digest,
            session_binding_sha256=command.session_binding_sha256,
            outcome=self._outcome,
            native_receipt_payload=dict(queue_receipt),
        )
        self._store.complete_ctp_dispatch_command(
            self._scope, receipt, writer_lease=self._lease
        )
        return receipt

    def dispatch_managed_command(self, command_id, _binding, sender):
        command = self._store.read_ctp_dispatch_command(self._scope, command_id)
        assert command is not None and command.status in {"COMPLETED", "UNKNOWN"}
        self.dispatch_calls.append(command_id)
        return sender(command)


class _SyntheticNativeOrderQueryEvidence:
    """Test-only typed stand-in, not native CTP query evidence."""

    instrument_id = "rb2710"
    exchange_id = "SHFE"
    order_sys_id = "SYS-bridge"
    session_generation_id = "synthetic-bridge-generation"
    query_front_id = 4
    query_session_id = 8
    query_request_id = 93
    front_id = 4
    session_id = 8


class _SyntheticOrderQueryVerifier:
    """Test-only verifier for Store persistence/consumer mechanics."""

    def verify_order_target(self, scope, reservation, evidence, *, now_ns):
        assert type(evidence) is _SyntheticNativeOrderQueryEvidence
        return CtpVerifiedOrderTargetProjection(
            account_key=reservation.account_key,
            scope_key=reservation.scope_key,
            trading_day=reservation.trading_day,
            managed_intent_id=reservation.managed_intent_id,
            runtime_order_id=reservation.runtime_order_id,
            order_ref=reservation.order_ref,
            account_fingerprint_sha256=sha256(b"test account").hexdigest(),
            registration_digest=sha256(b"test registration").hexdigest(),
            instrument_id=evidence.instrument_id,
            exchange_id=evidence.exchange_id,
            session_generation_id=evidence.session_generation_id,
            connection_generation=1,
            query_front_id=evidence.query_front_id,
            query_session_id=evidence.query_session_id,
            query_request_id=evidence.query_request_id,
            query_filters_sha256=sha256(b"test filters").hexdigest(),
            query_records_sha256=sha256(b"test records").hexdigest(),
            source_evidence_sha256=sha256(b"test source evidence").hexdigest(),
            query_record_count=1,
            query_match_count=1,
            query_complete=True,
            query_terminal=True,
            query_timed_out=False,
            query_error_id=0,
            late_callback_count=0,
            order_sys_id=evidence.order_sys_id,
            front_id=evidence.front_id,
            session_id=evidence.session_id,
            provider_state="OPEN",
            quantity=1,
            traded_quantity=0,
            remaining_quantity=1,
            verifier_id="test-only.synthetic-bridge-query-verifier",
            verified_at_ns=now_ns,
            expires_at_ns=now_ns + 5_000_000_000,
        )


def _bridge(tmp_path, *, worker_store=None, outcome="QUEUED"):
    store = SqliteExecutionStore(tmp_path / "bridge.sqlite3")
    authority = CtpUnifiedOrderActionAuthority(store)
    scope = _scope()
    lease = store.acquire_or_renew_lease(scope, "bridge-owner", ttl_ns=120_000_000_000)
    worker = FakeSameStoreWorker(worker_store or store, scope, lease, outcome=outcome)
    bridge = CtpOrderActionAuthorityBridge(
        scope=scope,
        store=store,
        authority=authority,
        worker=worker,
        order_seed=_order_seed(),
        action_seed=_action_seed(),
        writer_lease=lease,
    )
    return store, authority, scope, lease, worker, bridge


def _stage(bridge, scope):
    order = bridge.reserve_submit("intent-bridge", _runtime())
    target = CtpCancelTarget(order.order_ref, "SHFE", "SYS-bridge", 4, 8)
    request = {
        "InstrumentID": "rb2710",
        "OrderRef": order.order_ref,
        "ExchangeID": target.exchange_id,
        "OrderSysID": target.order_sys_id,
        "FrontID": target.front_id,
        "SessionID": target.session_id,
        "ActionFlag": "0",
        "LimitPrice": 0.0,
        "VolumeChange": 0,
    }
    projection = bridge._store.issue_ctp_order_target_projection(
        scope,
        order.managed_intent_id,
        _SyntheticNativeOrderQueryEvidence(),
        verifier=_SyntheticOrderQueryVerifier(),
    )
    return bridge.stage_cancel(
        managed_action_id="cancel-bridge",
        managed_intent_id="intent-bridge",
        runtime_order_id=_runtime(),
        expected_order_ref=order.order_ref,
        command_id="cancel-bridge-command",
        request_payload=request,
        target=target,
        cancel_target_projection=projection,
        approval_use_id="approval-bridge",
        approval_digest=sha256(b"approved fake action").hexdigest(),
        session_binding={
            "session_generation_id": "synthetic-bridge-generation",
            "dispatch_front_id": 4,
            "dispatch_session_id": 8,
            "opaque": "test",
        },
    )


def test_bridge_uses_one_order_action_authority_and_sends_only_after_receipt(tmp_path):
    store, _authority, scope, _lease, worker, bridge = _bridge(tmp_path)
    try:
        handle = _stage(bridge, scope)
        assert handle.order.order_ref == handle.command.cancel_target_order_ref
        assert handle.action.native_action_ref == handle.command.request_payload["OrderActionRef"]
        sent = []

        def sender(command):
            sent.append((
                command.command_id,
                command.request_payload["OrderRef"],
                command.request_payload["OrderActionRef"],
                command.native_receipt_payload["provider_ack"],
            ))
            return "local queue observed"

        result = bridge.persist_queue_receipt_then_dispatch(
            handle,
            binding=object(),
            queue_receipt={"local_queue_code": 0, "provider_ack": False},
            sender=sender,
        )
        assert result == "local queue observed"
        assert sent == [(
            "cancel-bridge-command",
            handle.order.order_ref,
            handle.action.native_action_ref,
            False,
        )]
        assert worker.dispatch_calls == ["cancel-bridge-command"]
        assert not hasattr(store, "new_runtime_order_binding")
    finally:
        store.close()


def test_bridge_rejects_worker_bound_to_another_sqlite_authority(tmp_path):
    other = SqliteExecutionStore(tmp_path / "other.sqlite3")
    store = SqliteExecutionStore(tmp_path / "bridge.sqlite3")
    try:
        authority = CtpUnifiedOrderActionAuthority(store)
        scope = _scope()
        lease = store.acquire_or_renew_lease(scope, "owner", ttl_ns=120_000_000_000)
        worker = FakeSameStoreWorker(other, scope, lease)
        with pytest.raises(CtpOrderActionBridgeError, match="same-store worker"):
            CtpOrderActionAuthorityBridge(
                scope=scope,
                store=store,
                authority=authority,
                worker=worker,
                order_seed=_order_seed(),
                action_seed=_action_seed(),
                writer_lease=lease,
            )
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_order_identity_reservations"
        ).fetchone()[0] == 0
    finally:
        other.close()
        store.close()


def test_bridge_never_dispatches_if_queue_receipt_write_fails(tmp_path):
    store, _authority, scope, _lease, worker, bridge = _bridge(tmp_path)
    try:
        handle = _stage(bridge, scope)
        store._connection.execute(
            """CREATE TRIGGER reject_receipt
               BEFORE UPDATE OF native_receipt_payload_json ON ctp_dispatch_commands
               BEGIN SELECT RAISE(ABORT, 'receipt write failure'); END"""
        )
        sent = []
        with pytest.raises(CtpOrderActionBridgeError, match="queue receipt persistence failed"):
            bridge.persist_queue_receipt_then_dispatch(
                handle,
                binding=object(),
                queue_receipt={"local_queue_code": 0, "provider_ack": False},
                sender=lambda value: sent.append(value),
            )
        assert sent == []
        assert worker.dispatch_calls == []
        current = store.read_ctp_dispatch_command(scope, handle.command.command_id)
        assert current is not None and current.status == "CLAIMED"
    finally:
        store.close()


def test_unknown_queue_receipt_is_not_dispatched(tmp_path):
    store, _authority, _scope_value, _lease, worker, bridge = _bridge(
        tmp_path, outcome="UNKNOWN"
    )
    try:
        handle = _stage(bridge, _scope())
        sent = []
        with pytest.raises(CtpOrderActionBridgeError, match="queue receipt does not echo"):
            bridge.persist_queue_receipt_then_dispatch(
                handle,
                binding=object(),
                queue_receipt={"local_queue_code": 0, "provider_ack": False},
                sender=lambda value: sent.append(value),
            )
        assert sent == []
        assert worker.dispatch_calls == []
    finally:
        store.close()
