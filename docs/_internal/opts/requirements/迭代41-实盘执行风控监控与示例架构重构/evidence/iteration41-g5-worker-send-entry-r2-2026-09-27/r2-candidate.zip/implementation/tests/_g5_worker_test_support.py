from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from itertools import count

from bt_api_execution import (
    CtpCancelTarget,
    CtpOrderRefSeedProof,
    CtpVerifiedOrderTargetProjection,
    ExecutionScope,
    SqliteExecutionStore,
)
from bt_api_execution.ctp_identity_authority import (
    CtpActionRefSeedProof,
    CtpUnifiedOrderActionAuthority,
)
from bt_api_execution.ctp_single_worker_candidate import (
    CtpManagedPreparedDispatch,
    CtpManagedQueueReceipt,
    stable_managed_command_id,
)
from bt_api_execution.errors import ContractValidationError


@dataclass(frozen=True)
class _SyntheticNativeOrderQueryEvidence:
    """Test-only opaque stand-in; this is not evidence from a native SDK query."""

    instrument_id: str
    exchange_id: str
    order_sys_id: str
    session_generation_id: str
    query_front_id: int
    query_session_id: int
    query_request_id: int
    front_id: int
    session_id: int
    provider_state: str = "OPEN"
    quantity: int = 1
    traded_quantity: int = 0


class _SyntheticOrderQueryVerifier:
    """Test-only fake verifier used to exercise the durable consumer contract."""

    def verify_order_target(self, scope, reservation, evidence, *, now_ns):
        if type(evidence) is not _SyntheticNativeOrderQueryEvidence:
            raise ContractValidationError("synthetic typed query evidence required")
        return CtpVerifiedOrderTargetProjection(
            account_key=reservation.account_key,
            scope_key=reservation.scope_key,
            trading_day=reservation.trading_day,
            managed_intent_id=reservation.managed_intent_id,
            runtime_order_id=reservation.runtime_order_id,
            order_ref=reservation.order_ref,
            account_fingerprint_sha256=sha256(b"synthetic account fingerprint").hexdigest(),
            registration_digest=sha256(b"synthetic registration").hexdigest(),
            instrument_id=evidence.instrument_id,
            exchange_id=evidence.exchange_id,
            session_generation_id=evidence.session_generation_id,
            connection_generation=1,
            query_front_id=evidence.query_front_id,
            query_session_id=evidence.query_session_id,
            query_request_id=evidence.query_request_id,
            query_filters_sha256=sha256(b"synthetic query filters").hexdigest(),
            query_records_sha256=sha256(b"synthetic query records").hexdigest(),
            source_evidence_sha256=sha256(b"synthetic source evidence").hexdigest(),
            query_record_count=1,
            query_match_count=1,
            query_complete=True,
            query_terminal=True,
            query_timed_out=False,
            query_error_id=0,
            late_callback_count=0,
            order_sys_id=evidence.order_sys_id,
            front_id=evidence.front_id,
            session_id=evidence.session_id,
            provider_state=evidence.provider_state,
            quantity=evidence.quantity,
            traded_quantity=evidence.traded_quantity,
            remaining_quantity=evidence.quantity - evidence.traded_quantity,
            verifier_id="test-only.synthetic-order-query-verifier",
            verified_at_ns=now_ns,
            expires_at_ns=now_ns + 5_000_000_000,
        )


_QUERY_REQUEST_IDS = count(11)


def _scope() -> ExecutionScope:
    return ExecutionScope("CTP", "simulation", "g5-worker", "strategy.worker", "20260927")


def _runtime_id(value: str) -> str:
    return "bt-managed-v1:" + sha256(value.encode("ascii")).hexdigest()


def _open(path, owner: str = "worker-owner"):
    store = SqliteExecutionStore(path)
    authority = CtpUnifiedOrderActionAuthority(store)
    scope = _scope()
    lease = store.acquire_or_renew_lease(scope, owner, ttl_ns=120_000_000_000)

    return store, authority, scope, lease


def _seed_order(authority, scope, lease):
    return authority.reserve_submit_order_identity(
        scope,
        CtpOrderRefSeedProof(
            "20260927",
            "000000000010",
            "000000000012",
            sha256(b"synthetic order seed").hexdigest(),
        ),
        "worker-intent",
        _runtime_id("worker-intent"),
        writer_lease=lease,
    )


def _prepared(order):
    target = CtpCancelTarget(order.order_ref, "SHFE", "SYS-WORKER", 17, 29)
    payload = {
        "InstrumentID": "rb2710",
        "OrderRef": target.order_ref,
        "ExchangeID": target.exchange_id,
        "OrderSysID": target.order_sys_id,
        "FrontID": target.front_id,
        "SessionID": target.session_id,
        "ActionFlag": "0",
        "LimitPrice": 0.0,
        "VolumeChange": 0,
    }
    action_id = "cancel-worker"
    return CtpManagedPreparedDispatch(
        operation="cancel",
        command_id=stable_managed_command_id(
            "cancel", "worker-intent", order.runtime_order_id, action_id
        ),
        managed_intent_id="worker-intent",
        runtime_order_id=order.runtime_order_id,
        order_ref=order.order_ref,
        request_payload=payload,
        order_ref_reservation=order,
        approval_use_id="approval-worker",
        approval_digest=sha256(b"synthetic approval").hexdigest(),
        session_binding={
            "session_generation_id": "generation-1",
            "dispatch_front_id": 17,
            "dispatch_session_id": 29,
        },
        session_generation_id="generation-1",
        dispatch_front_id=17,
        dispatch_session_id=29,
        native_request_id=5,
        local_queue_receipt_id="0123456789abcdef0123456789abcdef",
        managed_cancel_intent_id=action_id,
        cancel_target_exchange_id=target.exchange_id,
        cancel_target_order_sys_id=target.order_sys_id,
        cancel_target_front_id=target.front_id,
        cancel_target_session_id=target.session_id,
    )


def _prepared_submit(order):
    return CtpManagedPreparedDispatch(
        operation="submit",
        command_id=stable_managed_command_id(
            "submit", "worker-intent", order.runtime_order_id
        ),
        managed_intent_id="worker-intent",
        runtime_order_id=order.runtime_order_id,
        order_ref=order.order_ref,
        request_payload={"InstrumentID": "rb2710", "OrderRef": order.order_ref},
        order_ref_reservation=order,
        approval_use_id="approval-submit-worker",
        approval_digest=sha256(b"synthetic submit approval").hexdigest(),
        session_binding={
            "session_generation_id": "generation-1",
            "dispatch_front_id": 17,
            "dispatch_session_id": 29,
        },
        session_generation_id="generation-1",
        dispatch_front_id=17,
        dispatch_session_id=29,
        native_request_id=6,
        local_queue_receipt_id="1123456789abcdef0123456789abcdef",
    )


def _reserve_action(authority, scope, lease, order):
    return authority.reserve_cancel_action_identity(
        scope,
        "cancel-worker",
        "worker-intent",
        order.runtime_order_id,
        order.order_ref,
        legacy_seed=CtpActionRefSeedProof(
            "20260927", 41, sha256(b"synthetic action seed").hexdigest()
        ),
        writer_lease=lease,
    )


def _queue(binding, command):
    return CtpManagedQueueReceipt(
        command_id=command.command_id,
        request_payload_sha256=command.request_payload_sha256,
        operation=command.operation,
        receipt_id=binding.local_queue_receipt_id,
        queued=True,
    )


def _target_projection(store, order, prepared, *, exchange_id=None):
    evidence = _SyntheticNativeOrderQueryEvidence(
        instrument_id=prepared.request_payload["InstrumentID"],
        exchange_id=exchange_id or prepared.cancel_target_exchange_id,
        order_sys_id=prepared.cancel_target_order_sys_id,
        session_generation_id=prepared.session_generation_id,
        query_front_id=prepared.dispatch_front_id,
        query_session_id=prepared.dispatch_session_id,
        query_request_id=next(_QUERY_REQUEST_IDS),
        front_id=prepared.cancel_target_front_id,
        session_id=prepared.cancel_target_session_id,
    )
    return store.issue_ctp_order_target_projection(
        _scope(), order.managed_intent_id, evidence, verifier=_SyntheticOrderQueryVerifier()
    )



__test__ = False
