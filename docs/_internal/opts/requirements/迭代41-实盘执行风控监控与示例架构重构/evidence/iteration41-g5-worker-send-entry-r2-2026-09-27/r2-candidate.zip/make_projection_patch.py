import difflib
from pathlib import Path

ROOT = Path(r"D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate")
BASE = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
PATHS = (
    "implementation/sdk/src/bt_api_execution/__init__.py",
    "implementation/sdk/src/bt_api_execution/store.py",
    "implementation/sdk/src/bt_api_execution/ctp_identity_authority.py",
    "implementation/sdk/src/bt_api_execution/ctp_single_worker_candidate.py",
    "implementation/backtrader_bridge/ctp_order_action_bridge.py",
    "implementation/tests/test_g5_single_worker_action_handoff.py",
    "implementation/tests/test_g5_store_order_action_bridge.py",
    "implementation/tests/test_g5_unified_order_action_authority.py",
)

patch_parts = []
for relative in PATHS:
    old_path = BASE / relative
    new_path = ROOT / relative
    patch_parts.append(
        "".join(
            difflib.unified_diff(
                old_path.read_text(encoding="utf-8").splitlines(keepends=True),
                new_path.read_text(encoding="utf-8").splitlines(keepends=True),
                fromfile="a/" + relative,
                tofile="b/" + relative,
            )
        )
    )

output = ROOT / "implementation/sdk_patch/G5_TYPED_TARGET_PROJECTION_DURABLE_CONSUMER.patch"
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text("".join(patch_parts), encoding="utf-8", newline="")
print(f"patch={output}")
print(f"bytes={output.stat().st_size}")
