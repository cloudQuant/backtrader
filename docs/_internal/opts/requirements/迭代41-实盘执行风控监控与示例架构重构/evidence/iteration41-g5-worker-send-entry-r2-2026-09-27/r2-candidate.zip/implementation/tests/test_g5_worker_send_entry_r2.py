from __future__ import annotations

import inspect

import pytest
from _g5_worker_test_support import (
    _open,
    _prepared,
    _prepared_submit,
    _queue,
    _reserve_action,
    _seed_order,
    _target_projection,
)
from bt_api_execution.ctp_single_worker_candidate import CtpManagedSingleWorkerCandidate


def test_r2_dispatch_has_no_caller_sender_and_rejects_before_native_entry(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "r2-no-sender.sqlite3")
    try:
        order = _seed_order(authority, scope, lease)
        prepared = _prepared_submit(order)
        worker = CtpManagedSingleWorkerCandidate(store, scope, lease, authority)
        signature = inspect.signature(worker.dispatch_managed_command)
        assert list(signature.parameters) == ["command_id", "binding"]
        binding = worker.stage_prepared_dispatch(prepared)
        staged = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert staged is not None
        binding = worker.record_managed_queue_receipt(
            prepared.command_id, binding, _queue(binding, staged)
        )
        entered = []

        def sync_wrapper(_command):
            entered.append("wrapper")
            return object()

        # A caller callback is rejected by Python's signature before it can run.
        with pytest.raises(TypeError):
            worker.dispatch_managed_command(prepared.command_id, binding, sync_wrapper)
        assert entered == []
        persisted = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert persisted is not None and persisted.status == "READY"

        result = worker.dispatch_managed_command(prepared.command_id, binding)
        assert result.worker_state == "REJECTED"
        assert result.native_call_entered is False
        assert result.command.status == "COMPLETED"
        again = worker.dispatch_managed_command(prepared.command_id, binding)
        assert again.worker_state == "REJECTED"
        assert again.native_call_entered is False
        assert entered == []
    finally:
        store.close()


def test_r2_cancel_projection_is_rechecked_after_claim_and_expiry_rejects(tmp_path, monkeypatch):
    store, authority, scope, lease = _open(tmp_path / "r2-expired-projection.sqlite3")
    try:
        order = _seed_order(authority, scope, lease)
        action = _reserve_action(authority, scope, lease, order)
        prepared = _prepared(order)
        worker = CtpManagedSingleWorkerCandidate(store, scope, lease, authority)
        projection_handle = _target_projection(store, order, prepared)
        binding = worker.stage_prepared_dispatch(
            prepared,
            cancel_target_projection=projection_handle,
            action_identity=action,
        )
        staged = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert staged is not None
        binding = worker.record_managed_queue_receipt(
            prepared.command_id, binding, _queue(binding, staged)
        )
        expiry_ns = projection_handle.projection.expires_at_ns
        # Claim sees a fresh row; the code-owned port's final durable read
        # then sees equality as expired.
        reads = iter((expiry_ns - 1, expiry_ns))
        monkeypatch.setattr(store, "_monotonic_now_ns", lambda: next(reads))
        result = worker.dispatch_managed_command(prepared.command_id, binding)
        assert result.worker_state == "REJECTED"
        assert result.native_call_entered is False
        assert result.command.status == "COMPLETED"
        row = store._connection.execute(
            "SELECT state FROM g5_ctp_worker_handoffs WHERE account_key = ? AND command_id = ?",
            (scope.account_key, prepared.command_id),
        ).fetchone()
        assert row["state"] == "REJECTED"
    finally:
        store.close()


def test_r2_missing_trusted_generation_time_and_sdk_pin_default_reject(tmp_path):
    store, authority, scope, lease = _open(tmp_path / "r2-missing-authorities.sqlite3")
    try:
        order = _seed_order(authority, scope, lease)
        prepared = _prepared_submit(order)
        assert "connection_generation" not in prepared.session_binding
        assert "process_generation" not in prepared.session_binding
        worker = CtpManagedSingleWorkerCandidate(store, scope, lease, authority)
        binding = worker.stage_prepared_dispatch(prepared)
        staged = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert staged is not None
        binding = worker.record_managed_queue_receipt(
            prepared.command_id, binding, _queue(binding, staged)
        )
        result = worker.dispatch_managed_command(prepared.command_id, binding)
        assert result.worker_state == "REJECTED"
        assert result.native_call_entered is False
        assert result.command.native_receipt_payload == {
            "kind": "native_send_port_unavailable",
            "outcome": "REJECTED",
        }
    finally:
        store.close()


def test_r2_claim_crash_reopens_as_unknown_and_never_reenters_port(tmp_path):
    path = tmp_path / "r2-crash-after-claim.sqlite3"
    store, authority, scope, lease = _open(path)
    order = _seed_order(authority, scope, lease)
    prepared = _prepared_submit(order)
    worker = CtpManagedSingleWorkerCandidate(store, scope, lease, authority)
    binding = worker.stage_prepared_dispatch(prepared)
    staged = store.read_ctp_dispatch_command(scope, prepared.command_id)
    assert staged is not None
    binding = worker.record_managed_queue_receipt(
        prepared.command_id, binding, _queue(binding, staged)
    )
    claimed = store.claim_ctp_dispatch_command(scope, prepared.command_id, writer_lease=lease)
    assert claimed is not None and claimed.status == "CLAIMED"
    assert store.release_lease(scope, lease.owner_id, fencing_token=lease.fencing_token)
    store.close()

    reopened, authority2, scope2, lease2 = _open(path, "r2-worker-restarted")
    try:
        worker2 = CtpManagedSingleWorkerCandidate(reopened, scope2, lease2, authority2)
        recovered = worker2.recover_claimed_after_restart()
        assert len(recovered) == 1 and recovered[0].status == "UNKNOWN"
        result = worker2.dispatch_managed_command(prepared.command_id, binding)
        assert result.worker_state == "UNKNOWN"
        assert result.native_call_entered is False
        persisted = reopened.read_ctp_dispatch_command(scope2, prepared.command_id)
        assert persisted is not None and persisted.status == "UNKNOWN"
    finally:
        reopened.close()
