from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(r"D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate")
BASE_ROOT = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
V21_STORE = Path(
    r"D:\temp\g5-v21-execution-wheel-build-20260927\source\src\bt_api_execution\store.py"
)
V21_WORKER = Path(
    r"D:\temp\g5-v21-execution-wheel-build-20260927\source\src\bt_api_execution\ctp_single_worker_candidate.py"
)
MANIFEST = ROOT / "evidence/final-output-manifest.json"
PATCH = ROOT / "implementation/sdk_patch/G5_TYPED_TARGET_PROJECTION_DURABLE_CONSUMER.patch"
EXCLUDED_CACHE_DIRS = {"__pycache__", ".pytest_cache", ".ruff_cache", ".benchmarks"}

outputs = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path == MANIFEST:
        continue
    relative = path.relative_to(ROOT)
    if EXCLUDED_CACHE_DIRS.intersection(relative.parts):
        continue
    data = path.read_bytes()
    outputs.append(
        {"path": relative.as_posix(), "bytes": len(data), "sha256": sha256(data).hexdigest()}
    )

base_manifest_path = BASE_ROOT / "evidence/final-output-manifest.json"
source = {
    "format": "iteration41-g5-typed-durable-target-consumer-manifest.v1",
    "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "status": "TYPED_DURABLE_CONSUMER_ONLY / BLOCKED / G5_NOT_ACCEPTED",
    "backtrader_source_head": "ad2c142b9a8b42cede85886528c681abdfcb8096",
    "sdk_snapshot_head": "2700cb5454ef4c3d1780eda28b6f33307a860998",
    "base_worker_handoff_candidate_manifest_sha256": sha256(
        base_manifest_path.read_bytes()
    ).hexdigest(),
    "frozen_input_manifest_sha256": sha256(
        (ROOT / "frozen-input-manifest.json").read_bytes()
    ).hexdigest(),
    "delta_patch": {
        "path": PATCH.relative_to(ROOT).as_posix(),
        "sha256": sha256(PATCH.read_bytes()).hexdigest(),
    },
    "v21_reference": {
        "store_source_path": str(V21_STORE),
        "store_source_sha256": sha256(V21_STORE.read_bytes()).hexdigest(),
        "schema_version": 21,
        "worker_source_path": str(V21_WORKER),
        "worker_source_sha256": sha256(V21_WORKER.read_bytes()).hexdigest(),
        "projection_contract": (
            "CtpVerifiedOrderTargetProjection fields, durable projection table, one-use "
            "consumption table, immutable rows, and default rejecting verifier were reviewed "
            "and adapted to the isolated frozen SDK Store schema. This is not a V21 Store pin."
        ),
        "native_verifier_status": (
            "V21 source has only the verifier Protocol and _Reject verifier; no concrete native "
            "query producer or current SDK-owned query readback adapter was found."
        ),
        "compatibility_limits": [
            "V21 worker stage_prepared_dispatch has no action_identity keyword.",
            "V21 allocates per-account ActionRef from one; candidate Store accepts only its own "
            "CtpUnifiedOrderActionAuthority and never mixes V21's allocator.",
            "V21 projection session_generation_id is not OS process_generation.",
        ],
    },
    "native_query_producer_status": "MISSING; default verifier rejects",
    "actionref_authority": (
        "Only this candidate's CtpUnifiedOrderActionAuthority is accepted by its Store; "
        "the seed is caller-supplied and unverified. No V21 allocator is mixed in."
    ),
    "seed_status": "CALLER_SUPPLIED / NON_AUTHORIZING",
    "projection_status": (
        "Durable typed consumer/readback and one-use binding exist in candidate schema 6. "
        "Only test-only synthetic evidence has an injected verifier; production default Rejects."
    ),
    "dispatch_status": "NO_WRITE / NO_PROVIDER / NO_REAL_SDK / ZERO_REPLAY_TESTED",
    "test_summary": {
        "candidate_focus": "26 passed",
        "candidate_sdk_frozen_tests_against_candidate_source": (
            "53 passed / 4 failed: three assertions still expect schema version 5; one direct "
            "CANCEL fixture omits the now-required typed target projection and candidate ActionRef."
        ),
        "candidate_sdk_frozen_tests_against_frozen_source": "57 passed (baseline only)",
        "ruff": (
            "Changed candidate files: E4,E7,E9,F,I passed. Broader SDK scan reports existing "
            "I001 formatting in untouched cancellation.py and facade.py."
        ),
        "py_compile": "passed",
        "frozen_input_integrity": (
            "27 non-cache source entries match; 23 generated __pycache__ entries listed in the "
            "frozen manifest are ignored because Python mutates/removes interpreter caches."
        ),
    },
    "excluded_paths_note": (
        "Generated Python and tool caches are omitted. Frozen read-only inputs and their "
        "digests are enumerated in frozen-input-manifest.json."
    ),
    "outputs": outputs,
}
MANIFEST.write_text(json.dumps(source, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(f"outputs={len(outputs)}")
print(f"base_candidate_manifest_sha256={source['base_worker_handoff_candidate_manifest_sha256']}")
print(f"frozen_input_manifest_sha256={source['frozen_input_manifest_sha256']}")
print(f"v21_store_source_sha256={source['v21_reference']['store_source_sha256']}")
print(f"manifest={MANIFEST}")
