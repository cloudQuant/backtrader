from __future__ import annotations

import difflib
from pathlib import Path

root = Path(__file__).resolve().parent
base = root.parent / "r1-frozen-candidate"
pairs = [
    ("README.md", base / "README.md", root / "README.md"),
    (
        "implementation/sdk/src/bt_api_execution/ctp_single_worker_candidate.py",
        base / "implementation/sdk/src/bt_api_execution/ctp_single_worker_candidate.py",
        root / "implementation/sdk/src/bt_api_execution/ctp_single_worker_candidate.py",
    ),
    (
        "implementation/tests/test_g5_single_worker_action_handoff.py",
        base / "implementation/tests/test_g5_single_worker_action_handoff.py",
        None,
    ),
    (
        "implementation/tests/_g5_worker_test_support.py",
        None,
        root / "implementation/tests/_g5_worker_test_support.py",
    ),
    (
        "implementation/tests/test_g5_worker_send_entry_r2.py",
        None,
        root / "implementation/tests/test_g5_worker_send_entry_r2.py",
    ),
]
parts: list[str] = []
for relative, old_path, new_path in pairs:
    old_lines = [] if old_path is None else old_path.read_text(encoding="utf-8").splitlines(keepends=True)
    new_lines = [] if new_path is None else new_path.read_text(encoding="utf-8").splitlines(keepends=True)
    if old_lines == new_lines:
        continue
    diff = list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{relative}",
            tofile=f"b/{relative}",
            n=3,
        )
    )
    parts.append(f"diff --git a/{relative} b/{relative}\n")
    if old_path is None:
        parts.append("new file mode 100644\n--- /dev/null\n")
        parts.append(f"+++ b/{relative}\n")
    elif new_path is None:
        parts.append("deleted file mode 100644\n")
        parts.append(f"--- a/{relative}\n+++ /dev/null\n")
    else:
        parts.extend(diff[:2])
    parts.extend(diff[2:])

patch_path = root / "implementation/sdk_patch/G5_SEND_ENTRY_FAIL_CLOSED_R2.patch"
patch_path.parent.mkdir(parents=True, exist_ok=True)
patch_path.write_text("".join(parts), encoding="utf-8", newline="\n")
print(f"wrote {patch_path} ({len(parts)} patch lines)")