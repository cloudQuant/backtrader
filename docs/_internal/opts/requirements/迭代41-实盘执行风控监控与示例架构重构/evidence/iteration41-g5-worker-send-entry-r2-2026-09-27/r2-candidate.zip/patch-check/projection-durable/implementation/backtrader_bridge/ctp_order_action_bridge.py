"""Unregistered Store bridge candidate for one shared CTP identity ledger.

The ordinary BtApiStore call sites stay fail-closed. This narrow adapter is
only usable when an exact SDK store, the same-store queue worker, the explicit
legacy seed proofs, and the current writer lease are injected together.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

from bt_api_execution import (
    CtpCancelTarget,
    CtpOrderTargetProjectionHandle,
    ExecutionScope,
    SqliteExecutionStore,
)
from bt_api_execution.ctp_identity_authority import (
    CtpActionIdentityReservation,
    CtpActionRefSeedProof,
    CtpUnifiedOrderActionAuthority,
)
from bt_api_execution.store import (
    CtpDispatchCommand,
    CtpDispatchReceipt,
    CtpOrderIdentityReservation,
)


class CtpOrderActionBridgeError(ValueError):
    """Redacted failure for the unregistered CTP identity bridge."""


@dataclass(frozen=True)
class CtpCancelAuthorityHandle:
    """Exact order and cancel identities staged in the one SDK SQLite file."""

    order: CtpOrderIdentityReservation
    action: CtpActionIdentityReservation
    command: CtpDispatchCommand


class CtpOrderActionAuthorityBridge:
    """Store/SDK seam that never allocates an alternate native identifier."""

    def __init__(
        self,
        *,
        scope: ExecutionScope,
        store: SqliteExecutionStore,
        authority: CtpUnifiedOrderActionAuthority,
        worker: Any,
        order_seed: Any,
        action_seed: Optional[CtpActionRefSeedProof],
        writer_lease: Any,
    ) -> None:
        required_worker_methods = (
            "stage_prepared_dispatch",
            "record_managed_queue_receipt",
            "dispatch_managed_command",
        )
        if (
            type(store) is not SqliteExecutionStore
            or type(authority) is not CtpUnifiedOrderActionAuthority
            or authority.store is not store
            or getattr(worker, "_store", None) is not store
            or getattr(worker, "_scope", None) != scope
            or any(not callable(getattr(worker, name, None)) for name in required_worker_methods)
        ):
            raise CtpOrderActionBridgeError(
                "one exact SDK store, scope, and same-store worker are required"
            )
        self._scope = scope
        self._store = store
        self._authority = authority
        self._worker = worker
        self._order_seed = order_seed
        self._action_seed = action_seed
        self._writer_lease = writer_lease

    def reserve_submit(self, managed_intent_id: str, runtime_order_id: str):
        """Return the single SDK OrderRef reservation after exact readback."""

        reservation = self._authority.reserve_submit_order_identity(
            self._scope,
            self._order_seed,
            managed_intent_id,
            runtime_order_id,
            writer_lease=self._writer_lease,
        )
        current = self._store.read_ctp_order_identity(self._scope, managed_intent_id)
        if current != reservation:
            raise CtpOrderActionBridgeError("shared OrderRef authority readback differs")
        return reservation

    def stage_cancel(
        self,
        *,
        managed_action_id: str,
        managed_intent_id: str,
        runtime_order_id: str,
        expected_order_ref: str,
        command_id: str,
        request_payload: Mapping[str, Any],
        target: CtpCancelTarget,
        cancel_target_projection: CtpOrderTargetProjectionHandle,
        approval_use_id: str,
        approval_digest: str,
        session_binding: Mapping[str, Any],
    ) -> CtpCancelAuthorityHandle:
        """Reserve ActionRef and stage a hash-bound command in the same DB."""

        if "OrderActionRef" in request_payload:
            raise CtpOrderActionBridgeError("caller-supplied OrderActionRef is forbidden")
        order = self._store.read_ctp_order_identity(self._scope, managed_intent_id)
        if (
            type(order) is not CtpOrderIdentityReservation
            or order.runtime_order_id != runtime_order_id
            or order.order_ref != expected_order_ref
            or target.order_ref != expected_order_ref
        ):
            raise CtpOrderActionBridgeError("cancel target differs from exact OrderRef reservation")
        if type(cancel_target_projection) is not CtpOrderTargetProjectionHandle:
            raise CtpOrderActionBridgeError("typed verified target projection is required")
        try:
            projection = self._store.read_ctp_order_target_projection(
                self._scope, cancel_target_projection
            )
        except Exception as error:
            raise CtpOrderActionBridgeError("same-store target projection readback failed") from error
        if (projection.account_key != order.account_key
                or projection.scope_key != order.scope_key
                or projection.trading_day != order.trading_day
                or projection.managed_intent_id != order.managed_intent_id
                or projection.runtime_order_id != order.runtime_order_id
                or projection.order_ref != order.order_ref
                or projection.exchange_id != target.exchange_id
                or projection.order_sys_id != target.order_sys_id
                or projection.front_id != target.front_id
                or projection.session_id != target.session_id):
            raise CtpOrderActionBridgeError("target projection differs from cancel identity")
        action = self._authority.reserve_cancel_action_identity(
            self._scope,
            managed_action_id,
            managed_intent_id,
            runtime_order_id,
            expected_order_ref,
            legacy_seed=self._action_seed,
            writer_lease=self._writer_lease,
        )
        command = self._authority.stage_cancel_command(
            self._scope,
            managed_action_id,
            command_id,
            request_payload,
            target=target,
            cancel_target_projection=cancel_target_projection,
            approval_use_id=approval_use_id,
            approval_digest=approval_digest,
            session_binding=session_binding,
            writer_lease=self._writer_lease,
        )
        if (
            command.command_id != command_id
            or command.operation != "CANCEL"
            or command.request_payload.get("OrderRef") != order.order_ref
            or command.request_payload.get("OrderActionRef") != action.native_action_ref
            or command.cancel_target_order_ref != order.order_ref
            or command.reservation_managed_intent_id != managed_intent_id
        ):
            raise CtpOrderActionBridgeError("staged command differs from shared identity ledger")
        current_order = self._store.read_ctp_order_identity(self._scope, managed_intent_id)
        current_action = self._authority.read_cancel_action_identity(
            self._scope, managed_action_id
        )
        current_command = self._store.read_ctp_dispatch_command(self._scope, command_id)
        if current_order != order or current_action != action or current_command != command:
            raise CtpOrderActionBridgeError("post-stage authority readback differs")
        return CtpCancelAuthorityHandle(order, action, command)

    def persist_queue_receipt_then_dispatch(
        self,
        handle: CtpCancelAuthorityHandle,
        binding: Any,
        queue_receipt: Mapping[str, Any],
        sender: Any,
    ) -> Any:
        """Use the same worker: durable local receipt must precede its claim/send.

        The SDK worker must return a typed same-row queue projection from
        ``record_managed_queue_receipt``. A bare return code, fake receipt, or
        out-of-store outbox is rejected. Queue admission is not provider ACK.
        """

        if type(handle) is not CtpCancelAuthorityHandle:
            raise CtpOrderActionBridgeError("typed same-store cancel handle is required")
        if not isinstance(queue_receipt, Mapping) or not queue_receipt:
            raise CtpOrderActionBridgeError("typed local queue receipt payload is required")
        try:
            receipt_projection = self._worker.record_managed_queue_receipt(
                handle.command.command_id, binding, queue_receipt
            )
            durable = self._store.read_ctp_dispatch_command(
                self._scope, handle.command.command_id
            )
        except Exception as error:
            raise CtpOrderActionBridgeError("same-store queue receipt persistence failed") from error
        if (
            type(receipt_projection) is not CtpDispatchReceipt
            or durable is None
            or durable.command_id != handle.command.command_id
            or durable.request_payload_sha256 != handle.command.request_payload_sha256
            or durable.request_payload.get("OrderRef") != handle.order.order_ref
            or durable.request_payload.get("OrderActionRef") != handle.action.native_action_ref
            or getattr(receipt_projection, "command_id", None) != handle.command.command_id
            or getattr(receipt_projection, "request_payload_sha256", None)
            != handle.command.request_payload_sha256
            or getattr(receipt_projection, "outcome", None) != "QUEUED"
            or dict(receipt_projection.native_receipt_payload) != dict(queue_receipt)
        ):
            raise CtpOrderActionBridgeError("queue receipt does not echo durable identity")
        try:
            after = self._store.read_ctp_dispatch_command(
                self._scope, handle.command.command_id
            )
            if after != durable:
                raise CtpOrderActionBridgeError("queue receipt changed before worker dispatch")
            return self._worker.dispatch_managed_command(
                handle.command.command_id, binding, sender
            )
        except Exception as error:
            raise CtpOrderActionBridgeError("same-store worker dispatch is unavailable") from error


__all__ = [
    "CtpCancelAuthorityHandle",
    "CtpOrderActionAuthorityBridge",
    "CtpOrderActionBridgeError",
]
