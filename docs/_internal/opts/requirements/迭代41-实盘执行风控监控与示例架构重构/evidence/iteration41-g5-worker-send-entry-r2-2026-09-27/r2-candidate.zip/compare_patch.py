from hashlib import sha256
from pathlib import Path

root = Path(r"D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate")
for relative in (
    "backtrader/stores/ctp_i9_managed_dispatch.py",
    "backtrader/stores/ctp_i9_parent_request_builder.py",
):
    applied = (root / "patch-check" / relative).read_bytes()
    candidate = (root / "implementation/main_repo_patch" / relative).read_bytes()
    applied_lf = applied.replace(b"\r\n", b"\n")
    candidate_lf = candidate.replace(b"\r\n", b"\n")
    print(relative)
    print(f"applied={sha256(applied_lf).hexdigest()}")
    print(f"candidate={sha256(candidate_lf).hexdigest()}")
    print(f"match={applied_lf == candidate_lf}")
