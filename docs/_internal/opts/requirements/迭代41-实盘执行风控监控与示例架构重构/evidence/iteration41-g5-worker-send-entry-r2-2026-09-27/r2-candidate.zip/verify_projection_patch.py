from hashlib import sha256
from pathlib import Path
import shutil
import subprocess

ROOT = Path(r"D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate")
BASE = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
RELATIVE_PATHS = (
    "implementation/sdk/src/bt_api_execution/__init__.py",
    "implementation/sdk/src/bt_api_execution/store.py",
    "implementation/sdk/src/bt_api_execution/ctp_identity_authority.py",
    "implementation/sdk/src/bt_api_execution/ctp_single_worker_candidate.py",
    "implementation/backtrader_bridge/ctp_order_action_bridge.py",
    "implementation/tests/test_g5_single_worker_action_handoff.py",
    "implementation/tests/test_g5_store_order_action_bridge.py",
    "implementation/tests/test_g5_unified_order_action_authority.py",
)
PATCH = ROOT / "implementation/sdk_patch/G5_TYPED_TARGET_PROJECTION_DURABLE_CONSUMER.patch"
CHECK_ROOT = ROOT / "patch-check/projection-durable"

for relative in RELATIVE_PATHS:
    source = BASE / relative
    destination = CHECK_ROOT / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)

for verb in ("--check",):
    result = subprocess.run(
        ["git", "apply", verb, str(PATCH)],
        cwd=CHECK_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        raise SystemExit(result.stdout + result.stderr)
apply = subprocess.run(
    ["git", "apply", str(PATCH)],
    cwd=CHECK_ROOT,
    capture_output=True,
    text=True,
    check=False,
)
if apply.returncode:
    raise SystemExit(apply.stdout + apply.stderr)

lines = ["git apply --check: passed", "git apply: passed"]
for relative in RELATIVE_PATHS:
    applied = (CHECK_ROOT / relative).read_bytes()
    candidate = (ROOT / relative).read_bytes()
    matched = applied.replace(b"\r\n", b"\n") == candidate.replace(b"\r\n", b"\n")
    lines.extend(
        (
            f"path={relative}",
            f"applied_sha256={sha256(applied).hexdigest()}",
            f"candidate_sha256={sha256(candidate).hexdigest()}",
            f"normalized_match={matched}",
        )
    )
    if not matched:
        raise SystemExit("patch output differs from candidate: " + relative)
lines.append("All delta-patch outputs match the isolated candidate after LF normalization.")
log = ROOT / "evidence/g5-projection-patch-apply-check.log"
log.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))
