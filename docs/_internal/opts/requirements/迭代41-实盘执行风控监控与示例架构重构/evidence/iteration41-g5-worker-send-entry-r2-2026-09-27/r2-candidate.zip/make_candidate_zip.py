from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate")
OUTPUT = ROOT.with_suffix(".zip")
SKIP_DIRS = {"__pycache__", ".pytest_cache", ".ruff_cache", ".benchmarks"}

with ZipFile(OUTPUT, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or SKIP_DIRS.intersection(path.relative_to(ROOT).parts):
            continue
        archive.write(path, path.relative_to(ROOT).as_posix())

print(f"zip={OUTPUT}")
print(f"bytes={OUTPUT.stat().st_size}")
print(f"sha256={sha256(OUTPUT.read_bytes()).hexdigest()}")
