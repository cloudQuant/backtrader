from pathlib import Path
from hashlib import sha256
root=Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
a=(root/"patch-check/backtrader/stores/ctp_i9_parent_request_builder.py").read_bytes()
b=(root/"implementation/main_repo_patch/backtrader/stores/ctp_i9_parent_request_builder.py").read_bytes()
normalize=lambda x:x.replace(b"\r\n",b"\n")
na,nb=normalize(a),normalize(b)
lines=[
    "git apply --check: passed",
    "git apply: passed",
    f"applied_raw_sha256={sha256(a).hexdigest()}",
    f"candidate_raw_sha256={sha256(b).hexdigest()}",
    f"applied_lf_normalized_sha256={sha256(na).hexdigest()}",
    f"candidate_lf_normalized_sha256={sha256(nb).hexdigest()}",
    f"normalized_match={na == nb}",
    "Raw hashes differ only because git apply emits LF while candidate source has CRLF.",
]
(root/"evidence/g5-patch-apply-check.log").write_text("\n".join(lines)+"\n",encoding="utf-8")
