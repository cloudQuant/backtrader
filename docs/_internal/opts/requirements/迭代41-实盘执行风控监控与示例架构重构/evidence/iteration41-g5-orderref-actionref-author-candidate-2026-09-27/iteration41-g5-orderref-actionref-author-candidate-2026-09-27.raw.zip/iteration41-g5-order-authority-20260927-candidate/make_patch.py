from pathlib import Path
import difflib
root = Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
old = root / "inputs/backtrader/backtrader/stores/ctp_i9_parent_request_builder.py"
new = root / "implementation/main_repo_patch/backtrader/stores/ctp_i9_parent_request_builder.py"
out = root / "implementation/main_repo_patch/G5_ORDERREF_ACTIONREF_AUTHORITY.patch"
diff = difflib.unified_diff(
    old.read_text(encoding="utf-8").splitlines(keepends=True),
    new.read_text(encoding="utf-8").splitlines(keepends=True),
    fromfile="a/backtrader/stores/ctp_i9_parent_request_builder.py",
    tofile="b/backtrader/stores/ctp_i9_parent_request_builder.py",
)
out.write_text("".join(diff), encoding="utf-8", newline="")
