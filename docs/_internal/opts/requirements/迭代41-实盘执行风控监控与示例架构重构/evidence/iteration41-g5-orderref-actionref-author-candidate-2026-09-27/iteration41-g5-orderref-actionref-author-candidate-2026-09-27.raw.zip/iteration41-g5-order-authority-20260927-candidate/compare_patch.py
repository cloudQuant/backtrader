from pathlib import Path
from hashlib import sha256
root=Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
a=(root/"patch-check/backtrader/stores/ctp_i9_parent_request_builder.py").read_bytes()
b=(root/"implementation/main_repo_patch/backtrader/stores/ctp_i9_parent_request_builder.py").read_bytes()
print(len(a),len(b),a.count(b"\r\n"),b.count(b"\r\n"),a.count(b"\n"),b.count(b"\n"))
print(sha256(a.replace(b"\r\n",b"\n")).hexdigest())
print(sha256(b.replace(b"\r\n",b"\n")).hexdigest())
