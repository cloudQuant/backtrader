from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
root=Path(r"D:\temp\iteration41-g5-order-authority-20260927-candidate")
manifest_path=root/"evidence/final-output-manifest.json"
outputs=[]
for path in sorted(root.rglob("*")):
    if not path.is_file() or path==manifest_path:
        continue
    relative=path.relative_to(root)
    if "__pycache__" in relative.parts:
        continue
    data=path.read_bytes()
    outputs.append({"path":relative.as_posix(),"bytes":len(data),"sha256":sha256(data).hexdigest()})
source={
    "format":"iteration41-g5-output-manifest.v1",
    "generated_at_utc":datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "backtrader_source_head":"ad2c142b9a8b42cede85886528c681abdfcb8096",
    "sdk_snapshot_head":"2700cb5454ef4c3d1780eda28b6f33307a860998",
    "frozen_input_manifest_sha256":sha256((root/"frozen-input-manifest.json").read_bytes()).hexdigest(),
    "excluded_paths_note":"Generated __pycache__ bytecode is omitted; frozen source input files are enumerated in frozen-input-manifest.json.",
    "outputs":outputs,
}
manifest_path.write_text(json.dumps(source,indent=2,sort_keys=True)+"\n",encoding="utf-8")
print(f"outputs={len(outputs)}")
print(f"frozen_input_manifest_sha256={source['frozen_input_manifest_sha256']}")
print(f"manifest={manifest_path}")
