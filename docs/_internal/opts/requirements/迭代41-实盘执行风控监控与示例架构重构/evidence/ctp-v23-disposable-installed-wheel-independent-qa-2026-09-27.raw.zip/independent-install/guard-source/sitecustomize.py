import atexit
import importlib.abc
import json
import os
import socket
import sys
from pathlib import Path

_receipt_dir = Path(os.environ['BT_V23_GUARD_RECEIPT_DIR'])
_receipt_dir.mkdir(parents=True, exist_ok=True)
_state = {
    'schema': 'iteration41-v23-offline-test-guard.v1',
    'pid': os.getpid(),
    'network_attempts': [],
    'local_loopback_connects': 0,
    'blocked_native_imports': [],
    'installed_origin': None,
    'installed_version': None,
    'loaded_native_roots': [],
}

class _DenyNativeCtp(importlib.abc.MetaPathFinder):
    _blocked = ('bt_api_ctp', 'ctp', 'thosttraderapi', 'thostmduserapi')
    def find_spec(self, fullname, path=None, target=None):
        if any(fullname == root or fullname.startswith(root + '.') for root in self._blocked):
            _state['blocked_native_imports'].append(fullname)
            raise ModuleNotFoundError('native/provider import blocked by V23 probe guard', name=fullname)
        return None

sys.meta_path.insert(0, _DenyNativeCtp())


def _is_loopback(host):
    if host is None or str(host).lower() == 'localhost':
        return True
    try:
        return __import__('ipaddress').ip_address(str(host).split('%', 1)[0]).is_loopback
    except ValueError:
        return False


def _address_host(address):
    return address[0] if isinstance(address, tuple) and address else address

_orig_connect = socket.socket.connect
_orig_connect_ex = socket.socket.connect_ex
_orig_create_connection = socket.create_connection
_orig_getaddrinfo = socket.getaddrinfo
_orig_sendto = socket.socket.sendto

def _guard_connect(self, address):
    if _is_loopback(_address_host(address)):
        _state['local_loopback_connects'] += 1
        return _orig_connect(self, address)
    _state['network_attempts'].append('socket.connect')
    raise RuntimeError('external network access blocked by V23 probe guard')

def _guard_connect_ex(self, address):
    if _is_loopback(_address_host(address)):
        _state['local_loopback_connects'] += 1
        return _orig_connect_ex(self, address)
    _state['network_attempts'].append('socket.connect_ex')
    raise RuntimeError('external network access blocked by V23 probe guard')

def _guard_getaddrinfo(host, *args, **kwargs):
    if _is_loopback(host):
        return _orig_getaddrinfo(host, *args, **kwargs)
    _state['network_attempts'].append('socket.getaddrinfo')
    raise RuntimeError('external DNS/network access blocked by V23 probe guard')

def _guard_create_connection(address, *args, **kwargs):
    if _is_loopback(_address_host(address)):
        return _orig_create_connection(address, *args, **kwargs)
    _state['network_attempts'].append('socket.create_connection')
    raise RuntimeError('external network access blocked by V23 probe guard')

def _guard_sendto(self, data, address):
    if _is_loopback(_address_host(address)):
        return _orig_sendto(self, data, address)
    _state['network_attempts'].append('socket.sendto')
    raise RuntimeError('external network access blocked by V23 probe guard')

socket.socket.connect = _guard_connect
socket.socket.connect_ex = _guard_connect_ex
socket.getaddrinfo = _guard_getaddrinfo
socket.create_connection = _guard_create_connection
socket.socket.sendto = _guard_sendto

try:
    import bt_api_execution
    from importlib.metadata import version
    _state['installed_origin'] = str(Path(bt_api_execution.__file__).resolve())
    _state['installed_version'] = version('bt_api_execution')
    _purelib = Path(sys.prefix, 'Lib', 'site-packages').resolve()
    if not Path(_state['installed_origin']).is_relative_to(_purelib):
        raise RuntimeError(f'bt_api_execution did not resolve to venv purelib: {_state["installed_origin"]}')
    if _state['installed_version'] != '0.2.3.dev0+audit.v23.f94b924e1e20':
        raise RuntimeError(f'wrong installed distribution version: {_state["installed_version"]}')
except Exception as exc:
    _state['origin_error'] = f'{type(exc).__name__}: {exc}'
    raise

def _write_guard_receipt():
    _state['loaded_native_roots'] = sorted(
        name for name in sys.modules
        if any(name == root or name.startswith(root + '.') for root in ('bt_api_ctp','ctp','thosttraderapi','thostmduserapi'))
    )
    path = _receipt_dir / f'guard-{os.getpid()}.json'
    path.write_text(json.dumps(_state, sort_keys=True, indent=2) + '\n', encoding='utf-8')

atexit.register(_write_guard_receipt)
