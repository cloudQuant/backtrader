from __future__ import annotations
import base64,csv,hashlib,io,json,os,shutil,subprocess,sys,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
qa=Path(__file__).resolve().parent
frozen=Path(r'D:\temp\iteration41-v23-install-probe-20260927-r3')
source=qa/'source-payload'
wheel=qa/'rebuilt-wheelhouse-a'/'bt_api_execution-0.2.3.dev0+audit.v23.f94b924e1e20-py3-none-any.whl'
tools=qa/'frozen-extracted'/'offline-test-wheelhouse'
guard_src=qa/'frozen-extracted'/'probe'/'guard'/'sitecustomize.py'
guard=qa/'guard'; shutil.copytree(qa/'frozen-extracted'/'probe'/'guard',guard,dirs_exist_ok=True)
venv=qa/'venv-clean'; logs=qa/'install-test-logs'; receipts=qa/'guard-receipts'; logs.mkdir(exist_ok=True); receipts.mkdir(exist_ok=True)
python=Path(r'C:\Anaconda3\python.exe'); expected_version='0.2.3.dev0+audit.v23.f94b924e1e20'; expected_wheel='9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591'
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha(p): return sha_bytes(p.read_bytes())
def run(label,cmd,cwd,env,logname=None):
    cp=subprocess.run([str(x) for x in cmd],cwd=str(cwd),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
    log=logs/(logname or (label+'.log')); log.write_text(cp.stdout,encoding='utf-8')
    return cp,log
# All package/install commands are local-only. The V23 guard denies non-loopback socket/DNS/sendto operations; pytest's local Windows asyncio socketpair is explicitly allowed.
env=os.environ.copy()
for k in ('PYTHONPATH','PYTHONHOME','PYTHONUSERBASE','PIP_INDEX_URL','PIP_EXTRA_INDEX_URL'):
    env.pop(k,None)
env.update({'PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_CONFIG_FILE':'NUL','PYTHONUTF8':'1'})
if venv.exists(): raise RuntimeError('refusing existing QA venv')
cp,log=run('venv-create',[python,'-m','venv','--clear',venv],qa,env)
assert cp.returncode==0,cp.stdout
venv_py=venv/'Scripts'/'python.exe'; assert venv_py.is_file()
pyvenv=(venv/'pyvenv.cfg').read_text(encoding='utf-8').lower(); assert 'include-system-site-packages = false' in pyvenv
wheel_names=['pytest-8.2.2-py3-none-any.whl','pytest_asyncio-0.24.0-py3-none-any.whl','pluggy-1.6.0-py3-none-any.whl','packaging-26.3-py3-none-any.whl','iniconfig-2.3.0-py3-none-any.whl','colorama-0.4.6-py2.py3-none-any.whl']
tool_manifest=json.loads((frozen/'offline-test-wheelhouse-manifest.json').read_text(encoding='utf-8'))
expected={x['name']:x for x in tool_manifest['files']}; tool_rows=[]
for n in wheel_names:
    p=tools/n; row=expected[n]; assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],n
    tool_rows.append({'name':n,'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(tool_rows)==6 and sha(wheel)==expected_wheel
install_args=[venv_py,'-m','pip','install','--no-index','--no-deps','--disable-pip-version-check',*[tools/n for n in wheel_names],wheel]
cp,log=run('offline-install',install_args,qa,env); install_result={'returncode':cp.returncode,'log':str(log),'log_sha256':sha(log),'output':cp.stdout}
assert cp.returncode==0,cp.stdout
cp,log=run('pip-check',[venv_py,'-m','pip','check','--disable-pip-version-check'],qa,env); pip_check={'returncode':cp.returncode,'log':str(log),'log_sha256':sha(log),'output':cp.stdout}
assert cp.returncode==0 and 'No broken requirements found' in cp.stdout,cp.stdout
# Fresh, isolated origin probe under the installed final guard.
origin_env=env.copy(); origin_env.update({'BT_V23_GUARD_RECEIPT_DIR':str(receipts),'PYTHONPATH':str(guard)})
code="import importlib.metadata as m,json,pathlib,sys; import bt_api_execution; p=pathlib.Path(bt_api_execution.__file__).resolve(); pure=pathlib.Path(sys.prefix,'Lib','site-packages').resolve(); assert p.is_relative_to(pure); assert m.version('bt_api_execution')=='"+expected_version+"'; assert not any(str(pathlib.Path(x).resolve()).lower().startswith(r'C:\\anaconda3\\lib\\site-packages'.lower()) for x in sys.path if x); print(json.dumps({'python':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'version':m.version('bt_api_execution'),'origin':str(p),'site_packages':str(pure)},indent=2))"
cp,log=run('installed-origin',[venv_py,'-B','-c',code],qa,origin_env); origin={'returncode':cp.returncode,'log':str(log),'log_sha256':sha(log),'stdout':cp.stdout}; assert cp.returncode==0,cp.stdout
origin_json=json.loads(cp.stdout)
# Strict installed RECORD audit (pip-generated .pyc rows may be unhashed; wheel files remain exact).
site=Path(origin_json['site_packages']); dist_info=next(site.glob('bt_api_execution-*.dist-info')); record_path=dist_info/'RECORD'
with zipfile.ZipFile(wheel) as wz:
    wheel_names_set=set(wz.namelist()); wheel_record=next(n for n in wheel_names_set if n.endswith('.dist-info/RECORD'))
    pkg_names={n for n in wheel_names_set if n.startswith('bt_api_execution/')}
rows=list(csv.reader(io.StringIO(record_path.read_text(encoding='utf-8')))); seen=set(); hashed=0; pycs=[]
for row in rows:
    assert len(row)==3
    name,digest,size=row; assert name not in seen
    seen.add(name); path=site.joinpath(*name.split('/')); assert path.is_file(),name; data=path.read_bytes()
    if size: assert int(size)==len(data),name
    if digest:
        alg,encoded=digest.split('=',1); actual=base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode('ascii').rstrip('=')
        assert alg=='sha256' and encoded==actual,name; hashed+=1
    elif name==wheel_record: pass
    elif name.startswith('bt_api_execution/__pycache__/') and name.endswith('.pyc'): pycs.append(name)
    else: raise AssertionError('unexpected unhashed RECORD row '+name)
assert wheel_record in seen and len(seen)==34 and hashed==20 and len(pycs)==13
actual_pkg={p.relative_to(site).as_posix() for p in (site/'bt_api_execution').rglob('*') if p.is_file() and p.suffix!='.pyc' and '__pycache__' not in p.parts}
assert actual_pkg==pkg_names and len(pkg_names)==14
with zipfile.ZipFile(wheel) as wz:
    for name in pkg_names: assert site.joinpath(*name.split('/')).read_bytes()==wz.read(name),name
record_audit={'status':'PASS','wheel_sha256':sha(wheel),'installed_record_rows':len(seen),'hashed_entries_verified':hashed,'unhashed_pip_pyc_entries':len(pycs),'installed_package_files':len(pkg_names),'installed_package_bytes_match_wheel':True,'installed_dist_root':str(site)}
# The source-tree test execution points at the installed wheel; guard blocks external sockets/DNS and native/provider imports.
run_env=env.copy(); run_env['BT_V23_GUARD_RECEIPT_DIR']=str(receipts); run_env['PYTHONPATH']=str(guard)+';'+str(source/'tests'); run_env.pop('PYTEST_DISABLE_PLUGIN_AUTOLOAD',None)
focus=['tests/test_ctp_dispatch_commands.py','tests/test_ctp_native_owner_process_binding_v23.py','tests/test_ctp_process_exit_recovery_v22.py','tests/test_ctp_account_family_owner.py','tests/test_ctp_account_owner_handoff.py','tests/test_ctp_callback_session_owner.py','tests/test_ctp_callback_session_router.py','tests/test_ctp_callback_source_bridge.py']
results=[]
for label,args in [('focused',[venv_py,'-m','pytest','-q','--tb=short',*focus,'--junitxml',logs/'focused.junit.xml']),('full',[venv_py,'-m','pytest','-q','--tb=short','tests','--junitxml',logs/'full.junit.xml'])]:
    cp,log=run(label,args,source,run_env,label+'.log')
    totals=None
    try:
        root=ET.parse(logs/(label+'.junit.xml')).getroot(); suites=[root] if root.tag=='testsuite' else list(root.findall('testsuite'))
        totals={k:sum(int(s.attrib.get(k,'0')) for s in suites) for k in ('tests','failures','errors','skipped')}
    except Exception: pass
    results.append({'label':label,'command':[str(x) for x in args],'cwd':str(source),'returncode':cp.returncode,'log':str(log),'log_sha256':sha(log),'junit':str(logs/(label+'.junit.xml')) if (logs/(label+'.junit.xml')).exists() else None,'junit_sha256':sha(logs/(label+'.junit.xml')) if (logs/(label+'.junit.xml')).exists() else None,'junit_totals':totals})
# All guard receipts from origin+two test subprocesses: no external connect/DNS/sendto attempts and no loaded native roots.
guard_files=sorted(receipts.glob('guard-*.json')); guard_rows=[]
for p in guard_files:
    facts=json.loads(p.read_text(encoding='utf-8')); assert facts.get('installed_version')==expected_version and str(facts.get('installed_origin','')).lower().startswith(str(site/'bt_api_execution').lower())
    assert facts.get('network_attempts')==[] and facts.get('loaded_native_roots')==[]
    guard_rows.append({'path':str(p),'sha256':sha(p),'facts':facts})
assert len(guard_rows)>=3
expected_focus={'tests':188,'failures':0,'errors':0,'skipped':2}; expected_full={'tests':324,'failures':0,'errors':0,'skipped':2}
receipt={'schema':'iteration41-v23-independent-installed-wheel-qa.v1','status':'PASS_LOCAL_OFFLINE_INSTALL_AND_FAKE_TESTS' if results[0]['junit_totals']==expected_focus and results[1]['junit_totals']==expected_full and all(r['returncode']==0 for r in results) else 'CHECK_FAILED','probe_version':expected_version,'frozen_v23_manifest_sha256':'f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330','wheel_sha256':sha(wheel),'wheel_bytes':wheel.stat().st_size,'venv':{'path':str(venv),'python':str(venv_py),'include_system_site_packages':False,'pyvenv_cfg_sha256':sha(venv/'pyvenv.cfg'),'origin_probe':origin_json},'offline_tool_wheels':tool_rows,'offline_install':install_result,'pip_check':pip_check,'installed_record_audit':record_audit,'tests':results,'guard_receipts':guard_rows,'local_loopback_connects':sum(int(x['facts'].get('local_loopback_connects',0)) for x in guard_rows),'external_attempts':sum(len(x['facts'].get('network_attempts',[])) for x in guard_rows),'native_roots_loaded':sorted({root for x in guard_rows for root in x['facts'].get('loaded_native_roots',[])}),'blocked_native_import_attempts':sum(len(x['facts'].get('blocked_native_imports',[])) for x in guard_rows),'guard_scope':'Python socket/connect/connect_ex/getaddrinfo/create_connection/sendto guard; local loopback permitted for asyncio socketpair; external destinations and DNS denied. pip no-index/no-deps; this is not OS firewall attestation.','g1_acceptance':False,'g5_acceptance':False,'provider_or_native_execution':False}
(qa/'independent-install-test-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
