from __future__ import annotations
import base64,csv,hashlib,io,json,os,shutil,subprocess,sys,zipfile
from email.parser import BytesParser
from pathlib import Path
qa=Path(__file__).resolve().parent
seed=qa/'source-payload'
manifest=json.loads((qa/'frozen-receipts'/'V23-PROBE-ARTIFACT-MANIFEST.json').read_text(encoding='utf-8'))
# The full frozen source manifest is embedded in the artifact ZIP and also copied under inputs.
import zipfile as _zip
with _zip.ZipFile(qa/'frozen-probe-artifacts.zip') as z:
    source_manifest=json.loads(z.read('inputs/V23-SOURCE-MANIFEST.json'))
rows=source_manifest['payload_files']
EXPECTED_SOURCE='f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330'
EXPECTED_WHEEL='9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591'
VERSION='0.2.3.dev0+audit.v23.f94b924e1e20'
PYTHON=Path(r'C:\Anaconda3\python.exe')
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha(p): return sha_bytes(p.read_bytes())
def verify_payload(root):
    for r in rows:
        p=root.joinpath(*r['path'].split('/'))
        assert p.is_file() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],r['path']
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}=={r['path'] for r in rows}
assert sha(qa/'frozen-receipts'/'V23-PROBE-ARTIFACT-MANIFEST.json')=='9fa563a58225e715b955a524d2e06a141e78adc684bcb852e70bdf7b56cd9a14'
# Copy the exact 44 frozen payloads into independent source roots.
results=[]
for label in ('A','B'):
    br=qa/f'rebuild-{label}'; src=br/'source'; wheels=qa/f'rebuilt-wheelhouse-{label.lower()}'
    br.mkdir(); wheels.mkdir(); shutil.copytree(seed,src)
    verify_payload(src)
    py=src/'pyproject.toml'; original=py.read_bytes(); original_sha=sha_bytes(original)
    assert original_sha=='a83f75e04cebe9d46b221bc6e46c39db2edab0fc15deceaa31ff2f15703eb3c1'
    assert original.count(b'version = "0.2.0"')==1 and original.count(b'readme = "README.md"')==1
    transformed=original.replace(b'version = "0.2.0"',f'version = "{VERSION}"'.encode('ascii'),1).replace(b'readme = "README.md"',b'readme = "README-v23-owner-binding.md"',1)
    py.write_bytes(transformed)
    overlay={'label':label,'frozen_v23_manifest_sha256':EXPECTED_SOURCE,'source_pyproject_sha256':original_sha,'probe_pyproject_sha256':sha_bytes(transformed),'version_overlay':VERSION,'readme_overlay':'README-v23-owner-binding.md'}
    (br/'metadata-overlay.json').write_text(json.dumps(overlay,indent=2)+'\n',encoding='utf-8')
    env=os.environ.copy()
    for k in ('PYTHONPATH','PYTHONHOME','PYTHONUSERBASE','PIP_INDEX_URL','PIP_EXTRA_INDEX_URL'):
        env.pop(k,None)
    env.update({'SOURCE_DATE_EPOCH':'1790452042','PYTHONHASHSEED':'0','TZ':'UTC','PYTHONUTF8':'1','PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_CONFIG_FILE':'NUL'})
    cmd=[str(PYTHON),'-m','pip','wheel','--no-index','--no-deps','--no-build-isolation','--no-cache-dir','--wheel-dir',str(wheels),str(src)]
    cp=subprocess.run(cmd,cwd=br,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
    log=qa/f'rebuild-{label.lower()}.log'; log.write_text(cp.stdout,encoding='utf-8')
    assert cp.returncode==0,(label,cp.returncode,cp.stdout[-4000:])
    wheel_files=list(wheels.glob('*.whl')); assert len(wheel_files)==1
    wheel=wheel_files[0]; wb=wheel.read_bytes(); wh=sha_bytes(wb)
    assert wheel.name=='bt_api_execution-'+VERSION+'-py3-none-any.whl' and wh==EXPECTED_WHEEL and len(wb)==177694,(wheel.name,wh,len(wb))
    with zipfile.ZipFile(wheel) as z:
        assert z.testzip() is None
        ns=set(z.namelist()); recs=[n for n in ns if n.endswith('.dist-info/RECORD')]; assert len(recs)==1
        seen=set(); hashed=0
        for row in csv.reader(io.StringIO(z.read(recs[0]).decode('utf-8'))):
            path,digest,size=row; assert path not in seen and path in ns
            seen.add(path); content=z.read(path)
            if size: assert int(size)==len(content),path
            if digest:
                algorithm,encoded=digest.split('=',1); actual=base64.urlsafe_b64encode(hashlib.sha256(content).digest()).decode('ascii').rstrip('=')
                assert algorithm=='sha256' and actual==encoded,path; hashed+=1
            else: assert path==recs[0]
        assert seen==ns and len(seen)==18 and hashed==17
        metadata=BytesParser().parsebytes(z.read(next(n for n in ns if n.endswith('.dist-info/METADATA'))))
        assert metadata['Name']=='bt_api_execution' and metadata['Version']==VERSION
        expected_pkg={r['path'].removeprefix('src/') for r in rows if r['path'].startswith('src/bt_api_execution/')}
        actual_pkg={n for n in ns if n.startswith('bt_api_execution/')}
        assert actual_pkg==expected_pkg and len(expected_pkg)==14
        for rel in expected_pkg: assert z.read(rel)==(src/'src'/Path(*rel.split('/'))).read_bytes(),rel
    results.append({'label':label,'source_root':str(src),'wheel_path':str(wheel),'wheel_sha256':wh,'wheel_bytes':len(wb),'build_exit_code':cp.returncode,'build_log':str(log),'build_log_sha256':sha(log),'metadata_overlay_sha256':sha(br/'metadata-overlay.json'),'record_member_count':18,'record_hashed_member_count':17,'package_file_count':14,'version':VERSION,'zip_testzip':'passed'})
assert results[0]['wheel_sha256']==results[1]['wheel_sha256']==EXPECTED_WHEEL
receipt={'schema':'iteration41-v23-independent-wheel-build-receipt.v1','frozen_source_manifest_sha256':EXPECTED_SOURCE,'frozen_payload_count':len(rows),'frozen_payload_bytes':sum(r['bytes'] for r in rows),'probe_version':VERSION,'source_only':True,'builds':results,'byte_identical':True,'wheel_sha256':EXPECTED_WHEEL,'g1_g5_acceptance':False}
(qa/'independent-wheel-build-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
