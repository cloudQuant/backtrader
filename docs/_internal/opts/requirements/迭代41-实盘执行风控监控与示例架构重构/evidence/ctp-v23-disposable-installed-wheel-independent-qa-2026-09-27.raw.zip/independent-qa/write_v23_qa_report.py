import hashlib,json
from pathlib import Path
qa=Path(r'D:\temp\iteration41-v23-install-probe-independent-qa-20260927')
frozen=Path(r'D:\temp\iteration41-v23-install-probe-20260927-r3')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
fr=json.loads((frozen/'V23-OFFLINE-INSTALLED-WHEEL-RECEIPT.json').read_text(encoding='utf-8'))
install=json.loads((qa/'independent-install-test-receipt.json').read_text(encoding='utf-8'))
build=json.loads((qa/'independent-wheel-build-receipt.json').read_text(encoding='utf-8'))
audit=json.loads((qa/'frozen-audit.json').read_text(encoding='utf-8'))
assert install['status']=='PASS_LOCAL_OFFLINE_INSTALL_AND_FAKE_TESTS'
artifacts={
 'frozen_probe_archive':{'path':'frozen-probe-artifacts.zip','sha256':sha(qa/'frozen-probe-artifacts.zip')},
 'frozen_audit':{'path':'frozen-audit.json','sha256':sha(qa/'frozen-audit.json')},
 'independent_build_receipt':{'path':'independent-wheel-build-receipt.json','sha256':sha(qa/'independent-wheel-build-receipt.json')},
 'independent_install_test_receipt':{'path':'independent-install-test-receipt.json','sha256':sha(qa/'independent-install-test-receipt.json')},
 'independent_build_script':{'path':'independent_builds.py','sha256':sha(qa/'independent_builds.py')},
 'independent_install_test_script':{'path':'independent_install_and_test.py','sha256':sha(qa/'independent_install_and_test.py')},
 'focused_log':{'path':'install-test-logs/focused.log','sha256':sha(qa/'install-test-logs'/'focused.log')},
 'focused_junit':{'path':'install-test-logs/focused.junit.xml','sha256':sha(qa/'install-test-logs'/'focused.junit.xml')},
 'full_log':{'path':'install-test-logs/full.log','sha256':sha(qa/'install-test-logs'/'full.log')},
 'full_junit':{'path':'install-test-logs/full.junit.xml','sha256':sha(qa/'install-test-logs'/'full.junit.xml')},
 'pip_check_log':{'path':'install-test-logs/pip-check.log','sha256':sha(qa/'install-test-logs'/'pip-check.log')},
 'initial_failed_guard_log':{'path':'frozen-initial-failure/focused.log','sha256':sha(qa/'frozen-initial-failure'/'focused.log')},
 'initial_failed_guard_junit':{'path':'frozen-initial-failure/focused.junit.xml','sha256':sha(qa/'frozen-initial-failure'/'focused.junit.xml')},
 'qa_report':{'path':'V23-INDEPENDENT-QA.md'},
}
receipt={
 'schema':'iteration41-v23-independent-qa-receipt.v1',
 'date':'2026-09-27',
 'candidate_root':str(frozen),
 'qa_root':str(qa),
 'frozen_source_manifest_sha256':audit['frozen_source_manifest_sha256'],
 'frozen_source_payload_count':44,
 'frozen_source_payload_bytes':1748219,
 'candidate_artifact_manifest_sha256':audit['artifact_manifest_sha256'],
 'candidate_artifact_archive_sha256':audit['artifact_archive_sha256'],
 'candidate_install_receipt_sha256':sha(frozen/'V23-OFFLINE-INSTALLED-WHEEL-RECEIPT.json'),
 'unique_probe_version':'0.2.3.dev0+audit.v23.f94b924e1e20',
 'dual_wheel_sha256':'9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591',
 'independent_two_root_builds':'both rebuilt byte-identical wheel',
 'independent_build_receipt_sha256':sha(qa/'independent-wheel-build-receipt.json'),
 'offline_tool_wheels':'6/6 verified and installed from local wheels',
 'pip_check':'passed: No broken requirements found.',
 'no_system_site_packages_venv':True,
 'installed_origin':'fresh QA venv site-packages; exact disposable version confirmed',
 'installed_record':'PASS: 34 rows, 20 hashed entries, 13 generated unhashed pyc rows; all 14 package files byte-match wheel',
 'independent_focused':'186 passed, 2 skipped',
 'independent_full':'322 passed, 2 skipped',
 'independent_guard':{'external_attempts':0,'native_roots_loaded':[],'blocked_native_import_attempts':4,'loopback_connects':26,'scope':'Python-level guard denies external network/DNS and permits local loopback for Windows asyncio socketpair; pip uses --no-index. Not OS firewall attestation.'},
 'first_failed_guard_attempt':{'preserved':True,'result':fr['initial_harness_attempt']['result'],'log_sha256':fr['initial_harness_attempt']['initial_log_sha256'],'junit_sha256':fr['initial_harness_attempt']['initial_junit_sha256'],'classification':fr['initial_harness_attempt']['classification'],'initial_guard_source_present_in_freeze':False},
 'source_or_pin_changes':False,
 'provider_native_credentials_or_external_network_used':False,
 'g1_acceptance':False,
 'g5_acceptance':False,
 'default_route_changed':False,
 'artifacts_sha256':artifacts,
}
(qa/'V23-INDEPENDENT-QA-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
report=f'''# V23 disposable installed-wheel probe — independent QA

Date: 2026-09-27  
Disposition: **Local offline install/build/test evidence verified. G1 and G5 remain CLOSED; the default route is unchanged.** No source or pin was edited.

## Frozen identity

The V23 source manifest SHA-256 is `{audit['frozen_source_manifest_sha256']}`. Its **44 payload files total 1,748,219 bytes**; all were independently re-hashed from the frozen artifact ZIP and copied into the separate QA source tree. The candidate’s artifact manifest SHA-256 is `{audit['artifact_manifest_sha256']}`; its archive SHA-256 is `{audit['artifact_archive_sha256']}`. All 133 listed archive entries matched size/SHA, the archive contains the two additional self-describing manifest files, and `ZipFile.testzip()` passed.

The wheel is an explicitly disposable probe build with version `0.2.3.dev0+audit.v23.f94b924e1e20`, not a release version. The source manifest’s baseline `distribution_version` is `0.2.0`; the one-time packaging overlay sets the unique probe version and README name only in temporary build roots.

## Independent builds, install, and RECORD

I reconstructed two distinct source roots from the 44 manifest-bound payloads and rebuilt with `pip wheel --no-index --no-deps --no-build-isolation --no-cache-dir` in separate directories. Both builds produced the same expected 177,694-byte wheel:

`9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591`

Both wheel ZIPs passed `testzip`; each contains one RECORD with 18 members and 17 SHA-256-hashed rows. All 14 package members matched the build source bytes. The candidate’s A/B wheel copies and copied input wheel were independently checked against the same hash and RECORD contract.

A fresh QA venv with `include-system-site-packages = false` installed the rebuilt wheel plus all six hash-verified test-tool wheels using local files and `--no-index`. `pip check` passed. Import origin and distribution metadata resolved inside that venv at the disposable version. Installed RECORD verification passed: 34 rows, 20 hashed entries, 13 pip-generated unhashed `.pyc` rows, and all 14 package files byte-matched the wheel.

## Test rerun and network/native guard

The same installed wheel passed the guarded focused set (**186 passed, 2 skipped**) and full package set (**322 passed, 2 skipped**) in the fresh venv. Their JUnit files report 188 and 324 total cases respectively, with zero failures/errors and two skips each.

All three fresh-process guard receipts reported **0 external connect/DNS/sendto attempts and 0 loaded native roots**. Each test process recorded 13 permitted local loopback connects used by Windows asyncio socketpair; the focused+full total was 26. Four attempts to import `bt_api_ctp` were blocked by the guard (two per test run); no native module loaded and no provider executed. The Python guard blocks external addresses/DNS; this is harness evidence, not an OS firewall attestation. `pip` was configured `--no-index`/`--no-deps` and used only the local wheelhouse.

## Preserved first guard failure

The original failed focused attempt is retained byte-for-byte: **180 passed, 2 skipped, 12 setup/teardown errors**. Its JUnit/traceback shows pytest-asyncio’s Windows `ProactorEventLoop` calling `socket.socketpair()`, which connects to a local loopback endpoint; the initial guard rejected that local connect and caused setup/teardown failures. The frozen receipt classifies this as a harness false positive; the corrected guard permits loopback while continuing to block external destinations and DNS. The failed log SHA-256 is `{fr['initial_harness_attempt']['initial_log_sha256']}` and JUnit SHA-256 is `{fr['initial_harness_attempt']['initial_junit_sha256']}`. The old all-connect-deny guard source itself was not included in the frozen archive, so the archived failure log/receipt explain the issue but do not allow re-executing the exact old guard code.

## Scope

This verifies a unique-version, source-only, locally rebuilt and installed wheel and fake/offline package tests. It does not verify production signing/release, installed deployments outside this disposable venv, a real CTP SDK/native extension, provider access, G1/G5 authority, service containment, or a live route. G1/G5 remain closed and the default route was not changed.

## Raw evidence

- Independent receipt: `V23-INDEPENDENT-QA-receipt.json`, SHA-256 `{sha(qa/'V23-INDEPENDENT-QA-receipt.json')}` (its QA report hash is linked below).
- Frozen audit: `frozen-audit.json`, SHA-256 `{sha(qa/'frozen-audit.json')}`.
- Independent wheel build receipt: `independent-wheel-build-receipt.json`, SHA-256 `{sha(qa/'independent-wheel-build-receipt.json')}`.
- Independent install/test receipt: `independent-install-test-receipt.json`, SHA-256 `{sha(qa/'independent-install-test-receipt.json')}`.
- Focused JUnit SHA-256 `{sha(qa/'install-test-logs'/'focused.junit.xml')}`; full JUnit SHA-256 `{sha(qa/'install-test-logs'/'full.junit.xml')}`.
- Frozen first-failure files and the complete original V23 probe archive are included in the raw QA package and independently hashed by its contents sidecar.
'''
(qa/'V23-INDEPENDENT-QA.md').write_text(report,encoding='utf-8')
receipt=json.loads((qa/'V23-INDEPENDENT-QA-receipt.json').read_text(encoding='utf-8'))
receipt['artifacts_sha256']['qa_report']['sha256']=sha(qa/'V23-INDEPENDENT-QA.md')
(qa/'V23-INDEPENDENT-QA-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'qa_report_sha256':sha(qa/'V23-INDEPENDENT-QA.md'),'qa_receipt_sha256':sha(qa/'V23-INDEPENDENT-QA-receipt.json'),'candidate_manifest':audit['frozen_source_manifest_sha256'],'wheel_sha256':receipt['dual_wheel_sha256'],'focused':receipt['independent_focused'],'full':receipt['independent_full']},indent=2))
