# V23 disposable installed-wheel probe — independent QA

Date: 2026-09-27  
Disposition: **Local offline install/build/test evidence verified. G1 and G5 remain CLOSED; the default route is unchanged.** No source or pin was edited.

## Frozen identity

The V23 source manifest SHA-256 is `f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330`. Its **44 payload files total 1,748,219 bytes**; all were independently re-hashed from the frozen artifact ZIP and copied into the separate QA source tree. The candidate’s artifact manifest SHA-256 is `9fa563a58225e715b955a524d2e06a141e78adc684bcb852e70bdf7b56cd9a14`; its archive SHA-256 is `fd2656dc2347daa6badf592764bd856a628c756291cd1c26d575e5dba327a312`. All 133 listed archive entries matched size/SHA, the archive contains the two additional self-describing manifest files, and `ZipFile.testzip()` passed.

The wheel is an explicitly disposable probe build with version `0.2.3.dev0+audit.v23.f94b924e1e20`, not a release version. The source manifest’s baseline `distribution_version` is `0.2.0`; the one-time packaging overlay sets the unique probe version and README name only in temporary build roots.

## Independent builds, install, and RECORD

I reconstructed two distinct source roots from the 44 manifest-bound payloads and rebuilt with `pip wheel --no-index --no-deps --no-build-isolation --no-cache-dir` in separate directories. Both builds produced the same expected 177,694-byte wheel:

`9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591`

Both wheel ZIPs passed `testzip`; each contains one RECORD with 18 members and 17 SHA-256-hashed rows. All 14 package members matched the build source bytes. The candidate’s A/B wheel copies and copied input wheel were independently checked against the same hash and RECORD contract.

A fresh QA venv with `include-system-site-packages = false` installed the rebuilt wheel plus all six hash-verified test-tool wheels using local files and `--no-index`. `pip check` passed. Import origin and distribution metadata resolved inside that venv at the disposable version. Installed RECORD verification passed: 34 rows, 20 hashed entries, 13 pip-generated unhashed `.pyc` rows, and all 14 package files byte-matched the wheel.

## Test rerun and network/native guard

The same installed wheel passed the guarded focused set (**186 passed, 2 skipped**) and full package set (**322 passed, 2 skipped**) in the fresh venv. Their JUnit files report 188 and 324 total cases respectively, with zero failures/errors and two skips each.

All three fresh-process guard receipts reported **0 external connect/DNS/sendto attempts and 0 loaded native roots**. Each test process recorded 13 permitted local loopback connects used by Windows asyncio socketpair; the focused+full total was 26. Four attempts to import `bt_api_ctp` were blocked by the guard (two per test run); no native module loaded and no provider executed. The Python guard blocks external addresses/DNS; this is harness evidence, not an OS firewall attestation. `pip` was configured `--no-index`/`--no-deps` and used only the local wheelhouse.

## Preserved first guard failure

The original failed focused attempt is retained byte-for-byte: **180 passed, 2 skipped, 12 setup/teardown errors**. Its JUnit/traceback shows pytest-asyncio’s Windows `ProactorEventLoop` calling `socket.socketpair()`, which connects to a local loopback endpoint; the initial guard rejected that local connect and caused setup/teardown failures. The frozen receipt classifies this as a harness false positive; the corrected guard permits loopback while continuing to block external destinations and DNS. The failed log SHA-256 is `c8f6c047d66f6844b5272076e0d96e6319ab628de110b9db103b8171cd348be1` and JUnit SHA-256 is `fe83f80a5fa7a417d248f9c96c8a4846498ee284c534154c6d869b04bb0d55d2`. The old all-connect-deny guard source itself was not included in the frozen archive, so the archived failure log/receipt explain the issue but do not allow re-executing the exact old guard code.

## Scope

This verifies a unique-version, source-only, locally rebuilt and installed wheel and fake/offline package tests. It does not verify production signing/release, installed deployments outside this disposable venv, a real CTP SDK/native extension, provider access, G1/G5 authority, service containment, or a live route. G1/G5 remain closed and the default route was not changed.

## Raw evidence

- Independent receipt: `V23-INDEPENDENT-QA-receipt.json`; the raw archive index binds its file hash and all evidence entries.
- Frozen audit: `frozen-audit.json`, SHA-256 `1967a6965ee902ba2153e9ba9c8ada193ea2a4c81a0aa5840b45087b0dbde71d`.
- Independent wheel build receipt: `independent-wheel-build-receipt.json`, SHA-256 `980ccf2e68185e7562d94d415be8f016830c27f22561919f234cae3213856998`.
- Independent install/test receipt: `independent-install-test-receipt.json`, SHA-256 `0a448ac95d0f91580c3ed594c63321887b31378ce935a14463b8539558b17915`.
- Focused JUnit SHA-256 `c2ed8b90e651d54413d67652a542d8551b075a5b90f951ce31f4988b28dc2def`; full JUnit SHA-256 `8594f804bb1c682cb796d6e6fcac8cf81a2ff585bf7cb12c873dbf090d8a8443`.
- Frozen first-failure files and the complete original V23 probe archive are included in the raw QA package and independently hashed by its contents sidecar.
