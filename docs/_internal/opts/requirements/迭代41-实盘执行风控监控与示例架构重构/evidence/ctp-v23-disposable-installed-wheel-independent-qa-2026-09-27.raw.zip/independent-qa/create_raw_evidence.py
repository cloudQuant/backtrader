from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

QA = Path(r'D:\temp\iteration41-v23-install-probe-independent-qa-20260927')
OUT = QA / 'V23-INDEPENDENT-QA-RAW.zip'
INDEX = QA / 'V23-INDEPENDENT-QA-RAW.index.json'
EXPECTED_SOURCE = 'f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330'
EXPECTED_CANDIDATE_ZIP = 'fd2656dc2347daa6badf592764bd856a628c756291cd1c26d575e5dba327a312'
EXPECTED_WHEEL = '9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591'

def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())

candidate_zip = QA / 'frozen-probe-artifacts.zip'
assert sha(candidate_zip) == EXPECTED_CANDIDATE_ZIP
with zipfile.ZipFile(candidate_zip) as zf:
    assert zf.testzip() is None
    source_manifest_bytes = zf.read('inputs/V23-SOURCE-MANIFEST.json')
    source_manifest = json.loads(source_manifest_bytes)
assert sha_bytes(source_manifest_bytes) == EXPECTED_SOURCE
rows = source_manifest['payload_files']
assert len(rows) == 44 and sum(row['bytes'] for row in rows) == 1748219
for row in rows:
    path = QA / 'source-payload' / Path(*row['path'].split('/'))
    assert path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['path']

entries: dict[str, Path | bytes] = {}
def add(dest: str, src: Path) -> None:
    if not src.is_file():
        raise FileNotFoundError(src)
    if dest in entries:
        raise ValueError(f'duplicate archive name {dest}')
    entries[dest] = src
def add_bytes(dest: str, data: bytes) -> None:
    if dest in entries:
        raise ValueError(f'duplicate archive name {dest}')
    entries[dest] = data
def add_tree(prefix: str, directory: Path) -> None:
    for src in sorted(directory.rglob('*')):
        if src.is_file() and '__pycache__' not in src.parts and '.pytest_cache' not in src.parts:
            add(prefix + '/' + src.relative_to(directory).as_posix(), src)
def data(path: Path) -> bytes:
    return path.read_bytes() if isinstance(path, Path) else path
def entry_hash(path: Path | bytes) -> str:
    return sha(path) if isinstance(path, Path) else sha_bytes(path)
def entry_size(path: Path | bytes) -> int:
    return path.stat().st_size if isinstance(path, Path) else len(path)

add('frozen-input/V23-PROBE-ARTIFACTS.zip', candidate_zip)
add('frozen-input/frozen-audit.json', QA / 'frozen-audit.json')
add_tree('frozen-input/receipts', QA / 'frozen-receipts')
add_tree('frozen-input/first-failed-guard', QA / 'frozen-initial-failure')
add_bytes('frozen-input/V23-SOURCE-MANIFEST.json', source_manifest_bytes)
for row in rows:
    rel = row['path']
    add('frozen-input/source-payload/' + rel, QA / 'source-payload' / Path(*rel.split('/')))

add('independent-build/independent_builds.py', QA / 'independent_builds.py')
add('independent-build/receipt.json', QA / 'independent-wheel-build-receipt.json')
add('independent-build/console.log', QA / 'independent-builds-console.log')
add('independent-build/exit.txt', QA / 'independent-builds.exit')
for label in ('a', 'b'):
    add(f'independent-build/root-{label}-build.log', QA / f'rebuild-{label}.log')
    add(f'independent-build/root-{label}-metadata-overlay.json', QA / f'rebuild-{label.upper()}' / 'metadata-overlay.json')
    wheel_dir = QA / f'rebuilt-wheelhouse-{label}'
    wheels = sorted(wheel_dir.glob('*.whl'))
    assert len(wheels) == 1 and sha(wheels[0]) == EXPECTED_WHEEL
    add(f'independent-build/root-{label}-wheel/{wheels[0].name}', wheels[0])

add('independent-install/independent_install_and_test.py', QA / 'independent_install_and_test.py')
add('independent-install/receipt.json', QA / 'independent-install-test-receipt.json')
add('independent-install/console.log', QA / 'install-test-console.log')
add('independent-install/exit.txt', QA / 'install-test.exit')
add_tree('independent-install/logs', QA / 'install-test-logs')
add_tree('independent-install/guard-source', QA / 'guard')
add_tree('independent-install/guard-receipts', QA / 'guard-receipts')
add('independent-qa/report.md', QA / 'V23-INDEPENDENT-QA.md')
add('independent-qa/receipt.json', QA / 'V23-INDEPENDENT-QA-receipt.json')
add('independent-qa/frozen-audit.json', QA / 'frozen-audit.json')
add('independent-qa/create_raw_evidence.py', QA / 'create_raw_evidence.py')
add('independent-qa/write_v23_qa_report.py', QA / 'write_v23_qa_report.py')

content_rows = [
    {'path': name, 'bytes': entry_size(path), 'sha256': entry_hash(path)}
    for name, path in sorted(entries.items())
]
tmp_zip = OUT.with_suffix('.zip.tmp')
with zipfile.ZipFile(tmp_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for name, path in sorted(entries.items()):
        zf.writestr(name, data(path))
    content_index = {
        'schema': 'iteration41-v23-independent-qa-raw-archive-content-index.v1',
        'entries': content_rows,
    }
    zf.writestr('RAW-CONTENTS.index.json', json.dumps(content_index, indent=2, sort_keys=True) + '\n')
tmp_zip.replace(OUT)
with zipfile.ZipFile(OUT) as zf:
    assert zf.testzip() is None
    names = set(zf.namelist())
    assert len(names) == len(entries) + 1
    inner = json.loads(zf.read('RAW-CONTENTS.index.json'))
    assert len(inner['entries']) == len(entries)
    for row in inner['entries']:
        raw = zf.read(row['path'])
        assert len(raw) == row['bytes'] and sha_bytes(raw) == row['sha256'], row['path']
    artifact_manifest = json.loads(zf.read('frozen-input/receipts/V23-PROBE-ARTIFACT-MANIFEST.json'))
    assert artifact_manifest['entry_count'] == 133
    assert artifact_manifest['frozen_v23_manifest_sha256'] == EXPECTED_SOURCE
    assert artifact_manifest['dual_wheel_sha256'] == EXPECTED_WHEEL

external_index = {
    'schema': 'iteration41-v23-independent-qa-raw-archive-index.v1',
    'archive': OUT.name,
    'archive_bytes': OUT.stat().st_size,
    'archive_sha256': sha(OUT),
    'testzip': 'passed',
    'entry_count_excluding_internal_index': len(entries),
    'internal_content_index': 'RAW-CONTENTS.index.json',
    'frozen_source_manifest_sha256': EXPECTED_SOURCE,
    'candidate_probe_archive_sha256': EXPECTED_CANDIDATE_ZIP,
    'probe_wheel_sha256': EXPECTED_WHEEL,
    'g1_acceptance': False,
    'g5_acceptance': False,
    'default_route_changed': False,
}
INDEX.write_text(json.dumps(external_index, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(external_index, indent=2, sort_keys=True))
