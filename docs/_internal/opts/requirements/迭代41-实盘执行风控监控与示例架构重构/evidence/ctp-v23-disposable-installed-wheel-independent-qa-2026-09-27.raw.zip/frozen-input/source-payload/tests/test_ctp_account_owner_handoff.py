from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass
from decimal import Decimal

import pytest
from v23_native_owner_fake import FakeNativeOwnerProcessAttestor

from bt_api_execution import (
    CtpAccountCloseDrainProofV1,
    CtpCallbackSessionStoreAdapter,
    CtpVerifiedAccountCloseDrainV1,
    ExecutionScope,
    ExecutionState,
    InvalidStateTransition,
    OrderIntent,
    OrderType,
    PositionEffect,
    Side,
    SqliteExecutionStore,
    WriterLeaseUnavailable,
    payload_sha256,
)

_TAGS = {
    "source_instance_id": "source-instance-01",
    "native_client_epoch": "a" * 32,
    "native_api_source_id": "api-source-01",
    "native_spi_source_id": "spi-source-01",
    "native_api_generation": 1,
    "source_connection_generation": 0,
}


class CtpTraderCallbackIngressRecordV2:
    def __init__(self, payload):
        self._payload = payload

    def to_payload(self):
        return dict(self._payload)


@dataclass(frozen=True)
class _SourceTags:
    source_instance_id: str = _TAGS["source_instance_id"]
    native_client_epoch: str = _TAGS["native_client_epoch"]
    native_api_source_id: str = _TAGS["native_api_source_id"]
    native_spi_source_id: str = _TAGS["native_spi_source_id"]
    native_api_generation: int = _TAGS["native_api_generation"]
    connection_generation: int = _TAGS["source_connection_generation"]


@dataclass(frozen=True)
class _LoginObservation:
    broker_id: str = "broker"
    user_id: str = "user"
    trading_day: str = "20260925"
    connection_generation: int = 1
    request_id: int = 17


class _OfflineVerifier:
    """Deterministic test port only; it does not authenticate a deployed issuer."""

    verifier_id = "offline-test-verifier"
    issuer_id = "offline-test-issuer"
    audience = "offline-test-store"

    def __init__(self, *, wrong_digest=False):
        self.calls = 0
        self.wrong_digest = wrong_digest

    def verify(self, proof, expected, *, now_ns):
        self.calls += 1
        assert expected["proof_payload"] == proof.to_payload()
        return CtpVerifiedAccountCloseDrainV1(
            proof_id=proof.proof_id,
            proof_sha256=("0" * 64 if self.wrong_digest else payload_sha256(proof.to_payload())),
            verifier_id=self.verifier_id,
            observed_at_ns=now_ns,
        )


def _scope(environment="simulation", account_name="acct-A", day="20260925"):
    account_ref = "ctp-account-ref.v1:" + hashlib.sha256(account_name.encode()).hexdigest()
    return ExecutionScope("ctp", environment, account_ref, "strategy.handoff", day)


def _callback_record(
    owner_id,
    name,
    sequence,
    *,
    generation,
    fields=(),
    request_id=None,
    phase="PRE_LOGIN",
    callback_class=None,
):
    named_args = []
    if name.startswith("OnRsp"):
        names = ("pRspAuthenticateField", "pRspInfo", "nRequestID", "bIsLast")
        named_args = [
            {
                "argument_slot": index,
                "name": arg_name,
                "present": True,
                "scalar_captured": index >= 2,
                "value": (request_id if index == 2 else True) if index >= 2 else None,
            }
            for index, arg_name in enumerate(names)
        ]
        callback_class = callback_class or "PRE_LOGIN"
    elif name == "OnFrontConnected":
        callback_class = callback_class or "PRE_LOGIN"
    else:
        named_args = [
            {
                "argument_slot": 0,
                "name": "pInstrumentStatus",
                "present": True,
                "scalar_captured": False,
                "value": None,
            }
        ]
        callback_class = callback_class or "AUDIT_INFORMATIONAL"
    flattened_fields = [
        {
            "argument_slot": slot,
            "field_name": field_name,
            "present": True,
            "scalar_captured": True,
            "value": value,
        }
        for slot, field_name, value in fields
    ]
    unsigned = {
        "schema": "ctp_trader_callback_ingress.v2",
        "owner_intent_id": owner_id,
        "callback_name": name,
        "callback_class": callback_class,
        "phase": phase,
        **_TAGS,
        "connection_generation": generation,
        "sequence": sequence,
        "monotonic_ns": sequence + 100,
        "named_args": named_args,
        "flattened_fields": flattened_fields,
        "capture_complete": True,
        "missing_getters": [],
    }
    digest = hashlib.sha256(
        json.dumps(unsigned, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()
    return CtpTraderCallbackIngressRecordV2({**unsigned, "digest": digest})


def _setup(tmp_path, *, verifier=None):
    scope = _scope()
    store = SqliteExecutionStore.open_ctp_account_store(
        tmp_path / "account.sqlite3", scope, ctp_close_drain_verifier=verifier
    )
    store._ctp_native_owner_process_attestor = FakeNativeOwnerProcessAttestor()
    family_owner = store.acquire_ctp_account_family_owner(scope)
    lease = store.acquire_or_renew_lease(
        scope,
        "offline-handoff-writer",
        ttl_ns=60_000_000_000,
        ctp_account_family_owner=family_owner,
    )
    callback_owner = store.create_ctp_callback_session_owner(scope, writer_lease=lease)
    adapter = CtpCallbackSessionStoreAdapter(
        store,
        scope,
        callback_owner,
        lease,
        lambda **kwargs: kwargs,
        CtpTraderCallbackIngressRecordV2,
    )
    assert adapter is not None
    records = [
        _callback_record(callback_owner.owner_intent_id, "OnFrontConnected", 1, generation=0),
        _callback_record(
            callback_owner.owner_intent_id,
            "OnRspAuthenticate",
            2,
            generation=1,
            request_id=16,
            fields=((0, "BrokerID", "broker"), (0, "UserID", "user"), (1, "ErrorID", 0)),
        ),
        _callback_record(
            callback_owner.owner_intent_id,
            "OnRspUserLogin",
            3,
            generation=1,
            request_id=17,
            fields=(
                (0, "BrokerID", "broker"),
                (0, "UserID", "user"),
                (0, "TradingDay", "20260925"),
                (0, "FrontID", 31),
                (0, "SessionID", 41),
                (1, "ErrorID", 0),
            ),
        ),
    ]
    for record in records:
        store.append_ctp_callback_ingress(callback_owner, record)
    binding = store.bind_ctp_callback_session(
        scope, callback_owner, _LoginObservation(), _SourceTags(), 3, writer_lease=lease
    )
    return store, scope, family_owner, lease, callback_owner, binding


def _proof(store, scope, target, family_owner, callback_owner, binding, *, sequence=3):
    now = time.time_ns()
    tags = (
        binding.source_instance_id,
        binding.native_client_epoch,
        binding.native_api_source_id,
        binding.native_spi_source_id,
        binding.native_api_generation,
        binding.source_connection_generation,
    )
    return CtpAccountCloseDrainProofV1(
        proof_id=uuid.uuid4().hex,
        issuer_id=_OfflineVerifier.issuer_id,
        audience=_OfflineVerifier.audience,
        journal_incarnation_id=store.journal_source_identity()["generation"],
        account_ref=scope.account_ref,
        family_key=family_owner.family_key,
        from_owner_intent_id=family_owner.owner_intent_id,
        from_generation=family_owner.generation,
        from_account_key=scope.account_key,
        from_scope_key=scope.key,
        from_environment=scope.environment,
        from_trading_day=scope.trading_day,
        callback_owner_intent_id=callback_owner.owner_intent_id,
        session_binding_sha256=binding.session_binding_sha256,
        source_tags=tags,
        final_source_sequence=sequence,
        target_account_key=target.account_key,
        target_scope_key=target.key,
        target_environment=target.environment,
        target_trading_day=target.trading_day,
        issued_at_ns=now - 1_000_000,
        expires_at_ns=now + 2_000_000_000,
        native_released=True,
        join_required=True,
        join_completed=True,
        thread_alive=False,
        timed_out=False,
        callbacks_sealed=True,
        callback_queue_drained=True,
        signature="offline-fake-signature",
    )


def _handoff(store, scope, family, lease, callback_owner, proof, target):
    return store.complete_ctp_account_owner_handoff(
        scope,
        target,
        family_owner=family,
        callback_owner=callback_owner,
        writer_lease=lease,
        proof=proof,
    )


@pytest.mark.unit
def test_clean_close_handoff_is_atomic_one_shot_and_fences_old_generation(tmp_path):
    verifier = _OfflineVerifier()
    store, scope, family, lease, callback_owner, binding = _setup(tmp_path, verifier=verifier)
    target = _scope("live", day="20260926")
    proof = _proof(store, scope, target, family, callback_owner, binding)
    try:
        receipt = _handoff(store, scope, family, lease, callback_owner, proof, target)
        assert receipt.from_generation == 1 and receipt.to_generation == 2
        assert receipt.target_environment == "live"
        assert verifier.calls == 1
        assert store.read_ctp_account_owner_handoff_receipt(proof.proof_id, target) == receipt
        assert store.read_ctp_dispatch_command(target, "not-yet-created") is None
        with pytest.raises(
            InvalidStateTransition, match="outside the current account owner generation"
        ):
            store.read_ctp_dispatch_command(scope, "historical-scope-read")

        # Lost response / retry reads the one committed receipt, not a second
        # verifier decision or another owner generation.
        assert _handoff(store, scope, family, lease, callback_owner, proof, target) == receipt
        assert verifier.calls == 1
        generations = store._connection.execute(
            "SELECT generation, owner_state FROM ctp_account_family_owner_generations "
            "ORDER BY generation"
        ).fetchall()
        assert [tuple(row) for row in generations] == [(1, "CLOSED"), (2, "AVAILABLE")]
        lease_row = store._connection.execute(
            "SELECT expires_at_ns FROM execution_writer_leases WHERE scope_key = ?",
            (lease.scope_key,),
        ).fetchone()
        assert lease_row["expires_at_ns"] == 0

        late = _callback_record(
            callback_owner.owner_intent_id,
            "OnRtnInstrumentStatus",
            4,
            generation=1,
            phase="ACTIVE",
            callback_class="AUDIT_INFORMATIONAL",
        )
        with pytest.raises(Exception, match="not live"):
            store.append_ctp_callback_ingress(callback_owner, late)

        db_path = store.path
        store.close()

        # A process that lost the committed response can recover only the exact
        # durable receipt. The restarted Store has no trusted verifier, so it
        # cannot mint or consume a second proof.
        reopened = SqliteExecutionStore.open_ctp_account_store(db_path, target)
        try:
            assert (
                reopened.read_ctp_account_owner_handoff_receipt(proof.proof_id, target) == receipt
            )
            assert (
                _handoff(reopened, scope, family, lease, callback_owner, proof, target) == receipt
            )
            successor = reopened.acquire_ctp_account_family_owner(target)
            assert successor.generation == 2
            next_lease = reopened.acquire_or_renew_lease(
                target,
                "offline-handoff-writer-next",
                ttl_ns=60_000_000_000,
                ctp_account_family_owner=successor,
            )
            reopened._ctp_native_owner_process_attestor = FakeNativeOwnerProcessAttestor()
            next_owner = reopened.create_ctp_callback_session_owner(target, writer_lease=next_lease)
            assert next_owner.account_key == target.account_key
        finally:
            reopened.close()

        # Once claimed, a process crash cannot reconstruct or reopen that owner.
        with pytest.raises(Exception, match="owner generation does not match"):
            SqliteExecutionStore.open_ctp_account_store(db_path, target)
    finally:
        store.close()


@pytest.mark.unit
def test_handoff_fails_closed_without_verifier_and_on_cross_account_target(tmp_path):
    store, scope, family, lease, callback_owner, binding = _setup(tmp_path)
    target = _scope("live", day="20260926")
    proof = _proof(store, scope, target, family, callback_owner, binding)
    try:
        with pytest.raises(InvalidStateTransition, match="verifier is unavailable"):
            _handoff(store, scope, family, lease, callback_owner, proof, target)
        other_account = _scope("live", account_name="acct-B", day="20260926")
        with pytest.raises(Exception, match="same canonical account"):
            _handoff(store, scope, family, lease, callback_owner, proof, other_account)
        row = store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owner_generations WHERE generation = 1"
        ).fetchone()
        assert row["owner_state"] == "ACTIVE"
    finally:
        store.close()


@pytest.mark.unit
def test_handoff_rejects_unresolved_execution_and_callback_gap_before_verifier(tmp_path):
    verifier = _OfflineVerifier()
    store, scope, family, lease, callback_owner, binding = _setup(tmp_path, verifier=verifier)
    target = _scope("live", day="20260926")
    proof = _proof(store, scope, target, family, callback_owner, binding)
    try:
        intent = OrderIntent(
            intent_id="pending-intent",
            scope=scope,
            signal_id="signal-1",
            instrument="rb2701",
            side=Side.BUY,
            position_effect=PositionEffect.OPEN,
            order_type=OrderType.LIMIT,
            quantity=Decimal("1"),
            price=Decimal("100"),
        )
        pending = store.admit_intent(intent, writer_lease=lease)
        assert pending.state is ExecutionState.PENDING_ADMISSION
        with pytest.raises(InvalidStateTransition, match="unresolved or UNKNOWN"):
            _handoff(store, scope, family, lease, callback_owner, proof, target)
        assert verifier.calls == 0
    finally:
        store.close()

    verifier = _OfflineVerifier()
    (tmp_path / "callback-gap").mkdir()
    store, scope, family, lease, callback_owner, binding = _setup(
        tmp_path / "callback-gap", verifier=verifier
    )
    target = _scope("live", day="20260926")
    late = _callback_record(
        callback_owner.owner_intent_id,
        "OnRtnInstrumentStatus",
        4,
        generation=1,
        phase="ACTIVE",
        callback_class="AUDIT_INFORMATIONAL",
    )
    store.append_ctp_callback_ingress(callback_owner, late)
    proof = _proof(store, scope, target, family, callback_owner, binding, sequence=4)
    try:
        with pytest.raises(InvalidStateTransition, match="source prefix"):
            _handoff(store, scope, family, lease, callback_owner, proof, target)
        assert verifier.calls == 0
    finally:
        store.close()


@pytest.mark.unit
def test_handoff_rechecks_writer_fence_and_verifier_result(tmp_path):
    verifier = _OfflineVerifier()
    store, scope, family, lease, callback_owner, binding = _setup(tmp_path, verifier=verifier)
    target = _scope("live", day="20260926")
    proof = _proof(store, scope, target, family, callback_owner, binding)
    try:
        assert store.release_lease(scope, lease.owner_id, fencing_token=lease.fencing_token)
        with pytest.raises(WriterLeaseUnavailable):
            _handoff(store, scope, family, lease, callback_owner, proof, target)
        row = store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owner_generations WHERE generation = 1"
        ).fetchone()
        assert row["owner_state"] == "ACTIVE"
    finally:
        store.close()

    verifier = _OfflineVerifier(wrong_digest=True)
    (tmp_path / "bad-verifier").mkdir()
    store, scope, family, lease, callback_owner, binding = _setup(
        tmp_path / "bad-verifier", verifier=verifier
    )
    target = _scope("live", day="20260926")
    proof = _proof(store, scope, target, family, callback_owner, binding)
    try:
        with pytest.raises(InvalidStateTransition, match="stale or not verified"):
            _handoff(store, scope, family, lease, callback_owner, proof, target)
        row = store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owner_generations WHERE generation = 1"
        ).fetchone()
        assert row["owner_state"] == "ACTIVE"
    finally:
        store.close()
