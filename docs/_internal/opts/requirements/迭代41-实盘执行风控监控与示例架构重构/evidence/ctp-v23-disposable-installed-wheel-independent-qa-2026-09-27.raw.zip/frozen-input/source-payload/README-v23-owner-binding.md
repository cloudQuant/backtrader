# V23 G1 native-owner process-binding candidate

This is an isolated, source-only `bt_api_execution` candidate based directly on the frozen V22 candidate manifest (`V22-CANDIDATE-MANIFEST.json`, SHA-256 `8244038ab975f30de6c0ba56c140f033ddd5b5ce5fb3cabc9e60abb7bf24066d`). V22 itself is based on the R3r3 + V21 owner-handoff composite manifest with SHA-256 `00577665667a33c9a7d62d331c0cad99b0b660790d0b475d0bd8c1b6caa6e2dd`.

V23 advances the SQLite schema to 23 and binds an owner process generation to the journal, account/scope, account-family owner/fence, callback owner, supervisor/Job identifiers, PID plus process creation time, Windows session, owner SID digest, deployment/artifact digests, and one attestor proof. The binding row is immutable and must match before a session-bound native claim. V22 claims that predate OS process binding migrate to `UNKNOWN` and poison the callback owner/account family; they are never replayed.

The default process attestor is absent: owner creation and native session claims fail closed. Tests inject a fake attestor and prove local transaction/schema behavior only. Python-private protocols and injected policy are not an OS security boundary and do not establish G5. The process-exit verifier is also absent by default.

The generic local `claim_ctp_dispatch_command()` path can persist a `CLAIMED` ledger row with `native_call_inflight=0`, but the candidate's only sender consumer never passes that claim to its injected sender. A queued READY V2 command sent to `dispatch_managed_command()` without the native-owner adapter is atomically moved to `UNKNOWN` and its owner/family poisoned before any sender call. No native request/send API is present in this package; the candidate is not wired to a production route.

Verification is source-only with CPython 3.11.5 / pytest 8.2.2. Full package: 322 passed, 2 skipped because the separate `bt_api_ctp` SDK package is absent; the skips are not passes. No wheel was built or installed. No CTP native SDK, provider, credentials, private configuration, network, or real account was accessed.
