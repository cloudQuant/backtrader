from __future__ import annotations

import hashlib
import importlib.util
import json
import sqlite3
import sys
import threading
import time
import types
from dataclasses import dataclass, replace
from hashlib import sha256
from pathlib import Path

import pytest

from bt_api_execution import (
    CtpCallbackSessionBindingV1,
    CtpCallbackSessionStoreAdapter,
    CtpDispatchAuthority,
    CtpOrderRefLegacyMapping,
    CtpOrderRefSeedProof,
    DurableStoreError,
    ExecutionScope,
    InvalidStateTransition,
    SqliteExecutionStore,
    payload_sha256,
)
from bt_api_execution.store import (
    _CtpNativeOwnerProcessBindingRequest,
    _CtpVerifiedNativeOwnerProcessBinding,
    _CtpVerifiedProcessExitCapability,
)


def _scope() -> ExecutionScope:
    account_ref = "ctp-account-ref.v1:" + sha256(b"v22-process-exit-account").hexdigest()
    return ExecutionScope("ctp", "simulation", account_ref, "strategy.v22", "20260925")


def _runtime_order_id(intent_id: str) -> str:
    return "bt-managed-v1:" + sha256(intent_id.encode("ascii")).hexdigest()


def _seed_proof(scope: ExecutionScope) -> CtpOrderRefSeedProof:
    legacy_scope = ExecutionScope(
        "ctp", "simulation", scope.account_ref, "strategy.legacy", "20260924"
    )
    source_digests = (
        ("backtrader_prototype", sha256(b"synthetic prototype inventory").hexdigest()),
        ("sdk_jsonl", sha256(b"synthetic empty callback inventory").hexdigest()),
    )
    return CtpOrderRefSeedProof(
        trading_day=scope.trading_day,
        native_max_order_ref="000000000010",
        legacy_ledger_max_order_ref="000000000012",
        legacy_ledger_sha256=payload_sha256(dict(source_digests)),
        account_key=scope.account_key,
        scope_key=scope.key,
        session_generation_id="ctp-native-v2:" + "a" * 32 + ":1:1:31:41",
        native_front_id=31,
        native_session_id=41,
        existing_native_order_refs=("000000000009", "000000000010"),
        legacy_source_sha256=source_digests,
        legacy_mappings=(
            CtpOrderRefLegacyMapping(
                source_name="backtrader_prototype",
                account_key=scope.account_key,
                trading_day="20260924",
                scope_key=legacy_scope.key,
                managed_intent_id="legacy-managed-intent",
                runtime_order_id="legacy-runtime-order-1",
                order_ref="000000000012",
            ),
        ),
    )


class _IngressRecord:
    def __init__(self, payload):
        self._payload = dict(payload)

    def to_payload(self):
        return dict(self._payload)


@dataclass(frozen=True)
class _SourceTags:
    source_instance_id: str = "source-instance-v22"
    native_client_epoch: str = "a" * 32
    native_api_source_id: str = "api-source-v22"
    native_spi_source_id: str = "spi-source-v22"
    native_api_generation: int = 1
    connection_generation: int = 0


@dataclass(frozen=True)
class _LoginObservation:
    broker_id: str = "broker"
    user_id: str = "user"
    trading_day: str = "20260925"
    connection_generation: int = 1
    request_id: int = 17


def _callback_record(owner_id: str, name: str, sequence: int, *, generation: int, fields=(), request_id=None):
    named_args = []
    if name.startswith("OnRsp"):
        names = ("pRspAuthenticateField", "pRspInfo", "nRequestID", "bIsLast")
        named_args = [
            {
                "argument_slot": index,
                "name": arg_name,
                "present": True,
                "scalar_captured": index >= 2,
                "value": (request_id if index == 2 else True) if index >= 2 else None,
            }
            for index, arg_name in enumerate(names)
        ]
    flattened_fields = [
        {
            "argument_slot": slot,
            "field_name": field_name,
            "present": True,
            "scalar_captured": True,
            "value": value,
        }
        for slot, field_name, value in fields
    ]
    unsigned = {
        "schema": "ctp_trader_callback_ingress.v2",
        "owner_intent_id": owner_id,
        "callback_name": name,
        "callback_class": "PRE_LOGIN",
        "phase": "PRE_LOGIN",
        "source_instance_id": "source-instance-v22",
        "native_client_epoch": "a" * 32,
        "native_api_source_id": "api-source-v22",
        "native_spi_source_id": "spi-source-v22",
        "native_api_generation": 1,
        "source_connection_generation": 0,
        "connection_generation": generation,
        "sequence": sequence,
        "monotonic_ns": sequence + 100,
        "named_args": named_args,
        "flattened_fields": flattened_fields,
        "capture_complete": True,
        "missing_getters": [],
    }
    digest = hashlib.sha256(
        json.dumps(
            unsigned,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()
    return _IngressRecord({**unsigned, "digest": digest})


class _FakeAuthority:
    def verify_action(self, command, *, now_ns):
        return CtpDispatchAuthority(
            authority_type="ctp_dispatch_authority.v1",
            command_binding_sha256=command.authority_binding_sha256,
            approval_use_id=command.approval_use_id,
            approval_digest=command.approval_digest,
            source_digest_sha256=sha256(b"synthetic authority input").hexdigest(),
            verifier_id="v22-fake-authority.v1",
            verified_at_ns=now_ns,
            expires_at_ns=now_ns + 5_000_000_000,
        )


class _FakeProcessExitVerifier:
    verifier_id = "v22-fake-process-exit-verifier.v1"

    def __init__(self, *, tamper=None, entered=None, release=None):
        self.tamper = tamper
        self.entered = entered
        self.release = release
        self.calls = []

    def verify_process_exit(self, request):
        self.calls.append(request)
        if self.entered is not None:
            self.entered.set()
        if self.release is not None and not self.release.wait(timeout=5):
            raise TimeoutError("fake test verifier release timed out")
        capability = _CtpVerifiedProcessExitCapability(
            challenge=request.challenge,
            journal_incarnation_id=request.journal_incarnation_id,
            account_key=request.account_key,
            family_key=request.family_key,
            family_generation=request.family_generation,
            family_owner_intent_id=request.family_owner_intent_id,
            callback_owner_intent_id=request.callback_owner_intent_id,
            writer_owner_id=request.writer_owner_id,
            writer_fencing_token=request.writer_fencing_token,
            session_generation_id=request.session_generation_id,
            process_generation_id=request.process_generation_id,
            native_owner_binding_sha256=request.native_owner_binding_sha256,
            claimed_command_ids=request.claimed_command_ids,
            claim_set_sha256=request.claim_set_sha256,
            verifier_id=self.verifier_id,
            proof_id="c" * 32,
            supervisor_id="d" * 32,
            job_id="e" * 32,
            process_id=4812,
            process_creation_time_100ns=9_000_001,
            process_exit_code=1,
            process_exit_observed=True,
            job_empty_observed=True,
            controls_released=True,
            proof_sha256="0" * 64,
        )
        if self.tamper is not None:
            field_name, value = self.tamper
            capability = replace(capability, **{field_name: value})
        proof = hashlib.sha256(
            json.dumps(
                SqliteExecutionStore._ctp_process_exit_capability_payload(capability),
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode("utf-8")
        ).hexdigest()
        return replace(capability, proof_sha256=proof)


class _FakeNativeOwnerProcessAttestor:
    """Offline-only fake; its Python injection is not a service trust boundary."""

    attestor_id = "v23-fake-g1-process-attestor.v1"

    def attest_owner_process(self, request: _CtpNativeOwnerProcessBindingRequest):
        proof = _CtpVerifiedNativeOwnerProcessBinding(
            challenge=request.challenge,
            journal_incarnation_id=request.journal_incarnation_id,
            account_key=request.account_key,
            scope_key=request.scope_key,
            family_key=request.family_key,
            family_generation=request.family_generation,
            family_owner_intent_id=request.family_owner_intent_id,
            callback_owner_intent_id=request.callback_owner_intent_id,
            writer_owner_id=request.writer_owner_id,
            writer_fencing_token=request.writer_fencing_token,
            process_generation_id=request.process_generation_id,
            supervisor_instance_id="d" * 32,
            job_instance_id="e" * 32,
            process_id=4812,
            process_creation_time_100ns=9_000_001,
            windows_session_id=0,
            owner_sid_sha256=sha256(b"synthetic owner SID").hexdigest(),
            deployment_manifest_sha256=sha256(b"synthetic deployment manifest").hexdigest(),
            artifact_digest_sha256=sha256(b"synthetic owner artifact").hexdigest(),
            observed_at_ns=time.time_ns(),
            expires_at_ns=request.expires_at_ns,
            attestor_id=self.attestor_id,
            proof_id="c" * 32,
            proof_sha256="0" * 64,
        )
        digest = hashlib.sha256(
            json.dumps(
                SqliteExecutionStore._ctp_native_owner_process_binding_proof_payload(proof),
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode("utf-8")
        ).hexdigest()
        return replace(proof, proof_sha256=digest)


def _active_fixture(
    tmp_path: Path, *, verifier=None, command_count: int = 1, process_attestor=None
):
    scope = _scope()
    store = SqliteExecutionStore(
        tmp_path / "v22-process-exit.sqlite3",
        _ctp_process_exit_verifier=verifier,
        _ctp_native_owner_process_attestor=(
            process_attestor or _FakeNativeOwnerProcessAttestor()
        ),
    )
    store._bind_new_ctp_account_store_identity(scope, store._ctp_account_family_key(scope))
    family_owner = store.acquire_ctp_account_family_owner(scope)
    lease = store.acquire_or_renew_lease(
        scope,
        "v22-writer",
        ttl_ns=60_000_000_000,
        ctp_account_family_owner=family_owner,
    )
    first = store.seed_ctp_order_ref_and_reserve_identity(
        scope,
        _seed_proof(scope),
        "v22-intent-1",
        _runtime_order_id("v22-intent-1"),
        writer_lease=lease,
    )
    owner = store.create_ctp_callback_session_owner(scope, writer_lease=lease)
    CtpCallbackSessionStoreAdapter(
        store, scope, owner, lease, lambda **kwargs: kwargs, _IngressRecord
    )
    store.append_ctp_callback_ingress(
        owner, _callback_record(owner.owner_intent_id, "OnFrontConnected", 1, generation=0)
    )
    store.append_ctp_callback_ingress(
        owner,
        _callback_record(
            owner.owner_intent_id,
            "OnRspAuthenticate",
            2,
            generation=1,
            request_id=16,
            fields=((0, "BrokerID", "broker"), (0, "UserID", "user"), (1, "ErrorID", 0)),
        ),
    )
    login = _callback_record(
        owner.owner_intent_id,
        "OnRspUserLogin",
        3,
        generation=1,
        request_id=17,
        fields=(
            (0, "BrokerID", "broker"),
            (0, "UserID", "user"),
            (0, "TradingDay", "20260925"),
            (0, "FrontID", 31),
            (0, "SessionID", 41),
            (1, "ErrorID", 0),
        ),
    )
    store.append_ctp_callback_ingress(owner, login)
    source_tags = _SourceTags()
    binding = store.bind_ctp_callback_session(
        scope, owner, _LoginObservation(), source_tags, 3, writer_lease=lease
    )
    assert type(binding) is CtpCallbackSessionBindingV1

    commands = []
    reservations = [first]
    for index in range(2, command_count + 1):
        intent_id = f"v22-intent-{index}"
        reservations.append(
            store.reserve_ctp_order_identity(
                scope, intent_id, _runtime_order_id(intent_id)
            )
        )
    for index, reservation in enumerate(reservations, start=1):
        command_id = f"v22-command-{index}"
        queue_id = f"{index:032x}"
        command = store.stage_ctp_dispatch_command(
            scope,
            command_id,
            "SUBMIT",
            {
                "OrderRef": reservation.order_ref,
                "InstrumentID": "rb2710",
                "LimitPrice": "3510.5",
                "VolumeTotalOriginal": 1,
            },
            approval_use_id=f"v22-approval-{index}",
            approval_digest=sha256(f"v22-approval-digest-{index}".encode()).hexdigest(),
            session_binding=store._ctp_callback_session_binding_payload(binding),
            writer_lease=lease,
            managed_intent_id=reservation.managed_intent_id,
            order_ref=reservation.order_ref,
            managed_action_id=reservation.managed_intent_id,
            session_generation_id=binding.session_generation_id,
            dispatch_front_id=binding.dispatch_front_id,
            dispatch_session_id=binding.dispatch_session_id,
            native_request_id=50 + index,
            local_queue_receipt_id=queue_id,
        )
        store.record_ctp_dispatch_queue_receipt(
            scope,
            command_id,
            {
                "kind": "command_receipt",
                "command": "submit",
                "receipt_id": queue_id,
                "queued": True,
            },
            writer_lease=lease,
        )
        commands.append(command)
    claimed = store.claim_ctp_dispatch_command(
        scope,
        commands[0].command_id,
        writer_lease=lease,
        authority_verifier=_FakeAuthority(),
        _callback_session_owner=owner,
    )
    assert claimed is not None and claimed.status == "CLAIMED"
    return store, scope, lease, family_owner, owner, binding, commands, claimed


def _read_owner_state(store, owner):
    return store._connection.execute(
        "SELECT owner_state, poison_code, process_generation_id "
        "FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id = ?",
        (owner.owner_intent_id,),
    ).fetchone()


@pytest.mark.unit
def test_v22_claim_binds_store_process_generation_and_private_recovery_poison_is_atomic(tmp_path):
    verifier = _FakeProcessExitVerifier()
    store, scope, lease, family_owner, owner, binding, commands, claimed = _active_fixture(
        tmp_path, verifier=verifier
    )
    try:
        generation = store._connection.execute(
            "SELECT process_generation_id, callback_owner_intent_id, owner_state "
            "FROM ctp_account_family_owner_generations WHERE family_key = ? AND generation = ?",
            (family_owner.family_key, family_owner.generation),
        ).fetchone()
        owner_row = _read_owner_state(store, owner)
        command_row = store._connection.execute(
            "SELECT process_generation_id, native_call_inflight, status "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()
        assert generation["process_generation_id"] == owner_row["process_generation_id"]
        assert generation["callback_owner_intent_id"] == owner.owner_intent_id
        assert command_row["process_generation_id"] == owner_row["process_generation_id"]
        assert tuple(command_row[1:]) == (1, "CLAIMED")

        recovered = store._recover_ctp_claims_after_verified_process_exit(scope)
        assert recovered == (claimed.command_id,)
        row = store._connection.execute(
            "SELECT status, unknown_reason, native_call_inflight, native_receipt_payload_json "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()
        assert tuple(row) == ("UNKNOWN", "verified_owner_process_exit", 0, None)
        assert tuple(_read_owner_state(store, owner)[:2]) == (
            "POISONED",
            "owner_process_exit_verified",
        )
        assert store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owners WHERE family_key = ?",
            (family_owner.family_key,),
        ).fetchone()[0] == "POISONED"
        proof = store._connection.execute(
            "SELECT journal_incarnation_id, family_key, family_generation, session_generation_id, "
            "process_generation_id, claimed_command_ids_json, process_id, process_exit_observed, "
            "job_empty_observed, controls_released FROM ctp_process_exit_recoveries"
        ).fetchone()
        assert proof[0] == store.journal_source_identity()["generation"]
        assert proof[1] == family_owner.family_key
        assert proof[2] == family_owner.generation
        assert proof[3] == binding.session_generation_id
        assert proof[4] == owner_row["process_generation_id"]
        assert json.loads(proof[5]) == [claimed.command_id]
        assert tuple(proof[6:]) == (4812, 1, 1, 1)

        # Neither the generic writer-change recovery path nor a duplicate fake
        # proof can reopen or replay a callback-owned native claim.
        with pytest.raises(InvalidStateTransition, match="persistent owner|not active"):
            store.recover_claimed_ctp_dispatch_commands(scope, writer_lease=lease)
        assert store.read_ctp_dispatch_command(scope, claimed.command_id).status == "UNKNOWN"
        assert len(verifier.calls) == 1
        with pytest.raises(InvalidStateTransition, match="uniquely active"):
            store._recover_ctp_claims_after_verified_process_exit(scope)
        assert len(verifier.calls) == 1
        other_store = SqliteExecutionStore(store.path)
        try:
            with pytest.raises(InvalidStateTransition):
                other_store.acquire_ctp_account_family_owner(scope)
        finally:
            other_store.close()
        with pytest.raises(sqlite3.IntegrityError):
            store._connection.execute(
                "UPDATE ctp_process_exit_recoveries SET process_exit_code = 0"
            )
        with pytest.raises(sqlite3.IntegrityError):
            store._connection.execute("DELETE FROM ctp_process_exit_recoveries")
    finally:
        store.close()


@pytest.mark.unit
@pytest.mark.parametrize(
    "field,value",
    [
        ("journal_incarnation_id", "f" * 32),
        ("family_key", "ctp-account-family.v1:" + "f" * 64),
        ("family_generation", 99),
        ("family_owner_intent_id", "f" * 32),
        ("callback_owner_intent_id", "f" * 32),
        ("writer_owner_id", "old-writer-token"),
        ("writer_fencing_token", 99),
        ("session_generation_id", "wrong-native-session-generation"),
        ("process_generation_id", "f" * 32),
        ("claimed_command_ids", ("other-command",)),
        ("claim_set_sha256", "0" * 64),
    ],
)
def test_v22_process_exit_verifier_must_match_each_persisted_identity(tmp_path, field, value):
    verifier = _FakeProcessExitVerifier(tamper=(field, value))
    store, scope, _, _, owner, _, _, claimed = _active_fixture(tmp_path, verifier=verifier)
    try:
        with pytest.raises(InvalidStateTransition, match="capability context"):
            store._recover_ctp_claims_after_verified_process_exit(scope)
        command = store.read_ctp_dispatch_command(scope, claimed.command_id)
        assert command is not None and command.status == "CLAIMED"
        assert _read_owner_state(store, owner)[0] == "ACTIVE"
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0] == 0
    finally:
        store.close()


@pytest.mark.unit
def test_v22_process_exit_rejects_bool_process_id_even_with_rehashed_capability(tmp_path):
    verifier = _FakeProcessExitVerifier(tamper=("process_id", True))
    store, scope, _, _, owner, _, _, claimed = _active_fixture(tmp_path, verifier=verifier)
    try:
        with pytest.raises(InvalidStateTransition, match="capability is incomplete"):
            store._recover_ctp_claims_after_verified_process_exit(scope)
        assert store.read_ctp_dispatch_command(scope, claimed.command_id).status == "CLAIMED"
        assert _read_owner_state(store, owner)[0] == "ACTIVE"
    finally:
        store.close()


@pytest.mark.unit
def test_v22_process_exit_default_closed_and_generic_recovery_cannot_clear_inflight_claim(tmp_path):
    store, scope, lease, _, owner, _, _, claimed = _active_fixture(tmp_path)
    try:
        with pytest.raises(InvalidStateTransition, match="not configured"):
            store._recover_ctp_claims_after_verified_process_exit(scope)
        with pytest.raises(TypeError):
            store._recover_ctp_claims_after_verified_process_exit(scope, process_id=4812)
        assert store.recover_claimed_ctp_dispatch_commands(scope, writer_lease=lease) == ()
        command = store.read_ctp_dispatch_command(scope, claimed.command_id)
        assert command is not None and command.status == "CLAIMED"
        assert _read_owner_state(store, owner)[0] == "ACTIVE"
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0] == 0
    finally:
        store.close()


@pytest.mark.unit
def test_v22_recovery_rolls_back_unknown_poison_and_audit_if_proof_insert_fails(tmp_path):
    verifier = _FakeProcessExitVerifier()
    store, scope, _, _, owner, _, _, claimed = _active_fixture(tmp_path, verifier=verifier)
    try:
        store._connection.execute(
            "CREATE TRIGGER qa_deny_process_exit_recovery BEFORE INSERT "
            "ON ctp_process_exit_recoveries BEGIN SELECT RAISE(ABORT, 'qa abort'); END"
        )
        with pytest.raises(DurableStoreError, match="transaction failed"):
            store._recover_ctp_claims_after_verified_process_exit(scope)
        command = store.read_ctp_dispatch_command(scope, claimed.command_id)
        assert command is not None and command.status == "CLAIMED"
        raw = store._connection.execute(
            "SELECT native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()[0]
        assert raw == 1
        assert _read_owner_state(store, owner)[0] == "ACTIVE"
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0] == 0

        store._connection.execute("DROP TRIGGER qa_deny_process_exit_recovery")
        assert store._recover_ctp_claims_after_verified_process_exit(scope) == (
            claimed.command_id,
        )
    finally:
        store.close()


@pytest.mark.unit
def test_v22_verification_outside_writer_transaction_does_not_admit_successor_claim(tmp_path):
    entered = threading.Event()
    release = threading.Event()
    verifier = _FakeProcessExitVerifier(entered=entered, release=release)
    store, scope, lease, family_owner, owner, _, commands, claimed = _active_fixture(
        tmp_path, verifier=verifier, command_count=2
    )
    errors = []
    result = []

    def recover():
        try:
            result.extend(store._recover_ctp_claims_after_verified_process_exit(scope))
        except BaseException as error:  # captured for assertion in the main test thread
            errors.append(error)

    thread = threading.Thread(target=recover, daemon=True)
    try:
        thread.start()
        assert entered.wait(timeout=5)
        with pytest.raises(InvalidStateTransition, match="unresolved CTP dispatch command"):
            store.claim_ctp_dispatch_command(
                scope,
                commands[1].command_id,
                writer_lease=lease,
                authority_verifier=_FakeAuthority(),
                _callback_session_owner=owner,
            )
        other_store = SqliteExecutionStore(store.path)
        try:
            with pytest.raises(InvalidStateTransition):
                other_store.acquire_ctp_account_family_owner(scope)
        finally:
            other_store.close()
        assert store.read_ctp_dispatch_command(scope, claimed.command_id).status == "CLAIMED"
        assert store.read_ctp_dispatch_command(scope, commands[1].command_id).status == "READY"
    finally:
        release.set()
        thread.join(timeout=5)
        store.close()
    assert not thread.is_alive()
    assert not errors
    assert result == [claimed.command_id]


def _load_frozen_v21_store():
    source_root = Path(
        r"D:\temp\iteration41_v20_r3r3_v21_handoff_freeze_r1_20260927\src"
    )
    store_path = source_root / "bt_api_execution" / "store.py"
    expected = "799319096de17d4fe60560240c9424f249b3afed34a2daed1dbcc07d486d605d"
    if not store_path.is_file() or hashlib.sha256(store_path.read_bytes()).hexdigest() != expected:
        pytest.skip("exact frozen V21 source snapshot is unavailable")
    package_name = "_bt_api_execution_frozen_v21"
    package = types.ModuleType(package_name)
    package.__path__ = [str(source_root / "bt_api_execution")]
    sys.modules[package_name] = package
    spec = importlib.util.spec_from_file_location(package_name + ".store", store_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _load_frozen_v20_store():
    source_root = Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\src")
    store_path = source_root / "bt_api_execution" / "store.py"
    expected = "75b01d7badbf67043c65082bee8dc27efbe4a309a739ff9f5cadd50f21ccde72"
    if not store_path.is_file() or hashlib.sha256(store_path.read_bytes()).hexdigest() != expected:
        pytest.skip("exact frozen V20 source snapshot is unavailable")
    package_name = "_bt_api_execution_frozen_v20"
    package = types.ModuleType(package_name)
    package.__path__ = [str(source_root / "bt_api_execution")]
    sys.modules[package_name] = package
    spec = importlib.util.spec_from_file_location(package_name + ".store", store_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.mark.unit
def test_v20_account_identity_store_migrates_to_v23_native_owner_binding_schema(tmp_path):
    v20 = _load_frozen_v20_store()
    current_scope = _scope()
    scope = v20.ExecutionScope(
        current_scope.provider,
        current_scope.environment,
        current_scope.account_ref,
        current_scope.strategy_id,
        current_scope.trading_day,
    )
    database = tmp_path / "legacy-v20-account-identity.sqlite3"
    legacy = v20.SqliteExecutionStore(database)
    legacy._bind_new_ctp_account_store_identity(scope, legacy._ctp_account_family_key(scope))
    legacy.close()

    migrated = SqliteExecutionStore(database)
    try:
        schema_version = migrated._connection.execute(
            "SELECT value FROM execution_meta WHERE key = 'schema_version'"
        ).fetchone()[0]
        assert schema_version == "23"
        assert migrated._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0] == 0
        for table_name in (
            "ctp_account_family_owner_generations",
            "ctp_dispatch_callback_session_owners",
            "ctp_dispatch_commands",
        ):
            columns = {
                row["name"]
                for row in migrated._connection.execute(f"PRAGMA table_info({table_name})")
            }
            assert "process_generation_id" in columns
    finally:
        migrated.close()


@pytest.mark.unit
def test_new_account_store_factory_handles_its_empty_created_database(tmp_path):
    scope = _scope()
    database = tmp_path / "new-factory-created-store.sqlite3"
    store = SqliteExecutionStore.open_ctp_account_store(database, scope)
    try:
        version = store._connection.execute(
            "SELECT value FROM execution_meta WHERE key = 'schema_version'"
        ).fetchone()[0]
        assert version == "23"
        identity = store.read_ctp_account_store_identity(scope)
        assert identity.account_ref == scope.account_ref
    finally:
        store.close()


@pytest.mark.unit
def test_process_exit_migration_preflight_rejects_nonempty_partial_schemas(tmp_path):
    unrelated = tmp_path / "unrelated-nonempty.sqlite3"
    with sqlite3.connect(unrelated) as connection:
        connection.execute("CREATE TABLE unrelated(id INTEGER PRIMARY KEY)")
    with pytest.raises(DurableStoreError, match="preflight V21"):
        SqliteExecutionStore._preflight_v21_migration_path(str(unrelated))

    partial_v21 = tmp_path / "partial-v21.sqlite3"
    with sqlite3.connect(partial_v21) as connection:
        connection.execute("CREATE TABLE execution_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        connection.execute(
            "INSERT INTO execution_meta(key, value) VALUES ('schema_version', '21')"
        )
    with pytest.raises(DurableStoreError, match="frozen shape"):
        SqliteExecutionStore._preflight_v21_migration_path(str(partial_v21))


@pytest.mark.unit
def test_v21_claim_without_process_binding_migrates_to_unknown_and_poisoned_fence(tmp_path):
    v21 = _load_frozen_v21_store()
    current_scope = _scope()
    scope = v21.ExecutionScope(
        current_scope.provider,
        current_scope.environment,
        current_scope.account_ref,
        current_scope.strategy_id,
        current_scope.trading_day,
    )
    database = tmp_path / "legacy-v21-claim.sqlite3"
    legacy = v21.SqliteExecutionStore(database)
    legacy._bind_new_ctp_account_store_identity(scope, legacy._ctp_account_family_key(scope))
    family_owner = legacy.acquire_ctp_account_family_owner(scope)
    lease = legacy.acquire_or_renew_lease(
        scope,
        "v21-writer",
        ttl_ns=60_000_000_000,
        ctp_account_family_owner=family_owner,
    )
    proof = v21.CtpOrderRefSeedProof(
        trading_day=scope.trading_day,
        native_max_order_ref="000000000010",
        legacy_ledger_max_order_ref="000000000012",
        legacy_ledger_sha256=payload_sha256(
            {
                "backtrader_prototype": sha256(b"synthetic prototype inventory").hexdigest(),
                "sdk_jsonl": sha256(b"synthetic empty callback inventory").hexdigest(),
            }
        ),
        account_key=scope.account_key,
        scope_key=scope.key,
        session_generation_id="v21-session-generation",
        native_front_id=31,
        native_session_id=41,
        existing_native_order_refs=("000000000009", "000000000010"),
        legacy_source_sha256=(
            ("backtrader_prototype", sha256(b"synthetic prototype inventory").hexdigest()),
            ("sdk_jsonl", sha256(b"synthetic empty callback inventory").hexdigest()),
        ),
        legacy_mappings=(
            v21.CtpOrderRefLegacyMapping(
                source_name="backtrader_prototype",
                account_key=scope.account_key,
                trading_day="20260924",
                scope_key=ExecutionScope(
                    "ctp", "simulation", scope.account_ref, "strategy.legacy", "20260924"
                ).key,
                managed_intent_id="legacy-managed-intent",
                runtime_order_id="legacy-runtime-order-1",
                order_ref="000000000012",
            ),
        ),
    )
    reservation = legacy.seed_ctp_order_ref_and_reserve_identity(
        scope, proof, "v21-intent", _runtime_order_id("v21-intent"), writer_lease=lease
    )
    queue_id = "9" * 32
    command = legacy.stage_ctp_dispatch_command(
        scope,
        "v21-claimed-command",
        "SUBMIT",
        {
            "OrderRef": reservation.order_ref,
            "InstrumentID": "rb2710",
            "LimitPrice": "3510.5",
            "VolumeTotalOriginal": 1,
        },
        approval_use_id="v21-approval-use",
        approval_digest=sha256(b"v21 approval digest").hexdigest(),
        session_binding={
            "session_identity": "v21-session",
            "session_generation_id": "v21-session-generation",
            "dispatch_front_id": 31,
            "dispatch_session_id": 41,
        },
        writer_lease=lease,
        managed_intent_id=reservation.managed_intent_id,
        order_ref=reservation.order_ref,
        managed_action_id=reservation.managed_intent_id,
        session_generation_id="v21-session-generation",
        dispatch_front_id=31,
        dispatch_session_id=41,
        native_request_id=51,
        local_queue_receipt_id=queue_id,
    )
    legacy.record_ctp_dispatch_queue_receipt(
        scope,
        command.command_id,
        {"kind": "command_receipt", "command": "submit", "receipt_id": queue_id, "queued": True},
        writer_lease=lease,
    )
    claimed = legacy.claim_ctp_dispatch_command(
        scope,
        command.command_id,
        writer_lease=lease,
        authority_verifier=type(
            "V21Authority",
            (),
            {
                "verify_action": lambda self, staged, *, now_ns: v21.CtpDispatchAuthority(
                    authority_type="ctp_dispatch_authority.v1",
                    command_binding_sha256=staged.authority_binding_sha256,
                    approval_use_id=staged.approval_use_id,
                    approval_digest=staged.approval_digest,
                    source_digest_sha256=sha256(b"synthetic v21 authority").hexdigest(),
                    verifier_id="v21-fixture-authority",
                    verified_at_ns=now_ns,
                    expires_at_ns=now_ns + 5_000_000_000,
                )
            },
        )(),
    )
    assert claimed is not None and claimed.status == "CLAIMED"
    legacy.close()

    migrated = SqliteExecutionStore(database)
    try:
        row = migrated._connection.execute(
            "SELECT status, unknown_reason, process_generation_id "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (command.command_id,),
        ).fetchone()
        assert tuple(row) == (
            "UNKNOWN",
            "schema_upgrade_requires_ctp_v2_dispatch_cutover",
            None,
        )
        assert migrated._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owners WHERE family_key = ?",
            (family_owner.family_key,),
        ).fetchone()[0] == "POISONED"
        assert migrated._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0] == 0
        with pytest.raises(InvalidStateTransition):
            migrated.acquire_ctp_account_family_owner(current_scope)
    finally:
        migrated.close()
