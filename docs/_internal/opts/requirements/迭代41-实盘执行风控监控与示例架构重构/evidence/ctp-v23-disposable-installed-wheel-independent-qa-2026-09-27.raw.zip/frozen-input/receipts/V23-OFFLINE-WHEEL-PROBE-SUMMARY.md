# V23 offline installed-wheel probe

- Frozen source manifest SHA-256: `f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330`.
- Disposable version: `0.2.3.dev0+audit.v23.f94b924e1e20`.
- Dual pure-Python wheel SHA-256: `9f7f61cc0ddea8953070fcfdfa6ac41e70d3bd594c2ceda35f9377db57419591`; builds byte-identical.
- Focused installed-wheel tests: 186 passed, 2 skipped.
- Full installed-wheel package tests: 322 passed, 2 skipped.
- External network attempts: 0; native SDK modules loaded: 0.
- This is a local source-only install probe. It does not provide G1/G5 acceptance or real OS attestation.
- Artifact manifest SHA-256: `9fa563a58225e715b955a524d2e06a141e78adc684bcb852e70bdf7b56cd9a14`.
- Archive SHA-256: `fd2656dc2347daa6badf592764bd856a628c756291cd1c26d575e5dba327a312`; `ZipFile.testzip()` passed.
