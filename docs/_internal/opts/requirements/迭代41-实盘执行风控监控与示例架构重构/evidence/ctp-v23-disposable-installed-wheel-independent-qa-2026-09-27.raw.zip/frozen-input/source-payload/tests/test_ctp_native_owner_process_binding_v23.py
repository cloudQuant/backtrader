from __future__ import annotations

import sqlite3

import pytest
from test_ctp_process_exit_recovery_v22 import (
    _active_fixture,
    _FakeAuthority,
    _runtime_order_id,
    _scope,
    _seed_proof,
)
from v23_native_owner_fake import FakeNativeOwnerProcessAttestor

from bt_api_execution import InvalidStateTransition, SqliteExecutionStore


def _prepared_store(tmp_path, *, attestor=None):
    scope = _scope()
    store = SqliteExecutionStore(
        tmp_path / "v23-owner-binding.sqlite3",
        _ctp_native_owner_process_attestor=attestor,
    )
    store._bind_new_ctp_account_store_identity(scope, store._ctp_account_family_key(scope))
    family = store.acquire_ctp_account_family_owner(scope)
    lease = store.acquire_or_renew_lease(
        scope,
        "v23-binding-writer",
        ttl_ns=60_000_000_000,
        ctp_account_family_owner=family,
    )
    store.seed_ctp_order_ref_and_reserve_identity(
        scope,
        _seed_proof(scope),
        "v23-intent",
        _runtime_order_id("v23-intent"),
        writer_lease=lease,
    )
    return store, scope, family, lease


@pytest.mark.unit
def test_v23_native_owner_binding_is_committed_immutable_and_matches_claim(tmp_path):
    store, scope, lease, family, owner, _, commands, claimed = _active_fixture(
        tmp_path, command_count=2
    )
    try:
        row = store._connection.execute(
            "SELECT journal_incarnation_id, account_key, scope_key, family_key, "
            "family_generation, family_owner_intent_id, callback_owner_intent_id, "
            "writer_owner_id, writer_fencing_token, process_generation_id, "
            "supervisor_instance_id, job_instance_id, process_id, "
            "process_creation_time_100ns, windows_session_id, owner_sid_sha256, "
            "deployment_manifest_sha256, artifact_digest_sha256, binding_sha256 "
            "FROM ctp_native_owner_process_bindings WHERE callback_owner_intent_id = ?",
            (owner.owner_intent_id,),
        ).fetchone()
        assert row is not None
        assert row[0] == store.journal_source_identity()["generation"]
        assert tuple(row[1:9]) == (
            scope.account_key,
            scope.key,
            family.family_key,
            family.generation,
            family.owner_intent_id,
            owner.owner_intent_id,
            lease.owner_id,
            lease.fencing_token,
        )
        assert row[9] == store._connection.execute(
            "SELECT process_generation_id FROM ctp_dispatch_callback_session_owners "
            "WHERE owner_intent_id = ?",
            (owner.owner_intent_id,),
        ).fetchone()[0]
        assert row[10] and row[11]
        assert row[12:15] == (4812, 9_000_001, 0)
        assert all(len(row[index]) == 64 for index in (15, 16, 17, 18))
        command = store._connection.execute(
            "SELECT process_generation_id, native_call_inflight, status "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()
        assert tuple(command) == (row[9], 1, "CLAIMED")
        assert claimed.command_id == commands[0].command_id
        with pytest.raises(sqlite3.IntegrityError):
            store._connection.execute(
                "UPDATE ctp_native_owner_process_bindings SET process_id = 4813 "
                "WHERE callback_owner_intent_id = ?",
                (owner.owner_intent_id,),
            )
        with pytest.raises(sqlite3.IntegrityError):
            store._connection.execute(
                "DELETE FROM ctp_native_owner_process_bindings WHERE callback_owner_intent_id = ?",
                (owner.owner_intent_id,),
            )
    finally:
        store.close()


@pytest.mark.unit
def test_v23_default_without_service_attestor_creates_no_owner_or_claim(tmp_path):
    store, scope, family, lease = _prepared_store(tmp_path)
    try:
        with pytest.raises(InvalidStateTransition, match="attestor is not configured"):
            store.create_ctp_callback_session_owner(scope, writer_lease=lease)
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_dispatch_callback_session_owners"
        ).fetchone()[0] == 0
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_native_owner_process_bindings"
        ).fetchone()[0] == 0
        row = store._connection.execute(
            "SELECT callback_owner_intent_id, process_generation_id "
            "FROM ctp_account_family_owner_generations WHERE family_key = ? AND generation = ?",
            (family.family_key, family.generation),
        ).fetchone()
        assert tuple(row) == (None, None)
    finally:
        store.close()


@pytest.mark.unit
@pytest.mark.parametrize(
    "field,value,match",
    [
        ("journal_incarnation_id", "f" * 32, "context does not match"),
        ("account_key", "account:" + "f" * 64, "context does not match"),
        ("family_generation", 9, "context does not match"),
        ("family_owner_intent_id", "f" * 32, "context does not match"),
        ("callback_owner_intent_id", "f" * 32, "context does not match"),
        ("writer_owner_id", "old-writer", "context does not match"),
        ("writer_fencing_token", 9, "context does not match"),
        ("process_generation_id", "f" * 32, "context does not match"),
        ("process_id", True, "incomplete or stale"),
        ("windows_session_id", False, "incomplete or stale"),
    ],
)
def test_v23_rejects_forged_or_type_confused_binding_before_owner_commit(
    tmp_path, field, value, match
):
    store, scope, family, lease = _prepared_store(
        tmp_path, attestor=FakeNativeOwnerProcessAttestor(tamper=(field, value))
    )
    try:
        with pytest.raises(InvalidStateTransition, match=match):
            store.create_ctp_callback_session_owner(scope, writer_lease=lease)
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_dispatch_callback_session_owners"
        ).fetchone()[0] == 0
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_native_owner_process_bindings"
        ).fetchone()[0] == 0
        generation = store._connection.execute(
            "SELECT callback_owner_intent_id, process_generation_id "
            "FROM ctp_account_family_owner_generations WHERE family_key = ? AND generation = ?",
            (family.family_key, family.generation),
        ).fetchone()
        assert tuple(generation) == (None, None)
    finally:
        store.close()


@pytest.mark.unit
def test_v23_binding_insert_rollback_leaves_no_owner_generation_or_binding(tmp_path):
    attestor = FakeNativeOwnerProcessAttestor()
    store, scope, family, lease = _prepared_store(tmp_path, attestor=attestor)
    try:
        store._connection.execute(
            "CREATE TRIGGER qa_deny_v23_binding BEFORE INSERT "
            "ON ctp_native_owner_process_bindings "
            "BEGIN SELECT RAISE(ABORT, 'qa binding insert denied'); END"
        )
        with pytest.raises(Exception, match="transaction failed"):
            store.create_ctp_callback_session_owner(scope, writer_lease=lease)
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_dispatch_callback_session_owners"
        ).fetchone()[0] == 0
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_native_owner_process_bindings"
        ).fetchone()[0] == 0
        generation = store._connection.execute(
            "SELECT callback_owner_intent_id, process_generation_id, owner_state "
            "FROM ctp_account_family_owner_generations WHERE family_key = ? AND generation = ?",
            (family.family_key, family.generation),
        ).fetchone()
        assert tuple(generation) == (None, None, "CLAIMED")
    finally:
        store.close()


@pytest.mark.unit
def test_v23_missing_binding_blocks_next_native_session_claim(tmp_path):
    store, scope, lease, _, owner, _, commands, claimed = _active_fixture(
        tmp_path, command_count=2
    )
    try:
        store._connection.execute(
            "DROP TRIGGER ctp_native_owner_process_binding_immutable_update"
        )
        store._connection.execute(
            "DROP TRIGGER ctp_native_owner_process_binding_immutable_delete"
        )
        store._connection.execute(
            "DELETE FROM ctp_native_owner_process_bindings WHERE callback_owner_intent_id = ?",
            (owner.owner_intent_id,),
        )
        with pytest.raises(InvalidStateTransition, match="binding is missing"):
            store.claim_ctp_dispatch_command(
                scope,
                commands[1].command_id,
                writer_lease=lease,
                authority_verifier=_FakeAuthority(),
                _callback_session_owner=owner,
            )
        assert store.read_ctp_dispatch_command(scope, claimed.command_id).status == "CLAIMED"
        assert store.read_ctp_dispatch_command(scope, commands[1].command_id).status == "READY"
        assert store._connection.execute(
            "SELECT COUNT(*) FROM ctp_dispatch_authority_uses WHERE command_id = ?",
            (commands[1].command_id,),
        ).fetchone()[0] == 0
    finally:
        store.close()


@pytest.mark.unit
def test_v23_v22_claimed_owner_migrates_unknown_poisoned_and_never_replays(tmp_path):
    store, scope, lease, family, owner, _, _, claimed = _active_fixture(tmp_path)
    database = store.path
    try:
        store._connection.execute(
            "DROP TRIGGER ctp_native_owner_process_binding_immutable_update"
        )
        store._connection.execute(
            "DROP TRIGGER ctp_native_owner_process_binding_immutable_delete"
        )
        store._connection.execute("DROP INDEX ctp_native_owner_binding_account_generation")
        store._connection.execute("DROP TABLE ctp_native_owner_process_bindings")
        store._connection.execute(
            "UPDATE execution_meta SET value='22' WHERE key='schema_version'"
        )
    finally:
        store.close()

    migrated = SqliteExecutionStore(database)
    try:
        command = migrated._connection.execute(
            "SELECT status, unknown_reason, native_call_inflight FROM ctp_dispatch_commands "
            "WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()
        owner_row = migrated._connection.execute(
            "SELECT owner_state, poison_code, process_generation_id "
            "FROM ctp_dispatch_callback_session_owners WHERE owner_intent_id = ?",
            (owner.owner_intent_id,),
        ).fetchone()
        family_row = migrated._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owners WHERE family_key = ?",
            (family.family_key,),
        ).fetchone()
        assert tuple(command) == ("UNKNOWN", "g1_process_binding_missing", 1)
        assert tuple(owner_row[:2]) == ("POISONED", "g1_process_binding_missing")
        assert owner_row[2]
        assert family_row[0] == "POISONED"
        assert migrated._connection.execute(
            "SELECT COUNT(*) FROM ctp_native_owner_process_bindings"
        ).fetchone()[0] == 0
        with pytest.raises(InvalidStateTransition):
            migrated._recover_ctp_claims_after_verified_process_exit(scope)
        assert migrated.read_ctp_dispatch_command(scope, claimed.command_id).status == "UNKNOWN"
    finally:
        migrated.close()
