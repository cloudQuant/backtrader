from __future__ import annotations

import hashlib
import json
import time
from dataclasses import replace

from bt_api_execution.store import (
    SqliteExecutionStore,
    _CtpNativeOwnerProcessBindingRequest,
    _CtpVerifiedNativeOwnerProcessBinding,
)


class FakeNativeOwnerProcessAttestor:
    """Offline fake for source tests; not an OS authority or production verifier."""

    attestor_id = "fake-v23-native-owner-attestor.v1"

    def __init__(self, tamper: tuple[str, object] | None = None) -> None:
        self.tamper = tamper

    def attest_owner_process(
        self, request: _CtpNativeOwnerProcessBindingRequest
    ) -> _CtpVerifiedNativeOwnerProcessBinding:
        def id32(label: str) -> str:
            return hashlib.sha256((label + request.process_generation_id).encode()).hexdigest()[:32]

        proof = _CtpVerifiedNativeOwnerProcessBinding(
            challenge=request.challenge,
            journal_incarnation_id=request.journal_incarnation_id,
            account_key=request.account_key,
            scope_key=request.scope_key,
            family_key=request.family_key,
            family_generation=request.family_generation,
            family_owner_intent_id=request.family_owner_intent_id,
            callback_owner_intent_id=request.callback_owner_intent_id,
            writer_owner_id=request.writer_owner_id,
            writer_fencing_token=request.writer_fencing_token,
            process_generation_id=request.process_generation_id,
            supervisor_instance_id=id32("supervisor:"),
            job_instance_id=id32("job:"),
            process_id=4812,
            process_creation_time_100ns=9_000_001,
            windows_session_id=0,
            owner_sid_sha256=hashlib.sha256(b"synthetic SID").hexdigest(),
            deployment_manifest_sha256=hashlib.sha256(b"synthetic deployment").hexdigest(),
            artifact_digest_sha256=hashlib.sha256(b"synthetic artifact").hexdigest(),
            observed_at_ns=time.time_ns(),
            expires_at_ns=request.expires_at_ns,
            attestor_id=self.attestor_id,
            proof_id=id32("proof:"),
            proof_sha256="0" * 64,
        )
        if self.tamper is not None:
            proof = replace(proof, **{self.tamper[0]: self.tamper[1]})
        payload = SqliteExecutionStore._ctp_native_owner_process_binding_proof_payload(proof)
        digest = hashlib.sha256(
            json.dumps(
                payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
            ).encode("utf-8")
        ).hexdigest()
        return replace(proof, proof_sha256=digest)
