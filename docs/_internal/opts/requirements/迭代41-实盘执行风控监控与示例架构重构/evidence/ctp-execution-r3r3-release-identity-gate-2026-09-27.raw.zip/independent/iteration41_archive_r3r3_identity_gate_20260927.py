from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


AUDIT = Path(r"D:\temp\iteration41_v20_r3r3_release_identity_gate_20260927")
PARENT_ZIP = Path(r"D:\q\parent-a-76d5e0e.zip")
MAIN = Path(r"D:\source_code\backtrader")
EVIDENCE = MAIN / "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence"
STEM = "ctp-execution-r3r3-release-identity-gate-2026-09-27"
MANIFEST_SHA = "9e3fd8c6dff7a7c0596c77a7bab61ef8c93188b7f73a8fca3dfa0115b84206e2"
AUDIT_SHA = "6e494c0611b811dfbeff3307c96c2b49c352bab16536b2e9769cde9ee33c3a31"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def verified(path: Path, expected: str, size: int | None = None) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"invalid source {path}")
    raw = path.read_bytes()
    if sha(raw) != expected or (size is not None and len(raw) != size):
        raise RuntimeError(f"source hash mismatch {path}")
    return raw


def main() -> None:
    manifest_raw = verified(AUDIT / "artifact-manifest.json", MANIFEST_SHA)
    audit_raw = verified(AUDIT / "release-identity-audit.json", AUDIT_SHA)
    manifest = json.loads(manifest_raw)
    audit = json.loads(audit_raw)
    assert manifest["decision"] == audit["decision"] == "BLOCKED_EXACT_PARENT_AND_RUNTIME_PINS"
    assert len(manifest["files"]) == 11 and manifest["wheel_outputs"] == []
    assert len(audit["main_runtime_exact_pins"]) == 5
    for row in manifest["files"]:
        verified(AUDIT / row["path"], row["sha256"], row["bytes"])
    assert sha(PARENT_ZIP.read_bytes()) == audit["parent_source"]["archive_sha256"]
    with zipfile.ZipFile(PARENT_ZIP) as parent_zip:
        parent_session = parent_zip.read("bt_api_py/_execution_session.py")
        parent_project = parent_zip.read("pyproject.toml")
    assert sha(parent_session) == audit["parent_source"]["bt_api_py/_execution_session.py_sha256"]
    assert sha(parent_project) == audit["parent_source"]["pyproject_sha256"]
    for row in audit["main_runtime_exact_pins"]:
        verified(MAIN / row["path"], row["sha256"])
    for suffix in (".raw.zip", ".json", ".md"):
        assert not (EVIDENCE / f"{STEM}{suffix}").exists()
    entries: list[dict[str, object]] = []
    archive = EVIDENCE / f"{STEM}.raw.zip"

    def add(zf: zipfile.ZipFile, path: Path, name: str, expected: str) -> None:
        raw = verified(path, expected)
        zf.writestr(name, raw)
        entries.append({"path": name, "sha256": expected, "bytes": len(raw)})

    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zf:
        add(zf, AUDIT / "artifact-manifest.json", "audit/artifact-manifest.json", MANIFEST_SHA)
        for row in manifest["files"]:
            add(zf, AUDIT / row["path"], "audit/" + row["path"], row["sha256"])
        zf.writestr("parent/bt_api_py/_execution_session.py", parent_session)
        entries.append({"path": "parent/bt_api_py/_execution_session.py", "sha256": sha(parent_session), "bytes": len(parent_session)})
        zf.writestr("parent/pyproject.toml", parent_project)
        entries.append({"path": "parent/pyproject.toml", "sha256": sha(parent_project), "bytes": len(parent_project)})
        for row in audit["main_runtime_exact_pins"]:
            add(zf, MAIN / row["path"], "main/" + row["path"], row["sha256"])
        script = Path(__file__)
        add(zf, script, "independent/" + script.name, sha(script.read_bytes()))
    with zipfile.ZipFile(archive) as zf:
        assert zf.testzip() is None
        assert len(zf.namelist()) == len(entries) == 20
    archive_sha = sha(archive.read_bytes())
    review = {
        "schema": "iteration41.execution_r3r3.release_identity.root_review.v1",
        "status": "BLOCKED_EXACT_PARENT_AND_RUNTIME_PINS",
        "audit_manifest_sha256": MANIFEST_SHA,
        "audit_receipt_sha256": AUDIT_SHA,
        "root_verified": "11 audit artifacts plus exact parent project/session and five main runtime pin files",
        "finding": "R3r2 and R3r3 both declare 0.2.0; unique 0.2.1 conflicts with exact parent/runtime version and wheel filename guards",
        "scope": "No wheel built or installed; previous 284+2 result is source-only",
        "next_step": "Coordinated unique distribution version and exact parent/runtime pin migration in isolated candidate",
        "archive": {"file": archive.name, "sha256": archive_sha, "entries": len(entries)},
        "files": entries,
    }
    (EVIDENCE / f"{STEM}.json").write_text(json.dumps(review, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (EVIDENCE / f"{STEM}.md").write_text(
        "# Execution R3r3 发行身份与精确 pin 门\n\n"
        "**当前安装制品不通过。**R3r2 与 R3r3 源码 manifest 都声明 `bt_api_execution 0.2.0`；"
        "复用版本会得到同版本不同哈希的 wheel。唯一的 `0.2.1` 被 parent76 `_execution_session.py` 和主仓五处运行时精确版本/文件名门拒绝。"
        "root 复核了 11 份审计制品、parent 源和五处主仓 pin 的 SHA-256。没有为 R3r3 构建或安装 wheel，"
        "此前 `284 passed / 2 skipped` 仅是源码测试。下一步须协调 parent 与主仓 pin，再做双构建、RECORD、安装来源和联调。"
        "默认 CTP 写入与 live 路由保持关闭。\n\n"
        f"[机器记录]({STEM}.json)与[原始归档]({STEM}.raw.zip)保留精确文件；"
        f"归档 SHA-256 `{archive_sha}`，共 {len(entries)} 项。\n",
        encoding="utf-8",
    )
    print(json.dumps({"archive": str(archive), "sha256": archive_sha, "entries": len(entries)}))


if __name__ == "__main__":
    main()
