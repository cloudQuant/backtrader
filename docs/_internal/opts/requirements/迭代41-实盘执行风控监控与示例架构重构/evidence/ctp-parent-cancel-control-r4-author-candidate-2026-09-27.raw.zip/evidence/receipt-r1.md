# Cancellation-control r4 evidence receipt

Snapshot
- Immutable copy: D:\temp\iteration41-cancel-control-r4-freeze-r1-20260927
- Manifest SHA256: 60B020202ED89169E24AFCA30B1B1B16680151A11C6F52C518D0F5BBFA7FAB0D
- Manifest contains 154 payload files.
- Changed files relative to frozen r3:
  - bt_api_py\runtime_plugins\cancellation_control.py SHA256 8B7D2B02654D0B4A9FBEA63F4BC359A0135DF6410CF4034EA069A41E32B898CD
  - tests\test_cancellation_dispatch_resolution_control.py SHA256 0160907F5AE68EBA844BF39961B65EA09F038C3D0517A3FB0E432A142407C8D7

Verification
- Exact command: PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest --noconftest -p no:cacheprovider tests\test_cancellation_dispatch_resolution_control.py -q
- Result: 20 passed in 13.20s. Full output: frozen-r1-focused-tests.log.
- Ruff check on the two changed files reports 23 findings. Frozen r3 reports 18; r4 adds five diagnostics (four S110/BLE001 findings on defensive rollback/close suppression and one RUF100 import directive). JSON: frozen-r1-ruff.json.
- Cross-process probe: ordinary concurrent DELETE is blocked by the immutable-event trigger; same-user DROP TRIGGER + DELETE succeeds after commit. Output: sqlite-writer-boundary-probes.log.

R4 changes
- Appends and commits the release-prepared monitor event before the final risk release step.
- Holds a monitor SQLite BEGIN IMMEDIATE writer reservation across exact event readback, risk audit release, and final risk-latch removal; applies equivalent guarding to released replay.
- Installs and validates code-owned update/delete triggers before the critical transition.
- Explicitly closes the verification connection which was previously left open by SQLite connection context-manager semantics.
- Fail-closed rollback reasserts both latches if the risk-store acknowledgement is ambiguous.

Limit
- Ordinary concurrent SQLite DML is serialized/rejected by the trigger. A same-user process with file/DDL authority can drop the triggers and delete or replace the monitor DB; the probe reproduces this. Thus the local guard is cooperative SQLite writer protection only. Cross-database atomicity and hostile same-user isolation are not established. This remains an offline fake-path improvement; CTP and production release remain rejected.
- The event append and trigger installation commit before the final guarded section. The final monitor transaction holds a write reservation but does not write the release event; the risk release commits before that monitor connection exits. This ordering does not demonstrate a crash-induced missing-event state, but r4 has no general atomic transaction spanning the two databases. Process-death behavior is not independently tested.
- Independent review and main bridge rerun are pending; this receipt is not an acceptance result.

