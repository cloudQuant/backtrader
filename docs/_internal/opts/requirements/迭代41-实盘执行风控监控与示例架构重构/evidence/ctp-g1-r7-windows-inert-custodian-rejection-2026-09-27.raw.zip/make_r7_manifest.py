import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
payload = [
    "g1_win_lazy_probe.cpp",
    "g1_win_lazy_probe.exe",
    "g1_win_lazy_probe.obj",
    "build_r7.bat",
    "build_r7.log",
    "build_r7.exitcode",
    "run_r7_scenarios.py",
    "r7_scenarios.json",
    "r7_scenario_runner.stdout.log",
    "r7_receipt.json",
    "R7_FINDINGS.md",
    "r7_environment.txt",
    "make_r7_manifest.py",
]
files = {}
for name in payload:
    data = (root / name).read_bytes()
    files[name] = {
        "sha256": hashlib.sha256(data).hexdigest(),
        "size_bytes": len(data),
    }

hash_list = {
    "candidate": "R7 Windows inert lazy-custodian experiment",
    "hash_algorithm": "SHA-256",
    "payloads": files,
}
hash_list_path = root / "r7_payload_hashes.json"
hash_list_path.write_text(json.dumps(hash_list, indent=2, sort_keys=True) + "\n", encoding="utf-8")
hash_list_data = hash_list_path.read_bytes()
files["r7_payload_hashes.json"] = {
    "sha256": hashlib.sha256(hash_list_data).hexdigest(),
    "size_bytes": len(hash_list_data),
}

manifest = {
    "manifest_version": 1,
    "candidate": "R7 Windows inert lazy-custodian experiment",
    "disposition": "REJECTED / G1 CLOSED",
    "scope": (
        "fresh D:\\temp isolation directory; no repository modifications; "
        "no CTP/provider/credentials/private config/SCM service/default route"
    ),
    "files": files,
}
manifest_path = root / "r7_manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
manifest_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
(root / "r7_manifest.sha256").write_text(
    manifest_hash + "  r7_manifest.json\n", encoding="ascii"
)

checks = []
for name, metadata in files.items():
    data = (root / name).read_bytes()
    checks.append(
        {
            "file": name,
            "ok": hashlib.sha256(data).hexdigest() == metadata["sha256"]
            and len(data) == metadata["size_bytes"],
        }
    )
receipt = json.loads((root / "r7_receipt.json").read_text(encoding="utf-8"))
scenarios = json.loads((root / "r7_scenarios.json").read_text(encoding="utf-8"))
checks.extend(
    [
        {
            "file": "receipt/disposition",
            "ok": receipt.get("disposition", "").startswith("REJECTED / G1 CLOSED"),
        },
        {
            "file": "scenarios/count",
            "ok": len(scenarios) == 9,
        },
        {
            "file": "scenario/admission-sync-negative",
            "ok": next(x for x in scenarios if x["mode"] == "admission-sync")["result"]["caller_blocked_at_deadline"],
        },
        {
            "file": "scenario/admission-overlapped-pending",
            "ok": "cancel_completed=0" in next(x for x in scenarios if x["mode"] == "admission-overlapped")["result"]["caller_output"],
        },
    ]
)
print(
    json.dumps(
        {
            "manifest_sha256": manifest_hash,
            "manifest_payloads": len(files),
            "checks": checks,
            "all_ok": all(item["ok"] for item in checks),
        },
        sort_keys=True,
    )
)
if not all(item["ok"] for item in checks):
    raise SystemExit(1)
