@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
cl /nologo /EHsc /std:c++17 /W4 /DUNICODE /D_UNICODE g1_win_lazy_probe.cpp /Fe:g1_win_lazy_probe.exe /link advapi32.lib
if errorlevel 1 (
  >build_r7.exitcode echo 1
  exit /b 1
)
>build_r7.exitcode echo 0
exit /b 0
