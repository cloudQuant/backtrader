import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

root = Path(__file__).resolve().parent
exe = root / "g1_win_lazy_probe.exe"
modes = ["normal", "create_process", "pipe", "token", "receipt", "join", "descendant_join", "admission-sync", "admission-overlapped"]
rows = []
for mode in modes:
    started = time.monotonic()
    proc = subprocess.Popen([str(exe), mode], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    timed_out = False
    try:
        stdout, _ = proc.communicate(timeout=6.0)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.terminate()
        try:
            stdout, _ = proc.communicate(timeout=1.0)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, _ = proc.communicate(timeout=1.0)
    duration_ms = round((time.monotonic() - started) * 1000, 3)
    parsed = None
    for line in reversed((stdout or "").splitlines()):
        try:
            parsed = json.loads(line)
            break
        except json.JSONDecodeError:
            pass
    rows.append({"mode": mode, "duration_ms_external_watchdog": duration_ms,
                 "outer_timeout": timed_out, "process_exit": proc.returncode,
                 "stdout": stdout, "result": parsed})
    print(json.dumps(rows[-1], sort_keys=True))
(root / "r7_scenarios.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

summary = {
    "candidate": "R7 isolated true-Windows inert Job/IPC probe",
    "timestamp_local": time.strftime("%Y-%m-%d %H:%M:%S %z"),
    "host": {"os": os.name, "platform": __import__("platform").platform(),
             "python": __import__("platform").python_version()},
    "request_budget_ms": 1800,
    "worker_stage_budget_ms": 500,
    "protocol_observations": [
        "Before GO/request admission, the harness creates the worker Job, starts the worker suspended with PROC_THREAD_ATTRIBUTE_JOB_LIST, verifies Job ActiveProcesses==1 and exact IsProcessInJob membership, resumes it, observes WORKER_READY, creates/connects named-pipe IPC, and starts a distinct caller process in a separate caller Job. Worker process/thread/Job handles are held by the same harness process.",
        "The harness itself is both the worker custodian and caller deadline observer; it is not an independently supervised custodian process. A separate Python runner imposes a six-second outer process watchdog, but it does not own duplicated Job handles.",
        "create_process injection successfully starts an inert sleeper child inside the worker Job and then blocks the worker; pipe injection successfully creates a pipe and then blocks; token injection opens only the worker's own TOKEN_QUERY handle and then blocks; receipt injection creates/signals a local event and then blocks; join injection performs a real infinite WaitForSingleObject on an inert sleeper. These tests do not stall CreateProcessW/CreatePipe/OpenProcessToken/receipt-creation inside those API calls.",
        "descendant_join observes ActiveProcesses==3 (worker, child spawner, grandchild sleeper) before TerminateJobObject and ActiveProcesses==0 after worker exit.",
        "admission-sync uses a real synchronous WriteFile over an already-connected named pipe with no reader. At 1800ms the caller process is still blocked; the harness terminates the separate caller Job. Worker Job controls remain valid at UNKNOWN. The full harness elapsed was 1828ms, so the exact caller deadline was exceeded and the caller did not return normally.",
        "admission-overlapped uses an already-connected overlapped pipe and emits UNKNOWN, but CancelIoEx had not completed (cancel_completed=0) when the caller returned with exit code 54. This one-shot process does not retain a live I/O reaper/context; it is not evidence that a persistent request handler may safely release the OVERLAPPED/buffer or that the admission stall is eliminated.",
        "Warmup and IPC connection are explicitly completed before GO and are outside the measured request budget. No request-during-not-ready rejection case is implemented. Synchronous QueryInformationJobObject, TerminateJobObject, CloseHandle, and CreateProcessW setup calls were not forced to hang; their signatures/docs do not provide a hard in-call deadline.",
    ],
    "scenarios": [],
    "scope": "inert Python/C++ test workers only; no CTP, credentials, private config, provider, SCM service, or default route",
    "non_acceptance": "This is not G1 acceptance. Custodian and watchdog are in one native harness process; synchronous Win32 APIs are not documented as hard-time-bounded.",
}
for row in rows:
    d = row["result"] or {}
    summary["scenarios"].append({"mode": row["mode"], "external_watchdog_ms": row["duration_ms_external_watchdog"],
                                 "outer_timeout": row["outer_timeout"], "status": d.get("status"),
                                 "elapsed_ms_internal": d.get("elapsed_ms"), "caller_exit_code": d.get("caller_exit_code"),
                                 "active_before_terminate": d.get("active_before_terminate"),
                                 "active_after_terminate": d.get("active_after_terminate"),
                                 "exact_exit_and_job_empty": d.get("exact_exit_and_job_empty"),
                                 "controls_retained_at_unknown": d.get("controls_retained_at_unknown"),
                                 "controls_released_after_exact_proof": d.get("controls_released_after_exact_proof"),
                                 "caller_output": d.get("caller_output"), "error": d.get("error")})
summary["disposition"] = "REJECTED / G1 CLOSED: synchronous named-pipe admission exceeded its 1800ms request budget and required caller-process termination; overlapped admission returned UNKNOWN while I/O was still pending (cancel_completed=0), so safe caller return with retained I/O ownership was not demonstrated."
(root / "r7_receipt.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print("RECEIPT", json.dumps({"source_sha256": sha(root / "g1_win_lazy_probe.cpp"),
                            "exe_sha256": sha(exe), "build_log_sha256": sha(root / "build_r7.log"),
                            "scenarios_sha256": sha(root / "r7_scenarios.json"),
                            "receipt_sha256": sha(root / "r7_receipt.json")}, sort_keys=True))
