# R7 Windows inert lazy-custodian experiment — frozen findings

**Disposition: REJECTED; G1 remains closed.** This is a throwaway experiment under `D:\temp`; no repository files, service registration, CTP, provider, credentials, protected config, or default route were touched.

## Tested behavior

- The native worker was created suspended with `PROC_THREAD_ATTRIBUTE_JOB_LIST`, so it entered its pre-created Windows Job before resume. Before request admission, the harness observed `ActiveProcesses == 1`, exact `IsProcessInJob` membership, `WORKER_READY`, connected named-pipe IPC, and pre-owned worker process/thread/Job handles.
- Baseline normal request completed; the worker exited code 0, Job count reached 0, and the harness released the handles only after that exact proof.
- Inert request-time stalls after successful setup were terminated from the Job. A real Join wait blocked on a sleeper. The descendant case observed three Job members (worker + child + grandchild); every injected worker stall ended with worker exit code `0xE1000001`, `ActiveProcesses == 0`, and controls released only after exact exit/empty proof.
- Synchronous admission negative used a real `WriteFile` to a connected named pipe with a full/no-reader server buffer. At the 1800ms request deadline the caller was still blocked. The harness killed the caller Job, reported UNKNOWN while worker controls remained valid, and finished at 1828ms. The caller did not return normally and the end-to-end observed time exceeded the requested deadline.
- Overlapped admission returned an UNKNOWN line, but `CancelIoEx` had not completed (`cancel_completed=0`); caller process exit code was 54. The one-shot process did not retain a live I/O reaper/context, so this does not demonstrate safe return from a persistent request handler or elimination of blocked admission.

## Limits

- Custodian and its deadline observer are in the same native harness process. The external Python runner is only a 6-second process watchdog and owns no duplicated Job handle.
- Worker stage injections stall after the corresponding native setup succeeds; they do not make `CreateProcessW`, `CreatePipe`, `OpenProcessToken`, Job query/termination, or handle release hang inside the Win32 call.
- Worker/Job warmup and IPC connection happened before the request timer began. No request-during-not-ready rejection case was implemented.
- The harness exercises real Windows process/Job/pipe APIs but cannot establish a hard bound for synchronous Win32 APIs. It is a local diagnostic, not G1 acceptance.

## Reproduction

From this directory, build with `build_r7.bat` in a Visual Studio 2022 x64 environment, then run `python run_r7_scenarios.py`. The frozen log contains nine serialized scenarios: normal, create_process, pipe, token, receipt, join, descendant_join, admission-sync, and admission-overlapped.
