import json
import os
import sys
import threading
import time
from pathlib import Path

ROOT = r'D:\source_code\backtrader'
sys.path.insert(0, ROOT)
from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand, run_outer_watchdog

CMD = FixedOuterCommand([sys.executable, '-c', 'pass'], ROOT, {})

class BlockingSession:
    process_created = True
    job_assignment_observed = True
    def __init__(self, mode, release_gate):
        self.mode = mode
        self.release_gate = release_gate
        self.terminate_started = None
        self.release_started = None
    def resume_launcher(self): return True
    def poll_launcher_exit_code(self): return 0 if self.mode == 'release' else None
    def poll_job_empty(self): return True if self.mode == 'release' else False
    def terminate_job(self):
        self.terminate_started = time.monotonic()
        self.release_gate.wait()
        return True
    def terminate_launcher_process(self): return True
    def release_controls(self):
        self.release_started = time.monotonic()
        self.release_gate.wait()
        return True

class Backend:
    def __init__(self, session): self.session = session
    def create_suspended_in_job(self, command, *, deadline_monotonic): return self.session
    def retain_controls(self, session): return 'fake-retained'

def run_case(mode):
    gate = threading.Event()
    session = BlockingSession(mode, gate)
    backend = Backend(session)
    started = time.monotonic()
    deadline = started + 0.24
    stop_deadline = started + (0.10 if mode == 'terminate' else 0.18)
    done = threading.Event()
    outcome = {}
    def invoke():
        try:
            outcome['result'] = run_outer_watchdog(
                CMD, backend=backend,
                deadline_monotonic=deadline,
                stop_deadline_monotonic=stop_deadline,
                poll_interval_seconds=0.01,
            )
        except BaseException as exc:
            outcome['error'] = repr(exc)
        finally:
            outcome['returned_at'] = time.monotonic()
            done.set()
    t = threading.Thread(target=invoke, daemon=True)
    t.start()
    if mode == 'terminate':
        # Wait until synchronous termination has begun, then probe past hard deadline.
        while session.terminate_started is None and time.monotonic() < deadline + 0.15:
            time.sleep(0.002)
        block_started = session.terminate_started
    else:
        while session.release_started is None and time.monotonic() < deadline + 0.15:
            time.sleep(0.002)
        block_started = session.release_started
    time.sleep(max(0.0, deadline + 0.05 - time.monotonic()))
    caller_alive_past_deadline = not done.is_set()
    observed_past_deadline = time.monotonic()
    gate.set()
    t.join(timeout=1.0)
    result = outcome.get('result')
    return {
        'case': mode,
        'hard_deadline_seconds_from_start': round(deadline - started, 3),
        'blocking_call_started': block_started is not None,
        'caller_still_blocked_after_deadline_plus_50ms': caller_alive_past_deadline,
        'probe_time_seconds_from_start': round(observed_past_deadline - started, 3),
        'probe_lateness_seconds': round(observed_past_deadline - deadline, 3),
        'returned_time_seconds_from_start': round(outcome.get('returned_at', 0) - started, 3),
        'outcome_state': getattr(result, 'state', None),
        'outcome_reason': getattr(result, 'reason', None),
        'outcome_error': outcome.get('error'),
        'fake_only': True,
        'ctp_imported': False,
        'provider_or_network_calls': 0,
    }

print(json.dumps([run_case('terminate'), run_case('release')], sort_keys=True, indent=2))


