import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import pytest

root = Path(os.environ["G4_PROBE_ROOT"]).resolve()
source = root / "source-a"
site = (Path(sys.prefix) / "Lib" / "site-packages").resolve()
assert Path(sys.prefix).resolve() != Path(sys.base_prefix).resolve()
assert "include-system-site-packages = false" in (Path(sys.prefix) / "pyvenv.cfg").read_text(encoding="utf-8").lower()
dist = importlib.metadata.distribution("bt_api_ctp")
assert dist.version == "2.0.4+g4r2.probe.20260927"
import bt_api_ctp
from bt_api_ctp.ctp import _ctp_base
import bt_api_ctp.ctp.client as client
assert Path(bt_api_ctp.__file__).resolve().is_relative_to(site)
assert Path(client.__file__).resolve().is_relative_to(site)
assert _ctp_base.is_ctp_native_loaded() is False

nodes = [
    str(source / "tests" / "test_ctp_native_lifecycle_receipt.py"),
    str(source / "tests" / "test_ctp_shutdown.py"),
    str(source / "tests" / "test_md_startup_locking.py"),
]
junit = root / "consumer-fake-junit.xml"
code = pytest.main([
    "--noconftest", "-q", "--tb=short",
    "--junitxml", str(junit),
    *nodes,
])
assert code == pytest.ExitCode.OK, f"pytest returned {code!r}"
assert Path(bt_api_ctp.__file__).resolve().is_relative_to(site)
assert Path(client.__file__).resolve().is_relative_to(site)
assert _ctp_base.is_ctp_native_loaded() is False
assert "bt_api_ctp.ctp._ctp" not in sys.modules
native_modules = sorted(
    name for name, module in sys.modules.items()
    if name == "_ctp" or name.endswith(".ctp._ctp")
)
assert not native_modules, native_modules
guard_log = Path(os.environ["G4_CTP_NATIVE_GUARD_LOG"])
blocked = [json.loads(line) for line in guard_log.read_text(encoding="utf-8").splitlines() if line]
assert blocked and all(row.get("blocked") is True for row in blocked)
result = {
    "schema": "iteration41.g4.r2.installed_fake_lifecycle_consumer.v1",
    "python": sys.executable,
    "version": dist.version,
    "bt_api_ctp_origin": bt_api_ctp.__file__,
    "client_origin": client.__file__,
    "site_packages": str(site),
    "test_nodes": nodes,
    "pytest_code": int(code),
    "junit": str(junit),
    "native_guard_blocked_imports": blocked,
    "ctp_native_loaded": _ctp_base.is_ctp_native_loaded(),
    "ctp_extension_modules_in_sys_modules": native_modules,
}
(root / "consumer-fake-result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
