@echo off
setlocal
set "ROOT=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\source-a"
set "OUT=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\wheel-a"
set "TEMP=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\scratch-a"
set "TMP=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\scratch-a"
set "STATUS=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\build-a-status.txt"
set "LOG=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\build-a.log"
> "%STATUS%" echo run_id=g4-r2-disposable-a
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x86_amd64 > "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\vcvarsall-a.log" 2>&1
if errorlevel 1 (
  >> "%STATUS%" echo vcvarsall_exit=nonzero
  exit /b 21
)
>> "%STATUS%" echo vcvarsall_exit=0
where cl.exe > "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\tool-paths-a.txt" 2>&1
if errorlevel 1 (
  >> "%STATUS%" echo where_cl_exit=nonzero
  exit /b 22
)
>> "%STATUS%" echo where_cl_exit=0
where link.exe >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\tool-paths-a.txt" 2>&1
if errorlevel 1 (
  >> "%STATUS%" echo where_link_exit=nonzero
  exit /b 23
)
>> "%STATUS%" echo where_link_exit=0
set "SOURCE_DATE_EPOCH=1790420787"
set "PYTHONHASHSEED=0"
set "PYTHONUTF8=1"
set "TZ=UTC"
set "PIP_NO_INDEX=1"
set "PIP_CONFIG_FILE=NUL"
set "CL=/Brepro"
set "LINK=/Brepro"
>> "%STATUS%" echo python=C:\Anaconda3\python.exe
>> "%STATUS%" echo SOURCE_DATE_EPOCH=%SOURCE_DATE_EPOCH%
>> "%STATUS%" echo PYTHONHASHSEED=%PYTHONHASHSEED%
>> "%STATUS%" echo PYTHONUTF8=%PYTHONUTF8%
>> "%STATUS%" echo TZ=%TZ%
>> "%STATUS%" echo PIP_NO_INDEX=%PIP_NO_INDEX%
>> "%STATUS%" echo PIP_CONFIG_FILE=%PIP_CONFIG_FILE%
>> "%STATUS%" echo CL=%CL%
>> "%STATUS%" echo LINK=%LINK%
"C:\Anaconda3\python.exe" -m pip wheel --no-deps --no-build-isolation --no-cache-dir --no-index --wheel-dir "%OUT%" "%ROOT%" > "%LOG%" 2>&1
if errorlevel 1 (
  >> "%STATUS%" echo pip_wheel_exit=nonzero
  exit /b 31
)
>> "%STATUS%" echo pip_wheel_exit=0
exit /b 0
