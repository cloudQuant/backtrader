
@echo off
setlocal
set "TEMP=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\scratch-a"
set "TMP=D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\scratch-a"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x86_amd64 > "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-vcvarsall.log" 2>&1
set "VCERR=%ERRORLEVEL%"
echo vcvarsall_exit=%VCERR% > "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt"
if not "%VCERR%"=="0" exit /b 21
where cl.exe >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt" 2>&1
where link.exe >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt" 2>&1
echo VCINSTALLDIR=%VCINSTALLDIR% >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt"
echo VSCMD_VER=%VSCMD_VER% >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt"
echo VCToolsVersion=%VCToolsVersion% >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt"
echo WindowsSDKVersion=%WindowsSDKVersion% >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt"
cl /Bv > "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\cl-version.log" 2>&1
echo cl_bv_exit=%ERRORLEVEL% >> "D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927\toolchain-facts.txt"
exit /b 0

