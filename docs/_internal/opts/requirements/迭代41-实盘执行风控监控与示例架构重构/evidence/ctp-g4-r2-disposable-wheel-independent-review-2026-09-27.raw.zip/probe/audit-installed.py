import base64
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import sys
import zipfile

root = Path(os.environ["G4_PROBE_ROOT"]).resolve()
venv = Path(sys.prefix).resolve()
site = (venv / "Lib" / "site-packages").resolve()
wheel = Path(os.environ["G4_PROBE_WHEEL"]).resolve()
guard_log = Path(os.environ["G4_CTP_NATIVE_GUARD_LOG"])
assert Path(sys.prefix).resolve() != Path(sys.base_prefix).resolve()
assert (venv / "pyvenv.cfg").read_text(encoding="utf-8").lower().find("include-system-site-packages = false") >= 0
assert not any("C:\\anaconda3\\lib\\site-packages" in p.lower() for p in sys.path)

dist = metadata.distribution("bt_api_ctp")
assert dist.version == "2.0.4+g4r2.probe.20260927", dist.version
direct_url = json.loads(dist.read_text("direct_url.json"))
assert direct_url["archive_info"]["hash"].startswith("sha256=")
assert direct_url["archive_info"]["hash"].split("=",1)[1] == hashlib.sha256(wheel.read_bytes()).hexdigest()

checked = 0
unhashed = []
for entry in dist.files or ():
    path = Path(dist.locate_file(entry)).resolve()
    try:
        path.relative_to(site)
    except ValueError:
        raise AssertionError(f"distribution file outside venv site-packages: {entry} => {path}")
    data = path.read_bytes()
    if entry.size is not None:
        assert len(data) == entry.size, (entry, len(data), entry.size)
    if entry.hash is None:
        unhashed.append(str(entry))
        continue
    digest = hashlib.new(entry.hash.mode, data).digest()
    encoded = base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")
    assert encoded == entry.hash.value, (entry, encoded, entry.hash.value)
    checked += 1

with zipfile.ZipFile(wheel) as z:
    assert z.testzip() is None
    names = z.namelist()
    rec = next(n for n in names if n.endswith(".dist-info/RECORD"))
    for name in names:
        if name.endswith(".dist-info/RECORD"):
            continue
        installed = (site / Path(name)).resolve()
        assert installed.is_file(), f"wheel file missing after install: {name}"
        assert installed.read_bytes() == z.read(name), f"wheel payload differs after install: {name}"

import bt_api_ctp
import bt_api_ctp.ctp.client as client
from bt_api_ctp.ctp import _ctp_base
assert Path(bt_api_ctp.__file__).resolve().is_relative_to(site)
assert Path(client.__file__).resolve().is_relative_to(site)
assert _ctp_base.is_ctp_native_loaded() is False
assert "bt_api_ctp.ctp._ctp" not in sys.modules
assert guard_log.exists(), "CTP extension import attempt was not observed by the guard"
blocked = [json.loads(line) for line in guard_log.read_text(encoding="utf-8").splitlines() if line]
assert blocked and all(row.get("blocked") is True for row in blocked)
native_loaded = sorted(
    name for name, module in sys.modules.items()
    if name == "_ctp" or name.endswith(".ctp._ctp")
)
assert not native_loaded, native_loaded
result = {
    "schema": "iteration41.g4.r2.installed_probe_audit.v1",
    "python": sys.executable,
    "python_prefix": str(venv),
    "python_base_prefix": sys.base_prefix,
    "system_site_packages": False,
    "distribution": dist.metadata["Name"],
    "version": dist.version,
    "wheel": str(wheel),
    "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
    "direct_url": direct_url,
    "package_origin": bt_api_ctp.__file__,
    "client_origin": client.__file__,
    "site_packages": str(site),
    "sys_path": sys.path,
    "record_hashed_rows_verified": checked,
    "record_unhashed_entries": unhashed,
    "wheel_payload_rows_compared": len(names)-1,
    "native_guard_blocked_imports": blocked,
    "ctp_native_loaded": _ctp_base.is_ctp_native_loaded(),
    "ctp_extension_modules_in_sys_modules": native_loaded,
}
out=root/"installed-audit.json"
out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result,indent=2))
