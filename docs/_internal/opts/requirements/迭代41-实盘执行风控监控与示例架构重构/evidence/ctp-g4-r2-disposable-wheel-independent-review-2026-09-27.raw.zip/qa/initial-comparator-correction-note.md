# 初次源比较结果更正记录

第一次源文件比较对三个已检出文件计算原始 SHA-256，在 tests/test_ctp_callback_ingress_client.py 上报告表面差异：基线 D:\q\e 为 2950f29a32b8fff49f293554fc3765d8c0a8e566eea0207a7444380fd9251bcd，source-a 与 source-b 都为 08f37df3b48a378e4fcb3c4980dc2e3812ce4deb446b45a7fbd29d8a6a64e4e9。这是换行差异：基线工作树为 LF，复制目录为 CRLF。依照基线仓库的 Git 路径清理规则，source-a 的 blob ID 为 158514df5a02184af081a373092a59c7d856aea7，与 HEAD 中该路径 blob 完全一致；source-b 原始 bytes 与 source-a 一致。

更正后的审计分别比较两个 source copy 中 266 个 HEAD 跟踪文件，并按 Git 路径规则规范化换行；每棵树均 0 内容差异、仅此 1 个 EOL-only 路径。两个 r2 覆盖文件原始 bytes 与冻结候选 manifest 哈希匹配。source-a 的 103 项和 source-b 的 95 项 extras 是构建/pytest 生成内容，不是跟踪输入。

第一次比较脚本和原始日志未作为独立文件保留；最终审计记录保留原始 SHA 摘要和 Git blob 复核结果。早期审计脚本还因对 git status 空白、pip 退出码格式及本次 A/B wheel 自身计入扫描范围的检查器假设有误而短暂报告失败；更正检查器后最终失败列表为空。这些是 QA 检查器修正，不是候选失败。
