from __future__ import annotations
import base64, csv, hashlib, io, json, os, re, subprocess, sys, zipfile
from pathlib import Path, PurePosixPath
import xml.etree.ElementTree as ET

P = Path(r"D:\temp\iteration41-g4-lifecycle-r2-repro-probe-20260927")
QA = Path(r"D:\temp\iteration41-g4-lifecycle-r2-independent-qa-20260927")
failures = []
notes = []
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def check(label, ok, value=None):
    if not ok: failures.append({"check": label, "value": value})
    return bool(ok)
def readj(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def git(path, *args):
    cp = subprocess.run(["git", "-C", str(path), *args], check=True, capture_output=True, text=True)
    return cp.stdout.strip()
def git_status(path):
    cp = subprocess.run(["git", "-C", str(path), "status", "--porcelain=v1", "--untracked-files=all"], check=True, capture_output=True, text=True)
    return cp.stdout
def git_blob(path, rev, rel):
    cp = subprocess.run(["git", "-C", str(path), "show", f"{rev}:{rel}"], check=True, capture_output=True)
    return cp.stdout
def safe_rel(s):
    q = PurePosixPath(s.replace("\\", "/"))
    return not q.is_absolute() and ".." not in q.parts

receipt = readj(P / "freeze-receipt.json")
em = readj(P / "freeze-evidence-manifest.json")
source_manifest = readj(P / "source-manifest.json")
source_inputs = readj(P / "source-input-hashes.json")
repro = readj(P / "wheel-repro-manifest.json")
record_report = readj(P / "wheel-record-validation.json")
installed = readj(P / "installed-audit.json")
consumer = readj(P / "consumer-fake-result.json")
identities = readj(P / "existing-wheel-identities.json")
tool = readj(P / "build-toolchain.json")
objects = readj(P / "build-object-audit.json")

receipt_sha = sha_file(P / "freeze-receipt.json")
manifest_sha = sha_file(P / "freeze-evidence-manifest.json")
readme_sha = sha_file(P / "README.md")
check("freeze receipt sha", receipt_sha == "4b23afe25c80830b01409e7319f5b27a94ab29456ed2b775e304049b57023671", receipt_sha)
check("evidence manifest sha", manifest_sha == "d579ef460d9fd1b9e03364f7e96f9c58cf1afc78b72eaa326bcb7225829c9dc7", manifest_sha)
check("README sha", readme_sha == "96eeb81ebce64b5512a43572d9847b9f8f8572854f21c499add98a65fc0c18a7", readme_sha)
check("receipt references manifest hash", receipt["evidence_manifest_sha256"] == manifest_sha, receipt["evidence_manifest_sha256"])
check("r2 source freeze hash", source_inputs["r2_freeze_manifest"]["sha256"] == "e55d077572ee7f071d3d0ad0fd74522618e1e338a6e38e9963ed6ef76d2f15ee")

manifest_file_results = []
for row in em["files"]:
    path = P / Path(row["path"])
    exists = path.is_file()
    actual_size = path.stat().st_size if exists else None
    actual_sha = sha_file(path) if exists else None
    good = exists and actual_size == row["size"] and actual_sha == row["sha256"]
    manifest_file_results.append({"path": row["path"], "size_ok": exists and actual_size == row["size"], "sha_ok": exists and actual_sha == row["sha256"], "actual_size": actual_size, "actual_sha256": actual_sha})
    check("evidence member " + row["path"], good, manifest_file_results[-1])

probe_version = receipt["probe_version"]
expected_wheel_sha = receipt["wheel_sha256"]
wheel_paths = [P / Path(row["path"]) for row in em["wheels"]]
wheel_results = []
all_member_hashes = []
records = []
wheel_members = []
for wp in wheel_paths:
    data = wp.read_bytes()
    digest = sha_bytes(data)
    check("wheel file sha " + wp.name, digest == expected_wheel_sha, digest)
    with zipfile.ZipFile(wp) as z:
        bad_member = z.testzip()
        names = z.namelist()
        check("wheel zip test " + wp.name, bad_member is None, bad_member)
        check("wheel unique member names " + wp.name, len(names) == len(set(names)), {"members": len(names), "unique": len(set(names))})
        member_map = {n: sha_bytes(z.read(n)) for n in names}
        rec_names = [n for n in names if n.endswith(".dist-info/RECORD")]
        check("one RECORD " + wp.name, len(rec_names) == 1, rec_names)
        rec_name = rec_names[0] if rec_names else ""
        rows = list(csv.reader(io.StringIO(z.read(rec_name).decode("utf-8")))) if rec_name else []
        rec_by_path = {}
        for row in rows:
            if len(row) != 3 or row[0] in rec_by_path:
                failures.append({"check": "RECORD row shape/duplicate " + wp.name, "value": row})
                continue
            rec_by_path[row[0]] = row[1:]
        check("RECORD exact member set " + wp.name, set(rec_by_path) == set(names), {"record_only": sorted(set(rec_by_path)-set(names)), "zip_only": sorted(set(names)-set(rec_by_path))})
        hashed = 0
        unchecked = []
        unsafe = []
        for name in names:
            if not safe_rel(name): unsafe.append(name)
            if name == rec_name:
                check("RECORD self row blank " + wp.name, rec_by_path.get(name) == ["", ""], rec_by_path.get(name))
                continue
            hash_field, size_field = rec_by_path.get(name, ["", ""])
            raw = z.read(name)
            if not hash_field:
                unchecked.append(name)
                continue
            algorithm, encoded = hash_field.split("=", 1)
            actual_encoded = base64.urlsafe_b64encode(hashlib.new(algorithm, raw).digest()).decode("ascii").rstrip("=")
            ok = actual_encoded == encoded and str(len(raw)) == size_field
            check("RECORD payload " + wp.name + ":" + name, ok, {"hash": actual_encoded, "expected": encoded, "size": len(raw), "expected_size": size_field})
            hashed += 1
        check("RECORD unsafe paths " + wp.name, not unsafe, unsafe)
        metadata_names = [n for n in names if n.endswith(".dist-info/METADATA")]
        metadata_text = z.read(metadata_names[0]).decode("utf-8") if metadata_names else ""
        name_field = next((x.split(":",1)[1].strip() for x in metadata_text.splitlines() if x.startswith("Name:")), None)
        version_field = next((x.split(":",1)[1].strip() for x in metadata_text.splitlines() if x.startswith("Version:")), None)
        check("wheel version " + wp.name, version_field == probe_version, version_field)
        wheel_results.append({"path": str(wp), "size": len(data), "sha256": digest, "zip_testzip": bad_member, "member_count": len(names), "member_sha256": member_map, "record_rows": len(rows), "record_hashed_payloads": hashed, "record_unhashed": unchecked, "unsafe_paths": unsafe, "name": name_field, "version": version_field})
        wheel_members.append(member_map)
        records.append({"record_rows": len(rows), "hashed_payloads": hashed, "unhashed": unchecked})
if len(wheel_members) == 2:
    check("A/B member set equality", set(wheel_members[0]) == set(wheel_members[1]), {"a":len(wheel_members[0]),"b":len(wheel_members[1])})
    diffs = [n for n in set(wheel_members[0]) | set(wheel_members[1]) if wheel_members[0].get(n) != wheel_members[1].get(n)]
    check("A/B all member bytes equal", not diffs, diffs)
    check("wheel manifest reports same hashes", repro["wheels"][0]["wheel_sha256"] == repro["wheels"][1]["wheel_sha256"] == expected_wheel_sha)
    check("source install version is disposable", probe_version.endswith(".probe.20260927") and all(w["version"] == probe_version for w in wheel_results))
unique_collision = [r for r in identities["rows"] if r.get("version") == probe_version and not str(r.get("path","")).lower().startswith(str(P).lower())]
check("probe version unique vs existing scan", not unique_collision, unique_collision)
check("existing identity scan covers 28 wheels", identities.get("wheel_files_scanned") == 28 and len(identities["rows"]) == 28, {"scanned":identities.get("wheel_files_scanned"),"rows":len(identities["rows"])})

base = Path(r"D:\q\e")
candidate = Path(r"D:\temp\iteration41_g4_native_lifecycle_receipt_candidate_20260927_r2")
base_head = git(base, "rev-parse", "HEAD")
base_status = git_status(base)
candidate_head = git(candidate, "rev-parse", "HEAD")
candidate_status = git_status(candidate)
check("base HEAD", base_head == source_manifest["base_head"] == "29f8ff171f61a71038328a7067e0909bf44774b2", base_head)
check("base worktree clean", not base_status, base_status)
check("candidate HEAD equals base", candidate_head == source_manifest["base_head"], candidate_head)
candidate_status_paths = [line[3:].replace("\\","/") for line in candidate_status.splitlines()]
expected_candidate_status = ["src/bt_api_ctp/ctp/client.py", "tests/test_ctp_native_lifecycle_receipt.py"]
check("r2 candidate status only exact two overlay paths", set(candidate_status_paths) == set(expected_candidate_status), candidate_status)
freeze_path = Path(source_inputs["r2_freeze_manifest"]["path"])
freeze_sha = sha_file(freeze_path)
check("candidate r2 manifest hash", freeze_sha == source_inputs["r2_freeze_manifest"]["sha256"], freeze_sha)
freeze = readj(freeze_path)
freeze_changed = {row["path"]:row["sha256"].lower() for row in freeze["changed_files"]}
check("freeze manifest changed path set", set(freeze_changed) == set(expected_candidate_status), sorted(freeze_changed))
for rel, expected in freeze_changed.items():
    actual = sha_file(candidate / Path(rel))
    check("candidate exact overlay " + rel, actual == expected, actual)
for item in source_inputs["clean_baseline_inputs"]:
    rel = item["path"].split(" (",1)[0]
    actual = sha_file(base / Path(rel))
    check("baseline source hash " + rel, actual == item["sha256"], actual)

# Compare every tracked HEAD file in the clean base to the two materialized build roots,
# with the two r2 overlays and the single disposable pyproject version substitution.
tracked = git(base, "ls-tree", "-r", "--name-only", "HEAD").splitlines()
source_checks = []
probe_line = b'2.0.4+iteration41.i9'
version_line = b'2.0.4+g4r2.probe.20260927'
overlay_paths = set(expected_candidate_status)
expected_pyproject_sha = {s["label"]:s["pyproject_sha256"].lower() for s in source_manifest["sources"]}
for label in ("a","b"):
    src = P / ("source-" + label)
    mismatches = []
    eol_only = []
    expected_set = set(tracked)
    for rel in tracked:
        actual_path = src / Path(rel)
        if not actual_path.is_file():
            mismatches.append({"path":rel,"problem":"missing"})
            continue
        if rel in overlay_paths:
            exp = (candidate / Path(rel)).read_bytes()
            if actual_path.read_bytes() != exp:
                mismatches.append({"path":rel,"problem":"overlay bytes differ","expected_sha":sha_bytes(exp),"actual_sha":sha_file(actual_path)})
        elif rel == "pyproject.toml":
            exp = (base / "pyproject.toml").read_bytes()
            count = exp.count(probe_line)
            if count != 1:
                mismatches.append({"path":rel,"problem":"expected one base version token","count":count})
            exp = exp.replace(probe_line, version_line)
            check("materialized pyproject hash " + label, sha_bytes(exp) == expected_pyproject_sha[label], sha_bytes(exp))
            if actual_path.read_bytes() != exp:
                mismatches.append({"path":rel,"problem":"version-only disposable metadata differs","expected_sha":sha_bytes(exp),"actual_sha":sha_file(actual_path)})
        else:
            expected = (base / Path(rel)).read_bytes()
            actual = actual_path.read_bytes()
            if actual != expected:
                if b"\x00" in actual or b"\x00" in expected or actual.replace(b"\r\n", b"\n") != expected.replace(b"\r\n", b"\n"):
                    mismatches.append({"path":rel,"problem":"content differs beyond CRLF normalization","expected_sha":sha_bytes(expected),"actual_sha":sha_bytes(actual)})
                else:
                    eol_only.append(rel)
    extras = []
    for fp in src.rglob("*"):
        if fp.is_file():
            rel = fp.relative_to(src).as_posix()
            if rel not in expected_set:
                extras.append(rel)
    check("all base tracked inputs plus exact r2/version overlay in source-" + label, not mismatches, mismatches[:20])
    source_checks.append({"label":label,"tracked_count":len(tracked),"mismatch_count":len(mismatches),"eol_only_normalization_count":len(eol_only),"eol_only_paths":eol_only,"generated_extra_count":len(extras),"generated_extras_sample":extras[:30],"mismatches_sample":mismatches[:20]})
# Overlay and baseline input hashes in each source tree
for s in source_manifest["sources"]:
    src=Path(s["path"])
    for rel, expected in s["source_overlays"].items():
        actual=sha_file(src/Path(rel))
        check("materialized overlay " + s["label"] + ":" + rel, actual == expected.lower(), actual)
    check("materialized setup hash " + s["label"], sha_file(src/"setup.py") == s["setup_sha256"].lower())
    check("materialized wrapper hash " + s["label"], sha_file(src/"src/bt_api_ctp/ctp/ctp_wrap.cpp") == s["wrapper_sha256"].lower())
    check("materialized version field " + s["label"], s["probe_version"] == probe_version)

# Build isolation and documented reproducibility caveat.
cmd_a=(P/"build-a.cmd").read_text(errors="replace").lower()
cmd_b=(P/"build-b.cmd").read_text(errors="replace").lower()
check("distinct build command roots", "source-a" in cmd_a and "wheel-a" in cmd_a and "scratch-a" in cmd_a and "source-b" in cmd_b and "wheel-b" in cmd_b and "scratch-b" in cmd_b, {"a":cmd_a,"b":cmd_b})
obj_map={}
for row in objects["objects"]:
    rel=row["relative"].split("\\")[-1]
    obj_map.setdefault(rel,{})[row["label"]]=row["sha256"]
obj_diffs={rel: v for rel,v in obj_map.items() if set(v)=={"a","b"} and v["a"]!=v["b"]}
final_native_equal=all(
    obj_map.get(n,{}).get("a")==obj_map.get(n,{}).get("b")
    for n in ("_ctp.cp311-win_amd64.pyd","thostmduserapi_se.dll","thosttraderapi_se.dll")
)
check("final extension and bundled DLL build outputs equal", final_native_equal, obj_map)
notes.append({"intermediate_object_hash_differences":obj_diffs,"final_native_outputs_equal":final_native_equal})
for label in ("a","b"):
    stat=(P/f"build-{label}-status.txt").read_text(errors="replace")
    log=(P/f"build-{label}.log").read_text(errors="replace")
    check(f"build {label} exit status", "pip_wheel_exit=0" in stat and "Successfully built bt_api_ctp" in log)

# Installed venv, origin, direct_url, RECORD and installed payload bytes.
venv=Path(installed["python_prefix"])
site=Path(installed["site_packages"])
cfg=(venv/"pyvenv.cfg").read_text(encoding="utf-8").lower()
check("consumer no system site packages", "include-system-site-packages = false" in cfg and installed["system_site_packages"] is False)
check("consumer version unique", installed["version"]==probe_version)
check("package/client import origin under venv site-packages", Path(installed["package_origin"]).is_relative_to(site) and Path(installed["client_origin"]).is_relative_to(site), {"package":installed["package_origin"],"client":installed["client_origin"],"site":str(site)})
du_path=site/"bt_api_ctp-2.0.4+g4r2.probe.20260927.dist-info"/"direct_url.json"
du=readj(du_path)
direct_sha=du["archive_info"]["hash"].split("=",1)[1]
check("installed direct_url wheel hash", direct_sha == expected_wheel_sha, direct_sha)
check("installed audit reports wheel hash and RECORD/payload counts", installed["wheel_sha256"]==expected_wheel_sha and installed["record_hashed_rows_verified"]==92 and installed["wheel_payload_rows_compared"]==89, {"wheel_sha":installed["wheel_sha256"],"record_rows":installed["record_hashed_rows_verified"],"wheel_payload_rows":installed["wheel_payload_rows_compared"]})
# Validate installed distribution's current RECORD against current installed bytes, without importing it.
inst_record=site/"bt_api_ctp-2.0.4+g4r2.probe.20260927.dist-info"/"RECORD"
inst_rows=list(csv.reader(inst_record.read_text(encoding="utf-8").splitlines()))
inst_checked=0
inst_unhashed=[]
inst_bad=[]
for row in inst_rows:
    if len(row)!=3: inst_bad.append({"row":row,"problem":"shape"}); continue
    rel,hf,size=row
    if not safe_rel(rel): inst_bad.append({"path":rel,"problem":"unsafe"}); continue
    path=(site/Path(rel)).resolve()
    try: path.relative_to(site.resolve())
    except ValueError: inst_bad.append({"path":rel,"problem":"escapes site"}); continue
    if not path.is_file(): inst_bad.append({"path":rel,"problem":"missing"}); continue
    data=path.read_bytes()
    if size and len(data)!=int(size): inst_bad.append({"path":rel,"problem":"size","actual":len(data),"expected":size})
    if hf:
        alg,enc=hf.split("=",1)
        got=base64.urlsafe_b64encode(hashlib.new(alg,data).digest()).decode("ascii").rstrip("=")
        if got!=enc: inst_bad.append({"path":rel,"problem":"hash","actual":got,"expected":enc})
        inst_checked+=1
    else:
        inst_unhashed.append(rel)
check("installed RECORD hashes/paths", not inst_bad, inst_bad[:20])
# Compare all wheel members except wheel RECORD against installed file bytes.
installed_payload_diffs=[]
with zipfile.ZipFile(wheel_paths[0]) as z:
    wheel_record=next(n for n in z.namelist() if n.endswith(".dist-info/RECORD"))
    for n in z.namelist():
        if n==wheel_record: continue
        actual_path=(site/Path(n)).resolve()
        if not actual_path.is_file() or actual_path.read_bytes()!=z.read(n):
            installed_payload_diffs.append(n)
check("installed wheel payload byte equality", not installed_payload_diffs, installed_payload_diffs[:30])
native_files=[]
with zipfile.ZipFile(wheel_paths[0]) as z:
    for n in z.namelist():
        if n.endswith(".pyd") or n.lower().endswith(".dll"):
            installed_path=(site/Path(n)).resolve()
            native_files.append({"wheel_member":n,"wheel_sha256":sha_bytes(z.read(n)),"installed_sha256":sha_file(installed_path) if installed_path.is_file() else None,"installed_present":installed_path.is_file(),"bytes_equal":installed_path.is_file() and installed_path.read_bytes()==z.read(n)})
check("installed native payload bytes equal wheel (not mapped-loaded)", all(r["bytes_equal"] for r in native_files), native_files)
pip_check=(P/"pip-check.txt").read_text(encoding="utf-8").strip()
pip_exit=(P/"pip-check-exit.txt").read_text(encoding="utf-8").strip()
check("pip check", pip_check=="No broken requirements found." and pip_exit=="exit_code=0", {"output":pip_check,"exit":pip_exit})

# Fake-test outputs and native guard.
jroot=ET.parse(P/"consumer-fake-junit.xml").getroot()
suite=(jroot.find("testsuite") if jroot.tag=="testsuites" else jroot)
tests=int(suite.attrib.get("tests","-1")); fails=int(suite.attrib.get("failures","-1")); errs=int(suite.attrib.get("errors","-1")); skipped=int(suite.attrib.get("skipped","-1"))
test_log=(P/"consumer-fake-tests.log").read_text(encoding="utf-8",errors="replace")
check("installed fake JUnit 66 tests clean", (tests,fails,errs,skipped)==(66,0,0,0), (tests,fails,errs,skipped))
check("installed fake log matches 66 passed", "66 passed" in test_log and consumer["pytest_code"]==0, test_log[-700:])
config_warning_count=test_log.count("PytestConfigWarning")
runtime_warning_count=test_log.count("RuntimeWarning: CTP C++ extension")
notes.append({"pytest_config_warning_count":config_warning_count,"ctp_extension_block_runtime_warning_count":runtime_warning_count})
guard_rows=[json.loads(line) for line in (P/"native-import-guard.log").read_text(encoding="utf-8").splitlines() if line]
check("native import attempts blocked before extension", len(guard_rows)==2 and all(r.get("blocked") is True and r.get("module")=="bt_api_ctp.ctp._ctp" for r in guard_rows), guard_rows)
check("no CTP extension loaded in installed audit", installed["ctp_native_loaded"] is False and not installed["ctp_extension_modules_in_sys_modules"] and consumer["ctp_native_loaded"] is False and not consumer["ctp_extension_modules_in_sys_modules"])
sitecustomize=(P/"native-guard/sitecustomize.py").read_text(encoding="utf-8")
check("guard is first meta-path finder and raises", "sys.meta_path.insert(0" in sitecustomize and "raise ModuleNotFoundError" in sitecustomize)
check("no-index build/offline consumer declarations", "PIP_NO_INDEX=1" in (P/"commands-and-environment.txt").read_text() and "--no-index" in (P/"commands-and-environment.txt").read_text())
check("no provider/session acceptance disclaimer", receipt["status"]=="FOCUSED_READY_FOR_INDEPENDENT_QA" and any("No real CTP native session" in x for x in receipt["limitations"]))

# Recompute key source state after all prior read-only work.
base_status_after=git_status(base)
candidate_status_after=git_status(candidate)
check("base worktree remains clean at postcheck", not base_status_after, base_status_after)
for rel,expected in freeze_changed.items():
    check("candidate postcheck " + rel, sha_file(candidate/Path(rel))==expected, sha_file(candidate/Path(rel)))

summary={
 "schema":"iteration41.g4.r2.disposable_wheel_independent_qa.v1",
 "classification":"WHEEL_SOURCE_FAKE_INSTALLATION_PASS / G4_NATIVE_CLOSE_CLOSED / DEFAULT_PIN_CLOSED",
 "probe_root":str(P),
 "receipt_sha256":receipt_sha,
 "evidence_manifest_sha256":manifest_sha,
 "readme_sha256":readme_sha,
 "evidence_files_verified":len(manifest_file_results),
 "evidence_manifest_failures":[x for x in manifest_file_results if not (x["size_ok"] and x["sha_ok"])],
 "base":{"path":str(base),"head":base_head,"clean_before":not bool(base_status),"clean_after":not bool(base_status_after)},
 "candidate":{"path":str(candidate),"head":candidate_head,"expected_changed_paths":expected_candidate_status,"changed_overlay_hashes":freeze_changed,"freeze_manifest_sha256":freeze_sha,"status_before_after":candidate_status_after},
 "source_copies":source_checks,
 "probe_version":probe_version,
 "version_scan":{"scanned":identities["wheel_files_scanned"],"collision_count":len(unique_collision)},
 "wheels":[{k:v for k,v in wr.items() if k!="member_sha256"} for wr in wheel_results],
 "wheel_member_sets_and_hashes_equal":not any(f["check"].startswith("A/B") for f in failures),
 "wheel_record":[{"wheel":str(wheel_paths[i]),"rows":records[i]["record_rows"],"hashed_payloads":records[i]["hashed_payloads"],"unhashed":records[i]["unhashed"]} for i in range(len(records))],
 "installed":{"venv":str(venv),"system_site_packages":False,"version":installed["version"],"direct_url_sha256":direct_sha,"package_origin":installed["package_origin"],"client_origin":installed["client_origin"],"installed_record_rows":len(inst_rows),"installed_record_hashed_rows_checked":inst_checked,"installed_record_unhashed_entries":inst_unhashed,"installed_record_failures":inst_bad,"wheel_payload_equal":not installed_payload_diffs,"native_payload_files":native_files,"pip_check":pip_check,"pip_check_exit":pip_exit},
 "fake_consumer":{"junit":{"tests":tests,"failures":fails,"errors":errs,"skipped":skipped},"pytest_config_warning_count":config_warning_count,"native_guard_runtime_warning_count":runtime_warning_count,"native_guard_rows":guard_rows,"native_loaded":False},
 "build":{"a_exit0":"pip_wheel_exit=0" in (P/"build-a-status.txt").read_text(),"b_exit0":"pip_wheel_exit=0" in (P/"build-b-status.txt").read_text(),"distinct_roots":True,"toolchain":tool["msvc"],"intermediate_object_differences":obj_diffs,"final_native_outputs_equal":final_native_equal},
 "warnings_or_boundaries":[
    "Consumer fake log contains a RuntimeWarning caused by the deliberate _ctp import guard in addition to the PytestConfigWarning; it is not only a single-warning log.",
    "Intermediate ctp_wrap.obj hashes differ between A/B, while final _ctp.pyd, bundled DLLs and wheels are byte-identical.",
    "Installed packaged DLL byte hashes match wheel members, but the extension was deliberately blocked and no DLL was mapped/loaded."
 ],
 "notes":notes,
 "checks_failed":failures
}
(QA/"independent-qa-summary.json").write_text(json.dumps(summary,indent=2)+chr(10),encoding="utf-8")
print(json.dumps({"checks_total":len(manifest_file_results)+len(wheel_results)*10+len(failures),"manifest_files":len(manifest_file_results),"wheels":[{k:v for k,v in wr.items() if k!="member_sha256"} for wr in wheel_results],"source_copies":source_checks,"installed_record":{"rows":len(inst_rows),"hashed_checked":inst_checked,"unhashed":len(inst_unhashed),"failures":inst_bad},"warnings":notes,"failed_checks":failures,"summary":str(QA/"independent-qa-summary.json")},indent=2))
if failures: sys.exit(1)
