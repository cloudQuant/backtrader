import hashlib, json
from pathlib import Path
root=Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a")
manifest_path=root/'manifest.json'
manifest_bytes=manifest_path.read_bytes()
manifest=json.loads(manifest_bytes)
rows=[]
for item in manifest['files']:
    path=root/item['path']
    data=path.read_bytes()
    actual=hashlib.sha256(data).hexdigest()
    rows.append({'path':item['path'],'bytes_expected':item['bytes'],'bytes_actual':len(data),'sha256_expected':item['sha256'],'sha256_actual':actual,'ok':len(data)==item['bytes'] and actual==item['sha256']})
result={'manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'source_commit':manifest['source_commit'],'source_label':manifest['source_label'],'file_count':len(rows),'all_payloads_match':all(r['ok'] for r in rows),'files':rows}
out=Path(r"D:\temp\iteration41_v20_r2_independent_review_20260927\snapshot_verification.json")
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
