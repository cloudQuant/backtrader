# Iteration 41 V20 R2 independent review

- Snapshot: `D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a`
- Snapshot manifest SHA-256: `15c37a6cc5503127c63d6987b9de0fd71a48181fc33dff5a4e52f57a8fc5d129`
- Source commit: `33d132d6f9d16f64cc229f576435b0fafc6bfab1`
- All 29 payload entries independently rehashed; all matched declared byte counts and SHA-256.

## Results

- Independent factory/family focus: `28 passed` (pytest 8.0.0, Python 3.11.5), command `PYTHONPATH=src; PYTHONDONTWRITEBYTECODE=1; python -m pytest -p no:cacheprovider tests/test_ctp_account_store_factory.py tests/test_ctp_account_family_owner.py -q --tb=short`.
- Additional public API probe rejected same-Store B owner, B lease, generic-provider lease, B identity read, B OrderRef reservation, B lease release, and B callback-session owner. No family-owner/lease/reservation/session rows were written by these rejected calls. Account A owner+lease succeeded afterward.
- Raw-constructor reopen preserved the account-B rejection and did not reissue the permanently persisted family owner.
- Code/test review confirms explicit cases for raw reopen, same-Store account mismatch and generic-provider mismatch, foreign family-owner rows, orphan writer lease rows, foreign execution/cancellation rows, and foreign CTP callback-session/dispatch-command rows. The preflight path is read-only and rejects those fixtures before rewrite.

## Scope

The reviewed guard binds a factory-opened database to one exact canonical CTP `account_ref`; it permits same-account strategy/day siblings under the one environment owner, rejects another account/provider, and rejects reopen/reissue of a persistent owner. This is ordinary API misuse and durable-history validation, not a claim of defense against hostile in-process Python or filesystem/database administrators.
