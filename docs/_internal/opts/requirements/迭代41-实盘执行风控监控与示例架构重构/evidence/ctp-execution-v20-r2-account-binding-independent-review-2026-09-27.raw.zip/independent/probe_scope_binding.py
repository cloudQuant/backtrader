from __future__ import annotations
import hashlib, json, tempfile, time
from pathlib import Path
from bt_api_execution import ContractValidationError, DurableStoreError, ExecutionScope, SqliteExecutionStore, WriterLease

def scope(label: str, provider: str = 'ctp', environment: str = 'simulation', strategy: str = 'strategy.one', day: str = '20260926') -> ExecutionScope:
    ref = 'ctp-account-ref.v1:' + hashlib.sha256(label.encode('ascii')).hexdigest() if provider == 'ctp' else label
    return ExecutionScope(provider, environment, ref, strategy, day)

base = Path(tempfile.mkdtemp(prefix='v20-r2-scope-probe-'))
path = base / 'bound.sqlite3'
a, b, generic = scope('A'), scope('B'), scope('generic', provider='fake', environment='offline')
store = SqliteExecutionStore.open_ctp_account_store(path, a)
checks = []
def rejects(name, callable_, expected):
    try:
        callable_()
    except expected:
        checks.append({'case': name, 'result': 'rejected'})
    else:
        raise AssertionError(f'{name} was accepted')

rejects('same-store foreign account family owner', lambda: store.acquire_ctp_account_family_owner(b), ContractValidationError)
rejects('same-store foreign account lease', lambda: store.acquire_or_renew_lease(b, 'writer-b', ttl_ns=30_000_000_000), ContractValidationError)
rejects('same-store generic provider lease', lambda: store.acquire_or_renew_lease(generic, 'writer-g', ttl_ns=30_000_000_000), ContractValidationError)
rejects('same-store foreign identity read', lambda: store.read_ctp_account_store_identity(b), DurableStoreError)
rejects('same-store foreign OrderRef reservation', lambda: store.reserve_ctp_order_identity(b, 'intent-b', 'bt-managed-v1:' + 'a' * 64), ContractValidationError)
rejects('same-store foreign lease release', lambda: store.release_lease(b, 'writer-b', fencing_token=1), ContractValidationError)
foreign_lease = WriterLease(b.account_key, 'writer-b', 1, time.time_ns() + 30_000_000_000)
rejects('same-store foreign callback-session owner', lambda: store.create_ctp_callback_session_owner(b, writer_lease=foreign_lease), ContractValidationError)
counts = {table: store._connection.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0] for table in ('ctp_account_family_owners','execution_writer_leases','ctp_order_identity_reservations','ctp_dispatch_callback_session_owners')}
assert counts == {'ctp_account_family_owners': 0, 'execution_writer_leases': 0, 'ctp_order_identity_reservations': 0, 'ctp_dispatch_callback_session_owners': 0}, counts
owner_a = store.acquire_ctp_account_family_owner(a)
lease_a = store.acquire_or_renew_lease(a, 'writer-a', ttl_ns=30_000_000_000, ctp_account_family_owner=owner_a)
assert lease_a.family_owner_intent_id == owner_a.owner_intent_id
checks.append({'case':'valid bound-account owner and lease after rejected probes','result':'accepted'})
store.close()
raw = SqliteExecutionStore(path)
try:
    rejects('raw-reopen foreign account owner', lambda: raw.acquire_ctp_account_family_owner(b), ContractValidationError)
    rejects('raw-reopen foreign account lease', lambda: raw.acquire_or_renew_lease(b, 'writer-b', ttl_ns=30_000_000_000), ContractValidationError)
    try:
        raw.acquire_ctp_account_family_owner(a)
    except Exception as exc:
        checks.append({'case':'raw-reopen exact account handle is unavailable as intended','result':type(exc).__name__})
    else:
        raise AssertionError('reopen reissued persistent owner')
finally:
    raw.close()
print(json.dumps({'db':str(path),'checks':checks,'side_effect_counts_before_A':counts},indent=2))

