# Independent QA receipt — parent cancellation-release composition freeze r2

Date: 2026-09-27 (Asia/Singapore)
Scope: independent read-only verification of the frozen local fake/offline parent cancellation-release composition.

## Frozen identity and payload

- Snapshot: `D:\temp\iteration41-cancel-control-composition-freeze-r2-20260927`
- Manifest: `D:\temp\iteration41-cancel-control-composition-evidence-r2-20260927\snapshot-manifest.json`
- Manifest SHA-256: `B52E918A07195847B4011D1F68B476486AB4FB17E6DCFF8E49EAAABE1BABAE3D` (matches the requested digest).
- All 1,013 manifest payload entries exist with matching byte sizes and SHA-256 hashes. The actual file set is exact: no missing files, extra files, or symlinks.
- All four external input artifacts, all three `main_files`, and the frozen `focused.log`/`focused.xml` hashes match the manifest. The frozen result is `23 passed, 1 warning, exit 0`; its recorded warning is the QA venv's unrecognized `asyncio_default_fixture_loop_scope` pytest option.

## Independent 23-item focused run

Ran the manifest's two focused test files from the frozen snapshot using its specified QA venv, with bytecode writes disabled, pytest cache disabled, and basetemp/JUnit/stdout in this independent QA directory. Result: **23 passed, exit 0** in 8.82 seconds under Python 3.11.5 / pytest 8.2.2. This run did not reproduce the frozen run's configuration warning. Snapshot payload verification was repeated after pytest; all 1,013 files still match and there are no extra files, so the candidate remained unchanged.

## RELEASED replay review

Reviewed `bt_api_py/runtime_plugins/cancellation_control.py` and `tests/test_cancellation_dispatch_resolution_control.py` in the hash-verified snapshot.

- `release_cancel_freeze()` routes a command whose durable status is `RELEASED` to `_resume_released_command()` before returning the idempotent success result.
- Replay validates the release-applied timestamp, durable reconciliation evidence/current cancellation record, stored typed dispatch proof, and current fake-dispatch authority. It checks that the unknown-outcome and typed dispatch-inflight causes are already absent.
- `_verify_release_prepared_monitor_fact()` then opens the composed `monitor.sqlite3` using a SQLite URI with `mode=ro`. It selects the prepared event by exact event ID, reconstructs the expected event, and compares its fingerprint, scope, event type, serialized data, and occurrence time.
- Only after that readback succeeds does replay call `resolve_cancel_dispatch_freeze(proof)`, then conditionally clear the final `cancel-release-in-progress:<scope>:<cancel>` risk cause. The final progress-latch resolution is therefore ordered after the read-only outbox check.
- If readback fails, replay enters `_reassert_after_failed_release()`, which writes and verifies both `cancel-outcome-unknown:<scope>:<cancel>` and `cancel-release-in-progress:<scope>:<cancel>` risk freezes, marks the local audit command reasserted, and raises `CANCELLATION_CONTROL_RELEASE_RECOVERY_FAILED`.
- The parameterized deleted/corrupted-outbox tests first simulate a crash after the RELEASED audit commit and before the final latch clear. On replay, both mutations fail closed; the tests assert both risk freezes are active and the audit command is back to pending. The intact-outbox restart case asserts that the final latch can be cleared.

Code locations: `release_cancel_freeze()` near line 1113, `_resume_released_command()` near line 1502, `_verify_release_prepared_monitor_fact()` near line 1581, `_reassert_after_failed_release()` near line 1894, and the deleted/corrupted event test near line 509.

## Side effects and acceptance boundary

For the frozen RELEASED replay path, the reviewed effects are local SQLite audit/risk updates, read-only monitor-outbox verification, and local fake-authority/facade reads. The path does not call a CTP SDK/provider, broker, network, or account endpoint. On an outbox failure it deliberately performs local writes to reassert the two risk freezes and audit that recovery state.

The constructor accepts a deployment-supplied `authorize` callable. The RELEASED replay branch is taken before that callback, so it is not called during these idempotent replays. A caller can still supply arbitrary behavior to the callback on a first-time release; this offline fixture does not qualify that deployment-owned callback. Also, the monitor check and risk-latch mutation use separate SQLite stores; this verifies exact ordering and fails closed for deleted/corrupt rows observed at readback, but it does not create a cross-database atomic transaction or prove resistance to concurrent external tampering of local files.

This is **local fake/offline composition evidence only**. It changes no default CTP route and accepts no real account, provider, network, SDK-native, or production cancellation-release behavior.

## Independent evidence files

- `snapshot-verification.json`: all manifest payload/input/test-log checks.
- `focused.log`, `focused.xml`, `focused-status.txt`: independent isolated 23-item run.
- `verify_snapshot.py`: read-only hash verifier for the manifest and payload.
- `receipt.md`: this review.
- `evidence-manifest.json`: hashes of this receipt and the independent evidence artifacts.
