from __future__ import annotations
import hashlib,json,os
from pathlib import Path
manifest_path=Path(r'D:\temp\iteration41-cancel-control-composition-evidence-r2-20260927\snapshot-manifest.json')
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
root=Path(manifest['snapshot_root'])
def sha(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
listed={item['path'].replace('\\','/'):item for item in manifest['snapshot_files']}
actual=set()
symlinks=[]
for cur,dirs,files in os.walk(root,followlinks=False):
    base=Path(cur)
    for d in list(dirs):
        q=base/d
        if q.is_symlink(): symlinks.append(q.relative_to(root).as_posix()); dirs.remove(d)
    for f in files:
        p=base/f
        rel=p.relative_to(root).as_posix()
        actual.add(rel)
        if p.is_symlink(): symlinks.append(rel)
missing=sorted(set(listed)-actual)
extra=sorted(actual-set(listed))
changed=[]
for rel,item in listed.items():
    p=root/Path(rel)
    if not p.is_file():
        if rel not in missing: changed.append({'path':rel,'problem':'not-file'})
        continue
    size=p.stat().st_size
    digest=sha(p)
    if size!=item['bytes'] or digest!=item['sha256'].upper():
        changed.append({'path':rel,'expected_bytes':item['bytes'],'actual_bytes':size,'expected_sha256':item['sha256'],'actual_sha256':digest})
input_results=[]
for item in manifest['inputs']:
    p=Path(item['path'])
    input_results.append({'name':item['name'],'path':str(p),'exists':p.is_file(),'expected_sha256':item['sha256'],'actual_sha256':sha(p) if p.is_file() else None,'match':p.is_file() and sha(p)==item['sha256'].upper()})
main_results=[]
for item in manifest['main_files']:
    p=root/Path(item['path'])
    main_results.append({'path':item['path'],'exists':p.is_file(),'expected_sha256':item['sha256'],'actual_sha256':sha(p) if p.is_file() else None,'match':p.is_file() and sha(p)==item['sha256'].upper()})
checks=manifest['test']
evidence_dir=manifest_path.parent
log=evidence_dir/checks['stdout']; junit=evidence_dir/checks['junit']
result={'manifest_path':str(manifest_path),'manifest_sha256':sha(manifest_path),'manifest_schema':manifest['schema'],'snapshot_root':str(root),'listed_file_count':manifest['snapshot_file_count'],'actual_file_count':len(actual),'listed_count_matches':manifest['snapshot_file_count']==len(listed),'snapshot_exact_file_set':not missing and not extra,'missing_file_count':len(missing),'extra_file_count':len(extra),'hash_or_size_mismatch_count':len(changed),'mismatches':changed,'symlink_count':len(symlinks),'symlink_paths':symlinks,'main_files_match':all(x['match'] for x in main_results),'main_files':main_results,'inputs_match':all(x['match'] for x in input_results),'inputs':input_results,'frozen_focused_log_matches':log.is_file() and sha(log)==checks['stdout_sha256'].upper(),'frozen_focused_junit_matches':junit.is_file() and sha(junit)==checks['junit_sha256'].upper(),'frozen_test_result':checks['result'],'frozen_test_warning':checks['warning']}
print(json.dumps(result,indent=2,sort_keys=True))


