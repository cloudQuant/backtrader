from pathlib import Path
import hashlib
import json
import sys

root = Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r1_20260926")
sys.path.insert(0, str(root / "src"))
from bt_api_execution import DurableStoreError, ExecutionScope, SqliteExecutionStore
import bt_api_execution.store as source

db = Path(r"D:\temp\iteration41_v20_root_schema_probe_r1_20260926\same-name-wrong-trigger.sqlite3")
scope = ExecutionScope("ctp", "simnow", "ctp-account-ref.v1:" + hashlib.sha256(b"synthetic-root-account").hexdigest(), "root-schema-probe", "20260926")
before = hashlib.sha256(db.read_bytes()).hexdigest()
results = []
for api in (SqliteExecutionStore.inspect_ctp_account_store_file, SqliteExecutionStore.open_ctp_account_store):
    try:
        api(db, scope)
    except DurableStoreError as error:
        results.append({"api": api.__name__, "rejected": True, "error": str(error)})
    else:
        raise AssertionError(api.__name__ + " accepted malformed schema")
after = hashlib.sha256(db.read_bytes()).hexdigest()
assert before == after
record = {
    "schema": "iteration41.v20.root_schema_green.v1",
    "source_origin": source.__file__,
    "source_sha256": hashlib.sha256(Path(source.__file__).read_bytes()).hexdigest(),
    "db_sha256_before": before,
    "db_sha256_after": after,
    "results": results,
    "native_calls": 0,
    "scope": "Single root same-name wrong-trigger regression on previously generated r0 temporary DB. Full V20/main runtime acceptance remains separate.",
}
target = Path(r"D:\temp\iteration41_v20_root_schema_green_r1_20260926.json")
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record))
