from __future__ import annotations

import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
excluded = {"review_manifest.json"}
files = []
for path in sorted(root.rglob("*")):
    if not path.is_file() or path.name in excluded:
        continue
    relative = path.relative_to(root).as_posix()
    files.append(
        {
            "path": relative,
            "size": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    )
manifest = {
    "schema": "iteration41.v20.independent-review-receipt.v1",
    "snapshot": r"D:\temp\iteration41_v20_ctp_account_store_freeze_r1_20260926",
    "snapshot_manifest_sha256": "3b66dee3a29400ec7ee6231873bd9f7e8682c14966384b8aa1e88e0c51e6354a",
    "store_source_sha256": "4067c3fb010a1285c4ca07d7aa26b9e0375a415a278833bde9918e9c78e5e608",
    "factory_test_sha256": "006923e2bf3ad2a09b9cfde6f3c60a1de72c8a1be95c42464641dfe076645155",
    "independent_focus": "39 passed; three-file factory/family-owner/store focus",
    "acceptance": "BLOCKED: same-Store cross-account family-owner/lease/session/claim succeeds after factory binding to account A",
    "files": files,
}
manifest_path = root / "review_manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({
    "manifest": str(manifest_path),
    "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    "payload_count": len(files),
}, indent=2))

