from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

v18_src = Path(os.environ["V18_BT_API_EXECUTION_SRC"]).resolve()
v20_src = Path(os.environ["EXPECTED_BT_API_EXECUTION_SRC"]).resolve()
out = Path(os.environ["V20_V18_QA_OUT"]).resolve()
out.mkdir(parents=True, exist_ok=True)
db_path = out / "actual_v18_store.sqlite3"

create_code = r'''
import hashlib, json, sqlite3, sys
from pathlib import Path
import bt_api_execution.store as module
from bt_api_execution import SqliteExecutionStore
source = Path(sys.argv[1]).resolve()
actual = Path(module.__file__).resolve()
assert actual.is_relative_to(source), (actual, source)
path = Path(sys.argv[2])
store = SqliteExecutionStore(path)
store.close()
with sqlite3.connect(path) as db:
    version = db.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
    tables = sorted(row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
result = {
    "source": str(actual),
    "source_sha256": hashlib.sha256(actual.read_bytes()).hexdigest(),
    "path": str(path),
    "schema_version": version,
    "tables": tables,
    "database_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
}
print(json.dumps(result))
'''
env_v18 = dict(os.environ)
env_v18["PYTHONPATH"] = str(v18_src)
created = subprocess.run(
    [sys.executable, "-c", create_code, str(v18_src), str(db_path)],
    env=env_v18, text=True, capture_output=True, check=True,
)
created_result = json.loads(created.stdout)

probe_code = r'''
import hashlib, json, sqlite3, sys
from pathlib import Path
from bt_api_execution import ExecutionScope, SqliteExecutionStore
import bt_api_execution.store as module
source = Path(sys.argv[1]).resolve()
actual = Path(module.__file__).resolve()
assert actual.is_relative_to(source), (actual, source)
path = Path(sys.argv[2])
scope = ExecutionScope(
    "ctp", "simnow",
    "ctp-account-ref.v1:" + hashlib.sha256(b"v20-v18-old-schema-synthetic").hexdigest(),
    "strategy.synthetic", "20260926",
)
def digest():
    return hashlib.sha256(path.read_bytes()).hexdigest()
def schema():
    with sqlite3.connect(path) as db:
        rows = db.execute(
            "SELECT type,name,sql FROM sqlite_master WHERE type IN ('table','index','trigger') ORDER BY type,name"
        ).fetchall()
    return hashlib.sha256(json.dumps(rows, separators=(",",":")).encode()).hexdigest()
before = digest()
schema_before = schema()
inspect_error = None
try:
    kind = SqliteExecutionStore.inspect_ctp_account_store_file(path, scope).kind
except Exception as exc:
    kind = None
    inspect_error = type(exc).__name__ + ": " + str(exc)
after_inspect = digest()
schema_after_inspect = schema()
open_error = None
try:
    store = SqliteExecutionStore.open_ctp_account_store(path, scope)
except Exception as exc:
    open_error = type(exc).__name__ + ": " + str(exc)
else:
    store.close()
after_open = digest()
schema_after_open = schema()
with sqlite3.connect(path) as db:
    version_after = db.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
    tables_after = sorted(row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
result = {
    "source": str(actual),
    "source_sha256": hashlib.sha256(actual.read_bytes()).hexdigest(),
    "path": str(path),
    "inspect_kind": kind,
    "inspect_error": inspect_error,
    "open_error": open_error,
    "database_sha256_before": before,
    "database_sha256_after_inspect": after_inspect,
    "database_sha256_after_open": after_open,
    "schema_sha256_before": schema_before,
    "schema_sha256_after_inspect": schema_after_inspect,
    "schema_sha256_after_open": schema_after_open,
    "schema_version_after": version_after,
    "tables_after": tables_after,
}
print(json.dumps(result))
'''
env_v20 = dict(os.environ)
env_v20["PYTHONPATH"] = str(v20_src)
probed = subprocess.run(
    [sys.executable, "-c", probe_code, str(v20_src), str(db_path)],
    env=env_v20, text=True, capture_output=True, check=True,
)
probe_result = json.loads(probed.stdout)
result = {
    "schema": "iteration41.v20.independent_actual_v18_preflight.v1",
    "v18_source": created_result,
    "v20_source": {
        "path": str(v20_src / "bt_api_execution" / "store.py"),
        "store_sha256": hashlib.sha256((v20_src / "bt_api_execution" / "store.py").read_bytes()).hexdigest(),
        "manifest_expected": os.environ.get("V20_EXPECTED_MANIFEST_SHA256"),
    },
    "probe": probe_result,
}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))

