from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

source = Path(os.environ["EXPECTED_BT_API_EXECUTION_SRC"]).resolve()
out = Path(os.environ["V20_LEGACY_QA_OUT"]).resolve()
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(source))
from bt_api_execution import ExecutionScope, SqliteExecutionStore
import bt_api_execution.store as store_module

actual_source = Path(store_module.__file__).resolve()
if not actual_source.is_relative_to(source):
    raise RuntimeError(f"wrong source origin: {actual_source}, expected under {source}")
scope = ExecutionScope(
    "ctp", "simnow",
    "ctp-account-ref.v1:" + hashlib.sha256(b"v20-independent-legacy-synthetic").hexdigest(),
    "strategy.synthetic", "20260926",
)

exact_columns = """(
    client_order_id TEXT PRIMARY KEY,
    approval_id TEXT NOT NULL UNIQUE,
    request_digest TEXT NOT NULL,
    request_json TEXT NOT NULL,
    state TEXT NOT NULL,
    order_ref TEXT,
    order_sys_id TEXT,
    front_id INTEGER,
    session_id INTEGER,
    status TEXT,
    traded_quantity INTEGER NOT NULL DEFAULT 0,
    position_digest TEXT,
    updated_at REAL NOT NULL
)"""

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def make_case(name: str, ddl: str, populate: bool = False, view: bool = False) -> Path:
    path = out / f"{name}.sqlite3"
    with closing(sqlite3.connect(path)) as db:
        db.execute(ddl)
        if populate:
            db.execute(
                "INSERT INTO ctp_sim_orders "
                "(client_order_id, approval_id, request_digest, request_json, state, updated_at) "
                "VALUES ('synthetic-order', 'synthetic-approval', 'synthetic-digest', '{}', 'UNKNOWN', 1.0)"
            )
        if view:
            db.execute("CREATE VIEW ctp_sim_orders_view AS SELECT client_order_id FROM ctp_sim_orders")
        db.commit()
    return path

def inspect_open(path: Path) -> dict[str, object]:
    before = digest(path)
    inspect_result = None
    inspect_error = None
    try:
        inspect_result = SqliteExecutionStore.inspect_ctp_account_store_file(path, scope).kind
    except Exception as exc:
        inspect_error = f"{type(exc).__name__}: {exc}"
    after_inspect = digest(path)
    open_error = None
    try:
        store = SqliteExecutionStore.open_ctp_account_store(path, scope)
    except Exception as exc:
        open_error = f"{type(exc).__name__}: {exc}"
    else:
        store.close()
    after_open = digest(path)
    with closing(sqlite3.connect(path)) as db:
        names = sorted(
            row[0] for row in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
        )
    return {
        "inspect_kind": inspect_result,
        "inspect_error": inspect_error,
        "open_error": open_error,
        "sha_before": before,
        "sha_after_inspect": after_inspect,
        "sha_after_open": after_open,
        "main_db_unchanged": before == after_inspect == after_open,
        "tables_after": names,
    }

cases = {}
cases["exact_empty_orders_only"] = inspect_open(
    make_case("exact_empty_orders_only", f"CREATE TABLE ctp_sim_orders {exact_columns}")
)
cases["malformed_orders_only_short_columns"] = inspect_open(
    make_case(
        "malformed_orders_only_short_columns",
        "CREATE TABLE ctp_sim_orders (client_order_id TEXT PRIMARY KEY)",
    )
)
cases["malformed_orders_only_extra_column"] = inspect_open(
    make_case(
        "malformed_orders_only_extra_column",
        f"CREATE TABLE ctp_sim_orders {exact_columns[:-1]}, surprise TEXT)",
    )
)
cases["malformed_orders_only_populated"] = inspect_open(
    make_case(
        "malformed_orders_only_populated",
        f"CREATE TABLE ctp_sim_orders {exact_columns}",
        populate=True,
    )
)
cases["partial_metadata_only"] = inspect_open(
    make_case(
        "partial_metadata_only",
        "CREATE TABLE ctp_sim_journal_metadata (value TEXT)",
    )
)
cases["extra_view_on_orders_only"] = inspect_open(
    make_case(
        "extra_view_on_orders_only",
        f"CREATE TABLE ctp_sim_orders {exact_columns}",
        view=True,
    )
)

result = {
    "schema": "iteration41.v20.independent_legacy_layout_review.v1",
    "source": str(actual_source),
    "store_sha256": digest(actual_source),
    "manifest_expected": os.environ.get("V20_EXPECTED_MANIFEST_SHA256"),
    "output_dir": str(out),
    "cases": cases,
}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))

