# V20 CTP account-store factory independent review

## Frozen inputs

- V20 r1 snapshot: `D:\temp\iteration41_v20_ctp_account_store_freeze_r1_20260926`
- Snapshot manifest SHA-256: `3b66dee3a29400ec7ee6231873bd9f7e8682c14966384b8aa1e88e0c51e6354a`
- All 29 payload hashes listed by the snapshot manifest matched.
- Store source SHA-256: `4067c3fb010a1285c4ca07d7aa26b9e0375a415a278833bde9918e9c78e5e608`
- Factory test SHA-256: `006923e2bf3ad2a09b9cfde6f3c60a1de72c8a1be95c42464641dfe076645155`
- Runtime: Python 3.11.5, pytest 8.0.0, `C:\anaconda3\python.exe`. No native, provider, or network calls.

## Blocking finding

The factory-bound Store does not enforce its persisted single-account identity on subsequent public mutation APIs. In a fresh synthetic DB, I called `open_ctp_account_store(path, scope_A)`. Reading the identity with scope B correctly failed, but the same returned Store then accepted:

1. `acquire_ctp_account_family_owner(scope_B)`;
2. `acquire_or_renew_lease(scope_B, ..., ctp_account_family_owner=owner_B)`;
3. `create_ctp_callback_session_owner(scope_B, writer_lease=lease_B)`;
4. `claim_for_dispatch(..., scope_B, writer_lease=lease_B)`.

The submit reached `DISPATCHING` while the durable Store identity remained bound to account A. Native/provider calls were zero. This is a supported same-Store API misuse path, not a hostile Python or filesystem scenario. V20 r1 therefore is **not accepted** until the persisted identity constrains all scope-bearing CTP mutation/claim paths. Reproducer and JSON result are in `account_scope_binding_probe.py` and `r1-same-store-cross-account/result.json`.

## Passing checks

The independent factory/family-owner/Store focus passed **39 tests**:

```powershell
$env:PYTHONPATH='src'
$env:PYTHONDONTWRITEBYTECODE='1'
& 'C:\anaconda3\python.exe' -m pytest -p no:cacheprovider tests/test_ctp_account_store_factory.py tests/test_ctp_account_family_owner.py tests/test_execution_store.py -q --tb=short
```

Additional independent SQLite probes against the frozen r1 source:

- Exact V20 control is classified `CTP_EXECUTION_STORE` and reports the exact bound account.
- Same-name `ctp_account_store_identity_immutable_update` trigger with body `SELECT 1` is rejected by inspect and factory-open. The main DB SHA and schema SHA remain unchanged.
- An extra `ctp_account_store_identity` column is rejected by both APIs, without main DB or schema changes.
- A same-name `ctp_dispatch_commands_scope_status` index over the wrong column is rejected by both APIs, without main DB or schema changes.
- The exact empty legacy `ctp_sim_orders` signature is classified `LEGACY_CTP_JOURNAL`; factory-open still refuses it before new Store DDL. Main DB hash and table set remain unchanged.
- Malformed legacy signatures (short/extra columns, populated orders-only, partial metadata-only, and an extra view) are rejected by inspect and factory-open without changing the main DB.
- A real schema-v18 database created by the frozen V18 source is rejected by V20 inspect and factory-open; database/schema hashes, schema version `18`, and table set remain unchanged.
- The focused author tests also cover exact-account mismatch, current V20 identity readback through a live WAL, missing identity, V19/unknown layouts, orphan sidecars, URI/in-memory rejection, and exact empty scoped legacy layout.

The V20 author reports 256 passed / 2 skipped for the full package. I independently ran only the 39-test factory/family-owner/Store focus plus the probes above.

## r0 regression comparison

Independent r0 probes reproduced the fixed r1 defects: r0 accepted a same-name altered trigger, an extra identity column, and a wrong same-name index. r0 rejected the supported empty orders-only legacy signature as partial/ambiguous. r1 closes those exact cases. The added same-Store scope-B mutation gap is separate and remains open in r1.

## Scope

Checks use synthetic local SQLite files. This review does not claim protection against hostile filesystem replacement, cloned/reparsed databases, or OS-level handle attacks. Inspecting WAL-mode files may create SQLite SHM sidecars; acceptance checks compare DB/schema content and do not treat sidecar creation as schema mutation.

