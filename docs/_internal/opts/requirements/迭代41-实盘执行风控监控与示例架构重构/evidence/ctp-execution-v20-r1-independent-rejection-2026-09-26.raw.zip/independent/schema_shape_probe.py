from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

source = Path(os.environ["EXPECTED_BT_API_EXECUTION_SRC"]).resolve()
out = Path(os.environ["V20_QA_OUT"]).resolve()
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(source))
from bt_api_execution import ExecutionScope, SqliteExecutionStore
import bt_api_execution.store as store_module

actual_source = Path(store_module.__file__).resolve()
if not actual_source.is_relative_to(source):
    raise RuntimeError(f"wrong source origin: {actual_source}, expected under {source}")

def scope():
    return ExecutionScope(
        "ctp", "simnow",
        "ctp-account-ref.v1:" + hashlib.sha256(b"v20-independent-synthetic-account").hexdigest(),
        "strategy.synthetic", "20260926",
    )

def file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def schema_sha(path: Path) -> str:
    with closing(sqlite3.connect(path)) as db:
        rows = db.execute(
            "SELECT type, name, sql FROM sqlite_master "
            "WHERE type IN ('table', 'index', 'trigger') ORDER BY type, name"
        ).fetchall()
    return hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()

def create_store(path: Path) -> None:
    store = SqliteExecutionStore.open_ctp_account_store(path, scope())
    store.close()

def probe_existing(path: Path) -> dict[str, object]:
    before = file_sha(path)
    schema_before = schema_sha(path)
    inspect_error = None
    inspect_kind = None
    try:
        inspect_kind = SqliteExecutionStore.inspect_ctp_account_store_file(path, scope()).kind
    except Exception as exc:
        inspect_error = f"{type(exc).__name__}: {exc}"
    after_inspect = file_sha(path)
    schema_after_inspect = schema_sha(path)
    open_error = None
    opened = None
    try:
        opened = SqliteExecutionStore.open_ctp_account_store(path, scope())
    except Exception as exc:
        open_error = f"{type(exc).__name__}: {exc}"
    else:
        opened.close()
    after_open = file_sha(path)
    schema_after_open = schema_sha(path)
    return {
        "inspect_kind": inspect_kind,
        "inspect_error": inspect_error,
        "open_error": open_error,
        "main_db_sha_before": before,
        "main_db_sha_after_inspect": after_inspect,
        "main_db_sha_after_open": after_open,
        "schema_sha_before": schema_before,
        "schema_sha_after_inspect": schema_after_inspect,
        "schema_sha_after_open": schema_after_open,
        "schema_unchanged": schema_before == schema_after_inspect == schema_after_open,
    }

cases = {}
baseline = out / "baseline.sqlite3"
create_store(baseline)
store = SqliteExecutionStore.open_ctp_account_store(baseline, scope())
try:
    identity = store.read_ctp_account_store_identity(scope())
finally:
    store.close()
cases["exact_v20_control"] = {
    "inspection": SqliteExecutionStore.inspect_ctp_account_store_file(baseline, scope()).kind,
    "identity_account_ref": identity.account_ref,
}

trigger_path = out / "same_name_wrong_trigger.sqlite3"
create_store(trigger_path)
with closing(sqlite3.connect(trigger_path)) as db:
    db.execute("DROP TRIGGER ctp_account_store_identity_immutable_update")
    db.execute(
        "CREATE TRIGGER ctp_account_store_identity_immutable_update "
        "BEFORE UPDATE ON ctp_account_store_identity BEGIN SELECT 1; END"
    )
    db.commit()
cases["same_name_wrong_trigger"] = probe_existing(trigger_path)

column_path = out / "wrong_identity_columns.sqlite3"
create_store(column_path)
with closing(sqlite3.connect(column_path)) as db:
    db.execute("ALTER TABLE ctp_account_store_identity ADD COLUMN unexpected TEXT")
    db.commit()
cases["wrong_identity_columns"] = probe_existing(column_path)

index_path = out / "same_name_wrong_index.sqlite3"
create_store(index_path)
with closing(sqlite3.connect(index_path)) as db:
    db.execute("DROP INDEX ctp_dispatch_commands_scope_status")
    db.execute(
        "CREATE INDEX ctp_dispatch_commands_scope_status "
        "ON ctp_dispatch_commands(command_id)"
    )
    db.commit()
cases["same_name_wrong_index"] = probe_existing(index_path)

legacy_path = out / "empty_legacy_orders_only.sqlite3"
with closing(sqlite3.connect(legacy_path)) as db:
    db.execute("PRAGMA journal_mode=WAL")
    db.execute(
        """
        CREATE TABLE ctp_sim_orders (
            client_order_id TEXT PRIMARY KEY,
            approval_id TEXT NOT NULL UNIQUE,
            request_digest TEXT NOT NULL,
            request_json TEXT NOT NULL,
            state TEXT NOT NULL,
            order_ref TEXT,
            order_sys_id TEXT,
            front_id INTEGER,
            session_id INTEGER,
            status TEXT,
            traded_quantity INTEGER NOT NULL DEFAULT 0,
            position_digest TEXT,
            updated_at REAL NOT NULL
        )
        """
    )
    db.commit()
legacy_before = file_sha(legacy_path)
legacy_inspect_kind = None
legacy_inspect_error = None
try:
    legacy_inspect_kind = SqliteExecutionStore.inspect_ctp_account_store_file(
        legacy_path, scope()
    ).kind
except Exception as exc:
    legacy_inspect_error = f"{type(exc).__name__}: {exc}"
legacy_after_inspect = file_sha(legacy_path)
legacy_open_error = None
try:
    store = SqliteExecutionStore.open_ctp_account_store(legacy_path, scope())
except Exception as exc:
    legacy_open_error = f"{type(exc).__name__}: {exc}"
else:
    store.close()
legacy_after_open = file_sha(legacy_path)
with closing(sqlite3.connect(legacy_path)) as db:
    legacy_tables = sorted(
        row[0] for row in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    )
cases["empty_orders_only_legacy"] = {
    "inspect_kind": legacy_inspect_kind,
    "inspect_error": legacy_inspect_error,
    "open_error": legacy_open_error,
    "main_db_sha_before": legacy_before,
    "main_db_sha_after_inspect": legacy_after_inspect,
    "main_db_sha_after_open": legacy_after_open,
    "main_db_unchanged": legacy_before == legacy_after_inspect == legacy_after_open,
    "tables_after": legacy_tables,
}

result = {
    "schema": "iteration41.v20.independent_factory_review.v2",
    "source": str(actual_source),
    "source_sha256": file_sha(actual_source),
    "manifest_expected": os.environ.get("V20_EXPECTED_MANIFEST_SHA256"),
    "output_dir": str(out),
    "cases": cases,
}
result_path = out / "result.json"
result_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))

