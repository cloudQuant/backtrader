from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path
from decimal import Decimal

source = Path(os.environ["EXPECTED_BT_API_EXECUTION_SRC"]).resolve()
out = Path(os.environ["V20_ACCOUNT_SCOPE_QA_OUT"]).resolve()
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(source))
from bt_api_execution import (
    ExecutionScope,
    OrderIntent,
    PositionEffect,
    Side,
    SqliteExecutionStore,
)
import bt_api_execution.store as store_module

actual = Path(store_module.__file__).resolve()
if not actual.is_relative_to(source):
    raise RuntimeError(f"wrong source origin: {actual}, expected under {source}")

def make_scope(label: str) -> ExecutionScope:
    return ExecutionScope(
        "ctp",
        "simnow",
        "ctp-account-ref.v1:" + hashlib.sha256(label.encode("ascii")).hexdigest(),
        "strategy.synthetic",
        "20260926",
    )

scope_a = make_scope("account-A")
scope_b = make_scope("account-B")
path = out / "factory-account-a-then-public-scope-b.sqlite3"
store = SqliteExecutionStore.open_ctp_account_store(path, scope_a)
results = {
    "source": str(actual),
    "store_sha256": hashlib.sha256(actual.read_bytes()).hexdigest(),
    "manifest_expected": os.environ.get("V20_EXPECTED_MANIFEST_SHA256"),
    "scope_a_account_ref": scope_a.account_ref,
    "scope_b_account_ref": scope_b.account_ref,
}
try:
    identity_a = store.read_ctp_account_store_identity(scope_a)
    results["identity_a_read"] = identity_a.account_ref
    try:
        store.read_ctp_account_store_identity(scope_b)
    except Exception as exc:
        results["identity_b_read_error"] = f"{type(exc).__name__}: {exc}"
    else:
        results["identity_b_read_error"] = None

    owner_b = None
    lease_b = None
    try:
        owner_b = store.acquire_ctp_account_family_owner(scope_b)
        results["scope_b_owner"] = {
            "family_key": owner_b.family_key,
            "account_key": owner_b.account_key,
            "owner_intent_id": owner_b.owner_intent_id,
        }
    except Exception as exc:
        results["scope_b_owner_error"] = f"{type(exc).__name__}: {exc}"

    if owner_b is not None:
        try:
            lease_b = store.acquire_or_renew_lease(
                scope_b,
                "synthetic-account-b-writer",
                ttl_ns=30_000_000_000,
                ctp_account_family_owner=owner_b,
            )
            results["scope_b_lease"] = {
                "scope_key": lease_b.scope_key,
                "fencing_token": lease_b.fencing_token,
                "family_key": lease_b.family_key,
                "family_owner_intent_id": lease_b.family_owner_intent_id,
            }
        except Exception as exc:
            results["scope_b_lease_error"] = f"{type(exc).__name__}: {exc}"

    if lease_b is not None:
        try:
            session_b = store.create_ctp_callback_session_owner(
                scope_b, writer_lease=lease_b
            )
            results["scope_b_callback_session_owner"] = session_b.owner_intent_id
        except Exception as exc:
            results["scope_b_callback_session_owner_error"] = f"{type(exc).__name__}: {exc}"

        intent = OrderIntent.limit(
            intent_id="synthetic-b-submit",
            scope=scope_b,
            signal_id="synthetic-signal-b",
            instrument="rb2710",
            side=Side.BUY,
            position_effect=PositionEffect.OPEN,
            quantity=Decimal("1"),
            price=Decimal("100"),
        )
        try:
            store.admit_intent(intent, writer_lease=lease_b)
            store.activate_intent(intent.intent_id, scope_b, writer_lease=lease_b)
            record, claimed = store.claim_for_dispatch(
                intent.intent_id, scope_b, writer_lease=lease_b
            )
            results["scope_b_claim"] = {
                "claimed": claimed,
                "record_state": record.state.value,
                "intent_id": record.intent_id,
            }
        except Exception as exc:
            results["scope_b_claim_error"] = f"{type(exc).__name__}: {exc}"

    results["identity_a_still_readable"] = (
        store.read_ctp_account_store_identity(scope_a).account_ref
    )
finally:
    store.close()

results["provider_calls"] = []
results["native_calls"] = 0
result_path = out / "result.json"
result_path.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
print(json.dumps(results, indent=2))

