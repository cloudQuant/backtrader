from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


SOURCE = Path(r"D:\temp\iteration41_v20_r3_cancel_terminal_candidate_20260927")
ROOT_QA = Path(r"D:\temp\iteration41-r3r3-root-independent-qa-20260927")
EVIDENCE = Path(r"D:\source_code\backtrader\docs\_internal\opts\requirements\迭代41-实盘执行风控监控与示例架构重构\evidence")
STEM = "ctp-execution-r3r3-terminal-cancel-independent-review-2026-09-27"
SOURCE_MANIFEST_SHA = "7655307fb90c959dabf5dc14786d02c60edd3fcf3d1fc3cefc32f2512e34eeec"
PARENT_MANIFEST_SHA = "0a0850c107856262470d584132c4d869db1eb4dba6f37a33323fdf569981f41d"
AUTHOR_INDEX_SHA = "f14a95bbdc046a19763322ff522c137eb22bf440eca678b9125240fb8a46112f"
ROOT_COPY_SHA = "ddf454da91ed21b7017d4fd0c41c6554ed7dff66ca1634881930164b4487d460"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def checked(root: Path, name: str, expected: str, size: int | None = None) -> bytes:
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise RuntimeError(f"invalid archive path: {name}")
    path = root / relative
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"invalid archive source: {path}")
    raw = path.read_bytes()
    if sha(raw) != expected or (size is not None and len(raw) != size):
        raise RuntimeError(f"archive source mismatch: {path}")
    return raw


def pytest_counts(path: Path) -> dict[str, int]:
    suite = ET.fromstring(path.read_bytes())[0]
    return {key: int(suite.attrib[key]) for key in ("tests", "errors", "failures", "skipped")}


def main() -> None:
    source_manifest_raw = checked(SOURCE, "source-manifest-r3r3.json", SOURCE_MANIFEST_SHA)
    parent_raw = checked(SOURCE, "parent-r3r2-manifest.json", PARENT_MANIFEST_SHA)
    index_raw = checked(SOURCE, "qa/evidence-index-r3r3.json", AUTHOR_INDEX_SHA)
    root_copy_raw = checked(ROOT_QA, "root-copy-receipt.json", ROOT_COPY_SHA)
    source_manifest = json.loads(source_manifest_raw)
    author_index = json.loads(index_raw)
    root_copy = json.loads(root_copy_raw)
    assert source_manifest["parent_manifest_sha256"] == PARENT_MANIFEST_SHA
    assert author_index["source_manifest_sha256"] == SOURCE_MANIFEST_SHA
    assert root_copy["copied_payloads"] == len(source_manifest["files"]) == 30
    assert len(author_index["artifacts"]) == 18
    assert pytest_counts(ROOT_QA / "qa/root-cancel-focus.xml") == {
        "tests": 35, "errors": 0, "failures": 0, "skipped": 0
    }
    assert pytest_counts(ROOT_QA / "qa/root-execution-full.xml") == {
        "tests": 1, "errors": 1, "failures": 0, "skipped": 0
    }
    assert pytest_counts(ROOT_QA / "qa/root-execution-full-plugin.xml") == {
        "tests": 286, "errors": 0, "failures": 0, "skipped": 2
    }
    for row in source_manifest["files"]:
        expected = row["sha256"]
        checked(SOURCE, row["path"], expected, row["bytes"])
        checked(ROOT_QA, row["path"], expected, row["bytes"])
    for suffix in (".raw.zip", ".json", ".md"):
        assert not (EVIDENCE / f"{STEM}{suffix}").exists()
    entries: list[dict[str, object]] = []
    archive = EVIDENCE / f"{STEM}.raw.zip"

    def add(zf: zipfile.ZipFile, root: Path, name: str, prefix: str,
            expected: str | None = None, size: int | None = None) -> None:
        raw = (root / name).read_bytes() if expected is None else checked(root, name, expected, size)
        normalized_name = name.replace("\\", "/")
        member = f"{prefix}/{normalized_name}"
        zf.writestr(member, raw)
        entries.append({"path": member, "sha256": sha(raw), "bytes": len(raw)})

    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zf:
        for row in source_manifest["files"]:
            add(zf, SOURCE, row["path"], "source", row["sha256"], row["bytes"])
        add(zf, SOURCE, "source-manifest-r3r3.json", "source", SOURCE_MANIFEST_SHA)
        add(zf, SOURCE, "parent-r3r2-manifest.json", "source", PARENT_MANIFEST_SHA)
        for row in author_index["artifacts"]:
            add(zf, SOURCE, row["path"], "author", row["sha256"], row["bytes"])
        add(zf, SOURCE, "qa/evidence-index-r3r3.json", "author", AUTHOR_INDEX_SHA)
        for name in (
            "root-copy-receipt.json", "qa/root-cancel-focus.xml",
            "qa/root-execution-full.xml", "qa/root-execution-full-plugin.xml",
        ):
            add(zf, ROOT_QA, name, "independent", ROOT_COPY_SHA if name == "root-copy-receipt.json" else None)
        add(zf, Path(r"D:\temp"), "iteration41_verify_copy_r3r3_root_20260927.py", "independent")
        add(zf, Path(r"D:\temp"), "iteration41_archive_r3r3_root_20260927.py", "independent")
    with zipfile.ZipFile(archive) as zf:
        assert zf.testzip() is None
        assert len(zf.namelist()) == len(entries)
    archive_sha = sha(archive.read_bytes())
    review = {
        "schema": "iteration41.execution_r3r3.root_review.v1",
        "status": "LOCAL_TERMINAL_CANCEL_COMMIT_PASS_MAIN_PROOF_WIRING_PENDING",
        "source_manifest_sha256": SOURCE_MANIFEST_SHA,
        "parent_manifest_sha256": PARENT_MANIFEST_SHA,
        "author_evidence_index_sha256": AUTHOR_INDEX_SHA,
        "root_copy_receipt_sha256": ROOT_COPY_SHA,
        "root_independent": {
            "payload_hashes_verified": 30,
            "focused": "35 passed, native imports/network zero",
            "full_first_attempt": "collection error: pytest-asyncio disabled by root's plugin-autoload setting",
            "full_corrected": "284 passed, 2 optional SDK skips; no native imports or direct network/DNS",
            "junit_files": [
                "qa/root-cancel-focus.xml", "qa/root-execution-full.xml",
                "qa/root-execution-full-plugin.xml",
            ],
        },
        "scope_limits": [
            "Same-transaction local terminal event/target readback is not provider-authenticated evidence.",
            "No parent fake issuer/risk release or main Backtrader positive cancellation integration is accepted by this review.",
            "No CTP provider, real account, order, cancel, or production route was exercised.",
        ],
        "archive": {"file": archive.name, "sha256": archive_sha, "entries": len(entries)},
        "files": entries,
    }
    (EVIDENCE / f"{STEM}.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (EVIDENCE / f"{STEM}.md").write_text(
        "# Execution R3r3 终态撤单原子读回独立复核\n\n"
        "冻结 manifest `" + SOURCE_MANIFEST_SHA + "` 以 R3r2 `" + PARENT_MANIFEST_SHA + "` 为父；"
        "30 项 payload 中只改 `store.py`、公开导出和一份新测试。root 在独立副本重算全部源码/测试哈希后，"
        "取消焦点 `35 passed`，完整包 `284 passed / 2 optional SDK skipped`，native import 与直接网络/DNS 均为零。"
        "初次完整集因 root 禁用 pytest 插件而在 `asyncio` marker 收集阶段失败；恢复兼容 venv 的 pytest-asyncio 后通过，原失败 XML 随归档保留。\n\n"
        "`CancelObservationCommitV1`、`record_cancel_observation_with_commit` 与受 writer lease 检查的 "
        "`read_terminal_cancel_commit` 提供同一 SQLite 事务中的取消事件、目标记录/事件及规范来源字段；"
        "来源摘要不认证真实 provider。parent fake issuer、risk release 与主仓三项取消正例尚未在本复核中通过，"
        "因此只接受局部离线合同，维持 `NO_WRITE / LIVE_NO_GO`。\n\n"
        f"[机器记录]({STEM}.json)和[原始归档]({STEM}.raw.zip)保存精确来源与复跑 XML；"
        f"归档 SHA-256 `{archive_sha}`，共 {len(entries)} 项。\n",
        encoding="utf-8",
    )
    print(json.dumps({"archive": str(archive), "sha256": archive_sha, "entries": len(entries)}))


if __name__ == "__main__":
    main()
