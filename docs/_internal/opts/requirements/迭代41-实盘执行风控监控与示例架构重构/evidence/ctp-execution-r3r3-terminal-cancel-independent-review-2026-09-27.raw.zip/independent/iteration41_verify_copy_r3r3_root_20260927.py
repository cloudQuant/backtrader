from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path


SOURCE = Path(r"D:\temp\iteration41_v20_r3_cancel_terminal_candidate_20260927")
DESTINATION = Path(r"D:\temp\iteration41-r3r3-root-independent-qa-20260927")
MANIFEST_SHA = "7655307fb90c959dabf5dc14786d02c60edd3fcf3d1fc3cefc32f2512e34eeec"
PARENT_SHA = "0a0850c107856262470d584132c4d869db1eb4dba6f37a33323fdf569981f41d"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def main() -> None:
    assert not DESTINATION.exists()
    manifest_raw = (SOURCE / "source-manifest-r3r3.json").read_bytes()
    parent_raw = (SOURCE / "parent-r3r2-manifest.json").read_bytes()
    assert sha(manifest_raw) == MANIFEST_SHA
    assert sha(parent_raw) == PARENT_SHA
    manifest = json.loads(manifest_raw)
    parent = json.loads(parent_raw)
    assert manifest["parent_manifest_sha256"] == PARENT_SHA
    files = manifest["files"]
    assert len(files) == 30
    delta = {
        row["path"] for row in files if row["path"] not in {item["path"]: item["sha256"] for item in parent["files"]}
        or row["sha256"] != {item["path"]: item["sha256"] for item in parent["files"]}.get(row["path"])
    }
    assert delta == {
        "src/bt_api_execution/store.py",
        "src/bt_api_execution/__init__.py",
        "tests/test_cancel_terminal_commit.py",
    }
    DESTINATION.mkdir()
    copied = []
    for row in files:
        relative = Path(row["path"])
        assert not relative.is_absolute() and ".." not in relative.parts
        source = SOURCE / relative
        assert source.is_file() and not source.is_symlink()
        raw = source.read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
        destination = DESTINATION / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        assert sha(destination.read_bytes()) == row["sha256"]
        copied.append(row)
    runner = SOURCE / "qa" / "run_full_execution_guarded.py"
    assert runner.is_file() and not runner.is_symlink()
    (DESTINATION / "qa").mkdir()
    shutil.copy2(runner, DESTINATION / "qa" / runner.name)
    (DESTINATION / "source-manifest-r3r3.json").write_bytes(manifest_raw)
    (DESTINATION / "parent-r3r2-manifest.json").write_bytes(parent_raw)
    receipt = {
        "schema": "iteration41.r3r3.root_copy.v1",
        "source_manifest_sha256": MANIFEST_SHA,
        "parent_manifest_sha256": PARENT_SHA,
        "source_delta": sorted(delta),
        "copied_payloads": len(copied),
        "runner_sha256": sha(runner.read_bytes()),
        "source_root": str(SOURCE),
        "copy_root": str(DESTINATION),
    }
    (DESTINATION / "root-copy-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
