from __future__ import annotations

import builtins
import ipaddress
import socket
import sys
import threading
from pathlib import Path

import bt_api_execution
import bt_api_execution.store
import pytest

blocked_native_imports: list[str] = []
blocked_network: list[str] = []
internal_loopback_ipc: list[str] = []
original_import = builtins.__import__
original_connect = socket.socket.connect
original_connect_ex = socket.socket.connect_ex
original_socketpair = socket.socketpair
socketpair_context = threading.local()


def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    leaf = name.rsplit(".", 1)[-1]
    if leaf in {"_ctp", "ctp_wrap"}:
        blocked_native_imports.append(name)
        raise ImportError("native CTP import blocked during offline Execution QA")
    return original_import(name, globals, locals, fromlist, level)


def _allow_internal_loopback_ipc(self, address, operation):
    if getattr(socketpair_context, "active", False):
        try:
            host = address[0]
            is_loopback = ipaddress.ip_address(host).is_loopback
        except (TypeError, ValueError, IndexError):
            is_loopback = False
        if self.family in {socket.AF_INET, socket.AF_INET6} and is_loopback:
            internal_loopback_ipc.append(f"{operation}:{address!r}")
            return True
    blocked_network.append(f"{operation}:{address!r}")
    raise OSError("network access blocked during offline Execution QA")


def guarded_connect(self, address):
    if self.family in {socket.AF_INET, socket.AF_INET6}:
        if _allow_internal_loopback_ipc(self, address, "asyncio_socketpair_connect"):
            return original_connect(self, address)
    return original_connect(self, address)


def guarded_connect_ex(self, address):
    if self.family in {socket.AF_INET, socket.AF_INET6}:
        if _allow_internal_loopback_ipc(self, address, "asyncio_socketpair_connect_ex"):
            return original_connect_ex(self, address)
    return original_connect_ex(self, address)


def guarded_socketpair(*args, **kwargs):
    prior = getattr(socketpair_context, "active", False)
    socketpair_context.active = True
    try:
        return original_socketpair(*args, **kwargs)
    finally:
        socketpair_context.active = prior


def denied_resolution(*args, **kwargs):
    blocked_network.append("dns-resolution")
    raise OSError("DNS access blocked during offline Execution QA")


builtins.__import__ = guarded_import
socket.socket.connect = guarded_connect
socket.socket.connect_ex = guarded_connect_ex
socket.socketpair = guarded_socketpair
socket.getaddrinfo = denied_resolution
socket.gethostbyname = denied_resolution

print(f"bt_api_execution origin: {Path(bt_api_execution.__file__).resolve()}")
print(f"bt_api_execution.store origin: {Path(bt_api_execution.store.__file__).resolve()}")

exit_code = pytest.main(sys.argv[1:])
loaded_native = sorted(
    name for name in sys.modules if name.rsplit(".", 1)[-1] in {"_ctp", "ctp_wrap"}
)
print(f"blocked native import attempts: {blocked_native_imports!r}")
print(f"blocked network attempts: {blocked_network!r}")
print(f"allowed asyncio loopback IPC operations: {internal_loopback_ipc!r}")
print(f"native modules loaded: {loaded_native!r}")
if blocked_native_imports or blocked_network or loaded_native:
    raise SystemExit(98)
raise SystemExit(exit_code)
