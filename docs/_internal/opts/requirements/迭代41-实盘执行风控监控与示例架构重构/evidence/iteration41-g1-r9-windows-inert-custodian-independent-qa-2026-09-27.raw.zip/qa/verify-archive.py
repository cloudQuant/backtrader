from pathlib import Path
import hashlib,json,zipfile
ev=Path(r'D:\source_code\backtrader\docs\_internal\opts\requirements\迭代41-实盘执行风控监控与示例架构重构\evidence\iteration41-g1-r9-windows-inert-custodian-author-2026-09-27')
qa=Path(r'D:\temp\iteration41-g1-r9-independent-qa-20260927')
receipt=json.loads((ev/'r9_author_archive_receipt.json').read_text(encoding='utf-8-sig'))
index=json.loads((ev/'r9_candidate_entries.json').read_text(encoding='utf-8-sig'))
zip_path=ev/'r9_candidate_raw.zip'
assert hashlib.sha256(zip_path.read_bytes()).hexdigest()==receipt['raw_zip_sha256']=='2055fb8329a06d80abe8fc52ae2d2fec25674686300defe96192faf3a4e44f3a'
assert hashlib.sha256((ev/'r9_candidate_entries.json').read_bytes()).hexdigest()==receipt['entry_index_sha256']=='1957b0bdc47c26903de96eed6a8c08bb4d25613d56d495de2c3add2198852665'
assert hashlib.sha256((ev/'r9_author_archive_receipt.json').read_bytes()).hexdigest()=='119f0dada52a3df1056c56d7c36e080bdeccb5874b7a275fe6f73b325bf8f6e1'
assert hashlib.sha256((ev/'AUTHOR_R9_EVIDENCE.md').read_bytes()).hexdigest()==receipt['author_page_sha256']
z=zipfile.ZipFile(zip_path)
assert z.testzip() is None
names=set(z.namelist())
listed={x['path'] for x in index['entries']}
assert len(listed)==19
assert names==listed | {'r9_candidate_entries.json'}
assert hashlib.sha256(z.read('r9_candidate_entries.json')).hexdigest()==receipt['entry_index_sha256']
manifest=json.loads(z.read('r9_manifest.json'))
assert len(manifest['payload_sha256'])==15
assert hashlib.sha256(z.read('r9_manifest.json')).hexdigest()==receipt['candidate_manifest_sha256']
assert set(manifest['payload_sha256'])=={x['path'] for x in index['entries'] if x['path'] in manifest['payload_sha256']}
for ent in index['entries']:
    raw=z.read(ent['path'])
    assert len(raw)==ent['bytes'], ent['path']
    assert hashlib.sha256(raw).hexdigest()==ent['sha256'], ent['path']
for member,key in [('r9_receipt.json','candidate_receipt_sha256'),('r9_trials.json','candidate_trials_sha256'),('r9_trials_initial.json','first_failed_trial_sha256')]:
    assert hashlib.sha256(z.read(member)).hexdigest()==receipt[key], member
copy=qa/'frozen-copy'
if copy.exists():
    raise RuntimeError(f'isolated copy already exists: {copy}')
copy.mkdir()
for name in names:
    target=(copy/name).resolve()
    assert target.parent==copy.resolve(), (name,target)
    target.write_bytes(z.read(name))
assert hashlib.sha256((copy/'r9_manifest.json').read_bytes()).hexdigest()==receipt['candidate_manifest_sha256']
summary={'archive_sha256':receipt['raw_zip_sha256'],'index_sha256':receipt['entry_index_sha256'],
 'archive_testzip':'passed','archive_members':len(names),'indexed_files':len(index['entries']),
 'manifest_payloads':len(manifest['payload_sha256']),'archive_entry_hashes_verified':len(index['entries']),
 'manifest_sha256':receipt['candidate_manifest_sha256'],'manifest_status':manifest['status'],
 'isolated_copy':str(copy),'isolated_copy_verified_files':len(names)}
(qa/'archive-verification.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
