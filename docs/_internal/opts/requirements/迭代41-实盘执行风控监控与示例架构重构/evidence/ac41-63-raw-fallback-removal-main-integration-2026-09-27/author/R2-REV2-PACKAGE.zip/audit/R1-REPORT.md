# AC41-63 controlled writer slice 2

Date: 2026-09-27  
Decision: **NO_WRITE / LIVE_NO_GO**. This evidence does not accept any account route, CTP writer, or live path.

## Scope and frozen inputs

This is a read-only trace of 12 distinct, previously unreviewed candidates from the frozen 389-entry AC41-63 inventory, plus a fail-closed patch kept in an isolated `D:\temp` copy. No repository files were changed. No private config, credentials, account, native library, real CTP SDK, network endpoint, order, or cancel was accessed.

Frozen input hashes:

- Source manifest: `423CB56E86375019307D252AD774706A259161D7D4EF7B605410EDB0FC889FC6`
- Candidate inventory: `FACBBC93067D77A317E3A0ABDE5EF89BC77BD53E4A4EB18722B51124E3E20780`
- Writer dispositions: `95116E8866A50D645664764856F1CEB6E855B3D05E540F7E38D59F30EA65C7FD`
- Frozen `backtrader/stores/btapistore.py`: `DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826`

The inventory contains 327 writer candidates and 62 dynamic candidates. The prior slice reviewed 10 IDs. This slice adds 12 distinct IDs, so 22/389 have been traced across the two slices and 367 remain unexamined. The authoritative disposition JSON is unchanged: all 389 entries remain `REVIEW_REQUIRED / NOT_AVAILABLE`; this report does not turn any candidate into “safe” or “closed.”

## Reachable CTP request path

The frozen source shows a direct Python path into the raw CTP request methods:

1. `BtApiStore._resolve_bt_api_client` returns the CTP wrapper class when the provider is `ctp` (`backtrader/stores/btapistore.py:1761-1775`).
2. `BtApiBroker.submit` performs local order checks and consumes a broker approval operation before calling `self.store.submit_order(order)` (`backtrader/brokers/btapibroker.py:2812-2875`).
3. `BtApiStore.submit_order` routes to `_submit_order_legacy` when no managed adapter is attached (`backtrader/stores/btapistore.py:7723-7727`). The legacy dispatcher calls `api.submit_order(payload)` (`:7937-7938`); prior-slice fake probes reached this delegate.
4. `CtpClientWrapper.submit_order` builds a native CTP request and calls `_send_native_order_insert` (`backtrader/stores/btapistore.py:2539-2610`). The native helper’s prior-slice candidate is `i41-writer-fbe05d71d70ed65a9838` at `:1935`: when the typed method or capability is missing, the old code fell through to `trader_client.api.ReqOrderInsert(field, req_id)` at `:1939-1941`.
5. Cancellation has the corresponding path: Store cancellation without an adapter delegates to `_cancel_order_ref_legacy` (`:8006-8008`, `:8065-8068`), which calls `api.cancel_order` (`:8243-8249`). `CtpClientWrapper.cancel_order` calls `_send_native_order_action` (`:2636-2678`); the old helper fell through to raw `ReqOrderAction` at `:1943-1949`.

Thus the default registered CLI’s closed CTP route does not close this separate direct Python Store/wrapper route. The old fallbacks were reachable by source composition, but no real SDK or provider call was attempted. The source comment assumed an SDK build without the typed gate handled fallback safely; that SDK behavior and build were not verified.

## New slice candidates

Each candidate retains its frozen official `REVIEW_REQUIRED / NOT_AVAILABLE` status. The observation column is static path mapping only.

| Candidate ID | Source point | Trace observation |
|---|---|---|
| `i41-writer-5c76e7bbaaf9eaf8fafb` | `backtrader/brokers/btapibroker.py:2875` | Broker submit front door reaches Store after local validation/approval checks; downstream Store route decides managed versus legacy dispatch. |
| `i41-writer-6df08432c5aec510239a` | `backtrader/brokers/btapibroker.py:3103` | Broker cancel reaches Store after local cancel guards and approval handling; downstream route remains unresolved. |
| `i41-writer-921a46a1979e1076c023` | `backtrader/brokers/btapibroker.py:4367` | Remote-open-order cleanup reaches `cancel_order_ref`; helper checks Store and nonempty reference, but has no local Order object. Caller-level authority binding was not fully traced. |
| `i41-writer-5c0e163572ea9a5a8fe4` | `backtrader/stores/btapistore.py:2634` | CTP wrapper `create_order` aliases to `submit_order`, which reaches the prior-slice native insert candidate. |
| `i41-writer-bf56d1ec1d8f9b98d4fd` | `backtrader/stores/btapistore.py:7823` | Managed CTP Store invokes the supplied adapter with a one-use, exact-type command enqueue callback. Adapter code is caller-provided Python; callback constraints do not constrain side effects outside the callback. |
| `i41-writer-4817d2f7cc8d1a6f137d` | `backtrader/stores/managed_execution.py:773` | Typed adapter validator checks the `submit_order` attribute and version; this is shape validation, not code identity. Descriptor access can execute Python. |
| `i41-writer-9d6b74c674a29822eabd` | `backtrader/stores/managed_execution.py:775` | Typed adapter validator checks the `cancel_order` attribute and returns the caller object. |
| `i41-writer-9272fb151289cdcd07a9` | `backtrader/stores/managed_execution.py:806` | Generic adapter validation checks only that `submit_order` is callable. |
| `i41-writer-789fa193cd6ecb32323e` | `backtrader/stores/managed_execution.py:816` | Generic cancellation validation checks only that `cancel_order` is callable. |
| `i41-writer-4e6bdd63429f38994dff` | `backtrader_runtime/ctp_trader_client_port.py:1014` | Typed simulation port resolves SDK insert only after staged-write, request-type, order-reference, and identity checks; it then requires verifier consumption/evidence. SDK provenance and behavior remain unverified. |
| `i41-writer-4b56f8cf4860c5fec787` | `backtrader_runtime/managed_execution.py:2800` | Cancellation control dynamically imports its SDK plugin after authorization, recovery, supported-route, and state-directory checks. This is composition, not itself a native request. |
| `i41-writer-e7d7f270d49ed8f4d8aa` | `backtrader_runtime/managed_execution.py:2869` | Cancellation facade requires writer-lease/facade and risk gate/scope facts before importing the risk package. No provider request occurs in this method. |

Full candidate objects and per-candidate notes are in `selected-candidates.json`; frozen line windows are in `source-extracts.txt`.

## Isolated fail-closed patch

`PATCH.diff` changes only `_send_native_order_insert` and `_send_native_order_action` in the frozen Store copy. Both methods now:

1. reject a missing `_execution_gate_capability` before reading the typed SDK attribute;
2. require the typed SDK method to be callable; and
3. call only that typed method when both conditions hold.

The raw `ReqOrderInsert` and `ReqOrderAction` fallbacks are removed. The patch is separate from the audit package and was not applied to the shared repository. It addresses the narrow raw fallback only.

The fake boundary probe invokes the actual patched `CtpClientWrapper` methods with fake CTP struct classes and fake trader clients. For both insert and cancel, it covers: (a) missing capability with a trap descriptor, (b) capability present but typed method missing, and (c) capability and typed fake present. All six cases passed. In the missing-capability cases the typed descriptor read count was **0**. Across every case, `.api` access count and raw native call count were **0**. A typed fake was called only in case (c). Raw JSON output is `fake-boundary-probe.json`.

## Legacy compatibility checks

Tests used the targeted committed `HEAD` unit-test files and an isolated source tree built from the frozen application snapshot. The test harness supplies fake `bt_api_ctp` modules and blocks real `bt_api_py`, `bt_api_risk`, or unexpected `bt_api_ctp` imports. These are local fake tests; no real SDK was loaded. The synchronous focus used `pytest -p no:asyncio` because the installed pytest-asyncio plugin fails collection for this environment’s pytest package collector.

- Baseline: `test_ctp_wrapper_submit_order_supports_exchange_prefixed_symbol_and_preserves_order_ref` — **1 passed** using its raw fake `ReqOrderInsert` client.
- Patched: same legacy test — **1 expected failure** at the new gate. This is a real compatibility change: a direct wrapper/client exposing only raw `ReqOrderInsert` can no longer submit; it must supply the typed method and an armed capability.
- Patched negative focus — **5 passed**: three invalid-lot cases, unsupported CTP Market order rejection, and implicit settlement-write rejection.

Raw pytest logs and exit records are included. The expected failure is not hidden or counted as a pass.

## Limits and required follow-up

`_execution_gate_capability` remains same-process mutable private state. A caller able to mutate the wrapper and inject a `trader_client` can forge a non-`None` object and cause the wrapper to call the injected typed method. The patch creates no trusted per-action grant, external actor, caller identity binding, or SDK attestation. The typed SDK method’s enforcement is unverified. Do not interpret the typed fake dispatch case as an authorization success.

Other generic Store/API delegates, adapters, provider lifecycle, account scope, G4/G5, default-runner integration, and production behavior remain unresolved. Overall posture stays **NO_WRITE / LIVE_NO_GO**.

The frozen base does not contain the later r2b/r2c wiring. Reapply or resolve this two-method patch after that wiring is integrated, then rerun the fake descriptor probe and the legacy compatibility focus against the resulting candidate. This bundle is not acceptance of an r2b/r2c integration.
