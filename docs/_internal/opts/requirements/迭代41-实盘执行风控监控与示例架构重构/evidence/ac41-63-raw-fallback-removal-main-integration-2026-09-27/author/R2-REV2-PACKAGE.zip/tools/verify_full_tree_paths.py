from pathlib import Path
import hashlib, json
root=Path(r"D:\temp\ac41-63-writer-slice2-r2-20260927")
before=root/"source-apply-before"
after=root/"source-apply-after"
def manifest(directory):
    return {
        p.relative_to(directory).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in directory.rglob("*") if p.is_file()
    }
a=manifest(before); b=manifest(after)
assert set(a)==set(b), (sorted(set(a)-set(b)), sorted(set(b)-set(a)))
changed=sorted(k for k in a if a[k]!=b[k])
assert changed==["backtrader/stores/btapistore.py"], changed
assert a[changed[0]]=="dba2989252db76fe010fbee7caacdcdba34a9b951e3702724156482b67fae826"
assert b[changed[0]]=="05268b4953a20fa0699639f7e05ee354a4bcafc4b47915dd4ba352b26276e0d9"
out={
 "before_file_count": len(a),
 "after_file_count": len(b),
 "changed_paths": changed,
 "path_sets_equal": True,
 "base_sha256": a[changed[0]],
 "target_sha256": b[changed[0]],
 "no_other_path_mutation": True,
}
(root/"NO-OTHER-PATH-ASSERTION.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
print(json.dumps(out,indent=2))
