from pathlib import Path
import base64, hashlib, json

root = Path(r"D:\temp\ac41-63-writer-slice2-r2-20260927")
base_path = root / "baseline-unmigrated/backtrader/stores/btapistore.py"
target_path = root / "patched-unmigrated/backtrader/stores/btapistore.py"
base = base_path.read_bytes()
target = target_path.read_bytes()

def block(lines):
    return ("\r\n".join(lines) + "\r\n").encode("ascii")

old_insert = block([
    "        def _send_native_order_insert(self, field, req_id):",
    '            """Route one order insert through the typed execution gate."""',
    '            typed = getattr(self.trader_client, "submit_order_insert", None)',
    "            capability = self._execution_gate_capability",
    "            if callable(typed) and capability is not None:",
    "                return typed(field, req_id, execution_capability=capability)",
    "            # SDK builds without the execution gate keep the raw path; on",
    "            # gated builds an unarmed fallback fails closed inside the SDK.",
    "            return self.trader_client.api.ReqOrderInsert(field, req_id)",
])
new_insert = block([
    "        def _send_native_order_insert(self, field, req_id):",
    '            """Require a typed SDK method and non-null capability for native inserts."""',
    "            capability = self._execution_gate_capability",
    "            if capability is None:",
    "                raise BtApiStoreError(",
    '                    "CTP order insert requires the typed execution gate and capability"',
    "                )",
    '            typed = getattr(self.trader_client, "submit_order_insert", None)',
    "            if not callable(typed):",
    "                raise BtApiStoreError(",
    '                    "CTP order insert requires the typed execution gate and capability"',
    "                )",
    "            return typed(field, req_id, execution_capability=capability)",
])
old_action = block([
    "        def _send_native_order_action(self, field, req_id):",
    '            """Route one order action (cancel) through the typed gate."""',
    '            typed = getattr(self.trader_client, "submit_order_action", None)',
    "            capability = self._execution_gate_capability",
    "            if callable(typed) and capability is not None:",
    "                return typed(field, req_id, execution_capability=capability)",
    "            return self.trader_client.api.ReqOrderAction(field, req_id)",
])
new_action = block([
    "        def _send_native_order_action(self, field, req_id):",
    '            """Require a typed SDK method and non-null capability for native cancels."""',
    "            capability = self._execution_gate_capability",
    "            if capability is None:",
    "                raise BtApiStoreError(",
    '                    "CTP order action requires the typed execution gate and capability"',
    "                )",
    '            typed = getattr(self.trader_client, "submit_order_action", None)',
    "            if not callable(typed):",
    "                raise BtApiStoreError(",
    '                    "CTP order action requires the typed execution gate and capability"',
    "                )",
    "            return typed(field, req_id, execution_capability=capability)",
])

assert hashlib.sha256(base).hexdigest() == "dba2989252db76fe010fbee7caacdcdba34a9b951e3702724156482b67fae826"
assert hashlib.sha256(target).hexdigest() == "05268b4953a20fa0699639f7e05ee354a4bcafc4b47915dd4ba352b26276e0d9"
assert base.count(old_insert) == base.count(old_action) == 1
insert_at = base.index(old_insert)
action_at = base.index(old_action)
assert insert_at < action_at
expected = (
    base[:insert_at] + new_insert
    + base[insert_at + len(old_insert):action_at] + new_action
    + base[action_at + len(old_action):]
)
assert expected == target, "unrelated source bytes changed"

def manifest(directory):
    result = {}
    for path in Path(directory).rglob("*"):
        if path.is_file():
            result[path.relative_to(directory).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

before_dir = root / "gitpatch-check"
after_dir = root / "gitpatch-apply"
before_files = manifest(before_dir)
after_files = manifest(after_dir)
assert set(before_files) == set(after_files), "file additions/deletions occurred"
changed_paths = sorted(path for path in before_files if before_files[path] != after_files[path])
assert changed_paths == ["backtrader/stores/btapistore.py"], changed_paths
assert before_files[changed_paths[0]] == hashlib.sha256(base).hexdigest()
assert after_files[changed_paths[0]] == hashlib.sha256(target).hexdigest()

def fragment(old, new, old_offset, new_offset):
    return {
        "old_offset": old_offset,
        "old_length": len(old),
        "old_sha256": hashlib.sha256(old).hexdigest(),
        "old_base64": base64.b64encode(old).decode("ascii"),
        "new_offset": new_offset,
        "new_length": len(new),
        "new_sha256": hashlib.sha256(new).hexdigest(),
        "new_base64": base64.b64encode(new).decode("ascii"),
    }
meta = {
    "base_path": "backtrader/stores/btapistore.py",
    "base_sha256": hashlib.sha256(base).hexdigest(),
    "base_bytes": len(base),
    "base_crlf_count": base.count(b"\r\n"),
    "base_lf_count": base.count(b"\n"),
    "base_bare_lf_count": base.count(b"\n") - base.count(b"\r\n"),
    "target_sha256": hashlib.sha256(target).hexdigest(),
    "target_bytes": len(target),
    "target_crlf_count": target.count(b"\r\n"),
    "target_lf_count": target.count(b"\n"),
    "target_bare_lf_count": target.count(b"\n") - target.count(b"\r\n"),
    "exact_expected_bytes_match": True,
    "unchanged_prefix_between_and_suffix_asserted": True,
    "no_other_path_mutation_assertion": {
        "before_file_count": len(before_files),
        "after_file_count": len(after_files),
        "changed_paths": changed_paths,
        "passed": True,
    },
    "standard_git_patch": {
        "path": "PATCH-GIT.diff",
        "sha256": hashlib.sha256((root / "PATCH-GIT.diff").read_bytes()).hexdigest(),
        "strict_apply_check_passed_core_autocrlf_false": True,
        "strict_apply_passed_core_autocrlf_false": True,
        "applied_output_sha256_matches_target": hashlib.sha256((after_dir / changed_paths[0]).read_bytes()).hexdigest() == hashlib.sha256(target).hexdigest(),
    },
    "test_migration": {
        "path": "TEST-MIGRATION.diff",
        "sha256": hashlib.sha256((root / "TEST-MIGRATION.diff").read_bytes()).hexdigest(),
        "preserves_existing_nodeid": "test_ctp_wrapper_submit_order_supports_exchange_prefixed_symbol_and_preserves_order_ref",
        "adds_nodeid": "test_ctp_wrapper_submit_order_rejects_raw_only_client_before_api_access",
        "git_apply_check_on_current_main_tree": "pending-final-rerun",
    },
    "replacements": [
        fragment(old_insert, new_insert, insert_at, insert_at),
        fragment(old_action, new_action, action_at, action_at + len(new_insert) - len(old_insert)),
    ],
}
(root / "BYTE-REPLACEMENTS.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in meta.items() if k != "replacements"}, indent=2))
