from pathlib import Path
import difflib, hashlib, json
root=Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-20260927")
test= root/"patched/tests/unit/stores/test_btapistore.py"
text=test.read_text(encoding="utf-8")
marker='@pytest.mark.parametrize("size", [0, 1.5, "bad"])'
assert text.count(marker)==1
addition='''@pytest.mark.parametrize(
    "has_capability,typed_mode",
    [(False, "trap"), (True, "missing")],
    ids=["missing-capability", "missing-typed-method"],
)
def test_ctp_wrapper_cancel_rejects_without_raw_action_access(has_capability, typed_mode):
    """Native cancel fails closed before raw ReqOrderAction when the typed gate is absent."""
    optional_sdk("bt_api_ctp.ctp.client")
    wrapper_cls = _create_ctp_wrapper_class()

    class FakeApi:
        def __init__(self):
            self.raw_calls = 0

        def ReqOrderAction(self, field, req_id):
            self.raw_calls += 1
            raise AssertionError("raw ReqOrderAction must not be reached")

    class FakeTraderClient:
        is_ready = True

        def __init__(self):
            self.api_reads = 0
            self.typed_method_reads = 0
            self.raw_api = FakeApi()

        @property
        def submit_order_action(self):
            self.typed_method_reads += 1
            if typed_mode == "trap":
                raise AssertionError("typed action descriptor must not be read without capability")
            return None

        @property
        def api(self):
            self.api_reads += 1
            return self.raw_api

    client = wrapper_cls()
    client.trader_client = FakeTraderClient()
    client._execution_gate_capability = object() if has_capability else None

    with pytest.raises(BtApiStoreError, match="typed execution gate and capability"):
        client._send_native_order_action(object(), 17)

    assert client.trader_client.api_reads == 0
    assert client.trader_client.raw_api.raw_calls == 0
    assert client.trader_client.typed_method_reads == (0 if not has_capability else 1)


'''
text=text.replace(marker, addition+marker,1)
test.write_text(text,encoding="utf-8")
# Same test migration is used against baseline source for expected-negative comparisons.
(root/"baseline/tests/unit/stores/test_btapistore.py").write_bytes(test.read_bytes())
original=Path(r"D:\temp\ac41-63-writer-slice2-20260927\audit-bundle\test-harness\test_btapistore.py")
diff="".join(difflib.unified_diff(
    original.read_text(encoding="utf-8").splitlines(True),
    test.read_text(encoding="utf-8").splitlines(True),
    fromfile="a/tests/unit/stores/test_btapistore.py",
    tofile="b/tests/unit/stores/test_btapistore.py",
))
(root/"TEST-MIGRATION.diff").write_text(diff,encoding="utf-8")
summary={
 "existing_insert_nodeid_preserved":"test_ctp_wrapper_submit_order_supports_exchange_prefixed_symbol_and_preserves_order_ref",
 "insert_negative_nodeid":"test_ctp_wrapper_submit_order_rejects_raw_only_client_before_api_access",
 "cancel_negative_param_nodeid":"test_ctp_wrapper_cancel_rejects_without_raw_action_access",
 "test_file_sha256":hashlib.sha256(test.read_bytes()).hexdigest(),
 "migration_diff_sha256":hashlib.sha256((root/"TEST-MIGRATION.diff").read_bytes()).hexdigest(),
}
(root/"TEST-MIGRATION-METADATA.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
print(json.dumps(summary,indent=2))

