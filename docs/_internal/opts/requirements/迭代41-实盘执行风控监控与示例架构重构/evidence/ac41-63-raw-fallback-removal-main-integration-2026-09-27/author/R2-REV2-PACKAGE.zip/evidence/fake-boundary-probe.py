from pathlib import Path
import sys
cwd = Path.cwd()
sys.path.insert(0, str(cwd))
import json
import conftest
from backtrader.stores.btapistore import BtApiStoreError, _create_ctp_wrapper_class

wrapper_cls = _create_ctp_wrapper_class()

class TrapApi:
    def __init__(self):
        self.raw_calls = []
    def ReqOrderInsert(self, *args):
        self.raw_calls.append(("ReqOrderInsert", args))
        raise AssertionError("raw ReqOrderInsert boundary was reached")
    def ReqOrderAction(self, *args):
        self.raw_calls.append(("ReqOrderAction", args))
        raise AssertionError("raw ReqOrderAction boundary was reached")

class FakeTraderClient:
    is_ready = True
    def __init__(self, operation, typed_mode, trap_on_get=False):
        self.operation = operation
        self.typed_mode = typed_mode
        self.trap_on_get = trap_on_get
        self.typed_attr_reads = 0
        self.api_accesses = 0
        self._api = TrapApi()
        self.typed_calls = []
    @property
    def api(self):
        self.api_accesses += 1
        return self._api
    def __getattr__(self, name):
        if name in {"submit_order_insert", "submit_order_action"}:
            self.typed_attr_reads += 1
            if name != self.operation:
                return None
            if self.trap_on_get:
                raise AssertionError("typed method descriptor read before capability check")
            if self.typed_mode == "missing":
                return None
            if self.typed_mode == "noncallable":
                return "not-callable"
            def call(*args, **kwargs):
                self.typed_calls.append((name, args, kwargs))
                return "typed-ok"
            return call
        raise AttributeError(name)

def run_case(operation, typed_mode, capability_present, trap_on_get, expected):
    trader = FakeTraderClient(operation, typed_mode, trap_on_get)
    wrapper = wrapper_cls()
    wrapper.trader_client = trader
    wrapper._execution_gate_capability = object() if capability_present else None
    method_name = "_send_native_order_insert" if operation == "submit_order_insert" else "_send_native_order_action"
    method = getattr(wrapper, method_name)
    outcome = None
    try:
        outcome = method(object(), 17)
    except BtApiStoreError as exc:
        outcome = "rejected:" + str(exc)
    if expected == "reject":
        assert isinstance(outcome, str) and outcome.startswith("rejected:"), (operation, outcome)
        assert trader.typed_calls == [], (operation, trader.typed_calls)
    else:
        assert outcome == "typed-ok", (operation, outcome)
        assert len(trader.typed_calls) == 1, (operation, trader.typed_calls)
    assert trader.api_accesses == 0, (operation, trader.api_accesses)
    assert trader._api.raw_calls == [], (operation, trader._api.raw_calls)
    return {
        "operation": operation,
        "typed_mode": typed_mode,
        "capability_present": capability_present,
        "typed_descriptor_trap": trap_on_get,
        "outcome": outcome,
        "typed_attribute_reads": trader.typed_attr_reads,
        "typed_calls": len(trader.typed_calls),
        "api_property_accesses": trader.api_accesses,
        "raw_native_calls": len(trader._api.raw_calls),
        "pass": True,
    }

results = []
for operation in ("submit_order_insert", "submit_order_action"):
    results.append(run_case(operation, "present", False, True, "reject"))
    results.append(run_case(operation, "missing", True, False, "reject"))
    results.append(run_case(operation, "noncallable", True, False, "reject"))
    results.append(run_case(operation, "present", True, False, "typed"))
summary = {
    "probe": "r2 byte-exact patched CtpClientWrapper methods with inert fake SDK classes",
    "real_sdk_loaded": False,
    "network_used": False,
    "native_boundary_called": False,
    "cases": results,
    "all_pass": all(row["pass"] for row in results),
}
out = Path(r"D:\temp\ac41-63-writer-slice2-r2-20260927\fake-boundary-probe-r2.json")
out.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
