"""Inert CTP package shim for legacy unit tests; never imports a real SDK."""
import sys
import types
from importlib import metadata
from importlib.abc import MetaPathFinder
from types import SimpleNamespace

_original_distribution = metadata.distribution

def _distribution(name):
    if name == "bt_api_ctp":
        return SimpleNamespace(name="bt_api_ctp", version="0.fake")
    return _original_distribution(name)

metadata.distribution = _distribution

class _NoRealOptionalSdk(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in sys.modules:
            return None
        if fullname.split(".", 1)[0] in {"bt_api_py", "bt_api_risk"}:
            raise ImportError("real optional SDK import blocked by isolated test harness")
        if fullname.startswith("bt_api_ctp"):
            raise ImportError("unexpected CTP module import blocked by isolated test harness")
        return None

sys.meta_path.insert(0, _NoRealOptionalSdk())

class _Field:
    pass

class _Spi:
    pass

class _Client:
    pass

root = types.ModuleType("bt_api_ctp")
root.__path__ = []
ctp = types.ModuleType("bt_api_ctp.ctp")
ctp.__path__ = []
client = types.ModuleType("bt_api_ctp.ctp.client")
client.MdClient = _Client
client.TraderClient = _Client
client._MdSpi = _Spi
client._TraderSpi = _Spi
md_api = types.ModuleType("bt_api_ctp.ctp.ctp_md_api")
md_api.CThostFtdcMdSpi = _Spi
order_structs = types.ModuleType("bt_api_ctp.ctp.ctp_structs_order")
order_structs.CThostFtdcInputOrderActionField = _Field
order_structs.CThostFtdcInputOrderField = _Field
trader_api = types.ModuleType("bt_api_ctp.ctp.ctp_trader_api")
trader_api.CThostFtdcTraderSpi = _Spi

root.ctp = ctp
ctp.client = client
ctp.ctp_md_api = md_api
ctp.ctp_structs_order = order_structs
ctp.ctp_trader_api = trader_api
sys.modules.update({
    "bt_api_ctp": root,
    "bt_api_ctp.ctp": ctp,
    "bt_api_ctp.ctp.client": client,
    "bt_api_ctp.ctp.ctp_md_api": md_api,
    "bt_api_ctp.ctp.ctp_structs_order": order_structs,
    "bt_api_ctp.ctp.ctp_trader_api": trader_api,
})
