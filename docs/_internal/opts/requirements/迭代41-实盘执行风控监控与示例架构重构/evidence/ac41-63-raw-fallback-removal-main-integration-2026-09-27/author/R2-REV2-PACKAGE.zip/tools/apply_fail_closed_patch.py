from pathlib import Path
import hashlib
import sys

EXPECTED_BASE_SHA256 = "dba2989252db76fe010fbee7caacdcdba34a9b951e3702724156482b67fae826"
ERROR_INSERT = "CTP order insert requires the typed execution gate and capability"
ERROR_ACTION = "CTP order action requires the typed execution gate and capability"

def block(lines):
    return ("\r\n".join(lines) + "\r\n").encode("ascii")

old_insert = block([
    "        def _send_native_order_insert(self, field, req_id):",
    '            """Route one order insert through the typed execution gate."""',
    '            typed = getattr(self.trader_client, "submit_order_insert", None)',
    "            capability = self._execution_gate_capability",
    "            if callable(typed) and capability is not None:",
    "                return typed(field, req_id, execution_capability=capability)",
    "            # SDK builds without the execution gate keep the raw path; on",
    "            # gated builds an unarmed fallback fails closed inside the SDK.",
    "            return self.trader_client.api.ReqOrderInsert(field, req_id)",
])
new_insert = block([
    "        def _send_native_order_insert(self, field, req_id):",
    '            """Require a typed SDK method and non-null capability for native inserts."""',
    "            capability = self._execution_gate_capability",
    "            if capability is None:",
    "                raise BtApiStoreError(",
    '                    "CTP order insert requires the typed execution gate and capability"',
    "                )",
    '            typed = getattr(self.trader_client, "submit_order_insert", None)',
    "            if not callable(typed):",
    "                raise BtApiStoreError(",
    '                    "CTP order insert requires the typed execution gate and capability"',
    "                )",
    "            return typed(field, req_id, execution_capability=capability)",
])
old_action = block([
    "        def _send_native_order_action(self, field, req_id):",
    '            """Route one order action (cancel) through the typed gate."""',
    '            typed = getattr(self.trader_client, "submit_order_action", None)',
    "            capability = self._execution_gate_capability",
    "            if callable(typed) and capability is not None:",
    "                return typed(field, req_id, execution_capability=capability)",
    "            return self.trader_client.api.ReqOrderAction(field, req_id)",
])
new_action = block([
    "        def _send_native_order_action(self, field, req_id):",
    '            """Require a typed SDK method and non-null capability for native cancels."""',
    "            capability = self._execution_gate_capability",
    "            if capability is None:",
    "                raise BtApiStoreError(",
    '                    "CTP order action requires the typed execution gate and capability"',
    "                )",
    '            typed = getattr(self.trader_client, "submit_order_action", None)',
    "            if not callable(typed):",
    "                raise BtApiStoreError(",
    '                    "CTP order action requires the typed execution gate and capability"',
    "                )",
    "            return typed(field, req_id, execution_capability=capability)",
])

if len(sys.argv) != 2:
    raise SystemExit("usage: apply_fail_closed_patch.py PATH_TO_btapistore.py")
path = Path(sys.argv[1]).resolve()
original = path.read_bytes()
base_sha = hashlib.sha256(original).hexdigest()
if base_sha != EXPECTED_BASE_SHA256:
    raise SystemExit(f"refusing unexpected base SHA-256: {base_sha}")
if original.count(old_insert) != 1 or original.count(old_action) != 1:
    raise SystemExit("refusing because exact CRLF method blocks are not unique")
patched = original.replace(old_insert, new_insert, 1).replace(old_action, new_action, 1)
path.write_bytes(patched)
print(f"base_sha256={base_sha}")
print(f"patched_sha256={hashlib.sha256(patched).hexdigest()}")
print(f"input_bytes={len(original)} output_bytes={len(patched)}")
print(f"untouched bytes preserved: {len(patched) == len(original) + len(new_insert) - len(old_insert) + len(new_action) - len(old_action)}")
