from pathlib import Path
import hashlib, json, xml.etree.ElementTree as ET
root=Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-20260927")

def summarize_junit(name):
    path=root/name
    tree=ET.parse(path).getroot()
    suites=[tree] if tree.tag=="testsuite" else list(tree.iter("testsuite"))
    out={"tests":0,"failures":0,"errors":0,"skipped":0,"time_seconds":0.0,"junit_path":name,"junit_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"failure_nodeids":[]}
    for suite in suites:
        for k in ("tests","failures","errors","skipped"): out[k]+=int(suite.attrib.get(k,0))
        out["time_seconds"]+=float(suite.attrib.get("time",0))
        for case in suite.iter("testcase"):
            mod=case.attrib.get("classname","").replace(".","/")+".py"
            nodeid=mod+"::"+case.attrib.get("name","")
            for kind in ("failure","error"):
                failure=case.find(kind)
                if failure is not None:
                    out["failure_nodeids"].append({"nodeid":nodeid,"kind":kind,"message":failure.attrib.get("message","")[:260]})
    return out

scenario_files={
 "focused_before_baseline_with_migration":"baseline-focused.xml",
 "focused_after_patch_with_migration":"patched-focused.xml",
 "two_files_before_baseline_with_migration":"baseline-full.xml",
 "two_files_after_patch_with_migration":"patched-full.xml",
}
scenarios={key:summarize_junit(file) for key,file in scenario_files.items()}
probe=json.loads((root/"fake-boundary-probe-r2.json").read_text(encoding="utf-8"))
migrated=Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-20260927\patched\tests\unit\stores\test_btapistore.py")
patch_text=(root/"TEST-MIGRATION.diff").read_text(encoding="utf-8")
headers=[line[6:] for line in patch_text.splitlines() if line.startswith("--- a/") or line.startswith("+++ b/")]
changed_paths=sorted({h for h in headers})
assert changed_paths==["tests/unit/stores/test_btapistore.py"],changed_paths
test_path_assertion={
 "test_migration_patch_sha256":hashlib.sha256((root/"TEST-MIGRATION.diff").read_bytes()).hexdigest(),
 "patched_paths":changed_paths,
 "single_file_only":True,
 "current_main_apply_check_read_only_exit":0,
 "applied_to_main":False,
}
(root/"TEST-PATH-ASSERTION.json").write_text(json.dumps(test_path_assertion,indent=2)+"\n",encoding="utf-8")
results={
 "schema":"ac41-63-writer-slice2-r2-rev2-results",
 "scope":["tests/unit/stores/test_btapistore.py","tests/unit/stores/test_btapistore_iteration22.py"],
 "real_sdk_loaded":False,"network_used":False,"native_boundary_called":False,
 "scenarios":scenarios,
 "fake_boundary_probe":{"cases":len(probe["cases"]),"all_pass":probe["all_pass"],"path":"fake-boundary-probe-r2.json","sha256":hashlib.sha256((root/"fake-boundary-probe-r2.json").read_bytes()).hexdigest()},
 "test_patch_paths":changed_paths,
 "test_patch_current_main_apply_check":"PASS_READ_ONLY",
 "source_patch_same_as_r2":True,
}
(root/"R2-REV2-RESULTS.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
manifest=json.loads((root/"R1-selected-candidates.json").read_text(encoding="utf-8"))
new_ids=[x["candidate_id"] for x in manifest["new_slice"]]
prev_ids=manifest["prior_reviewed_ids"]
report=f'''# AC41-63 CTP direct-writer fallback — r2 rev2

Status: isolated fail-closed patch candidate; NO_WRITE / LIVE_NO_GO. Nothing was applied to the shared main tree.

## Scope and authority

Raw CTP insert/action fallbacks were reachable from direct Python wrapper methods. The insert sink is prior reviewed candidate i41-writer-fbe05d71d70ed65a9838 at backtrader/stores/btapistore.py:1935; the corresponding raw action is at :1943-1949. The new slice includes i41-writer-5c0e163572ea9a5a8fe4 for CtpClientWrapper.create_order, an alias/reachable route to the same insert helper at :2608. The first two controlled slices cover 22 of 389 inventory candidates; 367 remain unexamined. Every static inventory disposition remains REVIEW_REQUIRED / NOT_AVAILABLE.

New slice candidate IDs: {", ".join(new_ids)}.
Prior reviewed IDs remain in R1-selected-candidates.json.

The source patch removes raw ReqOrderInsert / ReqOrderAction fallbacks. Missing capability is rejected before typed SDK attribute access; missing/non-callable typed methods reject before .api access. It does not establish write authorization: _execution_gate_capability remains mutable same-process private state, and injected capability plus typed method can produce fake calls. There is no trusted per-action grant or external Actor.

## Frozen source facts

Source patch SHA-256: {hashlib.sha256((root/"PATCH-GIT.diff").read_bytes()).hexdigest()}.
Exact base Store SHA-256: dba2989252db76fe010fbee7caacdcdba34a9b951e3702724156482b67fae826.
Patched Store target SHA-256: 05268b4953a20fa0699639f7e05ee354a4bcafc4b47915dd4ba352b26276e0d9.
The exact mixed-EOL byte replacement has a hash-pinned applicator plus a standard Git patch validated with core.autocrlf=false. The patch preserves mixed line endings and applied to an isolated clone with target SHA equality. The 1025-file before/after manifest shows only backtrader/stores/btapistore.py changed.

## Final test migration

TEST-MIGRATION.diff SHA-256: {hashlib.sha256((root/"TEST-MIGRATION.diff").read_bytes()).hexdigest()}.
It preserves the submit positive test nodeid and changes that fake to require typed submit plus a non-null capability. It adds a raw-only submit rejection test with typed descriptor and .api traps. It also adds a parameterized cancellation negative test with two cases:
- missing capability: typed action descriptor, .api, and raw ReqOrderAction all have zero reads/calls;
- capability present but typed method absent: .api and raw ReqOrderAction remain zero.

The migration patch modifies only tests/unit/stores/test_btapistore.py. Read-only git apply --check passed against the current main test source; no patch was applied. Source patch current-main checks were already passed against the same exact Store base.

## Verification

Eight boundary probes against the exact byte-patched methods passed: for insert and action, absent capability rejects before trap-attribute access; missing and non-callable typed methods reject; typed fake with capability calls only the typed fake. Every case recorded zero .api property access and zero raw Req* calls.

The final focused JUnit has four selectors: baseline source with migration has 1 pass / 3 expected gate failures; patched source with migration has 4 passes. The two full relevant test files with the same migration have baseline 335 pass / 6 failures and patched 338 pass / 3 failures. The only three patched failures are shared harness/fixture limitations:
- tests/unit/stores/test_btapistore.py::test_create_ctp_wrapper_patches_missing_spi_callbacks (inert shim lacks OnRspQryInvestorPositionDetail);
- tests/unit/stores/test_btapistore.py::test_ctp_wrapper_fetch_open_orders_converts_ctp_rows (real optional CTP order-container import is blocked);
- tests/unit/stores/test_btapistore_iteration22.py::test_managed_order_request_carries_strategy_cycle_and_recovery_role (fixture lacks persisted runtime_order_id binding).

Baseline-only failures additionally include the submit raw-only descriptor trap and both cancellation cases. JUnit documents with exact nodeids are in R2-REV2-RESULTS.json. All runs used inert CTP fakes and SDK import guards; no real SDK, network, native code, provider session, or order was used.

## Application order and supersession

Apply PATCH-GIT.diff first, then TEST-MIGRATION.diff, and rerun the two listed files. r2 rev2 supersedes the initial r2 package only for the test migration and related results. The initial r2 ZIP remains preserved unchanged. r1 also remains preserved unchanged with its NEEDS_REVISION QA state; r2 is the superseding source patch artifact. Replay and review after r2b/r2c wiring or any source change. Parent independent QA and broader regression are still required; do not infer merge readiness or live authorization.
'''
(root/"R2-REV2-REPORT.md").write_text(report,encoding="utf-8")
print(json.dumps({
 "test_migration_sha256":hashlib.sha256((root/"TEST-MIGRATION.diff").read_bytes()).hexdigest(),
 "results_sha256":hashlib.sha256((root/"R2-REV2-RESULTS.json").read_bytes()).hexdigest(),
 "test_path_assertion_sha256":hashlib.sha256((root/"TEST-PATH-ASSERTION.json").read_bytes()).hexdigest(),
 "report_sha256":hashlib.sha256((root/"R2-REV2-REPORT.md").read_bytes()).hexdigest(),
 "candidate_counts":{"inventory":389,"previous":10,"new":12,"cumulative":22,"remaining":367},
 "new_ids":new_ids,
 "scenarios":{k:{"tests":v["tests"],"failures":v["failures"],"failure_nodeids":[f["nodeid"] for f in v["failure_nodeids"]]} for k,v in scenarios.items()},
},indent=2))

