from __future__ import annotations
import hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-independent-qa-20260927")
PKG=ROOT/"qa-package"; CONTENT=PKG/"content"; MANIFEST=CONTENT/"QA-PACKAGE-MANIFEST.json"; ZIP=PKG/"QA-PACKAGE.zip"
def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
rows=[]
for p in sorted(CONTENT.rglob("*")):
    if p.is_file() and p!=MANIFEST:
        b=p.read_bytes(); rows.append({"path":p.relative_to(CONTENT).as_posix(),"bytes":len(b),"sha256":sha(b)})
meta={"schema":"ac41-63-writer-slice2-r2-rev2-independent-qa-package-v1","verdict":"SAFE_TO_APPLY_RAW_FALLBACK_REMOVAL_ONLY","status":"AUTHOR_CANDIDATE_NO_WRITE_LIVE_NO_GO; independent scope limited to raw fallback removal","artifact_count":len(rows),"author_input":{"zip_sha256":"c9a2456d6fff2a1d5743f2402d423eb783720dff90cbe02164e83d27216e3e0b","manifest_sha256":"ad48e4dd52404bcb97180aa7fd49f7312bc39dce1cabf3194d0288f39658226a","store_patch_sha256":"2182f12a729afc39dfa6ba4c23bb4accd557f4dcda3138ef238cb039e52de291","test_patch_sha256":"43217ec36a412d68e91133ff9c2b640a47dc0ae49c1eac64abc0cb0b3bc39d7b"},"artifacts":rows}
MANIFEST.write_text(json.dumps(meta,indent=2)+"\n",encoding="utf-8")
with zipfile.ZipFile(ZIP,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(CONTENT.rglob("*")):
        if p.is_file(): z.write(p,p.relative_to(CONTENT).as_posix())
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(rows)+1
    for r in rows:
        d=z.read(r["path"]); assert len(d)==r["bytes"] and sha(d)==r["sha256"],r["path"]
    assert z.read("QA-PACKAGE-MANIFEST.json")==MANIFEST.read_bytes()
h=sha(ZIP.read_bytes()); (PKG/"QA-PACKAGE.SHA256.txt").write_text(f"{h}  QA-PACKAGE.zip\n",encoding="ascii")
print(json.dumps({"zip":str(ZIP),"zip_sha256":h,"manifest":str(MANIFEST),"manifest_sha256":sha(MANIFEST.read_bytes()),"receipt_sha256":sha((CONTENT/"qa/QA-RECEIPT.md").read_bytes()),"artifact_count":len(rows),"zip_members":len(rows)+1,"zip_testzip":None},sort_keys=True))
