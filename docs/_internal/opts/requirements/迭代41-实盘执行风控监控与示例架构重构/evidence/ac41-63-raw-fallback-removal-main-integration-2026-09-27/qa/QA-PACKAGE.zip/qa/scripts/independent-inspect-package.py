import json, zipfile
from pathlib import Path
root=Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-20260927")
manifest=json.loads((root/"package-content"/"R2-REV2-PACKAGE-MANIFEST.json").read_text(encoding="utf-8"))
with zipfile.ZipFile(root/"R2-REV2-PACKAGE.zip") as z:
 print(json.dumps({"manifest_entries":len(manifest.get("artifacts",[])),"artifact_paths":[e["path"] for e in manifest.get("artifacts",[])],"zip_entries":len(z.namelist()),"zip_names":z.namelist()[:15],"zip_testzip":z.testzip()},indent=2))
