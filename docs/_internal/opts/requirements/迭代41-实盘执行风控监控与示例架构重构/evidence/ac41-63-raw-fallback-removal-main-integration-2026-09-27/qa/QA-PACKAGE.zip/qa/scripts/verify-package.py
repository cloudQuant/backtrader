from __future__ import annotations
import hashlib, json, pathlib, zipfile
ROOT = pathlib.Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-20260927")
PKG = ROOT / "package-content"
ZIP = ROOT / "R2-REV2-PACKAGE.zip"
MANIFEST = PKG / "R2-REV2-PACKAGE-MANIFEST.json"
EXPECTED = {
    "zip": "c9a2456d6fff2a1d5743f2402d423eb783720dff90cbe02164e83d27216e3e0b",
    "manifest": "ad48e4dd52404bcb97180aa7fd49f7312bc39dce1cabf3194d0288f39658226a",
    "store_patch": "2182f12a729afc39dfa6ba4c23bb4accd557f4dcda3138ef238cb039e52de291",
    "test_patch": "43217ec36a412d68e91133ff9c2b640a47dc0ae49c1eac64abc0cb0b3bc39d7b",
}
def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
assert sha(ZIP.read_bytes()) == EXPECTED["zip"]
assert sha(MANIFEST.read_bytes()) == EXPECTED["manifest"]
assert sha((PKG/"patches/PATCH-GIT.diff").read_bytes()) == EXPECTED["store_patch"]
assert sha((PKG/"patches/TEST-MIGRATION.diff").read_bytes()) == EXPECTED["test_patch"]
m = json.loads(MANIFEST.read_text(encoding="utf-8"))
assert m["status"] == "ISOLATED_PATCH_CANDIDATE_AWAITING_INDEPENDENT_QA_NO_WRITE_LIVE_NO_GO"
assert m["write_authorized"] is False and m["capability_trust_established"] is False
rows = m["artifacts"]
assert len(rows) == 44
for row in rows:
    p = PKG / pathlib.Path(row["path"])
    b = p.read_bytes()
    assert len(b) == row["bytes"], (row["path"], len(b), row["bytes"])
    assert sha(b) == row["sha256"], row["path"]
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    names = set(z.namelist())
    expected_names = {r["path"] for r in rows} | {"R2-REV2-PACKAGE-MANIFEST.json", "R2-REV2-SHA256SUMS.txt"}
    assert names == expected_names, (sorted(names-expected_names), sorted(expected_names-names))
    assert len(names) == 46
    for row in rows:
        data = z.read(row["path"])
        assert len(data) == row["bytes"] and sha(data) == row["sha256"], row["path"]
    assert z.read("R2-REV2-PACKAGE-MANIFEST.json") == MANIFEST.read_bytes()
print(json.dumps({"manifest_artifacts":len(rows),"zip_members":len(names),"zip_testzip":None,"payload_hashes":"44/44 exact","zip_payloads":"44/44 exact","status":m["status"],"write_authorized":m["write_authorized"],"capability_trust_established":m["capability_trust_established"]}, sort_keys=True))
