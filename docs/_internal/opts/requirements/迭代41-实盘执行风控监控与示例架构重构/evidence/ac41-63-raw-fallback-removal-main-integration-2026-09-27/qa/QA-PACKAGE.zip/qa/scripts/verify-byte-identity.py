from __future__ import annotations
import base64,hashlib,json,pathlib
PKG=pathlib.Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-20260927\package-content")
BASE=PKG/"source/btapistore.base.py"; TARGET=PKG/"source/btapistore.target.py"; SPEC=json.loads((PKG/"BYTE-REPLACEMENTS.json").read_text(encoding="utf-8"))
def sha(b): return hashlib.sha256(b).hexdigest()
def bare_lf(b): return b.count(b"\n")-b.count(b"\r\n")
base=BASE.read_bytes(); target=TARGET.read_bytes()
assert sha(base)==SPEC["base_sha256"] and len(base)==SPEC["base_bytes"]
assert sha(target)==SPEC["target_sha256"] and len(target)==SPEC["target_bytes"]
repls=sorted(SPEC["replacements"],key=lambda r:r["old_offset"])
old_cursor=new_cursor=0
for row in repls:
    oo,no=row["old_offset"],row["new_offset"]
    old=base64.b64decode(row["old_base64"]); new=base64.b64decode(row["new_base64"])
    assert len(old)==row["old_length"] and len(new)==row["new_length"]
    assert sha(old)==row["old_sha256"] and sha(new)==row["new_sha256"]
    assert oo>=old_cursor and no==new_cursor+(oo-old_cursor)
    assert base[old_cursor:oo]==target[new_cursor:no], "prefix/interstitial bytes differ"
    assert base[oo:oo+len(old)]==old and target[no:no+len(new)]==new
    old_cursor=oo+len(old); new_cursor=no+len(new)
assert base[old_cursor:]==target[new_cursor:], "suffix bytes differ"
reconstructed=bytearray(base)
for row in sorted(repls,key=lambda r:r["old_offset"],reverse=True):
    oo=row["old_offset"]; old=base64.b64decode(row["old_base64"]); new=base64.b64decode(row["new_base64"])
    reconstructed[oo:oo+len(old)]=new
reconstructed=bytes(reconstructed)
assert reconstructed==target
counts={"base_crlf":base.count(b"\r\n"),"target_crlf":target.count(b"\r\n"),"base_bare_lf":bare_lf(base),"target_bare_lf":bare_lf(target)}
assert counts=={"base_crlf":SPEC["base_crlf_count"],"target_crlf":SPEC["target_crlf_count"],"base_bare_lf":SPEC["base_bare_lf_count"],"target_bare_lf":SPEC["target_bare_lf_count"]}
assert counts["base_bare_lf"]==counts["target_bare_lf"]
result={"verdict":"PASS","replacement_blocks":len(repls),"outside_replacement_bytes":"byte-identical prefix/interstitial/suffix","reconstruction_matches_target":True,"hashes":{"base":sha(base),"target":sha(target)},"bytes":{"base":len(base),"target":len(target)},"line_endings":counts,"bare_lf_delta":counts["target_bare_lf"]-counts["base_bare_lf"]}
OUT=pathlib.Path(r"D:\temp\ac41-63-writer-slice2-r2-rev2-independent-qa-20260927\byte-identity.json")
OUT.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result,sort_keys=True))
