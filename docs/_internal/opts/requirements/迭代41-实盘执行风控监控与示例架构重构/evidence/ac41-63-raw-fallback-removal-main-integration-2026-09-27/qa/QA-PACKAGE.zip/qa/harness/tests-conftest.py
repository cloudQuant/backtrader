"""Inert CTP package shim for legacy unit tests; never imports a real SDK."""
import sys
import types
from importlib import metadata
from importlib.abc import MetaPathFinder
from types import SimpleNamespace

_original_distribution = metadata.distribution

def _distribution(name):
    if name == "bt_api_ctp":
        return SimpleNamespace(name="bt_api_ctp", version="0.fake")
    return _original_distribution(name)

metadata.distribution = _distribution

class _NoRealOptionalSdk(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in sys.modules:
            return None
        if fullname.split(".", 1)[0] in {"bt_api_py", "bt_api_risk"}:
            raise ImportError("real optional SDK import blocked by isolated test harness")
        if fullname.startswith("bt_api_ctp"):
            raise ImportError("unexpected CTP module import blocked by isolated test harness")
        return None

sys.meta_path.insert(0, _NoRealOptionalSdk())

class _Field:
    pass

class _Spi:
    pass

class _Client:
    pass

root = types.ModuleType("bt_api_ctp")
root.__path__ = []
ctp = types.ModuleType("bt_api_ctp.ctp")
ctp.__path__ = []
client = types.ModuleType("bt_api_ctp.ctp.client")
client.MdClient = _Client
client.TraderClient = _Client
client._MdSpi = _Spi
client._TraderSpi = _Spi
md_api = types.ModuleType("bt_api_ctp.ctp.ctp_md_api")
md_api.CThostFtdcMdSpi = _Spi
order_structs = types.ModuleType("bt_api_ctp.ctp.ctp_structs_order")
order_structs.CThostFtdcInputOrderActionField = _Field
order_structs.CThostFtdcInputOrderField = _Field
trader_api = types.ModuleType("bt_api_ctp.ctp.ctp_trader_api")
trader_api.CThostFtdcTraderSpi = _Spi

root.ctp = ctp
ctp.client = client
ctp.ctp_md_api = md_api
ctp.ctp_structs_order = order_structs
ctp.ctp_trader_api = trader_api
sys.modules.update({
    "bt_api_ctp": root,
    "bt_api_ctp.ctp": ctp,
    "bt_api_ctp.ctp.client": client,
    "bt_api_ctp.ctp.ctp_md_api": md_api,
    "bt_api_ctp.ctp.ctp_structs_order": order_structs,
    "bt_api_ctp.ctp.ctp_trader_api": trader_api,
})

# Independent QA guard: fake test suite must never touch sockets or native loaders.
import ctypes as _ctypes
import socket as _socket

_QA_SIDE_EFFECTS = {"network_attempts": 0, "native_load_attempts": 0}
_orig_connect = _socket.socket.connect
_orig_connect_ex = _socket.socket.connect_ex
def _guard_connect(sock, address, *args, **kwargs):
    host = address[0] if isinstance(address, tuple) and address else None
    if host in {"127.0.0.1", "::1", "localhost"}:
        return _orig_connect(sock, address, *args, **kwargs)
    _QA_SIDE_EFFECTS["network_attempts"] += 1
    raise AssertionError("external network disabled in isolated QA")
def _guard_connect_ex(sock, address, *args, **kwargs):
    host = address[0] if isinstance(address, tuple) and address else None
    if host in {"127.0.0.1", "::1", "localhost"}:
        return _orig_connect_ex(sock, address, *args, **kwargs)
    _QA_SIDE_EFFECTS["network_attempts"] += 1
    raise AssertionError("external network disabled in isolated QA")
def _deny_socket(*args, **kwargs):
    _QA_SIDE_EFFECTS["network_attempts"] += 1
    raise AssertionError("network disabled in isolated QA")
def _deny_native(*args, **kwargs):
    _QA_SIDE_EFFECTS["native_load_attempts"] += 1
    raise AssertionError("native loading disabled in isolated QA")
_socket.socket.connect = _guard_connect
_socket.socket.connect_ex = _guard_connect_ex
_socket.create_connection = _deny_socket
_socket.getaddrinfo = _deny_socket
_orig_cdll = _ctypes.CDLL
_orig_windll = _ctypes.WinDLL
_CTP_DLL_TOKENS = ("bt_api", "ctp", "thost")
def _guard_cdll(name, *args, **kwargs):
    if any(token in str(name).lower() for token in _CTP_DLL_TOKENS):
        return _deny_native(name, *args, **kwargs)
    return _orig_cdll(name, *args, **kwargs)
def _guard_windll(name, *args, **kwargs):
    if any(token in str(name).lower() for token in _CTP_DLL_TOKENS):
        return _deny_native(name, *args, **kwargs)
    return _orig_windll(name, *args, **kwargs)
_ctypes.CDLL = _guard_cdll
_ctypes.WinDLL = _guard_windll



import json as _json
import os as _os
from pathlib import Path as _Path

def pytest_sessionfinish(session, exitstatus):
    fake_names = {
        "bt_api_ctp",
        "bt_api_ctp.ctp",
        "bt_api_ctp.ctp.client",
        "bt_api_ctp.ctp.ctp_md_api",
        "bt_api_ctp.ctp.ctp_structs_order",
        "bt_api_ctp.ctp.ctp_trader_api",
    }
    unexpected_sdk_modules = sorted(
        name for name in sys.modules
        if name.split(".", 1)[0] in {"bt_api_py", "bt_api_risk"}
        or (name.startswith("bt_api_ctp") and name not in fake_names)
    )
    guard = {
        "network_attempts": _QA_SIDE_EFFECTS["network_attempts"],
        "ctp_native_load_attempts": _QA_SIDE_EFFECTS["native_load_attempts"],
        "unexpected_sdk_modules": unexpected_sdk_modules,
        "fake_ctp_shim_loaded": all(name in sys.modules for name in fake_names),
        "real_sdk_import_blocker": True,
        "verdict": "PASS" if not _QA_SIDE_EFFECTS["network_attempts"] and not _QA_SIDE_EFFECTS["native_load_attempts"] and not unexpected_sdk_modules else "FAIL",
    }
    target = _os.environ.get("I41_QA_GUARD_FILE")
    if target:
        _Path(target).write_text(_json.dumps(guard, indent=2) + "\n", encoding="utf-8")
    if guard["verdict"] != "PASS":
        session.exitstatus = 3

