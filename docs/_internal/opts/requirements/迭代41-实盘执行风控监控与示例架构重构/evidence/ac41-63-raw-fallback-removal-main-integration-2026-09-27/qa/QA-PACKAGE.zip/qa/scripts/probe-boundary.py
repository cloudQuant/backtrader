from __future__ import annotations
import json, pathlib, sys
TREE=pathlib.Path(sys.argv[1]).resolve(); OUT=pathlib.Path(sys.argv[2]).resolve(); BASELINE="baseline" in TREE.name
sys.path.insert(0,str(TREE/"tests")); sys.path.insert(0,str(TREE))
import conftest
from backtrader.stores.btapistore import BtApiStoreError,_create_ctp_wrapper_class
class RawApi:
    def __init__(self): self.calls=[]
    def ReqOrderInsert(self,*args): self.calls.append(("ReqOrderInsert",args)); return 0
    def ReqOrderAction(self,*args): self.calls.append(("ReqOrderAction",args)); return 0
class Trader:
    is_ready=True
    def __init__(self,operation,mode,trap):
        self.operation,self.mode,self.trap=operation,mode,trap
        self.typed_reads,self.api_reads,self.typed_calls=0,0,[]; self._raw_api=RawApi()
    @property
    def api(self): self.api_reads+=1; return self._raw_api
    def __getattr__(self,name):
        if name not in {"submit_order_insert","submit_order_action"}: raise AttributeError(name)
        self.typed_reads+=1
        if name!=self.operation: return None
        if self.trap: raise AssertionError("typed descriptor read before capability check")
        if self.mode=="missing": return None
        if self.mode=="noncallable": return "not-callable"
        def call(*args,**kwargs): self.typed_calls.append((name,args,kwargs)); return "typed-ok"
        return call
wrapper_cls=_create_ctp_wrapper_class(); results=[]
for operation in ("submit_order_insert","submit_order_action"):
    send_name="_send_native_order_insert" if operation.endswith("insert") else "_send_native_order_action"
    for mode,has_capability,trap,expected in (("present",False,True,"reject"),("missing",True,False,"reject"),("noncallable",True,False,"reject"),("present",True,False,"typed")):
        trader=Trader(operation,mode,trap); wrapper=wrapper_cls(); wrapper.trader_client=trader
        wrapper._execution_gate_capability=object() if has_capability else None; outcome=None
        try: outcome=getattr(wrapper,send_name)(object(),17)
        except BtApiStoreError as exc: outcome="rejected:"+str(exc)
        except Exception as exc: outcome=f"exception:{type(exc).__name__}:{exc}"
        if not BASELINE:
            ok=(isinstance(outcome,str) and outcome.startswith("rejected:") and trader.api_reads==0 and trader._raw_api.calls==[] and trader.typed_calls==[]) if expected=="reject" else (outcome=="typed-ok" and trader.api_reads==0 and trader._raw_api.calls==[] and len(trader.typed_calls)==1)
            state="candidate_fail_closed" if expected=="reject" else "candidate_typed_fake_call"
        elif expected=="typed":
            ok=outcome=="typed-ok" and trader.api_reads==0 and trader._raw_api.calls==[] and len(trader.typed_calls)==1
            state="legacy_typed_fake_call"
        elif trap:
            ok=outcome.startswith("exception:AssertionError:") and trader.typed_reads==1 and trader.api_reads==0 and trader._raw_api.calls==[]
            state="legacy_reads_typed_descriptor_before_gate"
        else:
            ok=outcome==0 and trader.api_reads==1 and len(trader._raw_api.calls)==1 and trader.typed_calls==[]
            state="legacy_raw_fallback_reached"
        row={"operation":operation,"typed_mode":mode,"capability_present":has_capability,"typed_descriptor_trap":trap,"outcome":outcome,"typed_attribute_reads":trader.typed_reads,"typed_calls":len(trader.typed_calls),"api_property_accesses":trader.api_reads,"raw_native_calls":len(trader._raw_api.calls),"state":state,"pass":bool(ok)}
        results.append(row)
        if not ok: raise AssertionError(row)
guard={"network_attempts":conftest._QA_SIDE_EFFECTS["network_attempts"],"ctp_native_load_attempts":conftest._QA_SIDE_EFFECTS["native_load_attempts"],"real_sdk_modules_loaded":sorted(n for n in sys.modules if n.split(".",1)[0] in {"bt_api_py","bt_api_risk"})}
assert guard["network_attempts"]==guard["ctp_native_load_attempts"]==0,guard
assert not guard["real_sdk_modules_loaded"],guard
OUT.write_text(json.dumps({"verdict":"PASS","tree_kind":"baseline" if BASELINE else "candidate","cases":results,"guard":guard},indent=2)+"\n",encoding="utf-8")
print(json.dumps({"verdict":"PASS","tree_kind":"baseline" if BASELINE else "candidate","case_count":len(results),"candidate_zero_raw_on_rejects":not BASELINE,"baseline_legacy_gaps":sum(r["state"] in {"legacy_reads_typed_descriptor_before_gate","legacy_raw_fallback_reached"} for r in results),"network_attempts":guard["network_attempts"],"ctp_native_load_attempts":guard["ctp_native_load_attempts"],"real_sdk_modules_loaded":guard["real_sdk_modules_loaded"]},sort_keys=True))
