# ruff: noqa: E402
"""Offline source-only import primitives for the I13/I15 launcher review.

This module is deliberately not an operator entry point.  It does not read a
runtime config, inspect a marker, create a Job, contact a provider, or invoke a
candidate supervisor.  A future captured ``python -I -S -B -c`` bootstrap may
use these primitives only after an external trust descriptor has supplied the
manifest and interpreter pins.  The current I13/I15 pins are unset/zero, so
there is no production trust descriptor that can successfully seal this
checkout. This offline slice targets only the fixed CPython 3.11.5 interpreter;
it is not part of the repository's general Python 3.8+ runtime or CLI.

The finder owns the complete ``backtrader_runtime`` namespace.  It never lets
PathFinder retry an unlisted runtime name, explicitly rejects ``backtrader``
and non-stdlib imports, and compiles only the exact source bytes it hashes.
The standard-library roots passed by a caller must themselves come from an
independently pinned interpreter descriptor; merely passing ``sys.path`` is
not proof of that fact.

Only standard-library module objects captured by this bootstrap or exact source
and extension entries in the verified runtime closure are in the import
closure. New stdlib names fail closed unless the runtime seal supplies their
exact origin and kind; no general ``PathFinder`` fallback is permitted.

The Windows source lease below is integrated with this offline manifest sealer
and source loader. It opens every path component with ``OPEN_REPARSE_POINT``,
retains handles that deny write/delete sharing, and reopens paths to compare
volume/file IDs before reading. The returned seal owns the lease until explicit
close. The parent descriptor, PyYAML/SDK artifacts, fixed stdlib closure, and
actual Windows launch path still require independent pins and review.
"""

import sys


# Exact startup image for the pinned Windows CPython 3.11.5 build used by this
# offline slice.  A name allowlist (for example ``sys.stdlib_module_names``)
# alone is insufficient: an arbitrary preloaded ``sys.modules['json']`` would
# otherwise survive the helper imports below.  The external interpreter and
# stdlib still need an independently reviewed pin; this list cannot establish
# that trust root by itself.
_STARTUP_MODULE_NAMES = frozenset(
    {
        "__main__",
        "_abc",
        "_codecs",
        "_codecs_cn",
        "_frozen_importlib",
        "_frozen_importlib_external",
        "_imp",
        "_io",
        "_multibytecodec",
        "_signal",
        "_thread",
        "_warnings",
        "_weakref",
        "abc",
        "builtins",
        "codecs",
        "encodings",
        "encodings.aliases",
        "encodings.gbk",
        "encodings.utf_8",
        "io",
        "marshal",
        "nt",
        "sys",
        "time",
        "winreg",
        "zipimport",
    }
)
_BUILTIN_STARTUP_MODULES = frozenset(
    {
        "_abc",
        "_codecs",
        "_codecs_cn",
        "_imp",
        "_io",
        "_multibytecodec",
        "_signal",
        "_thread",
        "_warnings",
        "_weakref",
        "builtins",
        "marshal",
        "nt",
        "sys",
        "time",
        "winreg",
    }
)
_FROZEN_STARTUP_MODULES = frozenset(
    {"_frozen_importlib", "_frozen_importlib_external", "abc", "codecs", "io", "zipimport"}
)
_SOURCE_STARTUP_MODULES = frozenset(
    {"encodings", "encodings.aliases", "encodings.gbk", "encodings.utf_8"}
)
_MODULE_NAME_ALIASES = {
    "_collections_abc": "collections.abc",
    "_io": "io",
    "os.path": "ntpath",
}
_MODULE_SPEC_NAME_ALIASES = {
    "importlib._bootstrap": "_frozen_importlib",
    "importlib._bootstrap_external": "_frozen_importlib_external",
    "os.path": "ntpath",
}


def _startup_fail(reason):
    raise RuntimeError(reason)


def _default_filefinder_loader_details(external):
    categories = (
        (external.ExtensionFileLoader, external.EXTENSION_SUFFIXES),
        (external.SourceFileLoader, external.SOURCE_SUFFIXES),
        (external.SourcelessFileLoader, external.BYTECODE_SUFFIXES),
    )
    return tuple((suffix, loader) for loader, suffixes in categories for suffix in suffixes)


def _filefinder_is_default(finder, external, path):
    if type(finder) is not external.FileFinder or finder.path != path:
        return False
    expected = _default_filefinder_loader_details(external)
    actual = finder._loaders
    if type(actual) is not list or len(actual) != len(expected):
        return False
    if not all(
        type(item) is tuple
        and len(item) == 2
        and item[0] == expected[index][0]
        and item[1] is expected[index][1]
        for index, item in enumerate(actual)
    ):
        return False
    try:
        nt = sys.modules["nt"]
        details = nt.stat(path)
        names = nt.listdir(path)
    except (OSError, KeyError):
        return False
    cache = finder._path_cache
    if type(cache) is not set or any(type(name) is not str for name in cache):
        return False
    return finder._path_mtime == details.st_mtime and cache == set(names)


def _module_matches_startup_origin(name, module, *, external, frozen, stdlib_root):
    expected_module_name = _MODULE_NAME_ALIASES.get(name, name)
    if type(module) is not type(sys) or getattr(module, "__name__", None) != expected_module_name:
        return False
    if name == "__main__":
        return getattr(module, "__spec__", None) is None
    spec = getattr(module, "__spec__", None)
    if spec is None or getattr(spec, "name", None) != name:
        return False
    if name in _BUILTIN_STARTUP_MODULES:
        return (
            getattr(spec, "origin", None) == "built-in"
            and getattr(spec, "loader", None) is frozen.BuiltinImporter
            and getattr(module, "__loader__", None) is frozen.BuiltinImporter
        )
    if name in _FROZEN_STARTUP_MODULES:
        return (
            getattr(spec, "origin", None) == "frozen"
            and getattr(spec, "loader", None) is frozen.FrozenImporter
            and getattr(module, "__loader__", None) is frozen.FrozenImporter
        )
    if name not in _SOURCE_STARTUP_MODULES:
        return False
    relative = name.replace(".", "\\")
    source_name = "__init__.py" if name == "encodings" else relative + ".py"
    expected = (
        stdlib_root + "\\" + relative + "\\" + source_name
        if name == "encodings"
        else stdlib_root + "\\" + source_name
    )
    loader = getattr(spec, "loader", None)
    return (
        getattr(spec, "origin", None) == expected
        and getattr(module, "__file__", None) == expected
        and type(loader) is external.SourceFileLoader
        and getattr(loader, "name", None) == name
        and getattr(loader, "path", None) == expected
        and getattr(module, "__loader__", None) is loader
    )


def _check_initial_importer_cache(*, external, zipimport):
    cache = sys.path_importer_cache
    if type(cache) is not dict or len(sys.path) != 4:
        _startup_fail("bootstrap_importer_cache_invalid")
    encodings_path = sys.path[2] + "\\encodings"
    expected_keys = {sys.path[0], sys.path[1], sys.path[2], encodings_path}
    if set(cache) != expected_keys:
        _startup_fail("bootstrap_importer_cache_invalid")
    zip_path = sys.path[0]
    zip_importer = cache[zip_path]
    try:
        sys.modules["nt"].stat(zip_path)
    except OSError:
        if zip_importer is not None:
            _startup_fail("bootstrap_importer_cache_invalid")
    else:
        if (
            type(zip_importer) is not zipimport.zipimporter
            or getattr(zip_importer, "archive", None) != zip_path
            or getattr(zip_importer, "prefix", None) != ""
        ):
            _startup_fail("bootstrap_importer_cache_invalid")
    for path in expected_keys - {zip_path}:
        if not _filefinder_is_default(cache[path], external, path):
            _startup_fail("bootstrap_importer_cache_invalid")


def _check_initial_import_state():
    """Reject any process that differs from the pinned 3.11.5 startup image."""

    frozen = sys.modules.get("_frozen_importlib")
    external = sys.modules.get("_frozen_importlib_external")
    zipimport = sys.modules.get("zipimport")
    if frozen is None or external is None or zipimport is None:
        raise RuntimeError("bootstrap_import_state_invalid")

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        _startup_fail("bootstrap_runtime_baseline_invalid")
    if type(sys.modules) is not dict or frozenset(sys.modules) != _STARTUP_MODULE_NAMES:
        _startup_fail("bootstrap_preloaded_module_set_invalid")
    for name, module in sys.modules.items():
        if not _module_matches_startup_origin(
            name,
            module,
            external=external,
            frozen=frozen,
            stdlib_root=sys.path[2],
        ):
            _startup_fail("bootstrap_preloaded_module_invalid")

    expected_meta_path = [frozen.BuiltinImporter, frozen.FrozenImporter, external.PathFinder]
    if sys.meta_path != expected_meta_path:
        raise RuntimeError("bootstrap_meta_path_invalid")

    prefix = sys.pycache_prefix
    prefix_absolute = type(prefix) is str and (
        (len(prefix) >= 3 and prefix[1] == ":" and prefix[2] in "\\/") or prefix.startswith("\\\\")
    )
    if (
        not sys.flags.isolated
        or not sys.flags.no_site
        or not sys.dont_write_bytecode
        or not prefix_absolute
    ):
        raise RuntimeError("bootstrap_interpreter_flags_invalid")
    try:
        sys.modules["nt"].stat(prefix)
    except OSError:
        pass
    else:
        _startup_fail("bootstrap_pycache_prefix_not_fresh")

    hooks = sys.path_hooks
    if len(hooks) == 2:
        hook = hooks[1]
        try:
            closure = tuple(cell.cell_contents for cell in hook.__closure__ or ())
        except (AttributeError, ValueError):
            closure = ()
        expected_loader_details = (
            (external.ExtensionFileLoader, list(external.EXTENSION_SUFFIXES)),
            (external.SourceFileLoader, list(external.SOURCE_SUFFIXES)),
            (external.SourcelessFileLoader, list(external.BYTECODE_SUFFIXES)),
        )
        hook_is_default = (
            len(closure) == 2
            and external is not None
            and closure[0] is external.FileFinder
            and type(closure[1]) is tuple
            and len(closure[1]) == len(expected_loader_details)
            and all(
                actual[0] is expected[0] and actual[1] == expected[1]
                for actual, expected in zip(closure[1], expected_loader_details)
            )
        )
    else:
        hook_is_default = False
    if (
        len(hooks) != 2
        or hooks[0] is not zipimport.zipimporter
        or getattr(hooks[1], "__module__", None) != "_frozen_importlib_external"
        or getattr(hooks[1], "__qualname__", None)
        != "FileFinder.path_hook.<locals>.path_hook_for_FileFinder"
        or not hook_is_default
    ):
        raise RuntimeError("bootstrap_path_hooks_invalid")

    _check_initial_importer_cache(external=external, zipimport=zipimport)

    blocked = ("backtrader", "backtrader_runtime", "sitecustomize", "usercustomize")
    for name in tuple(sys.modules):
        if any(name == prefix or name.startswith(prefix + ".") for prefix in blocked):
            raise RuntimeError("bootstrap_preloaded_module_invalid")
        root = name.partition(".")[0]
        if (
            root != "__main__"
            and root not in sys.stdlib_module_names
            and root not in sys.builtin_module_names
        ):
            raise RuntimeError("bootstrap_preloaded_nonstdlib_module")


_check_initial_import_state()

# Preserve the validated interpreter-owned objects before importing any helper
# modules.  The snapshots let later public calls reject replacement modules or
# importer-cache objects even after this file has loaded its stdlib helpers.
_INITIAL_MODULE_OBJECTS = dict(sys.modules)
_INITIAL_IMPORTER_CACHE = dict(sys.path_importer_cache)

import hashlib
import hmac
import importlib.abc
import importlib.machinery  # noqa: F401 - preloaded for the sealed dependency helper
import importlib.util
import ast  # noqa: F401 - preloaded for the appended captured parent launcher
import base64  # noqa: F401 - used by the fixed child bootstrap payload
import csv  # noqa: F401 - preloaded for the sealed dependency helper
import ctypes
import json
import io  # noqa: F401 - preloaded for the sealed dependency helper
import ntpath  # noqa: F401 - preloaded for the appended captured parent launcher
import os
import re
import stat
import threading  # noqa: F401 - preloaded for the sealed dependency helper
import zlib  # noqa: F401 - used by the fixed child bootstrap payload
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
from types import MappingProxyType
from typing import Mapping, Optional, Sequence


_BOOTSTRAP_MODULE_OBJECTS = dict(sys.modules)
_BOOTSTRAP_IMPORTER_CACHE = dict(sys.path_importer_cache)
_BOOTSTRAP_META_PATH = tuple(sys.meta_path)
_BOOTSTRAP_PATH_HOOKS = tuple(sys.path_hooks)
_BOOTSTRAP_PATHS = tuple(sys.path)
_BOOTSTRAP_PYCACHE_PREFIX = sys.pycache_prefix


def _path_is_beneath(path: object, root: str) -> bool:
    if type(path) is not str:
        return False
    normalized_path = os.path.normcase(os.path.abspath(path))
    normalized_root = os.path.normcase(os.path.abspath(root)).rstrip("\\/")
    return normalized_path.startswith(normalized_root + os.sep)


def _path_is_root_or_beneath(path: object, root: str) -> bool:
    if type(path) is not str:
        return False
    normalized_path = os.path.normcase(os.path.abspath(path))
    normalized_root = os.path.normcase(os.path.abspath(root)).rstrip("\\/")
    return normalized_path == normalized_root or normalized_path.startswith(
        normalized_root + os.sep
    )


def _module_has_pinned_kind(name: str, module: object) -> bool:
    """Check a post-bootstrap module's kind and origin, without trusting its name."""

    expected_module_name = _MODULE_NAME_ALIASES.get(name, name)
    if type(module) is not type(sys) or getattr(module, "__name__", None) != expected_module_name:
        return False
    spec = getattr(module, "__spec__", None)
    expected_spec_name = _MODULE_SPEC_NAME_ALIASES.get(name, name)
    if spec is None or getattr(spec, "name", None) != expected_spec_name:
        return False
    frozen = sys.modules.get("_frozen_importlib")
    external = sys.modules.get("_frozen_importlib_external")
    origin = getattr(spec, "origin", None)
    loader = getattr(spec, "loader", None)
    if origin == "built-in":
        return loader is frozen.BuiltinImporter and getattr(module, "__loader__", None) is loader
    if origin == "frozen":
        return loader is frozen.FrozenImporter and getattr(module, "__loader__", None) is loader
    root = name.partition(".")[0]
    if root not in sys.stdlib_module_names and root not in sys.builtin_module_names:
        return False
    if type(loader) is external.SourceFileLoader:
        return (
            type(origin) is str
            and origin.endswith(".py")
            and _path_is_beneath(origin, sys.path[2])
            and getattr(module, "__file__", None) == origin
            and getattr(loader, "name", None) == expected_module_name
            and getattr(loader, "path", None) == origin
            and getattr(module, "__loader__", None) is loader
        )
    zipimport = sys.modules.get("zipimport")
    if zipimport is not None and type(loader) is zipimport.zipimporter:
        archive = getattr(loader, "archive", None)
        return (
            type(origin) is str
            and type(archive) is str
            and archive in _BOOTSTRAP_PATHS
            and origin.lower().endswith(".py")
            and _path_is_beneath(origin, archive)
            and getattr(module, "__file__", None) == origin
            and getattr(module, "__loader__", None) is loader
        )
    if type(loader) is external.ExtensionFileLoader:
        return (
            type(origin) is str
            and origin.lower().endswith(".pyd")
            and any(_path_is_beneath(origin, root_path) for root_path in sys.path[1:3])
            and getattr(module, "__file__", None) == origin
            and getattr(loader, "name", None) == expected_module_name
            and getattr(loader, "path", None) == origin
            and getattr(module, "__loader__", None) is loader
        )
    return False


def _is_bootstrap_typing_alias(name: str, module: object) -> bool:
    return (
        name in {"typing.io", "typing.re"}
        and _BOOTSTRAP_MODULE_OBJECTS.get(name) is module
        and isinstance(module, type)
        and type(module).__name__ == "_DeprecatedType"
        and type(module).__module__ == "typing"
        and getattr(module, "__module__", None) == "typing"
        and getattr(module, "__name__", None) == name
    )


def _check_post_bootstrap_state(seal=None, finder=None):
    """Reject object/cache swaps after helper import and before each load."""

    if type(sys.modules) is not dict or type(sys.path_importer_cache) is not dict:
        raise SealedImportError("bootstrap_import_state_invalid")
    if tuple(sys.path) != _BOOTSTRAP_PATHS:
        raise SealedImportError("sys_path_changed")
    if (
        not sys.flags.isolated
        or not sys.flags.no_site
        or not sys.dont_write_bytecode
        or type(sys.pycache_prefix) is not str
        or not os.path.isabs(sys.pycache_prefix)
        or sys.pycache_prefix != _BOOTSTRAP_PYCACHE_PREFIX
        or os.path.exists(sys.pycache_prefix)
    ):
        raise SealedImportError("bootstrap_interpreter_flags_invalid")
    for name, module in _BOOTSTRAP_MODULE_OBJECTS.items():
        if sys.modules.get(name) is not module:
            raise SealedImportError("bootstrap_module_replaced")
    dependency_modules = tuple(
        (name, module)
        for name, module in sys.modules.items()
        if name.partition(".")[0] in _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS
    )
    dependency_finder = (
        getattr(finder, "_dependency_finder", None)
        if type(finder) is SealedSourceFinder
        else None
    )
    if dependency_modules:
        validator = getattr(dependency_finder, "validate_current", None)
        if not callable(validator):
            raise SealedImportError("bootstrap_dependency_module_invalid")
        try:
            validator()
        except BaseException:
            raise SealedImportError("bootstrap_dependency_seal_invalid") from None
    runtime_stdlib_names = tuple(
        name
        for name in sys.modules
        if type(finder) is SealedSourceFinder
        and name in finder._runtime_stdlib_entries
    )
    if runtime_stdlib_names:
        runtime_seal = finder._runtime_closure
        if runtime_seal is None or runtime_seal is not finder._runtime_closure_identity:
            raise SealedImportError("bootstrap_runtime_closure_invalid")
        validator = getattr(runtime_seal, "verify_current", None)
        if not callable(validator):
            raise SealedImportError("bootstrap_runtime_closure_invalid")
        try:
            validator()
        except BaseException:
            raise SealedImportError("bootstrap_runtime_closure_invalid") from None
    for name, module in sys.modules.items():
        if name == "__main__":
            if type(module) is not type(sys):
                raise SealedImportError("bootstrap_preloaded_module_invalid")
            continue
        if name == "backtrader" or name.startswith("backtrader."):
            raise SealedImportError("unsealed_backtrader_namespace")
        if name in {"sitecustomize", "usercustomize"}:
            raise SealedImportError("site_import_blocked")
        if name == "backtrader_runtime" or name.startswith("backtrader_runtime."):
            if seal is None or finder is None:
                raise SealedImportError("bootstrap_preloaded_module_invalid")
            if (
                type(finder) is not SealedSourceFinder
                or finder._seal is not seal
                or not finder._was_executed_or_in_progress(name, module)
            ):
                raise SealedImportError("bootstrap_runtime_module_invalid")
            module_spec = getattr(module, "__spec__", None)
            loader = getattr(module_spec, "loader", None)
            expected_relatives = {
                name.replace(".", "/") + "/__init__.py",
                name.replace(".", "/") + ".py",
            }
            if (
                type(loader) is not _SealedSourceLoader
                or loader._finder is not finder
                or loader._seal is not seal
                or loader._fullname != name
                or loader._relative not in expected_relatives
                or loader._relative not in seal.files
            ):
                raise SealedImportError("bootstrap_runtime_module_invalid")
            expected_origin = str(seal.source_root.joinpath(*PurePosixPath(loader._relative).parts))
            if getattr(module_spec, "origin", None) != expected_origin:
                raise SealedImportError("bootstrap_runtime_module_invalid")
            continue
        if name.partition(".")[0] in _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS:
            owns_module = getattr(dependency_finder, "owns_module", None)
            if not callable(owns_module):
                raise SealedImportError("bootstrap_dependency_module_invalid")
            try:
                owned = owns_module(name, module)
            except BaseException:
                owned = False
            if owned is not True:
                raise SealedImportError("bootstrap_dependency_module_invalid")
            continue
        if type(finder) is SealedSourceFinder and finder._owns_runtime_stdlib_module(
            name, module
        ):
            continue
        if type(finder) is SealedSourceFinder and finder._owns_fixed_role_module(
            name, module
        ):
            continue
        if type(finder) is SealedSourceFinder and finder._owns_fixed_bootstrap_support(
            name, module
        ):
            continue
        if _is_bootstrap_typing_alias(name, module):
            continue
        if name in _BOOTSTRAP_MODULE_OBJECTS:
            if _BOOTSTRAP_MODULE_OBJECTS[name] is not module:
                raise SealedImportError("bootstrap_module_replaced")
            if any(module is initial for initial in _INITIAL_MODULE_OBJECTS.values()):
                continue
            if not _module_has_pinned_kind(name, module):
                raise SealedImportError("bootstrap_module_origin_invalid")
            continue
        raise SealedImportError("bootstrap_module_outside_snapshot")

    cache = sys.path_importer_cache
    external = sys.modules.get("_frozen_importlib_external")
    zipimport = sys.modules.get("zipimport")
    for key, original in _BOOTSTRAP_IMPORTER_CACHE.items():
        if key not in cache or cache[key] is not original:
            raise SealedImportError("importer_cache_replaced")
    for key, importer in cache.items():
        if type(key) is not str:
            raise SealedImportError("importer_cache_invalid")
        if importer is None:
            if key != _BOOTSTRAP_PATHS[0]:
                raise SealedImportError("importer_cache_invalid")
            continue
        if type(importer) is zipimport.zipimporter:
            if key != _BOOTSTRAP_PATHS[0] or getattr(importer, "archive", None) != key:
                raise SealedImportError("importer_cache_invalid")
            continue
        if not any(_path_is_root_or_beneath(key, root_path) for root_path in _BOOTSTRAP_PATHS[1:]):
            raise SealedImportError("importer_cache_outside_stdlib")
        if not _filefinder_is_default(importer, external, key):
            raise SealedImportError("importer_cache_invalid")

    if finder is None:
        if tuple(sys.meta_path) != _BOOTSTRAP_META_PATH:
            raise SealedImportError("meta_path_changed")
    elif tuple(sys.meta_path) != (finder,) + _BOOTSTRAP_META_PATH:
        raise SealedImportError("meta_path_changed")
    if tuple(sys.path_hooks) != _BOOTSTRAP_PATH_HOOKS:
        raise SealedImportError("path_hooks_changed")


_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_MAX_MANIFEST_BYTES = 1024 * 1024
_MAX_SOURCE_BYTES = 16 * 1024 * 1024
_MAX_SOURCE_FILES = 4096
_REPARSE_POINT_ATTRIBUTE = 0x400
_FILE_ATTRIBUTE_DIRECTORY = 0x10
_FILE_ATTRIBUTE_REPARSE_POINT = 0x400
_FILE_ATTRIBUTE_DEVICE = 0x40
_FILE_LIST_DIRECTORY = 0x00000001
_FILE_READ_ATTRIBUTES = 0x80
_GENERIC_READ = 0x80000000
_FILE_SHARE_READ = 0x1
_FILE_SHARE_WRITE = 0x2
_FILE_SHARE_DELETE = 0x4
_OPEN_EXISTING = 3
_FILE_FLAG_OPEN_REPARSE_POINT = 0x00200000
_FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
_FILE_ATTRIBUTE_TAG_INFO_CLASS = 9
_FILE_ID_INFO_CLASS = 18
_FILE_ID_BOTH_DIRECTORY_INFO_CLASS = 10
_FILE_ID_BOTH_DIRECTORY_RESTART_INFO_CLASS = 11
_PIN_PATHS = MappingProxyType(
    {
        "i13": "backtrader_runtime/ctp_i13_source_identity_pin.py",
        "i15": "backtrader_runtime/ctp_i15_source_identity_pin.py",
    }
)
_FIXED_READONLY_WORKER_RELATIVE_PATH = "scripts/ctp_i13_i15_readonly_preflight_worker.py"
_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
)
_FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_request_coordinator.py"
)
_FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_receipt_writer.py"
)
_FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH = (
    "scripts/ctp_i13_i15_readonly_token_bootstrap.py"
)
# Service-role sources are fixed data, executed only from this sealed bootstrap.
# They never widen the `backtrader_runtime` import namespace.
_FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS = frozenset(
    {
        _FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH,
        _FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH,
        _FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH,
    }
)
_FIXED_READONLY_ROLE_MODULES = MappingProxyType(
    {
        "request_coordinator": (
            _FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH,
            "_i13_fixed_readonly_request_coordinator",
            "ctp_i13_i15_readonly_request_coordinator_binding.v1",
            "main",
        ),
        "receipt_writer": (
            _FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH,
            "_i13_fixed_readonly_receipt_writer",
            "ctp_i13_i15_readonly_receipt_writer_binding.v1",
            "main",
        ),
    }
)
_FIXED_READONLY_TOKEN_HELPER_MODULE = (
    _FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH,
    "_i13_fixed_readonly_token_bootstrap",
    "ctp_i13_i15_readonly_token_bootstrap.v1",
)
_FIXED_BOOTSTRAP_SUPPORT_MODULES = MappingProxyType(
    {
        "scripts/ctp_i13_i15_outer_watchdog.py": "scripts.ctp_i13_i15_outer_watchdog",
        "scripts/ctp_i13_i15_worker_output_channel.py": "scripts.ctp_i13_i15_worker_output_channel",
        "scripts/ctp_i13_i15_windows_job_backend.py": "scripts.ctp_i13_i15_windows_job_backend",
    }
)
_FIXED_BOOTSTRAP_SUPPORT_PACKAGE_ORIGIN = "<fixed-i13-bootstrap-support-package>"
_FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN = object()
_FIXED_READONLY_DATA_RELATIVE_PATHS = frozenset(
    {
        _FIXED_READONLY_WORKER_RELATIVE_PATH,
        _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH,
        *_FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS,
    }
)
_FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH = (
    "backtrader_runtime/ctp_i13_worker_dependency_seal.py"
)
_SEALED_DEPENDENCY_TOP_LEVEL_ROOTS = ("yaml", "bt_api_base", "bt_api_ctp")
_MAX_LEASE_PATHS = _MAX_SOURCE_FILES + len(_PIN_PATHS) + 1


@dataclass(frozen=True)
class CandidateSpec:
    manifest_path: str
    manifest_schema: object
    entrypoint: str
    pin_key: str


CANDIDATES = MappingProxyType(
    {
        "i13_md": CandidateSpec(
            "backtrader_runtime/ctp_i13_source_manifest.json",
            1,
            "backtrader_runtime.ctp_i13_md_oneshot_supervisor",
            "i13",
        ),
        "i15_td": CandidateSpec(
            "backtrader_runtime/ctp_i15_source_manifest.json",
            "ctp_i15_source_manifest.v2",
            "backtrader_runtime.ctp_i15_td_only_readonly",
            "i15",
        ),
    }
)


class SealedImportError(ValueError):
    """A redacted fail-closed source seal or import rejection."""


class WindowsSourceLeaseError(ValueError):
    """A Windows source lease or reopened-file identity check failed."""


_PENDING_WINDOWS_SOURCE_LEASES = []


def _remember_pending_windows_lease(lease) -> None:
    if not any(pending is lease for pending in _PENDING_WINDOWS_SOURCE_LEASES):
        _PENDING_WINDOWS_SOURCE_LEASES.append(lease)


def _forget_pending_windows_lease(lease) -> None:
    _PENDING_WINDOWS_SOURCE_LEASES[:] = [
        pending for pending in _PENDING_WINDOWS_SOURCE_LEASES if pending is not lease
    ]


class _FileAttributeTagInfo(ctypes.Structure):
    _fields_ = [("FileAttributes", wintypes.DWORD), ("ReparseTag", wintypes.DWORD)]


class _FileIdInfo(ctypes.Structure):
    _fields_ = [("VolumeSerialNumber", ctypes.c_ulonglong), ("FileId", ctypes.c_ubyte * 16)]


class _FileIdBothDirectoryInfo(ctypes.Structure):
    """Fixed prefix of FILE_ID_BOTH_DIR_INFO; FileName is variable length."""

    _fields_ = [
        ("NextEntryOffset", wintypes.DWORD),
        ("FileIndex", wintypes.DWORD),
        ("CreationTime", ctypes.c_longlong),
        ("LastAccessTime", ctypes.c_longlong),
        ("LastWriteTime", ctypes.c_longlong),
        ("ChangeTime", ctypes.c_longlong),
        ("EndOfFile", ctypes.c_longlong),
        ("AllocationSize", ctypes.c_longlong),
        ("FileAttributes", wintypes.DWORD),
        ("FileNameLength", wintypes.DWORD),
        ("EaSize", wintypes.DWORD),
        ("ShortNameLength", ctypes.c_ubyte),
        ("ShortName", wintypes.WCHAR * 12),
        ("FileId", ctypes.c_longlong),
        ("FileName", wintypes.WCHAR * 1),
    ]


@dataclass(frozen=True)
class WindowsFileIdentity:
    volume_serial: int
    file_id: bytes


@dataclass(frozen=True)
class _WindowsLeaseEntry:
    path: str
    identity: WindowsFileIdentity
    is_directory: bool
    size: Optional[int]
    handle: object


class _WindowsLeaseApi:
    def __init__(self):
        if sys.platform != "win32":
            raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
        try:
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        except (AttributeError, OSError):
            raise WindowsSourceLeaseError("windows_file_id_api_unavailable") from None
        kernel32.CreateFileW.argtypes = (
            wintypes.LPCWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.HANDLE,
        )
        kernel32.CreateFileW.restype = wintypes.HANDLE
        kernel32.GetFileInformationByHandleEx.argtypes = (
            wintypes.HANDLE,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
        )
        kernel32.GetFileInformationByHandleEx.restype = wintypes.BOOL
        kernel32.GetFileSizeEx.argtypes = (wintypes.HANDLE, ctypes.POINTER(ctypes.c_longlong))
        kernel32.GetFileSizeEx.restype = wintypes.BOOL
        kernel32.ReadFile.argtypes = (
            wintypes.HANDLE,
            wintypes.LPVOID,
            wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD),
            wintypes.LPVOID,
        )
        kernel32.ReadFile.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL
        self.kernel32 = kernel32

    @staticmethod
    def _invalid_handle(handle) -> bool:
        return handle is None or handle == wintypes.HANDLE(-1).value

    def open(self, path: str, *, is_directory: bool, lease: bool, read_data: bool = False):
        access = _FILE_READ_ATTRIBUTES
        if is_directory:
            access |= _FILE_LIST_DIRECTORY
        elif read_data:
            access |= _GENERIC_READ
        share = (
            _FILE_SHARE_READ if lease else _FILE_SHARE_READ | _FILE_SHARE_WRITE | _FILE_SHARE_DELETE
        )
        flags = _FILE_FLAG_OPEN_REPARSE_POINT
        if is_directory:
            flags |= _FILE_FLAG_BACKUP_SEMANTICS
        handle = self.kernel32.CreateFileW(
            path,
            access,
            share,
            None,
            _OPEN_EXISTING,
            flags,
            None,
        )
        if self._invalid_handle(handle):
            raise WindowsSourceLeaseError("source_handle_open_failed")
        return handle

    def close(self, handle) -> None:
        if not self.kernel32.CloseHandle(handle):
            raise WindowsSourceLeaseError("source_handle_close_failed")

    def attributes(self, handle) -> int:
        details = _FileAttributeTagInfo()
        if not self.kernel32.GetFileInformationByHandleEx(
            handle,
            _FILE_ATTRIBUTE_TAG_INFO_CLASS,
            ctypes.byref(details),
            ctypes.sizeof(details),
        ):
            raise WindowsSourceLeaseError("source_attributes_unavailable")
        return details.FileAttributes

    def identity(self, handle) -> WindowsFileIdentity:
        details = _FileIdInfo()
        if not self.kernel32.GetFileInformationByHandleEx(
            handle,
            _FILE_ID_INFO_CLASS,
            ctypes.byref(details),
            ctypes.sizeof(details),
        ):
            raise WindowsSourceLeaseError("source_file_id_unavailable")
        return WindowsFileIdentity(
            volume_serial=int(details.VolumeSerialNumber),
            file_id=bytes(details.FileId),
        )

    def size(self, handle) -> int:
        value = ctypes.c_longlong()
        if not self.kernel32.GetFileSizeEx(handle, ctypes.byref(value)):
            raise WindowsSourceLeaseError("source_size_unavailable")
        if value.value < 0:
            raise WindowsSourceLeaseError("source_size_invalid")
        return int(value.value)

    def read(self, handle, size: int) -> bytes:
        result = bytearray()
        while len(result) < size:
            requested = min(64 * 1024, size - len(result))
            buffer = ctypes.create_string_buffer(requested)
            received = wintypes.DWORD()
            if not self.kernel32.ReadFile(
                handle,
                buffer,
                requested,
                ctypes.byref(received),
                None,
            ):
                raise WindowsSourceLeaseError("source_read_failed")
            if received.value == 0:
                break
            result.extend(buffer.raw[: received.value])
        return bytes(result)

    def list_directory(self, handle) -> tuple[str, ...]:
        """Enumerate names from the retained directory handle only."""

        attributes = self.attributes(handle)
        if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
            raise WindowsSourceLeaseError("source_path_reparse_point")
        if not attributes & _FILE_ATTRIBUTE_DIRECTORY:
            raise WindowsSourceLeaseError("source_directory_not_leased")
        identity_before = self.identity(handle)
        buffer_size = 64 * 1024
        buffer = ctypes.create_string_buffer(buffer_size)
        names = []
        information_class = _FILE_ID_BOTH_DIRECTORY_RESTART_INFO_CLASS
        while True:
            succeeded = self.kernel32.GetFileInformationByHandleEx(
                handle,
                information_class,
                buffer,
                buffer_size,
            )
            information_class = _FILE_ID_BOTH_DIRECTORY_INFO_CLASS
            if not succeeded:
                error = ctypes.get_last_error()
                if error == 18:  # ERROR_NO_MORE_FILES
                    break
                raise WindowsSourceLeaseError("source_directory_read_failed")

            offset = 0
            while True:
                if offset < 0 or offset + ctypes.sizeof(_FileIdBothDirectoryInfo) > buffer_size:
                    raise WindowsSourceLeaseError("source_directory_buffer_invalid")
                row = _FileIdBothDirectoryInfo.from_buffer(buffer, offset)
                name_length = int(row.FileNameLength)
                name_offset = offset + _FileIdBothDirectoryInfo.FileName.offset
                if (
                    name_length <= 0
                    or name_length % 2
                    or name_offset + name_length > buffer_size
                    or row.FileAttributes & (_FILE_ATTRIBUTE_REPARSE_POINT | _FILE_ATTRIBUTE_DEVICE)
                ):
                    raise WindowsSourceLeaseError("source_directory_entry_invalid")
                raw_name = ctypes.string_at(ctypes.addressof(buffer) + name_offset, name_length)
                try:
                    name = raw_name.decode("utf-16-le", "strict")
                except UnicodeError:
                    raise WindowsSourceLeaseError("source_directory_entry_invalid") from None
                if (
                    not name
                    or "/" in name
                    or "\\" in name
                    or ":" in name
                    or "\x00" in name
                ):
                    raise WindowsSourceLeaseError("source_directory_entry_invalid")
                if name in {".", ".."}:
                    if not row.FileAttributes & _FILE_ATTRIBUTE_DIRECTORY:
                        raise WindowsSourceLeaseError("source_directory_entry_invalid")
                else:
                    names.append(name)
                    if len(names) > 100_000:
                        raise WindowsSourceLeaseError("source_directory_entry_limit")
                next_offset = int(row.NextEntryOffset)
                if next_offset == 0:
                    break
                if (
                    next_offset % 8
                    or next_offset < _FileIdBothDirectoryInfo.FileName.offset + name_length
                    or offset + next_offset + ctypes.sizeof(_FileIdBothDirectoryInfo) > buffer_size
                ):
                    raise WindowsSourceLeaseError("source_directory_buffer_invalid")
                offset += next_offset
        if self.identity(handle) != identity_before:
            raise WindowsSourceLeaseError("source_file_identity_mismatch")
        folded = [name.casefold() for name in names]
        if len(folded) != len(set(folded)):
            raise WindowsSourceLeaseError("source_directory_case_collision")
        return tuple(names)


def _canonical_windows_absolute_path(value: object) -> str:
    try:
        raw = os.fspath(value)
    except TypeError:
        raise WindowsSourceLeaseError("source_path_invalid") from None
    if type(raw) is not str or not raw or sys.platform != "win32":
        raise WindowsSourceLeaseError("source_path_invalid")
    raw = raw.replace("/", "\\")
    if (
        len(raw) < 3
        or not raw[0].isalpha()
        or raw[1:3] != ":\\"
        or raw.startswith("\\\\")
        or any(part in {".", ".."} for part in raw[3:].split("\\") if part)
        or ":" in raw[3:]
        or any(char in raw for char in '*?"<>|')
    ):
        raise WindowsSourceLeaseError("source_path_invalid")
    for component in raw[3:].split("\\"):
        if not component:
            continue
        stem = component.split(".", 1)[0].rstrip(" .").casefold()
        if (
            component.endswith((".", " "))
            or stem in {"con", "prn", "aux", "nul"}
            or (len(stem) == 4 and stem[:3] in {"com", "lpt"} and stem[3] in "123456789")
        ):
            raise WindowsSourceLeaseError("source_path_invalid")
    normalized = os.path.normpath(os.path.abspath(raw))
    if not os.path.isabs(normalized) or len(normalized) > 32767:
        raise WindowsSourceLeaseError("source_path_invalid")
    return normalized


def _windows_path_components(path: str, *, final_is_directory: bool):
    parts = PureWindowsPath(path).parts
    if not parts or not parts[0].endswith("\\"):
        raise WindowsSourceLeaseError("source_path_invalid")
    current = PureWindowsPath(parts[0])
    yield str(current), True
    for index, part in enumerate(parts[1:]):
        current = current / part
        last = index == len(parts) - 2
        yield str(current), final_is_directory if last else True


def _lease_relative_parts(relative: object) -> tuple[str, ...]:
    if type(relative) is not str or not relative or "\\" in relative:
        raise WindowsSourceLeaseError("source_relative_path_invalid")
    path = PurePosixPath(relative)
    if (
        path.is_absolute()
        or path.as_posix() != relative
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise WindowsSourceLeaseError("source_relative_path_invalid")
    return path.parts


class WindowsSourceLease:
    """Hold path handles and read only matching file IDs and source bytes.

    ``SealedSourceTree`` retains this lease and its loader reads exact verified
    bytes through it. Every path component is opened without following its
    final reparse point; retained handles use a read-only share mask. Windows
    still permits directory attribute handles, so this is not a general path
    immutability claim. A failed close poisons the lease and preserves the
    handle for explicit retry.
    """

    def __init__(self, root: str, api: _WindowsLeaseApi):
        self.root = root
        self._api = api
        self._entries = {}
        self._handles = []
        self._closed = False
        self._poisoned = False

    @classmethod
    def acquire(cls, source_root: object, relative_paths: Sequence[str]):
        if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
            raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
        root = _canonical_windows_absolute_path(source_root)
        if type(relative_paths) not in (tuple, list) or not relative_paths:
            raise WindowsSourceLeaseError("source_lease_paths_invalid")
        if len(relative_paths) > _MAX_LEASE_PATHS:
            raise WindowsSourceLeaseError("source_lease_paths_invalid")
        relative_parts = [_lease_relative_parts(value) for value in relative_paths]
        target_keys = {
            os.path.normcase(os.path.normpath(str(PureWindowsPath(root).joinpath(*parts))))
            for parts in relative_parts
        }
        if len(target_keys) != len(relative_parts):
            raise WindowsSourceLeaseError("source_lease_paths_invalid")
        api = _WindowsLeaseApi()
        lease = cls(root, api)
        try:
            lease._retain_path(root, final_is_directory=True)
            for parts in relative_parts:
                target = str(PureWindowsPath(root).joinpath(*parts))
                lease._retain_path(target, final_is_directory=False)
            return lease
        except BaseException:
            try:
                lease.close()
            except WindowsSourceLeaseError:
                raise WindowsSourceLeaseError("source_lease_acquire_cleanup_failed") from None
            raise

    def _retain_path(self, path: str, *, final_is_directory: bool) -> None:
        for component, is_directory in _windows_path_components(
            path, final_is_directory=final_is_directory
        ):
            key = os.path.normcase(os.path.normpath(component))
            existing = self._entries.get(key)
            if existing is not None:
                if existing.is_directory != is_directory:
                    raise WindowsSourceLeaseError("source_path_kind_conflict")
                continue
            handle = self._api.open(
                component,
                is_directory=is_directory,
                lease=True,
                read_data=not is_directory,
            )
            self._handles.append(handle)
            attributes = self._api.attributes(handle)
            if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
                raise WindowsSourceLeaseError("source_path_reparse_point")
            if bool(attributes & _FILE_ATTRIBUTE_DIRECTORY) != is_directory:
                raise WindowsSourceLeaseError("source_path_kind_invalid")
            identity = self._api.identity(handle)
            size = None if is_directory else self._api.size(handle)
            entry = _WindowsLeaseEntry(component, identity, is_directory, size, handle)
            self._entries[key] = entry

    def _close_tracked_handle(self, handle) -> None:
        if not any(current == handle for current in self._handles):
            return
        try:
            self._api.close(handle)
        except Exception:
            self._poisoned = True
            _remember_pending_windows_lease(self)
            raise WindowsSourceLeaseError("source_handle_close_failed") from None
        self._handles[:] = [current for current in self._handles if current != handle]

    def _open_verified_path(
        self, path: object, expected: _WindowsLeaseEntry, *, read_data: bool = False
    ):
        if self._closed or self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        canonical = _canonical_windows_absolute_path(path)
        handle = self._api.open(
            canonical,
            is_directory=expected.is_directory,
            lease=False,
            read_data=read_data,
        )
        self._handles.append(handle)
        try:
            attributes = self._api.attributes(handle)
            if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
                raise WindowsSourceLeaseError("source_path_reparse_point")
            if bool(attributes & _FILE_ATTRIBUTE_DIRECTORY) != expected.is_directory:
                raise WindowsSourceLeaseError("source_path_kind_invalid")
            if self._api.identity(handle) != expected.identity:
                raise WindowsSourceLeaseError("source_file_identity_mismatch")
            if read_data and not expected.is_directory and self._api.size(handle) != expected.size:
                raise WindowsSourceLeaseError("source_size_changed")
            return handle
        except BaseException:
            self._close_tracked_handle(handle)
            raise

    def read_source(self, relative: str, *, expected_sha256: str) -> bytes:
        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        expected = _sha256(expected_sha256, "source_digest_invalid")
        parts = _lease_relative_parts(relative)
        target = str(PureWindowsPath(self.root).joinpath(*parts))
        components = list(_windows_path_components(target, final_is_directory=False))
        reopened_file = None
        try:
            for component, is_directory in components:
                key = os.path.normcase(os.path.normpath(component))
                entry = self._entries.get(key)
                if entry is None or entry.is_directory != is_directory:
                    raise WindowsSourceLeaseError("source_path_not_leased")
                handle = self._open_verified_path(component, entry, read_data=not is_directory)
                if is_directory:
                    self._close_tracked_handle(handle)
                else:
                    reopened_file = (handle, entry)
            if reopened_file is None:
                raise WindowsSourceLeaseError("source_file_not_leased")
            handle, entry = reopened_file
            if entry.size is None or entry.size > _MAX_SOURCE_BYTES:
                raise WindowsSourceLeaseError("source_size_invalid")
            content = self._api.read(handle, entry.size)
            if (
                len(content) != entry.size
                or self._api.identity(handle) != entry.identity
                or self._api.size(handle) != entry.size
                or not hmac.compare_digest(hashlib.sha256(content).hexdigest(), expected)
            ):
                raise WindowsSourceLeaseError("source_content_changed")
            return content
        finally:
            if reopened_file is not None:
                self._close_tracked_handle(reopened_file[0])

    def list_directory(self, relative: str) -> tuple[str, ...]:
        """List one retained directory while checking its held file identity.

        This narrow API supports exact installed-dependency inventory checks.
        The directory and its ancestors are already held by the lease with a
        share mask that denies concurrent write/delete opens. Enumeration is
        performed through that retained handle, with the file ID compared
        before and after. Reparse entries are rejected. It accepts no absolute
        or caller-selected root path.
        """

        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        parts = _lease_relative_parts(relative)
        target = str(PureWindowsPath(self.root).joinpath(*parts))
        key = os.path.normcase(os.path.normpath(target))
        expected = self._entries.get(key)
        if expected is None or not expected.is_directory:
            raise WindowsSourceLeaseError("source_directory_not_leased")

        if self._api.identity(expected.handle) != expected.identity:
            raise WindowsSourceLeaseError("source_file_identity_mismatch")
        attributes = self._api.attributes(expected.handle)
        if attributes & _FILE_ATTRIBUTE_REPARSE_POINT:
            raise WindowsSourceLeaseError("source_path_reparse_point")
        names = self._api.list_directory(expected.handle)
        if self._api.identity(expected.handle) != expected.identity:
            raise WindowsSourceLeaseError("source_file_identity_mismatch")
        folded = [name.casefold() for name in names]
        if len(folded) != len(set(folded)):
            raise WindowsSourceLeaseError("source_directory_case_collision")
        return tuple(names)

    def verify_current(self) -> None:
        """Reopen every retained file/directory and verify its identity/size."""

        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        for entry in tuple(self._entries.values()):
            handle = self._open_verified_path(
                entry.path,
                entry,
                read_data=not entry.is_directory,
            )
            self._close_tracked_handle(handle)

    def close(self) -> None:
        if self._closed:
            return
        remaining = []
        for handle in reversed(tuple(self._handles)):
            try:
                self._api.close(handle)
            except Exception:
                remaining.append(handle)
        self._handles[:] = list(reversed(remaining))
        if self._handles:
            self._poisoned = True
            _remember_pending_windows_lease(self)
            raise WindowsSourceLeaseError("source_lease_close_failed")
        self._closed = True
        self._poisoned = False
        _forget_pending_windows_lease(self)

    def __enter__(self):
        if self._closed:
            raise WindowsSourceLeaseError("source_lease_closed")
        if self._poisoned:
            raise WindowsSourceLeaseError("source_lease_poisoned")
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()


def acquire_windows_source_lease(source_root: object, relative_paths: Sequence[str]):
    """Acquire a Windows deny-write/delete lease for exact relative paths."""

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
    return WindowsSourceLease.acquire(source_root, relative_paths)


def retry_pending_windows_source_lease_cleanup() -> None:
    """Retry close for lease objects retained after a failed handle close."""

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        raise WindowsSourceLeaseError("windows_file_id_api_unavailable")
    failed = False
    for lease in tuple(_PENDING_WINDOWS_SOURCE_LEASES):
        try:
            lease.close()
        except WindowsSourceLeaseError:
            failed = True
    if failed:
        raise WindowsSourceLeaseError("source_lease_cleanup_pending")


@dataclass(frozen=True)
class SealedSourceTree:
    candidate: str
    source_root: Path
    manifest_sha256: str
    files: Mapping[str, str]
    stdlib_paths: tuple[str, ...]
    source_lease: WindowsSourceLease

    @property
    def worker_sha256(self) -> str:
        """Return the pinned digest for the one fixed read-only worker source."""

        _require_source_lease(self)
        if self.candidate != "i13_md":
            raise SealedImportError("readonly_worker_source_unpinned")
        digest = self.files.get(_FIXED_READONLY_WORKER_RELATIVE_PATH)
        if digest is None:
            raise SealedImportError("readonly_worker_source_unpinned")
        return _sha256(digest, "readonly_worker_source_unpinned")

    def read_worker_source(self) -> bytes:
        """Read only the fixed worker bytes through the retained hash-bound lease."""

        digest = self.worker_sha256
        lease = _require_source_lease(self)
        try:
            return lease.read_source(
                _FIXED_READONLY_WORKER_RELATIVE_PATH,
                expected_sha256=digest,
            )
        except WindowsSourceLeaseError as error:
            raise SealedImportError("readonly_worker_source_unavailable") from error

    @property
    def bootstrap_sha256(self) -> str:
        """Return the pinned digest for the one fixed child bootstrap artifact."""

        _require_source_lease(self)
        if self.candidate != "i13_md":
            raise SealedImportError("readonly_bootstrap_source_unpinned")
        digest = self.files.get(_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH)
        if digest is None:
            raise SealedImportError("readonly_bootstrap_source_unpinned")
        return _sha256(digest, "readonly_bootstrap_source_unpinned")

    def read_bootstrap_source(self) -> bytes:
        """Read the fixed child bootstrap through the retained hash-bound lease."""

        digest = self.bootstrap_sha256
        lease = _require_source_lease(self)
        try:
            return lease.read_source(
                _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH,
                expected_sha256=digest,
            )
        except WindowsSourceLeaseError as error:
            raise SealedImportError("readonly_bootstrap_source_unavailable") from error

    def read_request_coordinator_source(self) -> bytes:
        """Read only the fixed service coordinator bytes through the source lease."""

        return self._read_fixed_readonly_source(
            _FIXED_READONLY_REQUEST_COORDINATOR_RELATIVE_PATH,
            "readonly_request_coordinator_source_unpinned",
            "readonly_request_coordinator_source_unavailable",
        )

    def read_receipt_writer_source(self) -> bytes:
        """Read only the fixed service receipt-writer bytes through the source lease."""

        return self._read_fixed_readonly_source(
            _FIXED_READONLY_RECEIPT_WRITER_RELATIVE_PATH,
            "readonly_receipt_writer_source_unpinned",
            "readonly_receipt_writer_source_unavailable",
        )

    def read_token_bootstrap_source(self) -> bytes:
        """Read only the fixed token-bootstrap bytes through the source lease."""

        return self._read_fixed_readonly_source(
            _FIXED_READONLY_TOKEN_BOOTSTRAP_RELATIVE_PATH,
            "readonly_token_bootstrap_source_unpinned",
            "readonly_token_bootstrap_source_unavailable",
        )

    def _read_fixed_readonly_source(
        self, relative_path: str, missing_reason: str, read_reason: str
    ) -> bytes:
        _require_source_lease(self)
        if self.candidate != "i13_md" or relative_path not in _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS:
            raise SealedImportError(missing_reason)
        digest = self.files.get(relative_path)
        if digest is None:
            raise SealedImportError(missing_reason)
        try:
            return self.source_lease.read_source(relative_path, expected_sha256=digest)
        except WindowsSourceLeaseError as error:
            raise SealedImportError(read_reason) from error

    def close(self) -> None:
        self.source_lease.close()

    def __enter__(self):
        _require_source_lease(self)
        return self

    def __exit__(self, exc_type, exc, traceback):
        self.close()


def _candidate_spec(candidate: object) -> CandidateSpec:
    if type(candidate) is not str or candidate not in CANDIDATES:
        raise SealedImportError("candidate_invalid")
    return CANDIDATES[candidate]


def _require_source_lease(seal: SealedSourceTree) -> WindowsSourceLease:
    if (
        type(seal) is not SealedSourceTree
        or sys.platform != "win32"
        or sys.version_info[:3] != (3, 11, 5)
    ):
        raise SealedImportError("windows_source_lease_required")
    lease = seal.source_lease
    if (
        type(lease) is not WindowsSourceLease
        or type(lease._api) is not _WindowsLeaseApi
        or lease._closed
        or lease._poisoned
        or type(lease._handles) is not list
        or not lease._handles
        or type(lease._entries) is not dict
        or type(seal.files) is not type(MappingProxyType({}))
    ):
        raise SealedImportError("source_lease_unavailable")
    try:
        root = _canonical_windows_absolute_path(seal.source_root)
        spec = _candidate_spec(seal.candidate)
        relative_paths = (spec.manifest_path,) + tuple(seal.files)
        for relative in relative_paths:
            parts = _lease_relative_parts(relative)
            path = str(PureWindowsPath(root).joinpath(*parts))
            key = os.path.normcase(os.path.normpath(path))
            entry = lease._entries.get(key)
            if entry is None or entry.is_directory or entry.size is None:
                raise SealedImportError("source_lease_unavailable")
    except (AttributeError, TypeError, WindowsSourceLeaseError):
        raise SealedImportError("source_lease_unavailable") from None
    if lease.root != root or seal.source_root != Path(root):
        raise SealedImportError("source_lease_root_mismatch")
    return lease


def _sha256(value: object, reason: str) -> str:
    if type(value) is not str or not _SHA256_RE.fullmatch(value) or value == "0" * 64:
        raise SealedImportError(reason)
    return value


def _reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise SealedImportError("manifest_duplicate_key")
        result[key] = value
    return result


def _safe_source_path(value: object) -> str:
    if type(value) is not str or not value or "\\" in value:
        raise SealedImportError("manifest_path_invalid")
    path = PurePosixPath(value)
    if (
        path.is_absolute()
        or path.as_posix() != value
        or path.suffix != ".py"
        or len(path.parts) < 2
        or path.parts[0] != "backtrader_runtime"
        or any(part in {"", ".", ".."} for part in path.parts)
        or value in _PIN_PATHS.values()
    ):
        raise SealedImportError("manifest_path_invalid")
    return value


def _safe_i13_manifest_path(value: object) -> str:
    """Accept runtime imports plus the exact fixed worker/bootstrap data paths."""

    if value in _FIXED_READONLY_DATA_RELATIVE_PATHS:
        return value
    return _safe_source_path(value)


def parse_candidate_manifest(
    candidate: object,
    raw: bytes,
    *,
    expected_manifest_sha256: object,
) -> Mapping[str, str]:
    """Parse and pin the existing candidate-specific manifest format.

    I13 uses schema 1 with a sorted ``source_files`` mapping. I15 uses its
    versioned schema with sorted ``files`` rows. Both encodings must be strict
    canonical JSON and contain only lower-case SHA-256 values.
    """

    spec = _candidate_spec(candidate)
    expected = _sha256(expected_manifest_sha256, "manifest_pin_unset")
    if type(raw) is not bytes or not raw or len(raw) > _MAX_MANIFEST_BYTES:
        raise SealedImportError("manifest_invalid")
    actual = hashlib.sha256(raw).hexdigest()
    if not hmac.compare_digest(actual, expected):
        raise SealedImportError("manifest_digest_mismatch")
    try:
        parsed = json.loads(raw.decode("utf-8"), object_pairs_hook=_reject_duplicate_keys)
    except SealedImportError:
        raise
    except (UnicodeError, ValueError, TypeError):
        raise SealedImportError("manifest_invalid") from None

    files = {}
    if candidate == "i13_md":
        if type(parsed) is not dict or set(parsed) != {"schema", "source_files"}:
            raise SealedImportError("manifest_invalid")
        if type(parsed["schema"]) is not int or parsed["schema"] != spec.manifest_schema:
            raise SealedImportError("manifest_invalid")
        rows = parsed["source_files"]
        if type(rows) is not dict or not 1 <= len(rows) <= _MAX_SOURCE_FILES:
            raise SealedImportError("manifest_invalid")
        if list(rows) != sorted(rows):
            raise SealedImportError("manifest_order_invalid")
        for path, digest in rows.items():
            files[_safe_i13_manifest_path(path)] = _sha256(digest, "manifest_invalid")
        if (
            _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH in files
            and _FIXED_READONLY_WORKER_RELATIVE_PATH not in files
        ):
            raise SealedImportError("readonly_worker_source_unpinned")
        if (
            _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH in files
            and _FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH not in files
        ):
            raise SealedImportError("readonly_dependency_helper_unpinned")
        service_role_paths = files.keys() & _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS
        if service_role_paths and service_role_paths != _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS:
            raise SealedImportError("readonly_service_role_sources_incomplete")
        if service_role_paths and (
            _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH not in files
            or _FIXED_READONLY_WORKER_RELATIVE_PATH not in files
            or _FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH not in files
        ):
            raise SealedImportError("readonly_service_role_bootstrap_unpinned")
        canonical_value = {"schema": 1, "source_files": files}
    else:
        if type(parsed) is not dict or set(parsed) != {"files", "schema"}:
            raise SealedImportError("manifest_invalid")
        if parsed["schema"] != spec.manifest_schema:
            raise SealedImportError("manifest_invalid")
        rows = parsed["files"]
        if type(rows) is not list or not 1 <= len(rows) <= _MAX_SOURCE_FILES:
            raise SealedImportError("manifest_invalid")
        previous = None
        for row in rows:
            if type(row) is not dict or set(row) != {"path", "sha256"}:
                raise SealedImportError("manifest_invalid")
            path = _safe_source_path(row["path"])
            digest = _sha256(row["sha256"], "manifest_invalid")
            if path in files:
                raise SealedImportError("manifest_duplicate_path")
            if previous is not None and path <= previous:
                raise SealedImportError("manifest_order_invalid")
            previous = path
            files[path] = digest
        canonical_value = {
            "files": [{"path": path, "sha256": digest} for path, digest in files.items()],
            "schema": spec.manifest_schema,
        }

    if not files:
        raise SealedImportError("manifest_invalid")
    if "backtrader_runtime/__init__.py" not in files:
        raise SealedImportError("runtime_package_init_unpinned")
    if spec.entrypoint.replace(".", "/") + ".py" not in files:
        raise SealedImportError("candidate_entrypoint_unpinned")
    canonical = json.dumps(
        canonical_value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")
    if raw != canonical:
        raise SealedImportError("manifest_not_canonical")
    return MappingProxyType(files)


def _has_reparse_point(details: os.stat_result) -> bool:
    return stat.S_ISLNK(details.st_mode) or bool(
        getattr(details, "st_file_attributes", 0) & _REPARSE_POINT_ATTRIBUTE
    )


def _assert_path_components(path: Path, *, final_kind: Optional[str] = None) -> None:
    if not path.is_absolute():
        raise SealedImportError("path_not_absolute")
    anchor = Path(path.anchor)
    current = anchor
    relative = path.parts[1:] if path.anchor else path.parts
    for index, part in enumerate(relative):
        current = current / part
        try:
            details = os.lstat(current)
        except OSError:
            raise SealedImportError("path_component_unavailable") from None
        if _has_reparse_point(details):
            raise SealedImportError("path_reparse_point")
        if index < len(relative) - 1 and not stat.S_ISDIR(details.st_mode):
            raise SealedImportError("path_parent_not_directory")
    if final_kind == "directory" and not stat.S_ISDIR(os.lstat(path).st_mode):
        raise SealedImportError("path_not_directory")
    if final_kind == "file" and not stat.S_ISREG(os.lstat(path).st_mode):
        raise SealedImportError("path_not_regular_file")


def _checked_read(root: Path, relative: str) -> bytes:
    if relative in _PIN_PATHS.values():
        safe = relative
    else:
        safe = _safe_source_path(relative) if relative.endswith(".py") else relative
    if type(safe) is not str or "\\" in safe:
        raise SealedImportError("source_path_invalid")
    parts = PurePosixPath(safe).parts
    if PurePosixPath(safe).is_absolute() or any(part in {"", ".", ".."} for part in parts):
        raise SealedImportError("source_path_invalid")
    current = root
    try:
        root_stat = os.lstat(root)
    except OSError:
        raise SealedImportError("source_root_unavailable") from None
    if _has_reparse_point(root_stat) or not stat.S_ISDIR(root_stat.st_mode):
        raise SealedImportError("source_root_invalid")
    for index, component in enumerate(parts):
        current = current / component
        try:
            before = os.lstat(current)
        except OSError:
            raise SealedImportError("source_file_unavailable") from None
        if _has_reparse_point(before):
            raise SealedImportError("source_path_reparse_point")
        final = index == len(parts) - 1
        if not final:
            if not stat.S_ISDIR(before.st_mode):
                raise SealedImportError("source_parent_not_directory")
            continue
        if not stat.S_ISREG(before.st_mode):
            raise SealedImportError("source_not_regular_file")
        try:
            with open(current, "rb") as stream:
                content = stream.read(_MAX_SOURCE_BYTES + 1)
            after = os.lstat(current)
        except OSError:
            raise SealedImportError("source_file_unavailable") from None
        if (
            _has_reparse_point(after)
            or not stat.S_ISREG(after.st_mode)
            or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or len(content) != after.st_size
            or len(content) > _MAX_SOURCE_BYTES
        ):
            raise SealedImportError("source_changed_during_read")
        return content
    raise SealedImportError("source_file_unavailable")


def _pyc_source_for_relative(relative: str) -> Optional[str]:
    path = PurePosixPath(relative)
    parts = path.parts
    if "__pycache__" not in parts:
        return None
    index = parts.index("__pycache__")
    if index != len(parts) - 2 or index == 0:
        raise SealedImportError("pyc_cache_layout_invalid")
    name = parts[-1]
    match = re.fullmatch(r"(.+)\.([A-Za-z0-9_-]+)\.pyc", name)
    if match is None or match.group(2) in {"", "py"}:
        raise SealedImportError("pyc_cache_layout_invalid")
    source_parts = parts[:index] + (match.group(1) + ".py",)
    return PurePosixPath(*source_parts).as_posix()


def _scan_source_inventory(
    package_root: Path,
    manifest_path: str,
    *,
    include_readonly_worker: bool = False,
    include_readonly_bootstrap: bool = False,
    include_readonly_service_roles: bool = False,
) -> set[str]:
    python_files = set()
    pyc_sources = set()
    stack = [(package_root, "backtrader_runtime")]
    while stack:
        directory, relative_directory = stack.pop()
        directory_parts = PurePosixPath(relative_directory).parts
        if "__pycache__" in directory_parts and directory_parts[-1] != "__pycache__":
            raise SealedImportError("pyc_cache_layout_invalid")
        try:
            with os.scandir(directory) as iterator:
                entries = sorted(iterator, key=lambda entry: entry.name)
        except OSError:
            raise SealedImportError("source_directory_unavailable") from None
        for entry in entries:
            relative = relative_directory + "/" + entry.name
            try:
                details = entry.stat(follow_symlinks=False)
            except OSError:
                raise SealedImportError("source_entry_unavailable") from None
            if _has_reparse_point(details):
                raise SealedImportError("source_tree_reparse_point")
            if stat.S_ISDIR(details.st_mode):
                stack.append((Path(entry.path), relative))
                continue
            if not stat.S_ISREG(details.st_mode):
                raise SealedImportError("source_entry_not_regular")
            lowered = entry.name.casefold()
            if lowered.endswith((".pyd", ".so", ".dll", ".dylib", ".pyo")):
                raise SealedImportError("source_native_artifact_invalid")
            if lowered.endswith(".pyc"):
                source = _pyc_source_for_relative(relative)
                if source is None:
                    raise SealedImportError("pyc_cache_layout_invalid")
                pyc_sources.add(source)
                continue
            if entry.name.endswith(".py"):
                python_files.add(relative)
            elif lowered.endswith(".py"):
                raise SealedImportError("source_python_suffix_invalid")
            elif entry.name.lower().endswith(".json") and relative == manifest_path:
                continue
    if not pyc_sources.issubset(python_files):
        raise SealedImportError("pyc_cache_source_missing")
    if include_readonly_worker:
        worker_path = package_root.parent.joinpath(*_FIXED_READONLY_WORKER_RELATIVE_PATH.split("/"))
        _assert_path_components(worker_path, final_kind="file")
        python_files.add(_FIXED_READONLY_WORKER_RELATIVE_PATH)
    if include_readonly_bootstrap:
        bootstrap_path = package_root.parent.joinpath(
            *_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH.split("/")
        )
        _assert_path_components(bootstrap_path, final_kind="file")
        python_files.add(_FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH)
    if include_readonly_service_roles:
        for relative in sorted(_FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS):
            service_path = package_root.parent.joinpath(*relative.split("/"))
            _assert_path_components(service_path, final_kind="file")
            python_files.add(relative)
    return python_files


def validate_stdlib_roots(expected_stdlib_paths: Sequence[str]) -> tuple[str, ...]:
    if type(expected_stdlib_paths) not in (tuple, list) or not expected_stdlib_paths:
        raise SealedImportError("stdlib_roots_unset")
    normalized = []
    for value in expected_stdlib_paths:
        if type(value) is not str or not os.path.isabs(value):
            raise SealedImportError("stdlib_root_invalid")
        canonical = os.path.normcase(os.path.abspath(value))
        if any(piece in canonical.casefold() for piece in ("site-packages", "appdata")):
            raise SealedImportError("stdlib_root_invalid")
        if canonical in normalized:
            raise SealedImportError("stdlib_root_duplicate")
        if os.path.exists(value):
            _assert_path_components(Path(value))
        normalized.append(canonical)
    current = tuple(os.path.normcase(os.path.abspath(value)) for value in sys.path)
    if any(
        type(value) is not str
        or not value
        or os.path.normcase(os.path.abspath(value)) not in normalized
        for value in sys.path
    ):
        raise SealedImportError("sys_path_outside_stdlib_roots")
    if len(current) != len(normalized) or set(current) != set(normalized):
        raise SealedImportError("sys_path_stdlib_mismatch")
    return tuple(current)


def validate_fixed_venv_binding(
    *,
    venv_root: str,
    python_executable: str,
    python_sha256: str,
    python_version: str,
    venv_home: str,
    actual_executable: Optional[str] = None,
    actual_version: Optional[str] = None,
) -> None:
    """Validate the exact -S venv facts supplied by an external descriptor.

    This pure validation helper does not make its arguments trusted. The
    descriptor and its digest must be anchored outside the checkout.
    """

    for value in (venv_root, python_executable, venv_home):
        if type(value) is not str or not os.path.isabs(value):
            raise SealedImportError("venv_binding_invalid")
    expected_python_hash = _sha256(python_sha256, "venv_python_pin_invalid")
    if type(python_version) is not str or not re.fullmatch(r"3\.11\.5", python_version):
        raise SealedImportError("venv_version_pin_invalid")
    root = Path(venv_root)
    executable = Path(python_executable)
    home = Path(venv_home)
    if os.name == "nt":
        expected_executable = root / "Scripts" / "python.exe"
    else:
        expected_executable = root / "bin" / "python"

    def norm(value):
        return os.path.normcase(os.path.abspath(str(value)))

    if norm(executable) != norm(expected_executable):
        raise SealedImportError("venv_executable_path_mismatch")
    running_executable = actual_executable if actual_executable is not None else sys.executable
    if norm(running_executable) != norm(executable):
        raise SealedImportError("venv_running_executable_mismatch")
    running_version = (
        actual_version if actual_version is not None else ".".join(map(str, sys.version_info[:3]))
    )
    if running_version != python_version:
        raise SealedImportError("venv_running_version_mismatch")

    _assert_path_components(root, final_kind="directory")
    _assert_path_components(home, final_kind="directory")
    _assert_path_components(executable, final_kind="file")
    cfg_path = root / "pyvenv.cfg"
    _assert_path_components(cfg_path, final_kind="file")
    try:
        raw_cfg = cfg_path.read_bytes()
    except OSError:
        raise SealedImportError("venv_config_unavailable") from None
    if len(raw_cfg) > 16 * 1024:
        raise SealedImportError("venv_config_invalid")
    config = {}
    try:
        for line in raw_cfg.decode("utf-8").splitlines():
            if not line.strip():
                continue
            key, separator, value = line.partition("=")
            if not separator:
                raise SealedImportError("venv_config_invalid")
            key = key.strip().casefold()
            value = value.strip()
            if key in config:
                raise SealedImportError("venv_config_duplicate_key")
            config[key] = value
    except UnicodeError:
        raise SealedImportError("venv_config_invalid") from None
    if (
        config.get("include-system-site-packages", "").casefold() != "false"
        or norm(config.get("home", "")) != norm(home)
        or config.get("version") != python_version
    ):
        raise SealedImportError("venv_config_binding_mismatch")
    try:
        executable_bytes = executable.read_bytes()
    except OSError:
        raise SealedImportError("venv_python_unavailable") from None
    if not hmac.compare_digest(hashlib.sha256(executable_bytes).hexdigest(), expected_python_hash):
        raise SealedImportError("venv_python_digest_mismatch")


def seal_candidate_source_tree(
    candidate: object,
    source_root: str | Path,
    *,
    expected_manifest_sha256: object,
    expected_pin_sha256s: Mapping[str, str],
    stdlib_paths: Sequence[str],
) -> SealedSourceTree:
    """Seal source bytes with retained Windows file-ID handles and hashes.

    The external manifest digest is checked before acquiring the lease. The
    manifest and every listed/pinned source are then reopened through the lease
    and revalidated before the returned tree can be installed or imported.
    The caller owns the returned lease and must close the tree explicitly.
    """

    if sys.platform != "win32" or sys.version_info[:3] != (3, 11, 5):
        raise SealedImportError("windows_source_lease_required")
    spec = _candidate_spec(candidate)
    try:
        root = Path(_canonical_windows_absolute_path(source_root))
    except WindowsSourceLeaseError:
        raise SealedImportError("source_root_invalid") from None
    _assert_path_components(root, final_kind="directory")
    package_root = root / "backtrader_runtime"
    _assert_path_components(package_root, final_kind="directory")
    if type(expected_pin_sha256s) is not dict or set(expected_pin_sha256s) != set(_PIN_PATHS):
        raise SealedImportError("pin_source_descriptor_invalid")
    pins = {
        path: _sha256(expected_pin_sha256s[key], "pin_source_descriptor_invalid")
        for key, path in _PIN_PATHS.items()
    }
    expected_digest = _sha256(expected_manifest_sha256, "manifest_pin_unset")

    # This first read is only used to learn the exact candidate file list. Its
    # bytes must already match the external manifest pin, and the leased reread
    # below repeats that pin before any tree is returned.
    initial_manifest = _checked_read(root, spec.manifest_path)
    if not hmac.compare_digest(hashlib.sha256(initial_manifest).hexdigest(), expected_digest):
        raise SealedImportError("manifest_digest_mismatch")
    manifest_files = parse_candidate_manifest(
        candidate, initial_manifest, expected_manifest_sha256=expected_digest
    )
    all_files = dict(manifest_files)
    all_files.update(pins)
    if spec.entrypoint.replace(".", "/") + ".py" not in all_files:
        raise SealedImportError("candidate_entrypoint_unpinned")
    checked_stdlib_paths = validate_stdlib_roots(stdlib_paths)

    lease_paths = (spec.manifest_path,) + tuple(sorted(all_files))
    lease = acquire_windows_source_lease(root, lease_paths)
    try:
        leased_manifest = lease.read_source(spec.manifest_path, expected_sha256=expected_digest)
        if not hmac.compare_digest(leased_manifest, initial_manifest):
            raise SealedImportError("manifest_changed_before_lease")
        verified_manifest_files = parse_candidate_manifest(
            candidate, leased_manifest, expected_manifest_sha256=expected_digest
        )
        verified_files = dict(verified_manifest_files)
        verified_files.update(pins)
        if verified_files != all_files:
            raise SealedImportError("manifest_changed_before_lease")

        if _scan_source_inventory(
            package_root,
            spec.manifest_path,
            include_readonly_worker=(_FIXED_READONLY_WORKER_RELATIVE_PATH in all_files),
            include_readonly_bootstrap=(
                _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH in all_files
            ),
            include_readonly_service_roles=bool(
                all_files.keys() & _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS
            ),
        ) != set(all_files):
            raise SealedImportError("source_inventory_mismatch")
        for relative, expected in all_files.items():
            lease.read_source(relative, expected_sha256=expected)

        return SealedSourceTree(
            candidate=candidate,
            source_root=Path(lease.root),
            manifest_sha256=expected_digest,
            files=MappingProxyType(all_files),
            stdlib_paths=checked_stdlib_paths,
            source_lease=lease,
        )
    except BaseException:
        try:
            lease.close()
        except WindowsSourceLeaseError:
            raise SealedImportError("source_lease_cleanup_failed") from None
        raise


class _SealedSourceLoader(importlib.abc.Loader):
    def __init__(
        self,
        seal: SealedSourceTree,
        finder: "SealedSourceFinder",
        fullname: str,
        relative: str,
        is_package: bool,
    ):
        self._seal = seal
        self._finder = finder
        self._fullname = fullname
        self._relative = relative
        self._is_package = is_package

    def create_module(self, spec):
        return None

    def is_package(self, fullname):
        return self._is_package

    def exec_module(self, module):
        self._finder._begin_module_execution(self, module)
        try:
            self._check_active()
            expected = self._seal.files.get(self._relative)
            if expected is None:
                raise SealedImportError("module_not_allowlisted")
            source = self._seal.source_lease.read_source(self._relative, expected_sha256=expected)
            if not hmac.compare_digest(hashlib.sha256(source).hexdigest(), expected):
                raise SealedImportError("source_digest_mismatch")
            origin = self._seal.source_root.joinpath(*PurePosixPath(self._relative).parts)
            code = compile(source, str(origin), "exec", dont_inherit=True)
            module.__file__ = str(origin)
            module.__cached__ = None
            if self._is_package:
                module.__path__ = [str(origin.parent)]
            exec(code, module.__dict__)
            self._finder._complete_module_execution(self, module)
        except BaseException:
            self._finder._abort_module_execution(self, module)
            raise

    def _check_active(self):
        _require_clean_after_install(self._seal, finder=self._finder)


class _SealedRuntimeStdlibLoader(importlib.abc.Loader):
    """Load one manifest-bound stdlib member through its runtime seal."""

    def __init__(self, runtime_seal, finder, entry):
        self._runtime_seal = runtime_seal
        self._finder = finder
        self._entry = entry
        self._fullname = entry.fullname
        self._spec = None
        self._extension_loader = (
            importlib.machinery.ExtensionFileLoader(self._fullname, entry.origin)
            if entry.kind == "extension"
            else None
        )

    def is_package(self, fullname):
        if fullname != self._fullname:
            raise ImportError("runtime_stdlib_name_mismatch")
        return self._entry.is_package

    def create_module(self, spec):
        if (
            spec is not self._spec
            or getattr(spec, "loader", None) is not self
            or getattr(spec, "origin", None) != self._entry.origin
            or self._runtime_seal is not self._finder._runtime_closure_identity
        ):
            raise ImportError("runtime_stdlib_spec_invalid")
        if self._entry.kind == "source":
            return None
        verified = self._runtime_seal.verify_stdlib_entry(self._fullname)
        if verified is not self._entry:
            raise ImportError("runtime_stdlib_entry_changed")
        return self._extension_loader.create_module(spec)

    def exec_module(self, module):
        self._finder._begin_runtime_stdlib_execution(self, module)
        try:
            _require_clean_after_install(self._finder._seal, finder=self._finder)
            verified = self._runtime_seal.verify_stdlib_entry(self._fullname)
            if verified is not self._entry:
                raise ImportError("runtime_stdlib_entry_changed")
            if self._entry.kind == "source":
                source = self._runtime_seal.read_stdlib_source(self._fullname)
                if (
                    type(source) is not bytes
                    or len(source) != self._entry.size
                    or not hmac.compare_digest(
                        hashlib.sha256(source).hexdigest(), self._entry.sha256
                    )
                ):
                    raise ImportError("runtime_stdlib_source_digest_mismatch")
                code = compile(source, self._entry.origin, "exec", dont_inherit=True)
                module.__file__ = self._entry.origin
                module.__cached__ = None
                if self._entry.is_package:
                    module.__path__ = [ntpath.dirname(self._entry.origin)]
                exec(code, module.__dict__)
            else:
                if self._extension_loader is None or self._entry.is_package:
                    raise ImportError("runtime_stdlib_extension_invalid")
                self._extension_loader.exec_module(module)
            self._finder._complete_runtime_stdlib_execution(self, module)
        except BaseException:
            self._finder._abort_runtime_stdlib_execution(self, module)
            raise


class SealedSourceFinder(importlib.abc.MetaPathFinder):
    """Own runtime imports and reject stdlib names outside the captured cache."""

    def __init__(self, seal: SealedSourceTree):
        self._seal = seal
        self._base_meta_path = tuple(sys.meta_path)
        self._base_path_hooks = tuple(sys.path_hooks)
        self._in_progress_modules = {}
        self._executed_modules = {}
        self._dependency_finder = None
        self._runtime_closure = None
        self._runtime_closure_identity = None
        self._runtime_stdlib_entries = {}
        self._runtime_stdlib_specs = {}
        self._runtime_stdlib_in_progress = {}
        self._runtime_stdlib_modules = {}
        self._fixed_role_modules = {}
        self._fixed_bootstrap_support_package = None
        self._fixed_bootstrap_support_modules = {}

    def attach_dependency_finder(self, dependency_finder) -> None:
        """Attach one fixed-root dependency finder without changing meta_path."""

        roots = getattr(dependency_finder, "top_level_roots", None)
        if (
            self._dependency_finder is not None
            or dependency_finder is None
            or type(roots) is not tuple
            or roots != _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS
            or not callable(getattr(dependency_finder, "find_spec", None))
            or not callable(getattr(dependency_finder, "owns_module", None))
            or not callable(getattr(dependency_finder, "validate_current", None))
            or not sys.meta_path
            or sys.meta_path[0] is not self
        ):
            raise SealedImportError("dependency_finder_invalid")
        _require_clean_after_install(self._seal, finder=self)
        self._dependency_finder = dependency_finder

    def detach_dependency_finder(self, dependency_finder) -> None:
        """Detach only the exact dependency finder previously attached."""

        if self._dependency_finder is not dependency_finder:
            raise SealedImportError("dependency_finder_identity_mismatch")
        self._dependency_finder = None

    def attach_runtime_closure(self, runtime_seal) -> None:
        """Attach one exact runtime seal for late stdlib imports."""

        entries = getattr(runtime_seal, "stdlib_modules", None)
        methods = (
            "stdlib_entry",
            "read_stdlib_source",
            "verify_stdlib_entry",
            "verify_current",
        )
        if (
            self._runtime_closure is not None
            or runtime_seal is None
            or type(entries) is not tuple
            or not all(callable(getattr(runtime_seal, name, None)) for name in methods)
            or not sys.meta_path
            or sys.meta_path[0] is not self
        ):
            raise SealedImportError("runtime_closure_invalid")
        _require_clean_after_install(self._seal, finder=self)
        validator = runtime_seal.verify_current
        try:
            validator()
        except BaseException:
            raise SealedImportError("runtime_closure_invalid") from None

        entries_by_name = {}
        for entry in entries:
            fullname = getattr(entry, "fullname", None)
            origin = getattr(entry, "origin", None)
            kind = getattr(entry, "kind", None)
            is_package = getattr(entry, "is_package", None)
            digest = getattr(entry, "sha256", None)
            size = getattr(entry, "size", None)
            relative_path = getattr(entry, "relative_path", None)
            root_kind = getattr(entry, "root_kind", None)
            parts = fullname.split(".") if type(fullname) is str else ()
            if (
                not parts
                or any(not part.isidentifier() for part in parts)
                or parts[0] not in sys.stdlib_module_names
                or fullname in sys.builtin_module_names
                or type(origin) is not str
                or not os.path.isabs(origin)
                or not any(_path_is_root_or_beneath(origin, root) for root in self._seal.stdlib_paths)
                or kind not in {"source", "extension"}
                or type(is_package) is not bool
                or type(digest) is not str
                or len(digest) != 64
                or any(char not in "0123456789abcdef" for char in digest)
                or type(size) is not int
                or size <= 0
                or type(relative_path) is not str
                or not relative_path
                or "\\" in relative_path
                or PurePosixPath(relative_path).is_absolute()
                or any(part in {"", ".", ".."} for part in PurePosixPath(relative_path).parts)
                or root_kind not in {"base", "venv"}
                or (kind == "source" and not origin.lower().endswith(".py"))
                or (kind == "extension" and (is_package or not origin.lower().endswith(".pyd")))
                or fullname in entries_by_name
            ):
                raise SealedImportError("runtime_stdlib_entry_invalid")
            try:
                if runtime_seal.stdlib_entry(fullname) is not entry:
                    raise SealedImportError("runtime_stdlib_entry_identity_mismatch")
                verified = runtime_seal.verify_stdlib_entry(fullname)
            except SealedImportError:
                raise
            except BaseException:
                raise SealedImportError("runtime_stdlib_entry_invalid") from None
            if verified is not entry:
                raise SealedImportError("runtime_stdlib_entry_identity_mismatch")
            entries_by_name[fullname] = entry

        # Hash-check source/extension files that were already imported by the
        # fixed bootstrap before the source finder was installed.
        for name, module in _BOOTSTRAP_MODULE_OBJECTS.items():
            if type(module) is not type(sys):
                continue
            module_spec = getattr(module, "__spec__", None)
            origin = getattr(module_spec, "origin", None)
            if type(origin) is not str or origin in {"built-in", "frozen"}:
                continue
            if not any(_path_is_root_or_beneath(origin, root) for root in self._seal.stdlib_paths):
                continue
            fullname = _MODULE_NAME_ALIASES.get(name, name)
            entry = entries_by_name.get(fullname)
            loader = getattr(module_spec, "loader", None)
            external = sys.modules.get("_frozen_importlib_external")
            expected_kind = (
                "source"
                if type(loader) is external.SourceFileLoader
                or type(loader) is sys.modules["zipimport"].zipimporter
                else "extension"
                if type(loader) is external.ExtensionFileLoader
                else None
            )
            if (
                entry is None
                or expected_kind != entry.kind
                or os.path.normcase(os.path.normpath(origin))
                != os.path.normcase(os.path.normpath(entry.origin))
            ):
                raise SealedImportError("runtime_bootstrap_stdlib_unpinned")
        self._runtime_stdlib_entries = entries_by_name
        self._runtime_closure = runtime_seal
        self._runtime_closure_identity = runtime_seal

    def detach_runtime_closure(self, runtime_seal) -> None:
        """Detach only the exact closure attached by this finder."""

        if self._runtime_closure is not runtime_seal:
            raise SealedImportError("runtime_closure_identity_mismatch")
        self._runtime_closure = None
        self._runtime_closure_identity = None

    def _begin_fixed_role_module(self, relative_path: str, module) -> None:
        """Temporarily register one verified data-only role during execution."""

        matches = [
            (name, spec)
            for name, spec in _FIXED_READONLY_ROLE_MODULES.items()
            if spec[0] == relative_path
        ]
        if relative_path == _FIXED_READONLY_TOKEN_HELPER_MODULE[0]:
            matches.append(("token_bootstrap", _FIXED_READONLY_TOKEN_HELPER_MODULE))
        if len(matches) != 1 or type(module) is not type(sys):
            raise SealedImportError("readonly_role_module_invalid")
        name, spec = matches[0]
        if name in self._fixed_role_modules or name in sys.modules:
            raise SealedImportError("readonly_role_module_already_active")
        module_spec = getattr(module, "__spec__", None)
        expected_origin = str(
            self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts)
        )
        digest = self._seal.files.get(relative_path)
        if (
            type(digest) is not str
            or module.__name__ != spec[1]
            or module_spec is None
            or module_spec.name != spec[1]
            or module_spec.loader is not None
            or module_spec.origin != expected_origin
            or module.__file__ != expected_origin
            or module.__loader__ is not None
        ):
            raise SealedImportError("readonly_role_module_invalid")
        self._fixed_role_modules[name] = (module, module_spec, relative_path, digest)

    def _owns_fixed_role_module(self, fullname, module) -> bool:
        for _role, record in self._fixed_role_modules.items():
            expected_module, expected_spec, relative_path, digest = record
            if fullname != expected_module.__name__ or module is not expected_module:
                continue
            expected_origin = str(
                self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts)
            )
            return (
                sys.modules.get(fullname) is module
                and getattr(module, "__spec__", None) is expected_spec
                and getattr(module, "__file__", None) == expected_origin
                and expected_spec.origin == expected_origin
                and self._seal.files.get(relative_path) == digest
            )
        return False

    def _begin_fixed_bootstrap_support_package(self, package, *, capability) -> None:
        """Register the one pathless package used by embedded support sources."""

        if (
            capability is not _FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN
            or type(self) is not SealedSourceFinder
            or self._seal.candidate != "i13_md"
            or self._fixed_bootstrap_support_package is not None
            or type(package) is not type(sys)
            or package.__name__ != "scripts"
            or "scripts" in sys.modules
            or any(name.startswith("scripts.") for name in sys.modules)
            or not sys.meta_path
            or sys.meta_path[0] is not self
        ):
            raise SealedImportError("bootstrap_support_package_invalid")
        _require_clean_after_install(self._seal, finder=self)
        package.__package__ = "scripts"
        package.__path__ = []
        package.__loader__ = None
        package.__file__ = None
        spec = importlib.machinery.ModuleSpec("scripts", None, is_package=True)
        spec.origin = _FIXED_BOOTSTRAP_SUPPORT_PACKAGE_ORIGIN
        spec.submodule_search_locations = []
        package.__spec__ = spec
        self._fixed_bootstrap_support_package = (package, spec)
        sys.modules["scripts"] = package

    def _load_fixed_bootstrap_support_module(
        self,
        relative_path: str,
        source: bytes,
        *,
        expected_sha256: str,
        capability,
    ):
        """Compile one exact embedded support module under the sealed scripts package."""

        fullname = _FIXED_BOOTSTRAP_SUPPORT_MODULES.get(relative_path)
        package_record = self._fixed_bootstrap_support_package
        if (
            capability is not _FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN
            or type(self) is not SealedSourceFinder
            or self._seal.candidate != "i13_md"
            or fullname is None
            or package_record is None
            or sys.modules.get("scripts") is not package_record[0]
            or getattr(package_record[0], "__spec__", None) is not package_record[1]
            or not sys.meta_path
            or sys.meta_path[0] is not self
            or fullname in sys.modules
            or fullname in self._fixed_bootstrap_support_modules
            or type(source) is not bytes
            or not source
            or type(expected_sha256) is not str
            or _SHA256_RE.fullmatch(expected_sha256) is None
        ):
            raise SealedImportError("bootstrap_support_module_binding_invalid")
        actual_sha256 = hashlib.sha256(source).hexdigest()
        if not hmac.compare_digest(actual_sha256, expected_sha256):
            raise SealedImportError("bootstrap_support_module_digest_mismatch")
        _require_clean_after_install(self._seal, finder=self)
        origin = str(self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts))
        try:
            code = compile(source, origin, "exec", dont_inherit=True)
        except (SyntaxError, UnicodeError, ValueError):
            raise SealedImportError("bootstrap_support_module_invalid") from None
        module = type(sys)(fullname)
        spec = importlib.machinery.ModuleSpec(fullname, None, origin=origin)
        spec.cached = None
        module.__file__ = origin
        module.__cached__ = None
        module.__package__ = "scripts"
        module.__loader__ = None
        module.__spec__ = spec
        module.__embedded_source_sha256__ = actual_sha256
        self._fixed_bootstrap_support_modules[fullname] = (
            module,
            spec,
            relative_path,
            actual_sha256,
            False,
        )
        sys.modules[fullname] = module
        try:
            exec(code, module.__dict__)
            if sys.modules.get(fullname) is not module or module.__spec__ is not spec:
                raise SealedImportError("bootstrap_support_module_identity_mismatch")
            self._fixed_bootstrap_support_modules[fullname] = (
                module,
                spec,
                relative_path,
                actual_sha256,
                True,
            )
            _require_clean_after_install(self._seal, finder=self)
            return module
        except BaseException:
            if sys.modules.get(fullname) is module:
                del sys.modules[fullname]
            self._fixed_bootstrap_support_modules.pop(fullname, None)
            raise

    def _owns_fixed_bootstrap_support(self, fullname, module) -> bool:
        package_record = self._fixed_bootstrap_support_package
        if fullname == "scripts":
            if package_record is None or package_record[0] is not module:
                return False
            package, spec = package_record
            return (
                sys.modules.get("scripts") is package
                and type(package) is type(sys)
                and package.__name__ == "scripts"
                and package.__package__ == "scripts"
                and package.__path__ == []
                and package.__loader__ is None
                and package.__file__ is None
                and package.__spec__ is spec
                and spec.name == "scripts"
                and spec.loader is None
                and spec.origin == _FIXED_BOOTSTRAP_SUPPORT_PACKAGE_ORIGIN
                and spec.submodule_search_locations == []
            )
        record = self._fixed_bootstrap_support_modules.get(fullname)
        if record is None or record[0] is not module:
            return False
        expected_module, expected_spec, relative_path, digest, _complete = record
        expected_origin = str(
            self._seal.source_root.joinpath(*PurePosixPath(relative_path).parts)
        )
        return (
            fullname == _FIXED_BOOTSTRAP_SUPPORT_MODULES.get(relative_path)
            and sys.modules.get(fullname) is expected_module
            and type(module) is type(sys)
            and module.__name__ == fullname
            and module.__package__ == "scripts"
            and module.__file__ == expected_origin
            and module.__cached__ is None
            and module.__loader__ is None
            and module.__spec__ is expected_spec
            and expected_spec.name == fullname
            and expected_spec.loader is None
            and expected_spec.origin == expected_origin
            and expected_spec.cached is None
            and self._fixed_bootstrap_support_package is not None
            and sys.modules.get("scripts") is self._fixed_bootstrap_support_package[0]
            and module.__embedded_source_sha256__ == digest
            and bool(digest)
        )

    def _end_fixed_role_module(self, role: str, module) -> None:
        record = self._fixed_role_modules.get(role)
        if record is None or record[0] is not module:
            raise SealedImportError("readonly_role_module_identity_mismatch")
        fullname = record[1].name
        current = sys.modules.get(fullname)
        if current is not module:
            if fullname in sys.modules:
                del sys.modules[fullname]
            del self._fixed_role_modules[role]
            raise SealedImportError("readonly_role_module_identity_mismatch")
        del sys.modules[fullname]
        del self._fixed_role_modules[role]
        if module.__name__ != fullname or getattr(module, "__spec__", None) is not record[1]:
            raise SealedImportError("readonly_role_module_identity_mismatch")

    def _owns_runtime_stdlib_module(self, fullname, module) -> bool:
        entry = self._runtime_stdlib_entries.get(fullname)
        if entry is None:
            return False
        loader = self._runtime_stdlib_specs.get(fullname)
        in_progress = self._runtime_stdlib_in_progress.get(fullname) is module
        if loader is None:
            return False
        if not in_progress and self._runtime_stdlib_modules.get(fullname) is not module:
            return False
        spec = getattr(module, "__spec__", None)
        if (
            type(module) is not type(sys)
            or sys.modules.get(fullname) is not module
            or getattr(module, "__name__", None) != fullname
            or spec is not loader._spec
            or getattr(spec, "loader", None) is not loader
            or getattr(spec, "origin", None) != entry.origin
            or getattr(spec, "cached", None) is not None
            or getattr(module, "__loader__", None) is not loader
            or getattr(module, "__cached__", None) is not None
        ):
            return False
        module_file = getattr(module, "__file__", None)
        if module_file != entry.origin and not (in_progress and module_file is None):
            return False
        if entry.is_package:
            module_path = getattr(module, "__path__", None)
            if type(module_path) is not list or module_path != [ntpath.dirname(entry.origin)]:
                return False
        elif hasattr(module, "__path__"):
            return False
        return True

    def _begin_runtime_stdlib_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            self._runtime_closure is not loader._runtime_seal
            or self._runtime_closure_identity is not loader._runtime_seal
            or self._runtime_stdlib_specs.get(fullname) is not loader
            or sys.modules.get(fullname) is not module
            or fullname in self._runtime_stdlib_in_progress
            or not self._owns_runtime_stdlib_module_for_execution(loader, module)
        ):
            raise SealedImportError("runtime_stdlib_execution_state_invalid")
        self._runtime_stdlib_in_progress[fullname] = module

    def _owns_runtime_stdlib_module_for_execution(self, loader, module) -> bool:
        entry = self._runtime_stdlib_entries.get(loader._fullname)
        spec = getattr(module, "__spec__", None)
        return (
            entry is loader._entry
            and self._runtime_stdlib_specs.get(loader._fullname) is loader
            and type(module) is type(sys)
            and sys.modules.get(loader._fullname) is module
            and getattr(module, "__name__", None) == loader._fullname
            and spec is loader._spec
            and getattr(spec, "loader", None) is loader
            and getattr(spec, "origin", None) == entry.origin
            and getattr(spec, "cached", None) is None
            and getattr(module, "__loader__", None) is loader
            and (getattr(module, "__file__", None) in {None, entry.origin})
        )

    def _complete_runtime_stdlib_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            self._runtime_stdlib_in_progress.get(fullname) is not module
            or not self._owns_runtime_stdlib_module(loader._fullname, module)
        ):
            raise SealedImportError("runtime_stdlib_execution_state_invalid")
        del self._runtime_stdlib_in_progress[fullname]
        self._runtime_stdlib_modules[fullname] = module

    def _abort_runtime_stdlib_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if self._runtime_stdlib_in_progress.get(fullname) is module:
            del self._runtime_stdlib_in_progress[fullname]

    def _loader_matches_module(self, loader, module, *, require_file: bool) -> bool:
        fullname = loader._fullname
        expected_relative = (
            fullname.replace(".", "/") + "/__init__.py"
            if loader._is_package
            else fullname.replace(".", "/") + ".py"
        )
        expected_origin = str(
            self._seal.source_root.joinpath(*PurePosixPath(expected_relative).parts)
        )
        module_spec = getattr(module, "__spec__", None)
        return (
            type(module) is type(sys)
            and getattr(module, "__name__", None) == fullname
            and getattr(module_spec, "name", None) == fullname
            and getattr(module_spec, "loader", None) is loader
            and getattr(module_spec, "origin", None) == expected_origin
            and getattr(module_spec, "cached", None) is None
            and getattr(module, "__loader__", None) is loader
            and (
                getattr(module, "__file__", None) == expected_origin
                if require_file
                else getattr(module, "__file__", None) in {None, expected_origin}
            )
            and loader._finder is self
            and loader._seal is self._seal
            and loader._relative == expected_relative
            and expected_relative in self._seal.files
        )

    def _was_executed_or_in_progress(self, fullname: str, module: object) -> bool:
        return (
            type(self._in_progress_modules) is dict
            and type(self._executed_modules) is dict
            and (
                self._in_progress_modules.get(fullname) is module
                or self._executed_modules.get(fullname) is module
            )
        )

    def _begin_module_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            type(self._in_progress_modules) is not dict
            or type(self._executed_modules) is not dict
            or sys.modules.get(fullname) is not module
            or not self._loader_matches_module(loader, module, require_file=False)
            or fullname in self._in_progress_modules
        ):
            raise SealedImportError("sealed_module_execution_state_invalid")
        previous = self._executed_modules.get(fullname)
        if previous is not None and previous is not module:
            raise SealedImportError("sealed_module_execution_state_invalid")
        self._executed_modules.pop(fullname, None)
        self._in_progress_modules[fullname] = module

    def _complete_module_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if (
            self._in_progress_modules.get(fullname) is not module
            or sys.modules.get(fullname) is not module
            or not self._loader_matches_module(loader, module, require_file=True)
        ):
            raise SealedImportError("sealed_module_execution_state_invalid")
        del self._in_progress_modules[fullname]
        self._executed_modules[fullname] = module

    def _abort_module_execution(self, loader, module) -> None:
        fullname = loader._fullname
        if self._in_progress_modules.get(fullname) is module:
            del self._in_progress_modules[fullname]

    def find_spec(self, fullname, path=None, target=None):
        _require_clean_after_install(self._seal, finder=self)
        if fullname == "backtrader" or fullname.startswith("backtrader."):
            raise ModuleNotFoundError("unsealed_backtrader_namespace")
        if fullname == "site" or fullname in {"sitecustomize", "usercustomize"}:
            raise ModuleNotFoundError("site_import_blocked")
        if fullname == "backtrader_runtime" or fullname.startswith("backtrader_runtime."):
            if any(not part.isidentifier() for part in fullname.split(".")):
                raise ModuleNotFoundError("runtime_module_name_invalid")
            if fullname.endswith(".__init__"):
                raise ModuleNotFoundError("runtime_module_name_invalid")
            relative_base = fullname.replace(".", "/")
            package_relative = relative_base + "/__init__.py"
            module_relative = relative_base + ".py"
            if package_relative in self._seal.files:
                relative, is_package = package_relative, True
            elif module_relative in self._seal.files:
                relative, is_package = module_relative, False
            else:
                raise ModuleNotFoundError("runtime_module_not_allowlisted")
            loader = _SealedSourceLoader(self._seal, self, fullname, relative, is_package)
            spec = importlib.util.spec_from_loader(
                fullname,
                loader,
                origin=str(self._seal.source_root.joinpath(*PurePosixPath(relative).parts)),
                is_package=is_package,
            )
            if spec is None:
                raise SealedImportError("sealed_module_spec_unavailable")
            spec.cached = None
            if is_package:
                spec.submodule_search_locations = [
                    str(self._seal.source_root.joinpath(*PurePosixPath(relative).parts[:-1]))
                ]
            return spec

        root = fullname.partition(".")[0]
        if root in _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS:
            dependency_finder = self._dependency_finder
            if dependency_finder is None:
                raise ModuleNotFoundError("sealed_dependency_finder_unavailable")
            validator = getattr(dependency_finder, "validate_current", None)
            delegate = getattr(dependency_finder, "find_spec", None)
            if not callable(validator) or not callable(delegate):
                raise ModuleNotFoundError("sealed_dependency_finder_invalid")
            try:
                validator()
                spec = delegate(fullname, path, target)
            except BaseException:
                raise ModuleNotFoundError("sealed_dependency_unavailable") from None
            if spec is None:
                raise ModuleNotFoundError("sealed_dependency_not_allowlisted")
            return spec
        if root not in sys.stdlib_module_names and root not in sys.builtin_module_names:
            raise ModuleNotFoundError("unsealed_external_module")
        runtime_seal = self._runtime_closure
        if runtime_seal is not None:
            if runtime_seal is not self._runtime_closure_identity:
                raise ModuleNotFoundError("runtime_closure_identity_mismatch")
            entry = self._runtime_stdlib_entries.get(fullname)
            if entry is not None:
                try:
                    verified = runtime_seal.verify_stdlib_entry(fullname)
                except BaseException:
                    raise ModuleNotFoundError("runtime_stdlib_unavailable") from None
                if verified is not entry:
                    raise ModuleNotFoundError("runtime_stdlib_entry_changed")
                loader = _SealedRuntimeStdlibLoader(runtime_seal, self, entry)
                spec = importlib.util.spec_from_loader(
                    fullname,
                    loader,
                    origin=entry.origin,
                    is_package=entry.is_package,
                )
                if spec is None:
                    raise SealedImportError("runtime_stdlib_spec_unavailable")
                spec.cached = None
                if entry.is_package:
                    spec.submodule_search_locations = [ntpath.dirname(entry.origin)]
                loader._spec = spec
                self._runtime_stdlib_specs[fullname] = loader
                return spec
        if (
            fullname not in _BOOTSTRAP_MODULE_OBJECTS
            or sys.modules.get(fullname) is not _BOOTSTRAP_MODULE_OBJECTS[fullname]
        ):
            raise ModuleNotFoundError("stdlib_module_outside_bootstrap_snapshot")
        raise ModuleNotFoundError("stdlib_module_not_preloaded")


def _require_clean_after_install(
    seal: SealedSourceTree, *, finder: Optional[SealedSourceFinder] = None
) -> None:
    _require_source_lease(seal)
    expected_paths = tuple(os.path.normcase(os.path.abspath(value)) for value in sys.path)
    if expected_paths != tuple(seal.stdlib_paths):
        raise SealedImportError("sys_path_changed")
    _check_post_bootstrap_state(seal=seal, finder=finder)
    if finder is not None and (not sys.meta_path or sys.meta_path[0] is not finder):
        raise SealedImportError("sealed_finder_not_first")


def validate_clean_bootstrap_import_state() -> None:
    """Require the captured stdlib bootstrap image before any source import."""

    _check_post_bootstrap_state()
    blocked = ("backtrader", "backtrader_runtime", "sitecustomize", "usercustomize")
    if any(
        name == prefix or name.startswith(prefix + ".")
        for name in sys.modules
        for prefix in blocked
    ):
        raise SealedImportError("bootstrap_preloaded_module_invalid")
    if tuple(sys.meta_path) != _BOOTSTRAP_META_PATH:
        raise SealedImportError("meta_path_changed")


def install_sealed_source_finder(seal: SealedSourceTree) -> SealedSourceFinder:
    """Install the strict finder as sys.meta_path[0] after a fresh-state check."""

    if not isinstance(seal, SealedSourceTree):
        raise SealedImportError("source_seal_invalid")
    _require_source_lease(seal)
    if not sys.flags.isolated or not sys.flags.no_site or not sys.dont_write_bytecode:
        raise SealedImportError("isolated_startup_required")
    prefix = sys.pycache_prefix
    if type(prefix) is not str or not os.path.isabs(prefix) or os.path.exists(prefix):
        raise SealedImportError("pycache_prefix_not_fresh")
    try:
        validate_clean_bootstrap_import_state()
    except SealedImportError:
        raise
    except RuntimeError as error:
        raise SealedImportError(str(error)) from None
    blocked = ("backtrader", "backtrader_runtime", "sitecustomize", "usercustomize")
    if any(
        name == blocked_prefix or name.startswith(blocked_prefix + ".")
        for name in sys.modules
        for blocked_prefix in blocked
    ):
        raise SealedImportError("bootstrap_preloaded_module_invalid")
    if tuple(os.path.normcase(os.path.abspath(value)) for value in sys.path) != tuple(
        seal.stdlib_paths
    ):
        raise SealedImportError("sys_path_changed")
    finder = SealedSourceFinder(seal)
    sys.meta_path.insert(0, finder)
    if sys.meta_path[0] is not finder:
        raise SealedImportError("sealed_finder_install_failed")
    return finder


def import_sealed_candidate_module(seal: SealedSourceTree, finder: SealedSourceFinder):
    """Import only the fixed candidate entrypoint through its sealed loader.

    Callers must use this checked boundary rather than importing a candidate
    name directly: Python returns an existing ``sys.modules`` object without
    consulting ``sys.meta_path``.
    """

    if not isinstance(seal, SealedSourceTree) or not isinstance(finder, SealedSourceFinder):
        raise SealedImportError("source_seal_invalid")
    if finder._seal is not seal or finder not in sys.meta_path:
        raise SealedImportError("sealed_finder_invalid")
    _require_clean_after_install(seal, finder=finder)
    entrypoint = _candidate_spec(seal.candidate).entrypoint
    module = importlib.import_module(entrypoint)
    _require_clean_after_install(seal, finder=finder)
    module_spec = getattr(module, "__spec__", None)
    loader = getattr(module_spec, "loader", None)
    expected_relative = entrypoint.replace(".", "/") + ".py"
    if (
        sys.modules.get(entrypoint) is not module
        or type(loader) is not _SealedSourceLoader
        or loader._finder is not finder
        or loader._seal is not seal
        or loader._fullname != entrypoint
        or loader._relative != expected_relative
        or loader._is_package
        or getattr(module, "__cached__", None) is not None
        or getattr(module_spec, "cached", None) is not None
    ):
        raise SealedImportError("candidate_entrypoint_not_sealed")
    return module


def _open_fixed_readonly_role_module(
    seal: SealedSourceTree, finder: SealedSourceFinder, role: str
):
    """Compile one exact data-only role while the sealed finder is installed."""

    if (
        type(seal) is not SealedSourceTree
        or type(finder) is not SealedSourceFinder
        or seal.candidate != "i13_md"
        or finder._seal is not seal
        or not sys.meta_path
        or sys.meta_path[0] is not finder
    ):
        raise SealedImportError("readonly_role_dispatch_unavailable")
    if finder._dependency_finder is None:
        raise SealedImportError("readonly_role_dependency_closure_unavailable")
    if finder._runtime_closure is None:
        raise SealedImportError("readonly_role_runtime_closure_unavailable")
    if finder._runtime_closure_identity is not finder._runtime_closure:
        raise SealedImportError("readonly_role_runtime_closure_invalid")
    if role == "token_bootstrap":
        relative, module_name, _schema = _FIXED_READONLY_TOKEN_HELPER_MODULE
        if "request_coordinator" not in finder._fixed_role_modules:
            raise SealedImportError("readonly_token_helper_outside_coordinator")
    else:
        role_spec = _FIXED_READONLY_ROLE_MODULES.get(role)
        if role_spec is None:
            raise SealedImportError("readonly_role_not_fixed")
        relative, module_name, _schema, _entrypoint = role_spec
    if not _FIXED_READONLY_SERVICE_ROLE_RELATIVE_PATHS.issubset(seal.files):
        raise SealedImportError("readonly_service_role_sources_incomplete")
    required = {
        _FIXED_READONLY_WORKER_RELATIVE_PATH,
        _FIXED_READONLY_BOOTSTRAP_RELATIVE_PATH,
        _FIXED_WORKER_DEPENDENCY_HELPER_RELATIVE_PATH,
    }
    if not required.issubset(seal.files):
        raise SealedImportError("readonly_service_role_bootstrap_unpinned")
    dependency_validator = getattr(finder._dependency_finder, "validate_current", None)
    runtime_validator = getattr(finder._runtime_closure, "verify_current", None)
    if (
        getattr(finder._dependency_finder, "top_level_roots", None)
        != _SEALED_DEPENDENCY_TOP_LEVEL_ROOTS
        or not all(
            callable(getattr(finder._dependency_finder, name, None))
            for name in ("find_spec", "owns_module", "validate_current")
        )
        or not all(
            callable(getattr(finder._runtime_closure, name, None))
            for name in (
                "stdlib_entry",
                "verify_stdlib_entry",
                "read_stdlib_source",
                "verify_current",
            )
        )
        or not callable(dependency_validator)
        or not callable(runtime_validator)
    ):
        raise SealedImportError("readonly_role_closure_unavailable")
    try:
        dependency_validator()
        runtime_validator()
    except BaseException:
        raise SealedImportError("readonly_role_closure_invalid") from None
    digest = _sha256(seal.files.get(relative), "readonly_role_source_unpinned")
    _require_clean_after_install(seal, finder=finder)
    try:
        source = seal.source_lease.read_source(relative, expected_sha256=digest)
    except WindowsSourceLeaseError as error:
        raise SealedImportError("readonly_role_source_unavailable") from error
    if type(source) is not bytes or not source:
        raise SealedImportError("readonly_role_source_invalid")
    try:
        code = compile(source, str(seal.source_root.joinpath(*PurePosixPath(relative).parts)), "exec", dont_inherit=True)
    except (SyntaxError, UnicodeError, ValueError):
        raise SealedImportError("readonly_role_source_invalid") from None
    if module_name in sys.modules:
        raise SealedImportError("readonly_role_module_already_active")
    module = type(sys)(module_name)
    origin = str(seal.source_root.joinpath(*PurePosixPath(relative).parts))
    module_spec = importlib.machinery.ModuleSpec(module_name, None, origin=origin)
    module.__file__ = origin
    module.__cached__ = None
    module.__package__ = ""
    module.__loader__ = None
    module.__spec__ = module_spec
    finder._begin_fixed_role_module(relative, module)
    sys.modules[module_name] = module
    try:
        exec(code, module.__dict__)
        if sys.modules.get(module_name) is not module or module.__spec__ is not module_spec:
            raise SealedImportError("readonly_role_module_identity_mismatch")
        _require_clean_after_install(seal, finder=finder)
        return module
    except BaseException:
        if module_name in sys.modules:
            del sys.modules[module_name]
        finder._fixed_role_modules.pop(role, None)
        raise


def run_fixed_readonly_service_role(
    seal: SealedSourceTree,
    finder: SealedSourceFinder,
    role: str,
    binding: object,
) -> int:
    """Reject role dispatch until the fixed bootstrap owns its runtime adapter.

    The role sources are data-only and are not invoked through caller-supplied
    runtime objects.  The fixed bootstrap must construct the narrow OS adapter
    itself before this boundary can be enabled.
    """

    if type(role) is not str or type(binding) is not dict:
        raise SealedImportError("readonly_role_binding_invalid")
    role_spec = _FIXED_READONLY_ROLE_MODULES.get(role)
    if role_spec is None or binding.get("schema") != role_spec[2]:
        raise SealedImportError("readonly_role_binding_invalid")
    raise SealedImportError("readonly_role_runtime_factory_unavailable")


def run_fixed_readonly_token_bootstrap(
    seal: SealedSourceTree,
    finder: SealedSourceFinder,
    raw: bytes,
    *,
    request_id: str,
    nonce: str,
    owner_sid: str,
):
    """Reject token application until a fixed coordinator adapter exists."""

    if (
        type(finder) is not SealedSourceFinder
        or "request_coordinator" not in finder._fixed_role_modules
    ):
        raise SealedImportError("readonly_token_helper_outside_coordinator")
    raise SealedImportError("readonly_token_runtime_adapter_unavailable")


__all__ = [
    "CANDIDATES",
    "SealedImportError",
    "SealedSourceFinder",
    "SealedSourceTree",
    "WindowsFileIdentity",
    "WindowsSourceLease",
    "WindowsSourceLeaseError",
    "acquire_windows_source_lease",
    "install_sealed_source_finder",
    "import_sealed_candidate_module",
    "parse_candidate_manifest",
    "seal_candidate_source_tree",
    "retry_pending_windows_source_lease_cleanup",
    "validate_fixed_venv_binding",
    "validate_clean_bootstrap_import_state",
    "validate_stdlib_roots",
]

# This generated tail is part of the fixed, hash-bound bootstrap artifact.
_READONLY_BOOTSTRAP_BINDING_ENV = "BT_I13_READONLY_BOOTSTRAP_BINDING"
_READONLY_BOOTSTRAP_BINDING_SCHEMA = "ctp_i13_i15_readonly_preflight_bootstrap_binding.v3"
_READONLY_BOOTSTRAP_SUPPORT_SCHEMA = 3
_READONLY_BOOTSTRAP_SUPPORT_B85 = (
    'c-ri}YkML`k|=yWoe%mIWk1hZz(%w{ca8B`S&iK~R=4y@vb|o7p6UXM7Sjk=3c6d<qx0L}h{#*yrHTT{m)SGkwMSHCWkyCuMn*)&'
    '<$wH-{~3S&axfgF*_TH*pTA5$rM<;G?Z??&(%Rko^61M!vURY1*g8xPn_JskgPp^J{Z?~3-EIw<2m5>b$#%Nc-QPXz?RNWH$!=?B'
    'JKZ}t*xv0Wd%J^XcenXvopn0=d-~<kL2IwMUH@{L%<rK8tT!7@=h=(id>Rj%+wkvh{BDuV`om-#_tWWU@^GJy=W#Ob-A!hV=>v3_'
    'O%}6WYG7<`_51yu!G5y0wbkF-?)H1VomOvmcYALyJvba}^}4$|+lM>by`BBm_TElwd$+sQ-QGDkZ0+>+57RByB|&)D+B(>KtcTEX'
    'knE+sz1?(ccd)(F-8yJ)4VpVUJNr9_{oO&g*K9U-(w%O)z286V?KF1|lUC9{*y-==?hW>uhuwjXj-BS=!C@gfrpXL3FiIAHgER*R'
    'tyT)7?(Xg-Y4>ojy|uqJ*xOCId;5dEt%KdeZm+jHfN8b1TYZ4)U_WiOc9Q<i_Mm^z+}#@VTpaA|HuqX#91ISdtwFlKyVu`K2fghi'
    '-5Io!*3MRUcYA;9U@O`0;^2E*dk2Tf_CCO})7wg0TZh|Qhy9&a(hcBXZ)bn65C^lxcs{&O<KAeJEoNyB9SnB%(w*I%y{&Y&*Xwta'
    'ZtDP+{IK8eb(4dn2SDu~03^);P)xGdO?rD>pwd0SR<qwd-1l&BxYulkad4O<gMOO!x4Qkk!^7SEq&a9E>}_ukx`VC5)*fJYuL=J@'
    '==BG?+gq(}v$@;fOW-e{(B1BC;^P3m*xD(?!30{*;*ZI^ch{f13!`ALzkM*+?WakvneL~%$$r1v+-i1#?svBL_V>Hp*5M&+Vp!ee'
    'V7s;38#MdrAZ>1M?d~5QCi{mj3R*zgdwD2GyMtzW0Q+ljZ~*%***|D)bz!UlAhXxs1qP8OfZc;`vcGqb08iN7Yo*P>U=OHow-q3R'
    '-Q6W9_&Axp2OIz<ri*#pyGzF7bQH!!4=BBx?)MIMx6-YBSS&z)y1PHv1r+p>o!x`2?cN~S?H&xay8!0ab{}{3L94s7x4YMBwR~dO'
    '+20OhVt>22-`{G%62s2l-5G3eCp!n-Ztrk!Z*S1r-RUR$&E4MCZUS6m_h8W5N)C2*T8FLu-ga-lm-c*2Y#+e?6=PyJ?oU2u@!uxh'
    '7zp`&I_~G-0hVZcu)npxJJ>lGz<L0AbPx7g{jGFxxSOQ#KJB;CgWcUGY{MQf`opb$x4WJ8`rECYLEpmz@RO~_TX+i0=sp2h>tD`i'
    '$v7KKX7?~&lFj4A7<g8e#vhtrK7RS-m){RRrTuy|NQR?L+`wr+GMqgUoIQfiqxoGL4aezh9-TI~Uz|2~BXtxsHa4#BhFNq!=`Tjm'
    'D2v7u_>}iEpG-#3Sw9-5AJSRWo2AJ-&8W|d+2q|Uxqq3=lW0Cm)B47{6o#SqNtC6~c3zL*gFgO-+4P6wcTsOL9t__tpxJOTu1CZB'
    '>0~y?1}E1S(bdZz>k)vQ%@cUIkwnwkq?cw{BZ{tJMEKQT^zcIfQLG;{?hoIk*&Lzor=ww)AQ(MFi*c61(=ot0%r*e6z4t)j(9=)A'
    '^hN|B;8V1nr5}drM;n9LVmciSX)fc*`0wd#veBFL)6L1pF*KYG0r;Z<93Dq+N0X!<4{$mBv-K_X{kOCSGwi0Y7-=+_renav2FD&u'
    'A{he|f*rrGP!ypY0SooZT{^~5$GGT-ejF86WRc0`_(jle^y3&H{C+aRm&X^UQB|y5I{q-6O~y2}$!z1~mzTAA^dT7y`+7lX3LLXy'
    '-LpB)mySzV#RZ_+G^q>3W)Wg#mc2MWIm@EKY;q6No+m@Z6tI&%NJ6mG;}4Vfa;WsvFq<Peh<-Q4F}yLIrGwG%-QApq7CQviDH)}+'
    'Iz1A-Vjn>8^alT)O&0I&pifw@-f$k#ZfI;E#R%3`kGhk|JOdJ(if-VO6hEJR81~Z5*#wAR4u;Gji>9MR24nS7nB>N2(i1BIphk=Y'
    'V3~kU$8(_0YXXP*={_Jjdz1TA-~ne#Gw5%~A?}m$aDWtxkYJy<Mf5C&^UUCGlqN6}qJ0VMMzVk&flee$@6!jQeClE{22$38iq(WI'
    'GY9g6zuvyZPoaIII~>1#yCK$vfWVDUM3TXhrq~hn0AMU;2!>=P@c+YcZ?x#cBiL60(&>!2NNUl|D4RquN}to!+qaUw8-L3t06-+A'
    '4vmjSbP9W(A=qqev6n$iOY5*uYNO~L5WmD*;N+U%&h7Pp{caE{k_gvtWP>*ur;7K%|0m;UG61?8r`SWEb_A|2&`S?E81Y0{edu&L'
    '7bsO+NXpL}YVXl5c<~Z;K{TBJF+NCYOF3hiA^`*Sk4AvL|5^-Z$e!Un95(QJL+~QC2EYj4rE~r{klMVV*r8loMOnBx<r3l78v^rU'
    '6A&nR9|*>n;*k)!bSXI%zLqNwXo062iXg=B=_in!#)Mh{d+%XW_c28R$pj_P>e0fDY3;^IcLaniy2eHy;0(iOid)lh(%67QPOM=Z'
    '4;C<T8prayh-jf{2V@)aQ5Uw#-j4d!n?Fob{q8Qw?%-(9Kkt*C`WuN+{XL%J_E*0q`tw<;{>mOQ0TR$i(i<fia$osQKY~Mfn2sd<'
    'VUIAhYIFh9kkoR4V~OpGu&NfXlPMtY9h?uJ9<JeqZh{nUx2Z?xQ^Y|ssz+BqO0Wd!#>>vd+4--pJ8!PztCLrq*T+#isw`0i8y{K~'
    '{^9vW=koaa^!$zb7WoUZmsoS?%Em9}mp^tc<IBz&H2t{~UmRb*!uCN;!~0%JogiLSHoiMQzrMP@Jib`FGfmgj-(~0j`>Atv9iN<^'
    'U%otjb9{ZiDww!2fsEtcWCFMvC-ccn_I%Pgy||8lxjen@tllXdDDlVHa4u(leg0$TO}y^>=Ww2mow>)~pZ-VZWqf&l)`_pqf4V#o'
    'eO*CkKuCX2aW7UsFU3$jDw=9NDg^wowjrRnxIF*i^7!@3<LhJH0swI~LACN7$l53%rn5>ts+`VKA^Yq!@h41uQ%!kO5pP8e@v?Ju'
    'atUz41l}CK#@;K8u5ou)WXt29u3!Dw`BgV#$6-ZxcF}qBvh(KT*ZB4Eo73+RMXXoB<v=F1`n~+=&GqT)j{gNe?^NT9Ur&x<R{~}_'
    '@W6CF%#Z>0H&J|`Be0i%WTl6YYw_|F{(`CgO5F=`%G^d*C$N2;P2ceMOyfgSeR<Wn{P`3JML}bh<77U)lwba!Fuwsa{SS`!?|!}R'
    'AbsuaL|;YCt=5icadCW!yrj6{)vIIBr~r0&JWCrOH%&p_tyXTfHV>1{!R_b0oyWia^*>>`<Ezt`e!Hv9=4SPOA7S&`uQzL-oAu_-'
    'qxdC1Q=}gHT92~bQlng)UUdA1e`WtP@ITYxG{yhzYE*3^odUYy-`&l;j>WPgj%81xpPXJQIpDybAk8Gxw90#}MPEmu8U1JH@?7E>'
    '2i~dx^5LM2kKdfUf<^iMm?$cy9Ssd8UDQ{q@ZrhXDK6l5r*D8o{E*-9ho6pti5$O)*$Ki{T@TG6QKv^}$Av%ewpqAYeD&+qb>}rw'
    '3(gklV|TN80H{2E`TF$DDY7eo>dJ1g-P+vU*?~siU7jDmjFC-Tc8*^HfY8k0o%Bg_a|?Ns__}5O+%bRdnLqc<pUo!wo3$ngb}PU-'
    ';~zS2I+v#>@$uOijNIBg*x80xd*%g#hHsiX`#T5Qdpif_6>)2L*WB9Q-rs2+;2!(_6wU&A5hEwYFXhAI3&g&9YB%lRqvoD`_Of%<'
    'frlrrPS0M_4z}7JUteFIe)p5u-Lwky65&*xH~BN_8=w}wVt;5?-q1jv(7a)OJL=i_FEBrNy4%`m9pIP8Z+?JP|LID;e|>!QBa#Bg'
    '-9I7+E%3m_g?hv>VK?iT2Nn|SRty91Le2~RGBeUYXet{-WAb1GjJWXA692=SkAqh0N#}TDgXGWXr9J?UNyzTZW|LX<=VY`<>Cf8H'
    'Mg;$We0>aTrJtY<k!MNTlybT-W5A)@K(TzIpAI5v4y%5^j*lciAd3$ict@b(%xcl*xA?zeyy1W(UD3X#%uVnbHA{06GzN>&=pGHS'
    'tmPX}*{~TsiQ4w27v1AOvt$U0czFH-t{Sx!nvCd8PNu&=^8u)Sv7GAoT|7;Ov#d)0l{lNF*<v(@mHPZhztO-3LPT8x1_}(dHW0z2'
    'Nk<>cPtBWU@K%h<%7BB;Dm61->hlI3-U3WwI&6O8wVWU*ag#B0GSX&F)J>je_3%%D0r)XW$Ewx0bj;(!YUM=*u^?aI6Z}Z1Tn!X|'
    'GWn5wDPD{xvwH((E&8I(dPv3(Ral)FnfX3f8pur>jmjgfih54X8yVnlj^}u#R;xXgUjALHdR1{Qw6A9XlH7gq1)6F5rc*JTwD-<H'
    'S|{xChe~ahJIcJDKFseX<5(E7Q9|@y<$UoWon=G0j{JEt>)j2}Y5*cQ149^>;%wMA4|}5_+A*zX@~XfcR6aI_fczP$JE#09gG3Z3'
    '{XWocW}c$3j<oML7x#E%n2cx1$0K2Z^WV82vfagBiM=8$?aZ2MT35{=_2{cQnjOgq!+T**eblISN_W434{qDY;MixmX!5_JZJI-L'
    'z^my6v%_gNz%cNa2xc?SqWk0lKuBjj+!bU_By-FZjcnb?V%$$=55)hmZv`tJTk<4ua8c*F7(-z^9gbtN3Q1O`cnhFba~5GpmAnOB'
    'D9%D{V8S6Kq};~N0Sa$o;^CNV;u0=685e-4wlW|!<UA3E#$EbJSSYJ{5(p|9mq=0v;)`Vi(T`c)+LHhkoyPaWj7~`j>wNZLdX>i{'
    'S+^Q^Q;;FdjXvp?)yiT%*gUAz>XPe=b1uG{Oy0Ni&%v5pbu@#90d{7^+gE=AnuD>aT|Gj>mi*HbOV-4SUO8a`$DJWrH`!Q`Og~q|'
    '^%|ZNlc_W^;19-|*-vNh;Tyq4sf}ToWTeo{5`S52l0C?0kk}|^&(pY!DdKO39a0m{>=<6Udpkw1We1N1XMBIyo71fvXg}r{R(O5V'
    'qLHCAb9Nm-LBrgr<+{c3e7mL+2XEM7x=pnub9FFvr!ih-;5M+qWJH53ut>bRu_)};rZ}ftL1IdpyHO-}Yb}s?7+fLs>I<ZIBRCMv'
    'YGRS%0g)1u2r7@Oqe%)D!Id<_7hp(qaKmA})mx2;K0cMGFV$>l@hjVnX0x$dL42qN)*MBv<JT`?W2`-0yluc6BbO!&S1>EcS;eg*'
    'TA5aigV<}$KKGR-vT8An$!)CkChExy;dWH@dvY3+q_H}>;B%M087pH{&KaCT>+F?>0BIj%aC^-W@-^0(b>q%Juu@>G4E_S{>r6*~'
    '?M?=z8~*m&2<@arw$zf-$^*`xmL)*QPf+e^%d52p03`(o17!maGZHD1tT!B1m`{P!iSlItbMP~Hp!Qr-a-;w$oUv)y2<KAe?}2RD'
    '3OF(opO?^*WZ$<1r#TAN9-GXQN*$q=VS>xHbq4EGS0^mFGN}l!jSW7Q+lXOyOEoRc2GdcNE^i)`)}*I_r?{{t(p$k>&E=xsZLxs3'
    '(wf@1tos0#UBV>*IZLQSS9|^PO!j=$a)jQTMayX&5}w_qQVsIfDNp*o&Fj4MnlR+l9WctSMi2mJ4UA$h^}hb%ekzS>=zTGpqsEXC'
    'U#=_fx5+GPS1WZC1dot=r(>dX;^u;byBuE47I`QLQhL-U=>dQ`BOX>Po116Zs505P&Hk?ESkv0hLg#3Aw*ke^TIRZMjcc1f>$X8o'
    '52{2^&b&RzHaw0LYulcfTMt?D+F@b0&Slaz`@7Dh(6;%rZrk|UVQ%JgE@ui$xnA4jO!Yk5VB6j^bxVY7^B;BBPUwQ~>dm)Ymv&dd'
    'u`IUD0a*{37Te~Wtozo*wy*)!q=8XMNpaE}#RGVkRllkW|1oWGh1vAd>`1%z+{_o#QF=2R&(WDu{Ri!UFb#r)T%G&yiN3BRGa+;|'
    '8cjYT|4b9rL>m(Aw#=qz1ZOlOF39_Fj1&Y~@rP7-xRC=WS=_5A-`1nSD0v4fai3)G>k+6GwdnYy6VV*C?GX5fo-6T9G~lzV+j<nZ'
    't}UyaYQH$rFJmzfkdVNTV{$|k*Axg<!f-tr4S_W)+aoQ)S|j&yaUF}ITnIuEUW-Qmh+6RP4*Yun|2FsFKYRGA**efSOaKCcXG6kf'
    'pfw4CUx~K#0$B8pRsiA2&DO1MJtSXXv2OIPX}zo2FIz<~w{N*NBVLNpG;X)*QL|>=G;gDSi~g^Lk6Ml@$_8-M&{bDtF@BHk(Xi`M'
    'c8dnTVnMrco%}pO<rCy9G<0~+v96lqHRP7?R5n!1_o49cHT}VagBRCNnU5NeoXTP`7@JxUT#p;5r6Y+8TU6PMyw<hQy!`9z=a?0Z'
    'sV5~^r{>r6QgERvekYlxdzn>tZ?cHFp~>uq-a7ox+>PVB@$z;Pulr;mgSZr#(0$7JmGp<7&W7XOaEi|8h#7IuBEirskBeuyrZD)A'
    'bs`})JUR3EtU}ye1uLE7{eqj)X}O$NGyV`ZJJnXOJ5f_^G;4Fv*D*_(uO0kKsq?duYq{^wvT0k?_gH)MuHM;e`{v!gYzLybl)m9S'
    'w&TrpBz^VpV2wbsfNd>ed;nDz-9_W%KIP|ak?V!K2DaZtN%U&J;(X-doxC>ssXO^iL)p?GGtcPUI*jBses*)TLsr|H$`xuV<U+NJ'
    '|2f#I+&&+8mIW+Zba5X}fUjZ{P+Od>)he8Q1Y^zeG7w<y9NpF|lb5k^Jqwh+QHxw4#*6!II*Yym_Kq@(`1NhH(>mNa+}m#*?h>f-'
    'IRI-<t*k#p84L#eYS2d>R8J8f#mV2gdR45tpUyzG?AyGWZ;S6>EAU_r6iGo^Lp?(AW!xIF9}^D4;!3QY!MbYaZB!dlW%&^U6nvy-'
    'Qo?GZ1FBTVYcI+WqezDH2hT(!mPU3j7iTn?ykATMixXf+*<|z~wE}t!JNoNi8;!=>w<r`$78oZcqnQ-rI=ecyWdE#zi$E7K<2hZ`'
    'WDi+mI!fjk@JP?$VBBt%y`WL2sJfKY_xA)&OoKt69N<dyb>zE0`+Okje@Ldo?G}75f=U`Nsh4MG)rxupjA)Ui@d$%7Q-p_^zVRP{'
    'WRxT22aPj&ax9>G1Hk>_G;SobcOohTn4TQA7k}*CC7@~7qk<<NCa@{ZgNyUiH`krZs(!x!{<Ynz74)(6le`AE?j%4Z7lNl53|blv'
    'I~0+*{JrR^x@EA}pWG*)m@jXL-N8B(HxiIlg|`hSk9s7Y$#1(4vvg2Z5Y~ck8DzD<hX6~>3`~S!V0)L&8NpO7fn79JYE!e-sz<Hu'
    '9TI{RKn>yG@eN4yD~Q=a2Ci5@G92lBqtMx13<fEKT7>_`z!&g3T)eH?FnJ4?)5k*G1*uN%lTX!VoiDcR&cY1hq+kUN$ocDNLAAz$'
    '{+8&Tr=RAWeC5t$)B&g62aM!qyyQeYx*GPcCs(vE@aHe?7h#67j9Ewk*v?knE!o;~tz>K6ArO2uut*A!5YiDRza7>sPS1_b;WJ$U'
    '<dXVeI0h}*>5Ae`;{iq*dq>CnbT&>$xkm>a5b*8y@M%tuMay}c_f25U#1}aqc*}-U_ZRI+eqrAwS=ymL(OY%n*;bfI%E~PlaQ{8L'
    'JRPHmL5@9Yg0O8CWG<I<rkq(2xu7<F#LtfBu(!I4d5Zp5{?S;i4CW`u*`V9&;eC2G`B<vmtKqx5+=gd>_+v7DEbG#4xwO+?&{$Na'
    'Pu;Mf%l^loC!@uEdIgeYGI~Q=Mov>&fGc3H1>Na3`LK<}Am@X#;rM-4)X(X-pMF|47&QuycB`r9xHm$eR;HfgUV4H@R1N^p?RV(t'
    'dOH3oOP91keozP_O{V|dWPbM&gy0^i6AuV)9-ttQEBXBGTZ$t&eHnjue*FsL4CB)`-=Bj-kMV-TPspYEq(#cK0V!yc(mhTK_V&cz'
    '0JG?ffx(^+26zh_o}0#h&U?OBcoS%`w?i##($8<BNjco)1Sa;b;C*M@KOZ2p;n!#^6e$^yO2TbQu@P*98o^mQemBn}+fL$+!d_kh'
    'r<{koK%Z*6O~q9NFfx-ZO+SAsxt{|?#x6ODuvH=|icZUIaoM@LKEAxxEt?y0=kgMxd(Y$7=a(J&4#Uiv2eOZ|(<?hNR)w1Bn5_6^'
    'hiqmnZq2;A>|7jQUUgy;eh4-dz-oZ%yn)tY)GhqSiW0yCEino;6TI?K8&3(gCR%`0YH@`}rVh}UZyhgvG|Q5oJ#4mLQ2&i|f15+Y'
    'c_JxOvxqIv(ie24*Z%Y0sAWT0cQUBvv5pl?tL8G-#(-lXLP?#Z79plgh&jOTEfGj^2XI6v16lW6vennQEUuvlvLTy(tLM5>z*X5<'
    '1ZBq*xg8pW@_<B{MD^F3Odk-w8v*dqEmIYxyWBDdx#yXWV^dUX6px5|z;w{yNmFasys2il*DJa5Vp&=P8ydA+GH9}A|0`<gM|vRM'
    'z$`qrGjJQm8~s~UEoK5bDAZvfPsTlgQ-+kJ!3ybvP4y^u+P79{M{{peI();Nd-IA%THF!yndcNBC#ek5oM264AfWz<ra1PyTKVgz'
    'tu6iNH^aFkHYaq@9!)}?Lq*L!yY=(JhmLPPQDlu|ik(ymH!iS9`qauqNV#X&^MO1X-VZr#jX~fuT)=P*M-a4EfPdo|v$`Psz0Yg@'
    'zoG-;1nki_<<AG3X<%|I{hW39b=hO`_c(79Ol=M#H|>iHDzW}NNL9zBs#|tijU#y@C-2Samk{ocB4x@^cL_(4?Rq3V+A{<85vG<J'
    'N$YvOCz9m@Q^FZZ1XbMORS7vbuwi=1I7UAm4+d|#EY(cL?lUmQT6BDJwn-jLLgFH2NM@}2OC*d5BA*=QIz#Iq`T>BT+Z~B3BzYGE'
    '!XT{Ja306iEFBGs-LV|!DiJp_8Z=_dccg9g;k3k^HALSq<Hq1D@2!bZH=oJq{&w_zGRjit<#aO4Cga@Kli3sy6HDYAk&hG-#H|tL'
    'Ok-u=TG{gD^t1lu3w8AG872wq-KX=rN#88h`;<A1*f(8lJFy7#UXrC=L^}SbRx=ck^o9FMCP{$)X5M?k6Ys0Kk?CXE#3qln@i#z6'
    'N+5gTBf7jTE(x_=c?98!mw|#93&iLRDN~IFU1e0%GH&Fj^bpt(!0auOC1({*rR#eaQBuWtG1h747>_lGLsx0sLW-Urs(__?ap{kL'
    'q1@o0+3YsGXk~h_SJ-r-SF=nfc}xH3U7zq?8^bJHbde71i9f-^PWLY|7m{bU?wny-Qr&$rwWmhA>WI5k2{#LLjA9S*W-LIsNGG2k'
    'YYjw8R;@j<JxwI~l;HwYo;#fCM7W0Nb4TBzl=lU5(Cdo@+^@z>tfsrJHK<8QUX=be-$bnyMZ;2%^%gTq9NU&2GF$fTggjb642oe>'
    'S7qzEC0aNKgF-Ln%=}c>4mipnnTiSBG(n^GCuG2p-288o;n)mIem&ktbh|?$EsTg_szw`)5^YA!@Ha7^M%0cB*_nm0`3P=4uP@9W'
    'V|^^Z^#Lt~O=JRMMwlPk1Jf2=+Gd;Lm35U;-T1;vE#P6^Hd{`83eA`-*Oqy4EM{2`$aSir%@9#llrJoqNI2y3CzKwi;rGiAZ-X^+'
    'cuSY0uj&Cw*Ol-Jz3Er?zpwj3Z<~a&dam3n-Up6SmwbrjG1G%3a|Q%av?yA?d1O{lMm0H)Y-!cDmZ=ob?Z9fej7l|bSUc*AwzV>3'
    '@KFsdkiW2nX{({{3=OUQhe&Sv8@4#un*FRjjfuVo9us5!?~!e{k!bMOUU+MhkwO6%AoSl3C?P8|T0`lck(&_qjSh>u3=QVcM7(U!'
    '4Nr=S^)G(2vVKtF`lIN9<LXfUliL7P%Wu+!&pKWhY&W;|TP&V~$zm2;vCt|%|A&?2&sc_nq>$G`=$6C?Dl!hGwRO1P+(kIIw|94U'
    'cG#K`b<0qdYKtUuM*hSFn1hvw7}uzhVvK-Bay8{lwXI`?ND1KB!Cp}2vb?SolB=7|n)JX}UrrSey8a;Yc2k(I(3+EPqQ(0dP3Ynd'
    'h}{i~j=T+wO&YF40h$uGT02kMq_b4qMuC1bb~mXAJ+nj+JTa=d(Cm4DdtErZ_Zc`$Sb!Ax)!}jiuNXBaQS8Vo{6|PA@q=0HnM#8f'
    'V2B*OC5C(lhZ@<z#CzM*07U6;qHWws&damO$I#UHv4`q_ZN`!NN6l5iXNx2@4g%A*#EFmy;oT7A_~kI>#nf{QiBuGSlp~cg>k`WI'
    'UaJ^m{4ve!#pU@mFe%KHjCrdYNxx4rS?x&_)&s479QF_Lx@1zJx37hC$n2yd`<m}t#7r52QH1=Dm<QQnEJ_NvM`z=Qbnbli-NP#y'
    '-}`taC%*tZ%+F7ES<cZ<HLtp?T2h7M*oP>oJ%M>^ANQ~oM;h>O6t<SigH5g>{v>9Z226m8#!Z{`fhE_`Ae^iCd)oHUe+sWphCOHf'
    'S9a<wkJ226PFUUQdY+rkcKq{sX6AWi8p;oyo*pA3MfW#VY6H3{#b*1{W;+05s0$lpX>Tz@USLJ?<hMtor259+SHNwr<V$3X!LLf~'
    'D%u(O+J(32To35w+jQ+OZo{(*5TO9t$u<lP_;>j%zgZ`pVaM70wB|Vx6|mUhH-S~QLjxpiUnrjul2E*F8ahca>C8CZlQjv7@-NAa'
    'lq?YNCbi`o#IT@zpFrVb_F?F=k`%gJC)Rhp?f^?p0(Kh6FKBH;VnE%wW0wzGHBoO0L}=wgiy@6$hkH*`H3B&qSQ>!LzRWZ;PIFcw'
    '4Ye(a{*o*q2u_&=&{lHFK926KMyF9Ytpx;jOc)@~?Ltl(T<BCTv^39K>&-f@@$?$%q1cK(K&!4Xb{XD~wv~dPq700JKsR!rtpzbA'
    'S3?>OFwI7=nKHPjcFo%$LUoT;_Kc^aCY%66{X@wdY`nP3?=4sKb+ofQHn7&ff@&#N%QIQ(EiKUqivgkwjd~D7uy&BDnyelg??P$E'
    'S=Q7whS3U`K2Y-&b(yTw`AD2)R^w1=AD!!_t-2DqecJdR$Aa+`3;c=}kAG6(HzW%fX_w|nrpM4t&VBNUyx=pVyo;ZIwC90)OS9&+'
    'Ff-&xZ)D5Lq;KM^cvEW0(t-%Ty?pat$vKnp1n>W8-j?rWq3u)*?^;lQH`5%NY1LRDPD*5`CrT(OWyD<tQQD@_qev7hHZ<1;%2DO;'
    '5%FpncMz=#c!Z3*wlS(gxHv-H_byJUqi@*;TpLq?MEwFw>3g4LT?zBqh2ZR+Pge7ig4$>@euw|&pK_{2%@gl#?E#mFZPQ6Mlx9G$'
    '@2VFHjXin?w6%Nc(Uv2FsS)s1ZT&S6T-LolDH$*R_q1j?=J>0IMdxtYtY*)o)s#qy;GS4C`jVv+i7))*1O6t^SGL&gvh`D;()gvb'
    'lr*ALmut_ymUzdA14wxbuekw)Cyp{4W9E}lI=9lV4TR9Q(s4i^#qOa%Pm4|k(IEd=@LM1sv-7FhBL|NN)`{YkdJyLw^#63^791YZ'
    '04nIHfhxxlj&*A!rVoIo0emXlg~VmcpT;9|pyUzHokS33R;{gaFB>MN-$1_b8rXE?`p>U%CA&mOaU5lQnQk>vX6-8)pCbP#kwz1|'
    'efKH#1lw`exP}KKHf0b&M>!o*<fbY>KYB0~+zqyQfp;;x#)j_e&4l!nP0X~<KgzK3HWon7RMl-&5L`F;m}KN`k@k&m?QnjlLb`3g'
    '4@}Vnrw=xmEat)q_eDQNhD=w)=s$$RaPA={qG=1iKR!9jsC2ywoscENDK8{(b1_3PAEuJ%pz*(eAUMKpiIoSX?*it&qSSTR4Z7TK'
    '_9i1B5Oflgd)}}G;1rPzedR0ir*R-J@a(lItsaHrfC3R=xf-2O8@Y31k&0)++FX`UHLsR>lC2)yWYobJR-bx@<#lx(=R`7Z|7($2'
    'p0rEv$eF-T->!9clOs{yI$bXj5S_?pbyme9TuJ$96-UIIEglGzE-iuU`pdPD!Ja0wOe{5!8xhsE<BO*u`*PV-SYApjEc+Qq1`xK2'
    '+QEbCQ*2l|F1>ozs+lOx^wS)Tl%-M#7}2fv=Zg3&-m8Pjs89Yr6vB+w<P;xOMc|5xy(QppH=HSnZz&5X{=^6s`RK_U2;qq7V4-CC'
    'o}etED6w2ZDxz$G!hy54N6CG+pAfu9QPr7JUBoK$TX(th#_7jcR%*`|H0o4M4Kv>BM3_$A2+KPK&N<;VOJWCQW85Ts%7OIx4hQQf'
    '>7|I62(wCnViFKd8h?UwQ>U%ac<{2+T7}$MvRda8TWeWfSwo;KHob&n#aFFQNp)|(TGb|~pplm)0Z`TwFjTii(uEa-Vws{tUV^!z'
    'h}F$A$RPQ?^`#JLOCCDZgh;VGCj<7ZGBRi~iN2014Xm?LG1vV<Hn)R|n3tyNhxvDjZR`m&A*XoJ_D|&zFF{(x9bVU^cU<DNmwAC}'
    'dcYSRc3Z5Swgos<u?#s*=gmT=bJf@CzUQk5HCmv-VGi(S_h5U~7!5_>$p{4$IH588BXgrOO7R+TP%ZU^k6o+DZ|@RcXrkC#6JrEe'
    'fycQBdGq%qB@nZW(x&wvXPRa(lyC`g(k<EAgwCQ7PGvzG{%$dTFB8+qoHROBhSn->z0XQ%CDeDF2B$v*eik@UI2Q}8?2a}gaFg$('
    'rj!>mtYc-DV=6m4lB9fOEaT?mH9RyFU5W}GK~2L>|6vVpd;E+R*_}_h-{WJX-0x_zng31si+j<$y!#im&qM#ZOpiJZqiV@zLWl{m'
    'E6#x3KKFLOyX53|Jd!9>9x8P&@f?O$i;tBtv*yY*zg4V<ohn2*<b+WF$Hj-(yKbfMkadu=Dq@x+WkrOP69s4z-o8?rG09cTuiVTz'
    '92SE&8U_v2Iw0!eV<(`6nwH~9qUjQTlou61S1!~;E{9rWx5!>a_8emfp#IC<svQ*t*UEH6Zh9V(mk1A1L0*oHktJ=V>_u2bFzr{R'
    'nIk}!E>~Wa2WT*Z``CjvZx@6>yE(!TIW!tq^+dc5Yxd<Kr7X}lh{5?Q{Z*#%2q3_nyk!l|V}q*O>0~MrC)gTCILTW+1_2E5;^+_L'
    '6kb?ekYPC4rYwk-B%8_wwm-~z$xH#9*X$_5n3HhsuUle1cmT@ut+UCyS#lp^qBLPRu}y7$p_28hk;t;|l$h*?pH5%q<z)8rD8B^g'
    'nmMU{@m<S(*WA<ZwhP|vSntr91>*aG^fo7BD^<iHV4HipyW5BR`+K0O?Cl)xVPwbQ;nqI%73cz*AJ(H*3tB;o<~IBdzxUyP58>bD'
    'ZnLH;(#UX<oB+7&E*%APh{+d4Da3d@rD)x_di6s({}H{Pzo*$DO>8U+pVZNkh=<w==9DE-bw%-&=<KBk&<(5<I*C{w;oTJomJx`p'
    ')vRb3@z8a#U$)tCgV6pEZsTI$fDP9=Vf`WsmU)sxB3xO+quA=X=dAqn9CMbdbAgldst(R8IXCA-^$8>e<N9P|@~2ego8ycu=(v#c'
    'AL+~>y2295j_H#3TaUgH)sleW{&0ExTGo0zJH9^sxg)Ym)%=25yf-sUT^3$?*||EoJiWNa3%%pl9a*zU7C&72_3=;Fudr01`7}^%'
    'xC9J-ae33DTakEacV5YJ)|a|z@DUy8r*qN)%$VCetB9BN0WTh=kXH}k!Y{B~w}7hY)R~v^j_9TC#7&+#q8h-PR1Q<$C`l<T!p`7l'
    'GN)=`)8QCjen`h30(VYvoQ)>)EXLEWT8Rk|OvW1v+OE`cQ*2^Od08g29EOkm+;p32CGdaTSJWeAErb6pOeQ&#xF{;;xU>W#{;5L~'
    'RYqhJt5`WQ57xW@Rbb{NYYUcUeBo4*#bSdh;o9d4<xEzIll^LlwciL*yT)K%*oW0iUi?S9xhHLw${`{g5JC&5KXvOT<DX5;R<2v%'
    '4{Z)z{T9$dMuKhui=eey%~31Wnij3u^F^kN?ws|otzeMWkQc{D0d=CsnumYBQ5pvO;>J;9qHVCY#Q#o%%<`I*@xeQT&a7)~jXc9`'
    '{t~74)A>Ur49?MgidwR%WQdb@FTv$)v<nm8xW5f~Q!KMPEV{l_Do0Mz$GNff#ugLv)yfj261e95O=-rV0zs)OIwe~jdUnooCK#&^'
    '(b76}QVblCr%vrCG$pI`Cw4@opL#L`5&lAFR=`g;>G5j<8a*&7U{ep8m!Y`wjiUNZLtvXUk#8&BVJ;6xZM6b|Kc6Q5wLrI#K{~@6'
    '#hEIhIzm#Rm8Wcqlf|qD5Ao7G%RRZ794`)VC0mGtoF0ju0#DS1eBNQtIyXWKbyJUcr}`IlSg_irKRo5lFHc6`W03;@`|UR7kl;>Z'
    'KXaNAn5HTHd>R=@_Om(F%Z;?K+O{GQk9>O#Uq$YoJ!F(`SX?@&WSis-EIoin2`H?0FF@_G7^=#LD>CW&YfulOyB@-8&F6wy{uPIO'
    'At{(LS0wZKtQuGaAV<5KO29_|bTv|Yt5(MjOxC-qm5aYB5~GkJN{-JnnYUB!)*obTyAvvQj>V4Qz|#9wJl)KaLF!cdra0pWc?)`D'
    'KiCJNR>&;B^J}ab{$ZGYjK*jbB`0!mDw4xQfAiJr;}c;%mFSy;lFBs;;;V~US{J1RX2TEY%yM#lfhm9n!*>he>s_ZCuyJ(t^2bJW'
    'ifIq=mv$)cib+POOZ)}Lm+AdSBLM1tk>Oc89E~Ja2|&<e(Bi9S50pgyB}k3aA*kEaG@UgzxKFsM6)61oRKWvQLC`!jh33sO>@`mM'
    'eNf9Y_VfXCfidv>w6`F~BJUNTvbDQs9`jPt&MQ|r^BS;tXCu`DO_RB>YG|n*$@0>Qv_c=}s!OFi{5YAthl4SoXmZF)cZU>=ep>U%'
    '`*f_-sM24{>l3=s(H{ZBOBSQK`mUf4#&M?;bnh}}Ptm1~1+$V2<CC+~&YSD_yHjDI{{C3F<6fWt*m<)~AyY|@a-ZlyXX)Q)@od?V'
    '0OQ1tMnJ#L^-~I}Qsoq1aLuck$^p{F(7BW?MIg25Jjc%~*W)wvfpRKz-r;!@e|LF){4z#c(PiiOW#<xmyduRq(E4+H_3PDj=QTE}'
    'NAdB?*QakzudXkTVG*yyLw8D#wI?iV7W6pHvz^k=9@{}Hs{1U|so0lRC*o1CgXwU*tP_u&iD(u%Z;R(F?<|J_qW`M<276mzda=B|'
    'mUAcQ)^8&ZG^_trrLo`<Ugevo{rQX8W1Sy9@`)h{`G6lg>XExn_H!{g`OI4$`8)^H{#PUzwY7ZtZLQJ}zBE;j&-mM-?rui;fKN(2'
    '@+mq*q<J(~L_W1A2)`(6q@RG_av{p(U<JWf#HvmD>83PulC7i2qy8CA0MU_m-|C+5`BJe+f0Xl;ZAtSQaN~{$I5AfI?|!}RTv;|n'
    'aRDsDT!NedeWXx7o{DQ_Nr`zYt=su~mw#Di`|Gaqc0(~$Imwk7-Q$EomQQDMc}v5OLxB@}o9N=zUTZsw&;OPp$DM6Q(zXv&PD|M*'
    'I|Efi_6Uzk*^qBu-IPD9S*_iDZ9Z||guWBFcE6D;z}tJ2qQCLpSl{KWuKqf2^`B!C=cIXAzKhG5wZt_InHNZ93aEn=u8U?LqZ_Wm'
    'x@_;H9O#v4OS`d>T#u@^(8RTcr=r+eJz^ES3Qcgo184nBtbEdW&X(%2HZ0?cf<RG8qd&|%L<zBgCg?rQRq^Vc-dm5#X>&wpOKcRA'
    'aYjxpq|g)XjT6B7M=9M1lLPrz%Gd>UbTY~$bA~2Gb2vPK$$Bb?VW?%*g<$g%`a%f)$C5r6%hd%*q9w#mUk$W{&=8!KQ0gJTkx&C?'
    'L`Y!GI~-ggHgp(-gxb7AAYafeX8(21TGIA}Adl0zO<?BBrI2<BImNazv<uA(lDUi~B*Njg$l-L=5<B?}dJ$&EI_Tr$%`EK!tvMz~'
    'wCv&@Kfl^U=K~atdkNnDlO0YB$_<YFbTsTz&J17<!sMv=1ec>PgmD->)gmJ|IyN*iCvxj0g77|lXuvF)p%R@iF;cHCteec3X&El_'
    'jh2{rgK;MS5ls$5iqWKe*P{pOiBv{p3Uiz)=@65}9POvV6Jj>$FN9l~a7d+mlaVmwC=)t$#N5;(AsmWoUD^aMV%uyJr{2Dn3yxBY'
    'fB5P6^5yCA8}xWNJOA}H(hw8fuU;K{>U%<r$Wyl2I0nINq+iZ2e*~@>@~qLLlvBN}(d1@j19{Fiy8ERD1K+okj7JYyV>(LasN>S}'
    'kHhhH>j`e3N=kVkF%ARHDH`SGX!{oXucAL>vmWi%%6jApR)}d;Mj*{OCjs}@BCX4Ja23{4PgJPmGx`7cWuAAL9!CfjR=pA~VN^|p'
    '(WU3(V=dr9sE25nvZ_@V=$fn1ny-u!`-iBnfvs3ZcMa~W5}K;pfa?^N#FVdSnjC)eI;LGxMD=LNKP$bXQm>OOe^_G2^0PCDEpH+P'
    'RuCBkBHC@_#dt(XCc<@(^5aPi;ko)wiKvnF6qTg`OBh?54M7-36|YJ&sE3CMsk0kT0#67aK5T2;gt{YZ@#OUWUfL9dBr+W>GNa~-'
    'Q~m|{Fl4DJ?24zbf>}x>rxHUlp%q1@_JvH+ePB*PIHeRMj%%R6EXwXCi%}m|H=Xr{Ld6!W5somyIA-c@98USsu=h|GcN!04Xe!b`'
    'Mjzpn*z6@!nuIuPol8q`J*_<*`NQ06!eMi}=;dzy%hj(l<zsoadC!ws?{0`21F*8jrK@BC-aRPJ5D)agi{0Rh@a?T~mi3yK(}l}j'
    '+NuV4WIGF~UZH2K^J@A)4|{`mUWeJd4-&Le@Ey-M&(WBTCZA?K5S2?^NE;6lbsa0P%pLX%?F^#1<<e2yRFXFCS9?hA08-pV$TA|{'
    '=;d~vhnCrC;)|0`*S%3}m(H>4-*^N0GgLz;G1zbMtQX`a=t^#P6ir1mS2CZYw`94-G9oR|(uyf{TRiK1`|+ETS0KHud(ZAGJb@eb'
    'buR(kF{_NFt82g@KVNd&SK{u_;-2~Ui4GUEKQ55I<V_;uHKi^WEjF~|n$j?!f-6XaPjv$s#OIQW#uC?-7C!T@G97%{9~aqq#DxRH'
    'XYswJ^8w*A?}k*;@4o{=r|E3|psCqDNsDP(Y(e{r{C;;=?svCDzX}&@hN8lT9^rK|g>K%7BT?{3+h1IZjdgJ!JVaYnf~vtLrHG#b'
    'Sn15MZb_~z^PSGDOA<K^IWQbepB}E!t>v@tQc*dImN{^U`8y3=Ck-iYIj!VV(~OH>PFw!Ud~i3p*9|?vh5RF>q~bQxFQ_j^b}>Uc'
    'FQ74(W>h==>@k;grw_dZmII`b6a@4f5~E8nk-Xq86+%7qa*z2_`gPlY7bV>cuP4wnK!!-_p8QM8CCJM^N1t*Q<=sem{`i6Qk^y_a'
    'o*bXN>ckh99e5xE((Jey#oC0!szznm$|%3n%*p)e`S3EC5$K89c#gZu%ev@G%Msn}0I@{z(5eUJF)Y$c)2AVKVNvB<E8zrPU9pOq'
    'w&_ylJZUynF_je0Ueh<xwk}j2ukt(0eh1uD7}sOxh^%-pYd2>x@!IMGa&(ri)k#J?F=P-OIesD*ZamY=I%XGp5>^V>u%)FqJ>=be'
    '(rZYmJnj$Q0nV#;Np=Tpt|5;|{I+qIev)r%A)#aaWe~l__rr`lD1CMU!{;$t5Zvd$RFkP4x>S6qe|LU<jYi%JdjXe^Q7AF|^Kzi2'
    'ykG@D4YJDaY88+#k!yHP&N2b@tuTsxmawHPK2GRtPWsHmrazUthjyCfydt{X#JfAP>iwxsX2qM7Yn@Bfe~#nm39Q{++9z=L9Ky@L'
    'NqH8w?oHs2;p}=&PXWC=OP68l+9hB%!6I5_bB2PYi#DvNb%9>7QfuDC9@V|NziCgK+k)i(RJ)bO+0re6th5=+1PteAo%rhfr^}O$'
    '%q+A@I<=&ax(3HIaZ$qme|L%YiA*Mlydp-!*sg!T*@5tKdcn03$6ILzW_A1<v#lV^Pi9?y&T{m8T_a_A0JxkIeUg5DH>MecZAHfE'
    '@k}nF=CaN|mDu{v&FY?0bS}U9b4BJgI7*%|Q|6NIO(wJcaGV%>Z5e}UE?ufR2`A_0moHD>pr4H+-8&L{5RPKm-GU@Xv?vQl2r(=-'
    '>oeg*q*MCk^7Oj16dm^H&w+`hqx(ppJFd8-Vq6XjbTby`>3j|vyz!rohn2=x_b8?GM<I?HzckDrhFjLEx@M&^P_giTD$_0t%knPS'
    'y|^svKAXF>ZMSM}JsmpWzi49~>nEF}oC~g1*suQdDfTFyO9!YkXGiE836r~~Kb)b%XVv+c6OL49ap(6PXTvV0GRc5jY)+Hj`vj&|'
    '$+55p?*IO@=JwU7G0%&F6DCiz^(-=BxvSMR%%-8vR+AgWQQ}<PuE5J=W-96PtnMFm9>O4B`=@7VK|dQ#K~7G!XQZNMi1hQicqT4~'
    '(s4odsfO!V#EB3ogTEJ^)Q;*x!tGIXg>oRs*W|JkNXRzy8WAZMXN!DVoL)KQ#?IA7v#BW^M<n{LQ_eXuPlOY@4U0aJ#k%eO@i`r>'
    '&hxJ$>!~#WmIcFq*367Z8RN1vR2EDYVvUuWCDNN$^VWvte<L+UCukBm(ybZ!gRnV0*H9cy<pz`$`T|X?dVNAIr=c5E&z!Paij<+O'
    'fM2Z^EL<p#{PARVk4;4{fjoECoUEnz?JFA=5QP+fq)(6~HCZVkv-~&?DQY_YjRi(B!Pr^Q21!XZx9nloW)ULT<gq3;9AzF^+SX1{'
    'h}hQ&4%rHD#^oj159BpmA)#UJbVXoF;dJpq+3AY5<)$mx`0qQ>TBra<9xIUJiZpI3L`Zl<W&m=-EtXqa#kW}&2zhYNO?9AKhbByc'
    's)y;qoxjr|DqNYMjc{X1v@Ey@fC;Ua^jeHS?55+Ck~cbHWGK<;A8wgc2&EjS=)L6RIpti;b8=!SPrbfSNh{Hp*5!)Qr<RfX^yozu'
    'M1MOeWnE!pjhX&GCy1Z~02BTD6U2h*R~BmO(N}?4)I52?jBLpa>~Zb4S-{^{=K7Zy@-H#uUt)+OhRDcO9^Sevd6_=Y9h<-!m9Ya+'
    '%Ft0+Z=WC(OG^<x!B^9TQ|DLW;iqe4f+PNj=^>KQ$e7xQ4UssZQy;6m7$OBSp2&+onafLfkxZ0L{_=Q*UCNt<*Nwhk&8la{2^shN'
    'fS46)ZiaJO=G*r)a_y_Eyaolg19_i#re&A;=!|P>v3LxnyH0_C6lS*H%d@(!wnpr7C9p<za<>)N$4_2bc5Up?hrCwaHE4dB)gZU7'
    'g$oLXf<D8Xy0m1+yUO9!hCPQqTFRq?02E~qcmi(^FtsAKF6&Cm8+>i%7VZr?)!8ihcofM>E`fld3k;)@HASeOXfZ}tIaV)3=hD;l'
    'IX(`702gQ_CK=}5WIe)vPVnpyYCDxDKEfhGM{fnQH_TrYSa=)3zKQe^fF&8Ip<&|yh#*^@j9q7G$Fu{i4#03c1-NAGhUi$<kaViD'
    'iXxhr4n7+q&yZyxL=yJ8tPf5}jj|MWI39;ETivl!ixi+&WQRRX6+*|+Pj7yFbN<U4h1mwj`|@Mb2`OH^zO8U03|S#eh12Iai`^w9'
    'cOWrrETjcBmqLF-+ogg<(W?UL<Mg9N>`wTop?o6xKXfPSwG)tsa)VfDExm0~Af!<V;fM(Rg%HfdCrUD-tY4~Bz@iHZ&mFuJSEqsw'
    '*G+n<+vZXYZO3Xpc?m?+3P+*bElyeArDq5Z>7OG(9j4$gSWmGL0ISNr;j<~HbZn6Vv+|T&_2XG)<0%^9iR5TR%;PaHS5OWp4j8PX'
    '^*{(~uIs=+J*^0YuR1&l65gF~gUExYAOUUeCe}G=*XTq7P#49<1=x04XYuSwQc=#JZm!_iItZ6?RKYjpc`rZRl;^$?eMBgN5Nu{?'
    'Hl2*~)ZW7L+h%z=RO6h2D^X0T<B1HTK>`Z6*cVWNJyk!a@v{|$51kER<mDWzYi>AC#93+khp2H)K$frEGw-$4`O5E@*t&cIf#*+Y'
    '&9csVVA%O)b91^;%Gnk2!PaH=S6MAeumzQEHkJ8Ushi11p|GJ<Ai7W9W34-$q}53Vfy*m4X<sNQZzg$pVy|BQh+xc7C8I3Sv&n~H'
    'U!<fJZBTXru@_WV(1=8?OX<ExAjr&ee@HIZf8}ibC(haGc!1}-;O6*MIu)sxWPQaA@@_VqKhWJ9CLUWQ$7|WdvGyo6p7D^>fVMe;'
    'oob8vxm&VPzi?Fw{!K`WV((W^PP^)I{Km;_Z9ekM32j%;OY5%D3e@0zZe8<o1IUu=Ue*-vK{4J()V(Ux5^cr+5+GkBz5Q%wU0h*r'
    '@QrO(6??2%1vEv@a4fH_DFX!vyjN~eHEa;(^3u}A>KaRlNJ$Tr5$v!b9@Ha#v)&f3!k6tq^0#?WtuEtaZ6ukP6(VVo7`5uLu@E+_'
    '=dAYIIxgU$omCV~<6KuTKz`d;n5WHX)rgGzS^n`67Ei;(%3%fhsQ7)u1W4r+V`tIuema?fG&`SC5<W_pM|taFapQ~`hqK6eRJtoX'
    '@L;FQH%S&*4|q;=`?$b^${w=O`2^gN#OMo>-CtT~i$poYsr;UpO-!ecJU;T;m<nEEASK)m`|S$MX%prI|L$(8OwYV5@`q-n=FUds'
    '`tv6uPDwGQo%h_vfla5LbC?-}XR9Q4F1In~eY`0K?G^PKsHRoid${~os83T7%l}-ylLfWBPo?-A{#L%M<$ldm6o$LtEdu@Y;9#RO'
    'FT1HwQtW=^_NL<O+{&%fcQ}3MDjQtWhnB8XTJ*pc*FYNj%ZJ`5-?r$xqV!}LfP*5eomRD&)asT`m(|u!3)$!m-k~dC?kCp38V79I'
    '@Vm-w$XRTSUQxw-dWRLsSO5Cg0_F^eqb>_1(lGwH-<|4AFj1$(JUj888*YABw(`6|WYIy(^#l}lf+Xo?B553G)r{%5-zts)YW(NN'
    '2K~QI_xn{yBWJ8voLtHj;Pz~BleTWw0Eyxbv~p&BgjeIxVK7Svqv5-|xs4$IG++eQRy!A;O>yXcY%gKk{#o~t*!G^(9c;DjpY_m`'
    '+kt1gAs|-B=hDmfK`dI$;}}vawnT%5xPekrR<}!-qOEGCk4UwNPwR$WZ7yt@U#-(52?ilz*qc|WJw4^g4l?vBVu@r$xBQ8H=g6<+'
    'G)qQvlAHpWnpmSi#mJ?Hh}%br+@HP_zHSCkoz%lXRd6inbQ3{vpCxTz$d6cweyHX8Lj&R7dpd63VP>&FkNS$7j$L=+^2$dUZoC>O'
    'MQ(Vm7u|ZEb4qepo*qd^*|7ghCAaq{nv>{0yx#*=Oxo*6clA)olcJt><9S|Bfl7wNdzRHP%oCjJPW_a2u9RF4Ra9vgOT>1OfIO=T'
    'D;p3ru()*u@)%OxEz8nYEF_0N6C=TuL+OH6P%erv`!mPIx?9+#Y}dQ8>)nE`t%?X7p;l&pw@5<138+lzgjGx{`Slc*TP5m#^_g}^'
    'mdCX3b-x@<J5QGP61ls*dU@XMlh_hS*&C;vgzL=43rEPzWiqkS)yerqCsap*;V4iYl+~Beu_71xS(Q~Ov+T`v>&&TJ2Nlm(h=l98'
    'x$xR&wmU=H8HBqEwXH;HmIqJU2Bt*iQp?oYb_}1niCo(G_QY`Bj&_dO%?smd+j?r<tCZ8mYnXbtMvi*t6iE%$gmLU@c%Kb|3L2?p'
    '#|@<hg+oe|ia`RexGQrT4%3X?xVX1X#UED1`D%%!zjG8%z=uHqg<cF!7nQmTUD$5f;JT%=f&q*=EzFHi_<}C~%Md!t``bU4uYDm#'
    'L;Y0hK`1@<4bjWS^2jym_7ip?eFo>zXLK9opcXohR+ep&72tm!AJHJ_?vBaRI9K&;EpQ=y0<^5#Af&?BxE82S36d;=Rg{f!5}opk'
    '<rPV}(7W&{G|W3La*kVCM>J>T;HaMLVPlGa^F$A`6>E_SBVdn=c-7iX^Y+>6lKMdARV0n$WHgGg=<!X3c~gNrd3k(&dj1AgarXS`'
    '<W=YOF+B{8j4yJGBlt>6t*#3cmgF(71NC~$%d5`i&!;CH{WMP%=kKiQ?)W0d2Mb??3{m)ec}01rmA3+wTa2xmrJM51XIF^igO^dH'
    'L^6&*3ZKn4$q7&m6`fw3m|F5wN1k$>4Dq9AF`lLGh9FMPuuSW)J4<E{#s(|uu0k{6j;H-7sP=ke<Lz4=C4=MY*}Z*BHP-RAROVX|'
    'K88+}dozoT`CT%nV#3n1Q1B>GbN+%9t%#clL@1e_p^8rtUuE?T%(8#{eSC3x(TR*6I*!=*zy>xk)2T4o)Cqz3nTk>)rn7;%A34p5'
    'Ft!AkOsZ4HxZd2N*1bdtdOFT2o=c!$qdUPq`cXDY(<$?Bq?PMtlhI<H0!orTI=W?z=oEUMq?t@vlA#56!||S!)PP7rVH_(@E2lwN'
    'D)OxqweAUU;aQ0lF2~v8KHb19I3f^^)|D<D$U6tUK+U}~M%3NO3co}RQ8s)xPUtRRf`xiTonBBh2Lb^|Z%IFyqE9<bI@_2tyr47b'
    'tdd0^li{2~|DeZylHO0S&KTPLRLI<kSa@ivmh$w)Il%m|AtL3X?r4HZ6VTpC^dmn13-mV<PWNI!av&AOC{<NrNidac!^6DTP+}(O'
    'C)gQ?)zjwoi__*VyKvMu8Y*mWLp%FZ453=NZrYpNr?iDAKQwHfle5!kHo-A1PgeA_r40(;Ev8e-7Q(8!fZjc&O)Dx$C@%qhH$ubG'
    'QuQf56S33XkVJ@cVEYOP=RSp<Gf#C?rN9baO(-72hNh1i1lkDWI?zuyMSdmtjszhSosdmJ%I+D4@dH@EU35HI@*bfX&a(|M(5BL7'
    'vT-ua?k4lU2vF}Q{RIV1!pHQb#_0k>CZfS&&a@!lA+XWquS`!0s6uty*g*ea*<9M5_0RjHr~dw1HW{nGh4ESankbNA&DCFUD$h5x'
    '<Hvl14o6+5JJs$Y`jKdX-6ERg+Y3_eFJL|wlWh12e~NbKN3Q#Dt0d|sgixzZJvyHXf9$$Wn6)9!U%Vd-Tv?J)q4A+v*$DYU!bf|`'
    'cD^BxJUHm6qyyRY(Ntf#+1flzHV3z#_jVrt`q%#iktzPUb9n`lK%njM=6@!ee}^w_&7Y0<>&@HGTlKwd_5I25o0q3AkFPuN+3~OE'
    'KV3sFfnt%;hJ6%OE52pog_^BnLvP?p<H@`H6JVV1eExt&P`uME{^-6R!zM+Vi(w}ttH~znDp(oG3qjpo9n{@*Kt)Jmk$zw1;U_2`'
    '5%1?OJMsB1Z&0Q>eM2JC)e_uSfJ>@U2m$FxPaN9q0zLeE+W7^AvhW88gA%naj!%9({s9RnFqO&%2z#eLBZXXceh|)~KycVN{gm8K'
    'M``wA3jl+)Oyc`te*niqoDJ{ClaDWC7n|t!Bm)$nJL;nI!>{q_OV&$+I%#;FR1BP@+LKAg40hSMIKI4sIi8=sLE;u0?DS3N@;cU$'
    '3gL}w%Uq2Qt%~;{o|^vF`>Xz^f&W2kJ^ru3?Iw2w)0=v`r8ebR=ZE8yU){mJKRqKFsVdiq7qP5OE$L7_=99p4a29{W+p_-TT|q+?'
    'Z1A^9H%3T7ODoY@W2b!6SPBQU6>x!$U!K1?`;}CRv(q15UB^Ps$K?q1r%PHGrw3t2#14b~X{Bd{F7@f`^cpA}v9#Af4GXVVUWB1U'
    'hr9}e)0b1oU}<MgEd{4HrPEOz7Da*FfxHMa^(b$O{EY+fBPR+!^ygLQ>_VWZ;DiVpmc`U^c2(h~`#P%T6Kb6U?Dw13VQ^LSCh=6%'
    'f*lr^CdY4JBiIY`JnL55*dPH6ge??!&d7I2m^^;Q003?^0ZH)~SY|&Vr6EmbASY`_VWCW5$|n>kH~w9Vc2z-lZ4s%+2fIe$%BWOg'
    '5beDr@2M%niv33VtLPWZCBQs1SMW!61#jyIW=j?3Yke7My6|q{y;m+I_7%JLoZqE;FY(HhKXh(9*>u_c=8;IFC??ZrG;TNS$Q<kA'
    'C5w{pWUZH<>A%8Va5`ED1xJQKqK-Bi8kJIB%1KLyj-v!chQdowa|3CvpHSF$B9wL^dRsOXQ2R5I`f*uN*+IQMRRLgtDKr8eu>>>G'
    'J?89?dfnT%0t;{73M*a0qQ++Fhhh4W2YI0ZBLjI+^rm7tQKQ4;dU6b@T?!<C#%`H#MBL>y;3Ffm0wAF`$5v$X5b8;aiV5nygXBG#'
    'S4da1BQ~{byUZ;lR^Oop-(y`awu!@?PRJIegK@+0;gla%q<m51hO4~UZ9;ZlpO;kB?JOfrCqUBj5u>8*s-io;Zyt^dQsL5PK0@>~'
    '058@g{H7}FZEjEBM$Og%%i!M_EJh=8YsyvLj!1cHw)P(@^}KPzDOUq{)Soh>s9rQ)N^xJ&?Zqe=>+SusjOgk|B7R|<rhT)Q$1t|C'
    'hRB^Yz2h}FHOpPXnyuUWz+;cAN|$Q;iMJ7uUl6-^3I`7!1JBQj^&~7Wqa*)tTDF#_sO~7UytSByokud@{q*9bu5HNZAu$8V87)F&'
    '<rQXI@`ceW8eBd*Eb;d~ENvg^08)*U6<a6ipN4GOI98eWGSj+`{q;{%Yhf;B5)(^~5|7N01f-vkc~e{P(E|Mm&ePryGse9KJ$a1l'
    'gtk+&M00Dyfr5~6WU84@@mzp4myN9ab@G`6QQOFFEOZFd<?T~Yaxp_=aN0jneBzX>a~dgEq7=7aG0dtgjd<_zwh}nh2V){ei}oz~'
    'Ka(z^0R#|@6?Ee}@)(^P`h6s4C20UJGpt9(1znh3t(W)dJfVwF)V)EgT3|K%Y%!YaR^?K&h;(^Q8B4p0B{f-EeVba9JxA<ZPvW*U'
    '>~CTv<cRwVq(_kwkp%wnJ79mqSyrY0%HahfU{aqSH<Uv*?7O;>`o<Bpw&V}IcA~WDgu`;P;F(i3V9=43n*{s2frqyM4~@UU>m|`^'
    'IXNkPP$RX9b-tzS?2bz8p!TkiVa&lyL@+IJDY2PA2-X(ZszhH!dpm9l2!GZBo*JKpn3k9X5bb0Pm>6jr4u#1)%cSs60kM>mWUFt5'
    '7deVWl@}FUM)^VsO446_m?hmzek5O-fI<T%#VME`lJNs(<(^TIg3px(YSfKJ<xwWX7tg7ABLgCsSB0m0?HN(2^ZYw#R52vFbjLba'
    '6&Qsn>$=nM5a*!hg%7NI5ZMtRG*)+Y)ex=-RY80OyTg~+(-D^w<?8DIM+HhJA+W$ufbuHkm6f^~3@HoU>1E>{0i>+3L_QkVQgekR'
    '>8Bvf;RQ5Z0FI+%_HKc;9KZtJx8cRv7;o(-<aL5rl$m!}(w{~Y9iw{LUyw1xQb#9UDz*ZLxj6IDF+o{@=A#FROw>owmDlK~>ZXzF'
    'hKitkoNDS?rq4f7UlS=s{B}k)+{me=9{8r5uD3=3^3b(iiRp6z$1gno%tgmb9dE%H8q3>D9wl^D+n{@B9KO*{@eaLOS<DBU2YA^g'
    'c$YY}<Gab^eLMeDuW@%!4?<@OylwR-*nu!EwW~+QmROJQhRk)wDuV*O297san73jepUCq&XNSt?N(MXiJ|Wj4sY8%~mbO@hf{Mw#'
    ';&C<D2E%mJ&wMhWk#E$X6c{e9tyZK#`rheYn_k;$7(Js~Ch3~ja+0@9%Q7$Jyl*X(st$u#H7^OVQja5Siuk4#aj12=@TM2g2O&|f'
    '2o6+BD=hh!ETBtkD=rvg;oK$sg$Q2!JAL;63K9QO{4$2*RVSqGo`cg7_zq4-y>ijYHDdg&Z58;#DBkuj6>J6%(ZXEOar4ZeA#h+!'
    '8LLiIYV6^Os%5>=Q@QnIW#bRQgyp;sZS`p-$}+Lup^X$H^JeFi0l)<81-tc6DwY2%M;I5BaU*E;R`VZG@5@7@ZtYMsu@lc9Kt}}M'
    'gy~&;74!~ZpYkmszTgf3D7m{(>4xUwzYK#{;Z4Z{NKZO`*v5g`f;vCJ4d0hG(=soDyNkd6qD_xHf0{CYv-otc>XoUb6<e?~br}68'
    '>rqu3J(XNgC%d5eWz3p26x%&e{San+0AsNjR2=KpvzBAKAcn*X;y!kc3?NiDh85X~%6K9F_PKvaJciDC-G>E<y|uJ*hJbr{J?c>a'
    '$81!qd0=2Qy}~g~)(?06*hs2TV2~ieh;<A57ul0MikyfzZ=H@bS96fWSX&4uoU`$@KGJxxSKS?ly}I>~!Fx7z4t<y(kD3dLLxvp&'
    'luKc|(QGz$DVKt3U>%d9)$!|>dpng9o4Po&rao{BSi1pJ9nQD>sCIg^GMg;xk{$84T2kc|YV5x8xG&KwNd>Gw{Ov(0Gi6xd@*D&_'
    'Ezgy3b}+&;re|TAlaoSfNrtJw*k!mg0mM*4`_9pxxX6R)StLR%Nyt80tYjaGbz-$UeXYnZgi0KKthsyU$=Y|)b6AJjWobG#50PEh'
    '^qHaxLx!P{Jr<FK*v{<p0ISlqtlgE8{aXfV*%)DBaHDxEgDtu#C7FyYU9v5{1b&C6b@sTdSvw!04)QRuhpLn9RjO1?MA(xxF=Jek'
    'ns$G2Kb1C3yj`2k(Ey#%#YbJ`x}VIlcC}K+Epde0E*(?gVUqQR!}j;dC`)UNbZqJAitf;)@kQGVyPD)nRbteq70X^1G_6%#QMnzE'
    '!t1UpPTP{8>-^fV?Ig&`+TLLnJo^AiCToC|D8Nmak)I?(=XCJ+CqI&WHtHNrPDTyy913UB2%koE?(NeSSrYu*2QJ{g!ggz`aSp^*'
    'ZUm8m$)@aDD6@gKOiAlEtYu6$b{U`q&*EwyGa8JtBh0~t_m1+yi!8NRi{gmW7dB{I#iv(iZ+=u?Hqe9xR8FR9s$QXPy<`L8K9u4H'
    'OJ&T4-37|`^=PXW{aa+a1uHNypa3@Ac%p$tlN{)X<9SvUZUZ8a;46%fLe~jhYumYvlV&}6Q^5@DWdsLgmbly0SBi~`nrFZ)E)<7t'
    '@Gx>+?zAn&B@6sb^XQgD9@CmCNV6uI=c5VvQ(c?&)A8b-OxU_aGlSj$qyBn9ALd7o%4HF0*G9OcRr#qGM|yshSL`VlU)F_VIL0%d'
    '3Tvy3Wc6Ts4iN&QZ>+M`Kp0Vz)mc)c{POhDBjuIgknRgeC^|qcWXmN&<yfceX&Xi8ULVzXPV0?9caa9R93)Wt5DJ!W5O?1G=(znu'
    '17CK2c*?-D^xa~V%!s>G6!#EWqeVh7%B;mXhL%0?Sj)NMV@`0(SrO+z?TQ4%TYL)tqpdyx`J-Bybz#Xcf9@OxzqiRv#*Y!D42V)h'
    'E6Q&+o>bjB#&l^To8a85ZVs^M>!@jeBcjI2j6kSn&7V%XW?`05FuU{drlf^)Mo0p2)`7&H_0tda$ow3RC;TT~36Zi=rOE0K^e<|!'
    'e~IQeKtX%apTVGRWIw`|=34zpH&8^?YhLz3ul%al4!U{boo~KN+t0di@|XvEO7}Jq<!!>BP3=nM*(;pe%pI^iS}_9D@mrSHw)in!'
    '-F8#k#g{n=4>O~$(FHKMH?x~(3@NA3%1Bx_>%oX&5iA@{2GpI59+rut=%g3Hs3YaKET&|_tp9aA{IBcbe_anh-}Nw4V(C(ldA+iG'
    'V*D%Uk}9m>#u=5m47#D>8*)G`b?p{lva8%ahl42B95;9^&G1%WYO=1R;}Z8^Ze^k3ey!EIb(YVqmn7EDx%^Yt;^D=`E;UBnHa=(K'
    'gut%cIeFNIM*hmXEe(gWvYS)y>ylTdW=5<7XDW(z!|2MPa0^{-n*h4X_$HLSK({Z(&6dl%SYK%qN^4H;&DC#d-~YYtMBK^dT#gV6'
    'GixR|n!RN7EVyFwjmYW}Rq0Z;AhZ*0T-c=OT~2UkDV@>Ks&bQ_=a}c!tl7=3HtC@8ngR<<d{f{8(Il!ie|Z4p*y1fHZq)a;Y+pKW'
    'LS1{?@4t<S+tVbhbka`B?A$c5Pcb<Mj|=g|Z);@^9$Rg8)H!*I?c~H^Hs0pEzb<IoH|JY4S;o*D&X%>J=1At<oQeoCd@@i8LE3ce'
    'Y6td1FANEWxf_o9z!Q3taUVJ#fG~}@$mf%3tnwwr_Y<H?q)Gk0;FTMsV=n-1Ha!I=bf+E-r#+Rb0Fzef&V5zd4?@b`drrta4oM{t'
    'n@=!-me4;Zm?I5)l}V|2NH1<~RXuf<lFJKzqgM2V>JRi<OuyBL-oCY<fBQBXI$9wNjd_h!mN2Q7W0EY)?n6n!m|70)=65277|2=2'
    'KfxClr!T4XaGpi4ULT*p8e&)DcWF*~vhhTL3D52^Mwz;km#iugmY~MS<g*dhg1h7crhF1uWSO;O?C)Lb1W~Dqw9;hJU10e<f>+xm'
    '5O6gKpa)yqH}yqUw8hjM$Eo1<3G31&wA;M?Y>iiBTo3ZAm5yq+i?B+p=IXHmSIXwCbYZFdCU)T{yIs}2DGv-D@O%hY0+7}}r@GA-'
    '?T9zGDq)4n)i~`f=vP5H@P#p11EgpeF8|?1s#&|frYK6kHau(<P_R>(U@y;u*sxi>M8Iu@460v6-?XExm1IQo?UI2NH(z^4c^w6|'
    'QuyqyturIlMa~{FXOT<sPFy_8l~mzJ*jl=&`P>u9@mN-7E;?GP)=^zEoX&X+DhD0A^ifURwTccZ<7BMeh2Vg<yU#iEYs_INuR*CH'
    '^_TXrMI)|1nB1jXjjiY#3z@JXwzu#xC01ofR`67Y<3VL53KQM*WzNp9{Zs(Lu>MWkMF{R(wkkF}_|`?>`Vi}$imYAYj^8O$6SQBM'
    'mi$Gn#66;=w(#pj_hPlU8(YUI>W8PArkrVPA}@?yvngMQtbDAzI-P1G${K2hrAxupw!Qc;8R50%LoE7JQ}wQK4SxL-v~Hb!`fkB9'
    '>I4M{yS9`H9vq7<bBany%(0atuSqige5H#u$=KBw6?UT<zMrn^{Jfqv9|qbuehBi{yg}XGV)Aa;=G!*gQ|mBhy;DGn=NCd!#Aa6Z'
    'qoUM(sz1!W2@}<+f$=NK7L1ipx~Z_ut0Mtknjh$I%o#nrWbBJvje^{{a>Ot|mrj8eHfMRX@+zoOip+Q-U#(|8p(G00dP2`aH$3Sl'
    '&}u-Xfsri<tE!cJQQU}Y`lc$okz(5HZ&RqK?Ft`td%kV!S4iJ&+c;y&YTF!ECF)OvtUF4%tx`UWc15Pks3?bxwk;?sRH^*!mJV*u'
    '-_TQ=la|VtA*;psRt`e8_gHT?<@lx`A#%j*mom)**=W@ul_yR<Fqn8#;Vc9ZBh!n-s*Bq1j2XNg)~Qk2Q4nzPR?wN16@y&>>rQfS'
    'g3U1IN|=51ZM3s>xVIYrlYrS0g0)52)a-j${k6W3mD~KE>_WBx8_vC~@)s~I#WiN+T*Jyu!3b6wW@2Gvq99Go!2;sW@ZFe_FHX8-'
    '_v!O6UvgHxcb<V1VYkMPfMwoe!cUY;6%!4<M2$7h7QG(j$x<!S`|13_>Qq{l5H$63HW{H`qo@$Z?}p9H*{R0f!_KQbI%=3h>HK2F'
    'y!@h_k8+Y}#G@M*5^-Bpa89fCnu6iLCc}g2l1=4S0iskuyCt9It%%QKN;|f-=6oaR!wM-4wv*&zH(ZOL!!e5J#^}jbC`{Rh-m{%z'
    '8XR&B(^AaueUg=!g|}9EHvZ~70ebHuLX-X~a}r*mQd{!k;i`6uyE>jD+BENbi;@lAODg8Ovk8wgmF`LnrhGe-@q;d4A=Cdu;|PzA'
    '2J`m{J2){n$P&b^<NluCp-Ffft^&jVt3FNsA~+|fbLWh@n<k#NsW0tk_gvEj%5zRyhlV^jj9-##j19OgHJ?8CZ1OR4b792XOTju*'
    'p|OW3{JV)(DB54t0)C*FNSkg51TUWAu|<_i#P3yMpUnE{EEstwZlAc>0S5?Iu@*P~*q-|XXv2XXjhw5)c~y<Kg4$?Ib#J-^awLWn'
    'M2RNGbqP>(M`^QZtmmP;0994;3QK%wRi2yRN>LgQB@I*B)4`fzimAy0L9>Ew$gnl}sEF#wEm*Fg4U3uhoEA@I0tjaTSQlt!MT4Pk'
    '#3;8x5XrL0guHbC$Z@w(URN^AR`6kzH8oCIbwHVx44T5ysRp%mpvmJ0`MaEO#C%W6Y<7n>sKieZBT$?EMy~l$q{4?)CIG=}9)o<#'
    'vXtJMy?*5G(?>75+3~3wX1eOBPIyEnXS#sTFqkG-REBeh%&MWwlV|V))vRc{9pzUR@Vhldqt@+N=j-=7*Xq}VoD7%rk10e7%0z4|'
    '+f6(*A$90wCZsQ(Eis|!P39%kaW7SW(J9cvUPk`NECGMYamTtR@=3>iNjy~ZM7&iv{QS)2k#Y+aJ+3T01bCOy`)S_>U~nqZ1X@6U'
    'Fd&ARh%yy!7MdGPcDFaJ+eb?$k%I$CWQ(qG_FP30)`km-rNvlWi5UH)xPnZ8YYYl@u<}E7zA1!NS7wn_Ou~?QL+6%Cc?t-uw8&jL'
    'n&v`7WgEwHYa1Z%7t9$iDXKE=x|m_$nHcPf*iP`x7wy7sOAv>it<^D5GHR%!bk0(a<O5esHsLi`6(VFJl-o+Npkg;$=d68>8>6TD'
    '+v=TI;BD&}V8lMRO)3CSjI}QNR*s<pyNaDh_scK8yaX&`F-t6>1h|8*BZ*;|C>%WlDRVkr_{yq^%C%0|Pa1BR+zJt6dn=ez>}*HD'
    'bbyvQLt1y*STnIf2n(AtFk-b$;R2Offd%5~VLVShJ=GjhJPF4%fla6~ENt&ku{?H8P<v@hWo6_kHyS#U!n(@U>Q4F(M>&O`v1y&~'
    'bxh{}ny0sr;K9BCsqkGo7vH=AP;0~p#M8!*BGC0LDD0BnAUHTyL;TEY0ZCp>M&*s6_Cm2WceJBi_{U>81>vb`w`q7_dlO~NoO!Gc'
    'stl-B%}BRvs!hQ_Qw?smZUty3GC6YXdA5gAH`q80lfzwU^-oNw&QtlBn1}_IO0zkf73}0?GxH`uj87IRjz<$@>8$^E$<%V@A<h^5'
    '13hL?@;w{Ar&=Pnz7g4}GjhvVBNa-Zp(Mvc*Ww6=(o7PA_lYfvW`f-%nF`hA4&9;{_GB=i62Sdo@@_oI=EGhi>VP;%QP_CbrPBT1'
    'r->@;EGkz|qzWlU0!UtH+cue6sd}<JoP{&@yIGq4g@<>`gxI?DG=-pzd6jGx#f^OdaHEkCcclT{R3+}oYS)w5@b93Yv+SS3f5$Gr'
    '#5}b;cP=H|qA$;?xnhcf91)RDJQ1rqUS$%oazR2`GQZ-|St3CiPZ{40<ydq)mAt`&E=w$5qVqk6H2A3=KsnG@1}ZN(jn~|QpVC{1'
    'SJiUKY6MCYOEfaiJ-onj^tF6YaB2z)g@7jmV6zt=3fsmSgiFCD4KMA|a#-C=$u<$?U5p?LN&PAL)5_4DgM<&KV{bNcpE=9yn%K%F'
    '!mzt>J*PE}LI-={+Ax;RDTd!!1-{pHyaa#K?u~(>Xp$)~(FqePP*yL|X|WV8Key#@lRK=+uQ0#j_jRfsp`Rrylxw9_a!sAEEO5#*'
    'u4j=ko;~<3APEa5LJg{xAk5|9H34()+~|g9Okybwc;wdM!KV#C*Kq3I#Gt>&aJ(>_jGX7R8duj+4t0UHt|7XYR4eU@SM5iCRW|EX'
    '9?mr!YVazC6-oFT7=VJw5pi$G$|~YbEl{#YEZ^z?<(2Fa{rM$(l(?5QK*U8C?%rt8PdBp%kX!CI?SzsbomKcW=(=ZsVW<@?CCYwO'
    'h-J+Up04V0H?k$AO7#oZP_&K&TBcJiPGyR1%H^&y$nw2TME)IJ``C(qS}%H1>)@)q&F>UYDc`_C$~u2n=->hRg%N<4)+}Tap~+8a'
    'mAR{nh&q)P2!%#f5atAsBI>wEk<nNZ(EH-;Ti+!5_N`J+qv)7~&ZIAb7f}!$4ey6Cei5BJ$l7d`+!F;BN%Q1see@bsL|^ldlgJJZ'
    'MD9Qz|3v^ifSFQ?AUN(YY7v;tVE7IMZL~tZ!0M<&fLbWq>0R<+IGKf01?iz(bHBM!koGW7x?D-cve^)m<J;xy2K^c07Fl|tHNqDE'
    '`-CYnJd_Vs^gk*Svgm)cYT#nIctxJ)o76uxuznXv@Zq-g@sSg)!V?Pk-|Gk!KO;y^xCf?$6)KpS$_te-wgImzsvW8X9yscI2N)*_'
    't(}5442dsp!oQA?+4g5l2V`g?s3XFp3L!zbPM#Cyp0T)sU7#2p$#=Rqp*z?rl%+m$)8<f@T5u1G56i%CGp4Q37f+_flbCBPO8{9F'
    'x^*V)E`MPNn!8=Nk)=2!O^SJWdz5zsbnli(k?NAEiBhH?X2%E?Pw@;I%d&x*89XhF&zVMXXK0IzEJn)8O*poB*BVq3J2-?_gu}xQ'
    'vl6Y;uPL<Qb*XKOA(rOU$8dlQxylqWv?AAFQ*b1AoSIVrIta2Uuwka2TS_D6ATVYgv;(hd{*iUHmiYkNqvTI|T}ynPS;b0ZZ&U*_'
    'i#D4N&-@c6wz^I6Z8TI_Pil3yMtM7zj@05&FY1RhG+E!;t7;0L$k(ha%55kWQIWLaCMU|5EKI8XkfakzQC}<=SPAHJj-HTLK5Oc|'
    'tOp9Fw*!@NhRtmX&kS)m<qvi1?WSRKx9F?gc<z1mSTi~}Z3m{~kop+IZ&MxmzmrOi)+;R1EhlQqX4eB{v4#G=r1tl@ykrtqjEGzw'
    'QT>K-?*9^@dY%pjDe25Jm7aHVIQ|<+DlDb1M6#2A7xVWd<h~SLnY6%MAE&HU8J?ZP>~4c))~47DERelvT*#=g$^it&uLKmUmMetd'
    'cVl{(u{;52kI3c#d`3<QqU5-+ONbBk^_j9680A~mJeMVBlezr55xtfe7j@7P<2YpyKPOo2h58dYx#=reOr0_+C9?;{NHGg?4+HBk'
    'b;pCuW9*t2q+LN;8I*Z}79{(#r66|G&ICxajO$CN&bu{^O21Uv6vs9;KcaHBc01>JV6V5mC+@~?+dqRWpdEPTafG(3od|&gcS=nA'
    '!zyWSF$+w-DXn&*_PlY8Qk>HYg_eoD^!0gR&!VEeD@M#`sokC2hq2g1g*~dK@{Nvpzz^*{1?<cNx2RV+QSpMwlVntM!<s2!_-ItE'
    'YGMv4c~yq~I>%VunQz^LwN$zEiZhKknGW3~JO+ZQSvaaxrJ=FJOea|ivkkbi7BzJqvgYP!29aafo6GDUp3LCZ#}N>4o!AZ0N6@*z'
    '%|rC*YqR388qQaK!9@F8=RGC(WfhSa+6X^Yr+Yg~HFX`d(y`yuV3HbPc=Ly5i1Eheh0^%oId%yT1~O_`zWx4UaJuxaw|k>W=58}w'
    'DST{gA?FrN?;>isN>GMQ2#Z_>X&sIOnM0!HgXZ7+2hv%rJzk(<PU)SSWBGK8&<NgWGY`UY&39UKS&Cc@@sVkd$Eb7|Y6ql6qRhJN'
    'wM;e;k0@~1#vh1&OE(RRy>gNqL2Al%h9GrkU&IeYRJjztZD(0Y?95$HI<8eo#J_M&n*!uYg->AF9;Tu&Ci8l&mJ2gyBtFoNPuo!_'
    'b^mgcuNSStd5Z+ln{d^#Call9Wd9p+jC&<U*Q$y~Qg|`#8Z68+ry3u=$d{4vt(W20d#Hl(X^=2AR)mm~@1`iL926xNwGviXjm*dH'
    '#h%FJ5fqx`s}gE;<rWl<tNCn*%BONwl;S0?oFdezlM9hrUflA_9Ja)(LB<6&l5`$|cBaTE0bO!BnmpW-lcI1QoP&B4oz633bCeEN'
    'l>QYH=xnG|ud0d*46aMla7{pEr6nq&OJrSfMrv36jV`)aic}$+cL^nj1zwb;8F|=2&!E@gP$1L~2be8Z&XOv?;sA8*gAi{>J$Fv3'
    'D~Ry^rL;)wESxNr^*B=TKSNYIMDH8IHc5BtaQY5=(M3nrF@DicN6CXyHQ#|;e@CN7{Yfg2ic=H1b<)kytgtZ|ME!?xau5ByeS0=Z'
    '`e(!L3>4J2Z}q*kNK*o=6I6g-L;`)XaBkup-r=f5)5&PqduVK+5=tu&$AbmxFR&jaILR0QAlk?_<Rf|itAE}nJ@q#RW~jdf4^Y1*'
    '`g2f$)SsZF!xF;5Dn`entv5mgex`=kk0gZv+tTk`YnE<8Q4Cg_dUQ_bSTfpBw;QjI-<*Emxw?+8ULB((X<VQ;WSNi1N#vqJ=oI~b'
    'XjL}ii(ju_oxh2H?p$7BO?cxHqhB3gp1eA}?wnlzblHh?C4r3?i|J?}sFV)8-EP^%xI{Aw@`1O_E&Rtk)1To40^ePqUmu^DMoyhC'
    '-tx`y_36*1zr1D_o%r<i#rfqmHo^dF@%ZK083inuq4ogE|Lk0z2eC_!;*(d$m)I6o?e8gik5?;O&DQqL?%w{vVbblvxd>twkM+9x'
    '>AUO84j~c9{e|tqw1L1~{q+6!r~g49R4Y_S8Dl2<qY?e@^no0Kh@PTLv6?4hF@*qQqCRRS?Kf<qenK1xMVU<!mHIlxh$Mzcrp1_y'
    'DOzUZ-!<V@#r#B!ksLez9(cylh6>XrBcjm$NULGLK_Z|W=SzFMM4x#2M%U{M^e<wwZ2x!yM%-a34mQL_j*KC^zmbnBNn{yJ62n&{'
    '%5=tB@<jXPSTR%+kBUB?WAb>AGV)L+Q5U8{SqvF|&3dxlpR%2y1&#tY^gLk-?}lUZ+s4TdZ7@VOM^si-`>)4#JLP>HmtG{2<&aG1'
    'mgk6NO%gJ5i0H7T5(5D;9yDR>#9v_*wDI55*+hUW5FM-}>)hs}T!*I)dZEgv?KZ|`Q3L@QN$!#v68Ma~m8{)K4)y%Cl-i6dv4qOR'
    'l3=JJ+xco{!tg+WdG6fs*%6vzrLo+gE?98Z7tkd+*Zk}l)U`<us#nIi_hO2h@x(Y+;$1VQwK-xD26lh}a|5NQZfNbN?%-*wr7wka'
    '{}f%?3Y7q?q7E2ysj6K*O{pBm`%`r1dw;6RgY;U?HcJMnsiab@3Kjc==zPK|xLrS}R*uYrnkEY?y}*kKdtm~{<zv!MCbPbw%Ubje'
    '9*lX!=q|92$AE_k#mFm+vCDC_?39g;BEWkpjh-lewD^SoGhU1;kI_G(&x6Wm6v~I69zRoQ+{cR0a_AZ9U(mrlWzn0?D>YMum}mi$'
    'G*+8+IALo#3cN7%Uq=2LtX0L!NIKfm#}<;PCl7U%Z@&HVAOHI+6Q~b;N+e)^%^HS|F@In|xP+9Nm486y8dz%$a6|jfMQe2>$z9OD'
    'pmq}(tiz2Q#$z*@^3-1fXu)Lgx6$k)%g)HG0OIVOQA83}OEwK@N$3r$`)--J>7@b;Kel!n>`qxQKm+lGr1^Y^l`TVmqnV}1WUJ8V'
    'A+DqmL}~u4S2*{&={QxU0u|P*;{2S0&dCwV2gT|m6X62m86~7of%{n4bLmtJzOq7wbu2Is5%!HFRKZD3P()!E&lidyQ6y**3QM8F'
    'GxGFFRX3UN<hnCa!Re#S22uf=@nrV&s-OW)W;qCfLZI5|Z%LNCWezr?9}l-B@bcT{&<h9~7I6iH!}9s_mJw#&l*6m<XC7O%r$0|s'
    'v^;nVax*9}1tr<BU}Q$tdV<Woz{GTxO(a`%@h0_18y`%72H)HGU%9z0F&TQU^Zag1JF7gR0nwdNC`2~-sEh8w-*#d(e91ahP53ys'
    'UZ!ZfDj`q7X2xPEqGfZ*C7f&}c}qhd<rGX*L2r{eT3#_QxgBk3;T!{Zg=8g%W`l9uV!OJZe+~bFF2m@hY+!*5al$Xtk*;w7m3YmH'
    '0`t<LIow=)81MpIhOhu=5<Rj@oS2_cPn27?Q%X`j5lqBJ9l-xO7N-?}3h;S`2qt1$BJEVHN+ZTUYQ;!US$eQ-3^dRk_F?<kWBHp>'
    'Xs{}YSm3>?UB<+zK&!7K@~ABY(ErSw030Wbq`wxZw-(F1m79rK_sT7Z=^~Ua(@u@|y{VpIQ)HbWGsgv80LfjhFSBJnPw}``cEck_'
    '7GLV>A)`L48hYc9jGyQ3mdD)kuL(AMNEx;GixSY`h;eT+0%k{%j~-8C9Mj{BiV<3ER%3_kQ#T&W;@<Ky&f!GjmXD*#1xHVacjvAp'
    'BF_4#wi@7hi`&P{7E9Ka^%GiQ>>{+l^nBg*)zYH`(4D_Na`?56WkF>p1m4wQC%P@OINTg<HgB!GqP~3qCnkHT0nceV3`e?wwvic8'
    '41j8Ub3}dJdTt&03{muy&l2(dI!rMb+O3ZQ8dcs{TbTDdSw?IRu};4isz#KP7t^efQM~`PJiqVq1Sjq;Q52ecW5)6T;G%8aZg>+o'
    '`lIHRzo_o8EcIte(Zix?tFLE}N&sk9Zv5Z!P*iBALsiLRuH+s?OnMpXXXF3F9^X0%Oo!G%z#gxA4k(q7fIyXjt4Bwi;ZyA^7pW8`'
    ';XZt{RZ8ZQO+Ezy)4Wl^QGFr1v=_iqF)^=3ow4JE*%PY<ws}km8PMfeg|k%bz*VLwaeu}~UwxH2H2%%BDR-`pKw||6=bCVD0+YXG'
    'gZPoZj`82jwbU>oONBoGK6jI|uwdwdjtzQwxB6+Wp`2yMC=4@~zv-}Hkx7*+LVjizoG!_0HC9N#p%_a2?z%a6t?i2H{1eOlL8S?C'
    'FFJ1=!o6kbg+py!a=b0r-i+eHwP;WrCMst24mfT5HW1-!t3B*c)R%eYYTOt?&C0-)69uh+QgVHOoMaO5Qhj<l0FP<LZK^^{)p*+A'
    '@2e0_I5hHG-Gjw}&C}WwFrlu+Dz?vuf`lI)cqy4or|6jwd>@#_696;*^m47NoyXXO-f-K^X5;U}X~o<`1e(4)JIjh&oDI9!AeaH5'
    '^zt$9^P<-FB%g#Yd76e!ucL^^;W!N8C<^ll|Aafr<6}8T-%%kaa}LI%$X*4*#*ZS-W_=FDhVht}dzgya0NJAu5@bA+c0W_~+=Qs$'
    'NC%YGQn-O=pG8%wRDLLv>5yw9W_=X#bIPBIylrO2wPuu1x>;Dx2K_B__OMJN+NF)eMQAr2C37I3drB+%aX8*?iH!RA?mqb>O<1ky'
    'tFQ1@pQ<bC(p@%@AQ4#<f?ZftB3BovY%r-DDT@WP;xBHFwr^{AcW<w|9k5kV6l--O?+h#AK3_s0eo*Rn%+|qQu_vm_hh74>wwu`x'
    'p(WuKUVg3&fwPkcek73JP!G`SU=kw()UV`k6g)w7i$Bib2SvN#6^U*Yc=sr2E7p-^HdQ$n<va!#Y0YuW(ITm{Uhew1OTdwCaO~hU'
    'j7E*J(t@Wo!J=!g8yo1`a-Q_Fxn)G>E)wBhsRu!5Il}^Tu5Q<(X0smc3UNp_EGKNq5GBpm3#3tJ-EISD3(3+1q8Y$YNl-qotpJc*'
    '<q#m^)ha;99CIrS&*|@vf+0ZkK~StFxgc>tA{RWmW6W^1`kRVVY*P1?B6F_-B_~KqNt#T$R+~O7S%){=(&0;{5-K4@=l2*Cp=+y1'
    'Uh+!0tmwtp%2rBhD`3PmgUUl))!HIPdh0V%dQs<R5<7!(4xPsk%f)_jBzjtTYH))tyk2!X_DW<`r;PWQZ60m7__72dTmYnFj&HfE'
    'l7n--z)!kvTYR$j!>O|BP({$%Q81WZg<Q)1D@f7?038mRFIj6?)A8ayC0~hnF-|@}D`Kx+wyV#T3OUtQrDvgf)mTg^-0-t>w89p7'
    'mo1OR49MomOQ?%JZ}{tgE%vsN^!wGqMy*@lL|<^30?Uz&lI#v`@5w+}?VV1&oU_<eTghF!Z?UyBVCD7iP&Gcp2x8heYRT(|f7)5;'
    'j+oaKZqkf{;%8O&f>AZIrhU?|cZt4!dng;Inmb*}9_0lh+u8HV$bDm~h~Y#~D(<9MeMy)`A~i}*Ay9r5s~p^bNn^q!ZQZE(H}Ljq'
    'gg#lBKmwN=#*~l4xYiaMAJ)Z;xx@|J-<F0gXt(EwjDp~^?MV&0i3*kATjtBIYneRjLfToniM%NQ5x^Jvxt)_cK+y%%Y$7-fRf|K8'
    'C|yN5s^bSY;*mJegljG3L<;!UCLi@)6k7(pLh$Q`5Sc)omswZfFT4q*cjO?l;%vxS$lsQQ?x@-a^^3L{xOfC|e(|pz*RIzrhF#)c'
    'N+XATOI4Ug@=>nWqPbT^+ojG>H5m+GOHh0ft<_LnWCGaYUGz<~h3JsKzK&Yaw}cz)r$9KO5aThw?~~BL5Dko_l+_rpn;Qv+8RM3u'
    'nE9M!4+;Br>&dY1{0^}1gkay>c{1z=zXR+C0oZBV^kU38KYmv{3%1kq=J9R2+$6+su04F*k13lsW~=!B+k5k`Mvi1*^mqP>8o%?N'
    'BwMI~ZZAVy{w@aEW`>5oK)XG+&8aS=0%}^QbhSV;9)ExPizWA^swBX(oS8GWQB_uEWMpJyL}V<WYpR~Q8cm^)QFNM+9pDW=eA2^A'
    '5ABQAFP}CxTJrO*9zkth`~;@3G_2B<+r%^Ub#5|+V5mfG&w*%^iHygenG0n20z2WBvARW)Arex99FgCAn~3x{G`sCB(w;6_um7i2'
    'HJjoFv#dI|P<bkruCKRvH~DHq7YtM_zQw>oIjDNPtsCIxV@TfY<HFM7E(_5BIz!>u>{V5^lnk^>&FE}+{^G^Pi>g6PgBk`#EG84v'
    'Q*FkPy&z&N#*77P4CIE~uoQmY(l6O>xcQagSz-42Ef);4AAXmZC9DI)XSQ~bBw@iKw*trwweRJ-FC35!{za*kH2kt1A@s|w=T%^-'
    'KCko4uf<G9aCs?S&TOhOAX5ZJ6o4i<YAX1&)pYBH?GAZwELEuM&5dt5E-n}Wune19iK)@(^{FJGdLPaERQffTkZf+b&X=+syu{#p'
    'JXB)qwHiQ@Y69R`y}N`e!Ln)e^W?=w({oRJ83D*CYv{PyS)&@GDBk3P$=@S*I(Vm;auz<hJvDKt^R?r(26cCe_h#V_Hn%#ayj<0{'
    '-2BQaT2eZZNb9W)OOY`@_(G2q#Qaj&H&;LwTxvUWCrQ6;qOYq!=yXlkjOU#-QL_Sozs&@%Zo{7>j&yb0e1FrHu;h$yGbx&gy}400'
    'MI0xnKXYFW>+u`{vDFuez$=O`&IetM>`twRU=$ov?!V2<s_`O)u3cu1a~5_JAN!NJfo^t|<7M<FhO_SrB+wkq&it7S^U*v@_=EMt'
    'fYI`1#5P~35D^JSxE`3EoFp+Z0qB8x>bPbB{RNlPTy5zEo{jXx8|RuVwP}f%g%*=p_97~Uf1L-ojnAzmzxl??nC0zm*fOCV|H9ld'
    'BKMrI+=RA`2sayL_xX^sLd0`}*~McdlX|`-Rua45oA|8_b0Kh8yvE<)+erS5e#%WLA{mUtFrT{v)vcV!Q)Stj{2feARe*%hHfmcf'
    '1+#FcD<S@Wp8!6#bz0jNcp-3*jE(Ue4_x6yPLMr&=7Q#M8AW|IKQ)NY`M&FQX!WNm$;q3j08w5R`Dlp8C>!(mr-Iu>GECt`rxVN~'
    'iIzAXFu*%4Y++2OpJOt=$qFu?!Ng1dS&z-U;`<e_Xb;{A@k5**sXgvM+uq1uIQ^YRiYTr`imGPuG|xU-PmxGd+R(CQ+~&Er|HYf<'
    '=YB{6x1t1T+-T!G`TvstyV>L<YzVkBj!{yM2ipu_O5WniO4@Ro!9}v#erxC!Pp|?8zU^_>jd4ReMSl2*h@~z=gfGYH)K^B8mCAi{'
    'Q`hXjqk`cnZriFW7^;ox1hNOC*K6lb<40*qBGpJXLrK9pb+-UULL0v7A*W<<EkI2Fk$|MWRC)32Cil)h%^{aQuNGtdu`e50_eDG>'
    'Gjj<NM_2wWSg)3wHf3Ep*tFb||MVL^x5FtM@g_2sl5a%xf7ca@f&=TXC`*<dY%%7PUeoe!W~Sm$ew3ymj`LA9w9h#PI`hWDi3M#K'
    '|0y69X2W3ZYaI`-N<i2;v<`=_34~Xn9>N)q7lFJy5SNx;hXq(j=;rVTjvMA62TK<#OLa~CEBRW<fRmOPLPKc|DrvnAj%6bA0}|Y&'
    'PTJM>@Zs!xX-lTgF&UT3f&ytZOsWuXJZZX?yVT)8I2X+Lde#QZyyJ8X-7e(bMYl|aB)BBbf!ll+wC^jv`3F9rjWa<<dIVWCzc!e('
    'cwn&Uj>o4Po#stYr_mQ?&N`BC#<`V@XlZ`fz*1lX;sr_v&j{w)atOV>VCT#+wJT_Aq8O2?HX&eDO`0X6vw>3~f_@4*+3z_;K_ILk'
    'v$14=lBRAiS(TiM{7{=@B`?$Xl#kehVU*om3^Q?!%^MnrqCYmxyk!+0RStLcupUaFXGmH4L~l#Z63>VwTlA(Xu9$MHty{o0DLGzS'
    'Z`_jH=J}_2uoifii_g#ctr_KlZZ)U}?g|=B%afb6z!4y;40*6Fcp|>&jbwpsGpE`A(|U@6;nCvWRTaIh65}$*qdM7SC}mycZ5g3b'
    'eb`l&Ca<n89`7l%oh#~ztK^z&lY7t<n@+DTNK+LNx56_cofT#pI|`bz-K6cB<GS?u`|25<*Og9J&i%n~$|gt&I9HqOLS>f|ksBhj'
    'loPjMXQ#@uk&=D|^C%~&4(1qK=Qmk6hBzENEJHVf;@o}e*LG>yOjyKv0DhlurEvJOj9(GrA>j>YYsyE%fY-6~LFd`=a)^B2OU1y}'
    'hm#{JkmW>SXcos&Kah2O?MDs=V`wYZ<-97u&;JUO33`J%bcT|nKBH=~5n%lbAoCfJyDED=5&ly~^&01sc=4bJB6O#ns%q!DSvPrf'
    '+=V^SJg;$os<!K(E+-@=(x3<B&u4v1!hZZCv0urd%_(FgbOVx08!xk4-Cn(|h@g){=X@_=v*M$z7O`MnACOr5j2*|1LAjJd&O96f'
    'Cy&#A>=1IBH9;#)%ONY~W;)<QaO*(C2fyhGwLF|#LS)mYnY#_-aitm{DpFGtP(jcs20_yUH?WWLxKWzIU>ZIFhGPyXMRq{W1MjB5'
    'qEBRiiK+IspJt*un==DO!je1Ewv~gy9(UUe7mon4t<pI>bNf-?ZChpR!@vT%{2~j#HAwHm;L;2u0hI#r#*&_U=8r&|=-8FH{(zuT'
    'DZ#5wEpiJ`y!wc;L1K>Uv1JDneEl~+`3HU(p0(=pz3Nd<Tc<G&3ViXdL%mw+li7f*TO^9wSqB0MCymdVWu1%y3DQmo3Ndly#W;Lm'
    'JhRF2xUo5iwfJ`UWQgC{aoE4MteOuZDw%L?Q$RTAQaME05Yg_pJKm0mS{h?+^TlzM)>Huq@f(r0i2la%ak{EGC9;+Bx)Jz_Cz+qJ'
    'sINsSVj-em`a9IGkpGQzH<5k=yvG1v@pby+y~jh(yNP&XFwgVfOlivK=i9!4lpaw){7}{3Int;&^KHOf=4=9{xUmhG(GLKov04Y1'
    '{>}jm`qk5WAH&#r&rOM<*#w;+)fkB;RjLT1&~tkqL)UpvmM9H`C)W$te#WP8yv0&LnkyHB&(B2EM4OKSSIy+9ynSL3F-XI0kL6m1'
    'A^u1xU{#t9HB{4l$gvQf9vu%lyPZLRegB*?V<q);JDn!SgD8@=G<xGbipBxo@Tw`rIK0X&Y-B$+Eu4|>+-!enjWbY_{9Qjmj_f4z'
    'u8iQfj}eI);hifiGFJS)YooCv`DFu3){Bm=x(nZQT9M+xd#Lce(i2=OS*nAYWaj}hQ^>Wij#la0yTM>(T_4Qm&9_)d$NqM1-_a8r'
    '?1trtZdeTH>fAXzfvx}}Qg`h%m#O+Wa}iZ-M1Lz0(MZ0PT#V8vz4%Pa5vm%c%vhABvr!4?NT~)~$mr-=A?O)OEi--#L~ZUI`HV|R'
    '@^6uffeV%Kqft5dNPlpFxR&9{nZmjk^E8E}9bI-4uPC=?$sl0hxebY`#4Uz3XahU$xpT!3Ec=Pm-Zj$oT}Yhv1eWp^q+cDkOB-a>'
    '*m)lMOyJkPrsmi7ywUg1df>FimB4{zamn7vVX5k?>t>>mpLEWoxBoSnmXmxszgKJLV33y3ulEwff2>Of7nNN)ZDU>9_;7oKt#NR3'
    'BhqS0AlEO-1t#U<`g`bYC-{Y^zK7BPjHvdN?=ciunjT+wv`t55(SoE4u>-7veRP4TDrERY1JC{HYVv#cB;a6gESQS*tcn@mEMFG+'
    'v~5?dk{#%pSDl*hZfl+~PcCce9L%7grr_4t5r*7GNQxCyRP1vdDW2961DBIhRaunva8(sWzv`m3(0EcByUB|uFn3U`dxPN6vMjjZ'
    'j+Q5&kZY-13l$n;4g{7|TML4-dT>%^qfvQ>Vu=R~0TB$%cl?{ifV(z%A6ULtCa*+y3ycuQB*-WdvWTrpO?J#13fDtwwYde%+Nxs&'
    'uuq-$wDKT8GOZIHJUq3P;GwI6#W;v*PA}l3C?N2RJOv&wX4Jn>S%iE4%2E8L=F?enf?-|9;RrN<5e|hj7TxexjP7|OVB5~`$Q#?O'
    'VJ$W`ef1J36yDQl38oxuzQwH#8Dde@`;zG$%?b=pt0_)JC3W1O;*#R2c3yCqDo9c9n)iVnb8g1E<yT1TQ#!l3T&;iHR|e|PB6BCe'
    '!$<e}%tj|DtV_9fc*sKH%j9F8Pm)1denfE#u{k1<IR8iT^LiGl#xx|q?Lf>%g(zgj01SuPIm@^sF3~lBUK$_Yw<2t}ob{wG*#h;~'
    'yG*r4spk{cm}xdC0tvg6PaMeIAs5Y{BfeL4B#5A}4<rvHUGJ<J8Tplhj{1=#OA;bpMfNI0#|iY>qroEHn8B&Z|8ZwMqONu)*sLBZ'
    '?Z7#kEw@-|4|_SHVmb>?b*(Y=x&olwCW<@QXYKF2frD!kR2r+dxugviXe<sLUM|gY>pP~Ig_8J%`L_7mQm8}K<%RsEP7c1j;OHoy'
    'Z8WLf=+|&;PQ#I<lRmTQ;2PubEOP^InkOM7CTV*L<VfmsuDfeMdJ`ru_(tDv``)a)Q_D7LSVl8;!LyO<F~S{ah%jr2N8be*M{iP2'
    '{F9M^h|vPSeZO(;iZCLikQ`lS^R}_qI%}~FsaUnydb>H&js5y0h?n$EL)0N2w`c@Ri5w8yZpvG;vTvn{OMdn^OXS#{D9qI`66R>&'
    '6jnmlwijiF#vx<%^~o?e!V08lH=)0}u$b8(zsLq3-9h9E8vRW3i2}*;Y&XVkeJfULU98qR9t_{L%<NPocoQ3zIp~CaNqL^m$pE=w'
    'Sgtt@mhDK+Y3GFUKUPL6FSBG&wKPV)cgike#YL%DdQ}&nrr=^#2~3OtI(_@<)xppEr_OdXaihvLV*WU@7`D+ytb$><vI7>n$!u|X'
    'S$qoE;tT}^y;fv|n+U6ty}aLEr@W2SOXplPnTBeqt?6)?IdOM7U!{4xWu-%%yUekeNtY!vMBLu<RvR63FK&Gqs%7kiUUhqcU_4W;'
    'tCChvS9XIhx&|cDQCq0Ev<c{TM44;#jdE9dD`4UC^n`o^Wn3byL)1K~ZR29M2*3GgvTx-wC6?3la10kLQJYXGwe>lwEz7NTa5TQB'
    'i&FhY!c!OFA-#Fs;_*h$UBW;kqb~JQF6KxF<m6zPbVu^q%ya~W$CL1Ynueu2Qj02MI32;`o)9V>XGN<a3^W-5yQYiDE*I{zI0z4d'
    'CSUQV2tQGD)QhTw705sXj9=ld6&hNFyR>B88sP~0+ft*s_v#vhoDvzC2@m)MM{FwqxPVB@3fq)8>?+%k#s`}|y%WPsGa|#aj7xbF'
    'mZqf>rAbzFXYx#{7-@BR9)iSJUU60J^tnV4M?sE#ULDS_;6d1Ty_b<)I;|{U1*`QEWhMEz0F)?Jsv@yS@A99+99%#`M`x=y@uG9}'
    'fL+-=x9chkrK8maCCN+kz9bbhASdG9U;=D%{jM0N+0F2)7tl8)%kO0u#dGxo{~IxeG@P6}dM9r5aOdlO3IM4`5hW(9$e@xarXITy'
    'sMrlCm6@`LGixc0bizx&<dD)z-L(Y+?ki~U_Rm*k>h9~_fSFzu<Gz1n>OfD)wlUHZd3UG7OVP)Fneg=WpKPHZ`*dGAW?E+EzJVsX'
    'tmqs0hdDD;UuR%;Q7GZpY-G0NT}O6vQCuy`#mpfX(c61D0*a)3<zdK3^0J<#p^HT^Qg<MfcPA_cu_GEMOLZlkWko8>4a~V%S;hB@'
    '@*!0rRf@rZ>*i(^h38%sS5*YpyjQlRPgPa86DfG>_yUTe!I}=6QiW)qatDqxs#tYVLgUS}{B(atiEBZYmDxt*9K>PVQK>pqSt=1{'
    'eKpM{*KH+{jO8ZaMHjj4Y4ez>kLOt<a5)L8mTK>b@*lJwZkN8?ptVxeIb~&suzVp0es7HBs&EF#vZkPGa`mFH)<RVR+>W?9fY-f9'
    '-azHegI`d}L-$RSP$cPG7AY-Zw6wK<yZ((mupU>|uk-SIcnJ^a4u@L@57l-{ozUzW*tBkP%>;vnGd4`PE2@+03qV(`aNz-0UFpJ0'
    'tN$pydn+3;u6XT)o#klf?BJ*U28I@MXL3?-Q+tq`%}y!Pm9$`PI^k9zKUpq85ADNH3T9Q!#Naa0aIe_KB+6Mh<%~#XL~fiqhq#4G'
    '9>+<*VSa2?^On_3(Bl+-I!v`;!i;!55POoU2n>(vPZIYhwfTeLt;j>^2`!PJ#DRuSh=iwV9v3q6a6V40HX`=qp6mc3<C(F1ZHIGX'
    'CePZ1ROY9MwXelRnC)2_AoKt*I2N<TXx@(GAQ7;<Kkuj%zAmJCdE7;jPJ8yDW~Dj9^m|{ZTrR%WZ23e7(+HXKxe|%zn&s(nJe|?I'
    'a#-F4Zvc$-q$)+ei%MKQL8>8{AOvYQX?KF2NaC|lj@nvUU5r7rEJwHbFfFH^a827)ljk4$9(HT+6x^aDU(v;{bH$<=fthdSb0g)9'
    '<K8N)$8JG)RW+@fSS2@&=aD27UE!uE%WG?o$B?u5PeMdYvV>zo75hjQD2B4<jD}A6&M03<y6frjZO4ZX=GY%T;Gvia$MbBMP0$sG'
    'uTG0ASVRCud}eMlrK`#NX8GIneE#sEmm~-C<YqCOOCdRv5;Frv_Y}$eI-}&5A}2KV`AmC#kXny69L;NmdNLES?Ckd`3_CbKA!2;^'
    '(1o9NX)TyA_VwX|ea{52QfFt^IeEbV5(sP@36PtOu+w{7=Q)?1Q%j)aZ;5`cI^3o1MhKBzjTlGAGQ_e=<=19-`jez2m!DNZF&q}<'
    '6WJkBPIRObqL^eICuS*<DsWZQgiGIT_W^$ztE6lFG7%z6yo=OqZXOq7YKAK7>N7g_ec3P#$t=1$OoU+xCZe!5W|RR50uB`>RJ5)9'
    '1T4vzQtj~`!tKQRlmHsx#Yhmcw5fpAiXx^#M8M&wf>NUi9D=xV^#MD)K|<$5TRB(r{|o0UWppUWRifQ$bvu~(JmSvA44`lE!#3lG'
    'RXmRP>N-6K4k+x$QTL-YDZ?2-+N;#DZ180ygGqxg>6%)9P<!YqvW%qS7pX?@wyhl_Ld$E20P!41iM~~Kd(Xe1fm2g$MN$Wji1$*x'
    ';}V^GAg!jtIQ*+}c-m%k*e)VGwcm7xFx(o>9ldwWZ;c@%z)i0#|0Pqk*6=T{!tUX#bQ_H6)noZt_u!ujE~CFB4znaOILtl*wRq_u'
    'qp{mv#CB$z%#iPk)T`V63}pJQZGWYIi=06|W7Nu&?{mZiwe5K&smjXgo-U|Ltl~D|*-t~IRk1ik=p$ohtX3F?e}a{Hg)pQBZ2yMw'
    'mA0e$D2P2-qPHT`kr$)bHnZ-t@?ZQ-pE#Cf@K>ke^fn_tRs>iFbr~UaZbV+4K|e_3a6Y$M%MeKu_t3^WMF`)%j?tF+zC6TBw=jmS'
    '({(ZJg=m^-HNOY217^ISJDwV1yWTIi#s{z7|IYG{W+zpxCXx>1DT~>7aE)07jpW%Cx*GmSu(Bb^_(H3q9!T(K6<`2b7JP_-zUYVn'
    'O+j!G;<M1w3_WC!jrppc_F71#z-(sF-cTSIN7zll^Oc$%41`VL`{9Br=p+;znN9Cs(u+}fmrvJ6us9=@lBdF>a3)kY!E<5A1&Z?*'
    '_w*Ts?w5Bc_71LLcc2&59F*p4VyiKvuz(Va_m6Ln&JJGhr>}R84qok_o~5Th?#RGhKZTwAuv4F`NjCLE(DmrBi~nc;<XDW^AORF~'
    'w-^JXNArbS^vucD$IBhc=hZA(A1CU25KI-hKO_#MBDoAgy^5|_Dk?a05(=Dtta<aU4}VLVfV!SEbMN`8YZU3O?i#|nq4eQQ{G5Ue'
    'ix$+28Ek|(jFnp)UzmF;QW!9JDVpP^08Le{)~ZB+-YnIHZy*Dp7}E}ubQ19CS@7+uDfvNHB6-A$z-fi^aey=XYqjdJ9ZC@BCj#)m'
    '_j4v_!U@!jX4+Y{q_wuyc=t-o)BEz2&^y7hwpdrsK`Upa6{xQdetVzvO~ST@>?^~Lg`d8k)4|Z?`(g{h0dRbI$tkaaXr}A(1iQn<'
    '8J1Ux+#4h%;F)r;`TW_z=9kGRTfoxLL3CT>cW^-BsV3cI@H0A|#%1yj1g`RKmh8Ma!0H*J{077zsuj-m!<neggdt3n$a;;PVW^-V'
    'oR&Mu<pNQjpvySc+9ea<0G4Q;^RdZ-t%7K_n9<zHKDh=x-r&|4-OGa=Z4nZvKb05B1<3KxeSs_nM4$z5Vd!>@c)rE<bQb5s?iy^e'
    '^$UzzA@lA99K*L67mj4?WOF3~(9BS%C~?LBC=AqN0Rps``D`u!lurjB>9Co&82^<Gn3vf{44j4W?~`Fkn1SZN_KMlH1N3!vTfinn'
    '#OJEO4=ezDgUkRZA{%nv^BEgV3qvwsA%;K(0fEJjyK7KU*8pOm%3;s9x(d=qL<y8-<9m(v$&@pZ%Y`MW4*Q+q<qRiAoL^7N#np8J'
    'y~2km`e2=u=}ZVkl6-XB@GKD<2;drD7FP=~0D1*x(~ndWQQS$QA)Z%k`s{S?&s_=cOb9<f;giK2ou@#!96&Q5^Xq($pu@6Dx*itU'
    ')wrC^0fDo{V36mq^1U^blz14tr@5AYmoxbnfk+Z28sjL_3|?{ZOZBMB<;%DsUVy76uA7Q#f}|$e?1}@ht8X%-t9&<sFX!c;guhPF'
    'CI^RMH#tLXVT}rU93LL02S;c7CqL~Rrl<S6$47go=<v|n`qFfHL0c7?^RbL+`BBydvBYehKT>Anuq%sTDhynHY$qS9nq9qOMn#$0'
    '{0t`4ZV#?A<S_XZUyjC$8%~|19;05;>ZR+PlgoO{-K*3-$H>FJXD+de`~l`cp>S=X8<=ICU`b`0ggO07W<sJEEzO@Oib`8guHhwd'
    '!*T?q2E>mX8Lt5;&^eZC2S%8|fx}l-pA#20@w=^q9kA99Cpq+k=9Iex^%kmw!fy=pO5sSoFk=ilu1^RuB3<~Z-J;VV6%02W2t1|S'
    'S){_LJu@rormCeDp)%+9vhX>d2kXm@E_)0;3kUFr`_cx#?@mZJUrZ2(J+;zeRV*reCk{|SjcvI-HSrxtmM@PCF`JjJDk!<Wp)3m5'
    'Y;+5>sgF;^RGokTV*1zeLJ*^1?b}J~6{^4l=q^8NiDI67WTfg8*-kD;WyU+dMIXT7a|+<1*RGW@U{@c={z=?TjAIy(R9vA_Ixp#r'
    '#G`Rdb+u#8-H{jQ7-FiPEpBp&DMBBNm+PBN*T@2g9CA|8_!*v{dNTuc@@bAD0|9qKmNGm`h>^mPp{ymqD)=T=zGjc%L4lvZjEH0K'
    '$qK>`A3eY-vPq6-D)Mk`>!A6-ByM1Rkj-2uVM89&bau*Rc`37O2;)OO297w;ZUj;Sq1;TwEi)xFk=&w<8=1Uz1E~zLCP=3+wgt`<'
    'kaLMNCmJi1-Q{@t5B_&iOetNO6<EAY`(XP+lpTNQB?ny20^m^FOmJM5hb|LcKXFu!uhvI&cYa->90FJ?;hY|0mZ4;x(N}k4kOi)b'
    '$;+g~BmE9J#$c2~qs0U<xn??F&>YC|Fr&4~i>c`K9%b_ptmYh`04heIV|s%kfI;eJt_>2ZWuIc7&3J!o`#Z*tZ$p-E?V)`-QWEW#'
    '5hqxAbFbhg>>2y$L^eRFHNTkvMU;~aM1w@11dME6;>^HvSM`DjmnI~IcC@atb^#*LB^$~loe3`0nk6I9Z1B*<RnjC%s|6D;QG}L@'
    '#=YbcaY}l2$gYPXsa{A0k8ou`gBbF55D_rZ7*C6UL%yS~_(kP97HPB(8xZucfPFeefsbTg15b+a2*n0vO|(>_=@j%$hI7q{1eZ(j'
    ';R7CmA3ktvB+NThFXY0B&3r-g6x60ogd%6g)L?*s86Y!*S@4kog7R1!CMhk81D7TsGFLK!n2^|Eh58XI*_x4#0Y{@v`o<xr2|IAU'
    '9c5FbWmITrIYgMfr%)RD12b~W%B+&dNL`l?Hc@7p-oUYzYG$2E25v}H6f<h>RXj6NIi8Lwwlktr@*6r`jLo6kL5lG@ZAHP(?9+Er'
    'jz+3~4uPhkS85~$nqAaeCsoQYuM#Sv@EIOEnszvyfrT&<whN@}0mXdyupo|T>jyv}?1W%|`3Zhu9)Kn!DBaBsx|O)MAy73xl>|}`'
    '0C^LzB1(9ceZUtlCCjq`F?Mu;`G-D^fvdy-QEMZ}su5JD^Kt_Folw25Z3}uCE`@MIdbuG#++_$*7&+5iWE3z@ju<tv8->jEVvwbn'
    '#yZgq@;86&c-a3^Drg%N%fIDgu1qR6vnLH|AyuVq%%)ej&jxqHXZiTH0PamQoQ<=|>{{H{qoA*mGQKSbdW$fJy}I3Iom3~C;`@iY'
    'A!$f#tQ+4dS3O+?HL757uTtlI&lOW;huuhT6)G0?*O5V`T;;G!`7D$jnnrA-p9pz7#V-O%$)KD7OQE;whLnb1bIN+R1I0TH-H%Nx'
    'R66+6#zspi#<VK@S1~q6YpP$>z%Nk-*badOk8PmD15yOb8E1jVOw%*!VM&<alQ2lmjQ|jUz6w}w2!qn&s|Ss=hqiP94!R#075*r5'
    '#BDSNn6L`XU985*pv_1Ay+|3|Cw%MQY6$|5xW7oUpp~)1lO7Gp;|{ACMrv?lSRgl}>`eLiDFDHK$!~&(>Nv6eavlAWgCu;BoCw<f'
    'jISgV=V{@#z;F&@V>S2+2)9KXs!3z^7xZG-G|XuHs%GxQ*Wd6#u`dpV?XYa+NKVU0S)`}Q)0HKynnolZHS14FQror!Ww$b9g;e<^'
    '8UkamA!-JxGW14KP}jHHreU{qR97QGC>)4=eMU;DAyr-~p--!AjTjb+#^^St*b(K;8_|+9ZJijkd(r-*0hJCAAgH`#1x!e2Y}da5'
    't$gMg+Gje|GqCP?u4il5P+3BdR2-yj%bYDOCrjJ0u|oWK-j&ubl&x;~yt+j3BX83S(VX8~kCN}uxV~Y<lctnG9{&7Ypn=hoZxaiq'
    'Z~IB~GC)8IN@U9HRbBzMmDSJ_6Uk;M)Wz+f-Lt}^h>}=2Nki`yol--#igy#EfxHQM|NdMc<-CukhMsBzy^lZxHk)!gzBd-lsSU`G'
    '7wD&G>}v&pHITJ^&LvoU6()Gza-WhAztWea-AQtSV*?n%a3&Djhn4@5m70p}dWu%;TRd4aEw!WSon%*db2}$_p0EFe0Z833$~6<#'
    'rX5g0rTNFY6-Ap0Vik>qXc`4o(Y!(xSB#|3++_vZVz5Xva*Rs=iA}(0@6s2fv}Aa-H_=8?oqFzKF}%v@(pZGY_~ga0HTc<eHXSAe'
    '^rbcvbrY_%i@lNka52#_DC%<P!-oj*LhtAen%tFmIhk-hAe=^?O-BV?HFAUlnI31#+)IWsK#|f_2|`jRwRIY`ZaOl00Dwt6A3iYa'
    'Sd5YD4y0*E*^{KbobKiL>Xsehrm)UL{ZtZ07+{dNUb4zIz9*#M>Lv%zj@kaSnC03w?Gr_^Coi7!Pm^MLFJ0BRM=~qpEixPhW1+(9'
    'gEOI($4dgo^7@t)du4d(8j5z8Y$jc;{C3SQyO@u1@KG=Xwrr|wvFkz)*T#H4qVB19FD)~yMZbju<ipknvRp&w(*;q2m=hse+Abx8'
    'u$hXhE8JAZ^l$<A-Y@|{4}sN}{hWD@F8uMf0469LSJ=ZqdM~n>&vxKbni%tCr5!{R`zBJg+_z30U*}l$H$bO;2=$R)jV8RQD(?~%'
    'ERl~%-{E60+TuIWAn>lieC%$6K7U>;$%Q;0Taha}6<<<6zPtuqc4X)B;?YO6m%w^Odr@CfyYf-+cxwU}ZS_F?Ci{R7)00lKZMSYR'
    'E`LIS{r>2dgitfK)wa=6m><L-Fwcs*$s0`@&D>}o9A3F0_2ZjNNd3k(q8t^{f2oo&&^#!pp?Z@G>4IrW0TZS)5u48p-ADyiqcNLJ'
    '<t2Ajn~0ulHi@aeUYnQ_X*Se`aJ?1GG?n^&RCP7G^Aze>zk!C022d(;RU=OqwuY|NfptH`I@lA)F3Kb?k48vbQZsd2dt5cWTK+cl'
    'yg(ZsrBDBs!}R$-T_vdWL%MI<A<(|_yBo9T^d-4=Ju6OM{I?r1-Sn+r-GJ4mum0-RSZn%KB-L$V!Rc4gS~qUX=?4d_HtY1GL)dnm'
    'zItTQN#FRp>yvTcd*XSI^*z5SO|T#>rzC&pSc=fQR{}i@=sg=*WM7drNTyH|+_X&w4#{QRTtSgQqrfgxX>^@|?9|jsze`!a;|UQ1'
    'fAEa5PiQI8c8X-(oMq?nrv{^$waLuG>Z#Yu8tthUP0flqS391*+Z5f*$bAY9GKc0&tBw+Z;N#9~ne-x~(xoV;A&5BNgoQ*u)uWq#'
    'If8wC3Oc>Em!T*dL8go;LKAHN%cTL=ZlzMxH63`>Q^#r7d~Q0G2FFv4*QzGv_>~%0_tR`VyUeFbNdZQevI5->-<I#pKAK)EWK+pL'
    '=E~bfnLngk&~RE#NYiI=4^(`!aFO13wcL2ks$#*iV{j=#5{s8@R-j2sGC@j{zN%ujJ>MUV;8=#}WS1_bL|k|I;PKYp@ujs96hlHK'
    'V`+>%e{}b?Myye@giL*L0q^r}Le7?g`uOfgT$|L&dWwpIQbs_G@V{JAGOFy$kjEV1&5=|rJU<D23%R-_9Ct8=%#v9tUofsoYP67l'
    '8X4$>_=@ZS=74-xIvE3q7X2Wnw_7{(A5>;M(hNpI2e41B0EDcb?GP0VlCId7@%}B``kABu#V6E2(`+`Esyz~%l;<tB$_#5pwWi8G'
    'emI*3QTKAwYCX%CM9dSh6G~?h=*h4VMe~J|=-_{=jL*e*9?uRQgx*{C`ocPvjReb}dHq&@ru_Z`RAj?RUUd$JwSQ$0u?~i?Az{ZB'
    'TFn2c4y~!+gB3{6D?5jIYDf3!a4Na7jRL_b*(m68RD7tRvzmq|TQtxn-cWzSvVe{0Am#47Q96F+LwhF6)QjT#9&^Kcu9(phQZ@K?'
    '`nN?lOHvnY#QefNRok@!-BzAzF8=UHr5sJ-W{V4On>K^^_krUZuP=w_IMC|)il0ojRYa?m`8`_3ulf$+(u8C1GD14Sl7yz93e97!'
    '`S{}VR8m<Z0LUv&3!8j>Qn@w{0oTQK7$&p6n{SZuDoCr=-;yIt!-5Inx{r8S)CLyQmWKMS?!U8=*zrh<D}7{AbYI|W1iTpzEp2fb'
    'TS66<*z!yu@^*&`p2X}SuKCFRXe}}es(FJg2w1iD=Htk<Y~>VIvgNR|MEb-Nv1m(Q?nu=+7CJeQzE1v~QeQr@(o96d-snc(uFNSl'
    'RC?U2FeogceK*ytD^+w~;%cIIhqsBGT#&s~Z`jobU0RKl!iaStW|E9^mtx9-_8U(tHJV25UmBo7%v2gGD$h9Ct=_^UiaK!W%=;jZ'
    '8V*2ehT^p?qg24*q1-&|^kuZ6nJ?9S#Zg|*W9?om<&_oqo^R}4j^9ZWb`yAIxOts-!FJqiIME&hY6@0AtC*=nOBVN02$h8J!HVjk'
    'nxvgiLXjw5qd=a7P@9UB2{9}NXY87{n<3AinjPj6l?PWK_ND~?q(r|A;oB*n6zkSHogM4hX~bY<FY1ITE=?V^o>>W^#=OM#E&6|$'
    'Rkb5h6|X8OAD6w&%zhr1R|Wi;f~?Ais-9PQ-vpVJ*DA!VLXGO!RS1!xS+B^h{Mr47UnwkvOuOdYCn?q8TkFsrbv41o7s>qoKg(ld'
    '!Q(s+w6H&j8QDF168#F6`&BLW4+C;Z`+TiUzM51YK(0~ilWCG~Wc+Vtf-<`em71-YCA9GD<Y9|#)D*tDIea;jcq6m;Ql|0c&Et=6'
    'vR=-F_yjiM2hzGrK)!HWFXUoU(tJG3#+2+ByOTB+SJ<u2AHFmZHY2`DqH~BXKK+06ML;ul_du$4dJ&gGE{lhr70tB5ojr*t(eUb_'
    '_S#{^;XR^ldLi*3383n3!Mq$20orMbzR4-pHwtF=Yemh{>ZRjMuAbXoO)btB?L-N;&OiI?v+qSPBNnV1u1|_dE|RYDCZZ&!Ty8jr'
    'zhuT$PLT(k<0_wtY_^=CU&K(}O)=PW%6V!rE7<L3ayiA=!x>QKO@`^~5IY!`iGo9cDfy_kwb?a>pi+P-rwS}?@!nGfT`H*H%}s$x'
    'lsFu(n9BNP<wy=QTf@F&aT6JPS`b`zp|)8s*)ft3^ZW`C>xmADc-*rm7DZsL%VZ@9p$t04Suy}JCi7sAZfHdkE#bt-+E#DvsMJ{y'
    'MUo((jM>ac7o`dcIEk7C>zn3R1*jfVN`Qz-`8Z#y&OFAM6$jars;gkgjX>g>$~~U^>Gb$WtPH|>1=yWa256a<7xa$-)hVTfQaUy^'
    'Tg<P^X)(X&M7tE~n5LZd8Aw{Bzom3j99b;0?hYu2uKe{^OzK&grFWXkzh?OW_MUnH`uAcm_mlY!tR%g6unTFx)$;f5jPJWuNqpDd'
    '9K6|2k9J<~r*BU7Umg66`uQ*LzuqsuAZ7gW3vOQ^T0rGG?4I=#;8{rA@W&u8CiC^%&GpvWyW^8T@1LZnyFc!~-l1#7`6MkipTj?2'
    'Qet!b1gnZ)j*6@6xzwb1r}l0)TWhaQ5Qb$tpp~cZsd6p#K_zsdi?3cJpC_9eTQBIHfbjV3*_*d#y3KRhhQB@BKl<V9NA>!}T1xo&'
    '{_U$*@UeQl@yD;$(v$t2J@<_Z#TQAS-!GC){QAG&Vy%mVJ@}K(7^=^J<&azNH`f1{tzVx1`h4rRUw-)?IO@`)<D=dEMlDZ6J)W*_'
    'uDAcsHa0*1V!iY0W_R<;-}smKZ2#os80K+u{OA26nl$vVx$#H&;@~(vINCja{pN803}5{bF`!;yMXrORAL#kl^7-rIll^pW=M0x~'
    '>-h`$m=L;qd~~$Gd$zv^@4kHgrS<Onx2J!hPd4RatVj$PI7?q0zdgcFw${>jI|pa!@%Mj%UeXOJqs@=7k_ap^Hu~}#z{c6Z;bFS7'
    'i^Y}c8O&(!?VH1c-JLTaH(Z;Y-QE4uQ|^^UdUtYgrXd#(X|;FG&Q1=#f6HsVxrP1z<!JZEljEa<|6zo^_~y&60W)t-j<M4e*7)Qv'
    '>EXd^=y4A)`0DuN_0HJ=@GMD1)cLE!ogdQUpY~4<ciy}qq-<_{{ru|}o8JIs8ckjuoB+uXmJW_i&vt+&5P@4Sw!ZmBkSfmxUVkre'
    'wJBbl{RRH@8s6>vuy2qy&g=E@p80A^yh403W<^Uv_R0S1V?fXD;lcjV8R7v(J_Z6v_kTVBY!ekc7eFg~!Ro=p4<*)q+&S8lb2>Qs'
    'asPw{0!Ux&z-N0%9;as~Z+FjN@pqx|(f;A-Hf2P6&-qKvxu&8>5%Z3i!7(wDT{w-#`H161b?B(h5qXjiGm-Yb7_C$BAoEnlz->BC'
    '_y)OQp6#XcXT#>ioC8#l0=99s{<m}d7wpLN{MU`{SI>Xb)}mN&g*2yH%rqS^0=#gI>U7l6{L(aUUF&034BPOJl}9EJ-eP2zO!Q$r'
    '&p%Oda9~k5IqU$BDpdqH8G~ps#pFDbd<25=l}^tiu?b_ls1zK}z^80vBh8IQ!7^x6w5=HSW|L6?I>>sf^L}&t+>9)Lj#53<Nyp}t'
    '&t~&$y12&QSR(olumqc}_&745p6moe|3L(mrgwM}GPd*MVQ~d;bvmL>*_1K_G9;b)5$OZ0p*)|W*1)4L-<SLpt6(GW?ak!dZ<80_'
    'z~U#H3DvWL!PEe%#q%w0;f?oxYx}%vOc}0oy554r5>|z)&M~ZJb|X~$1@%j^ht<Ro6cWi(gHkai2d2wTUFy|DA_e)rNASA4j)>bW'
    'xS*cXP!D00v*u2Xf~4YWpFk<xJ<80SeJ*Pt2Qpg7dGy6l4<2Gr!gl0j(k}WHZczJiu@ymdaao1oCqRtL#ZYPwCB(vNkK3WUUZO|*'
    'syAHROlJITH^JJ1SfFS|3Na?(rfMYRbk=XTx~R2ow>p>*6wC0Ww8uqDkjTrsbexSvI8P6>Uo_>ns8J(7rRA{lSF4Bur*@$Y$GBl`'
    'oDLV5h@2`qXP_pw>EGhyo$D;B;t=MXro&<|w;pdR-=@)g+kdT7SNa($c|7wBh4)+}(2j0e9szo4&}FM*UBQp$ejY~4JSDKi1yeO0'
    '@r>F|@pxA*h#*J_2-%(XilSnwvc5)k#|h)d+~zx1y=Y7eQ7;BOkx?4R?s{B9+$KO#=5K*Kk*I%EX24$YD>)e^l=QkRKlUS3)J+85'
    'O0qf3`y)8<hZ!*u+=1<sC?TbsbDd5P3-;W#S0n6>wR2*9IEZ`rW|NYd-d5%c+v!u097t{n@gpjHhV-<`(h8Dg8fJ=Rw!(UH+eVy6'
    'wR9Dn7BY?TxTJiCl8O!H=)~}*0h!EFZw=AR`Q#ydUU%gmfdn2+z=KR`(gskv;X~k|ULv4)nD=))Zu3Ah-t+<M#j0SA(CVnKu7#_B'
    '*(B*lIh_Zf$`#^_GRf|dSNQ0#Ek9Jvk8PbTB7Mt{wCWVOLuc%Ke4CHT39_<Z<&fKnX?CLYRAkiRwS?F7UwSTS4Ib(rT}SzXm)7s!'
    'grY&Xu*F5%@)9O1mz8WTXhQsa2>WkB0kVD|86|s@Z1Az&`tG3BwP5IgI4=Gc{Dn^q<}Y&5W%Cuei?L8KG86;Eh>xKO$i;JwaU?cH'
    '2j0rtOYSZ6Z>yr7A)_3)Gao<++<OTZDVLUI6m8h5l?^jBra#?QY9iD`|0Zpd_>*pJPxRb6wOBokwyoLCorfXqq8MX>Ob2U%Y-1bC'
    'pHF~p+w|`To`uv$n5&Cd-v(^K4?~HK3K;5Yex3B?9$t)%T}&Um-}WImR|Vi<CZY?x#}vTh&!=TPJgh{LqIbt)&Y(ODU32&dtx8-a'
    'Syst(2r0<W7<+-`J2z>iZypRpF@2UST%B25V+E+srLNCD`|Kz26<;Z0W0=A-`v&Z#b!mt<k)$+<TTI`I_8(&X*Cy83xmZo7O^-^k'
    '73h^9UB2RFg)Lw>QBHi8a*3uxT@*u@O!#)QH%M<w5Zou8vj*jC7kYTlu8QEthpFahd}RHpc~sMeIa%yL7U`NMDu?<Vx((nO0m@*#'
    'o^NgAjcUc5jqb!u;ZRIR8E^&esIwG=3<XKj5(3Ua1W>5+r=0cB`+*G6<9TZdy5lO3Zr<I{gv4at7300b!*)vo1Dka*%Z>R7&ydHq'
    'UP(x^NnwR}`i3lJNz4ZeyxvbS0c~-y02XI2A|3RWt&)=}8dhR?+_U9N+L3h~t;R-Zvs=@GoMu#n03}`b=JD@I_}&qo8+VRuw;m2L'
    'xoB%|`%Qc2<;x%7pO>e9>8QVd{f++K`1I@c#y6jS<0q}&WjVdU+@%3987v=aT@f6{lb#8^!#6)2AMCXQ#FGtgVa1+rVGVPefaIHh'
    'CIS*Jp10^I)K{?gcKOjMkkR<+RFKu4!o*qWKYM5P)yt+=?6=WR-Wy2UeRq0x($#3(18I3rF~~Q^R4t+HV7U`-@b>Wd=!ed^H8ij^'
    'd}*%M_s7SF&SJs>|IKPcUA65D%iLodiLIM#DljhYr}<@D_tlBMp;0<3YXR9{B!WbBaE#bWcn2&OVMlLw0mmsx7>lV{a7e0PxFqe?'
    '_>d0lmb(}*mv(D3@z>XEsn(_4x;PkL=g{&;IxWpch;*?unjgX7ai|el<z?G%(CHd0*G)tb6@yi`^$1<(<TjS6<MK<szgdZERx(NS'
    '(OaN5S|-0+CrNg1XZMiozU;?_iT&5rWtsG?v;6d=6x;Cfsne7>hFIZ$_}zc_-GBJqzahW7oaP3b(+ylUr{8QNJ8}|#3L-HYt;O<3'
    'S`30ba0vz~QO6_p4)N(Lco=9G-c3Iq9`EiPo`>28wg9(wA(UAd+WO<R^NEGPB@`Et=#mi*w2RKIbQc)V9r@g#Qd9cSkV~udy58{a'
    '$KvXG54OV@bk^x6=BvZ<PQ8%}?InglAly}!jhJfmN-LKp2RZ?ss<&bw8Kre}K2&kv#hiw$Xv4tNwSx0vTGs}ZOl&eU$?AuEF5K%8'
    'F*Cbigs#XjFV1u2u$|wn$+-h|6^9qQQZ;Tn^J?46?XqsUs_t{Ol<o^-{oGe-(Hi(UIa@@5;Se%NHw~#*nI;eu#V|}02ScMt6*Zij'
    '?E>hhqr<hOaPztaP@9$9FvU}MmU4DhEef9>i!cSl&q_Q&17Sn<OkkMk+QkQayxEQF5vH3~k*om{@nZVILz_m|DlAw?5kWW6c4H$*'
    'D<HVEbR|X_17v(2WnJ7P=i}j|EU+$hF~7!I_w!;rm@5x8sxx+n735D3_Cf;w(smVfAH;K(mUd^-Mi>1^cYU*G6OFdcQIE}KkY_1K'
    '3U{a^WkO9VoT#I9PNhY_tfnA69>%DWlibjiz10$(<x<QTOhu$u4GzZ|MKa_{jQUbk7MxM^6ox6`9vcdGZ?dRQ6$<$twJ&3KdW7cm'
    'I{(z({OX^;%fwRYtYr*gX-RswF0Z;+t|Fx?qP}yp(vkl6!9jIBcex%g>vcx9cDFa<)4cdKaavS5;V(x@=1s0KGdeoG>BW8eS6p*d'
    'Pg@Oara_>~b@c|V`7S^YaetI7G<=ONCa3WhjyYJ0v4pQ|9>CjG6oa}8LBqLoIpVa0lQf$Yw2|>AHRfktQ@Q2ozs@_oEPYKiP8$rD'
    'OX(t}pLkJqUj(}~rb{5IUrsw?UHS%ELI4D%B{$!L9Np7`m-&29!nzISX?dGZM^qb?1h#Nv4B>0mQjo>O+PiTmMDr!!mUL(8h1+qB'
    'FWku_UjjyIyaa@NDGLhB3^tcphYYDMwwR)}F3yNjg;3Bdg>TsnvjN5&H*e3t$O~xLJ(yKUA`$lTZSLhd@F6lCYNFN9VxO`fd6Zzx'
    '#sVxE0uWu+u4{HUuO{+9LI-}ImzR+@qULO)`Lg;Ws<TGN60vF#Y-9QwB1y&UV0TZEQ^2!!Rb~NhtfgD(X5uF9=VllARWYXf!O7gu'
    'J5=v)ZK&zgA?rJV91~TcfIZ|P;~_}^fpi$lor~y{jt0{bQwUQ^1Ur|AV=(s}$D3tc`1hIgN~1^<ws~KVJ^mMFZz%>h`TV*ZY8lTu'
    'r!9YnI-iFJ_&o%7hlryWz$}wyV<}weqp|Y3#+390L>g)4ekUriY(dh9V{!=7EVRpC+twlDBg^7(?!B!v44H8x(mF(3$&x;~g>9}`'
    '!TDP;!hn|KM@bM7f}#Ouh$wi0xV$LKInZu4k@B)es7Rp@2<Wi`UsVPW68xUMIoPA<rieC=Vss+LvWkHTXx&^7?O$8cN8ONKyGct='
    'U%k?ge(P8zWd+8>u$Yh6owi9`{sEzIVrvS9bZ(QGwu^CJlzPOpw$bAw%;fS0UcC#oU-EYG$$s-S*m)4d&=m|B^6YX}j$|LyxXimP'
    '>o$6ci+f8$?t7X?mA2Mk_|*rt%nvR)I*pYTO5-S>#TmJ3Y^+q<(cHR8Fo}Zn#d6a$SkD8w8Dw`>>V>~2k;Dt~1*KiktpZ6G=stQw'
    '_HL#ip~u!mgkBaW8JpzC_Km5qG`pgUXe?Z9)i1}Hv%S9AVV}+I2MQ>(BJS<CFO3=+uNAvV!KH9Kjz;%EDXjh$*d+JPLuZ3m`7#At'
    '#cV1`T#HP^jV(Dm!iN=;G0_yxC9(YCgwNKPa^aZ@)Y-sN3_6`)3&s1}9^`P?s;>>F8M6q+X{_Xhzy^pNxE<Q`7K3_(cW<jpIO!ls'
    '2eZ@!>ce>2VX%~!P`MW%2Y^D#A+fp24IWdk&{z`9^Y_q&W10yG<WD8r)(oqKE|58lS}3vt9@}~KE$B8Y@UhEJuR81Z1zMOv5aaA-'
    'vw1NZt*c=$6d&<@zg~>j|5RSc)M>(kkf2y)31r66P3kxhoTc!a*>LqsZPjw$x2-Z6Mkp;!2pi~kBpi4AuLReQereo<hO;Bu7KM5N'
    '&R3Jd7uD`EQOty~l(E#3e(p@e<)X&5!yD5DRCN{Pg_Tf<Y$!@%eU}yUSLO5+MCDO_EMjEqoDMcRga#{L)iRinYMw~H=N{p4rOwUA'
    's^av0NwpnmsShMI%$|Jb+>?jCtM)pne-LvQ;rE>ic^z-u-Ph;Uu-4t%3#US~AmAd@=llxz?mL2s3xh{Y&f<4G9Qou{--YeKC_!My'
    'JDi>Hy6bw}qmoWlM?;T9^%yP^jE{UnK;>|=98Q-}c4fIho#w(h@nFn8zC}3>f7OsOgKFV<q{}7*r0jy?BX7kuMqoignbX3{5_YNS'
    '8VK$z#rDG7-RRBc>~tYo$ETgIWwR%oOylghArrfChMQBZx{yNMRKeKb9xBmT_$R*Kaeb&9!A<1Q?MDPULyPeR<2qHwmZO3))*~u9'
    'VvVt`A2})*nvT2x^bDTH$%$r8VbO?LU6sPKOYOqeSKY^IUYn+;e4x)dHf6X~>aRRL<tc3L!6Gr%d5|B2>?NXr0`)Jlkw7=4q!aCX'
    'MtG>qk*C|rAY$XuANu}<^kcw%Q_RRW!~nX44PuCM4wW3kTR|7WFTymjocv?;S8u+=$#{pl*++Y6X-LT!dI{{?0UA@T69drL0JX|e'
    'iM<~tvwCgBUc@dztiK->m$~5gNTkk+H_|GwKhh=EDpVUvHz=RE6m6e87(y?hVkI(ZTPjL7v6JpP+t@y%tEd0KHBlM<0(;4J&%n4Q'
    'MNe_B3_Q=_*IGmCPK8k`aJg^Ubd38HapD@^3sZ;VCetJ!A*hq9=y=^B9y!PA7bn+m8zD7MWKFZOM@MD)P)V941~GD1M~7&m)!b{|'
    'd7O*eqWnFrYK;fh+1hZm$w)**MBdkwTu{6KRBpNTcZF0a_>{<%xOpy;B)EnZ-Ta|TZw3H~Q8&&}qL4#$s^;evm6F|Yo307_%2?;V'
    '%q*jhb)L3-oj~h2#)Ykik8HrFF}ZAx?*<w%;X81O3d_1enPJPv5&^G@QP76(XU+e8?fR8W!gT2hn)B7FSsr?EJEG?e=BMk1BW#BL'
    'xYT3o@ooOJZoea2sv8f}oN3CDf`(?xx|%@e(ZDcvrcj0H<gVSDS^!WxF>vTdva?(3rjBCSOZe;$_3zXgqJEkTsahku_VH|AaCIL0'
    'erK)z2FzKMRk>v?A_A9=PB+Ue)58}gJQGKB6eVjcCM!}Ahj&r~7FWsMmSt_Lvo)VigVRvuLqd~?j_YLYYCiBEgl0*i1YzHe&0qtX'
    'Z<Vfrh!(n{uC01>lYJ^~7B`Cebj(4hij1Z85oF)V9-azezJih6p_LC|H1-8%yt-IiUQ$Wm_uB;A`4Z>NW8qWeYNIT=XkA7)o@}JZ'
    '-U*jQtr<7}G@oV-c1~zaN**0Gn`#j<3|O#KqPX*1!A21nTU>wkYp*|-G*El|tXa9nnw5|S2Wc3wtU)nZ%{kYA-(n6wTGWd3O*w~$'
    'qz>fS+Rvb#K|6$^V6HM&&&zo>s%iko_DA13`39aUBevDH;f)$QQr3D}#;w~jbxHO6a~rmXHg9a($kL5#K+bpkhwXwV(eGNs3FWRi'
    'yfD)a+Q@!9MJAwD)NKWvE~3LLEEHyl$THN#h4CGZsEyS*q1sopt*m<GYFh<L5eYA#o#8E&J2XTt7FnMmn<rby5X4>%43?3@Vv|+*'
    '{{-y}k=RTAq7^tdeAl61zgFv&xqRh?;ulzl>!1EisJ`U%=I{?Y3?eHQv9VanX(ue6tJ5I{zgDI?RV}Pzsc|4z#0KMHj%%kmHO3w+'
    '`4QYM_X*-zAHiHPR+{Q&N{mn?+&H*UrmgdHe+PUD$*9pY3sl;5X=Th%sK9ME36!_3GG*cx4t%0i6>0mDmd#eKOX-sF%kISihfC2('
    ')m6(NegG!<6B?=G)n!sR%#-~OV|Vs}x3+aN(7?W}3bd<;14U>(V7ei$*{!%D>ooD5l;{WYtzDX61{m)vGSr%;Oj#<ME8e=zdDmI('
    ';{~;;3pHe}h_q#0YEu1Y?hf!yHrnWi*mnlH|JC>gJq5}O3K&|V0|hKs8eZi~O4w90vbA}louFyJ+DPPDTQzssV>iW^iAHP(8wS2@'
    'tL%f;W(Cw?xpxp@5b@Uf>ze76pHiWDAVugR1hQeVW9usEA=xFeJ_WVT%Hh>eFj=wYxT*&FO$qD=)0uB4m!mR+SL#V0cVAEabd%(}'
    'ad%pN(^>LGiD(2ik?4><T+hhun-2yoJH4iQrK;6BSqVp}0?4D{0&7&~qx)o7=8AE`gpy3vZxNNkRcEh^0^`pHWjP%pos`pOqKwD-'
    '-LydPWJPaP_gmNeHqKIXWj8C5i@D7aV(ChPi@ksRDuD)rkG%w|oHM5}OrC6E!ZPD1_y!AWUzEf9E@f~kv8+1QN-r1Fb^KDKy4SiD'
    's5QkWQI3F9>V)ROw4f`!$iPQ)Im60v^gK6TM2a#z$jGht<zlS&Q+-r`6Wae6DO`ja5g0ro4?i@dmJ}nHx8g{l%h$&!1*W7LpDT3K'
    '9R~S65R1^|QU{{Kd0V%C`1MgdRgNdWOL*bbC&)q*2)X@Y$@pF|yTp`6de+f^Gj!d6{_hCpC%eK^u!qV;uAsYC4{r6MkwjKLW8;Iq'
    '(#%%L_*ZDh;<?}T)dGc;$`$eB6bD%;8HS%rqPfDlB>NbZgO8PKYL%5HwELzOkBr3!(dA#VhGCHFdy7v5fI`7+l;@K+NL=lW-p0lz'
    '<@CZowP2B~2S}pR>HKb#yv)toaw}?IvUM65gdDe${7KxUP4_&6&xXtlByhb1L&l+yBd!%)5bej9p3#eP4U9)9tOS<lP1#<m_b{+Q'
    'H8iYRdlT$D>RO`kaaElvMf8A*)9QY$QTyQ2g{O+ClEP;SIpI^!oTZB5lRmLe0*7IE;_Py<N@4*v(^+erfan3jsGU5>HEYDHQaKvs'
    'KaVcSSXiG;@&QQt1F4gtenSZ?##f{V;fbnrI#!v4*7r0D4DNihT~BK8J>P6W9t{s!VS~`o)J>NqL2{&tRhR@K74po9^zGUE3)%M{'
    'nTr~bvg-@_)zt1Y^6D6-58gWJ!pVy^-^E*|QGy{)NF@i)j!6yY%+fi?@Aonv?K);Y9wuljy3Iv;lBI8&LVoF9GC8YJ`O$q6%M-DL'
    'kHCOu?cEMDHV(@DPmxcSx+Ff2b<!lz(yZ-4Up2nh?Sz#E;guD=tPOrd-a5QFH#fifCfu`HCO;ChnPL$5SlbBVSw^C3UQ`v%2+K3^'
    'VLGv!tNQ#W7ACx8MUk0f!Y#@bhsJ}JDQIC~Ut83mCk6$yI*}wo(uB%K6n5{aFLg+jh^>s9iK0wI8aqI^7Yo(MijzwDv2hv~Z($nw'
    'HwLm=T0BXxxALPb#E7<0N8Fiacd1vp*Uaynf11!$sgVIqBoFaVlXN`OIYjhgp)7zylUW%~|BFR2n!9%8mm-t6vfQGHvzX6ZVc-dB'
    'H9l5G>Hw;|+|+?KZbFhEUj4iz!DeoHl4Y$M6qy>f*~J8AML}jgmUvp}#u=Vv=Bi>8$Zv<C5%1h)kCoQ0)|<-xZI-Ms;i(P+ReX@6'
    '$=O(EWSKF_Z#0Y2oWedS#<+6hS<(;h&tyHZg?D(?cD%5SULI=omfWt&+=nr*#JmjDwas*LfwG=f(5vzoOOM~|AEo<0ADo^Y9Q`1_'
    'RE0lbE1$gHIgF*EbNRknA3sFbaa<QIzk@YHIaU1pL*vle3z+!FwWv(wOG8ouQZc4RJi_;HPyeDK6lk7D$7ks)Ov2ZBjHUFV6Ewlx'
    'h}7<Fv>_Jb_U6V$m(BBoyco4D%6gW-Tl}ACM!d^FPr_9ndU-9;?h(jp>3p#i3pkJV($KTf`OG9*6Db`xAh33QAF#&VWOHlt!P)kL'
    'i*0EwR<7*I><w1SVBUsPY7x%cpuc{+ybVU5OXO|PU&U$*Ij*UO7|?mrY`n^oP)$qtiUJD?$#0JXOCWH(Y364;q{s=;ks**IGg1ts'
    'bSqM#Mt!{FqgggtX#U3s<JoZ3M*iqgU6aRyWrSvOLe$J*uYFJ05d!K~BQ2do%FM{>@eu6RT}mQWO1v|2&bhDXAY1OJi{b|l6>}G`'
    'z5n%MG%qI7;y-J@H&B@0g4BMll7DC@J1dwy{?*ou&ftpeDQ_GItNmo_%WwYu=~T|Q=4$0%ez_ZLCirNckGq`7n5#wCC-bmRl&A6~'
    's6APHgVQ6<(MeeH51S-<n;3Az|HXWedPVG^urEAFZn;MP3xY<_jhEY6=CzLG$qQN$SF*1Nb&|)?@%40tw-~3CJU2yGLAT_e`0sYO'
    '6e1<|xPiVcSNw}?@G&=^dG~-7H-58uIY~qBRg4fdJnysq&6if}b8NKP6^>=^-@_qgMHij(mt-$w_>{%)WWjEzT;zch3R3}0^3D{P'
    'Xw5{x5&GD`Ys?}_*QmpSM;YA<PgL~V6jzKl*?n?>w~oT(G85NKnG97*MxbesA85v*OsLnvP)rM)t&d`Jd)zNOVvfpklH4q2<lPD4'
    'e>u$=EE8ZcB)N%lj$~$wlu#K3N3?kUsl0%mcSWH^;J!$f(|j_@IM|@PDR7XCUG{K+;n%cWT(J)+jdwT2%`PF79;@QIk)@LvplUu{'
    'pl>z)Rg4I%Sw6|oEtk6b@F9LB`QZcm#46X+nUTAOyn(qWPEYh?5(j(>FlMCSiYq)Spsgm<O~!c7M@yPO=h;gHj_qVBLS%efeuPm0'
    '8B}$Sop;q8dcs4IMdpH+1Ca|aVTo{I7%+)uS~;$yn2ql>X7Tdzf{T#M$o=_ZR*qo7)wb!ana;M-mMqp=nQbe|JFf0G5V2!Fo*$_g'
    'C>YD)rr?gWRlzPs`;`sU$R5MiX^tn7`er<?Xl?1>qd=HZ-BkMqlU=iNV#LSn;oR&;ZNbkK6Yq=vHon}C@b7-)IdE{{rYK@A`f{e8'
    '52MZO`{oaq80*5YjMC8(uhH-|+w;RsE3jl5s!(4Fcm+#1TdMoocMo)11Y@t3nY*7!b;XItQnCig+KmG18#~>M0}CUhTaAWJ)pinF'
    '#>m(rE;Pjx5}1TmV9k&3r5w(Y-I+I>o)Gl-SDvRi7Umwyk_n=w_wA-QgXbk3M>OvGFrOB;>JTIov^-Fhzgj-lJ~;m5YW#472M*oi'
    'g|2~xRn4kd96&=q@GOFre)t-5EkL9=yU_8tmZoqDrzzTdTkQIFy8Gk)>mBqkaO(QXNAHeL{=9#Z9=|<%^Y%=?a&H>(nP{rJ3=7q*'
    '*tWuV4eFU2&4Q;mzONMfu|br~TjzMY&iC3Rb%`T_JT_2hDK9U{gZp6f`Llz~FIiY!S0^3CtO0$3m`s6MH|21l9WJK%RRQM!iq#~0'
    'XUXp2fw<$s7A$RDq2&u9qpA_;O*ieXo$md)i)?V5&k<}8!LGC0q6CTbV4et1yO}QV#$rCm-M7yMcf)7-__mmq6ot1&p<TBmyuz`K'
    'n}%zUb1;_3#7|}5uBM!%6?QqaTFlU0C5LmIx7C~b`E@y7BRs<=FO$pcW4_Kpz4&B+N^`RF=75F(@P`;nhWi*~)amTHm?VNd&j?|;'
    'LbnjbW+3Qd*535&M@rJC?;ihj{C#?OaC-LP17UzE0%hO{Y<-lsaq$SrA3pr~;P5a#KB8}S506jxL0(2EfV`#vC3#H>Uqz$dx6qD2'
    'Er71pL>316WHHf2$dVDPD1l&w;EDB|l(YHzK$L-35vXgILK^NRZ^yu-Q8<DDCD{SakY#hM9172@(>}{?E{dx~xtO7o4ZtwXQNvrK'
    'aA{)Xpk6J;B19G1%&-?CT<l<7IJGD>g77WQuJt>hGFW>MWQGNF^D)mSvxGAm$etJ;8H;H=#dJ4-pJ7gj8_!|-<t1Yatpw{MqBgm*'
    'te5tZ6Hsi%OkP;Weg-{*3MeSJTqDF6<8>J~$gtguEi}FFCA%;m>GXPCq7ovT;zVas^;_eU6V55n6$jUnuk-FUB4ee_7p9k&qz103'
    '$V%LpIa5ali#;9c*bY!IxrpL)F`>5z+l6q;1v1Knd*vGJi{2WZOSBQw^l|~Km;-+n;xZ|!1lw#)KANNJ>zWeF@per9LTkDFyHrnS'
    'IgsC6|6E+il=tEZOdBA_x{C4v2oeku_b<VbmvsCNmB_&eXj(T=kGKUi#^n(&cgFYKL|QJo$zFlB6KTBYCTE!amA_*@yIE6x;(Mm6'
    'T_Fc?7+Sgu>;kyN>DyDhw%Ol<Gw+3Z`u6Bx7pvUuAN_Q2a(wi9|L6?fZ*FWsll`C1=!5k1Z0F?c?HkMvj)&YSH~Mnx#nw09sGg3F'
    '({~3)d&lqa`{ysVHoyLQ3*OSVuhO@tpd0S-o#ttR#`3S$(rR`_{cLW0^JT1|D7Im={TiUg&xKK%(we6p2}9#=HvhO~HC1!vZ_GsK'
    '{p62U)9-gq4|cHz;qluebOv!6Z?4&faq_~kGN;h=0W~O8ob2x&AMN5b`zijlhq!sZ(c2Jybw*GWN`Yh&Q)1wsfinri3i3b-Ad|)%'
    'N+*RzA3CMvQOswN5&#9Sv~T1v^&^q4WWvB41YxnrA0@Spwy@>Hj8bGtje~aqfEth|2ppXfB*kFMG*uZuP$d-7GfCHiRi?x$o$}q<'
    '<Y#L@B>lHLJ=M9?G@b7H&Tl})f2pkul5F`mXu~FaM$w5l0(Ln*AGA)i;3(rZ%<Lz;E?-CQT&b#KvM`d}vG7QNk`VB4QFm4yDI(yX'
    '4+OPflxu>Jv8ICo^=~UgMFyyt1?tOk#O?}y8iQanGg|_REucmX_*y8~+{jWu)fAx>zLfN2@{xCK;m>eNC8#kXk5QIh7Wrs6Bgwqo'
    '8eFto*P2c@X}3m`lU$`=Fr0DF7e_SM%V!_w<s|z4teBHSap>*v?&t8h!@Ix4Ui^Go{4I}uRrT`cT?_*U`F}c#eqZ0@RWTavNKq`>'
    '2x}OHU*4Twmv_89%?9fI;6kE&EBIb73BGrHW|X%Y>d75ye|<V19*jZTXnF3A>OE^l6%C}e<i0--(cJ#e4XN&wC0i^?1$|p&E2gRt'
    'eFzd*%X9EF#+QXQj6<Rs5ZA(KDK`5v5>_H_hj+^5DMkwXedxUg9!@>$(DM$*W>a~iJh0vZg`B~0bBJk8HJJ?3Q8~WCe+W2e59dR('
    'w)D1wtX~7izggU%rVS$4X+9S_QS~;1-|3v&a)Q=IZFfi^5Yv(%2FBmHr0fCrk#62hL2-rGyNK{`52v7vf#wVlMH+?H>)<#g`DFj('
    'wAmVAR`}yd&T1}k8x!J%g>!PBYTEc1@2r|OMkvlOp$q6gO@L_FmSAYmHiXHzWY`R`-)FO8Km=kGxkI*6ySWJTgHp1g;Nl7*A}V~H'
    '-;~pPZ@U=O2D_@h(VIN`X!ZDZM#pTdt?D$=F3wKEGITSvo?&uM$s(fMfm;2U>@d~sK%)h&Q<TGo{o3uDjDYRlWLNpC41_>QgMsbN'
    '4H^G=ge6$aC)S8MIujCHKCEbcF0_qImZfa7C%GzbqY8GYTI1d&gU}^5tQ#8PE9#c~5N&lqaL!aMgSO~-H)+v-tz>NK<_D8TM|zbB'
    'mc_+ISchq`-9h?G7)3$|5l(aoq5x2_-84!lGG-)3$nv}~Vq63rL2rA9hwYYp0|;5n@)UN|oE=*nFI64Rg0`O@YwNn6SASXO#q31S'
    'z@*ua@LkMb-U)ya4)o^@I;<~zW)>DTxUK4=VK^(uthF&a=gkLgjKcq3<kR~nhP!zp<_2IbNgRR&y=xju!5UfBl)ML_I(pR|h(R5!'
    'xI(}CIw00}&THr07+(h<G8Vv+{zl)jsBY;T4R=>0yey`jsS|qzfEv&3?PMr$;&ijzoE)Iz8OiHgEP;nO@Qvrcm!l)o3hR2lY+o8A'
    '%P&%WeM0vm{N<8Ig!O4)>a<AyXMq$m%T#tgZ`NaTc$9dwEUSGB6m#CFzs7W-zI{_wICN=9-o(p>hT-@jpYMMvKtvrjgJkLRBrrf7'
    'a6-0|U91^C#Q}ffMxtLfDeRah!-Lq60<+;QwDhFF&p!L?5VMG?Tjp#u2jBqT>twQ3H*onFt-F&FqqG-z>3DHZ*>u+FOTKoWEfa$N'
    '0O3;3#TPE+n>yiAwzChm9kT1ZYn&|P-{zdJMn^-UmYqC^s1^C8uztD}Ydw)0?hq;6%(mglHeE`-r%M;SSFvfId>6P}7v0w57rkPh'
    '-^|*8!H@ZUf0W%^46_8EZPUNsZ=ClA*(|>-N5i%VRboXFsQi~t8yl_OUtx>1+pS-J>;L*&tH;7-8#?P!2OYW~Q9to&OMuboBwuhJ'
    ')Q@?wCC_tqky(rja&r>Jk3_*~#)3*fAp9cR%HLh8z;rA7p8rjF>GgW&UA~vHktGUSpu>rw)GCL|7QV2w+QHp0*btsu?EuZecJMr?'
    'CF4NKJCbXPqSp-kz&A}Pi|?DoXeoZ_do*U_`!;8om}Jwr>l#c>0@;+ZRPbWs^3fAqRQdy*0TA5IV}gYP13R5?7T4@zMkv8brOS<y'
    'f651oIc}g7eYw*MI6Z`~w&NcSOBR~F4Fol^Z~;$Nn>TzIo^~-S#<Mv_SK;pLCPN@mkzO2MUuQE;F^=zAw0B#p;@;#SHY~;)m!kk7'
    '|N0x>Y34cSGnF+ptRss+!;%%6#aNkxh$9G-)R<d)xshmPprN}mj)}^6LpY)@@JFjpi==<6bqhS={-Uu>55%aR`e>MQ(EGi?SlyY6'
    'X2qDW{M10<7`<#bZ1b>A1epH(JphdapzVJ$C2tTAhbkX*Og5O36G$dY6C>y7;zsS7Q<3M#|DuV60$4=pn~AixsxYr@_WOZ0+N)RH'
    'p<}IZVO|_xmgu$G&{ob!R@d@o8ic6XrVTLgeL@qL7ANxn!l&gVRFq5g&^m%>J1KX8wOB=I@f(v2U@tw#wB1o+$_yRCINC<V7qp`R'
    'X1>$(3AqRY3oPg4+(<q%vw1$@5FbvjkItX1S#oz>j`DRuCdtKO2!}2#`_K~9E$5u?LILl~QKb=jI}s8*&t1qbuxd6j*`|56p+~K!'
    'ZH}YUO9b5^ooSmt8r99kLrQHp0VI5xV#f@i^@+LSHcfxh3*MRa^i{9uv&PSh`V-oo@<J>qd$uA!JMl<p8%3<T{w9h~t??G>ti^(5'
    '1C^ajXzdJf;W_6jD}8)-dQreC{Tmg(3EdDNBK-8fktko)otM&%5<dnKX|gsA>%IH-^z3-=VCSgEPEu((odD%p+k)6@XRY}WhlKmF'
    '7>!bNaH61D;tP_BeFrh&7G?q-K(-mcrerQdBny1g)hG+6bP0U3_9&C=n0y%8s_R<a-zhsd>i`t8wz2EF3J3TTZU}Mib%if&mn-+7'
    'J2PsG!ex9N9mPe|vu3GIO(U6dFy<MkJhZoyRw~YmUHPolO(N&60&&|ueI>-+<IlTEpkR{g|JK!R@F~uYMwPM4>J30Q&8~9uB`%J*'
    'h0LbY>|VbM`7v@zM&+B{*I01ckS}Oodo=e>4pFyv3x6Bejh1aqx6tr8n1N4_Se)8*Vhv+oNQZ0tD~2-q5x;gzmRsnCR`!EvYq12@'
    '2jW?D=DadIVe66oMWnVC4&^`f>W!m4-AW5=vq-a9?5*YZS=9#ZAU>Y0O9G99YCqBNcM(2s((iq$So=7?;~#CSh!tT(Mx(@XI#Xzh'
    'rupq)S;pAP2tJK`MweZ%sL`*=;I7nmthS_|9XPtwUJ=+}Hjc?Ozb(qeOq2}@=I}S~W!i!Hbb@&~s&aC~CIh&20K%lnD`KNL5>%q('
    'pez!aaaEyGd#yuhjB63(<)1NAf7?ZI{Vec-(zsd`Y)syc!*_MDQ#E$DE1QFd>yFfm9F`}#;F#eAbCt=ebf|8FQWYWiu{6c91m9?4'
    'OXP-9lc+7A>*~gljvC}%T453nnq--RiVTd=r86}XXW{(2zsR~-8j}KNY4#OYlByM<708?}7ve-7KB7IQ=WJ5J<<)PIesQhA_O^MC'
    'UADt!IdqUO%X56uKvuwv61F#4tFwo391V^vy0I+75h0%aN^4#?o4y8rS^89ihBm!;`2dV$13H>9sYxAW2G+B$z>}GzgCysFscBC}'
    '5V85{5lOF>S|YqOxb$X$Ux#7&9vy8Lh;H)L#vfmNy{c%%m$5#=l(aB0808~iFMPtg0`Bm4Kxy>}fJpu3agZwF(NY<pR#hN|D#4I*'
    '24{V`1bkep;Bcxdg*FW!hjk+Qgo&PmldS?VmCF%Cn#uNcfxm#*=qF56o6!1HbN$DZ`!$#b@n`@Ht!lY`gPMJ1fsSa7Nr&Vr{p8xA'
    'aib|IYtm6h=T~96@OD(S;i95>z-HmKrYr~;N|736S1d({%dA-2ksj&ZTLG;qQhY@Z)d?wcb$ndLl@{Yg-hBCOvvq~S7}ScJuXe=F'
    '(ZH_VkY2)=4AqgTD%TRQ9ioQ~ryeKME_1|sJyxcc#M(b4I*9=*(A?BsLg0mOftRA`dA%HS(ha=F;G`^Yeo;P%_1X1eKE#qNMtyV='
    'Jj!u%b{dflR^S|sNyiiYo{osB2*{iEqiy;B?D0ogp6V^kSG<M=6!+0=F7Eln9^@NhSmX6p@`cP}(xVU3>-<xD^Q(>yICic=)TPa9'
    '%D=QeDlT)bfvRqAgp`kB4JFMfN4G`}9w{_c<Y|arRW!VYkO_25FCqW>$#5Dn?T4H(;URtKn?&ntcJ`y&BQ(m1PYt1xGgw(Hv@4SV'
    'Z3hMqpsA9n*~ob>{%{QF=Opma8x324xj!LfAZt$AVd&x~mA7yWdNFWMSHR27&q@{2aH8^#A`F**1j$y+Gn7uH<_N3O<~wBNa%SGG'
    'Hc_`C=zH%`L!dK;+C`&rlg^l|@>x>6$-134uW**2AY<og_+!`kRdWDDaPBP4j~rj!h6^qS!H?U*zZrcKBUtYwe^2ylV>(!n!Mw{t'
    'o+_{_GS|qIHnOM!u=R30oS6<xHR)v<Aej@N^`m=E)1zHMg(jlDGv*cgLQ}p{2r082cM>jL&S;KKu-#gWKaSyuq8x^{6Gp0EX{RRn'
    'ZzuV@N=4T9(j37_>Y!eewUPHGn)1dKv@mu<%{VN0T7->>^r^jFrJJ&Nhjr(uDAdSwS>YtpTo{VmD{Y%)KUlS;auQ4yoH%F+hoj}^'
    ';0zQN>r^Qkk;y39Q{@H>3+v`~!b2~5Qa0Z$Qfh0NKvS8A#N0`GWN}1=+PjUc^5JryA%%9s8>Oo{>@+9gU{4+y1gx>-hljSpKdvm{'
    '$HtBd{2nVY+&{NhT*2@vVIpO+s<kWzXWtGeUo%=iZWdXYKy40LeyBGa<@uzIRfjfu8(Uo}Lj-^6EWBRzrgq1yJA@e!r*rctkbte#'
    'akmE6P?oHk8$`{!IrM%sZI&Kf4X^s`E}I#`ZNscFi`8wjW|yIRBMVM(DMu%=WuuMRXBA_V(0bPM&f1ePC@+OvsJ&<;+c^A*InxUK'
    'skn@Af=Yw7A@*0e8HK;CVm`7{`vz^9+R@E>_O6<I#4N?}mg07jTIX279Qhs9U7@8k3AwAOcNy;XAkL-)cxj`ISv#6Y;pnw4)CyZC'
    'q$~YdyAu+@Nl0)$G{p!1+e=b91q&Xl!Gj?6g63Q|!pf9cDeh8ROX}HQRDxT@%}P6gqpa&%x&Uxa3fz;XnYQ6IE|)N#-c(u2cIM?x'
    'F|cx#s-)N=Y3a-4!v{GvEIBhqSwx(Am}Hg0yDKxBe(tE*(pgwU1Dnq#)8ZzZ3Y$aNO;)rl#sFhMS@h?_Vu`k>1vPG*Pp6fQ$7QP9'
    '3pa001=<&d1RY=RRMx}^mUbeqZFa`yjM?YWM6Y!C`N;Ae@;O*F(9|uf9_-F3h2F$b$n3=rpTpHEC92Q_5?;vYqD2?TQqn~!dVg`$'
    'r0whQ2Duahou!wf>?$xvx(xH1%hc}ec3`b8b)j<PWhRz7od*MoQp2bi%xxea0TwGHI!sq)HTETXuAiw*IjW;b%%;B_@~pv#;T}3R'
    'e$4M@Z3n1|LV}?l?K1GO%^wb%83;bmj(yhQDC+=a8FJfF#G(oxs2j0xWhkxDGyl(r4FW1uQzILPl>)+yrU>w!evl=3g9M3yya^pF'
    'xmPhxd+WE;Hi-0oa4jNnA|46!qtsy>q$)F?lEzeS3hOS|UzMn3&T?q;zH?2`Zh}AqHkB`?DQt=imW0it84EU@wnoDyE6OP9E=-%h'
    'nel?8lj_*oSag_q)c8GgR26GF)J1n9OTrDONT7VVd7Ivax>#x}JE66~Q^^hFjgI_)fptu;vX)o@<tWd_l8^+g*-;=><GPsXPAKW5'
    'eU08;r8gt@jOx(HqGb3X)(C2(?0Z|#<_`wLz>?OXJUq*e813)fnqh#!1q%db8|z!?<yGs~Rp-g&a@cSyJxrkz`1zJiIb#{F9m-kW'
    'iN^>xCk<v(oS=%5?CDHYGU=XUdRVUSuwS>rfsC8lOuitmdc$!fa$p8b%FR<Ew%zbg8o!%tIMEFjMmmohuYzQR^k+B{#_~a}j&|YZ'
    'X3c{w6ORq<T6kgg9<ozD&7c8DZ6f1S0KQm<V#~_jGFVJ+G(YSAV^glZXYHGidg`-hvpgLxONdn*#>`Bln^o=AD%aR2p&=W5&wX;a'
    '<qUA|wv!Pr`8?U|_?ECoAe#l{DD_Dun!D5^6`+io;!Is@Z@AO-w}zYU!u_IS-r_G!dV0oDvJ*|7lp!t6H7n1a&<=~7`2pI(`t~(P'
    'Tl@3s2F)*TpOWH?Dql9yg|Sgjdg1S?2(bB0aup#qA;t!IKCMEXVg^K^ak^ZdHf4q^(k<rsCknw;_40Z+-qzrTdl=DSL&^JG`bHx3'
    'x*{Fx`PSE8ef_Y6Wb?A55(}+3=$=5}<bd>Hi{&ii+?ZS}H;^#Xad6}`C!qA<2Tlc|Sks<Sb*MME(4Y&l)h(kvICY8QNihs&V%Tkz'
    'XF-K^hcu)Ha<fYb&S-%^-7q3V$*Sb<5|K_R!9YKzx!f_5Tc&ZPoQ6$YHGrw|Rem{wwh2RLnGU($Rk%kzkEOb#trPAsbW1?Delo?D'
    'S2^<UNmboQcw1RAQh%*#MLyv8lyj!k%K6lh)-A!-*g7={fIG2}$*|!d9L}H<7|}+t4Hhy5Y1d*@whyDTS-QL;U7sHb`;mhRN31us'
    'drztlIuFD{E-Ggh$5l7^r<!#v$=WLCF-1{`$=dkfiitHjBFrc;Ms660J1peMI~gq(VyfuluXA;`BVLg!Pk>=hjeN`!3}+-Kq}WO;'
    'Xf8xg7PWJ<7$*x$^lO$PgT{v__QZQ9Gt~-+%E&8#+_r*v3J6`k|Fsh`VmViIT|B~a3uitHLF%!%Oph!2%2MH}Tg~@;!x-AfiJq<V'
    'q>2~>tXmR4_`&jcX&Qa&HLnf86<;)o!L0!}NVD>q#LkxXd()h2)BKkwxqm0RdDz-JYyN0!UF{dP`WiRL{<9i8smE{=a#)TOmLh}t'
    '!JA$DL@q$%j-8K>(A87%RK&A9PTrk<FrQsL3Ow6!F#SrE_sa^AGqM{uWm;@Fynwf*E2Cy`hy3l@HhZX!xoIFshrx^<=onb-w61i-'
    'egKW;qq@kY`cD0w6;`fR057tA8s>@qClJtm8RMT%h@p)i<eElQjnB%PeC4t9`j0xxq`GMqC=hO2<NDuRj`H$gHVU(g&dLa@h{pVQ'
    '4ui4yn(7FQ)x%zzN|<#>5K+`L4=>z>c7TY~HWFBITzdfH*-WQ<?}?vifi)_^;Hz##(d~#Jo4C4LF6M*sCRbs&%USUmqF842cq+~C'
    'h9T$S$4D6UyXqX?UI~J=bng9T0952NaS2g0C4yKr0sm5@hbIHUP`QY|1C0xl&hJCoZowu7UDpGM+><TgjaWO;20&{c*GT4*$I7^`'
    'rJ_bz_G1b5Bf0f!y;rsD;kPmZin>Wy1~Ez>_|jcpKXd2Ouhp~r4K(k5Tot!Au(yEDapH)aZpIKRk)n}#MdCM-YQ?8@@ntAgPbcUF'
    '?WSCC60;OK{eqrveMi!F+T(E^g4~=QI;Vz%lSWxS`d{`onr8ZtUe!+e7+qzKIj1aa<_sA1yl%%_uiXwhy7@+L10z?$?eI<ddgtf#'
    'WPkVgX!qc7KRw02_D+Ki)IXsgo?ufhF4L*PL%?-Av}l}XMI=;kAnQlw^^jaLR9K3@C@0zfE^=Ok8HM!ZpC+SXP|Qd7Nj@7)%R4wq'
    'C6Oe+VCL7bh8T8frMZidqK2xomZo^MlwzILR+Mruw$?ijf)5G%t@HmM9~zy-'
)
_READONLY_BOOTSTRAP_SUPPORT_SHA256 = "d7cad747cf533867ba5264c7fbaa65ccc98288ab0a2b5af59b89a14e7b23629a"
_READONLY_BOOTSTRAP_SUPPORT_PATHS = (
    "scripts/ctp_i13_i15_guardian_deployment_anchor.py",
    "scripts/ctp_i13_i15_parent_launcher.py",
    "scripts/ctp_i13_i15_runtime_closure.py",
    "scripts/ctp_i13_i15_outer_watchdog.py",
    "scripts/ctp_i13_i15_worker_output_channel.py",
    "scripts/ctp_i13_i15_windows_job_backend.py",
)
_READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES = 4 * 1024 * 1024
_READONLY_BOOTSTRAP_MAX_WORKER_OUTPUT_BYTES = 63 * 1024
_READONLY_BOOTSTRAP_ZERO_SHA256 = "0" * 64


def _readonly_bootstrap_fail(reason):
    sys.stderr.write("readonly_preflight_rejected:" + reason + "\n")
    sys.stderr.flush()
    return 78


def _readonly_bootstrap_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate")
        result[key] = value
    return result


def _readonly_bootstrap_digest(value):
    return (
        type(value) is str
        and len(value) == 64
        and value != _READONLY_BOOTSTRAP_ZERO_SHA256
        and all(char in "0123456789abcdef" for char in value)
    )


def _readonly_bootstrap_binding():
    expected_env_names = {
        "path",
        "systemroot",
        "windir",
        _READONLY_BOOTSTRAP_BINDING_ENV.casefold(),
    }
    folded_env = {}
    for name, value in os.environ.items():
        folded = name.casefold()
        if folded in folded_env:
            raise ValueError("environment")
        folded_env[folded] = value
    if set(folded_env) != expected_env_names:
        raise ValueError("environment")
    raw_text = folded_env[_READONLY_BOOTSTRAP_BINDING_ENV.casefold()]
    if type(raw_text) is not str or not raw_text or len(raw_text) > 4096:
        raise ValueError("binding_size")
    raw = raw_text.encode("ascii", "strict")
    wire_binding = json.loads(raw.decode("ascii"), object_pairs_hook=_readonly_bootstrap_pairs)
    if type(wire_binding) is not dict:
        raise ValueError("binding_fields")
    worker_schema = "ctp_i13_i15_readonly_preflight_bootstrap_binding.v3"
    coordinator_schema = "ctp_i13_i15_readonly_request_coordinator_binding.v1"
    receipt_schema = "ctp_i13_i15_readonly_receipt_writer_binding.v1"
    if wire_binding.get("schema") == worker_schema:
        expected_keys = {
            "schema",
            "deployment_descriptor_sha256",
            "source_manifest_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "dependency_manifest_sha256",
            "runtime_manifest_sha256",
            "python_sha256",
            "deadline_monotonic_ns",
            "request_id",
            "worker_output",
        }
        if set(wire_binding) != expected_keys:
            raise ValueError("binding_fields")
        binding = dict(wire_binding)
        binding["_readonly_role"] = "worker"
        binding["_readonly_role_binding"] = wire_binding
    elif wire_binding.get("schema") == coordinator_schema:
        if set(wire_binding) != {
            "schema", "request_id", "deadline_monotonic_ns", "deployment", "identities",
            "supervisor_output_channel", "token_control_channel",
        }:
            raise ValueError("binding_fields")
        deployment = wire_binding["deployment"]
        if type(deployment) is not dict or set(deployment) != {
            "descriptor_sha256", "source_manifest_sha256", "runtime_manifest_sha256",
            "dependency_manifest_sha256", "python_sha256", "i13_pin_sha256", "i15_pin_sha256",
            "bootstrap_sha256", "worker_sha256", "coordinator_sha256",
            "receipt_writer_sha256", "token_bootstrap_sha256",
        }:
            raise ValueError("deployment_binding")
        binding = {
            "schema": wire_binding["schema"],
            "_readonly_role": "coordinator",
            "_readonly_role_binding": wire_binding,
            "deployment_descriptor_sha256": deployment.get("descriptor_sha256"),
            "source_manifest_sha256": deployment.get("source_manifest_sha256"),
            "i13_pin_sha256": deployment.get("i13_pin_sha256"),
            "i15_pin_sha256": deployment.get("i15_pin_sha256"),
            "bootstrap_sha256": deployment.get("bootstrap_sha256"),
            "worker_sha256": deployment.get("worker_sha256"),
            "dependency_manifest_sha256": deployment.get("dependency_manifest_sha256"),
            "runtime_manifest_sha256": deployment.get("runtime_manifest_sha256"),
            "python_sha256": deployment.get("python_sha256"),
            "deadline_monotonic_ns": wire_binding["deadline_monotonic_ns"],
            "request_id": wire_binding["request_id"],
            "_deployment": dict(deployment),
        }
    elif wire_binding.get("schema") == receipt_schema:
        expected_keys = {
            "schema",
            "request_id",
            "deadline_monotonic_ns",
            "deployment",
            "work_result",
            "coordinator_job",
            "receipt_output_channel",
        }
        if set(wire_binding) != expected_keys:
            raise ValueError("binding_fields")
        deployment = wire_binding["deployment"]
        deployment_keys = {
            "descriptor_sha256",
            "source_manifest_sha256",
            "runtime_manifest_sha256",
            "dependency_manifest_sha256",
            "python_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "coordinator_sha256",
            "receipt_writer_sha256",
            "token_bootstrap_sha256",
        }
        if type(deployment) is not dict or set(deployment) != deployment_keys:
            raise ValueError("deployment_binding")
        channel = wire_binding["receipt_output_channel"]
        if type(channel) is not dict or set(channel) != {"nonce", "server_pid"}:
            raise ValueError("receipt_output_binding")
        binding = {
            "schema": wire_binding["schema"],
            "_readonly_role": "receipt_writer",
            "_readonly_role_binding": wire_binding,
            "deployment_descriptor_sha256": deployment["descriptor_sha256"],
            "source_manifest_sha256": deployment["source_manifest_sha256"],
            "i13_pin_sha256": deployment["i13_pin_sha256"],
            "i15_pin_sha256": deployment["i15_pin_sha256"],
            "bootstrap_sha256": deployment["bootstrap_sha256"],
            "worker_sha256": deployment["worker_sha256"],
            "dependency_manifest_sha256": deployment["dependency_manifest_sha256"],
            "runtime_manifest_sha256": deployment["runtime_manifest_sha256"],
            "python_sha256": deployment["python_sha256"],
            "deadline_monotonic_ns": wire_binding["deadline_monotonic_ns"],
            "request_id": wire_binding["request_id"],
            "receipt_output_channel": channel,
            "_deployment": deployment,
        }
        if any(not _readonly_bootstrap_digest(value) for value in deployment.values()):
            raise ValueError("deployment_digest")
        if (
            type(channel["nonce"]) is not str
            or len(channel["nonce"]) != 32
            or channel["nonce"] == "0" * 32
            or any(char not in "0123456789abcdef" for char in channel["nonce"])
            or type(channel["server_pid"]) is not int
            or channel["server_pid"] <= 0
            or channel["server_pid"] > 0xFFFFFFFF
        ):
            raise ValueError("receipt_output_binding")
    else:
        raise ValueError("binding_schema")
    # Compare canonical wire bytes before adding private in-process aliases.
    canonical_wire = json.dumps(
        wire_binding, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    )
    if canonical_wire.encode("ascii") != raw:
        raise ValueError("binding_canonical")
    if binding["_readonly_role"] == "worker":
        if binding["schema"] != _READONLY_BOOTSTRAP_BINDING_SCHEMA:
            raise ValueError("binding_canonical")
        for name in expected_keys - {"schema", "deadline_monotonic_ns", "request_id", "worker_output"}:
            if not _readonly_bootstrap_digest(binding[name]):
                raise ValueError("binding_digest")
    elif binding["_readonly_role"] == "receipt_writer":
        for name in (
            "deployment_descriptor_sha256",
            "source_manifest_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "dependency_manifest_sha256",
            "runtime_manifest_sha256",
            "python_sha256",
        ):
            if not _readonly_bootstrap_digest(binding[name]):
                raise ValueError("binding_digest")
    else:
        for name in (
            "deployment_descriptor_sha256",
            "source_manifest_sha256",
            "i13_pin_sha256",
            "i15_pin_sha256",
            "bootstrap_sha256",
            "worker_sha256",
            "dependency_manifest_sha256",
            "runtime_manifest_sha256",
            "python_sha256",
        ):
            if not _readonly_bootstrap_digest(binding[name]):
                raise ValueError("binding_digest")
    request_id = binding["request_id"]
    if (
        type(request_id) is not str
        or len(request_id) != 32
        or request_id == "0" * 32
        or any(char not in "0123456789abcdef" for char in request_id)
    ):
        raise ValueError("request_id")
    if binding["_readonly_role"] == "worker":
        worker_output = binding["worker_output"]
        if type(worker_output) is not dict or set(worker_output) != {"nonce", "server_pid"}:
            raise ValueError("worker_output_binding")
        nonce = worker_output["nonce"]
        server_pid = worker_output["server_pid"]
        if (
            type(nonce) is not str
            or len(nonce) != 32
            or nonce == "0" * 32
            or any(char not in "0123456789abcdef" for char in nonce)
            or type(server_pid) is not int
            or server_pid <= 0
            or server_pid > 0xFFFFFFFF
        ):
            raise ValueError("worker_output_binding")
    deadline = binding["deadline_monotonic_ns"]
    if type(deadline) is not int or deadline <= 0 or time.monotonic_ns() >= deadline:
        raise ValueError("deadline")
    return binding, folded_env


def _readonly_bootstrap_support():
    try:
        compressed = base64.b85decode(_READONLY_BOOTSTRAP_SUPPORT_B85.encode("ascii"))
        raw = zlib.decompress(compressed)
    except BaseException:
        raise ValueError("embedded_support_encoding") from None
    if (
        not raw
        or len(raw) > _READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES
        or hashlib.sha256(raw).hexdigest() != _READONLY_BOOTSTRAP_SUPPORT_SHA256
    ):
        raise ValueError("embedded_support_digest")
    if type(raw) is not bytes or len(raw) < 4:
        raise ValueError("embedded_support_schema")
    header_size = int.from_bytes(raw[:4], "big", signed=False)
    if header_size <= 0 or header_size > 64 * 1024 or 4 + header_size > len(raw):
        raise ValueError("embedded_support_schema")
    try:
        value = json.loads(
            raw[4 : 4 + header_size].decode("ascii", "strict"),
            object_pairs_hook=_readonly_bootstrap_pairs,
        )
    except (UnicodeError, ValueError, json.JSONDecodeError):
        raise ValueError("embedded_support_schema") from None
    if (
        type(value) is not dict
        or set(value) != {"schema", "transform", "files"}
        or value["schema"] != _READONLY_BOOTSTRAP_SUPPORT_SCHEMA
        or value["transform"] != "ast_unparse_v1"
    ):
        raise ValueError("embedded_support_schema")
    rows = value["files"]
    if type(rows) is not list or len(rows) != len(_READONLY_BOOTSTRAP_SUPPORT_PATHS):
        raise ValueError("embedded_support_files")
    sources = {}
    digests = {}
    source_digests = {}
    cursor = 4 + header_size
    for expected_path, row in zip(_READONLY_BOOTSTRAP_SUPPORT_PATHS, rows):
        if type(row) is not dict or set(row) != {
            "path",
            "source_sha256",
            "source_size",
            "executed_sha256",
            "executed_size",
        }:
            raise ValueError("embedded_support_row")
        source_size = row["source_size"]
        size = row["executed_size"]
        if (
            row["path"] != expected_path
            or not _readonly_bootstrap_digest(row["source_sha256"])
            or not _readonly_bootstrap_digest(row["executed_sha256"])
            or type(source_size) is not int
            or source_size <= 0
            or source_size > _READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES
            or type(size) is not int
            or size <= 0
            or size > _READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES
            or cursor + size > len(raw)
        ):
            raise ValueError("embedded_support_binding")
        source = raw[cursor : cursor + size]
        cursor += size
        if hashlib.sha256(source).hexdigest() != row["executed_sha256"]:
            raise ValueError("embedded_support_source_digest")
        source.decode("utf-8", "strict")
        sources[expected_path] = source
        digests[expected_path] = row["executed_sha256"]
        source_digests[expected_path] = row["source_sha256"]
    if cursor != len(raw):
        raise ValueError("embedded_support_trailing_bytes")
    return sources, digests, source_digests


def _readonly_bootstrap_bind_support_source_identity(source_seal, source_digests):
    if type(source_digests) is not dict or set(source_digests) != set(
        _READONLY_BOOTSTRAP_SUPPORT_PATHS
    ):
        raise ValueError("embedded_support_source_binding")
    for relative_path in _READONLY_BOOTSTRAP_SUPPORT_PATHS:
        digest = source_digests[relative_path]
        if (
            not _readonly_bootstrap_digest(digest)
            or source_seal.files.get(relative_path) != digest
        ):
            raise ValueError("embedded_support_source_binding")


def _readonly_bootstrap_exec_support(sources, relative_path, name):
    source = sources[relative_path]
    namespace = {"__name__": name, "__file__": "<fixed-embedded-source>"}
    exec(compile(source, "<fixed-embedded-source>", "exec", dont_inherit=True), namespace)
    return namespace


def _readonly_bootstrap_exec_support_modules(sources, digests, finder):
    fixed_paths = (
        "scripts/ctp_i13_i15_outer_watchdog.py",
        "scripts/ctp_i13_i15_worker_output_channel.py",
        "scripts/ctp_i13_i15_windows_job_backend.py",
    )
    if (
        any(name == "scripts" or name.startswith("scripts.") for name in sys.modules)
        or type(finder) is not SealedSourceFinder
    ):
        raise ValueError("bootstrap_support_import_state_invalid")
    package = type(sys)("scripts")
    finder._begin_fixed_bootstrap_support_package(
        package, capability=_FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN
    )
    modules = {}
    for relative_path in fixed_paths:
        module = finder._load_fixed_bootstrap_support_module(
            relative_path,
            sources[relative_path],
            expected_sha256=digests[relative_path],
            capability=_FIXED_BOOTSTRAP_SUPPORT_REGISTRATION_TOKEN,
        )
        modules[relative_path] = module
    return modules


def _readonly_bootstrap_architecture():
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    get_process = kernel32.GetCurrentProcess
    get_process.argtypes = []
    get_process.restype = ctypes.c_void_p
    query_arch = getattr(kernel32, "IsWow64Process2", None)
    if query_arch is None:
        raise ValueError("architecture_unavailable")
    query_arch.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ushort), ctypes.POINTER(ctypes.c_ushort)]
    query_arch.restype = ctypes.c_int
    process_machine = ctypes.c_ushort()
    native_machine = ctypes.c_ushort()
    if not query_arch(
        get_process(), ctypes.byref(process_machine), ctypes.byref(native_machine)
    ):
        raise ValueError("architecture_unavailable")
    machine = process_machine.value or native_machine.value
    if machine == 0x8664:
        return "AMD64"
    if machine == 0xAA64:
        return "ARM64"
    if machine == 0x014C:
        return "x86"
    return "unknown"


def _readonly_bootstrap_token_sid():
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    token = ctypes.c_void_p()
    open_token = advapi32.OpenProcessToken
    open_token.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p)]
    open_token.restype = ctypes.c_int
    get_process = kernel32.GetCurrentProcess
    get_process.argtypes = []
    get_process.restype = ctypes.c_void_p
    if not open_token(get_process(), 0x0008, ctypes.byref(token)):
        raise ValueError("token_unavailable")
    try:
        get_info = advapi32.GetTokenInformation
        get_info.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32)]
        get_info.restype = ctypes.c_int
        required = ctypes.c_uint32()
        get_info(token, 1, None, 0, ctypes.byref(required))
        if required.value <= 0 or required.value > 65536:
            raise ValueError("token_unavailable")
        buffer = ctypes.create_string_buffer(required.value)
        if not get_info(token, 1, buffer, required.value, ctypes.byref(required)):
            raise ValueError("token_unavailable")
        class _SidAndAttributes(ctypes.Structure):
            _fields_ = [("Sid", ctypes.c_void_p), ("Attributes", ctypes.c_uint32)]
        user = _SidAndAttributes.from_buffer(buffer)
        if not user.Sid:
            raise ValueError("token_unavailable")
        sid_text = ctypes.c_wchar_p()
        convert = advapi32.ConvertSidToStringSidW
        convert.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)]
        convert.restype = ctypes.c_int
        if not convert(user.Sid, ctypes.byref(sid_text)):
            raise ValueError("token_unavailable")
        try:
            value = sid_text.value
            if type(value) is not str or not value:
                raise ValueError("token_unavailable")
            return value
        finally:
            local_free = kernel32.LocalFree
            local_free.argtypes = [ctypes.c_void_p]
            local_free.restype = ctypes.c_void_p
            local_free(ctypes.cast(sid_text, ctypes.c_void_p))
    finally:
        close = kernel32.CloseHandle
        close.argtypes = [ctypes.c_void_p]
        close.restype = ctypes.c_int
        close(token)


def _readonly_bootstrap_retain_paths(anchor_ns, root, files, directories):
    root = anchor_ns["_canonical_windows_path"](root, "runtime_root_invalid")
    if type(files) not in (tuple, list) or type(directories) not in (tuple, list):
        raise ValueError("runtime_path_set_invalid")
    protected_type = anchor_ns["_ProtectedWindowsPaths"]
    protected = protected_type(frozenset({anchor_ns["_SYSTEM_SID"], anchor_ns["_ADMINISTRATORS_SID"]}))
    try:
        protected.add_paths(
            (root,),
            directory_paths=frozenset({root}),
            listable_directory_paths=frozenset({root}),
        )
        for relative in directories:
            if type(relative) is not str or "\\" in relative:
                raise ValueError("runtime_path_set_invalid")
            if relative == "":
                continue
            relative_path = PurePosixPath(relative)
            if (
                relative_path.as_posix() != relative
                or relative_path.is_absolute()
                or any(part in {"", ".", ".."} for part in relative_path.parts)
            ):
                raise ValueError("runtime_path_set_invalid")
            path = ntpath.join(root, *relative.split("/"))
            protected.add_paths(
                (path,),
                directory_paths=frozenset({path}),
                listable_directory_paths=frozenset({path}),
            )
        for relative in files:
            if type(relative) is not str or not relative or "\\" in relative:
                raise ValueError("runtime_path_set_invalid")
            relative_path = PurePosixPath(relative)
            if (
                relative_path.as_posix() != relative
                or relative_path.is_absolute()
                or any(part in {"", ".", ".."} for part in relative_path.parts)
            ):
                raise ValueError("runtime_path_set_invalid")
            path = ntpath.join(root, *relative.split("/"))
            protected.add_paths((path,))
        return anchor_ns["_RetainedDependencyPaths"](root, protected)
    except BaseException:
        try:
            protected.close()
        except BaseException:
            pass
        raise


def _readonly_bootstrap_run_receipt_writer(
    binding,
    *,
    raw_binding,
    anchor_ns,
    descriptor,
    parent_facts,
    source_seal,
    source_finder,
    dependency_seal,
    runtime_seal,
    anchor_paths,
    support_modules,
):
    """Run only the sealed receipt-writer role with a fixed protected root."""

    if (
        binding.get("_readonly_role") != "receipt_writer"
        or type(raw_binding) is not dict
        or raw_binding.get("schema") != "ctp_i13_i15_readonly_receipt_writer_binding.v1"
        or type(source_finder) is not SealedSourceFinder
        or source_finder._seal is not source_seal
        or source_finder._runtime_closure is not runtime_seal
        or source_finder._dependency_finder is None
    ):
        raise ValueError("receipt_writer_runtime_unavailable")

    role_module = None
    receipt_paths = None
    runtime = None
    try:
        role_module = _open_fixed_readonly_role_module(
            source_seal, source_finder, "receipt_writer"
        )
        parsed_binding = role_module.parse_receipt_writer_binding(raw_binding)
        if (
            parsed_binding.request_id != binding["request_id"]
            or parsed_binding.deadline_monotonic_ns != binding["deadline_monotonic_ns"]
            or dict(parsed_binding.deployment) != binding["_deployment"]
        ):
            raise ValueError("receipt_writer_binding_mismatch")

        expected_deployment = {
            "descriptor_sha256": descriptor.descriptor_sha256,
            "source_manifest_sha256": source_seal.manifest_sha256,
            "runtime_manifest_sha256": runtime_seal.manifest_sha256,
            "dependency_manifest_sha256": dependency_seal.manifest_sha256,
            "python_sha256": descriptor.python_sha256,
            "i13_pin_sha256": parent_facts.candidates["i13_md"]["pin_sha256"],
            "i15_pin_sha256": parent_facts.candidates["i15_td"]["pin_sha256"],
            "bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
            ),
            "worker_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_worker.py"
            ),
            "coordinator_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_request_coordinator.py"
            ),
            "receipt_writer_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_receipt_writer.py"
            ),
            "token_bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_token_bootstrap.py"
            ),
        }
        if any(type(value) is not str or not _readonly_bootstrap_digest(value) for value in expected_deployment.values()):
            raise ValueError("receipt_writer_deployment_incomplete")
        if dict(parsed_binding.deployment) != expected_deployment:
            raise ValueError("receipt_writer_deployment_mismatch")

        support_path = "scripts/ctp_i13_i15_worker_output_channel.py"
        output_channel_module = support_modules.get(support_path)
        if (
            output_channel_module is None
            or not source_finder._owns_fixed_bootstrap_support(
                "scripts.ctp_i13_i15_worker_output_channel", output_channel_module
            )
            or sys.modules.get("scripts.ctp_i13_i15_worker_output_channel")
            is not output_channel_module
        ):
            raise ValueError("receipt_writer_output_channel_unavailable")

        now_ns = time.monotonic_ns()
        if type(now_ns) is not int or now_ns >= parsed_binding.deadline_monotonic_ns:
            raise ValueError("deadline")

        program_data = anchor_ns["_program_data_path"]()
        fixed_root, _descriptor_path, _auth_key_path, _dependency_path, _runtime_path, receipt_root = (
            anchor_ns["_fixed_paths"](program_data)
        )
        expected_fixed_root = ntpath.join(
            program_data, *anchor_ns["FIXED_PROGRAMDATA_RELATIVE"].parts
        )
        if ntpath.normcase(ntpath.normpath(fixed_root)) != ntpath.normcase(
            ntpath.normpath(expected_fixed_root)
        ):
            raise ValueError("receipt_root_binding")

        integrity_sids = frozenset(
            {anchor_ns["_SYSTEM_SID"], anchor_ns["_ADMINISTRATORS_SID"]}
        )
        receipt_paths = anchor_ns["_ProtectedWindowsPaths"](integrity_sids)
        receipt_paths.add_paths(
            (receipt_root,),
            directory_paths=frozenset({receipt_root}),
            writable_paths=frozenset({receipt_root}),
            writer_sids_by_path={
                receipt_root: frozenset(
                    {
                        anchor_ns["_SYSTEM_SID"],
                        anchor_ns["_ADMINISTRATORS_SID"],
                        descriptor.service_sid,
                    }
                )
            },
        )
        if time.monotonic_ns() >= parsed_binding.deadline_monotonic_ns:
            raise ValueError("deadline")

        class _FixedReceiptWriterRuntime:
            __slots__ = (
                "_created",
                "_creation_started",
                "_execution_close_attempted",
                "_execution_close_errors",
                "_output_started",
                "_closed",
            )

            def __init__(self):
                self._created = False
                self._creation_started = False
                self._execution_close_attempted = False
                self._execution_close_errors = ()
                self._output_started = False
                self._closed = False

            def _check_deadline(self):
                now = time.monotonic_ns()
                if type(now) is not int or now < 0 or now >= parsed_binding.deadline_monotonic_ns:
                    raise ValueError("deadline")

            def _verify_current(self):
                self._check_deadline()
                if self._execution_close_attempted:
                    raise ValueError("execution_leases_already_closed")
                _require_clean_after_install(source_seal, finder=source_finder)
                source_seal.source_lease.verify_current()
                dependency_seal.verify_current()
                runtime_seal.verify_current()
                anchor_paths.verify_current()
                receipt_paths.verify_current()
                descriptor_raw = anchor_paths.read_file(
                    ntpath.join(
                        program_data,
                        *anchor_ns["FIXED_PROGRAMDATA_RELATIVE"].parts,
                        anchor_ns["FIXED_DESCRIPTOR_NAME"],
                    ),
                    max_bytes=anchor_ns["_MAX_DESCRIPTOR_BYTES"],
                )
                if hashlib.sha256(descriptor_raw).hexdigest() != descriptor.descriptor_sha256:
                    raise ValueError("deployment_changed")
                _require_clean_after_install(source_seal, finder=source_finder)
                self._check_deadline()

            def monotonic_ns(self):
                return time.monotonic_ns()

            def verify_deployment(self, deployment):
                if (
                    self._closed
                    or self._execution_close_attempted
                    or dict(deployment) != expected_deployment
                ):
                    raise ValueError("deployment_binding_mismatch")
                self._verify_current()

            def close_execution(self):
                if self._closed or self._execution_close_attempted:
                    raise ValueError("execution_close_reentry")
                self._execution_close_attempted = True
                errors = []
                if source_finder._runtime_closure is runtime_seal:
                    try:
                        source_finder.detach_runtime_closure(runtime_seal)
                    except Exception:
                        errors.append("runtime_closure_detach_failed")
                if source_finder._dependency_finder is not None:
                    dependency_finder_value = source_finder._dependency_finder
                    try:
                        source_finder.detach_dependency_finder(dependency_finder_value)
                    except Exception:
                        errors.append("dependency_finder_detach_failed")
                for name, close in (
                    ("runtime_closure_close_failed", runtime_seal.close),
                    ("dependency_seal_close_failed", dependency_seal.close),
                    ("source_seal_close_failed", source_seal.close),
                    ("anchor_paths_close_failed", anchor_paths.close),
                ):
                    try:
                        close()
                    except Exception:
                        errors.append(name)
                self._execution_close_errors = tuple(errors)
                self._check_deadline()
                if errors:
                    raise ValueError("deployment_execution_lease_close_failed")

            def persist_fixed_receipt(self, request_id, raw):
                if (
                    self._closed
                    or self._creation_started
                    or not self._execution_close_attempted
                    or request_id != parsed_binding.request_id
                    or type(raw) is not bytes
                    or not raw
                    or len(raw) > 64 * 1024
                ):
                    raise ValueError("receipt_write_binding_invalid")
                self._creation_started = True
                self._check_deadline()
                if dict(parsed_binding.deployment) != expected_deployment:
                    raise ValueError("deployment_binding_mismatch")
                receipt_paths.verify_current()
                created_path = receipt_paths.create_new_receipt(
                    receipt_root, parsed_binding.request_id, raw
                )
                target_path = ntpath.join(receipt_root, parsed_binding.request_id + ".json")
                if ntpath.normcase(ntpath.normpath(created_path)) != ntpath.normcase(
                    ntpath.normpath(target_path)
                ):
                    raise ValueError("receipt_target_mismatch")
                self._check_deadline()
                receipt_paths.add_paths((target_path,))
                readback = receipt_paths.read_file(target_path, max_bytes=64 * 1024)
                if readback != raw:
                    raise ValueError("receipt_readback_mismatch")
                self._check_deadline()
                self._created = True

            def write_supervisor_output(self, binding_value, output):
                if (
                    self._closed
                    or self._output_started
                    or not self._execution_close_attempted
                ):
                    raise ValueError("receipt_output_reentry")
                if (
                    type(binding_value) is not type(parsed_binding)
                    or binding_value != parsed_binding
                ):
                    raise ValueError("receipt_output_binding_mismatch")
                self._output_started = True
                self._check_deadline()
                receipt_paths.verify_current()
                self._check_deadline()
                nonce = parsed_binding.receipt_output_channel["nonce"]
                server_pid = parsed_binding.receipt_output_channel["server_pid"]
                frame_body = role_module.encode_receipt_writer_frame(
                    dict(output), request_id=parsed_binding.request_id, nonce=nonce
                )
                if type(frame_body) is not bytes or not frame_body or len(frame_body) > 64 * 1024:
                    raise ValueError("receipt_output_frame_size_invalid")
                frame = len(frame_body).to_bytes(4, "big", signed=False) + frame_body
                output_channel_module._write_bounded_frame(
                    frame,
                    nonce=nonce,
                    expected_server_pid=server_pid,
                    deadline_monotonic_ns=parsed_binding.deadline_monotonic_ns,
                )

            def close(self):
                if self._closed:
                    return
                self._closed = True
                errors = []
                try:
                    receipt_paths.close()
                except BaseException:
                    errors.append("receipt_path_close_failed")
                try:
                    source_finder._end_fixed_role_module("receipt_writer", role_module)
                except BaseException:
                    errors.append("receipt_role_unload_failed")
                if errors:
                    raise ValueError(";".join(errors))

        runtime = _FixedReceiptWriterRuntime()
        result = role_module.main(raw_binding, runtime)
        if type(result) is not int or result not in {0, 2}:
            raise ValueError("receipt_writer_result_invalid")
        return result
    finally:
        if runtime is not None:
            runtime.close()
        else:
            cleanup_error = None
            if receipt_paths is not None:
                try:
                    receipt_paths.close()
                except BaseException:
                    cleanup_error = True
            if role_module is not None:
                try:
                    source_finder._end_fixed_role_module("receipt_writer", role_module)
                except BaseException:
                    cleanup_error = True
            if cleanup_error:
                raise ValueError("receipt_writer_cleanup_failed")


def _readonly_bootstrap_run_coordinator(
    binding,
    *,
    raw_binding,
    descriptor,
    parent_facts,
    source_seal,
    source_finder,
    dependency_seal,
    runtime_seal,
    anchor_paths,
    support_modules,
):
    """Run the fixed coordinator from its retained source bytes."""

    if (
        binding.get("_readonly_role") != "coordinator"
        or type(raw_binding) is not dict
        or raw_binding.get("schema")
        != "ctp_i13_i15_readonly_request_coordinator_binding.v1"
        or type(source_finder) is not SealedSourceFinder
        or source_finder._seal is not source_seal
        or source_finder._runtime_closure is not runtime_seal
        or source_finder._dependency_finder is None
    ):
        raise ValueError("coordinator_runtime_unavailable")
    coordinator_module = None
    token_module = None
    runtime = None
    try:
        coordinator_module = _open_fixed_readonly_role_module(
            source_seal, source_finder, "request_coordinator"
        )
        token_module = _open_fixed_readonly_role_module(
            source_seal, source_finder, "token_bootstrap"
        )
        parsed = coordinator_module.parse_coordinator_binding(raw_binding)
        expected = {
            "descriptor_sha256": descriptor.descriptor_sha256,
            "source_manifest_sha256": source_seal.manifest_sha256,
            "runtime_manifest_sha256": runtime_seal.manifest_sha256,
            "dependency_manifest_sha256": dependency_seal.manifest_sha256,
            "python_sha256": descriptor.python_sha256,
            "i13_pin_sha256": parent_facts.candidates["i13_md"]["pin_sha256"],
            "i15_pin_sha256": parent_facts.candidates["i15_td"]["pin_sha256"],
            "bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
            ),
            "worker_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_preflight_worker.py"
            ),
            "coordinator_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_request_coordinator.py"
            ),
            "receipt_writer_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_receipt_writer.py"
            ),
            "token_bootstrap_sha256": source_seal.files.get(
                "scripts/ctp_i13_i15_readonly_token_bootstrap.py"
            ),
        }
        if (
            any(not _readonly_bootstrap_digest(value) for value in expected.values())
            or dict(parsed.deployment) != expected
            or parsed.request_id != binding["request_id"]
            or parsed.deadline_monotonic_ns != binding["deadline_monotonic_ns"]
        ):
            raise ValueError("coordinator_deployment_binding")
        output_channel_module = support_modules.get(
            "scripts/ctp_i13_i15_worker_output_channel.py"
        )
        if (
            output_channel_module is None
            or not source_finder._owns_fixed_bootstrap_support(
                "scripts.ctp_i13_i15_worker_output_channel", output_channel_module
            )
            or sys.modules.get("scripts.ctp_i13_i15_worker_output_channel")
            is not output_channel_module
        ):
            raise ValueError("coordinator_output_channel_unavailable")
        runtime = coordinator_module.BootstrapCoordinatorRuntime(
            parsed,
            descriptor=descriptor,
            parent_facts=parent_facts,
            source_seal=source_seal,
            source_finder=source_finder,
            dependency_seal=dependency_seal,
            runtime_seal=runtime_seal,
            anchor_paths=anchor_paths,
            support_modules=support_modules,
            token_module=token_module,
            output_channel_module=output_channel_module,
            expected_deployment=expected,
        )
        result = coordinator_module.main(raw_binding, runtime)
        if type(result) is not int or result not in {0, 2}:
            raise ValueError("coordinator_result_invalid")
        return result
    finally:
        if runtime is not None:
            runtime.close()
        if token_module is not None:
            source_finder._end_fixed_role_module("token_bootstrap", token_module)
        if coordinator_module is not None:
            source_finder._end_fixed_role_module("request_coordinator", coordinator_module)


def _readonly_bootstrap_detach_runtime_closure(source_finder, expected_seal):
    active = source_finder._runtime_closure
    if active is None:
        return
    if active is not expected_seal:
        raise ValueError("runtime_closure_replaced")
    source_finder.detach_runtime_closure(expected_seal)


def _readonly_bootstrap_detach_dependency_finder(source_finder, expected_finder):
    active = source_finder._dependency_finder
    if active is None:
        return
    if active is not expected_finder:
        raise ValueError("dependency_finder_replaced")
    source_finder.detach_dependency_finder(expected_finder)


def _readonly_bootstrap_run():
    stage = "binding"
    anchor_paths = None
    source_seal = None
    source_finder = None
    dependency_seal = None
    dependency_finder = None
    runtime_seal = None
    support_modules = None
    result = 78
    try:
        binding, env = _readonly_bootstrap_binding()
        if len(sys.argv) != 1:
            raise ValueError("argv")
        script_path = ntpath.normcase(ntpath.normpath(os.path.abspath(__file__)))
        bootstrap_relative = "scripts/ctp_i13_i15_readonly_preflight_bootstrap.py"
        source_root = ntpath.dirname(ntpath.dirname(script_path))
        if not ntpath.isabs(source_root) or ":" not in source_root[:3]:
            raise ValueError("source_root")
        if script_path != ntpath.normcase(ntpath.normpath(ntpath.join(source_root, bootstrap_relative))):
            raise ValueError("bootstrap_path")
        if ntpath.normcase(ntpath.normpath(env["path"])) != ntpath.normcase(
            ntpath.normpath(ntpath.dirname(sys.executable))
        ):
            raise ValueError("process_path")
        if not env["systemroot"] or env["systemroot"] != env["windir"]:
            raise ValueError("system_root")
        if type(sys.argv[0]) is not str or ntpath.normcase(ntpath.normpath(os.path.abspath(sys.argv[0]))) != script_path:
            raise ValueError("argv")
        if time.monotonic_ns() >= binding["deadline_monotonic_ns"]:
            raise ValueError("deadline")

        stage = "embedded_source"
        sources, support_sha256s, support_source_sha256s = _readonly_bootstrap_support()
        anchor_ns = _readonly_bootstrap_exec_support(
            sources,
            "scripts/ctp_i13_i15_guardian_deployment_anchor.py",
            "_i13_fixed_deployment_anchor",
        )
        parent_ns = _readonly_bootstrap_exec_support(
            sources,
            "scripts/ctp_i13_i15_parent_launcher.py",
            "_i13_fixed_parent_launcher",
        )
        runtime_ns = _readonly_bootstrap_exec_support(
            sources,
            "scripts/ctp_i13_i15_runtime_closure.py",
            "_i13_fixed_runtime_closure",
        )
        stage = "deployment_descriptor"
        program_data = anchor_ns["_program_data_path"]()
        fixed_root = ntpath.join(program_data, *anchor_ns["FIXED_PROGRAMDATA_RELATIVE"].parts)
        descriptor_path = ntpath.join(fixed_root, anchor_ns["FIXED_DESCRIPTOR_NAME"])
        dependency_path = ntpath.join(fixed_root, anchor_ns["FIXED_DEPENDENCY_MANIFEST_NAME"])
        runtime_path = ntpath.join(fixed_root, anchor_ns["FIXED_RUNTIME_MANIFEST_NAME"])
        integrity_sids = frozenset({anchor_ns["_SYSTEM_SID"], anchor_ns["_ADMINISTRATORS_SID"]})
        anchor_paths = anchor_ns["_ProtectedWindowsPaths"](integrity_sids)
        anchor_paths.add_paths((descriptor_path, dependency_path, runtime_path))
        descriptor_raw = anchor_paths.read_file(
            descriptor_path, max_bytes=anchor_ns["_MAX_DESCRIPTOR_BYTES"]
        )
        descriptor = anchor_ns["_parse_deployment_descriptor"](
            descriptor_raw,
            expected_sha256=anchor_ns["GUARDIAN_DEPLOYMENT_DESCRIPTOR_SHA256"],
            expected_worker_dependency_sha256=anchor_ns["WORKER_DEPENDENCY_MANIFEST_SHA256"],
            expected_runtime_manifest_sha256=anchor_ns["RUNTIME_MANIFEST_SHA256"],
        )
        anchor_paths.verify_current()
        if (
            descriptor.descriptor_sha256 != binding["deployment_descriptor_sha256"]
            or descriptor.source_manifest_sha256 != binding["source_manifest_sha256"]
            or descriptor.worker_dependency_manifest_sha256 != binding["dependency_manifest_sha256"]
            or descriptor.runtime_manifest_sha256 != binding["runtime_manifest_sha256"]
            or descriptor.python_sha256 != binding["python_sha256"]
            or descriptor.worker_sha256 != binding["worker_sha256"]
            or ntpath.normcase(descriptor.source_root) != ntpath.normcase(source_root)
            or _readonly_bootstrap_token_sid()
            != (
                descriptor.client_sid
                if binding["_readonly_role"] == "worker"
                else descriptor.service_sid
            )
        ):
            raise ValueError("deployment_binding")

        stage = "parent_descriptor"
        parent_descriptor = parent_ns["ExternallyPinnedDescriptor"](
            raw_bytes=descriptor.parent_trust_raw,
            sha256=descriptor.parent_trust_sha256,
            external_anchor_id="ctp-i13-i15-guardian-deployment-v2",
        )
        parent_facts = parent_ns["parse_trust_descriptor"](parent_descriptor)
        if (
            ntpath.normcase(parent_facts.source_root) != ntpath.normcase(source_root)
            or ntpath.normcase(parent_facts.python_executable)
            != ntpath.normcase(descriptor.python_executable)
            or parent_facts.python_sha256 != descriptor.python_sha256
            or parent_facts.python_version != descriptor.python_version
            or parent_facts.python_architecture != descriptor.python_architecture
            or parent_facts.candidates["i13_md"]["manifest_sha256"]
            != descriptor.source_manifest_sha256
            or parent_facts.candidates["i13_md"]["pin_sha256"] != binding["i13_pin_sha256"]
            or parent_facts.candidates["i15_td"]["pin_sha256"] != binding["i15_pin_sha256"]
        ):
            raise ValueError("parent_binding")
        actual_version = ".".join(str(part) for part in sys.version_info[:3])
        actual_architecture = _readonly_bootstrap_architecture()
        plan = parent_ns["preflight_parent_launch"](
            parent_descriptor,
            candidate="i13_md",
            captured_launcher_bytes=sources["scripts/ctp_i13_i15_parent_launcher.py"],
            actual_executable=os.path.abspath(sys.executable),
            actual_version=actual_version,
            actual_architecture=actual_architecture,
            actual_sys_path=tuple(sys.path),
        )
        if (
            ntpath.normcase(plan.source_root) != ntpath.normcase(source_root)
            or plan.manifest_sha256 != binding["source_manifest_sha256"]
            or plan.python_sha256 != binding["python_sha256"]
        ):
            raise ValueError("parent_plan")
        expected_pycache_prefix = ntpath.join(
            parent_facts.python_home, "disabled-bytecode-cache"
        )
        if (
            not ntpath.isabs(expected_pycache_prefix)
            or ntpath.normcase(ntpath.normpath(sys.pycache_prefix))
            != ntpath.normcase(ntpath.normpath(expected_pycache_prefix))
            or os.path.exists(expected_pycache_prefix)
        ):
            raise ValueError("pycache_prefix_binding")

        stage = "source_seal"
        source_seal = seal_candidate_source_tree(
            "i13_md",
            source_root,
            expected_manifest_sha256=plan.manifest_sha256,
            expected_pin_sha256s=dict(plan.pin_source_sha256s),
            stdlib_paths=plan.stdlib_paths,
        )
        _readonly_bootstrap_bind_support_source_identity(
            source_seal, support_source_sha256s
        )
        if (
            source_seal.files.get(bootstrap_relative) != binding["bootstrap_sha256"]
            or source_seal.files.get("scripts/ctp_i13_i15_readonly_preflight_worker.py")
            != binding["worker_sha256"]
            or source_seal.source_lease.read_source(
                bootstrap_relative, expected_sha256=binding["bootstrap_sha256"]
            )
            != open(__file__, "rb").read()
        ):
            raise ValueError("bootstrap_source_binding")
        if binding["_readonly_role"] in {"coordinator", "receipt_writer"}:
            role_source_digests = {
                "scripts/ctp_i13_i15_readonly_request_coordinator.py": binding[
                    "_deployment"
                ]["coordinator_sha256"],
                "scripts/ctp_i13_i15_readonly_receipt_writer.py": binding[
                    "_deployment"
                ]["receipt_writer_sha256"],
                "scripts/ctp_i13_i15_readonly_token_bootstrap.py": binding[
                    "_deployment"
                ]["token_bootstrap_sha256"],
            }
            if any(source_seal.files.get(path) != digest for path, digest in role_source_digests.items()):
                raise ValueError("service_role_source_binding")
        source_finder = install_sealed_source_finder(source_seal)

        stage = "dependency_seal"
        from backtrader_runtime import ctp_i13_worker_dependency_seal as dependency_api

        dependency_raw = dependency_api.read_fixed_worker_dependency_manifest(
            lambda: anchor_paths.read_file(dependency_path, max_bytes=1024 * 1024),
            expected_sha256=binding["dependency_manifest_sha256"],
        )
        dependency_root = ntpath.join(
            ntpath.dirname(ntpath.dirname(os.path.abspath(sys.executable))),
            "Lib",
            "site-packages",
        )
        if ntpath.normcase(dependency_root) != ntpath.normcase(
            ntpath.join(parent_facts.venv_root, "Lib", "site-packages")
        ):
            raise ValueError("dependency_root")
        dependency_seal = dependency_api.seal_worker_dependencies(
            dependency_raw,
            expected_manifest_sha256=binding["dependency_manifest_sha256"],
            python_executable=sys.executable,
            retain_paths=lambda files, directories: _readonly_bootstrap_retain_paths(
                anchor_ns, dependency_root, files, directories
            ),
        )
        if dependency_seal.manifest_sha256 != binding["dependency_manifest_sha256"]:
            raise ValueError("dependency_manifest_binding")
        dependency_finder = dependency_api.install_worker_dependency_finder(dependency_seal)

        stage = "runtime_seal"
        runtime_raw = anchor_paths.read_file(runtime_path, max_bytes=4 * 1024 * 1024)
        if hashlib.sha256(runtime_raw).hexdigest() != binding["runtime_manifest_sha256"]:
            raise ValueError("runtime_manifest_digest")
        descriptor_facts = {
            "python_executable": parent_facts.python_executable,
            "python_sha256": parent_facts.python_sha256,
            "python_version": parent_facts.python_version,
            "python_architecture": parent_facts.python_architecture,
            "python_home": parent_facts.python_home,
            "venv_root": parent_facts.venv_root,
            "pyvenv_cfg_sha256": parent_facts.pyvenv_cfg_sha256,
            "stdlib_paths": parent_facts.stdlib_paths,
        }
        process_facts = runtime_ns["capture_runtime_process_facts"]()
        runtime_seal = runtime_ns["seal_runtime_closure"](
            runtime_raw,
            expected_manifest_sha256=binding["runtime_manifest_sha256"],
            descriptor_facts=descriptor_facts,
            process_facts=process_facts,
            dependency_seal=dependency_seal,
            retain_paths=lambda root_kind, files, directories: _readonly_bootstrap_retain_paths(
                anchor_ns,
                parent_facts.python_home if root_kind == "base" else parent_facts.venv_root,
                files,
                directories,
            ),
        )
        source_finder.attach_runtime_closure(runtime_seal)
        source_seal.source_lease.verify_current()
        dependency_seal.verify_current()
        runtime_seal.verify_current()
        anchor_paths.verify_current()
        if time.monotonic_ns() >= binding["deadline_monotonic_ns"]:
            raise ValueError("deadline")

        stage = "embedded_process_support"
        support_modules = _readonly_bootstrap_exec_support_modules(
            sources, support_sha256s, source_finder
        )
        if binding["_readonly_role"] == "coordinator":
            stage = "coordinator"
            result = _readonly_bootstrap_run_coordinator(
                binding,
                raw_binding=binding["_readonly_role_binding"],
                descriptor=descriptor,
                parent_facts=parent_facts,
                source_seal=source_seal,
                source_finder=source_finder,
                dependency_seal=dependency_seal,
                runtime_seal=runtime_seal,
                anchor_paths=anchor_paths,
                support_modules=support_modules,
            )
        elif binding["_readonly_role"] == "receipt_writer":
            stage = "receipt_writer"
            result = _readonly_bootstrap_run_receipt_writer(
                binding,
                raw_binding=binding["_readonly_role_binding"],
                anchor_ns=anchor_ns,
                descriptor=descriptor,
                parent_facts=parent_facts,
                source_seal=source_seal,
                source_finder=source_finder,
                dependency_seal=dependency_seal,
                runtime_seal=runtime_seal,
                anchor_paths=anchor_paths,
                support_modules=support_modules,
            )
        elif binding["_readonly_role"] == "worker":
            output_channel_module = support_modules[
                "scripts/ctp_i13_i15_worker_output_channel.py"
            ]

            stage = "worker_source"
            worker_relative = "scripts/ctp_i13_i15_readonly_preflight_worker.py"
            worker_source = source_seal.source_lease.read_source(
                worker_relative, expected_sha256=binding["worker_sha256"]
            )
            worker_namespace = {
                "__name__": "_i13_fixed_readonly_preflight_worker",
                "__file__": ntpath.join(source_root, *worker_relative.split("/")),
            }
            exec(compile(worker_source, worker_namespace["__file__"], "exec", dont_inherit=True), worker_namespace)
            stage = "worker_run"
            class _BoundedWorkerOutput:
                __slots__ = ("_data",)

                def __init__(self):
                    self._data = bytearray()

                def write(self, text):
                    if type(text) is not str:
                        raise TypeError("worker_stdout_type")
                    encoded = text.encode("ascii", "strict")
                    if len(self._data) + len(encoded) > _READONLY_BOOTSTRAP_MAX_WORKER_OUTPUT_BYTES:
                        raise ValueError("worker_stdout_limit")
                    self._data.extend(encoded)
                    return len(text)

                def flush(self):
                    return None

                @property
                def encoding(self):
                    return "ascii"

                @property
                def errors(self):
                    return "strict"

                def isatty(self):
                    return False

                def writable(self):
                    return True

                def getvalue(self):
                    return bytes(self._data)

            worker_output_buffer = _BoundedWorkerOutput()
            original_stdout = sys.stdout
            sys.stdout = worker_output_buffer
            try:
                worker_result = worker_namespace["main"]()
                if sys.stdout is not worker_output_buffer:
                    raise ValueError("worker_stdout_replaced")
                worker_output_raw = worker_output_buffer.getvalue()
            finally:
                sys.stdout = original_stdout
            if type(worker_result) is not int or worker_result != 0:
                raise ValueError("worker_result")
            stage = "worker_output_channel"
            output_channel_module.write_worker_output_frame(
                worker_output_raw,
                request_id=binding["request_id"],
                nonce=binding["worker_output"]["nonce"],
                expected_server_pid=binding["worker_output"]["server_pid"],
                deadline_monotonic_ns=binding["deadline_monotonic_ns"],
            )
            result = worker_result
        else:
            raise ValueError("readonly_role_runtime_unavailable")
    except BaseException:
        result = _readonly_bootstrap_fail(stage)
    finally:
        cleanup_failed = False
        if runtime_seal is not None and source_finder is not None:
            try:
                _readonly_bootstrap_detach_runtime_closure(source_finder, runtime_seal)
            except BaseException:
                cleanup_failed = True
        if runtime_seal is not None:
            try:
                runtime_seal.close()
            except BaseException:
                cleanup_failed = True
        if dependency_finder is not None and source_finder is not None:
            try:
                _readonly_bootstrap_detach_dependency_finder(
                    source_finder, dependency_finder
                )
            except BaseException:
                cleanup_failed = True
        if dependency_seal is not None:
            try:
                dependency_seal.close()
            except BaseException:
                cleanup_failed = True
        if source_seal is not None:
            try:
                source_seal.close()
            except BaseException:
                cleanup_failed = True
        if anchor_paths is not None:
            try:
                anchor_paths.close()
            except BaseException:
                cleanup_failed = True
        if cleanup_failed:
            result = _readonly_bootstrap_fail("lease_cleanup")
    return result


raise SystemExit(_readonly_bootstrap_run())
