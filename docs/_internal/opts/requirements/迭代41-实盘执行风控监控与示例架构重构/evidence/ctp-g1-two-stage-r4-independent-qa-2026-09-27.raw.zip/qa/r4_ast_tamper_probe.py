import ast
import base64
import hashlib
import json
import sys
import zlib
from pathlib import Path

qa_root = Path(__file__).resolve().parent
source_root = qa_root / "source"
sys.path.insert(0, str(source_root))
from scripts import ctp_i13_source_manifest_candidate as builder

artifact = builder.build_readonly_preflight_bootstrap(source_root)
assert len(artifact) == 256988
assert hashlib.sha256(artifact).hexdigest() == "76514e602065754500583f77b97862101744ec87ed37a036e3903535721e82e7"
assert builder._MAX_BOOTSTRAP_BYTES == 262144
assert builder._MAX_BOOTSTRAP_BYTES - len(artifact) == 5156
module = ast.parse(artifact.decode("ascii"))
assignments = {}
for node in module.body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name):
                assignments[target.id] = node.value
support_b85 = ast.literal_eval(assignments["_READONLY_BOOTSTRAP_SUPPORT_B85"])
support_sha = ast.literal_eval(assignments["_READONLY_BOOTSTRAP_SUPPORT_SHA256"])
paths = ast.literal_eval(assignments["_READONLY_BOOTSTRAP_SUPPORT_PATHS"])
schema = ast.literal_eval(assignments["_READONLY_BOOTSTRAP_SUPPORT_SCHEMA"])
def _eval_int(node):
    if isinstance(node, ast.Constant) and type(node.value) is int:
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mult):
        return _eval_int(node.left) * _eval_int(node.right)
    raise AssertionError(f"non-integer constant expression: {ast.dump(node)}")
max_support = _eval_int(assignments["_READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES"])
support_names = {"_readonly_bootstrap_pairs", "_readonly_bootstrap_digest", "_readonly_bootstrap_support"}
support_functions = [node for node in module.body if isinstance(node, ast.FunctionDef)
                     and node.name in support_names]
assert {node.name for node in support_functions} == support_names
namespace = {
    "base64": base64, "hashlib": hashlib, "zlib": zlib, "json": json,
    "ValueError": ValueError, "UnicodeError": UnicodeError, "TypeError": TypeError,
    "_READONLY_BOOTSTRAP_ZERO_SHA256": "0" * 64,
    "_READONLY_BOOTSTRAP_SUPPORT_B85": support_b85,
    "_READONLY_BOOTSTRAP_SUPPORT_SHA256": support_sha,
    "_READONLY_BOOTSTRAP_SUPPORT_PATHS": paths,
    "_READONLY_BOOTSTRAP_SUPPORT_SCHEMA": schema,
    "_READONLY_BOOTSTRAP_MAX_SUPPORT_BYTES": max_support,
}
exec(compile(ast.Module(body=support_functions, type_ignores=[]), "<qa-extracted-support-loader>", "exec"), namespace)
load_support = namespace["_readonly_bootstrap_support"]
sources, executed_hashes, source_hashes = load_support()
assert len(sources) == 6 and set(sources) == set(paths)
compressed = base64.b85decode("".join(support_b85).encode("ascii"))
raw = zlib.decompress(compressed)
header_size = int.from_bytes(raw[:4], "big")
first_source_offset = 4 + header_size
mutated = bytearray(raw)
mutated[first_source_offset] ^= 1
mutated_b85 = base64.b85encode(zlib.compress(bytes(mutated), level=9)).decode("ascii")
namespace["_READONLY_BOOTSTRAP_SUPPORT_B85"] = mutated_b85
try:
    load_support()
except ValueError as exc:
    assert str(exc) == "embedded_support_digest"
else:
    raise AssertionError("stale outer digest accepted tampered support text")
namespace["_READONLY_BOOTSTRAP_SUPPORT_SHA256"] = hashlib.sha256(mutated).hexdigest()
try:
    load_support()
except ValueError as exc:
    assert str(exc) == "embedded_support_source_digest"
else:
    raise AssertionError("updated outer digest hid per-file executed-source tamper")
print(json.dumps({
    "artifact_bytes": len(artifact), "cap_bytes": builder._MAX_BOOTSTRAP_BYTES,
    "headroom_bytes": builder._MAX_BOOTSTRAP_BYTES - len(artifact),
    "source_count": len(sources), "baseline": "accepted",
    "tamper_stale_outer_digest": "rejected: embedded_support_digest",
    "tamper_updated_outer_stale_inner_digest": "rejected: embedded_support_source_digest",
    "executed_as_module": False
}, sort_keys=True))
