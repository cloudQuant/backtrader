"""Complete R28's exact runtime-map subset before the frozen R19 custody gate."""

from __future__ import annotations

import ast
import copy
import dataclasses
import hashlib
import ntpath
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_child_entry_path_r20_r1 as _R20


_R13 = _R20._R13
_R17 = _R20._R17
_R18 = _R20._R18
_R19 = _R20._R19
_R20_ORIGINAL_APPLY = _R20._apply_active_outer_transform

R21_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_child_main_map_r21_r1.py"
R21_RESULT_SCHEMA = "iteration41.okx.m01.r33.child-main-map-r21.root-preparation.v1"
R21_ADAPTER_RESULT_SCHEMA = "iteration41.okx.m01.r33.child-main-map-r21.parent-adapter.v1"
R21_SOURCE_ROLE = "r21_child_main_map_source"
R21_MAX_SOURCE_BYTES = 2097152
R21_MAX_OUTER_BYTES = 2097152
R21_SOURCE_MAP_MAX_BYTES = 1048576
R21_FAILURE_CODES = frozenset(
    {
        "r21_module_name",
        "r21_module_path",
        "r21_source_unavailable",
        "r21_source_size",
        "r21_source_binding",
        "r21_r20_source_binding",
        "r21_patch_context_busy",
        "r21_patch_context_changed",
        "r21_patch_owner_thread",
        "r21_outer_transform",
        "r21_transform_input",
        "r21_transform_anchor",
        "r21_transform_compile",
        "r21_helper_source_pin",
        "r21_helper_source_parse",
        "r21_helper_source_constants",
        "r21_helper_transform_compile",
        "r21_runtime_map_binding",
        "r21_runtime_public_shape",
        "r21_runtime_software_shape",
        "r21_main_public_shape",
        "r21_main_software_shape",
        "r21_public_binding",
        "r21_omission_binding",
        "r21_software_binding",
        "r21_hold_schema",
        "r21_hold_collision",
        "r21_hold_digest",
        "r21_prepared_binding",
        "r21_adapter_binding",
        "r21_r20_prepare_blocked",
        "r21_r20_adapter_blocked",
        "r21_transform_count",
    }
)

_R21_OMITTED_PUBLIC = (
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/root_diagnostic_once_r28_unset.py",
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/root_public_fill_r28_unset.py",
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/source-bundle.zip",
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/source-checkpoint.json",
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/source-index.json",
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/source-support/root-driver-r4.py",
        "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07/test_r28_root_preflight_diagnostic_source_fake.py",
        "tests/unit/runtime/test_iteration41_okx_m01_r28_preflight_diagnostic_source_fake.py",
    
)


class ChildMainMapR21Blocked(ValueError):
    """A fixed R21 source, map, transform, or hold contract failed."""

    def __init__(self, code: str):
        self.code = code if code in R21_FAILURE_CODES else "r21_hold_digest"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ChildMainMapR21Blocked(code)


def _canonical_json(value: Any) -> bytes:
    return _R20._canonical_json(value)


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R21_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r21_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R21_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r21_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R21_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ChildMainMapR21Blocked("r21_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R21_MAX_SOURCE_BYTES, "r21_source_size")
    return str(path), raw, _sha(raw)


_R21_OUTER_SUPPORT = br'''
R21_CHILD_MAIN_MAP_MARKER = b"iteration41.okx.m01.r33.child-main-map-r21.r1.v1"
R21_HELPER_PATH = __R21_HELPER_PATH__
R21_HELPER_SHA256 = __R21_HELPER_SHA256__
R21_HELPER_SOURCE_BYTES = __R21_HELPER_SOURCE_BYTES__
R21_SOURCE_MAP_MAX_BYTES = 1048576
R21_OMITTED_PUBLIC = frozenset(__R21_OMITTED_PUBLIC__)


def _r21_norm_relative(path):
    return ntpath.normcase(ntpath.normpath(path.replace("/", "\\")))


def _r21_norm_absolute(path):
    return ntpath.normcase(ntpath.normpath(path.replace("/", "\\")))


def _r21_pin_map(value, count, *, absolute, code):
    _check(type(value) is dict and len(value) == count, code)
    result = {}
    for path, digest in value.items():
        _check(
            type(path) is str and path and "\x00" not in path
            and type(digest) is str and len(digest) == 64
            and all(char in "0123456789abcdef" for char in digest),
            code,
        )
        normalized = _r21_norm_absolute(path) if absolute else _r21_norm_relative(path)
        drive, tail = ntpath.splitdrive(normalized)
        _check(
            (ntpath.isabs(path) if absolute else (not ntpath.isabs(path) and not drive
                and normalized not in (".", "..") and not normalized.startswith("..\\")))
            and normalized not in result,
            code,
        )
        result[normalized] = (path, digest)
    return result


def _r21_complete_main_maps(public, software, plan_raw, self_path, self_sha256):
    try:
        _map_raw, runtime_map, _map_sha = _r19_read_runtime_map(
            plan_raw, self_path, self_sha256
        )
    except BaseException:
        raise ValueError("r21_runtime_map_binding") from None
    runtime_public = _r21_pin_map(
        runtime_map.get("public_pins"), 118, absolute=False,
        code="r21_runtime_public_shape",
    )
    runtime_software = _r21_pin_map(
        runtime_map.get("software_pins"), 36, absolute=True,
        code="r21_runtime_software_shape",
    )
    main_public = _r21_pin_map(
        public, 110, absolute=False, code="r21_main_public_shape"
    )
    main_software = _r21_pin_map(
        software, 36, absolute=True, code="r21_main_software_shape"
    )
    for normalized, (path, digest) in main_public.items():
        _check(
            normalized in runtime_public
            and runtime_public[normalized][1] == digest,
            "r21_public_binding",
        )
    omitted = set(runtime_public) - set(main_public)
    _check(omitted == {_r21_norm_relative(path) for path in R21_OMITTED_PUBLIC},
           "r21_omission_binding")
    _check(
        {key: digest for key, (_path, digest) in main_software.items()}
        == {key: digest for key, (_path, digest) in runtime_software.items()},
        "r21_software_binding",
    )
    completed = dict(public)
    for normalized in omitted:
        path, digest = runtime_public[normalized]
        completed[path] = digest
    _check(type(completed) is dict and len(completed) == 118, "r21_public_binding")
    return completed


@contextlib.contextmanager
def _r21_held_public_sources(custody, public, software, self_path, self_sha256, plan_raw):
    completed = _r21_complete_main_maps(
        public, software, plan_raw, self_path, self_sha256
    )
    with _r19_held_public_sources(
        custody, completed, software, self_path, self_sha256, plan_raw
    ) as yielded:
        yield yielded


def _r21_rebuild_exact_active_outer(base_r10_outer, outer, *, held):
    regenerated = _r20_rebuild_exact_active_outer(base_r10_outer, outer, held=held)
    helper_raw = R21_HELPER_SOURCE_BYTES
    _check(
        type(helper_raw) is bytes and 0 < len(helper_raw) <= 2 * 1024 * 1024
        and _sha(helper_raw) == R21_HELPER_SHA256,
        "r21_helper_source_pin",
    )
    try:
        assignments, functions = _r13_source_nodes(helper_raw)
        support_template = ast.literal_eval(assignments["_R21_OUTER_SUPPORT"])
        relative_path = ast.literal_eval(assignments["R21_RELATIVE_PATH"])
        result_schema = ast.literal_eval(assignments["R21_RESULT_SCHEMA"])
        source_limit = ast.literal_eval(assignments["R21_MAX_SOURCE_BYTES"])
        outer_limit = ast.literal_eval(assignments["R21_MAX_OUTER_BYTES"])
        omitted = ast.literal_eval(assignments["_R21_OMITTED_PUBLIC"])
    except BaseException:
        raise ValueError("r21_helper_source_parse") from None
    try:
        transform = _r13_compile_function(
            {
                "ast": ast,
                "hashlib": hashlib,
                "ntpath": ntpath,
                "R21_MAX_SOURCE_BYTES": source_limit,
                "R21_MAX_OUTER_BYTES": outer_limit,
                "_R21_OMITTED_PUBLIC": omitted,
            },
            functions,
            "_apply_active_outer_transform",
            "_r21_apply_active_outer_transform",
        )
    except BaseException:
        raise ValueError("r21_helper_transform_compile") from None
    _check(
        type(support_template) is bytes
        and relative_path == "scripts/iteration41_okx_m01_r33_child_main_map_r21_r1.py"
        and result_schema == "iteration41.okx.m01.r33.child-main-map-r21.root-preparation.v1"
        and type(source_limit) is int and 0 < source_limit <= 2 * 1024 * 1024
        and type(outer_limit) is int and 0 < outer_limit <= 2 * 1024 * 1024
        and type(omitted) is tuple and len(omitted) == 8,
        "r21_helper_source_constants",
    )
    return transform(
        regenerated,
        R21_HELPER_PATH,
        R21_HELPER_SHA256,
        helper_raw,
        support_template,
        omitted,
    )
'''


def _apply_active_outer_transform(
    raw: bytes,
    helper_path: str,
    helper_sha256: str,
    helper_raw: bytes,
    support_template: bytes,
    omitted_public: tuple[str, ...],
) -> bytes:
    """Add the exact eight R28-omitted public rows before unchanged R19 custody."""
    if type(raw) is not bytes or not 0 < len(raw) <= R21_MAX_OUTER_BYTES:
        raise ValueError("r21_transform_input")
    if (
        b"iteration41.okx.m01.r33.child-entry-path-r20.r1.v1" not in raw
        or b"iteration41.okx.m01.r33.child-main-map-r21.r1.v1" in raw
    ):
        raise ValueError("r21_transform_input")
    if (
        type(helper_path) is not str or not ntpath.isabs(helper_path)
        or ntpath.normpath(helper_path) != helper_path or "\x00" in helper_path
        or type(helper_sha256) is not str or len(helper_sha256) != 64
        or any(char not in "0123456789abcdef" for char in helper_sha256)
        or type(helper_raw) is not bytes or not 0 < len(helper_raw) <= R21_MAX_SOURCE_BYTES
        or hashlib.sha256(helper_raw).hexdigest() != helper_sha256
        or type(support_template) is not bytes
        or type(omitted_public) is not tuple or len(omitted_public) != 8
    ):
        raise ValueError("r21_transform_input")
    support = support_template
    replacements = (
        (b"__R21_HELPER_PATH__", ascii(helper_path).encode("ascii")),
        (b"__R21_HELPER_SHA256__", ascii(helper_sha256).encode("ascii")),
        (b"__R21_OMITTED_PUBLIC__", ascii(omitted_public).encode("ascii")),
        (b"__R21_HELPER_SOURCE_BYTES__", repr(helper_raw).encode("ascii")),
    )
    if any(support.count(placeholder) != 1 for placeholder, _replacement in replacements):
        raise ValueError("r21_transform_anchor")
    for placeholder, replacement in replacements:
        if support.count(placeholder) != 1:
            raise ValueError("r21_transform_anchor")
        support = support.replace(placeholder, replacement, 1)

    old_rebuild = b"regenerated = _r20_rebuild_exact_active_outer(\n"
    new_rebuild = b"regenerated = _r21_rebuild_exact_active_outer(\n"
    old_scope = b"        with _r19_held_public_sources(\n"
    new_scope = b"        with _r21_held_public_sources(\n"
    if raw.count(old_rebuild) != 1 or raw.count(old_scope) != 1:
        raise ValueError("r21_transform_anchor")
    result = raw.replace(old_rebuild, new_rebuild, 1)
    result = result.replace(old_scope, new_scope, 1)
    run_anchor = b"def run_prelaunch(\n"
    if result.count(run_anchor) != 1:
        raise ValueError("r21_transform_anchor")
    result = result.replace(run_anchor, support + run_anchor, 1)
    if (
        len(result) > R21_MAX_OUTER_BYTES
        or result.count(new_rebuild) != 1
        or result.count(old_rebuild) != 0
        or result.count(new_scope) != 1
        or result.count(old_scope) != 0
        or b"iteration41.okx.m01.r33.child-main-map-r21.r1.v1" not in result
    ):
        raise ValueError("r21_transform_anchor")
    try:
        compile(result, "<r21-transformed-active-outer>", "exec", dont_inherit=True)
    except BaseException:
        raise ValueError("r21_transform_compile") from None
    return result


def _r21_source_transform(r20_raw: bytes, source):
    return _apply_active_outer_transform(
        r20_raw,
        source[0],
        source[2],
        source[1],
        _R21_OUTER_SUPPORT,
        tuple(sorted(_R21_OMITTED_PUBLIC)),
    )


_PATCH_LOCK = threading.Lock()
_PATCH_OWNER_THREAD: Optional[int] = None


def _call_with_r21_transform(call, r21_source):
    global _PATCH_OWNER_THREAD
    if not _PATCH_LOCK.acquire(blocking=False):
        raise ChildMainMapR21Blocked("r21_patch_context_busy")
    owner = threading.get_ident()
    original = _R20._apply_active_outer_transform
    calls = 0
    intact = True
    if _PATCH_OWNER_THREAD is not None or original is not _R20_ORIGINAL_APPLY:
        _PATCH_LOCK.release()
        raise ChildMainMapR21Blocked("r21_patch_context_changed")
    _PATCH_OWNER_THREAD = owner

    def apply_wrapper(*args: Any, **kwargs: Any) -> bytes:
        nonlocal calls
        if threading.get_ident() != owner:
            return original(*args, **kwargs)
        if _PATCH_OWNER_THREAD != owner or _R20._apply_active_outer_transform is not apply_wrapper:
            raise ChildMainMapR21Blocked("r21_patch_context_changed")
        calls += 1
        if calls != 1:
            raise ChildMainMapR21Blocked("r21_transform_count")
        try:
            r20_raw = original(*args, **kwargs)
            return _r21_source_transform(r20_raw, r21_source)
        except ChildMainMapR21Blocked:
            raise
        except BaseException:
            raise ChildMainMapR21Blocked("r21_outer_transform") from None

    _R20._apply_active_outer_transform = apply_wrapper
    result = None
    error = None
    try:
        result = call()
    except BaseException as exc:
        error = exc
    finally:
        intact = _R20._apply_active_outer_transform is apply_wrapper
        _R20._apply_active_outer_transform = original
        _PATCH_OWNER_THREAD = None
        _PATCH_LOCK.release()
    if error is not None:
        raise error
    _check(intact and calls == 1, "r21_patch_context_changed" if not intact else "r21_transform_count")
    return result


@dataclasses.dataclass(frozen=True)
class R21RootPreparedHold:
    """R20 validated preparation plus this exact R21 source row."""

    schema: str
    r20_result: Any
    r21_helper_path: str
    r21_helper_bytes: bytes
    r21_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def prepared_r13(self) -> Any:
        return self.r20_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r20_result.prepared_r14

    @property
    def r19_result(self) -> Any:
        return self.r20_result.r19_result

    @property
    def r17_result(self) -> Any:
        return self.r20_result.r17_result

    @property
    def runtime_source_map_path(self) -> str:
        return self.r20_result.runtime_source_map_path

    @property
    def runtime_source_map_sha256(self) -> str:
        return self.r20_result.runtime_source_map_sha256


def _add_r21_row(addition: dict[str, Any], source):
    path, raw, digest = source
    _check(_R13._R10._R9._absolute_windows_path(path), "r21_hold_schema")
    _check(type(raw) is bytes and _sha(raw) == digest, "r21_source_binding")
    result = copy.deepcopy(addition)
    entries = dict(result.get("entries", {}))
    target = _R13._R10._R9._normalized(path)
    _check(
        result.get("schema") == _R20._R16._R15.R15_HOLD_SCHEMA
        and result.get("canonical_child_map_count") == 154
        and all(_R13._R10._R9._normalized(existing) != target for existing in entries),
        "r21_hold_collision",
    )
    entries[path] = {
        "sha256": digest,
        "size_bytes": len(raw),
        "role": R21_SOURCE_ROLE,
        "origin": "repository_source:" + R21_RELATIVE_PATH,
    }
    result["entries"] = dict(sorted(entries.items()))
    return result, _sha(_canonical_json(result))


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R21RootPreparedHold:
    """Run the R20 same-call preparation with the exact R21 source transform."""
    source = _self_source()
    _check(type(_R20._apply_active_outer_transform) is type(_R20_ORIGINAL_APPLY), "r21_r20_source_binding")
    _check(_R20._apply_active_outer_transform is _R20_ORIGINAL_APPLY, "r21_r20_source_binding")
    try:
        r20_result = _call_with_r21_transform(
            lambda: _R20.prepare_root_hold(
                prepared_r31,
                root_metadata,
                environment=environment,
            ),
            source,
        )
    except ChildMainMapR21Blocked:
        raise
    except BaseException as exc:
        if isinstance(exc, _R20.ChildEntryPathR20Blocked):
            raise
        if isinstance(exc, _R19.ChildSourceScopeR19Blocked):
            raise
        if isinstance(exc, _R17.SourceMapGateR17Blocked):
            raise
        if isinstance(exc, _R18.ParentAdapterConstructorR18Blocked):
            raise
        raise ChildMainMapR21Blocked("r21_r20_prepare_blocked") from None
    _check(type(r20_result) is _R20.R20RootPreparedHold, "r21_r20_prepare_blocked")
    try:
        addition, digest = _add_r21_row(r20_result.hold_addition, source)
    except ChildMainMapR21Blocked:
        raise
    except BaseException:
        raise ChildMainMapR21Blocked("r21_hold_digest") from None
    return R21RootPreparedHold(
        schema=R21_RESULT_SCHEMA,
        r20_result=r20_result,
        r21_helper_path=source[0],
        r21_helper_bytes=source[1],
        r21_helper_sha256=source[2],
        hold_addition=addition,
        hold_addition_sha256=digest,
    )


def verify_root_hold(value: Any) -> bool:
    try:
        if type(value) is not R21RootPreparedHold or value.schema != R21_RESULT_SCHEMA:
            return False
        source = _self_source()
        if (value.r21_helper_path, value.r21_helper_bytes, value.r21_helper_sha256) != source:
            return False
        if not _R20.verify_root_hold(value.r20_result):
            return False
        addition, digest = _add_r21_row(value.r20_result.hold_addition, source)
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False


@dataclasses.dataclass(frozen=True)
class R21ParentAdapterResult:
    """R20 parent adapter plus this exact R21 source row and final digest."""

    schema: str
    prepared_hold: R21RootPreparedHold
    r20_adapter_result: Any
    adapter: Any
    r21_helper_path: str
    r21_helper_bytes: bytes
    r21_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    r13_recompose_calls: int
    r13_outer_transform_calls: int
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def r20_result(self) -> Any:
        return self.prepared_hold.r20_result

    @property
    def r19_result(self) -> Any:
        return self.r20_result.r19_result

    @property
    def r17_result(self) -> Any:
        return self.r20_result.r17_result

    @property
    def prepared_r13(self) -> Any:
        return self.r20_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r20_result.prepared_r14


def construct_parent_adapter(
    prepared_hold: Any,
    *,
    adapter_kwargs: Optional[dict[str, Any]] = None,
) -> R21ParentAdapterResult:
    """Construct the frozen R14 adapter while replaying R20 then exact R21."""
    source = _self_source()
    _check(verify_root_hold(prepared_hold), "r21_prepared_binding")
    try:
        r20_adapter_result = _call_with_r21_transform(
            lambda: _R20.construct_parent_adapter(
                prepared_hold.r20_result,
                adapter_kwargs=adapter_kwargs,
            ),
            source,
        )
    except ChildMainMapR21Blocked:
        raise
    except BaseException as exc:
        if isinstance(exc, _R20.ChildEntryPathR20Blocked):
            raise
        if isinstance(exc, _R19.ChildSourceScopeR19Blocked):
            raise
        if isinstance(exc, _R17.SourceMapGateR17Blocked):
            raise
        if isinstance(exc, _R13.ActiveOuterActivationBlocked):
            raise
        if isinstance(exc, _R18.ParentAdapterConstructorR18Blocked):
            raise
        raise ChildMainMapR21Blocked("r21_r20_adapter_blocked") from None
    _check(type(r20_adapter_result) is _R20.R20ParentAdapterResult, "r21_r20_adapter_blocked")
    try:
        addition, digest = _add_r21_row(r20_adapter_result.hold_addition, source)
    except ChildMainMapR21Blocked:
        raise
    except BaseException:
        raise ChildMainMapR21Blocked("r21_hold_digest") from None
    result = R21ParentAdapterResult(
        schema=R21_ADAPTER_RESULT_SCHEMA,
        prepared_hold=prepared_hold,
        r20_adapter_result=r20_adapter_result,
        adapter=r20_adapter_result.adapter,
        r21_helper_path=source[0],
        r21_helper_bytes=source[1],
        r21_helper_sha256=source[2],
        hold_addition=addition,
        hold_addition_sha256=digest,
        r13_recompose_calls=r20_adapter_result.r13_recompose_calls,
        r13_outer_transform_calls=r20_adapter_result.r13_outer_transform_calls,
    )
    _check(verify_parent_adapter_result(result), "r21_hold_digest")
    return result


def verify_parent_adapter_result(value: Any) -> bool:
    try:
        if type(value) is not R21ParentAdapterResult or value.schema != R21_ADAPTER_RESULT_SCHEMA:
            return False
        if not verify_root_hold(value.prepared_hold):
            return False
        source = _self_source()
        if (value.r21_helper_path, value.r21_helper_bytes, value.r21_helper_sha256) != source:
            return False
        if not _R20.verify_parent_adapter_result(value.r20_adapter_result):
            return False
        if value.adapter is not value.r20_adapter_result.adapter:
            return False
        if value.r13_recompose_calls != 1 or value.r13_outer_transform_calls != 1:
            return False
        expected, digest = _add_r21_row(value.r20_adapter_result.hold_addition, source)
        return (
            value.hold_addition == expected
            and value.hold_addition_sha256 == digest
            and value.hold_addition.get("canonical_child_map_count") == 154
        )
    except BaseException:
        return False
