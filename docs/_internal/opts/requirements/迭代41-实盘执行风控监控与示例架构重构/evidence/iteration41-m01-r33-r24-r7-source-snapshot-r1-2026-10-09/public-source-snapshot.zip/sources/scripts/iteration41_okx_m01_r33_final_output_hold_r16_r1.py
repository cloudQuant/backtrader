"""Single-call R16 preparation and parent-hold assembly for M01 R33.

R16 keeps the frozen R13/R14/R15 standalone APIs unchanged.  This composite
entrypoint starts from the same R31 inputs as Root, prepares and fully
revalidates the exact R13 child once, then carries immutable local facts
through the R14/R15 binding and final hold construction.  No facts escape as
validation authority; later calls must validate their own inputs.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as _R13
from scripts import iteration41_okx_m01_r33_final_output_hold_r15_r1 as _R15
from scripts import iteration41_okx_m01_r33_parent_adapter_transport_r14_r1 as _R14


R16_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_final_output_hold_r16_r1.py"
R16_RESULT_SCHEMA = "iteration41.okx.m01.r33.final-output-hold-r16.root-preparation.v1"
R16_MAX_SOURCE_BYTES = 2 * 1024 * 1024


class FinalOutputHoldR16Blocked(ValueError):
    """A current R31 input, final R13 output, or R14/R15 hold binding failed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise FinalOutputHoldR16Blocked(code)


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R16_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r16_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R16_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r16_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R16_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise FinalOutputHoldR16Blocked("r16_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R16_MAX_SOURCE_BYTES, "r16_source_size")
    return str(path), raw, _sha(raw)


@dataclasses.dataclass(frozen=True)
class _ValidatedR16Facts:
    """Immutable byte snapshot used only inside one composite call."""

    prepared_identity: int
    descriptor_json: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    binding_json: bytes
    transform_binding_json: bytes
    outer_binding_json: bytes
    binding_sha256: str
    active_outer_path: str
    active_outer_sha256: str
    plan_path: str
    plan_sha256: str


@dataclasses.dataclass(frozen=True)
class R16RootPreparedHold:
    """Exact R13/R14/R15 preparations and their final Root hold addition."""

    schema: str
    r16_helper_path: str
    r16_helper_bytes: bytes
    r16_helper_sha256: str
    prepared_r13: Any
    prepared_r14: Any
    prepared_r15: Any
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False


def _validated_r13_facts(
    prepared_r13: Any,
) -> tuple[_ValidatedR16Facts, tuple[dict[str, Any], dict[str, Any], dict[str, Any]]]:
    """Revalidate R13 fully and parse each final output once for this call."""
    _R13._validate_prepared(prepared_r13)
    try:
        descriptor = _R13._R10._R9._R4._validate_descriptor(prepared_r13.descriptor_json)
        source_map = _R13._R10._R9._R4._validate_source_map(
            prepared_r13.source_map_bytes, descriptor
        )
        manifest = _R13._R10._manifest_from_runner(prepared_r13.runner_bytes)
    except BaseException:
        raise FinalOutputHoldR16Blocked("r16_final_r13_outputs") from None

    runner_sha256 = _sha(prepared_r13.runner_bytes)
    source_map_sha256 = _sha(prepared_r13.source_map_bytes)
    binding = prepared_r13.binding
    _check(binding.get("runner_sha256") == runner_sha256, "r16_runner_binding")
    _check(binding.get("source_map_sha256") == source_map_sha256, "r16_source_map_binding")
    _check(descriptor.get("runner_sha256") == runner_sha256, "r16_descriptor_runner")
    _check(descriptor.get("source_map_sha256") == source_map_sha256, "r16_descriptor_source_map")
    _check(source_map.get("runner_template_sha256") == runner_sha256, "r16_map_runner")
    _check(
        source_map.get("manifest_binding_sha256") == manifest.get("manifest_binding_sha256"),
        "r16_map_manifest",
    )
    _check(
        manifest.get("manifest_binding_sha256") == binding.get("manifest_binding_sha256"),
        "r16_manifest_binding",
    )
    _check(
        descriptor.get("runtime_namespace") == source_map.get("runtime_namespace"),
        "r16_namespace_binding",
    )
    namespace = descriptor["runtime_namespace"]
    transform = binding.get("r13_transform_binding")
    _check(type(transform) is dict, "r16_transform_binding")
    _check(namespace.get("plan_path") == transform.get("plan_path"), "r16_plan_path_binding")
    _check(namespace.get("self_path") == transform.get("active_outer_path"), "r16_outer_path_binding")
    _check(
        manifest.get("candidate", {}).get("active_outer_sha256")
        == transform.get("active_outer_sha256"),
        "r16_manifest_outer_binding",
    )
    _check(
        namespace.get("active_wrapper_path")
        and manifest.get("candidate", {}).get("active_wrapper_sha256"),
        "r16_wrapper_binding",
    )
    runner_path = descriptor.get("runner_path")
    source_map_path = descriptor.get("source_map_path")
    _check(_R13._R10._R9._absolute_windows_path(runner_path), "r16_runner_path")
    _check(_R13._R10._R9._absolute_windows_path(source_map_path), "r16_source_map_path")
    _check(runner_path != source_map_path, "r16_output_path_collision")
    _check(
        binding.get("canonical_child_map_counts")
        == {"public": 118, "software": 36, "canonical": 154},
        "r16_child_map_count",
    )
    facts = _ValidatedR16Facts(
        prepared_identity=id(prepared_r13),
        descriptor_json=prepared_r13.descriptor_json,
        source_map_bytes=prepared_r13.source_map_bytes,
        runner_bytes=prepared_r13.runner_bytes,
        binding_json=_canonical_json(binding),
        transform_binding_json=_canonical_json(prepared_r13.transform_binding),
        outer_binding_json=_canonical_json(prepared_r13.outer_binding),
        binding_sha256=prepared_r13.binding_sha256,
        active_outer_path=transform["active_outer_path"],
        active_outer_sha256=transform["active_outer_sha256"],
        plan_path=transform["plan_path"],
        plan_sha256=transform["plan_sha256"],
    )
    return facts, (descriptor, source_map, manifest)


def _assert_facts_current(prepared_r13: Any, facts: _ValidatedR16Facts) -> None:
    """Catch in-call mutation without repeating the expensive source composition."""
    _check(id(prepared_r13) == facts.prepared_identity, "r16_facts_owner")
    _check(prepared_r13.descriptor_json == facts.descriptor_json, "r16_facts_descriptor_changed")
    _check(prepared_r13.source_map_bytes == facts.source_map_bytes, "r16_facts_map_changed")
    _check(prepared_r13.runner_bytes == facts.runner_bytes, "r16_facts_runner_changed")
    _check(_canonical_json(prepared_r13.binding) == facts.binding_json, "r16_facts_binding_changed")
    _check(
        _canonical_json(prepared_r13.transform_binding) == facts.transform_binding_json,
        "r16_facts_transform_changed",
    )
    _check(
        _canonical_json(prepared_r13.outer_binding) == facts.outer_binding_json,
        "r16_facts_outer_changed",
    )
    _check(prepared_r13.binding_sha256 == facts.binding_sha256, "r16_facts_binding_digest_changed")


def _prepare_r14_from_facts(prepared_r13: Any) -> Any:
    source = _R14._self_source()
    binding = _R14._adapter_binding(prepared_r13, source)
    return _R14.PreparedM01Child(
        r13_prepared=prepared_r13,
        helper_path=source[0],
        helper_bytes=source[1],
        helper_sha256=source[2],
        adapter_binding=binding,
        adapter_binding_sha256=_R14._binding_sha256(binding),
    )


def _prepare_r15_from_facts(
    prepared_r14: Any,
    facts: _ValidatedR16Facts,
    outputs: tuple[dict[str, Any], dict[str, Any], dict[str, Any]],
) -> Any:
    source = _R15._self_source()
    descriptor, _source_map, manifest = outputs
    helper_path, helper_raw, helper_sha256 = source
    runner_sha256 = _sha(facts.runner_bytes)
    source_map_sha256 = _sha(facts.source_map_bytes)
    binding = {
        "schema": _R15.R15_PREPARED_SCHEMA,
        "helper_path": helper_path,
        "helper_sha256": helper_sha256,
        "helper_size_bytes": len(helper_raw),
        "helper_role": _R15.R15_SOURCE_ROLE,
        "r14_binding_sha256": prepared_r14.adapter_binding_sha256,
        "r13_binding_sha256": facts.binding_sha256,
        "plan_path": facts.plan_path,
        "plan_sha256": facts.plan_sha256,
        "active_outer_path": facts.active_outer_path,
        "active_outer_sha256": facts.active_outer_sha256,
        "active_wrapper_path": descriptor["runtime_namespace"]["active_wrapper_path"],
        "active_wrapper_sha256": manifest["candidate"]["active_wrapper_sha256"],
        "runner_path": descriptor["runner_path"],
        "runner_sha256": runner_sha256,
        "runner_size_bytes": len(facts.runner_bytes),
        "source_map_path": descriptor["source_map_path"],
        "source_map_sha256": source_map_sha256,
        "source_map_size_bytes": len(facts.source_map_bytes),
        "manifest_binding_sha256": manifest["manifest_binding_sha256"],
        "runtime_namespace": dict(descriptor["runtime_namespace"]),
        "canonical_child_map_counts": {"public": 118, "software": 36, "canonical": 154},
        "authority": False,
    }
    prepared_r15 = _R15.PreparedM01Child(
        r14_prepared=prepared_r14,
        r15_helper_path=helper_path,
        r15_helper_bytes=helper_raw,
        r15_helper_sha256=helper_sha256,
        r15_binding=binding,
        r15_binding_sha256=_R15._binding_sha256(binding),
    )
    return prepared_r15


def _r13_hold_from_validated(prepared_r13: Any) -> dict[str, Any]:
    """Assemble R13 hold rows over a freshly validated R11 base hold."""
    base = _R13._R11.parent_hold_addition(prepared_r13.base_r11_prepared)
    _check(base.get("canonical_child_map_count") == 154, "r16_r11_child_map_count")
    _check(base.get("schema") == _R13._R11.R11_HOLD_SCHEMA, "r16_r11_parent_hold")
    entries = dict(base["entries"])
    binding = prepared_r13.transform_binding
    r10_path = binding["r10_composer_path"]
    r9 = _R13._R10._R9
    r10_key = r9._normalized(r10_path)
    r10_matches = [path for path in entries if r9._normalized(path) == r10_key]
    _check(len(r10_matches) == 1, "r16_r10_composer_hold_missing")
    r10_entry = entries[r10_matches[0]]
    _check(
        type(r10_entry) is dict
        and r10_entry.get("sha256") == binding["r10_composer_sha256"]
        and r10_entry.get("size_bytes") == binding["r10_composer_size_bytes"]
        and r10_entry.get("role") == _R13._R10.R10_COMPOSER_ROLE,
        "r16_r10_composer_hold_binding",
    )
    for row in binding["r10_external_source_rows"]:
        matches = [
            path for path in entries
            if r9._normalized(path) == r9._normalized(row["path"])
        ]
        _check(len(matches) == 1, "r16_r10_external_hold_missing")
        held = entries[matches[0]]
        _check(
            type(held) is dict
            and held.get("sha256") == row["sha256"]
            and held.get("size_bytes") == row["size_bytes"]
            and held.get("role") == row["role"]
            and held.get("origin") == row["origin"],
            "r16_r10_external_hold_binding",
        )
    once_path = prepared_r13.r10_prepared.once_path
    once_matches = [
        path for path in entries
        if r9._normalized(path) == r9._normalized(once_path)
    ]
    _check(len(once_matches) == 1, "r16_once_hold_anchor")
    once_key = once_matches[0]
    predecessor_once = prepared_r13.base_r11_prepared.r10_prepared.once_bytes
    _check(
        entries[once_key]
        == {
            "sha256": _sha(predecessor_once),
            "size_bytes": len(predecessor_once),
            "role": _R13._R10.R10_ONCE_ROLE,
        },
        "r16_once_hold_predecessor",
    )
    entries[once_key] = {
        "sha256": prepared_r13.r10_prepared.once_sha256,
        "size_bytes": prepared_r13.r10_prepared.once_size_bytes,
        "role": _R13._R10.R10_ONCE_ROLE,
        "origin": _R13.R13_ONCE_ORIGIN + ":" + _R13._R10.R28_ONCE_SHA256,
    }

    r12_path, r12_raw, r12_sha = prepared_r13.r12_dependency
    additions = (
        (
            r12_path,
            r12_raw,
            r12_sha,
            _R13.R13_R12_DEPENDENCY_ROLE,
            "repository_source:" + _R13._R12.R12_RELATIVE_PATH,
        ),
        (
            prepared_r13.sidecar_path,
            prepared_r13.bootstrap_bytes,
            prepared_r13.sidecar_sha256,
            _R13.R13_SIDECAR_ROLE,
            "generated_from_exact_r11_sidecar:" + prepared_r13.r11_prepared.sidecar_sha256,
        ),
        (
            prepared_r13.helper_path,
            prepared_r13.helper_bytes,
            prepared_r13.helper_sha256,
            _R13.R13_SOURCE_ROLE,
            "repository_source:" + _R13.R13_RELATIVE_PATH,
        ),
    )
    normalized = {r9._normalized(path) for path in entries}
    for path, raw, digest, role, origin in additions:
        _check(r9._absolute_windows_path(path), "r16_r13_hold_path")
        _check(type(raw) is bytes and _sha(raw) == digest, "r16_r13_hold_digest")
        key = r9._normalized(path)
        _check(key not in normalized, "r16_r13_hold_collision")
        normalized.add(key)
        entries[path] = {"sha256": digest, "size_bytes": len(raw), "role": role, "origin": origin}

    return {
        "schema": _R13.R13_HOLD_SCHEMA,
        "binding_sha256": prepared_r13.binding_sha256,
        "r11_binding_sha256": prepared_r13.r11_prepared.binding_sha256,
        "canonical_child_map_count": 154,
        "entries": dict(sorted(entries.items())),
        "once_path": once_path,
        "once_sha256": prepared_r13.r10_prepared.once_sha256,
        "once_size_bytes": prepared_r13.r10_prepared.once_size_bytes,
        "sidecar_path": prepared_r13.sidecar_path,
        "sidecar_sha256": prepared_r13.sidecar_sha256,
        "sidecar_size_bytes": prepared_r13.sidecar_size_bytes,
        "helper_path": prepared_r13.helper_path,
        "helper_sha256": prepared_r13.helper_sha256,
        "r12_dependency_path": r12_path,
        "r12_dependency_sha256": r12_sha,
        "r10_composer_path": r10_path,
        "r10_composer_sha256": binding["r10_composer_sha256"],
        "r10_composer_size_bytes": binding["r10_composer_size_bytes"],
        "r10_external_source_rows": list(binding["r10_external_source_rows"]),
        "reason_table_sha256": prepared_r13.reason_table_sha256,
        "transform_binding": dict(prepared_r13.transform_binding),
        "outer_binding": dict(prepared_r13.outer_binding),
    }


def _r14_hold_from_facts(base: dict[str, Any], prepared_r14: Any) -> dict[str, Any]:
    _check(
        base.get("canonical_child_map_count") == 154
        and base.get("schema") == _R13.R13_HOLD_SCHEMA,
        "r16_r14_r13_parent_hold",
    )
    entries = dict(base["entries"])
    r9 = _R13._R10._R9
    normalized = {r9._normalized(path) for path in entries}
    _check(r9._absolute_windows_path(prepared_r14.helper_path), "r16_r14_hold_path")
    helper_key = r9._normalized(prepared_r14.helper_path)
    _check(helper_key not in normalized, "r16_r14_hold_collision")
    _check(
        type(prepared_r14.helper_bytes) is bytes
        and len(prepared_r14.helper_bytes) == prepared_r14.adapter_binding["helper_size_bytes"]
        and _sha(prepared_r14.helper_bytes) == prepared_r14.helper_sha256,
        "r16_r14_hold_digest",
    )
    entries[prepared_r14.helper_path] = {
        "sha256": prepared_r14.helper_sha256,
        "size_bytes": len(prepared_r14.helper_bytes),
        "role": _R14.R14_SOURCE_ROLE,
        "origin": "repository_source:" + _R14.R14_RELATIVE_PATH,
    }
    result = dict(base)
    result.update(
        {
            "schema": _R14.R14_HOLD_SCHEMA,
            "r13_hold_schema": base["schema"],
            "r13_binding_sha256": prepared_r14.r13_prepared.binding_sha256,
            "r14_binding_sha256": prepared_r14.adapter_binding_sha256,
            "r14_helper_path": prepared_r14.helper_path,
            "r14_helper_sha256": prepared_r14.helper_sha256,
            "r14_helper_size_bytes": len(prepared_r14.helper_bytes),
            "r14_helper_role": _R14.R14_SOURCE_ROLE,
            "canonical_child_map_count": 154,
            "entries": dict(sorted(entries.items())),
        }
    )
    return result


def _r15_hold_from_facts(
    base: dict[str, Any],
    prepared_r14: Any,
    prepared_r15: Any,
    facts: _ValidatedR16Facts,
    outputs: tuple[dict[str, Any], dict[str, Any], dict[str, Any]],
) -> dict[str, Any]:
    _check(
        base.get("schema") == _R14.R14_HOLD_SCHEMA
        and base.get("canonical_child_map_count") == 154,
        "r16_r15_r14_parent_hold",
    )
    descriptor, _source_map, _manifest = outputs
    r13_prepared = prepared_r14.r13_prepared
    entries = dict(base["entries"])
    origin = "generated_from_exact_r13_binding:" + facts.binding_sha256
    _R15._replace_exact_entry(
        entries,
        descriptor["runner_path"],
        facts.runner_bytes,
        _R15.R15_RUNNER_ROLE,
        origin,
        r13_prepared.base_r11_prepared.r10_prepared.runner_bytes,
        "r10_generated_runner",
        "r16_runner_hold",
    )
    _R15._replace_exact_entry(
        entries,
        descriptor["source_map_path"],
        facts.source_map_bytes,
        _R15.R15_SOURCE_MAP_ROLE,
        origin,
        r13_prepared.base_r11_prepared.r10_prepared.source_map_bytes,
        "r10_generated_source_map",
        "r16_source_map_hold",
    )
    r9 = _R13._R10._R9
    _check(r9._absolute_windows_path(prepared_r15.r15_helper_path), "r16_r15_helper_path")
    helper_key = r9._normalized(prepared_r15.r15_helper_path)
    _check(helper_key not in {r9._normalized(path) for path in entries}, "r16_r15_helper_collision")
    entries[prepared_r15.r15_helper_path] = {
        "sha256": prepared_r15.r15_helper_sha256,
        "size_bytes": len(prepared_r15.r15_helper_bytes),
        "role": _R15.R15_SOURCE_ROLE,
        "origin": "repository_source:" + _R15.R15_RELATIVE_PATH,
    }
    result = dict(base)
    result.update(
        {
            "schema": _R15.R15_HOLD_SCHEMA,
            "r14_hold_schema": base["schema"],
            "r14_binding_sha256": prepared_r14.adapter_binding_sha256,
            "r15_binding_sha256": prepared_r15.r15_binding_sha256,
            "r15_helper_path": prepared_r15.r15_helper_path,
            "r15_helper_sha256": prepared_r15.r15_helper_sha256,
            "r15_helper_size_bytes": len(prepared_r15.r15_helper_bytes),
            "r15_helper_role": _R15.R15_SOURCE_ROLE,
            "final_runner_path": descriptor["runner_path"],
            "final_runner_sha256": prepared_r15.r15_binding["runner_sha256"],
            "final_runner_size_bytes": prepared_r15.r15_binding["runner_size_bytes"],
            "final_source_map_path": descriptor["source_map_path"],
            "final_source_map_sha256": prepared_r15.r15_binding["source_map_sha256"],
            "final_source_map_size_bytes": prepared_r15.r15_binding["source_map_size_bytes"],
            "plan_path": prepared_r15.r15_binding["plan_path"],
            "plan_sha256": prepared_r15.r15_binding["plan_sha256"],
            "active_outer_path": prepared_r15.r15_binding["active_outer_path"],
            "active_outer_sha256": prepared_r15.r15_binding["active_outer_sha256"],
            "active_wrapper_path": prepared_r15.r15_binding["active_wrapper_path"],
            "active_wrapper_sha256": prepared_r15.r15_binding["active_wrapper_sha256"],
            "manifest_binding_sha256": prepared_r15.r15_binding["manifest_binding_sha256"],
            "canonical_child_map_count": 154,
            "entries": dict(sorted(entries.items())),
        }
    )
    return result


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R16RootPreparedHold:
    """Prepare R13/R14/R15 and return the exact final hold in one call.

    Existing standalone preparation and hold APIs keep their own full
    validation behavior.  This function does not accept a validation flag or
    a cached proof; its private facts are created and consumed synchronously.
    """
    helper_path, helper_raw, helper_sha256 = _self_source()
    try:
        prepared_r13 = _R13.prepare_r33_child(
            prepared_r31, root_metadata, environment=environment
        )
    except BaseException:
        raise FinalOutputHoldR16Blocked("r16_r13_prepare") from None

    try:
        facts, outputs = _validated_r13_facts(prepared_r13)
        prepared_r14 = _prepare_r14_from_facts(prepared_r13)
        prepared_r15 = _prepare_r15_from_facts(prepared_r14, facts, outputs)
        r13_hold = _r13_hold_from_validated(prepared_r13)
        r14_hold = _r14_hold_from_facts(r13_hold, prepared_r14)
        hold_addition = _r15_hold_from_facts(
            r14_hold, prepared_r14, prepared_r15, facts, outputs
        )
    except FinalOutputHoldR16Blocked:
        raise
    except BaseException:
        raise FinalOutputHoldR16Blocked("r16_hold_assembly") from None

    _assert_facts_current(prepared_r13, facts)
    _check(hold_addition.get("canonical_child_map_count") == 154, "r16_final_child_map_count")
    _check(hold_addition.get("schema") == _R15.R15_HOLD_SCHEMA, "r16_final_hold_schema")
    _check(
        hold_addition.get("binding_sha256") == prepared_r13.binding_sha256
        and hold_addition.get("r14_binding_sha256") == prepared_r14.adapter_binding_sha256
        and hold_addition.get("r15_binding_sha256") == prepared_r15.r15_binding_sha256,
        "r16_final_hold_bindings",
    )
    hold_sha256 = _sha(_canonical_json(hold_addition))
    return R16RootPreparedHold(
        schema=R16_RESULT_SCHEMA,
        r16_helper_path=helper_path,
        r16_helper_bytes=helper_raw,
        r16_helper_sha256=helper_sha256,
        prepared_r13=prepared_r13,
        prepared_r14=prepared_r14,
        prepared_r15=prepared_r15,
        hold_addition=hold_addition,
        hold_addition_sha256=hold_sha256,
    )


if __name__ == "__main__":
    raise SystemExit("Call prepare_root_hold() with current R31 inputs and Root metadata.")
