"""Root-controlled installer and launcher template for OKX L03/L04 V4.

This template pins the reviewed public V4 packet and the independent GO report.
The root admission reference deliberately remains UNSET. Installation and case
execution stay closed until the root fills that constant in its reviewed copy.
The script has no configurable repository, profile, credential, endpoint, or
output path.

The V4 case process remains the typed evidence issuer. This outer launcher
holds the registration and source closure stable, then cross-checks the V4
summary against the new owner-only run directory and its typed private audit.
"""

from __future__ import annotations

from contextlib import ExitStack, contextmanager
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
from typing import Any
import zipfile


PROFILE = "OKX_L03_L04_FIXED_READONLY_V4"
VENUE = "okx"
ENVIRONMENT = "demo"
REGION = "global"
ENDPOINT = "https://openapi.okx.com"
CASES = frozenset({"L03", "L04"})

# The launcher is copied outside the checkout; never infer the checkout root
# from its own location or the caller's working directory.
REPO_ROOT = Path(r"D:\source_code\backtrader")
OKX_ROOT_REL = Path("examples/000_live_certification/okx_penetration")
SOURCE_PACKET_REL = Path(
    "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/"
    "iteration41-okx-l03-l04-fixed-readonly-v4-source-fake-2026-10-03"
)
REVIEW_PACKET_REL = Path(
    "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/"
    "iteration41-okx-l03-l04-fixed-readonly-v4-independent-review-go-r1-2026-10-03"
)
SOURCE_ZIP_SHA256 = "0f907a798c297814af5ee59039e1b6c0de8587a1cb62db7f21fff6ee04e6a0eb"
SOURCE_INDEX_SHA256 = "6134f9889667ea255d7b7db8e5d1bd57e53429b4a9c1e25f1b16df4a1858316c"
SOURCE_CHECKPOINT_SHA256 = "e522a5ddec5e2b7f8f98259b1271b89f146c0727eea0739a34ab5c7c1d42b204"
SOURCE_MAP_SHA256 = "ae78a1e30b3fe8b040d70c6a76433669f0258d0f4ae042ec6ea567c3864e0ac3"
REVIEW_JSON_SHA256 = "60ced8c738e4c0bca88f6e23ac5d3c39f2e296d28fa29bcfee6a3db2af8c855f"
REVIEW_README_SHA256 = "034ba1682fd18f21e5f0b8c3add1d4fde82907a8e870b49170d396975a60bc47"
PRIVATE_API_SHA256 = "b866194bdc56d91cc7a6678e83b0af8e4e018ee53a2c136325344c2ee8a5ecfd"

# Root fills these fields only in its reviewed launcher copy after installing
# the approved one-case registration plan. The checked-in template stays shut.
ROOT_ADMISSION_STATUS = "UNSET"
ROOT_ADMISSION_REF_SHA256 = "UNSET"

MAX_PUBLIC_FILE_BYTES = 8 * 1024 * 1024
MAX_AUDIT_BYTES = 256 * 1024
MAX_CHILD_STDOUT_BYTES = 64 * 1024
MAX_CHILD_STDERR_BYTES = 16 * 1024
CHILD_TIMEOUT_SECONDS = 150
CHILD_REAP_TIMEOUT_SECONDS = 5
_THREAD_SUSPEND_RESUME = 0x0002
_THREAD_QUERY_LIMITED_INFORMATION = 0x0800
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_NONCE = re.compile(r"[0-9a-f]{32}\Z")


class _JobBasicLimitInformation(C.Structure):
    _fields_ = [
        ("per_process_user_time", C.c_longlong),
        ("per_job_user_time", C.c_longlong),
        ("limit_flags", W.DWORD),
        ("minimum_working_set", C.c_size_t),
        ("maximum_working_set", C.c_size_t),
        ("active_process_limit", W.DWORD),
        ("affinity", C.c_size_t),
        ("priority_class", W.DWORD),
        ("scheduling_class", W.DWORD),
    ]


class _JobIoCounters(C.Structure):
    _fields_ = [(name, C.c_ulonglong) for name in (
        "read_operations", "write_operations", "other_operations",
        "read_bytes", "write_bytes", "other_bytes",
    )]


class _JobExtendedLimitInformation(C.Structure):
    _fields_ = [
        ("basic", _JobBasicLimitInformation),
        ("io", _JobIoCounters),
        ("process_memory_limit", C.c_size_t),
        ("job_memory_limit", C.c_size_t),
        ("peak_process_memory_used", C.c_size_t),
        ("peak_job_memory_used", C.c_size_t),
    ]


class _JobBasicAccountingInformation(C.Structure):
    _fields_ = [
        ("total_user_time", C.c_longlong),
        ("total_kernel_time", C.c_longlong),
        ("this_period_total_user_time", C.c_longlong),
        ("this_period_total_kernel_time", C.c_longlong),
        ("total_page_faults", W.DWORD),
        ("total_processes", W.DWORD),
        ("active_processes", W.DWORD),
        ("total_terminated_processes", W.DWORD),
    ]


class _ThreadEntry32(C.Structure):
    _fields_ = [
        ("size", W.DWORD),
        ("usage", W.DWORD),
        ("thread_id", W.DWORD),
        ("owner_process_id", W.DWORD),
        ("base_priority", W.LONG),
        ("delta_priority", W.LONG),
        ("flags", W.DWORD),
    ]


class _WinJobNative:
    """Small fixed Win32 Job/Toolhelp surface used only for the case child."""

    def __init__(self):
        if os.name != "nt":
            raise LauncherBlocked("windows_job_required")
        try:
            self.kernel = C.WinDLL("kernel32", use_last_error=True)
            self.CreateJobObjectW = self.kernel.CreateJobObjectW
            self.CreateJobObjectW.argtypes = [C.c_void_p, W.LPCWSTR]
            self.CreateJobObjectW.restype = W.HANDLE
            self.SetInformationJobObject = self.kernel.SetInformationJobObject
            self.SetInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD]
            self.SetInformationJobObject.restype = W.BOOL
            self.AssignProcessToJobObject = self.kernel.AssignProcessToJobObject
            self.AssignProcessToJobObject.argtypes = [W.HANDLE, W.HANDLE]
            self.AssignProcessToJobObject.restype = W.BOOL
            self.TerminateJobObject = self.kernel.TerminateJobObject
            self.TerminateJobObject.argtypes = [W.HANDLE, W.UINT]
            self.TerminateJobObject.restype = W.BOOL
            self.QueryInformationJobObject = self.kernel.QueryInformationJobObject
            self.QueryInformationJobObject.argtypes = [
                W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD)
            ]
            self.QueryInformationJobObject.restype = W.BOOL
            self.CloseHandle = self.kernel.CloseHandle
            self.CloseHandle.argtypes = [W.HANDLE]
            self.CloseHandle.restype = W.BOOL
            self.CreateToolhelp32Snapshot = self.kernel.CreateToolhelp32Snapshot
            self.CreateToolhelp32Snapshot.argtypes = [W.DWORD, W.DWORD]
            self.CreateToolhelp32Snapshot.restype = W.HANDLE
            self.Thread32First = self.kernel.Thread32First
            self.Thread32First.argtypes = [W.HANDLE, C.POINTER(_ThreadEntry32)]
            self.Thread32First.restype = W.BOOL
            self.Thread32Next = self.kernel.Thread32Next
            self.Thread32Next.argtypes = [W.HANDLE, C.POINTER(_ThreadEntry32)]
            self.Thread32Next.restype = W.BOOL
            self.OpenThread = self.kernel.OpenThread
            self.OpenThread.argtypes = [W.DWORD, W.BOOL, W.DWORD]
            self.OpenThread.restype = W.HANDLE
            self.GetProcessIdOfThread = self.kernel.GetProcessIdOfThread
            self.GetProcessIdOfThread.argtypes = [W.HANDLE]
            self.GetProcessIdOfThread.restype = W.DWORD
            self.ResumeThread = self.kernel.ResumeThread
            self.ResumeThread.argtypes = [W.HANDLE]
            self.ResumeThread.restype = W.DWORD
        except Exception:
            raise LauncherBlocked("windows_job_api_unavailable") from None

    def create_job(self):
        handle = self.CreateJobObjectW(None, None)
        if not handle:
            raise LauncherBlocked("windows_job_create")
        information = _JobExtendedLimitInformation()
        information.basic.limit_flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE.
        if not self.SetInformationJobObject(
            handle, 9, C.byref(information), C.sizeof(information)
        ):
            self.CloseHandle(handle)
            raise LauncherBlocked("windows_job_configuration")
        return handle

    def assign(self, job, process):
        try:
            process_handle = W.HANDLE(int(process._handle))
        except Exception:
            raise LauncherBlocked("windows_job_process_handle") from None
        if not self.AssignProcessToJobObject(job, process_handle):
            raise LauncherBlocked("windows_job_assignment")

    def resume_initial_thread(self, process_id):
        snapshot = self.CreateToolhelp32Snapshot(0x4, 0)  # TH32CS_SNAPTHREAD.
        if snapshot in (C.c_void_p(-1).value, -1):
            raise LauncherBlocked("windows_job_thread_snapshot")
        thread_handle = None
        try:
            entry = _ThreadEntry32()
            entry.size = C.sizeof(entry)
            matches = []
            if self.Thread32First(snapshot, C.byref(entry)):
                while True:
                    if entry.owner_process_id == process_id:
                        matches.append(entry.thread_id)
                    if not self.Thread32Next(snapshot, C.byref(entry)):
                        break
                    entry.size = C.sizeof(entry)
            if len(matches) != 1:
                raise LauncherBlocked("windows_job_initial_thread_count")
            thread_access = _THREAD_SUSPEND_RESUME | _THREAD_QUERY_LIMITED_INFORMATION
            thread_handle = self.OpenThread(thread_access, False, matches[0])
            if not thread_handle or self.GetProcessIdOfThread(thread_handle) != process_id:
                raise LauncherBlocked("windows_job_initial_thread_owner")
            previous = self.ResumeThread(thread_handle)
            if previous != 1:
                raise LauncherBlocked("windows_job_initial_thread_resume")
        finally:
            if thread_handle and not self.CloseHandle(thread_handle):
                raise LauncherBlocked("windows_job_thread_close")
            if not self.CloseHandle(snapshot):
                raise LauncherBlocked("windows_job_snapshot_close")

    def terminate(self, job):
        if job and not self.TerminateJobObject(job, 0xE0000001):
            raise LauncherBlocked("windows_job_terminate")

    def active_processes(self, job):
        info = _JobBasicAccountingInformation()
        returned = W.DWORD()
        if not self.QueryInformationJobObject(
            job, 1, C.byref(info), C.sizeof(info), C.byref(returned)
        ) or returned.value < C.sizeof(info):
            raise LauncherBlocked("windows_job_accounting")
        return int(info.active_processes)

    def close(self, job):
        if job and not self.CloseHandle(job):
            raise LauncherBlocked("windows_job_close")


class _WindowsProcessJob:
    """Own a kill-on-close Job and resume exactly one suspended case process."""

    def __init__(self, native=None):
        if native is None:
            native = _WinJobNative()
        self._native = native
        try:
            self._handle = native.create_job()
        except LauncherBlocked:
            raise
        except Exception:
            raise LauncherBlocked("windows_job_create") from None
        if not self._handle:
            raise LauncherBlocked("windows_job_create")
        self._process = None
        self._forced = False

    def __enter__(self):
        return self

    def spawn(self, command, **kwargs):
        process = None
        try:
            flags = kwargs.pop("creationflags", 0)
            process = subprocess.Popen(
                command,
                creationflags=flags | 0x4,  # CREATE_SUSPENDED.
                **kwargs,
            )
            self._process = process
            self._native.assign(self._handle, process)
            self._native.resume_initial_thread(process.pid)
            return process
        except Exception:
            try:
                self._native.terminate(self._handle)
            except Exception:
                pass
            if process is not None:
                try:
                    process.kill()
                except Exception:
                    pass
                try:
                    process.wait(timeout=CHILD_REAP_TIMEOUT_SECONDS)
                except Exception:
                    pass
                for stream in (process.stdin, process.stdout, process.stderr):
                    if stream is not None:
                        try:
                            stream.close()
                        except Exception:
                            pass
            raise LauncherBlocked("windows_job_spawn") from None

    def terminate(self, process=None):
        self._forced = True
        try:
            self._native.terminate(self._handle)
        finally:
            if process is not None:
                try:
                    process.kill()
                except Exception:
                    pass

    def active_processes(self) -> int:
        try:
            return self._native.active_processes(self._handle)
        except Exception:
            raise LauncherBlocked("windows_job_accounting") from None

    @property
    def was_forced(self) -> bool:
        return self._forced

    def __exit__(self, exc_type, exc, traceback):
        cleanup_failed = False
        try:
            try:
                try:
                    active = self.active_processes()
                except Exception:
                    active = None
                    cleanup_failed = True
                if active != 0:
                    self.terminate()
                    deadline = time.monotonic() + CHILD_REAP_TIMEOUT_SECONDS
                    while active != 0 and time.monotonic() < deadline:
                        time.sleep(0.05)
                        try:
                            active = self.active_processes()
                        except Exception:
                            active = None
                            cleanup_failed = True
                    cleanup_failed = cleanup_failed or active != 0
            except Exception:
                try:
                    self.terminate()
                except Exception:
                    pass
                cleanup_failed = True
        finally:
            self._native.close(self._handle)
            self._handle = None
        if cleanup_failed:
            raise LauncherBlocked("windows_job_tree_not_empty")
        return False


class LauncherBlocked(ValueError):
    """Fixed launcher refusal codes; never include private values or paths."""


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise LauncherBlocked(reason)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _canonical(value: Any) -> bytes:
    try:
        return json.dumps(
            value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False
        ).encode("ascii")
    except Exception:
        raise LauncherBlocked("json_invalid") from None


def _strict_json(raw: bytes) -> Any:
    def pairs(items):
        output = {}
        for key, value in items:
            if key in output:
                raise ValueError("duplicate")
            output[key] = value
        return output

    try:
        return json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs)
    except Exception:
        raise LauncherBlocked("json_invalid") from None


def _read_stable(path: Path, limit: int) -> bytes:
    try:
        info = path.lstat()
        _require(
            not info.st_file_attributes & 0x400
            and not path.is_symlink()
            and info.st_size <= limit
            and path.is_file(),
            "public_file_shape",
        )
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags)
        try:
            before = os.fstat(descriptor)
            chunks = []
            total = 0
            while total <= limit:
                chunk = os.read(descriptor, min(65536, limit + 1 - total))
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk)
            after = os.fstat(descriptor)
        finally:
            os.close(descriptor)
    except LauncherBlocked:
        raise
    except Exception:
        raise LauncherBlocked("public_file_unavailable") from None
    _require(
        total <= limit
        and total == before.st_size
        and (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
        == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
        and (before.st_dev, before.st_ino) == (info.st_dev, info.st_ino),
        "public_file_changed",
    )
    return b"".join(chunks)


def _source_members(index: Any) -> tuple[dict[str, Any], dict[str, str]]:
    _require(
        type(index) is dict
        and set(index) == {"schema", "profile", "scope", "source_map_sha256", "members"}
        and index.get("schema") == "okx-fixed-readonly-v4-source-index-v1"
        and index.get("profile") == PROFILE
        and index.get("scope") == "public source closure plus focused fake tests only"
        and type(index.get("members")) is list
        and len(index["members"]) == 30,
        "source_index_shape",
    )
    rows: dict[str, Any] = {}
    source_map: dict[str, str] = {}
    test_count = 0
    for row in index["members"]:
        _require(
            type(row) is dict
            and set(row) == {"kind", "path", "sha256", "size_bytes"}
            and type(row.get("path")) is str
            and type(row.get("sha256")) is str
            and _HEX64.fullmatch(row["sha256"]) is not None
            and type(row.get("size_bytes")) is int
            and 0 <= row["size_bytes"] <= MAX_PUBLIC_FILE_BYTES,
            "source_index_row",
        )
        path = row["path"]
        _require(
            path not in rows
            and "\\" not in path
            and not path.startswith("/")
            and all(part not in {"", ".", ".."} for part in path.split("/")),
            "source_index_path",
        )
        rows[path] = row
        if row["kind"] == "production_source":
            source_map[path] = row["sha256"]
        elif row["kind"] == "focused_fake_test":
            test_count += 1
        else:
            raise LauncherBlocked("source_index_kind")
    _require(len(source_map) == 24 and test_count == 6, "source_index_counts")
    map_digest = _sha(_canonical(dict(sorted(source_map.items()))))
    _require(
        map_digest == index.get("source_map_sha256") == SOURCE_MAP_SHA256,
        "source_map_digest",
    )
    return rows, source_map


def verify_public_bundle(repo_root: Path = REPO_ROOT) -> tuple[dict[str, str], dict[str, Any]]:
    """Verify exact V4 archive, index, checkpoint, review, and all 30 files."""
    _require(isinstance(repo_root, Path) and repo_root.is_absolute(), "repo_root")
    packet = repo_root / SOURCE_PACKET_REL
    review_dir = repo_root / REVIEW_PACKET_REL
    index_raw = _read_stable(packet / "source-index.json", 1024 * 1024)
    archive_raw = _read_stable(packet / "source.zip", MAX_PUBLIC_FILE_BYTES)
    checkpoint_raw = _read_stable(packet / "checkpoint.json", 128 * 1024)
    review_raw = _read_stable(review_dir / "review.json", 512 * 1024)
    review_readme = _read_stable(review_dir / "README.md", 256 * 1024)
    _require(_sha(index_raw) == SOURCE_INDEX_SHA256, "source_index_pin")
    _require(_sha(archive_raw) == SOURCE_ZIP_SHA256, "source_archive_pin")
    _require(_sha(checkpoint_raw) == SOURCE_CHECKPOINT_SHA256, "source_checkpoint_pin")
    _require(_sha(review_raw) == REVIEW_JSON_SHA256, "review_pin")
    _require(_sha(review_readme) == REVIEW_README_SHA256, "review_readme_pin")

    index = _strict_json(index_raw)
    rows, source_map = _source_members(index)
    checkpoint = _strict_json(checkpoint_raw)
    _require(
        type(checkpoint) is dict
        and checkpoint.get("schema") == "okx-fixed-readonly-v4-source-checkpoint-v1"
        and checkpoint.get("profile") == PROFILE
        and checkpoint.get("registered_source_map_sha256") == SOURCE_MAP_SHA256
        and checkpoint.get("source_archive") == {"path": "source.zip", "sha256": SOURCE_ZIP_SHA256}
        and checkpoint.get("source_index")
        == {"path": "source-index.json", "sha256": SOURCE_INDEX_SHA256},
        "source_checkpoint_binding",
    )
    review = _strict_json(review_raw)
    _require(
        type(review) is dict
        and review.get("schema") == "iteration41.okx.l03_l04.fixed_readonly_v4.independent_review.v1"
        and review.get("result") == "GO"
        and type(review.get("source_packet")) is dict
        and review["source_packet"].get("zip_sha256") == SOURCE_ZIP_SHA256
        and review["source_packet"].get("source_index_sha256") == SOURCE_INDEX_SHA256
        and review["source_packet"].get("checkpoint_sha256") == SOURCE_CHECKPOINT_SHA256
        and review["source_packet"].get("source_map_sha256") == SOURCE_MAP_SHA256
        and review["source_packet"].get("production_source_members") == 24
        and review["source_packet"].get("focused_fake_test_members") == 6
        and review["source_packet"].get("archive_total_members") == 30,
        "review_binding",
    )

    try:
        with zipfile.ZipFile(packet / "source.zip", "r") as archive:
            names = archive.namelist()
            _require(len(names) == 30 and len(set(names)) == 30 and set(names) == set(rows), "archive_members")
            for name, row in rows.items():
                raw = archive.read(name)
                _require(len(raw) == row["size_bytes"] and _sha(raw) == row["sha256"], "archive_member_digest")
                current = _read_stable(repo_root / Path(*name.split("/")), MAX_PUBLIC_FILE_BYTES)
                _require(current == raw, "workspace_source_changed")
    except LauncherBlocked:
        raise
    except Exception:
        raise LauncherBlocked("source_archive_invalid") from None
    return source_map, review


def _assert_root_admission() -> None:
    _require(
        type(ROOT_ADMISSION_STATUS) is str
        and ROOT_ADMISSION_STATUS == "ROOT_APPROVED_FIXED_READONLY_L03_L04"
        and type(ROOT_ADMISSION_REF_SHA256) is str
        and _HEX64.fullmatch(ROOT_ADMISSION_REF_SHA256) is not None,
        "root_admission_unset",
    )


def _import_profile(repo_root: Path):
    venue_root = repo_root / OKX_ROOT_REL
    _require(venue_root.is_dir(), "profile_source_missing")
    if str(venue_root) not in sys.path:
        sys.path.insert(0, str(venue_root))
    try:
        from _l03_l04_case_v4 import source_profile
    except Exception:
        raise LauncherBlocked("profile_source_unavailable") from None
    _require(
        source_profile.PROFILE == PROFILE
        and Path(r"D:\temp\iteration41-okx-l03-l04-case-v4-deployment") == source_profile.DEPLOYMENT_ROOT
        and source_profile.PRIVATE_API_SHA256 == PRIVATE_API_SHA256,
        "profile_constants_mismatch",
    )
    return source_profile


def registration_template() -> dict[str, Any]:
    """Return the exact two-case schema V4 accepts, for root review only."""
    source_map, _review = verify_public_bundle()
    profile = _import_profile(REPO_ROOT)
    current_map = profile.current_source_map()
    _require(current_map == source_map, "source_map_recomputation")
    return profile.registration_document(current_map, tuple(sorted(CASES)))


@contextmanager
def _held_object(private_module, api, path: Path, *, directory: bool, protected: bool):
    """Open with FILE_SHARE_READ only, verify identity/ACL, and retain handle."""
    access = 0x80 | (0x20000 if protected else 0)
    if not directory:
        access |= 0x80000000
    handle = api.CreateFileW(str(path), access, 0x1, None, 3, 0x02200000, None)
    if handle in (private_module._INVALID_HANDLE, -1):
        raise LauncherBlocked("readonly_lease_open")
    try:
        identity = api.info(handle, directory=directory)
        if protected:
            api.verify_acl(handle, api.current_sid(), directory=directory)
        yield handle, identity
        _require(api.info(handle, directory=directory) == identity, "readonly_lease_identity_changed")
        if protected:
            api.verify_acl(handle, api.current_sid(), directory=directory)
    except LauncherBlocked:
        raise
    except Exception:
        raise LauncherBlocked("readonly_lease_verification") from None
    finally:
        try:
            if not api.CloseHandle(handle):
                raise LauncherBlocked("readonly_lease_close")
        except LauncherBlocked:
            raise
        except Exception:
            raise LauncherBlocked("readonly_lease_close") from None


def _registration_document_hash(profile, lease) -> str:
    raw = _read_stable(lease.registration_path, profile.MAX_REGISTRATION_BYTES)
    _require(_sha(raw) == lease.registration_sha256, "registration_hash_changed")
    parsed = profile._strict_json(raw)
    _require(
        profile.validate_registration_document(
            parsed, case_id=lease.case_id, expected_source_map=dict(lease.source_map)
        )
        == parsed,
        "registration_document_invalid",
    )
    return _sha(raw)


@contextmanager
def _invocation_leases(profile, lease, source_map: dict[str, str], repo_root: Path):
    private_module = profile.private_artifacts_api()
    api = private_module._api()
    registration_path = lease.registration_path

    with ExitStack() as stack:
        # Keep owner-only directory identities open with read sharing only.
        # The private module's own verifier is also used as a second check.
        root_handle, root_identity = stack.enter_context(
            _held_object(
                private_module, api, profile.DEPLOYMENT_ROOT,
                directory=True, protected=True,
            )
        )
        runs_handle, runs_identity = stack.enter_context(
            _held_object(
                private_module, api, lease.evidence_parent,
                directory=True, protected=True,
            )
        )
        root_dir = private_module.PrivateArtifactDirectory(
            profile.DEPLOYMENT_ROOT, root_identity[0], root_identity[1]
        )
        runs_dir = private_module.PrivateArtifactDirectory(
            lease.evidence_parent, runs_identity[0], runs_identity[1]
        )
        stack.enter_context(root_dir._verified())
        stack.enter_context(runs_dir._verified())

        # The root-owned registration file is held open with FILE_SHARE_READ
        # only, denying write and delete sharing until all child work completes.
        reg_handle, reg_identity = stack.enter_context(
            _held_object(
                private_module, api, registration_path,
                directory=False, protected=True,
            )
        )
        _require(_registration_document_hash(profile, lease) == lease.registration_sha256, "registration_hash")
        _require(api.info(reg_handle, directory=False) == reg_identity, "registration_identity")

        # Hold all indexed source/test files and exact public packet files with
        # read-only sharing for the complete invocation.
        packet = repo_root / SOURCE_PACKET_REL
        review_dir = repo_root / REVIEW_PACKET_REL
        public_paths = [
            packet / "source.zip",
            packet / "source-index.json",
            packet / "checkpoint.json",
            review_dir / "review.json",
            review_dir / "README.md",
        ]
        public_paths.extend(repo_root / Path(*member.split("/")) for member in source_map)
        for path in public_paths:
            stack.enter_context(
                _held_object(
                    private_module, api, path, directory=False, protected=False
                )
            )
        _require(verify_public_bundle(repo_root)[0] == source_map, "held_public_bundle_changed")
        _require(_registration_document_hash(profile, lease) == lease.registration_sha256, "registration_hash")
        yield private_module, api, root_dir, runs_dir
        _require(_registration_document_hash(profile, lease) == lease.registration_sha256, "registration_hash")
        _require(api.info(reg_handle, directory=False) == reg_identity, "registration_identity")
        _require(api.info(root_handle, directory=True) == root_identity, "deployment_identity")
        _require(api.info(runs_handle, directory=True) == runs_identity, "runs_identity")


def _create_registration(profile, source_map: dict[str, str]) -> str:
    private_module = profile.private_artifacts_api()
    deployment = profile.DEPLOYMENT_ROOT
    _require(not os.path.lexists(deployment), "registration_root_exists")
    root_dir = private_module.create_private_directory(deployment)
    runs_dir = private_module.create_private_directory(deployment / profile.RUNS_NAME)
    root_dir.verify()
    runs_dir.verify()
    document = profile.registration_document(source_map, tuple(sorted(CASES)))
    digest = root_dir.write_json(profile.REGISTRATION_NAME, document)
    _require(type(digest) is str and _HEX64.fullmatch(digest) is not None, "registration_write_digest")
    for case_id in sorted(CASES):
        lease = profile.load_registered_profile(case_id)
        profile.verify_lease(lease)
        _require(lease.registration_sha256 == digest, "registration_file_hash")
    return digest


def _isolated_launcher() -> bool:
    flags = getattr(sys, "flags", None)
    return type(flags) is type(sys.flags) and all(
        type(getattr(flags, name, None)) is int and getattr(flags, name) == 1
        for name in ("isolated", "no_site", "dont_write_bytecode")
    )


def _bounded_communicate(process, timeout_seconds: int, job=None) -> tuple[bytes, bytes]:
    """Drain both child pipes concurrently with hard byte and time bounds."""
    if (
        process.stdout is None
        or process.stderr is None
        or type(timeout_seconds) is not int
        or timeout_seconds <= 0
    ):
        raise LauncherBlocked("child_pipe_setup")
    limits = {"stdout": MAX_CHILD_STDOUT_BYTES, "stderr": MAX_CHILD_STDERR_BYTES}
    collected: dict[str, bytes] = {}
    eof: dict[str, bool] = {"stdout": False, "stderr": False}
    errors: list[str] = []
    overflow = threading.Event()

    def terminate_tree() -> None:
        if job is not None:
            try:
                job.terminate(process)
            except Exception:
                errors.append("job_terminate")
        try:
            process.kill()
        except Exception:
            pass

    def drain(name: str, stream) -> None:
        chunks: list[bytes] = []
        total = 0
        try:
            while True:
                chunk = stream.read(4096)
                if not chunk:
                    eof[name] = True
                    break
                room = max(0, limits[name] + 1 - total)
                if room:
                    chunks.append(chunk[:room])
                total += len(chunk)
                if total > limits[name]:
                    overflow.set()
                    terminate_tree()
            collected[name] = b"".join(chunks)
        except Exception:
            errors.append(name)
            terminate_tree()
        finally:
            try:
                stream.close()
            except Exception:
                errors.append(name + "_close")

    threads = (
        threading.Thread(target=drain, args=("stdout", process.stdout), daemon=True),
        threading.Thread(target=drain, args=("stderr", process.stderr), daemon=True),
    )
    for thread in threads:
        thread.start()
    timed_out = False
    try:
        process.wait(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        terminate_tree()
        try:
            process.wait(timeout=CHILD_REAP_TIMEOUT_SECONDS)
        except Exception:
            pass
    except Exception:
        terminate_tree()
        try:
            process.wait(timeout=CHILD_REAP_TIMEOUT_SECONDS)
        except Exception:
            pass
        errors.append("wait")

    for thread in threads:
        thread.join(CHILD_REAP_TIMEOUT_SECONDS)
    if any(thread.is_alive() for thread in threads):
        terminate_tree()
        for stream in (process.stdout, process.stderr):
            try:
                stream.close()
            except Exception:
                pass
        for thread in threads:
            thread.join(CHILD_REAP_TIMEOUT_SECONDS)
        errors.append("pipe_eof")

    try:
        returncode = process.wait(timeout=CHILD_REAP_TIMEOUT_SECONDS)
    except Exception:
        returncode = None
    job_processes = 0
    if job is not None:
        try:
            job_processes = job.active_processes()
        except Exception:
            job_processes = -1
        if job_processes != 0:
            terminate_tree()
    if (
        timed_out
        or overflow.is_set()
        or errors
        or not all(eof.values())
        or returncode is None
        or job is not None and job_processes != 0
        or type(returncode) is not int
        or process.poll() != returncode
        or process.stdout is None
        or not process.stdout.closed
        or process.stderr is None
        or not process.stderr.closed
    ):
        raise LauncherBlocked("child_pipe_lifecycle")
    return collected.get("stdout", b""), collected.get("stderr", b"")


def _children_snapshot(runs_path: Path) -> dict[str, tuple[int, int, int, int, bool]]:
    try:
        rows = {}
        for path in runs_path.iterdir():
            info = path.lstat()
            is_directory = path.is_dir() and not path.is_symlink() and not info.st_file_attributes & 0x400
            _require(_NONCE.fullmatch(path.name) is not None and is_directory, "run_namespace_entry")
            rows[path.name] = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, is_directory)
        return rows
    except LauncherBlocked:
        raise
    except Exception:
        raise LauncherBlocked("run_namespace_unavailable") from None


def _strict_summary(raw: bytes, case_id: str) -> dict[str, Any]:
    _require(type(raw) is bytes and 0 < len(raw) <= MAX_CHILD_STDOUT_BYTES, "child_stdout_size")
    _require(raw.endswith(b"\n") and raw.count(b"\n") == 1, "child_stdout_shape")
    doc = _strict_json(raw[:-1])
    expected = {
        "profile", "venue", "environment", "case_id", "status", "reason",
        "receipt_count", "observation_count", "private_audit_sha256",
        "source_map_sha256", "completed_at_ms", "provider_rejection_claim",
    }
    _require(type(doc) is dict and set(doc) == expected, "child_summary_shape")
    _require(
        doc.get("profile") == PROFILE
        and doc.get("venue") == VENUE
        and doc.get("environment") == ENVIRONMENT
        and doc.get("case_id") == case_id
        and doc.get("status") == "PASS"
        and doc.get("receipt_count") == 1
        and type(doc.get("receipt_count")) is int
        and doc.get("observation_count") == 1
        and type(doc.get("observation_count")) is int
        and doc.get("provider_rejection_claim") == "NONE"
        and type(doc.get("reason")) is str
        and type(doc.get("completed_at_ms")) is int
        and _HEX64.fullmatch(doc.get("private_audit_sha256", "")) is not None
        and doc.get("source_map_sha256") == SOURCE_MAP_SHA256,
        "child_summary_binding",
    )
    return doc


def _audit_facts(
    store_module,
    audit: dict[str, Any],
    *,
    profile,
    case_id: str,
    nonce: str,
    parent_pid: int,
    start_ms: int,
    finish_ms: int,
    lease,
    summary,
) -> dict[str, Any]:
    """Cross-check the pinned V4 public result against its reopened audit."""
    typed_result, typed_action, typed_observation = store_module.FixedPrivateStore._typed_case_facts(audit)
    execution = audit.get("execution")
    _require(
        type(execution) is dict
        and execution.get("schema") == "okx.fixed_case_execution.v1"
        and execution.get("case_id") == case_id
        and execution.get("run_nonce") == nonce
        and execution.get("parent_pid") == parent_pid
        and type(execution.get("parent_pid")) is int
        and execution.get("registration_sha256") == lease.registration_sha256
        and execution.get("source_map_sha256") == SOURCE_MAP_SHA256
        and type(execution.get("started_at_ms")) is int
        and type(execution.get("deadline_at_ms")) is int
        and type(execution.get("completed_at_ms")) is int
        and start_ms <= execution["started_at_ms"] <= execution["completed_at_ms"] <= finish_ms
        and execution["completed_at_ms"] <= execution["deadline_at_ms"]
        and execution["completed_at_ms"] == summary["completed_at_ms"]
        and all(_HEX64.fullmatch(execution.get(key, "")) for key in (
        "account_scope_ref", "credential_binding_sha256", "uid_comparison_sha256",
            "capture_sha256", "log_sha256",
        )),
        "audit_execution_binding",
    )
    _require(
        typed_result.case_id == case_id
        and typed_result.status.value == "PASS"
        and typed_result.receipt_count == 1
        and typed_result.observation_count == 1
        and typed_result.reason == summary["reason"],
        "audit_result_binding",
    )
    action = typed_action
    observation = typed_observation
    expected_action, expected_kind = (
        ("inspect_monitor_log", "monitor_log_correlated")
        if case_id == "L03"
        else ("inspect_validation_log", "validation_rejected")
    )
    binding = {
        "venue": "okx",
        "environment_name": "demo",
        "environment_kind": "demo",
        "account_ref": execution["account_scope_ref"],
    }
    _require(
        action.case_id == case_id
        and action.name == expected_action
        and action.risk.value == "read"
        and action.binding.__dict__ == binding
        and action.attested_session_id == "local-c01:" + nonce
        and action.evidence_window_id == observation.evidence_window_id
        and action.correlation_id == observation.correlation_id
        and action.client_id == observation.client_id
        and action.plan.operations == ()
        and action.plan.order_count == 0
        and observation.binding.__dict__ == binding
        and observation.kind == expected_kind
        and observation.source == "OKX_FIXED_READONLY_CASE_V4"
        and observation.source_channel == "source-pinned-independent-read"
        and observation.operation_ids == ()
        and observation.provider_order_ids == (),
        "audit_typed_scope",
    )
    payload = observation.payload
    _require(
        type(payload) is dict
        and payload.get("source_map_sha256") == SOURCE_MAP_SHA256
        and payload.get("account_scope_ref") == execution["account_scope_ref"]
        and payload.get("capture_sha256") == execution["capture_sha256"]
        and payload.get("log_sha256") == execution["log_sha256"]
        and payload.get("observed_at_ms") == execution["completed_at_ms"],
        "audit_observation_scope",
    )
    lifecycles = execution.get("lifecycles")
    expected_roles = ("l03_issuer", "l03_observer") if case_id == "L03" else (
        "l04_c01_scope", "l04_reader", "l04_issuer"
    )
    _require(
        type(lifecycles) is list
        and tuple(row.get("role") for row in lifecycles if type(row) is dict) == expected_roles
        and len(lifecycles) == len(expected_roles),
        "audit_lifecycle_roles",
    )
    pids = []
    for row in lifecycles:
        _require(
            type(row) is dict
            and type(row.get("pid")) is int
            and row["pid"] > 0
            and type(row.get("started_at_ms")) is int
            and type(row.get("finished_at_ms")) is int
            and execution["started_at_ms"] <= row["started_at_ms"] <= row["finished_at_ms"] <= execution["completed_at_ms"]
            and type(row.get("exit_code")) is int
            and row["exit_code"] == 0
            and type(row.get("source_sha256")) is str
            and _HEX64.fullmatch(row["source_sha256"]) is not None
            and row["source_sha256"] == profile.role_source_digest(lease.source_map, row["role"])
            and type(row.get("output_sha256")) is str
            and _HEX64.fullmatch(row["output_sha256"]) is not None,
            "audit_lifecycle_shape",
        )
        if row["process_mode"] == "CHILD":
            _require(
                row["pid"] != parent_pid
                and row.get("process_reaped") is True
                and row.get("stdin_closed") is True
                and row.get("stdout_eof") is True
                and row.get("stderr_eof") is True
                and row.get("stdout_closed") is True
                and row.get("stderr_closed") is True
                and row.get("stderr_empty") is True
                and row.get("active_children_zero") is True,
                "audit_child_lifecycle",
            )
        else:
            _require(
                case_id == "L04"
                and row["role"] == "l04_issuer"
                and row["pid"] == parent_pid
                and row.get("process_mode") == "ROOT"
                and row.get("process_reaped") is False
                and row.get("stdin_closed") is False
                and row.get("stdout_eof") is False
                and row.get("stderr_eof") is False
                and row.get("stdout_closed") is False
                and row.get("stderr_closed") is False
                and row.get("stderr_empty") is True
                and row.get("active_children_zero") is True,
                "audit_root_lifecycle",
            )
        pids.append(row["pid"])
    _require(len(pids) == len(set(pids)), "audit_lifecycle_pid_reuse")
    return execution


def _verify_new_case_audit(
    *, profile, lease, private_module, api, runs_dir, before: dict, process, stdout: bytes,
    stderr: bytes, process_started_at_ms: int, process_finished_at_ms: int, case_id: str,
) -> dict[str, Any]:
    _require(type(stderr) is bytes and not stderr and len(stderr) <= MAX_CHILD_STDERR_BYTES, "child_stderr")
    summary = _strict_summary(stdout, case_id)
    after = _children_snapshot(runs_dir.path)
    _require(set(before).issubset(after), "run_namespace_removed")
    _require(all(before[name] == after[name] for name in before), "run_namespace_history_changed")
    created = tuple(set(after) - set(before))
    _require(len(created) == 1 and _NONCE.fullmatch(created[0]) is not None, "run_namespace_create_new")
    nonce = created[0]
    run_path = runs_dir.path / nonce

    with _held_object(
        private_module, api, run_path, directory=True, protected=True
    ) as (run_handle, run_identity):
        child_dir = private_module.PrivateArtifactDirectory(run_path, run_identity[0], run_identity[1])
        child_dir.verify()
        audit_path = run_path / "case-result.json"
        with _held_object(
            private_module, api, audit_path, directory=False, protected=True
        ) as (audit_handle, audit_identity):
            raw = _read_stable(audit_path, MAX_AUDIT_BYTES)
            _require(api.info(audit_handle, directory=False) == audit_identity, "audit_file_identity")
            _require(_sha(raw) == summary["private_audit_sha256"], "audit_file_digest")
            audit = _strict_json(raw)
            _require(
                audit.get("schema") == "okx.fixed_case_audit.v2"
                and audit.get("case_id") == case_id
                and audit.get("status") == "PASS"
                and audit.get("source_map_sha256") == SOURCE_MAP_SHA256,
                "audit_top_level",
            )
            store_module = __import__(
                "_l03_l04_case_v4.private_store", fromlist=["FixedPrivateStore"]
            )
            execution = _audit_facts(
                store_module,
                audit,
                profile=profile,
                case_id=case_id,
                nonce=nonce,
                parent_pid=process.pid,
                start_ms=process_started_at_ms,
                finish_ms=process_finished_at_ms,
                lease=lease,
                summary=summary,
            )
            _require(
                profile.source_map_digest(lease.source_map) == SOURCE_MAP_SHA256
                and api.info(run_handle, directory=True) == run_identity
                and api.info(audit_handle, directory=False) == audit_identity,
                "audit_parent_source_custody",
            )
    _require(process.returncode == 0 and process.poll() == 0, "child_exit")
    return _public_result(
        case_id=case_id,
        summary=summary,
        execution=execution,
        parent_pid=os.getpid(),
        child_pid=process.pid,
        started_at_ms=process_started_at_ms,
        launcher_finished_at_ms=process_finished_at_ms,
        stderr_empty=not stderr,
    )


def _public_result(
    *,
    case_id: str,
    summary: dict[str, Any],
    execution: dict[str, Any],
    parent_pid: int,
    child_pid: int,
    started_at_ms: int,
    launcher_finished_at_ms: int,
    stderr_empty: bool,
) -> dict[str, Any]:
    """Expose only public status, software pins, counts, timing and lifecycle."""
    return {
        "profile": PROFILE,
        "venue": VENUE,
        "environment": ENVIRONMENT,
        "case_id": case_id,
        "status": "PASS",
        "reason": summary["reason"],
        "receipt_count": summary["receipt_count"],
        "observation_count": summary["observation_count"],
        "provider_rejection_claim": "NONE",
        "source_map_sha256": SOURCE_MAP_SHA256,
        "review_json_sha256": REVIEW_JSON_SHA256,
        "parent_pid": parent_pid,
        "case_process_pid": child_pid,
        "started_at_ms": started_at_ms,
        "completed_at_ms": execution["completed_at_ms"],
        "launcher_finished_at_ms": launcher_finished_at_ms,
        "lifecycle_count": len(execution["lifecycles"]),
        "all_child_processes_reaped": True,
        "stdout_eof": True,
        "stderr_eof": True,
        "stderr_empty": stderr_empty,
    }


def _minimal_environment() -> dict[str, str]:
    return {key: os.environ[key] for key in ("SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "TEMP", "TMP") if key in os.environ}


def install_registration() -> str:
    """Create one root-owned registration admitting exactly L03 and L04."""
    _assert_root_admission()
    _require(_isolated_launcher(), "isolated_root_launcher_required")
    source_map, _review = verify_public_bundle()
    profile = _import_profile(REPO_ROOT)
    _require(profile.current_source_map() == source_map, "source_map_recomputation")
    digest = _create_registration(profile, source_map)
    return digest


def run_case(case_id: str) -> int:
    """Run one exact isolated V4 case under retained root/source leases."""
    _assert_root_admission()
    _require(_isolated_launcher(), "isolated_root_launcher_required")
    _require(type(case_id) is str and case_id in CASES, "case_not_admitted")
    source_map, _review = verify_public_bundle()
    profile = _import_profile(REPO_ROOT)
    _require(profile.current_source_map() == source_map, "source_map_recomputation")
    lease = profile.load_registered_profile(case_id)
    profile.verify_lease(lease)
    _require(dict(lease.source_map) == source_map and lease.source_map_sha256 == SOURCE_MAP_SHA256, "registered_source_map")
    _require(_registration_document_hash(profile, lease) == lease.registration_sha256, "registration_hash")

    case_entry = REPO_ROOT / OKX_ROOT_REL / "cases" / case_id / "run.py"
    _require(case_entry.is_file(), "case_entry_missing")
    command = [sys.executable, "-I", "-S", "-B", str(case_entry), "--fixed-readonly-v4"]
    started = time.time_ns() // 1_000_000
    with _invocation_leases(profile, lease, source_map, REPO_ROOT) as (
        private_module, api, _root_dir, runs_dir
    ):
        before = _children_snapshot(runs_dir.path)
        with _WindowsProcessJob() as job:
            process = None
            try:
                process = job.spawn(
                    command,
                    cwd=str(REPO_ROOT),
                    env=_minimal_environment(),
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    close_fds=True,
                    creationflags=(
                        getattr(subprocess, "CREATE_NO_WINDOW", 0)
                        | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                    ),
                )
                stdout, stderr = _bounded_communicate(
                    process, CHILD_TIMEOUT_SECONDS, job=job
                )
                waited = process.wait(timeout=CHILD_REAP_TIMEOUT_SECONDS)
                if job.active_processes() != 0 or job.was_forced:
                    job.terminate(process)
                    raise LauncherBlocked("child_tree_not_empty")
            except Exception:
                try:
                    if process is not None and process.poll() is None:
                        job.terminate(process)
                        process.wait(timeout=CHILD_REAP_TIMEOUT_SECONDS)
                except Exception:
                    pass
                raise LauncherBlocked("case_process_lifecycle") from None
            finished = time.time_ns() // 1_000_000
            if (
                type(waited) is not int
                or waited != process.returncode
                or process.poll() != process.returncode
                or process.stdin is not None and not process.stdin.closed
                or process.stdout is not None and not process.stdout.closed
                or process.stderr is not None and not process.stderr.closed
            ):
                raise LauncherBlocked("case_process_lifecycle")
            public_result = _verify_new_case_audit(
                profile=profile,
                lease=lease,
                private_module=private_module,
                api=api,
                runs_dir=runs_dir,
                before=before,
                process=process,
                stdout=stdout,
                stderr=stderr,
                process_started_at_ms=started,
                process_finished_at_ms=finished,
                case_id=case_id,
            )
    # Do not expose the private audit digest or registration digest.
    print(json.dumps(public_result, sort_keys=True, separators=(",", ":")))
    return 0


def _print_registration_template() -> int:
    _require(_isolated_launcher(), "isolated_root_launcher_required")
    document = registration_template()
    print(
        json.dumps(
            {"template_status": "UNSET_NOT_INSTALLED", "registration_document": document},
            sort_keys=True,
            separators=(",", ":"),
        )
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if type(args) is not list or any(type(arg) is not str for arg in args):
        raise SystemExit(2)
    if len(args) == 1 and args[0] == "--print-registration-template":
        try:
            return _print_registration_template()
        except Exception:
            print('{"status":"BLOCKED","reason":"public_template_unavailable"}')
            return 2
    if len(args) == 1 and args[0] == "--install-registration":
        try:
            install_registration()
            print(json.dumps({"status": "REGISTRATION_CREATED", "case_ids": ["L03", "L04"]}, sort_keys=True))
            return 0
        except Exception:
            print('{"status":"BLOCKED","reason":"root_registration_gate_unset_or_failed"}')
            return 2
    if len(args) == 2 and args[0] == "--run":
        try:
            return run_case(args[1])
        except Exception:
            print('{"status":"BLOCKED","reason":"root_case_launcher_gate_unset_or_failed"}')
            return 2
    print('{"status":"BLOCKED","reason":"fixed_launcher_arguments"}')
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
