"""Pinned stdin bootstrap for the M01 R33 child process.

The parent passes only a bounded JSON descriptor on stdin.  This module loads
the exact R31 runner bytes and the public CUv2 snapshot named by that
descriptor, then gives the runner CUv2's held-public-source context manager.
The checked-in R31 runner remains disabled; this bootstrap does not change its
activation flags or interpret its result as certification.
"""

from __future__ import annotations

import hashlib
import json
import ntpath
import sys
import types
from typing import Any


BOOTSTRAP_SCHEMA = "iteration41.okx.m01.r33.child-launch-descriptor.v1"
SOURCE_MAP_SCHEMA = "iteration41.okx.m01.r33.public-source-map.v1"
RESULT_SCHEMA = "iteration41.okx.m01.r33.child-bootstrap-result.v1"
FIXED_EXECUTABLE = "C:/anaconda3/python.exe"
CUV2_PUBLIC_SOURCE_SHA256 = "e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246"
MAX_DESCRIPTOR_BYTES = 4096
MAX_SOURCE_MAP_BYTES = 1024 * 1024
MAX_RUNNER_BYTES = 4 * 1024 * 1024
MAX_CUV2_BYTES = 1024 * 1024
MAX_STDOUT_BYTES = 128 * 1024
_HEX = frozenset("0123456789abcdef")
_NAMESPACE_KEYS = frozenset(
    {
        "control_dir",
        "deployment_dir",
        "plan_path",
        "self_path",
        "active_wrapper_path",
        "attempt_claim_path",
    }
)
_DESCRIPTOR_KEYS = frozenset(
    {
        "schema",
        "runner_path",
        "runner_sha256",
        "runner_template_schema",
        "manifest_binding_sha256",
        "root",
        "source_map_path",
        "source_map_sha256",
        "cuv2_path",
        "cuv2_sha256",
        "runtime_namespace",
        "plan_disposition",
        "budgets",
    }
)
_SOURCE_MAP_KEYS = frozenset(
    {
        "schema",
        "public_pins",
        "software_pins",
        "canonical_pins",
        "map_counts",
        "root",
        "runtime_namespace",
        "runner_template_sha256",
        "runner_template_schema",
        "manifest_binding_sha256",
        "plan_sha256",
        "plan_disposition",
    }
)


class BootstrapBlocked(ValueError):
    """A bounded bootstrap input failed a fixed public contract."""


def _check(value: Any, code: str) -> None:
    if not value:
        raise BootstrapBlocked(code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _is_sha(value: Any) -> bool:
    return (
        type(value) is str
        and len(value) == 64
        and all(character in _HEX for character in value)
    )


def _pairs_no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise BootstrapBlocked("duplicate_json_key")
        result[key] = value
    return result


def _reject_constant(_value):
    raise BootstrapBlocked("nonfinite_json_number")


def _strict_json(raw: bytes) -> Any:
    _check(type(raw) is bytes, "json_bytes_type")
    try:
        return json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=_pairs_no_duplicates,
            parse_constant=_reject_constant,
        )
    except BootstrapBlocked:
        raise
    except BaseException:
        raise BootstrapBlocked("invalid_json") from None


def _absolute_windows_path(value: Any) -> bool:
    return (
        type(value) is str
        and 0 < len(value) <= 32767
        and "\x00" not in value
        and ntpath.isabs(value)
    )


def _validate_namespace(value: Any) -> bool:
    return (
        type(value) is dict
        and frozenset(value) == _NAMESPACE_KEYS
        and all(_absolute_windows_path(value[key]) for key in _NAMESPACE_KEYS)
    )


def _valid_pin_map(value: Any, expected_count: int) -> bool:
    return (
        type(value) is dict
        and len(value) == expected_count
        and all(
            type(path) is str
            and 0 < len(path) <= 32767
            and "\x00" not in path
            and _is_sha(digest)
            for path, digest in value.items()
        )
    )


def _normalized_path(value: str) -> str:
    return ntpath.normcase(ntpath.normpath(value))


def _validate_descriptor(raw: bytes) -> dict:
    _check(type(raw) is bytes and 0 < len(raw) <= MAX_DESCRIPTOR_BYTES, "descriptor_size")
    value = _strict_json(raw)
    _check(type(value) is dict and frozenset(value) == _DESCRIPTOR_KEYS, "descriptor_shape")
    _check(value.get("schema") == BOOTSTRAP_SCHEMA, "descriptor_schema")
    for key in ("runner_path", "source_map_path", "cuv2_path"):
        _check(_absolute_windows_path(value.get(key)), "descriptor_path")
    _check(_absolute_windows_path(value.get("root")), "descriptor_root")
    for key in (
        "runner_sha256",
        "manifest_binding_sha256",
        "source_map_sha256",
        "cuv2_sha256",
    ):
        _check(_is_sha(value.get(key)), "descriptor_digest")
    _check(value.get("cuv2_sha256") == CUV2_PUBLIC_SOURCE_SHA256, "cuv2_source_pin")
    _check(
        type(value.get("runner_template_schema")) is str
        and value["runner_template_schema"].startswith("iteration41.okx.m01.v6.root-startup-runner-template.r31."),
        "runner_schema",
    )
    _check(_validate_namespace(value.get("runtime_namespace")), "descriptor_namespace")
    _check(value.get("plan_disposition") in {"NON_ACTUAL_PLAN", "READY_TO_RUN"}, "plan_disposition")
    _check(
        value.get("budgets")
        == {
            "parent_seconds": 100,
            "parent_cleanup_seconds": 5,
            "once_child_seconds": 180,
            "once_cleanup_seconds": 5,
            "outer_capture_seconds": 405,
            "outer_cleanup_seconds": 5,
        },
        "budget_binding",
    )
    return value


def _validate_source_map(raw: bytes, descriptor: dict) -> dict:
    _check(type(raw) is bytes and 0 < len(raw) <= MAX_SOURCE_MAP_BYTES, "source_map_size")
    _check(_sha(raw) == descriptor["source_map_sha256"], "source_map_digest")
    value = _strict_json(raw)
    _check(type(value) is dict and frozenset(value) == _SOURCE_MAP_KEYS, "source_map_shape")
    _check(value.get("schema") == SOURCE_MAP_SCHEMA, "source_map_schema")
    public = value.get("public_pins")
    software = value.get("software_pins")
    canonical = value.get("canonical_pins")
    _check(_valid_pin_map(public, 118), "public_pin_map")
    _check(_valid_pin_map(software, 36), "software_pin_map")
    combined = dict(public)
    _check(not set(combined).intersection(software), "pin_map_overlap")
    combined.update(software)
    _check(_valid_pin_map(canonical, 154), "canonical_pin_map")
    _check(value.get("map_counts") == {"public": 118, "software": 36, "canonical": 154}, "map_counts")
    _check(value.get("root") == descriptor["root"], "source_map_root")
    root = value["root"]
    _check(_absolute_windows_path(root), "source_map_root")
    projected = {
        _normalized_path(ntpath.join(root, path)): digest
        for path, digest in public.items()
    }
    projected.update(
        {_normalized_path(path): digest for path, digest in software.items()}
    )
    actual = {_normalized_path(path): digest for path, digest in canonical.items()}
    _check(len(projected) == 154 and projected == actual, "canonical_map_projection")
    _check(value.get("runtime_namespace") == descriptor["runtime_namespace"], "source_map_namespace")
    _check(value.get("runner_template_sha256") == descriptor["runner_sha256"], "source_map_runner_digest")
    _check(value.get("runner_template_schema") == descriptor["runner_template_schema"], "source_map_runner_schema")
    _check(value.get("manifest_binding_sha256") == descriptor["manifest_binding_sha256"], "source_map_manifest_binding")
    _check(value.get("plan_disposition") == descriptor["plan_disposition"], "source_map_plan_disposition")
    _check(_is_sha(value.get("plan_sha256")), "source_map_plan_digest")
    return value


def _read_bounded(path: str, maximum: int, reason: str) -> bytes:
    try:
        with open(path, "rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise BootstrapBlocked(reason) from None
    _check(type(raw) is bytes and 0 < len(raw) <= maximum, reason)
    return raw


def _load_source(raw: bytes, path: str, name: str):
    module = types.ModuleType(name)
    module.__file__ = path
    try:
        code = compile(raw, path, "exec", dont_inherit=True)
        exec(code, module.__dict__)
    except BaseException:
        raise BootstrapBlocked("pinned_source_load_failed") from None
    return module


def _write_result(stream, *, status: str, reason: str, exit_code: int) -> int:
    document = {
        "schema": RESULT_SCHEMA,
        "status": status,
        "reason": reason,
        "route_invocations": 0,
        "strict_cases_passed": 0,
        "authority": False,
    }
    try:
        raw = json.dumps(document, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")
        if len(raw) > MAX_STDOUT_BYTES:
            return 2
        stream.write(raw.decode("ascii") + "\n")
        stream.flush()
    except BaseException:
        return 2
    return exit_code


def run_descriptor(raw_descriptor: bytes, *, stdin=None, stdout=None) -> int:
    """Run a descriptor-bound runner without adding a readiness interpretation."""
    input_stream = sys.stdin.buffer if stdin is None else stdin
    output_stream = sys.stdout if stdout is None else stdout
    try:
        descriptor = _validate_descriptor(raw_descriptor)
        source_map_raw = _read_bounded(
            descriptor["source_map_path"], MAX_SOURCE_MAP_BYTES, "source_map_read"
        )
        source_map = _validate_source_map(source_map_raw, descriptor)
        runner_raw = _read_bounded(descriptor["runner_path"], MAX_RUNNER_BYTES, "runner_read")
        _check(_sha(runner_raw) == descriptor["runner_sha256"], "runner_digest")
        cuv2_raw = _read_bounded(descriptor["cuv2_path"], MAX_CUV2_BYTES, "cuv2_read")
        _check(_sha(cuv2_raw) == descriptor["cuv2_sha256"], "cuv2_digest")
        cuv2 = _load_source(cuv2_raw, descriptor["cuv2_path"], "_iteration41_m01_r33_cuv2")
        runner = _load_source(runner_raw, descriptor["runner_path"], "_iteration41_m01_r33_runner")
        _check(callable(getattr(cuv2, "held_public_sources", None)), "cuv2_entrypoint")
        _check(callable(getattr(runner, "main", None)), "runner_entrypoint")
        if descriptor["plan_disposition"] == "NON_ACTUAL_PLAN":
            _check(getattr(runner, "ROOT_RUNNER_ENABLED", None) is False, "nonactual_runner_enabled")
        root_scope = cuv2.held_public_sources(
            source_map["public_pins"], source_map["software_pins"]
        )
        result = runner.main(root_scope)
        # Result bytes are intentionally not forwarded. The external parent
        # records process exit and bounded output only; no child return value
        # can claim case, account, provider, or certification acceptance.
        _check(type(result) is dict, "runner_result_shape")
        if result.get("reason") == "root_runner_disabled":
            return _write_result(
                output_stream,
                status="BLOCKED",
                reason="runner_activation_closed",
                exit_code=2,
            )
        return _write_result(output_stream, status="CHILD_RETURNED", reason="runner_returned", exit_code=0)
    except BaseException:
        return _write_result(output_stream, status="BLOCKED", reason="bootstrap_blocked", exit_code=2)


def main() -> int:
    try:
        raw = sys.stdin.buffer.read(MAX_DESCRIPTOR_BYTES + 1)
    except BaseException:
        return _write_result(sys.stdout, status="BLOCKED", reason="descriptor_read", exit_code=2)
    if len(raw) > MAX_DESCRIPTOR_BYTES:
        return _write_result(sys.stdout, status="BLOCKED", reason="descriptor_size", exit_code=2)
    return run_descriptor(raw)


if __name__ == "__main__":
    raise SystemExit(main())
