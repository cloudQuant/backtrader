"""Focused R31 source/fake tests for bounded rereads on held file handles."""

from __future__ import annotations

import contextlib
import ctypes
import hashlib
import json
from pathlib import Path
import stat
import uuid
from ctypes import wintypes

import pytest

from scripts import iteration41_okx_m01_r31_root_startup_prepare_r1 as prepare


PLAN_BYTES = b"r31 bounded reread source-fake plan\n"


class _Handle:
    def __init__(self, path, directory=False):
        self.path = Path(path)
        self.directory = directory
        self.position = 0


class _SeekFilePointer:
    def __init__(self):
        self.argtypes = None
        self.restype = None
        self.calls = 0
        self.fail = False

    def __call__(self, handle, distance, new_position, move_method):
        self.calls += 1
        assert move_method == 0
        if self.fail:
            return 0
        offset = distance.value
        handle.position = offset
        ctypes.cast(new_position, ctypes.POINTER(ctypes.c_longlong)).contents.value = offset
        return 1


class _Kernel:
    def __init__(self):
        self.SetFilePointerEx = _SeekFilePointer()


class _FakeApi:
    def __init__(self):
        self.kernel = _Kernel()
        self.deny_acl = set()

    def current_sid(self):
        return "fake-sid"

    @contextlib.contextmanager
    def opened(self, path, *, directory, access):
        del access
        target = Path(path)
        if not target.exists() or target.is_dir() is not directory:
            raise OSError("fake_handle_unavailable")
        yield _Handle(target, directory=directory)

    def info(self, handle, *, directory=False):
        value = Path(handle.path).stat()
        return (value.st_dev, value.st_ino, stat.S_IFMT(value.st_mode))

    def verify_acl(self, handle, sid, *, directory=False):
        del sid, directory
        if str(Path(handle.path)) in self.deny_acl:
            raise PermissionError("fake_acl_rejected")


class _FakeCli:
    def __init__(self):
        self.read_calls = 0

    @contextlib.contextmanager
    def _locked_readonly_file(self, path, private, api):
        del private, api
        target = Path(path)
        if not target.is_file():
            raise OSError("fake_file_unavailable")
        yield _Handle(target)

    def _read_bounded_handle(self, api, handle, maximum):
        del api
        self.read_calls += 1
        raw = Path(handle.path).read_bytes()
        payload = raw[handle.position : handle.position + maximum + 1]
        handle.position += len(payload)
        if len(payload) > maximum:
            raise ValueError("fake_bound_exceeded")
        return payload

    def _locked_file_identity(self, api, handle, private):
        del private
        return api.info(handle, directory=False)


class _FakeCapture:
    def __init__(self, path):
        self.path = Path(path)

    def verify(self):
        assert self.path.is_dir()


class _FakePrivate:
    def __init__(self, api):
        self.api = api

    def _api(self):
        return self.api

    def create_private_directory(self, path):
        target = Path(path)
        target.mkdir()
        return _FakeCapture(target)


def _load(tmp_path):
    namespace = prepare.default_test_namespace(str(tmp_path / "r31"))
    result = prepare.prepare_root_startup(
        namespace, plan_sha256=hashlib.sha256(PLAN_BYTES).hexdigest()
    )
    outer = {"__name__": "_r31_outer_test"}
    exec(compile(result["active_outer_source"], "<r31-filled-outer>", "exec"), outer)
    return namespace, result, outer


def _predeploy(namespace, result):
    control = Path(namespace["control_dir"])
    deployment = Path(namespace["deployment_dir"])
    control.mkdir(parents=True)
    deployment.mkdir(parents=True)
    plan = Path(namespace["plan_path"])
    self_path = Path(namespace["self_path"])
    wrapper = Path(namespace["active_wrapper_path"])
    plan.write_bytes(PLAN_BYTES)
    self_path.write_bytes(result["active_outer_source"])
    wrapper.write_bytes(result["active_wrapper_source"])
    return wrapper


def test_r31_constructor_keeps_r30_wrapper_and_frozen_budgets(tmp_path):
    namespace, result, outer = _load(tmp_path)
    assert result["status"] == "SOURCE_FAKE_ONLY_DISABLED"
    assert len(result["public_pins"]) == 118
    assert len(result["software_pins"]) == 36
    assert len(result["canonical_pins"]) == 154
    assert result["active_wrapper_source"] == prepare._r30()[0].prepare_root_startup(
        namespace, plan_sha256=hashlib.sha256(PLAN_BYTES).hexdigest()
    )["active_wrapper_source"]
    assert outer["ROOT_PRELAUNCH_ENABLED"] is True
    assert result["manifest"]["once"]["child_timeout_seconds"] == 180
    assert result["manifest"]["once"]["child_cleanup_timeout_seconds"] == 5
    assert result["manifest"]["once"]["spawn_total_budget_seconds"] == 5
    assert result["manifest"]["outer_timeouts"] == {
        "capture_seconds": 405,
        "cleanup_seconds": 5,
        "external_parent_envelope_seconds": None,
        "external_parent_envelope_established": False,
    }
    assert result["manifest"]["safety"]["runner_default_enabled"] is False
    assert "SetFilePointerEx" in result["active_outer_source"].decode("utf-8")


def test_r31_rewinds_real_sequence_reader_for_first_repeat_and_tamper(tmp_path):
    namespace, result, outer = _load(tmp_path)
    wrapper_path = _predeploy(namespace, result)
    api = _FakeApi()
    cli = _FakeCli()
    private = _FakePrivate(api)
    sid = api.current_sid()
    held = {str(wrapper_path): result["active_wrapper_source"]}

    with contextlib.ExitStack() as stack:
        bindings = outer["_r30_predeployed_wrapper"](private, cli, api, sid, stack, held)
        seek = api.kernel.SetFilePointerEx
        assert seek.calls == 1
        assert cli.read_calls == 1
        assert seek.argtypes == [
            wintypes.HANDLE,
            ctypes.c_longlong,
            ctypes.POINTER(ctypes.c_longlong),
            wintypes.DWORD,
        ]
        assert seek.restype is wintypes.BOOL

        outer["_r30_verify_deployment"](private, cli, api, sid, held, bindings)
        assert seek.calls == 2
        assert cli.read_calls == 2

        wrapper_path.write_bytes(b"tampered wrapper")
        with pytest.raises(outer["PrelaunchBlocked"]) as tampered:
            outer["_r30_verify_deployment"](private, cli, api, sid, held, bindings)
        assert tampered.value.code == "deployment_wrapper_pin"
        assert seek.calls == 3
        assert cli.read_calls == 3


def test_r31_attempt_claim_rewinds_post_write_and_post_child_reads(tmp_path):
    namespace, result, outer = _load(tmp_path)
    wrapper_path = _predeploy(namespace, result)
    api = _FakeApi()
    cli = _FakeCli()
    private = _FakePrivate(api)
    sid = api.current_sid()
    claim_path = Path(namespace["attempt_claim_path"])
    outer["ATTEMPT_CLAIM"] = claim_path

    with contextlib.ExitStack() as stack:
        activation_id = str(uuid.uuid4())
        handle, identity, claim_raw = outer["_r30_create_attempt_claim"](
            private, cli, api, sid, stack, activation_id, PLAN_BYTES
        )
        seek = api.kernel.SetFilePointerEx
        assert seek.calls == 1
        assert cli.read_calls == 1
        outer["_r30_verify_attempt_claim"](
            private, cli, api, sid, handle, identity, claim_raw
        )
        assert seek.calls == 2
        assert cli.read_calls == 2

        claim_path.write_bytes(b"tampered claim")
        with pytest.raises(outer["PrelaunchBlocked"]) as tampered:
            outer["_r30_verify_attempt_claim"](
                private, cli, api, sid, handle, identity, claim_raw
            )
        assert tampered.value.code == "attempt_claim_identity_changed"
        assert seek.calls == 3
        assert cli.read_calls == 3
        assert wrapper_path.read_bytes() == result["active_wrapper_source"]


def test_r31_seek_failure_stops_before_the_reader(tmp_path):
    _namespace, _result, outer = _load(tmp_path)
    api = _FakeApi()
    api.kernel.SetFilePointerEx.fail = True
    cli = _FakeCli()
    handle = _Handle(tmp_path / "unused.bin")
    with pytest.raises(outer["PrelaunchBlocked"]) as failed:
        outer["_r31_read_bounded_from_start"](cli, api, handle, 64)
    assert failed.value.code == "held_file_seek_failed"
    assert cli.read_calls == 0


def test_r31_actual_pinned_cli_source_is_bound_and_has_advancing_reader():
    _r30, repo_root = prepare._r30()
    result = prepare.prepare_root_startup(
        prepare.default_test_namespace(), plan_sha256="a" * 64
    )
    prepare._verify_pinned_cli_reader(result["active_outer_source"], repo_root)
    raw = (repo_root / prepare.CLI_SOURCE_REL).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == prepare.CLI_SOURCE_SHA256
    assert b"reader(handle, buffer, maximum + 1" in raw
    assert b"SetFilePointerEx" not in raw
