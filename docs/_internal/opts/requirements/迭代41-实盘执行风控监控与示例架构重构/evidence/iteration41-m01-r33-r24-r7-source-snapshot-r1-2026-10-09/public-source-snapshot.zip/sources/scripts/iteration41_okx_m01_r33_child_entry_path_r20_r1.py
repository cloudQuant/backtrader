"""Normalize R28's generated Path value at the R20 source-boundary entry."""

from __future__ import annotations

import ast
import copy
import dataclasses
import hashlib
import ntpath
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as _R13
from scripts import iteration41_okx_m01_r33_final_output_hold_r16_r1 as _R16
from scripts import iteration41_okx_m01_r33_parent_adapter_constructor_r18_r1 as _R18
from scripts import iteration41_okx_m01_r33_parent_adapter_transport_r14_r1 as _R14
from scripts import iteration41_okx_m01_r33_source_map_gate_r17_r1 as _R17
from scripts import iteration41_okx_m01_r33_child_source_scope_r19_r1 as _R19


R20_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_child_entry_path_r20_r1.py"
R20_RESULT_SCHEMA = "iteration41.okx.m01.r33.child-entry-path-r20.root-preparation.v1"
R20_ADAPTER_RESULT_SCHEMA = "iteration41.okx.m01.r33.child-entry-path-r20.parent-adapter.v1"
R20_SOURCE_ROLE = "r20_child_entry_path_source"
R20_MAX_SOURCE_BYTES = 2097152
R20_MAX_OUTER_BYTES = 2097152
R20_PINNED_R19_SHA256 = "424edf3aecc997f36bbe9ba713c3278b594132016ab893164ecf822d734aa1d4"
R20_FAILURE_CODES = frozenset(
    {
        "r20_module_name",
        "r20_module_path",
        "r20_source_unavailable",
        "r20_source_size",
        "r20_source_binding",
        "r20_r19_source_pin",
        "r20_source_pin",
        "r20_source_identity",
        "r20_patch_context_busy",
        "r20_patch_owner_thread",
        "r20_patch_context_changed",
        "r20_descriptor_rejected",
        "r20_descriptor_input_changed",
        "r20_runtime_map_path_unbound",
        "r20_active_outer_transform",
        "r20_helper_source_pin",
        "r20_helper_source_parse",
        "r20_helper_source_constants",
        "r20_helper_transform_compile",
        "r20_helper_source_constants",
        "r20_r16_composite_blocked",
        "r20_r16_result_type",
        "r20_r17_result_binding",
        "r20_r19_result_binding",
        "r20_hold_schema",
        "r20_hold_collision",
        "r20_hold_digest",
        "r20_prepared_binding",
        "r20_r14_result",
        "r20_recompose_count",
        "r20_outer_transform_count",
        "r20_adapter_binding",
    }
)


class ChildEntryPathR20Blocked(ValueError):
    """A fixed R20 source, transform, or adapter contract failed."""

    def __init__(self, code: str):
        self.code = code if code in R20_FAILURE_CODES else "r20_adapter_binding"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ChildEntryPathR20Blocked(code)


def _canonical_json(value: Any) -> bytes:
    return _R17._canonical_json(value)


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R20_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r20_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R20_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r20_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R20_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ChildEntryPathR20Blocked("r20_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R20_MAX_SOURCE_BYTES, "r20_source_size")
    return str(path), raw, _sha(raw)


_R20_OUTER_SUPPORT = br'''
R20_CHILD_ENTRY_PATH_MARKER = b"iteration41.okx.m01.r33.child-entry-path-r20.r1.v1"
R20_HELPER_PATH = __R20_HELPER_PATH__
R20_HELPER_SHA256 = __R20_HELPER_SHA256__
R20_HELPER_SOURCE_BYTES = __R20_HELPER_SOURCE_BYTES__


def _r20_rebuild_exact_active_outer(base_r10_outer, outer, *, held):
    regenerated = _r19_rebuild_exact_active_outer(base_r10_outer, outer, held=held)
    helper_raw = R20_HELPER_SOURCE_BYTES
    _check(
        type(helper_raw) is bytes and 0 < len(helper_raw) <= 2 * 1024 * 1024
        and _sha(helper_raw) == R20_HELPER_SHA256,
        "r20_helper_source_pin",
    )
    try:
        assignments, functions = _r13_source_nodes(helper_raw)
    except BaseException:
        raise ValueError("r20_helper_source_parse") from None
    try:
        support_template = ast.literal_eval(assignments["_R20_OUTER_SUPPORT"])
        relative_path = ast.literal_eval(assignments["R20_RELATIVE_PATH"])
        result_schema = ast.literal_eval(assignments["R20_RESULT_SCHEMA"])
        source_limit = ast.literal_eval(assignments["R20_MAX_SOURCE_BYTES"])
        outer_limit = ast.literal_eval(assignments["R20_MAX_OUTER_BYTES"])
    except BaseException:
        raise ValueError("r20_helper_source_constants") from None
    try:
        transform = _r13_compile_function(
            {
                "ast": ast,
                "hashlib": hashlib,
                "ntpath": ntpath,
                "R20_MAX_SOURCE_BYTES": source_limit,
                "R20_MAX_OUTER_BYTES": outer_limit,
            },
            functions,
            "_apply_active_outer_transform",
            "_r20_apply_active_outer_transform",
        )
    except BaseException:
        raise ValueError("r20_helper_transform_compile") from None
    _check(
        type(support_template) is bytes
        and relative_path == "scripts/iteration41_okx_m01_r33_child_entry_path_r20_r1.py"
        and result_schema == "iteration41.okx.m01.r33.child-entry-path-r20.root-preparation.v1"
        and type(source_limit) is int and 0 < source_limit <= 2 * 1024 * 1024
        and type(outer_limit) is int and 0 < outer_limit <= 2 * 1024 * 1024,
        "r20_helper_source_constants",
    )
    return transform(
        regenerated,
        R20_HELPER_PATH,
        R20_HELPER_SHA256,
        helper_raw,
        support_template,
    )
'''


def _apply_active_outer_transform(
    raw: bytes,
    helper_path: str,
    helper_sha256: str,
    helper_raw: bytes,
    support_template: bytes,
) -> bytes:
    """Add one Path-to-string conversion at the generated R28 call boundary."""
    if type(raw) is not bytes or not 0 < len(raw) <= R20_MAX_OUTER_BYTES:
        raise ValueError("r20_outer_input_size")
    if (
        b"iteration41.okx.m01.r33.inner-child-source-scope-r19.r1.v1" not in raw
        or b"iteration41.okx.m01.r33.child-entry-path-r20.r1.v1" in raw
    ):
        raise ValueError("r20_transform_input")
    if (
        type(helper_path) is not str or not ntpath.isabs(helper_path)
        or ntpath.normpath(helper_path) != helper_path or "\x00" in helper_path
        or type(helper_sha256) is not str or len(helper_sha256) != 64
        or any(char not in "0123456789abcdef" for char in helper_sha256)
        or type(helper_raw) is not bytes or not 0 < len(helper_raw) <= R20_MAX_SOURCE_BYTES
        or hashlib.sha256(helper_raw).hexdigest() != helper_sha256
        or type(support_template) is not bytes
    ):
        raise ValueError("r20_transform_input_shape")
    support = support_template
    for placeholder, replacement in {
        b"__R20_HELPER_PATH__": ascii(helper_path).encode("ascii"),
        b"__R20_HELPER_SHA256__": ascii(helper_sha256).encode("ascii"),
        b"__R20_HELPER_SOURCE_BYTES__": repr(helper_raw).encode("ascii"),
    }.items():
        if support.count(placeholder) != 1:
            raise ValueError("r20_support_placeholder")
        support = support.replace(placeholder, replacement, 1)

    old_rebuild = b"regenerated = _r19_rebuild_exact_active_outer(\n"
    new_rebuild = b"regenerated = _r20_rebuild_exact_active_outer(\n"
    if raw.count(old_rebuild) != 1:
        raise ValueError("r20_rebuild_anchor")
    result = raw.replace(old_rebuild, new_rebuild, 1)

    run_anchor = b"def run_prelaunch(\n"
    if result.count(run_anchor) != 1:
        raise ValueError("r20_run_prelaunch_anchor")
    result = result.replace(run_anchor, support + run_anchor, 1)

    old_entry = b"    now_utc,\n):\n    result = {\n"
    new_entry = (
        b"    now_utc,\n):\n"
        b"    if isinstance(self_path, Path):\n"
        b"        self_path = str(self_path)\n"
        b"    result = {\n"
    )
    if result.count(old_entry) != 1:
        raise ValueError("r20_path_entry_anchor")
    result = result.replace(old_entry, new_entry, 1)
    if (
        len(result) > R20_MAX_OUTER_BYTES
        or result.count(new_rebuild) != 1
        or result.count(old_rebuild) != 0
        or result.count(new_entry) != 1
        or result.count(old_entry) != 0
        or result.count(b"if isinstance(self_path, Path):\n        self_path = str(self_path)\n") != 1
        or b"iteration41.okx.m01.r33.child-entry-path-r20.r1.v1" not in result
    ):
        raise ValueError("r20_transformed_outer_contract")
    try:
        compile(result, "<r20-transformed-active-outer>", "exec", dont_inherit=True)
    except BaseException:
        raise ValueError("r20_transformed_outer_compile") from None
    return result


_ORIGINAL_R13_COMPOSE = _R13._compose
_ORIGINAL_R13_ACTIVE_OUTER_SOURCE = _R13._active_outer_source
_ORIGINAL_R16_PREPARE = _R17._ORIGINAL_R16_PREPARE
_ORIGINAL_R17_APPLY = _R17._apply_active_outer_transform
_ORIGINAL_R17_ADD_HOLD_ROW = _R17._add_r17_hold_row
_ORIGINAL_R19_APPLY = _R19._apply_active_outer_transform


@dataclasses.dataclass(frozen=True)
class R20RootPreparedHold:
    """R19 validated preparation plus the exact R20 source row."""

    schema: str
    r19_result: Any
    r20_helper_path: str
    r20_helper_bytes: bytes
    r20_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def prepared_r13(self) -> Any:
        return self.r19_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r19_result.prepared_r14

    @property
    def r17_result(self) -> Any:
        return self.r19_result.r17_result

    @property
    def runtime_source_map_path(self) -> str:
        return self.r19_result.runtime_source_map_path

    @property
    def runtime_source_map_sha256(self) -> str:
        return self.r19_result.runtime_source_map_sha256


def _verify_sources(r17_source, r18_source, r19_source, r20_source) -> None:
    _R19._verify_sources(r17_source, r18_source, r19_source)
    _check(_R17._ORIGINAL_R16_PREPARE is _ORIGINAL_R16_PREPARE, "r20_source_identity")
    _check(_R17._apply_active_outer_transform is _ORIGINAL_R17_APPLY, "r20_source_identity")
    _check(_R19._apply_active_outer_transform is _ORIGINAL_R19_APPLY, "r20_source_identity")
    _check(
        type(r19_source) is tuple and len(r19_source) == 3
        and r19_source[2] == R20_PINNED_R19_SHA256,
        "r20_r19_source_pin",
    )
    _check(
        type(r20_source) is tuple and len(r20_source) == 3
        and type(r20_source[1]) is bytes and _sha(r20_source[1]) == r20_source[2],
        "r20_source_binding",
    )


def _add_r20_row(addition: dict[str, Any], r20_source):
    path, raw, digest = r20_source
    _check(_R13._R10._R9._absolute_windows_path(path), "r20_hold_schema")
    _check(type(raw) is bytes and _sha(raw) == digest, "r20_source_binding")
    result = copy.deepcopy(addition)
    entries = dict(result.get("entries", {}))
    target = _R13._R10._R9._normalized(path)
    _check(
        result.get("schema") == _R16._R15.R15_HOLD_SCHEMA
        and result.get("canonical_child_map_count") == 154
        and all(_R13._R10._R9._normalized(existing) != target for existing in entries),
        "r20_hold_collision",
    )
    entries[path] = {
        "sha256": digest,
        "size_bytes": len(raw),
        "role": R20_SOURCE_ROLE,
        "origin": "repository_source:" + R20_RELATIVE_PATH,
    }
    result["entries"] = dict(sorted(entries.items()))
    return result, _sha(_canonical_json(result))


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R20RootPreparedHold:
    """Run the exact R16 preparation with R17/R19/R20 source transforms."""
    r20_source = _self_source()
    r17_source = _R17._self_source()
    r18_source = _R18._self_source()
    r19_source = _R19._self_source()
    _verify_sources(r17_source, r18_source, r19_source, r20_source)
    if not _R17._PATCH_LOCK.acquire(blocking=False):
        raise ChildEntryPathR20Blocked("r20_patch_context_busy")
    if _R17._PATCH_OWNER_THREAD is not None:
        _R17._PATCH_LOCK.release()
        raise ChildEntryPathR20Blocked("r20_patch_context_changed")

    owner = threading.get_ident()
    _R17._PATCH_OWNER_THREAD = owner
    context: dict[str, Any] = {"source_map_path": None}
    original_compose = _R13._compose
    original_outer = _R13._active_outer_source
    wrappers_installed = False
    wrappers_intact = True
    result: Any = None
    operation_error: Optional[BaseException] = None
    try:
        _check(
            original_compose is _ORIGINAL_R13_COMPOSE
            and original_outer is _ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
            "r20_patch_context_changed",
        )

        def assert_owner() -> None:
            _check(
                _R17._PATCH_OWNER_THREAD == owner == threading.get_ident(),
                "r20_patch_owner_thread",
            )
            _check(
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper,
                "r20_patch_context_changed",
            )

        def compose_wrapper(base_r11: Any) -> Any:
            assert_owner()
            try:
                path = _R17._runtime_source_map_path(base_r11)
            except BaseException:
                raise ChildEntryPathR20Blocked("r20_descriptor_rejected") from None
            previous = context["source_map_path"]
            _check(previous is None or previous == path, "r20_descriptor_input_changed")
            context["source_map_path"] = path
            return original_compose(base_r11)

        def outer_wrapper(*args: Any, **kwargs: Any) -> bytes:
            assert_owner()
            path = context.get("source_map_path")
            _check(type(path) is str, "r20_runtime_map_path_unbound")
            base_outer = original_outer(*args, **kwargs)
            try:
                r17_outer = _ORIGINAL_R17_APPLY(
                    base_outer,
                    path,
                    r17_source[0],
                    r17_source[2],
                    _R17._R17_OUTER_SUPPORT,
                )
                r19_outer = _ORIGINAL_R19_APPLY(
                    r17_outer,
                    r19_source[0],
                    r19_source[2],
                    r19_source[1],
                    _R19._R19_OUTER_SUPPORT,
                )
                return _apply_active_outer_transform(
                    r19_outer,
                    r20_source[0],
                    r20_source[2],
                    r20_source[1],
                    _R20_OUTER_SUPPORT,
                )
            except BaseException:
                raise ChildEntryPathR20Blocked("r20_active_outer_transform") from None

        _R13._compose = compose_wrapper
        _R13._active_outer_source = outer_wrapper
        wrappers_installed = True
        try:
            result = _ORIGINAL_R16_PREPARE(
                prepared_r31,
                root_metadata,
                environment=environment,
            )
        except BaseException as exc:
            operation_error = exc
    except BaseException as exc:
        operation_error = exc
    finally:
        if wrappers_installed:
            wrappers_intact = (
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper
            )
            _R13._compose = original_compose
            _R13._active_outer_source = original_outer
        _R17._PATCH_OWNER_THREAD = None
        _R17._PATCH_LOCK.release()

    if operation_error is not None:
        if isinstance(operation_error, ChildEntryPathR20Blocked):
            raise operation_error
        if isinstance(operation_error, _R19.ChildSourceScopeR19Blocked):
            raise operation_error
        if isinstance(operation_error, _R17.SourceMapGateR17Blocked):
            raise operation_error
        if isinstance(operation_error, _R16.FinalOutputHoldR16Blocked):
            raise operation_error
        raise ChildEntryPathR20Blocked("r20_r16_composite_blocked") from None
    _check(wrappers_intact, "r20_patch_context_changed")
    runtime_map_path = context.get("source_map_path")
    _check(type(runtime_map_path) is str, "r20_runtime_map_path_unbound")
    _check(type(result) is _R16.R16RootPreparedHold, "r20_r16_result_type")

    try:
        r17_addition, r17_digest, runtime_map_sha = _ORIGINAL_R17_ADD_HOLD_ROW(
            result,
            r17_source[0],
            r17_source[1],
            r17_source[2],
            runtime_map_path,
        )
        r17_result = _R17.R17RootPreparedHold(
            schema=_R17.R17_RESULT_SCHEMA,
            r16_result=result,
            r17_helper_path=r17_source[0],
            r17_helper_bytes=r17_source[1],
            r17_helper_sha256=r17_source[2],
            runtime_source_map_path=runtime_map_path,
            runtime_source_map_sha256=runtime_map_sha,
            hold_addition=r17_addition,
            hold_addition_sha256=r17_digest,
        )
        _check(_R17.verify_hold_addition(r17_result), "r20_r17_result_binding")
        r19_addition, r19_digest = _R19._add_r19_hold_row(r17_result, r19_source)
        r19_result = _R19.R19RootPreparedHold(
            schema=_R19.R19_RESULT_SCHEMA,
            r17_result=r17_result,
            r19_helper_path=r19_source[0],
            r19_helper_bytes=r19_source[1],
            r19_helper_sha256=r19_source[2],
            hold_addition=r19_addition,
            hold_addition_sha256=r19_digest,
        )
        _check(_R19.verify_root_hold(r19_result), "r20_r19_result_binding")
        addition, digest = _add_r20_row(r19_result.hold_addition, r20_source)
    except ChildEntryPathR20Blocked:
        raise
    except BaseException:
        raise ChildEntryPathR20Blocked("r20_r19_result_binding") from None

    return R20RootPreparedHold(
        schema=R20_RESULT_SCHEMA,
        r19_result=r19_result,
        r20_helper_path=r20_source[0],
        r20_helper_bytes=r20_source[1],
        r20_helper_sha256=r20_source[2],
        hold_addition=addition,
        hold_addition_sha256=digest,
    )


def verify_root_hold(value: Any) -> bool:
    try:
        if type(value) is not R20RootPreparedHold or value.schema != R20_RESULT_SCHEMA:
            return False
        r20_source = _self_source()
        if (value.r20_helper_path, value.r20_helper_bytes, value.r20_helper_sha256) != r20_source:
            return False
        if not _R19.verify_root_hold(value.r19_result):
            return False
        addition, digest = _add_r20_row(value.r19_result.hold_addition, r20_source)
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False


@dataclasses.dataclass(frozen=True)
class R20ParentAdapterResult:
    """R19 parent adapter plus the exact R20 source row and final digest."""

    schema: str
    prepared_hold: R20RootPreparedHold
    r19_adapter_result: Any
    adapter: Any
    r20_helper_path: str
    r20_helper_bytes: bytes
    r20_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    r13_recompose_calls: int
    r13_outer_transform_calls: int
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def r19_result(self) -> Any:
        return self.prepared_hold.r19_result

    @property
    def r17_result(self) -> Any:
        return self.r19_result.r17_result

    @property
    def prepared_r13(self) -> Any:
        return self.r19_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r19_result.prepared_r14


def construct_parent_adapter(
    prepared_hold: Any,
    *,
    adapter_kwargs: Optional[dict[str, Any]] = None,
) -> R20ParentAdapterResult:
    """Recompose the exact R20 outer under the frozen R14 constructor."""
    r20_source = _self_source()
    r17_source = _R17._self_source()
    r18_source = _R18._self_source()
    r19_source = _R19._self_source()
    _verify_sources(r17_source, r18_source, r19_source, r20_source)
    _check(verify_root_hold(prepared_hold), "r20_prepared_binding")
    r19_result = prepared_hold.r19_result
    try:
        _R18._validated_inputs(r19_result.r17_result, r18_source)
    except BaseException:
        raise ChildEntryPathR20Blocked("r20_prepared_binding") from None
    runtime_map_path = r19_result.runtime_source_map_path
    if not _R17._PATCH_LOCK.acquire(blocking=False):
        raise ChildEntryPathR20Blocked("r20_patch_context_busy")

    owner = threading.get_ident()
    original_compose = _R13._compose
    original_outer = _R13._active_outer_source
    context: dict[str, Any] = {"runtime_map_path": None, "compose_calls": 0, "outer_calls": 0}
    wrappers_installed = False
    wrappers_intact = True
    adapter = None
    operation_error: Optional[BaseException] = None
    kwargs = dict(adapter_kwargs or {})
    try:
        _check(
            _R17._PATCH_OWNER_THREAD is None
            and original_compose is _ORIGINAL_R13_COMPOSE
            and original_outer is _ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
            "r20_patch_context_changed",
        )

        def assert_owner() -> None:
            _check(
                threading.get_ident() == owner,
                "r20_patch_owner_thread",
            )
            _check(
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper,
                "r20_patch_context_changed",
            )

        def compose_wrapper(base_r11: Any) -> Any:
            assert_owner()
            current_path = _R17._runtime_source_map_path(base_r11)
            _check(current_path == runtime_map_path, "r20_descriptor_input_changed")
            previous = context["runtime_map_path"]
            _check(previous is None or previous == current_path, "r20_descriptor_input_changed")
            context["runtime_map_path"] = current_path
            context["compose_calls"] += 1
            return original_compose(base_r11)

        def outer_wrapper(*args: Any, **outer_kwargs: Any) -> bytes:
            assert_owner()
            _check(context["runtime_map_path"] == runtime_map_path, "r20_runtime_map_path_unbound")
            context["outer_calls"] += 1
            base_outer = original_outer(*args, **outer_kwargs)
            try:
                r17_outer = _ORIGINAL_R17_APPLY(
                    base_outer,
                    runtime_map_path,
                    r17_source[0],
                    r17_source[2],
                    _R17._R17_OUTER_SUPPORT,
                )
                r19_outer = _ORIGINAL_R19_APPLY(
                    r17_outer,
                    r19_source[0],
                    r19_source[2],
                    r19_source[1],
                    _R19._R19_OUTER_SUPPORT,
                )
                return _apply_active_outer_transform(
                    r19_outer,
                    r20_source[0],
                    r20_source[2],
                    r20_source[1],
                    _R20_OUTER_SUPPORT,
                )
            except BaseException:
                raise ChildEntryPathR20Blocked("r20_active_outer_transform") from None

        _R13._compose = compose_wrapper
        _R13._active_outer_source = outer_wrapper
        wrappers_installed = True
        try:
            adapter = _R14.M01WindowsParentAdapter(
                prepared_hold.prepared_r14,
                **kwargs,
            )
        except BaseException as exc:
            operation_error = exc
    except BaseException as exc:
        operation_error = exc
    finally:
        if wrappers_installed:
            wrappers_intact = (
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper
            )
            _R13._compose = original_compose
            _R13._active_outer_source = original_outer
        _R17._PATCH_LOCK.release()

    if operation_error is not None:
        if type(operation_error) is _R13.ActiveOuterActivationBlocked:
            raise operation_error
        if type(operation_error) is _R14.ParentAdapterTransportBlocked:
            raise operation_error
        if type(operation_error) is _R19.ChildSourceScopeR19Blocked:
            raise operation_error
        if type(operation_error) is ChildEntryPathR20Blocked:
            raise operation_error
        raise ChildEntryPathR20Blocked("r20_r14_result") from None
    _check(wrappers_intact, "r20_patch_context_changed")
    _check(type(adapter) is _R14.M01WindowsParentAdapter, "r20_r14_result")
    _check(adapter.prepared is prepared_hold.prepared_r14, "r20_adapter_binding")
    _check(context["compose_calls"] == 1, "r20_recompose_count")
    _check(context["outer_calls"] == 1, "r20_outer_transform_count")

    try:
        r19_addition, _r18_digest = _R18._r18_add_hold_row(r19_result.r17_result, r18_source)
        entries = dict(r19_addition.get("entries", {}))
        _check(
            all(_R13._R10._R9._normalized(path) != _R13._R10._R9._normalized(r19_result.r19_helper_path)
                for path in entries),
            "r20_hold_collision",
        )
        entries[r19_result.r19_helper_path] = {
            "sha256": r19_result.r19_helper_sha256,
            "size_bytes": len(r19_result.r19_helper_bytes),
            "role": _R19.R19_SOURCE_ROLE,
            "origin": "repository_source:" + _R19.R19_RELATIVE_PATH,
        }
        r19_addition["entries"] = dict(sorted(entries.items()))
        r19_digest = _sha(_canonical_json(r19_addition))
        r19_adapter_result = _R19.R19ParentAdapterResult(
            schema=_R19.R19_ADAPTER_RESULT_SCHEMA,
            prepared_hold=r19_result,
            adapter=adapter,
            r18_helper_path=r18_source[0],
            r18_helper_bytes=r18_source[1],
            r18_helper_sha256=r18_source[2],
            hold_addition=r19_addition,
            hold_addition_sha256=r19_digest,
            r13_recompose_calls=context["compose_calls"],
            r13_outer_transform_calls=context["outer_calls"],
        )
        _check(_R19.verify_parent_adapter_result(r19_adapter_result), "r20_r19_result_binding")
        addition, digest = _add_r20_row(r19_addition, r20_source)
    except ChildEntryPathR20Blocked:
        raise
    except BaseException:
        raise ChildEntryPathR20Blocked("r20_hold_digest") from None

    result = R20ParentAdapterResult(
        schema=R20_ADAPTER_RESULT_SCHEMA,
        prepared_hold=prepared_hold,
        r19_adapter_result=r19_adapter_result,
        adapter=adapter,
        r20_helper_path=r20_source[0],
        r20_helper_bytes=r20_source[1],
        r20_helper_sha256=r20_source[2],
        hold_addition=addition,
        hold_addition_sha256=digest,
        r13_recompose_calls=context["compose_calls"],
        r13_outer_transform_calls=context["outer_calls"],
    )
    _check(verify_parent_adapter_result(result), "r20_hold_digest")
    return result


def verify_parent_adapter_result(value: Any) -> bool:
    """Freshly validate R17/R18/R19/R20 source rows, adapter, and final digest."""
    try:
        if type(value) is not R20ParentAdapterResult or value.schema != R20_ADAPTER_RESULT_SCHEMA:
            return False
        if not verify_root_hold(value.prepared_hold):
            return False
        r20_source = _self_source()
        if (value.r20_helper_path, value.r20_helper_bytes, value.r20_helper_sha256) != r20_source:
            return False
        if not _R19.verify_parent_adapter_result(value.r19_adapter_result):
            return False
        if value.adapter is not value.r19_adapter_result.adapter:
            return False
        if value.r13_recompose_calls != 1 or value.r13_outer_transform_calls != 1:
            return False
        expected, digest = _add_r20_row(value.r19_adapter_result.hold_addition, r20_source)
        return (
            value.hold_addition == expected
            and value.hold_addition_sha256 == digest
            and value.hold_addition.get("canonical_child_map_count") == 154
        )
    except BaseException:
        return False
