"""Additive R13 repair for the frozen R28 driver-activation gate.

R13 keeps the canonical 154-entry child map and all R28/R31/R10/R11/R12
source bytes unchanged. It composes the exact R31-to-R10 active outer, replaces
only the stale R28 ``driver_activation_copy`` equality gate with a manifest-
and-map-bound held-output verifier, then rebuilds the R10/R11/R12 derived
transport bytes. It does not activate a Root runner or perform provider work.
"""

from __future__ import annotations

import copy
import dataclasses
import hashlib
import json
import ntpath
import os
import re
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_outer_reason_ordinal_observer_r12_r2 as _R12
from scripts import iteration41_okx_m01_r33_returned_result_observer_r11_r1 as _R11
from scripts import iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1 as _R10


R13_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_active_outer_activation_r13_r1.py"
R13_BINDING_SCHEMA = "iteration41.okx.m01.r33.active-outer-gate-r13.r1.v1"
R13_HOLD_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition-r13.r1.v1"
R13_TRANSFORM_SCHEMA = "iteration41.okx.m01.r33.held-active-outer-transform-r13.r1.v1"
R13_SIDECAR_ROLE = "r13_r12_result_observer_bootstrap_sidecar"
R13_SOURCE_ROLE = "r13_active_outer_activation_source"
R13_R12_DEPENDENCY_ROLE = "r13_exact_r12_runtime_dependency"
R13_ONCE_ORIGIN = "generated_r13_once_from_exact_r10_base"
R13_GATE_MARKER = b"iteration41.okx.m01.r33.held-active-outer-transform-r13.r1.v1"
R13_MAX_OUTER_BYTES = 2 * 1024 * 1024
R13_ORIGINAL_TEMPLATE_SHA256 = "a143012f98af4579d416363cc2cb5b8551c7217dadbc5cb4ff826a48c89d4c4e"
R13_R10_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1.py"
R13_R10_SHA256 = "96a8edc31f7dc2dc88158f1d9ccd5142bbe1d405d8f2c57ee3deed38aec69226"
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")


class ActiveOuterActivationBlocked(ValueError):
    """A fixed R13 source, map, or transport contract failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ActiveOuterActivationBlocked(code)


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _self_source() -> tuple[str, bytes, str]:
    _check(__name__ == R13_RELATIVE_PATH[:-3].replace("/", "."), "r13_module_name")
    path = Path(__file__).resolve()
    root = Path(_R10.__file__).resolve().parents[1]
    expected = (root / Path(*R13_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected, "r13_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(2 * 1024 * 1024 + 1)
    except BaseException:
        raise ActiveOuterActivationBlocked("r13_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= 2 * 1024 * 1024, "r13_source_size")
    return str(path), raw, _sha(raw)


def _pinned_r12_source() -> tuple[str, bytes, str]:
    path, raw, digest = _R12._self_source()
    _check(
        getattr(_R12, "__name__", None)
        == "scripts.iteration41_okx_m01_r33_outer_reason_ordinal_observer_r12_r2",
        "r12_module_name",
    )
    _check(_sha(raw) == digest and digest == _R12._sha(raw), "r12_source_binding")
    return path, raw, digest


def _replace_once(raw: bytes, old: bytes, new: bytes, code: str) -> bytes:
    _check(type(raw) is bytes and raw.count(old) == 1, code)
    result = raw.replace(old, new, 1)
    _check(type(result) is bytes and result != raw, code)
    return result


_R13_OUTER_SUPPORT = br'''
import ast
import ntpath

R13_ACTIVE_OUTER_TRANSFORM_SCHEMA = __R13_SCHEMA__
R13_BASE_R10_OUTER_SHA256 = __R13_BASE_SHA256__
R13_BASE_R10_OUTER_SIZE_BYTES = __R13_BASE_SIZE__
R13_EXPECTED_PLAN_SHA256 = __R13_PLAN_SHA256__
R13_EXPECTED_NAMESPACE = json.loads(__R13_NAMESPACE_JSON__)
R13_EXPECTED_R28_TEMPLATE_SHA256 = __R13_TEMPLATE_SHA256__
R13_GENERATOR_PATH = __R13_GENERATOR_PATH__
R13_GENERATOR_SHA256 = __R13_GENERATOR_SHA256__
R13_GENERATOR_SIZE_BYTES = __R13_GENERATOR_SIZE__
R13_GENERATOR_RELATIVE_PATH = __R13_GENERATOR_RELATIVE_PATH__
R13_R10_COMPOSER_PATH = __R13_R10_PATH__
R13_R10_COMPOSER_SHA256 = __R13_R10_SHA256__
R13_R10_COMPOSER_SIZE_BYTES = __R13_R10_SIZE__
R13_R10_EXTERNAL_SOURCE_ROWS = json.loads(__R13_R10_EXTERNAL_ROWS_JSON__)
R13_ACTIVE_OUTER_MARKER = b"iteration41.okx.m01.r33.held-active-outer-transform-r13.r1.v1"


def _r13_norm(path):
    return os.path.normcase(os.path.normpath(str(path)))


def _r13_exact_held(held, path):
    _check(type(held) is dict and type(path) is str, "r13_held_shape")
    target = _r13_norm(path)
    matches = [
        value for key, value in held.items()
        if type(key) is str and _r13_norm(key) == target
    ]
    _check(len(matches) == 1 and type(matches[0]) is bytes, "r13_held_missing")
    return matches[0]


def _r13_map_pin(mapping, path, digest, code):
    _check(type(mapping) is dict and type(path) is str, code)
    target = _r13_norm(path)
    values = [
        value for key, value in mapping.items()
        if type(key) is str and _r13_norm(key) == target
    ]
    _check(len(values) == 1 and values[0] == digest, code)


def _r13_replace_once(raw, old, new, code):
    _check(type(raw) is bytes and type(old) is bytes and type(new) is bytes, code)
    _check(raw.count(old) == 1, code)
    result = raw.replace(old, new, 1)
    _check(type(result) is bytes and result != raw, code)
    return result


def _r13_read_pinned_source(path, digest, size):
    _check(
        type(path) is str
        and type(digest) is str
        and _HEX64.fullmatch(digest) is not None
        and type(size) is int
        and 0 < size <= 16 * 1024 * 1024,
        "r13_pinned_source_shape",
    )
    try:
        with Path(path).open("rb") as stream:
            before = os.fstat(stream.fileno())
            stream.seek(0)
            raw = stream.read(size + 1)
            after = os.fstat(stream.fileno())
    except BaseException:
        raise ValueError("r13_pinned_source_unavailable") from None
    first = (
        before.st_dev, before.st_ino, before.st_size,
        getattr(before, "st_mtime_ns", None), getattr(before, "st_ctime_ns", None),
    )
    second = (
        after.st_dev, after.st_ino, after.st_size,
        getattr(after, "st_mtime_ns", None), getattr(after, "st_ctime_ns", None),
    )
    _check(
        first == second
        and before.st_size == size
        and type(raw) is bytes
        and len(raw) == size
        and _sha(raw) == digest,
        "r13_pinned_source_changed",
    )
    return raw


def _r13_source_nodes(raw):
    _check(type(raw) is bytes and 0 < len(raw) <= 2 * 1024 * 1024, "r13_source_size")
    try:
        tree = ast.parse(raw.decode("utf-8"))
    except (UnicodeDecodeError, SyntaxError, ValueError):
        raise ValueError("r13_source_parse") from None
    assignments = {}
    functions = {}
    for node in tree.body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for target in targets:
                if isinstance(target, ast.Name):
                    assignments[target.id] = node.value
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions.setdefault(node.name, []).append(node)
    return assignments, functions


def _r13_constant_node(node, assignments, memo, visiting):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return _r13_constant(node.id, assignments, memo, visiting)
    if isinstance(node, (ast.Tuple, ast.List)):
        values = [_r13_constant_node(item, assignments, memo, visiting) for item in node.elts]
        return tuple(values) if isinstance(node, ast.Tuple) else values
    if isinstance(node, ast.Dict):
        return {
            _r13_constant_node(key, assignments, memo, visiting):
            _r13_constant_node(value, assignments, memo, visiting)
            for key, value in zip(node.keys, node.values)
        }
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _r13_constant_node(node.left, assignments, memo, visiting) + _r13_constant_node(
            node.right, assignments, memo, visiting
        )
    raise ValueError("r13_source_constant_expression")


def _r13_constant(name, assignments, memo, visiting):
    if name in memo:
        return memo[name]
    _check(name not in visiting and name in assignments, "r13_source_constant_missing")
    visiting.add(name)
    value = _r13_constant_node(assignments[name], assignments, memo, visiting)
    visiting.remove(name)
    memo[name] = value
    return value


def _r13_compile_function(namespace, functions, source_name, exported_name):
    matches = functions.get(source_name, [])
    _check(len(matches) == 1, "r13_source_function_count")
    node = matches[0]
    node.name = exported_name
    for argument in node.args.posonlyargs + node.args.args + node.args.kwonlyargs:
        argument.annotation = None
    if node.args.vararg is not None:
        node.args.vararg.annotation = None
    if node.args.kwarg is not None:
        node.args.kwarg.annotation = None
    node.returns = None
    module = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(module)
    try:
        exec(compile(module, "<r13-pinned-source-function>", "exec", dont_inherit=True), namespace)
    except BaseException:
        raise ValueError("r13_source_function_compile") from None
    return namespace[exported_name]


class _R13PathShim:
    @staticmethod
    def _normalized(path):
        return os.path.normcase(os.path.normpath(str(path)))


def _r13_rebuild_r10_outer(plan_raw):
    """Run the pinned R31 output builder and the pinned R10 outer composer."""
    prepared, base_outer, base_wrapper = _r10_regenerate_r31_outputs(plan_raw)
    _check(
        type(prepared) is dict
        and type(prepared.get("manifest")) is dict
        and prepared["manifest"].get("runtime_namespace") == R13_EXPECTED_NAMESPACE,
        "r13_r31_manifest_binding",
    )
    r10_raw = _r13_read_pinned_source(
        R13_R10_COMPOSER_PATH,
        R13_R10_COMPOSER_SHA256,
        R13_R10_COMPOSER_SIZE_BYTES,
    )
    assignments, functions = _r13_source_nodes(r10_raw)
    memo = {}
    names = (
        "R10_ACTIVATION_SOURCE_SPECS",
        "R10_ACTIVATION_SOURCE_ROLE",
        "R10_ACTIVATION_TRANSFORM_SCHEMA",
        "R10_EXTERNAL_SOURCE_ROLE",
        "R28_EXTERNAL_SOURCE_SPECS",
        "_R10_ACTIVE_OUTER_SUPPORT",
    )
    constants = {name: _r13_constant(name, assignments, memo, set()) for name in names}
    _check(
        type(constants["R10_ACTIVATION_SOURCE_SPECS"]) is tuple
        and type(constants["R28_EXTERNAL_SOURCE_SPECS"]) is tuple
        and type(constants["_R10_ACTIVE_OUTER_SUPPORT"]) is bytes,
        "r13_r10_constants_shape",
    )
    transform_globals = {
        "Any": object,
        "json": json,
        "ntpath": ntpath,
        "_HEX64": _HEX64,
        "_R9": _R13PathShim,
        "_check": _check,
        "_sha": _sha,
        "_replace_once": _r13_replace_once,
        **constants,
    }
    transform = _r13_compile_function(
        transform_globals, functions, "_r10_active_outer_source", "_r13_r10_active_outer_source"
    )

    rows = R13_R10_EXTERNAL_SOURCE_ROWS
    _check(type(rows) is list and len(rows) == 13, "r13_r10_external_rows")
    rows_by_name = {row.get("name"): row for row in rows if type(row) is dict}
    _check(len(rows_by_name) == 13, "r13_r10_external_source_set")
    activation_rows = R10_ACTIVATION_SOURCE_ROWS
    _check(type(activation_rows) is list and len(activation_rows) == 10, "r13_r10_activation_rows")
    external = []
    for row in activation_rows:
        pinned = rows_by_name.get(row.get("name")) if type(row) is dict else None
        _check(
            type(pinned) is dict
            and set(pinned) == {"name", "path", "sha256", "size_bytes", "role", "origin"}
            and pinned["path"] == row.get("path")
            and pinned["sha256"] == row.get("sha256")
            and pinned["size_bytes"] == row.get("size_bytes")
            and pinned["role"] == row.get("role")
            and pinned["origin"] == row.get("origin"),
            "r13_r10_activation_source_binding",
        )
        raw = _r10_activation_read_source(row)
        external.append(
            (row["name"], row["path"], raw, row["sha256"], row["role"], row["origin"])
        )
    activation_names = {row["name"] for row in activation_rows}
    origins = {
        "cli": "R28_ONCE.R28_CLI_HELPER_SHA256+R28_OUTER.CLI_REL+CLI_SHA256",
        "job": "R28_ONCE.R28_JOB_PATH+R28_JOB_SHA256",
        "cleanup": "R28_ONCE.R28_CLEANUP_PATH+R28_CLEANUP_SHA256",
    }
    standard_specs = constants["R28_EXTERNAL_SOURCE_SPECS"]
    _check(len(standard_specs) == 3, "r13_r10_standard_specs")
    for name, relative, digest in standard_specs:
        pinned = rows_by_name.get(name)
        _check(
            name not in activation_names
            and type(pinned) is dict
            and set(pinned) == {"name", "path", "sha256", "size_bytes", "role", "origin"}
            and pinned["sha256"] == digest
            and pinned["role"] == constants["R10_EXTERNAL_SOURCE_ROLE"] + ":" + name
            and pinned["origin"] == origins[name],
            "r13_r10_standard_source_binding",
        )
        expected_path = ntpath.join(
            prepared["manifest"]["root"], relative.replace("/", "\\")
        )
        _check(_R13PathShim._normalized(expected_path) == _R13PathShim._normalized(pinned["path"]),
               "r13_r10_standard_source_path")
        size = pinned["size_bytes"]
        _check(type(size) is int and 0 < size <= 16 * 1024 * 1024, "r13_r10_standard_source_size")
        raw = _r13_read_pinned_source(pinned["path"], digest, size)
        external.append((name, pinned["path"], raw, digest, pinned["role"], pinned["origin"]))
    _check(len(external) == 13 and {row[0] for row in external} == set(rows_by_name),
           "r13_r10_external_source_closure")
    active_outer = transform(
        base_outer,
        base_wrapper,
        prepared["manifest"],
        R13_EXPECTED_PLAN_SHA256,
        tuple(external),
    )
    _check(
        type(active_outer) is bytes
        and len(active_outer) == R13_BASE_R10_OUTER_SIZE_BYTES
        and _sha(active_outer) == R13_BASE_R10_OUTER_SHA256,
        "r13_r10_active_outer_rebuild",
    )
    return active_outer, prepared


def _r13_rebuild_exact_active_outer(base_r10_outer, outer):
    """Re-run the exact source-bound R13 generator and compare full bytes."""
    generator_raw = _r13_read_pinned_source(
        R13_GENERATOR_PATH,
        R13_GENERATOR_SHA256,
        R13_GENERATOR_SIZE_BYTES,
    )
    assignments, functions = _r13_source_nodes(generator_raw)
    try:
        support_template = ast.literal_eval(assignments["_R13_OUTER_SUPPORT"])
        generator_relative = ast.literal_eval(assignments["R13_RELATIVE_PATH"])
        r10_relative = ast.literal_eval(assignments["R13_R10_RELATIVE_PATH"])
        r10_sha256 = ast.literal_eval(assignments["R13_R10_SHA256"])
        transform_schema = ast.literal_eval(assignments["R13_TRANSFORM_SCHEMA"])
        original_template_sha256 = ast.literal_eval(assignments["R13_ORIGINAL_TEMPLATE_SHA256"])
        gate_marker = ast.literal_eval(assignments["R13_GATE_MARKER"])
    except BaseException:
        raise ValueError("r13_source_constants_unavailable") from None
    _check(
        type(support_template) is bytes
        and type(generator_relative) is str
        and generator_relative == R13_GENERATOR_RELATIVE_PATH
        and type(r10_relative) is str
        and type(r10_sha256) is str
        and _HEX64.fullmatch(r10_sha256) is not None
        and type(transform_schema) is str
        and type(original_template_sha256) is str
        and type(gate_marker) is bytes,
        "r13_source_constants_shape",
    )
    repo_root = ntpath.dirname(ntpath.dirname(R13_GENERATOR_PATH))
    _check(
        _r13_norm(R13_GENERATOR_PATH)
        == _r13_norm(ntpath.join(repo_root, generator_relative.replace("/", "\\"))),
        "r13_generator_path_binding",
    )
    _check(
        r10_sha256 == R13_R10_COMPOSER_SHA256
        and _r13_norm(R13_R10_COMPOSER_PATH)
        == _r13_norm(ntpath.join(repo_root, r10_relative.replace("/", "\\"))),
        "r13_r10_source_binding",
    )
    namespace = {
        "json": json,
        "ntpath": ntpath,
        "_check": _check,
        "_sha": _sha,
        "_replace_once": _r13_replace_once,
        "_HEX64": _HEX64,
        "R13_RELATIVE_PATH": generator_relative,
        "R13_R10_RELATIVE_PATH": r10_relative,
        "R13_R10_SHA256": r10_sha256,
        "R13_TRANSFORM_SCHEMA": transform_schema,
        "R13_ORIGINAL_TEMPLATE_SHA256": original_template_sha256,
        "R13_GATE_MARKER": gate_marker,
        "R13_MAX_OUTER_BYTES": 2 * 1024 * 1024,
        "_R13_OUTER_SUPPORT": support_template,
    }
    builder = _r13_compile_function(
        namespace, functions, "_active_outer_source", "_r13_active_outer_source"
    )
    expected = builder(
        base_r10_outer,
        outer=outer,
        generator_path=R13_GENERATOR_PATH,
        generator_sha256=R13_GENERATOR_SHA256,
        generator_size_bytes=R13_GENERATOR_SIZE_BYTES,
        r10_composer_path=R13_R10_COMPOSER_PATH,
        r10_composer_sha256=R13_R10_COMPOSER_SHA256,
        r10_composer_size_bytes=R13_R10_COMPOSER_SIZE_BYTES,
        external_source_rows=tuple(R13_R10_EXTERNAL_SOURCE_ROWS),
    )
    return expected


def _r13_verify_generated_active_outer(
    held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map
):
    """Bind the physical active outer to the validated same-call source map."""
    _check(
        type(candidate_template) is bytes
        and _sha(candidate_template) == R13_EXPECTED_R28_TEMPLATE_SHA256,
        "r13_original_template_pin",
    )
    _check(
        type(active_driver) is bytes
        and type(self_sha256) is str
        and re.fullmatch(r"[0-9a-f]{64}", self_sha256) is not None
        and type(plan_raw) is bytes
        and _sha(plan_raw) == R13_EXPECTED_PLAN_SHA256,
        "r13_plan_or_self_shape",
    )
    _check(
        type(source_map) is dict
        and source_map.get("runtime_namespace") == R13_EXPECTED_NAMESPACE
        and source_map.get("plan_sha256") == R13_EXPECTED_PLAN_SHA256
        and source_map.get("map_counts") == {"public": 118, "software": 36, "canonical": 154},
        "r13_source_map_binding",
    )
    namespace = R13_EXPECTED_NAMESPACE
    _check(
        type(self_path) is str
        and _r13_norm(self_path) == _r13_norm(namespace.get("self_path"))
        and _r13_norm(namespace.get("plan_path")) == _r13_norm(PLAN_PATH),
        "r13_namespace_binding",
    )
    held_outer = _r13_exact_held(held, self_path)
    _check(held_outer == active_driver, "r13_active_outer_held_bytes")
    base_r10_outer, _prepared = _r13_rebuild_r10_outer(plan_raw)
    regenerated = _r13_rebuild_exact_active_outer(
        base_r10_outer,
        {
            "active_outer": base_r10_outer,
            "active_outer_sha256": _sha(base_r10_outer),
            "active_outer_path": namespace["self_path"],
            "plan_path": namespace["plan_path"],
            "plan_sha256": R13_EXPECTED_PLAN_SHA256,
            "namespace": dict(namespace),
        },
    )
    _check(
        regenerated == active_driver
        and _sha(active_driver) == self_sha256
        and R13_ACTIVE_OUTER_MARKER in active_driver,
        "r13_exact_active_outer_rebuild",
    )
    _r13_map_pin(source_map.get("software_pins"), self_path, self_sha256, "r13_software_self_pin")
    _r13_map_pin(source_map.get("canonical_pins"), self_path, self_sha256, "r13_canonical_self_pin")
    plan_sha = _sha(plan_raw)
    _r13_map_pin(source_map.get("software_pins"), namespace["plan_path"], plan_sha, "r13_software_plan_pin")
    _r13_map_pin(source_map.get("canonical_pins"), namespace["plan_path"], plan_sha, "r13_canonical_plan_pin")
    return True

'''


def _active_outer_source(
    base_outer: bytes,
    *,
    outer: dict[str, Any],
    generator_path: str,
    generator_sha256: str,
    generator_size_bytes: int,
    r10_composer_path: str,
    r10_composer_sha256: str,
    r10_composer_size_bytes: int,
    external_source_rows: tuple[dict[str, Any], ...],
) -> bytes:
    """Replace exactly the obsolete R28 driver-template equality check."""
    _check(type(base_outer) is bytes and 0 < len(base_outer) <= R13_MAX_OUTER_BYTES, "base_outer_size")
    _check(type(outer) is dict, "outer_material_shape")
    template_sha = R13_ORIGINAL_TEMPLATE_SHA256
    plan_sha = outer.get("plan_sha256")
    namespace = outer.get("namespace")
    _check(type(plan_sha) is str and _HEX64.fullmatch(plan_sha) is not None, "plan_sha_shape")
    _check(type(namespace) is dict and set(namespace) == {
        "control_dir", "deployment_dir", "plan_path", "self_path", "active_wrapper_path", "attempt_claim_path"
    }, "namespace_shape")
    _check(
        type(generator_path) is str
        and type(generator_sha256) is str
        and _HEX64.fullmatch(generator_sha256) is not None
        and type(generator_size_bytes) is int
        and 0 < generator_size_bytes <= 2 * 1024 * 1024,
        "generator_source_binding",
    )
    repo_root = ntpath.dirname(ntpath.dirname(generator_path))
    _check(
        ntpath.normcase(ntpath.normpath(generator_path))
        == ntpath.normcase(
            ntpath.normpath(ntpath.join(repo_root, R13_RELATIVE_PATH.replace("/", "\\")))
        ),
        "generator_source_path",
    )
    _check(
        type(r10_composer_path) is str
        and type(r10_composer_sha256) is str
        and _HEX64.fullmatch(r10_composer_sha256) is not None
        and r10_composer_sha256 == R13_R10_SHA256
        and type(r10_composer_size_bytes) is int
        and 0 < r10_composer_size_bytes <= 2 * 1024 * 1024,
        "r10_composer_source_binding",
    )
    _check(
        ntpath.normcase(ntpath.normpath(r10_composer_path))
        == ntpath.normcase(
            ntpath.normpath(ntpath.join(repo_root, R13_R10_RELATIVE_PATH.replace("/", "\\")))
        ),
        "r10_composer_source_path",
    )
    _check(
        type(external_source_rows) is tuple
        and len(external_source_rows) == 13,
        "r10_external_source_rows_shape",
    )
    external_rows = []
    row_names = set()
    for row in external_source_rows:
        _check(
            type(row) is dict
            and set(row) == {"name", "path", "sha256", "size_bytes", "role", "origin"}
            and type(row["name"]) is str
            and row["name"] not in row_names
            and type(row["path"]) is str
            and type(row["sha256"]) is str
            and _HEX64.fullmatch(row["sha256"]) is not None
            and type(row["size_bytes"]) is int
            and 0 < row["size_bytes"] <= 16 * 1024 * 1024
            and type(row["role"]) is str
            and type(row["origin"]) is str,
            "r10_external_source_row_shape",
        )
        row_names.add(row["name"])
        external_rows.append(dict(row))
    _check(len(row_names) == 13, "r10_external_source_row_set")
    substitutions = {
        b"__R13_SCHEMA__": repr(R13_TRANSFORM_SCHEMA).encode("ascii"),
        b"__R13_BASE_SHA256__": repr(_sha(base_outer)).encode("ascii"),
        b"__R13_BASE_SIZE__": str(len(base_outer)).encode("ascii"),
        b"__R13_PLAN_SHA256__": repr(plan_sha).encode("ascii"),
        b"__R13_NAMESPACE_JSON__": repr(
            json.dumps(namespace, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        ).encode("ascii"),
        b"__R13_TEMPLATE_SHA256__": repr(template_sha).encode("ascii"),
        b"__R13_GENERATOR_PATH__": repr(generator_path).encode("ascii"),
        b"__R13_GENERATOR_SHA256__": repr(generator_sha256).encode("ascii"),
        b"__R13_GENERATOR_SIZE__": str(generator_size_bytes).encode("ascii"),
        b"__R13_GENERATOR_RELATIVE_PATH__": repr(R13_RELATIVE_PATH).encode("ascii"),
        b"__R13_R10_PATH__": repr(r10_composer_path).encode("ascii"),
        b"__R13_R10_SHA256__": repr(r10_composer_sha256).encode("ascii"),
        b"__R13_R10_SIZE__": str(r10_composer_size_bytes).encode("ascii"),
        b"__R13_R10_EXTERNAL_ROWS_JSON__": repr(
            json.dumps(external_rows, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        ).encode("ascii"),
    }
    support = _R13_OUTER_SUPPORT
    for marker, replacement in substitutions.items():
        _check(support.count(marker) == 1, "outer_support_anchor")
        support = support.replace(marker, replacement, 1)

    old_gate = (
        b"            _check(\n"
        b"                type(candidate_template) is bytes\n"
        b"                and type(active_driver) is bytes\n"
        b"                and _sha(active_driver) == self_sha256\n"
        b"                and normalize_driver_activation(active_driver) == candidate_template,\n"
        b'                "driver_activation_copy",\n'
        b"            )\n"
    )
    new_gate = (
        b"            _r13_verify_generated_active_outer(\n"
        b"                held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map\n"
        b"            )\n"
    )
    result = _replace_once(base_outer, old_gate, new_gate, "driver_activation_gate_anchor")
    result = _replace_once(result, b"def run_prelaunch(\n", support + b"def run_prelaunch(\n", "outer_support_anchor")
    try:
        compile(result, "<r13-generated-active-outer>", "exec", dont_inherit=True)
    except BaseException:
        raise ActiveOuterActivationBlocked("active_outer_compile") from None
    _check(
        result.count(b"_r13_verify_generated_active_outer(") == 2
        and b'"driver_activation_copy"' not in result
        and R13_GATE_MARKER in result,
        "active_outer_gate_contract",
    )
    return result


def _update_pin(mapping: dict[str, Any], path: str, digest: str, code: str) -> None:
    normalized = _R10._R9._normalized(path)
    matches = [key for key in mapping if type(key) is str and _R10._R9._normalized(key) == normalized]
    _check(len(matches) == 1, code)
    mapping[matches[0]] = digest


def _rebuild_r10_view(base: Any, outer: dict[str, Any], active_outer: bytes, generator: tuple[str, bytes, str]):
    """Rebind every R10 output after the one fixed outer-source edit."""
    r10 = _R10
    try:
        r10._validate_prepared(base)
        descriptor = r10._R9._R4._validate_descriptor(base.descriptor_json)
        source_map = r10._R9._R4._validate_source_map(base.source_map_bytes, descriptor)
        manifest = r10._manifest_from_runner(base.runner_bytes)
    except BaseException:
        raise ActiveOuterActivationBlocked("r10_base_rejected") from None
    updated = copy.deepcopy(manifest)
    active_outer_sha = _sha(active_outer)
    namespace = updated["runtime_namespace"]
    _check(namespace == outer["namespace"], "r13_namespace_rebind")
    _check(outer["plan_sha256"] == source_map.get("plan_sha256"), "r13_plan_rebind")
    updated["candidate"]["active_outer_sha256"] = active_outer_sha
    updated["runtime_outputs"]["root_prelaunch_source"]["sha256"] = active_outer_sha
    self_path = namespace["self_path"]
    _update_pin(updated["software_pins"], self_path, active_outer_sha, "r13_manifest_self_pin")
    _update_pin(updated["canonical_pins"], self_path, active_outer_sha, "r13_manifest_canonical_self_pin")
    r10_transform = dict(updated["r10_active_outer_source_transform"])
    r10_transform["active_outer_sha256"] = active_outer_sha
    r10_transform["active_outer_size_bytes"] = len(active_outer)
    r10_transform["role"] = "r31_r10_outer_with_manifest_bound_r13_held_output_gate"
    updated["r10_active_outer_source_transform"] = r10_transform
    generator_path, generator_raw, generator_sha = generator
    _check(_sha(generator_raw) == generator_sha, "r13_generator_source_pin")
    updated["r13_active_outer_source_transform"] = {
        "schema": R13_TRANSFORM_SCHEMA,
        "role": "exact_r31_r10_outer_with_fixed_r28_driver_gate_replacement",
        "generator_path": generator_path,
        "generator_sha256": generator_sha,
        "generator_size_bytes": len(generator_raw),
        "base_r10_active_outer_sha256": outer["active_outer_sha256"],
        "base_r10_active_outer_size_bytes": len(outer["active_outer"]),
        "active_outer_path": self_path,
        "active_outer_sha256": active_outer_sha,
        "active_outer_size_bytes": len(active_outer),
        "plan_path": namespace["plan_path"],
        "plan_sha256": outer["plan_sha256"],
        "namespace": dict(namespace),
        "original_r28_template_sha256": r10.R28_OUTER_TEMPLATE_SHA256,
        "gate_replacements": 1,
        "canonical_child_map_count": 154,
        "authority": False,
    }
    r10._seal_manifest(updated)
    try:
        r10._R31._validate_manifest(updated)
    except BaseException:
        raise ActiveOuterActivationBlocked("r13_manifest_rejected") from None

    base_once = r10._bounded_public(
        r10._repo_root() / Path(*r10.R28_ONCE_REL.split("/")),
        r10.R10_MAX_ONCE_BYTES,
        r10.R28_ONCE_SHA256,
    )
    active_wrapper_size = outer["active_wrapper_sha256"]
    _check(type(active_wrapper_size) is str and _HEX64.fullmatch(active_wrapper_size) is not None, "wrapper_digest_shape")
    # R10's pinned generation contract already carries the active wrapper bytes
    # through the 154-map derivation; rebuild from the unchanged R9/R31 inputs.
    base_descriptor = r10._R9._R4._validate_descriptor(base.r9_prepared.descriptor_json)
    base_source_map = r10._R9._R4._validate_source_map(
        base.r9_prepared.source_map_bytes, base_descriptor
    )
    base_manifest = r10._manifest_from_runner(base.r9_prepared.runner_bytes)
    _r31_outer, active_wrapper = r10._r31_active_outputs(base_manifest, base_source_map)
    _check(_sha(active_wrapper) == active_wrapper_size, "wrapper_output_binding")
    once_raw = r10._once_successor_source(
        base_once,
        updated,
        active_outer_size_bytes=len(active_outer),
        active_wrapper_size_bytes=len(active_wrapper),
        external_parent_sources=base.external_parent_sources,
    )
    once_sha = _sha(once_raw)
    _check(0 < len(once_raw) <= r10.R10_MAX_ONCE_BYTES, "r13_once_size")
    updated["once"]["path"] = base.once_path
    updated["once"]["sha256"] = once_sha
    updated["r10_once_predeployment"] = {
        "schema": r10.R10_PREPARATION_SCHEMA,
        "path": base.once_path,
        "sha256": once_sha,
        "size_bytes": len(once_raw),
        "role": r10.R10_ONCE_ROLE,
        "source_once_relative_path": r10.R28_ONCE_REL,
        "source_once_sha256": r10.R28_ONCE_SHA256,
        "source_once_size_bytes": len(base_once),
        "active_outer_path": namespace["self_path"],
        "active_outer_sha256": active_outer_sha,
        "active_outer_size_bytes": len(active_outer),
        "active_wrapper_path": namespace["active_wrapper_path"],
        "active_wrapper_sha256": _sha(active_wrapper),
        "active_wrapper_size_bytes": len(active_wrapper),
        "external_parent_sources": [
            {
                "name": name,
                "path": path,
                "sha256": digest,
                "size_bytes": len(raw),
                "role": role,
                "origin": origin,
            }
            for name, path, raw, digest, role, origin in base.external_parent_sources
        ],
        "external_source_reader": {
            "role": "r10_generated_bounded_from_start_stable_identity_reader",
            "implementation_function": "_r10_read_pinned_source",
            "implementation_generated_once_sha256": once_sha,
            "implementation_generated_once_size_bytes": len(once_raw),
            "max_read_bytes": "pinned_exact_size_plus_one",
            "checks": [
                "seek_to_offset_zero",
                "descriptor_identity_before_after",
                "exact_pinned_size",
                "exact_sha256",
            ],
            "generated_once_path": base.once_path,
            "source_composer_path": base.composer_path,
            "source_composer_sha256": base.composer_sha256,
        },
        "fixed_source_transformations": [
            "bind_R28_paths_to_fresh_namespace",
            "validate_R28_fill_outputs_against_frozen_templates",
            "select_R31_active_outer_and_wrapper_from_exact_154_map",
            "bind_R31_output_path_sha256_size_and_bytes",
            "replace_frozen_R28_wrapper_activation_copy_gate_with_exact_held_R31_regeneration",
            "replace_frozen_R28_driver_activation_copy_gate_with_exact_manifest_bound_R31_R10_output",
            "remove_test_port_entrypoint",
            "preserve_R30_predeployment_claim_capture_and_plan_gates",
        ],
        "r10_active_outer_source_transform": dict(r10_transform),
        "r13_active_outer_source_transform": dict(updated["r13_active_outer_source_transform"]),
        "source_composer_path": base.composer_path,
        "source_composer_sha256": base.composer_sha256,
        "source_composer_size_bytes": len(base.composer_bytes),
        "source_composer_role": r10.R10_COMPOSER_ROLE,
        "embedded_in_runner": True,
        "external_parent_hold_required": True,
        "external_parent_source_hold_required": True,
        "root_predeployment_required": True,
        "control_and_deployment_absence_gate_removed": True,
        "claim_policy": "frozen_r30_create_new_flush_bounded_readback",
        "capture_policy": "frozen_r30_fresh_capture",
        "outer_process_entry": "frozen_r28_bounded_job_spawn_without_test_port",
    }
    r10._seal_manifest(updated)
    try:
        r10._R31._validate_manifest(updated)
    except BaseException:
        raise ActiveOuterActivationBlocked("r13_final_manifest_rejected") from None

    runner = r10._render_runner(updated, once_raw)
    _check(0 < len(runner) <= r10.R10_MAX_RUNNER_BYTES, "r13_runner_size")
    source_map = copy.deepcopy(source_map)
    _update_pin(source_map["software_pins"], namespace["self_path"], active_outer_sha, "r13_source_map_software_self_pin")
    _update_pin(source_map["canonical_pins"], namespace["self_path"], active_outer_sha, "r13_source_map_canonical_self_pin")
    source_map["runner_template_sha256"] = _sha(runner)
    source_map["manifest_binding_sha256"] = updated["manifest_binding_sha256"]
    source_map["runtime_namespace"] = dict(namespace)
    source_map_raw = r10._canonical_json(source_map)
    _check(0 < len(source_map_raw) <= r10.R10_MAX_SOURCE_MAP_BYTES, "r13_source_map_size")
    descriptor = dict(descriptor)
    descriptor["runner_sha256"] = _sha(runner)
    descriptor["source_map_sha256"] = _sha(source_map_raw)
    descriptor["manifest_binding_sha256"] = updated["manifest_binding_sha256"]
    descriptor["runner_template_schema"] = updated["runner_template_schema"]
    descriptor_raw = r10._canonical_json(descriptor)
    _check(0 < len(descriptor_raw) <= r10.R10_MAX_DESCRIPTOR_BYTES, "r13_descriptor_size")
    r10._R9._R4._validate_descriptor(descriptor_raw)
    r10._R9._R4._validate_source_map(source_map_raw, descriptor)

    bootstrap = base.r9_prepared.r8_bootstrap_bytes
    stub = r10._R9._stub_source(
        sidecar_path=base.sidecar_path,
        bootstrap_size=len(bootstrap),
        bootstrap_sha256=_sha(bootstrap),
        descriptor_size=len(descriptor_raw),
        descriptor_sha256=_sha(descriptor_raw),
    )
    stdin_raw = r10._R9._wire_prefix(bootstrap) + descriptor_raw
    _check(len(stdin_raw) <= r10._R9.MAX_STDIN_BYTES, "r13_r10_stdin_limit")
    command = tuple(base.command[:7]) + (stub.decode("utf-8"),)
    units = r10._R9._command_line_units(command)
    _check(units <= r10._R9.MAX_COMMAND_LINE_UNITS, "r13_r10_command_limit")
    binding = dict(base.binding)
    binding.update(
        {
            "schema": r10.R10_BINDING_SCHEMA,
            "handoff_schema": r10.R10_PREPARATION_SCHEMA,
            "runner_sha256": _sha(runner),
            "source_map_sha256": _sha(source_map_raw),
            "manifest_binding_sha256": updated["manifest_binding_sha256"],
            "descriptor_json_sha256": _sha(descriptor_raw),
            "descriptor_json_size_bytes": len(descriptor_raw),
            "stdin_transport_size_bytes": len(stdin_raw),
            "once_executor_path": base.once_path,
            "once_executor_sha256": once_sha,
            "once_executor_size_bytes": len(once_raw),
            "once_executor_role": r10.R10_ONCE_ROLE,
            "source_composer_path": base.composer_path,
            "source_composer_sha256": base.composer_sha256,
            "source_composer_size_bytes": len(base.composer_bytes),
            "source_composer_role": r10.R10_COMPOSER_ROLE,
            "external_parent_sources": [
                {"name": name, "path": path, "sha256": digest, "size_bytes": len(raw), "role": role, "origin": origin}
                for name, path, raw, digest, role, origin in base.external_parent_sources
            ],
            "r8_observed_once_path": base.once_path,
            "r8_observed_once_sha256": once_sha,
            "r9_bootstrap_sidecar_path": base.sidecar_path,
            "r9_bootstrap_sidecar_sha256": base.sidecar_sha256,
            "r9_bootstrap_sidecar_size_bytes": base.sidecar_size_bytes,
            "windows_command_line_utf16_units_including_nul": units,
            "windows_command_line_limit_utf16_units_including_nul": r10._R9.MAX_COMMAND_LINE_UNITS,
            "canonical_map_counts": {"public": 118, "software": 36, "canonical": 154},
            "r13_active_outer_source_transform": dict(updated["r13_active_outer_source_transform"]),
        }
    )
    binding_sha = r10._R6._canonical_binding_digest(binding, command, base.cwd)
    return dataclasses.replace(
        base,
        command=command,
        descriptor_json=descriptor_raw,
        stdin_descriptor=stdin_raw,
        source_map_bytes=source_map_raw,
        runner_bytes=runner,
        once_bytes=once_raw,
        once_sha256=once_sha,
        once_size_bytes=len(once_raw),
        stub_bytes=stub,
        binding=binding,
        binding_sha256=binding_sha,
        windows_command_line_units=units,
    )


def _rebuild_r11_view(base: Any, r10_view: Any):
    r11 = _R11
    base_r8 = base.r10_prepared.r9_prepared.r8_prepared
    r11._R8._validate_prepared(base_r8)
    bootstrap = r11._compose_bootstrap(r10_view.sidecar_bytes)
    descriptor = r11._R9._R4._validate_descriptor(r10_view.descriptor_json)
    descriptor_sha = _sha(r10_view.descriptor_json)
    sidecar_path = r11._R9._sidecar_path(descriptor["runtime_namespace"]["deployment_dir"], _sha(bootstrap))
    stub = r11._R9._stub_source(
        sidecar_path=sidecar_path,
        bootstrap_size=len(bootstrap),
        bootstrap_sha256=_sha(bootstrap),
        descriptor_size=len(r10_view.descriptor_json),
        descriptor_sha256=descriptor_sha,
    )
    stdin_raw = r11._R9._wire_prefix(bootstrap) + r10_view.descriptor_json
    _check(len(stdin_raw) <= r11._R9.MAX_STDIN_BYTES, "r13_r11_stdin_limit")
    command = tuple(base.command[:7]) + (stub.decode("utf-8"),)
    units = r11._R9._command_line_units(command)
    _check(units <= r11._R9.MAX_COMMAND_LINE_UNITS, "r13_r11_command_limit")
    helper_path, helper_bytes, helper_sha = r11._self_source()
    dependencies = r11._dependency_rows()
    binding = dict(r10_view.binding)
    binding.update(
        {
            "schema": r11.R11_BINDING_SCHEMA,
            "result_observer_schema": r11.R11_RESULT_SCHEMA,
            "result_observer_prefix": r11.R11_FRAME_PREFIX.decode("ascii"),
            "result_observer_max_bytes": r11.R11_FRAME_MAX_BYTES,
            "r10_binding_sha256": r10_view.binding_sha256,
            "r10_sidecar_path": r10_view.sidecar_path,
            "r10_sidecar_sha256": r10_view.sidecar_sha256,
            "r10_sidecar_size_bytes": r10_view.sidecar_size_bytes,
            "r11_sidecar_path": sidecar_path,
            "r11_sidecar_sha256": _sha(bootstrap),
            "r11_sidecar_size_bytes": len(bootstrap),
            "r11_helper_path": helper_path,
            "r11_helper_sha256": helper_sha,
            "r11_helper_size_bytes": len(helper_bytes),
            "r11_dependency_sources": [
                {"path": path, "sha256": digest, "size_bytes": len(raw), "role": role}
                for path, raw, digest, role, _origin in dependencies
            ],
            "windows_command_line_utf16_units_including_nul": units,
            "windows_command_line_limit_utf16_units_including_nul": r11._R9.MAX_COMMAND_LINE_UNITS,
            "canonical_child_map_counts": {"public": 118, "software": 36, "canonical": 154},
            "r11_result_fields": [
                "reason_ordinal", "diagnostic_pair_ordinal", "route_invocations_reported",
                "native_operations_reported", "provider_requests_reported", "source_review_bound_reported",
                "outer_status", "outer_route_invocations",
            ],
            "outer_reason_policy": "never_emitted",
            "authority": False,
            "strict_cases_passed": 0,
            "case_result": False,
        }
    )
    binding_sha = r11._R6._canonical_binding_digest(binding, command, r10_view.cwd)
    return dataclasses.replace(
        base,
        r10_prepared=r10_view,
        command=command,
        descriptor_json=r10_view.descriptor_json,
        stdin_descriptor=stdin_raw,
        runner_bytes=r10_view.runner_bytes,
        bootstrap_bytes=bootstrap,
        stub_bytes=stub,
        sidecar_path=sidecar_path,
        sidecar_sha256=_sha(bootstrap),
        sidecar_size_bytes=len(bootstrap),
        helper_path=helper_path,
        helper_bytes=helper_bytes,
        helper_sha256=helper_sha,
        dependency_sources=dependencies,
        binding=binding,
        binding_sha256=binding_sha,
        windows_command_line_units=units,
    )


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R13 exact active outer, unchanged 154-map, and refreshed R12 sidecar."""

    base_r11_prepared: Any
    base_r12_prepared: Any
    r10_prepared: Any
    r11_prepared: Any
    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    descriptor_json: bytes
    stdin_descriptor: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    active_outer_source: bytes
    bootstrap_bytes: bytes
    stub_bytes: bytes
    sidecar_path: str
    sidecar_sha256: str
    sidecar_size_bytes: int
    helper_path: str
    helper_bytes: bytes
    helper_sha256: str
    r12_dependency: tuple[str, bytes, str]
    reason_table: tuple[str, ...]
    reason_table_sha256: str
    outer_binding: dict[str, Any]
    transform_binding: dict[str, Any]
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str
    windows_command_line_units: int

    @property
    def sidecar_bytes(self) -> bytes:
        return self.bootstrap_bytes


def _compose(base_r11: Any) -> PreparedM01Child:
    _check(
        R13_ORIGINAL_TEMPLATE_SHA256 == _R10.R28_OUTER_TEMPLATE_SHA256
        and R13_R10_SHA256 == _R11.R10_SHA256
        and R13_R10_RELATIVE_PATH == "scripts/" + _R11.R10_FILENAME,
        "r13_frozen_source_constants",
    )
    _R11._validate_prepared(base_r11)
    try:
        base_r12 = _R12._compose(base_r11)
        base_r10 = base_r11.r10_prepared
        outer = _R12._outer_material(base_r10)
    except BaseException:
        raise ActiveOuterActivationBlocked("r12_base_rejected") from None
    helper_path, helper_raw, helper_sha = _self_source()
    _pinned_r12_path, r12_raw, r12_sha = _pinned_r12_source()
    r10_path, r10_raw, r10_sha = _R11._pinned_module_source(
        _R10, _R11.R10_FILENAME, _R11.R10_SHA256
    )
    active_outer = _active_outer_source(
        outer["active_outer"],
        outer=outer,
        generator_path=helper_path,
        generator_sha256=helper_sha,
        generator_size_bytes=len(helper_raw),
        r10_composer_path=r10_path,
        r10_composer_sha256=r10_sha,
        r10_composer_size_bytes=len(r10_raw),
        external_source_rows=tuple(
            {
                "name": name,
                "path": path,
                "sha256": digest,
                "size_bytes": len(raw),
                "role": role,
                "origin": origin,
            }
            for name, path, raw, digest, role, origin in base_r10.external_parent_sources
        ),
    )
    r10_view = _rebuild_r10_view(base_r10, outer, active_outer, (helper_path, helper_raw, helper_sha))
    r11_view = _rebuild_r11_view(base_r11, r10_view)
    active_outer_sha = _sha(active_outer)
    outer = dict(outer)
    outer["active_outer"] = active_outer
    outer["active_outer_sha256"] = active_outer_sha
    outer["source_map_sha256"] = _sha(r10_view.source_map_bytes)
    table = _R12._active_outer_reason_literals(active_outer)
    table_sha = _R12._reason_table_digest(table, outer)
    bootstrap = _R12._compose_bootstrap(r11_view.bootstrap_bytes, table, outer)
    descriptor = _R12._R11._R9._R4._validate_descriptor(r11_view.descriptor_json)
    descriptor_sha = _sha(r11_view.descriptor_json)
    sidecar_path = _R12._R11._R9._sidecar_path(descriptor["runtime_namespace"]["deployment_dir"], _sha(bootstrap))
    stub = _R12._R11._R9._stub_source(
        sidecar_path=sidecar_path,
        bootstrap_size=len(bootstrap),
        bootstrap_sha256=_sha(bootstrap),
        descriptor_size=len(r11_view.descriptor_json),
        descriptor_sha256=descriptor_sha,
    )
    stdin_raw = _R12._R11._R9._wire_prefix(bootstrap) + r11_view.descriptor_json
    _check(len(stdin_raw) <= _R12._R11._R9.MAX_STDIN_BYTES, "r13_stdin_limit")
    command = tuple(base_r11.command[:7]) + (stub.decode("utf-8"),)
    units = _R12._R11._R9._command_line_units(command)
    _check(units <= _R12._R11._R9.MAX_COMMAND_LINE_UNITS, "r13_command_line_limit")
    outer_binding = {key: value for key, value in outer.items() if key != "active_outer"}
    transform_binding = {
        "schema": R13_TRANSFORM_SCHEMA,
        "active_outer_path": outer["active_outer_path"],
        "active_outer_sha256": active_outer_sha,
        "active_outer_size_bytes": len(active_outer),
        "base_r10_active_outer_sha256": _sha(_R12._outer_material(base_r10)["active_outer"]),
        "base_r10_active_outer_size_bytes": len(_R12._outer_material(base_r10)["active_outer"]),
        "plan_path": outer["plan_path"],
        "plan_sha256": outer["plan_sha256"],
        "source_map_sha256": outer["source_map_sha256"],
        "namespace": dict(outer["namespace"]),
        "original_r28_template_sha256": _R10.R28_OUTER_TEMPLATE_SHA256,
        "generator_path": helper_path,
        "generator_sha256": helper_sha,
        "generator_size_bytes": len(helper_raw),
        "r12_dependency_path": _pinned_r12_path,
        "r12_dependency_sha256": r12_sha,
        "r12_dependency_size_bytes": len(r12_raw),
        "r10_composer_path": r10_path,
        "r10_composer_sha256": r10_sha,
        "r10_composer_size_bytes": len(r10_raw),
        "r10_external_source_rows": [
            {
                "name": name,
                "path": path,
                "sha256": digest,
                "size_bytes": len(raw),
                "role": role,
                "origin": origin,
            }
            for name, path, raw, digest, role, origin in base_r10.external_parent_sources
        ],
        "gate_replacements": 1,
        "canonical_child_map_count": 154,
        "authority": False,
    }
    binding = dict(r11_view.binding)
    binding.update(
        {
            "schema": R13_BINDING_SCHEMA,
            "result_observer_schema": _R12.R12_RESULT_SCHEMA,
            "result_observer_prefix": _R12.R12_FRAME_PREFIX.decode("ascii"),
            "result_observer_max_bytes": _R12.R12_FRAME_MAX_BYTES,
            "r11_binding_sha256": r11_view.binding_sha256,
            "r11_sidecar_path": r11_view.sidecar_path,
            "r11_sidecar_sha256": r11_view.sidecar_sha256,
            "r11_sidecar_size_bytes": r11_view.sidecar_size_bytes,
            "r13_sidecar_path": sidecar_path,
            "r13_sidecar_sha256": _sha(bootstrap),
            "r13_sidecar_size_bytes": len(bootstrap),
            "r13_helper_path": helper_path,
            "r13_helper_sha256": helper_sha,
            "r13_helper_size_bytes": len(helper_raw),
            "r13_r12_dependency": {
                "path": _pinned_r12_path,
                "sha256": r12_sha,
                "size_bytes": len(r12_raw),
                "role": R13_R12_DEPENDENCY_ROLE,
            },
            "r13_r10_composer_dependency": {
                "path": r10_path,
                "sha256": r10_sha,
                "size_bytes": len(r10_raw),
                "role": _R10.R10_COMPOSER_ROLE,
            },
            "r13_transform_binding": dict(transform_binding),
            "r13_reason_table_schema": _R12.R12_REASON_TABLE_SCHEMA,
            "r13_reason_table_sha256": table_sha,
            "r13_reason_table_count": len(table),
            "r13_reason_table_literals": list(table),
            "r13_outer_source_binding": {**outer_binding, "namespace": dict(outer["namespace"])},
            "windows_command_line_utf16_units_including_nul": units,
            "windows_command_line_limit_utf16_units_including_nul": _R12._R11._R9.MAX_COMMAND_LINE_UNITS,
            "canonical_child_map_counts": {"public": 118, "software": 36, "canonical": 154},
            "authority": False,
            "strict_cases_passed": 0,
            "case_result": False,
        }
    )
    binding_sha = _R12._R11._R6._canonical_binding_digest(binding, command, base_r11.cwd)
    return PreparedM01Child(
        base_r11_prepared=base_r11,
        base_r12_prepared=base_r12,
        r10_prepared=r10_view,
        r11_prepared=r11_view,
        command=command,
        cwd=base_r11.cwd,
        environment=dict(base_r11.environment),
        descriptor_json=r11_view.descriptor_json,
        stdin_descriptor=stdin_raw,
        source_map_bytes=r10_view.source_map_bytes,
        runner_bytes=r10_view.runner_bytes,
        active_outer_source=active_outer,
        bootstrap_bytes=bootstrap,
        stub_bytes=stub,
        sidecar_path=sidecar_path,
        sidecar_sha256=_sha(bootstrap),
        sidecar_size_bytes=len(bootstrap),
        helper_path=helper_path,
        helper_bytes=helper_raw,
        helper_sha256=helper_sha,
        r12_dependency=(_pinned_r12_path, r12_raw, r12_sha),
        reason_table=table,
        reason_table_sha256=table_sha,
        outer_binding=outer_binding,
        transform_binding=transform_binding,
        binding=binding,
        binding_sha256=binding_sha,
        plan_disposition=base_r11.plan_disposition,
        windows_command_line_units=units,
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    _R10._verify_chain()
    try:
        base_r11 = _R11.prepare_r33_child(prepared_r31, root_metadata, environment=environment)
    except BaseException:
        raise ActiveOuterActivationBlocked("r11_prepare_rejected") from None
    return prepare_from_r11(base_r11)


def prepare_from_r11(base_r11: Any) -> PreparedM01Child:
    return _compose(base_r11)


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "prepared_type")
    try:
        expected = _compose(value.base_r11_prepared)
    except BaseException:
        raise ActiveOuterActivationBlocked("prepared_recompose") from None
    _check(value == expected, "prepared_binding")


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    _validate_prepared(prepared)
    base = _R11.parent_hold_addition(prepared.base_r11_prepared)
    entries = dict(base["entries"])
    r10_binding = prepared.transform_binding
    r10_path = r10_binding["r10_composer_path"]
    r10_key = _R10._R9._normalized(r10_path)
    r10_matches = [path for path in entries if _R10._R9._normalized(path) == r10_key]
    _check(len(r10_matches) == 1, "r13_r10_composer_hold_missing")
    r10_entry = entries[r10_matches[0]]
    _check(
        type(r10_entry) is dict
        and r10_entry.get("sha256") == r10_binding["r10_composer_sha256"]
        and r10_entry.get("size_bytes") == r10_binding["r10_composer_size_bytes"]
        and r10_entry.get("role") == _R10.R10_COMPOSER_ROLE,
        "r13_r10_composer_hold_binding",
    )
    for row in r10_binding["r10_external_source_rows"]:
        matches = [
            path for path in entries
            if _R10._R9._normalized(path) == _R10._R9._normalized(row["path"])
        ]
        _check(len(matches) == 1, "r13_r10_external_hold_missing")
        held = entries[matches[0]]
        _check(
            type(held) is dict
            and held.get("sha256") == row["sha256"]
            and held.get("size_bytes") == row["size_bytes"]
            and held.get("role") == row["role"]
            and held.get("origin") == row["origin"],
            "r13_r10_external_hold_binding",
        )
    once_path = prepared.r10_prepared.once_path
    once_matches = [path for path in entries if _R10._R9._normalized(path) == _R10._R9._normalized(once_path)]
    _check(len(once_matches) == 1, "r13_once_hold_anchor")
    once_key = once_matches[0]
    entries[once_key] = {
        "sha256": prepared.r10_prepared.once_sha256,
        "size_bytes": prepared.r10_prepared.once_size_bytes,
        "role": _R10.R10_ONCE_ROLE,
        "origin": R13_ONCE_ORIGIN + ":" + _R10.R28_ONCE_SHA256,
    }
    r12_path, r12_raw, r12_sha = prepared.r12_dependency
    additions = (
        (r12_path, r12_raw, r12_sha, R13_R12_DEPENDENCY_ROLE, "repository_source:" + _R12.R12_RELATIVE_PATH),
        (prepared.sidecar_path, prepared.bootstrap_bytes, prepared.sidecar_sha256, R13_SIDECAR_ROLE,
         "generated_from_exact_r11_sidecar:" + prepared.r11_prepared.sidecar_sha256),
        (prepared.helper_path, prepared.helper_bytes, prepared.helper_sha256, R13_SOURCE_ROLE,
         "repository_source:" + R13_RELATIVE_PATH),
    )
    normalized = {_R10._R9._normalized(path) for path in entries}
    for path, raw, digest, role, origin in additions:
        _check(_R10._R9._absolute_windows_path(path), "r13_hold_path")
        _check(type(raw) is bytes and _sha(raw) == digest, "r13_hold_digest")
        key = _R10._R9._normalized(path)
        _check(key not in normalized, "r13_hold_collision")
        normalized.add(key)
        entries[path] = {"sha256": digest, "size_bytes": len(raw), "role": role, "origin": origin}
    return {
        "schema": R13_HOLD_SCHEMA,
        "binding_sha256": prepared.binding_sha256,
        "r11_binding_sha256": prepared.r11_prepared.binding_sha256,
        "canonical_child_map_count": 154,
        "entries": dict(sorted(entries.items())),
        "once_path": once_path,
        "once_sha256": prepared.r10_prepared.once_sha256,
        "once_size_bytes": prepared.r10_prepared.once_size_bytes,
        "sidecar_path": prepared.sidecar_path,
        "sidecar_sha256": prepared.sidecar_sha256,
        "sidecar_size_bytes": prepared.sidecar_size_bytes,
        "helper_path": prepared.helper_path,
        "helper_sha256": prepared.helper_sha256,
        "r12_dependency_path": r12_path,
        "r12_dependency_sha256": r12_sha,
        "r10_composer_path": r10_path,
        "r10_composer_sha256": r10_binding["r10_composer_sha256"],
        "r10_composer_size_bytes": r10_binding["r10_composer_size_bytes"],
        "r10_external_source_rows": list(r10_binding["r10_external_source_rows"]),
        "reason_table_sha256": prepared.reason_table_sha256,
        "transform_binding": dict(prepared.transform_binding),
        "outer_binding": dict(prepared.outer_binding),
    }


def verify_parent_hold_addition(prepared: PreparedM01Child, value: Any) -> bool:
    try:
        return type(value) is dict and value == parent_hold_addition(prepared)
    except BaseException:
        return False


class M01WindowsParentAdapter:
    """Reuse the frozen R12 owner-thread supervisor with R13 transport bytes."""

    def __init__(self, prepared_child: PreparedM01Child, **kwargs: Any):
        _validate_prepared(prepared_child)
        self.prepared = prepared_child
        self._r12 = _R12.M01WindowsParentAdapter(prepared_child.base_r12_prepared, **kwargs)
        runtime_view = prepared_child.r10_prepared
        _R10._rebind_r9_adapter(self._r12._r11._r10._r9, runtime_view)
        self._r8_adapter = self._r12._r8_adapter
        self._used_lock = threading.Lock()
        self._used = False

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        with self._used_lock:
            _check(self._used is False, "adapter_reentry")
            self._used = True
        adapter = self._r8_adapter
        previous = adapter._project_r7_parent_result
        prepared = self.prepared
        adapter._project_r7_parent_result = lambda result: _R12._parent_projection(
            adapter, result, prepared, previous
        )
        try:
            return self._r12._r11._r10.supervise(source_scope, release_source_scope, **kwargs)
        finally:
            adapter._project_r7_parent_result = previous

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._r12.summarize_result(result)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._r12, name)


if __name__ == "__main__":
    raise SystemExit("Use prepare_r33_child() and hold the exact R13 addition.")
