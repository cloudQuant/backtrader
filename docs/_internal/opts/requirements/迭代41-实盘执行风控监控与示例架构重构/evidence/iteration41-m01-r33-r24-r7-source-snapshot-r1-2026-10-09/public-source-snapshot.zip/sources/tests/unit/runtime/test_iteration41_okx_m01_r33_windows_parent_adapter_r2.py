"""Fake-bottom contracts for the M01 R33 Windows parent adapter R2."""

from __future__ import annotations

import ctypes
import io
import json
import ntpath
import threading
import time
from pathlib import Path
from types import SimpleNamespace

from scripts import iteration41_okx_l03_l04_v4_root_launcher as launcher
from scripts import iteration41_okx_m01_r31_root_startup_prepare_r1 as r31
from scripts import iteration41_okx_m01_r33_child_bootstrap_r1 as bootstrap
from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r2 as r33
from scripts import iteration41_suspended_child_image_r2 as image_observer


_CUV2 = (
    Path(__file__).resolve().parents[3]
    / "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence"
    / "iteration41-cuv2-public-source-snapshot-r1-2026-10-08/cuv2-source.py"
)


def _prepared(tmp_path, *, disposition="NON_ACTUAL_PLAN"):
    prepared = r31.prepare_root_startup(
        r31.default_test_namespace(str(tmp_path)),
        plan_sha256="a" * 64,
    )
    metadata = {
        "schema": r33.ROOT_METADATA_SCHEMA,
        "cuv2_path": str(_CUV2),
        "cuv2_sha256": r33.CUV2_PUBLIC_SOURCE_SHA256,
        "owner_image_path": r33.FIXED_EXECUTABLE,
        "plan_disposition": disposition,
    }
    launch = r33.prepare_r33_child(
        prepared,
        metadata,
        environment={"SYSTEMROOT": "C:\\Windows"},
    )
    Path(launch.binding["runner_path"]).parent.mkdir(parents=True, exist_ok=True)
    Path(launch.binding["runner_path"]).write_bytes(launch.runner_bytes)
    Path(launch.binding["source_map_path"]).write_bytes(launch.source_map_bytes)
    return launch


class _FakeClock:
    def __init__(self):
        self.value = 50.0
        self.lock = threading.Lock()

    def __call__(self):
        with self.lock:
            return self.value

    def sleep(self, seconds):
        with self.lock:
            self.value += seconds


class _FakeFunction:
    def __init__(self, call):
        self.call = call
        self.argtypes = None
        self.restype = None

    def __call__(self, *args):
        return self.call(*args)


class _FakeKernel:
    def __init__(self, pid=4312, image_path=r"C:\anaconda3\python.exe"):
        self.pid = pid
        self.image_path = image_path
        self.events = []
        self.active_count = 0
        self.job_policy_flags = None
        self.functions = {
            "CreateJobObjectW": lambda *_args: 1001,
            "SetInformationJobObject": self._set_job,
            "AssignProcessToJobObject": self._assign,
            "TerminateJobObject": self._terminate,
            "QueryInformationJobObject": self._query_job,
            "CloseHandle": self._close_handle,
            "CreateToolhelp32Snapshot": lambda *_args: 2002,
            "Thread32First": self._thread_first,
            "Thread32Next": lambda *_args: False,
            "OpenThread": lambda *_args: 3003,
            "GetProcessIdOfThread": lambda *_args: self.pid,
            "ResumeThread": self._resume_thread,
            "GetProcessId": self._image_pid,
            "GetExitCodeProcess": self._image_exit,
            "QueryFullProcessImageNameW": self._image_path,
            "WaitForSingleObject": self._image_wait,
        }

    def __getattr__(self, name):
        try:
            return _FakeFunction(self.functions[name])
        except KeyError:
            raise AttributeError(name) from None

    def _set_job(self, _handle, _info_class, pointer, _size):
        info = ctypes.cast(
            pointer, ctypes.POINTER(launcher._JobExtendedLimitInformation)
        ).contents
        self.job_policy_flags = int(info.basic.limit_flags)
        self.events.append("job_policy")
        return self.job_policy_flags == 0x2000

    def _assign(self, _job, _process):
        self.active_count = 1
        self.events.append("assign")
        return True

    def _terminate(self, _job, _exit_code):
        self.active_count = 0
        self.events.append("terminate_job")
        return True

    def _query_job(self, _job, _class, info_pointer, size, returned_pointer):
        info = ctypes.cast(
            info_pointer, ctypes.POINTER(launcher._JobBasicAccountingInformation)
        ).contents
        info.active_processes = self.active_count
        returned = ctypes.cast(returned_pointer, ctypes.POINTER(launcher.W.DWORD))
        returned.contents.value = size
        return True

    def _close_handle(self, _handle):
        self.events.append("close_handle")
        return True

    def _thread_first(self, _snapshot, entry_pointer):
        entry = ctypes.cast(entry_pointer, ctypes.POINTER(launcher._ThreadEntry32)).contents
        entry.owner_process_id = self.pid
        entry.thread_id = 4004
        self.events.append("thread_first")
        return True

    def _resume_thread(self, _thread):
        self.events.append("resume")
        return 1

    def _image_pid(self, _handle):
        self.events.append("image_pid")
        return self.pid

    def _image_exit(self, _handle, exit_pointer):
        exit_code = ctypes.cast(
            exit_pointer, ctypes.POINTER(image_observer.wintypes.DWORD)
        )
        exit_code.contents.value = image_observer.STILL_ACTIVE
        self.events.append("image_exit")
        return True

    def _image_path(self, _handle, _flags, buffer, length_pointer):
        path = self.image_path
        buffer.value = path
        length = ctypes.cast(
            length_pointer, ctypes.POINTER(image_observer.wintypes.DWORD)
        )
        length.contents.value = len(path)
        self.events.append("image_path")
        return True

    def _image_wait(self, _handle, _milliseconds):
        self.events.append("image_wait")
        return image_observer.WAIT_TIMEOUT


class _FakeInput:
    def __init__(self, events):
        self.events = events
        self.payload = bytearray()
        self.closed = False

    def write(self, value):
        self.events.append("descriptor_write")
        self.payload.extend(value)
        return len(value)

    def flush(self):
        self.events.append("descriptor_flush")

    def close(self):
        self.closed = True
        self.events.append("stdin_close")


class _BlockingInput:
    def __init__(self):
        self.entered_write = threading.Event()
        self.release_write = threading.Event()
        self.finished = threading.Event()
        self.payload = bytearray()
        self.closed = False

    def write(self, value):
        self.entered_write.set()
        if not self.release_write.wait(2.0):
            raise TimeoutError("test write gate")
        self.payload.extend(value)
        return len(value)

    def flush(self):
        return None

    def close(self):
        self.closed = True
        self.finished.set()


class _AssignmentNative:
    def assign(self, _job, _process):
        return None

    def close(self, _job):
        return None


class _FakeReadPipe:
    def __init__(self, value):
        self.value = value
        self.offset = 0
        self.closed = False

    def read(self, size):
        if self.offset >= len(self.value):
            return b""
        chunk = self.value[self.offset : self.offset + size]
        self.offset += len(chunk)
        return chunk

    def close(self):
        self.closed = True


class _FakeProcess:
    def __init__(self, kernel, events):
        self.pid = kernel.pid
        self._handle = 77
        self.returncode = None
        self.stdin = _FakeInput(events)
        self.stdout = _FakeReadPipe(b'{"status":"BLOCKED"}\n')
        self.stderr = _FakeReadPipe(b"")
        self.kernel = kernel
        self.events = events

    def poll(self):
        return self.returncode

    def wait(self, timeout=None):
        assert timeout is not None and timeout > 0
        if self.returncode is None:
            self.returncode = 0
            self.kernel.active_count = 0
        self.events.append("wait")
        return self.returncode

    def kill(self):
        self.returncode = -9
        self.kernel.active_count = 0
        self.events.append("kill")


def test_prepared_child_binds_r31_map_bootstrap_command_and_fixed_budgets(tmp_path):
    launch = _prepared(tmp_path)

    assert launch.command[:7] == (
        r33.FIXED_EXECUTABLE,
        "-I",
        "-S",
        "-B",
        "-X",
        "utf8",
        "-c",
    )
    assert launch.command[7].encode("utf-8") == launch.bootstrap_bytes
    assert launch.plan_disposition == "NON_ACTUAL_PLAN"
    assert len(launch.stdin_descriptor) <= r33.MAX_DESCRIPTOR_BYTES
    descriptor = bootstrap._validate_descriptor(launch.stdin_descriptor)
    source_map = bootstrap._validate_source_map(
        launch.source_map_bytes, descriptor
    )
    assert source_map["map_counts"] == {"public": 118, "software": 36, "canonical": 154}
    assert descriptor["budgets"] == {
        "parent_seconds": 100,
        "parent_cleanup_seconds": 5,
        "once_child_seconds": 180,
        "once_cleanup_seconds": 5,
        "outer_capture_seconds": 405,
        "outer_cleanup_seconds": 5,
    }
    assert launch.binding["manifest_binding_sha256"] == source_map["manifest_binding_sha256"]
    assert r33.ROOT_REAL_ADAPTER_ENABLED is False


def test_child_bootstrap_loads_only_public_fixture_then_stops_at_closed_r31_runner(tmp_path):
    launch = _prepared(tmp_path)
    output = io.StringIO()

    code = bootstrap.run_descriptor(
        launch.stdin_descriptor,
        stdout=output,
    )

    result = json.loads(output.getvalue())
    assert code == 2
    assert result["schema"] == bootstrap.RESULT_SCHEMA
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "runner_activation_closed"
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0
    assert result["authority"] is False


def test_real_adapter_gate_stays_closed_for_nonactual_plan_and_no_fake_leaves(tmp_path):
    launch = _prepared(tmp_path, disposition="NON_ACTUAL_PLAN")
    authenticated = []

    def authenticate(scope, binding, timeout):
        authenticated.append((scope, binding, timeout))
        return True

    adapter = r33.M01WindowsParentAdapter(
        launch,
        scope_authenticator=authenticate,
    )

    assert adapter.verify_source_scope(object(), 1.0) is True
    assert len(authenticated) == 1
    assert adapter.launch_suspended(1.0) is None
    assert r33.ROOT_REAL_ADAPTER_ENABLED is False


def test_actual_pinned_job_and_image_leaves_run_assign_image_resume_order(tmp_path, monkeypatch):
    launch = _prepared(tmp_path)
    events = []
    kernel = _FakeKernel()
    kernel.events = events
    monkeypatch.setattr(launcher.C, "WinDLL", lambda *_args, **_kwargs: kernel)
    monkeypatch.setattr(image_observer.ctypes, "WinDLL", lambda *_args, **_kwargs: kernel)
    monkeypatch.setattr(image_observer.os, "name", "nt")
    monkeypatch.setattr(image_observer, "ROOT_NATIVE_ENABLED", True)
    native = launcher._WinJobNative()
    clock = _FakeClock()
    owner_thread = threading.get_ident()
    attestations = []
    process_holder = {}

    def authenticate(scope, binding, timeout):
        assert threading.get_ident() == owner_thread
        assert timeout > 0
        assert binding["owner_image_path"] == r33.FIXED_EXECUTABLE
        assert binding["cuv2_sha256"] == r33.CUV2_PUBLIC_SOURCE_SHA256
        assert binding["source_map_sha256"] == r33._sha(launch.source_map_bytes)
        attestations.append((scope, binding))
        return True

    def process_factory(command, **kwargs):
        assert tuple(command) == launch.command
        assert kwargs["creationflags"] == r33.CREATE_SUSPENDED
        assert kwargs["shell"] is False
        assert kwargs["stdin"] == launcher.subprocess.PIPE
        assert kwargs["stdout"] == launcher.subprocess.PIPE
        assert kwargs["stderr"] == launcher.subprocess.PIPE
        process = _FakeProcess(kernel, events)
        process_holder["process"] = process
        events.append("process_created_suspended")
        return process

    adapter = r33.M01WindowsParentAdapter(
        launch,
        scope_authenticator=authenticate,
        fake_leaves=True,
        native=native,
        process_factory=process_factory,
        launcher_module=launcher,
        image_module=image_observer,
        clock=clock,
        sleeper=clock.sleep,
    )
    source_scope = object()
    released = []

    def release(scope, timeout):
        assert threading.get_ident() == owner_thread
        assert scope is source_scope and timeout > 0
        released.append(scope)
        return True

    result = adapter.supervise(source_scope, release)

    assert result.status == "CHILD_EXITED"
    assert result.cleanup_complete is True
    assert result.scope_released is True
    assert result.stdout == b'{"status":"BLOCKED"}\n'
    assert result.stderr == b""
    assert len(released) == 1 and released[0] is source_scope
    assert len(attestations) == 1
    assert kernel.job_policy_flags == 0x2000
    assert events.index("process_created_suspended") < events.index("assign")
    assert events.index("assign") < events.index("descriptor_write")
    assert events.index("descriptor_write") < kernel.events.index("image_pid")
    assert kernel.events.index("image_path") < kernel.events.index("resume")
    assert kernel.events.index("assign") < kernel.events.index("resume")
    assert process_holder["process"].stdin.closed is True
    assert adapter.summarize_result(result)["strict_cases_passed"] == 0
    assert not hasattr(result, "case_pass")


def test_wrong_image_stops_before_resume_and_capture_overflow_is_not_complete(tmp_path, monkeypatch):
    launch = _prepared(tmp_path)
    events = []
    kernel = _FakeKernel(image_path=r"C:\other\python.exe")
    kernel.events = events
    monkeypatch.setattr(launcher.C, "WinDLL", lambda *_args, **_kwargs: kernel)
    monkeypatch.setattr(image_observer.ctypes, "WinDLL", lambda *_args, **_kwargs: kernel)
    monkeypatch.setattr(image_observer.os, "name", "nt")
    monkeypatch.setattr(image_observer, "ROOT_NATIVE_ENABLED", True)
    native = launcher._WinJobNative()
    clock = _FakeClock()

    def process_factory(_command, **_kwargs):
        return _FakeProcess(kernel, events)

    adapter = r33.M01WindowsParentAdapter(
        launch,
        scope_authenticator=lambda *_args: True,
        fake_leaves=True,
        native=native,
        process_factory=process_factory,
        launcher_module=launcher,
        image_module=image_observer,
        clock=clock,
        sleeper=clock.sleep,
    )
    source_scope = object()
    result = adapter.supervise(source_scope, lambda *_args: True)

    assert result.status == "ADMISSION_BLOCKED"
    assert result.reason == "target_verification_failed"
    assert "resume" not in kernel.events
    assert result.cleanup_complete is True

    drain = r33._BoundedDrain(io.BytesIO(b"0123456789"), 4, "r33-overflow-test")
    drain.start()
    drain.thread.join(1.0)
    raw, eof, overflow, failed = drain.snapshot()
    assert raw == b"0123"
    assert eof is True and overflow is True and failed is False


def test_descriptor_pipe_write_uses_remaining_deadline_and_keeps_late_leaf_pending(tmp_path):
    launch = _prepared(tmp_path)
    native = _AssignmentNative()
    adapter = r33.M01WindowsParentAdapter(
        launch,
        scope_authenticator=lambda *_args: True,
        fake_leaves=True,
        native=native,
        process_factory=lambda *_args, **_kwargs: None,
    )
    stream = _BlockingInput()
    process = SimpleNamespace(stdin=stream, stdout=io.BytesIO(), stderr=io.BytesIO())
    session = r33._Session(
        job=SimpleNamespace(_handle=1),
        process=process,
        native=native,
        stdout_drain=r33._BoundedDrain(process.stdout, 32, "r33-deadline-stdout"),
        stderr_drain=r33._BoundedDrain(process.stderr, 32, "r33-deadline-stderr"),
    )

    started = time.monotonic()
    assert adapter.assign_to_job(session, 0.02) is False
    elapsed = time.monotonic() - started

    assert stream.entered_write.is_set()
    assert elapsed < 0.5
    assert session.launch_error is True
    assert session.assignment_attempted is True
    assert adapter.job_assigned(session) is True
    with session.pending_lock:
        assert session.pending_operations == 1
    assert adapter.close_job(session, 0.02) is False

    stream.release_write.set()
    assert stream.finished.wait(1.0)
    deadline = time.monotonic() + 1.0
    while time.monotonic() < deadline:
        with session.pending_lock:
            if session.pending_operations == 0:
                break
        time.sleep(0.001)
    with session.pending_lock:
        assert session.pending_operations == 0
    assert bytes(stream.payload) == launch.stdin_descriptor

