"""Instance-isolated R33 parent facade and R3 child command binding.

R4 keeps R1/R2/R3 frozen. It executes hash-pinned R2 bytes in a fresh
module namespace per adapter instead of toggling the imported public R2
module global. Each facade's inherited launch gate is only opened from its
owner-thread `supervise` callback path and is closed in every exit path.
"""

from __future__ import annotations

import hashlib
import json
import sys
import threading
import time
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional


R2_FILENAME = "iteration41_okx_m01_r33_windows_parent_adapter_r2.py"
R2_SOURCE_SHA256 = "544cbfe4afba327f69c528d9b31da8982405f57acd1ecd3e4d5b1e87838d8e83"
R3_BOOTSTRAP_FILENAME = "iteration41_okx_m01_r33_child_bootstrap_r3.py"
R3_BOOTSTRAP_SHA256 = "98a0476502807fed1c01c1cf2dbc3d8c19af139c4817b17269fc0f18ee6674d1"
R31_SOURCE_SHA256 = "c95f72c6d168352893339bad5f53e5f48e5b201219a30de8b2de6d90f50e441a"
R32_SOURCE_SHA256 = "5f9986146991188be4f0121e754c0a1e231e90700d167fe265464154cab8af1e"
LAUNCHER_SOURCE_SHA256 = "0b8076f4cd8aa4419a29a0bbc3f1884e24c2610e2ba5b6cf2000c0cdf861c023"
IMAGE_SOURCE_SHA256 = "3f14b2771a73e056b7902f48f65bfebbf17e93a62202a55f66de6ac3ff12d0cc"
R1_BOOTSTRAP_SOURCE_SHA256 = "0cea3ea9331fa5fc132ddf0924084d413b051d005effb7fe9664a23870670ee0"
CUV2_SOURCE_SHA256 = "e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246"
ROOT_METADATA_SCHEMA = "iteration41.okx.m01.r33.root-owned-bootstrap-metadata.v1"
FIXED_EXECUTABLE = "C:/anaconda3/python.exe"
_SAFE_ENV_KEYS = frozenset({"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "TEMP", "TMP"})
_GATE_LOCK = threading.Lock()
_MODULE_LOCK = threading.Lock()
_MODULE_SEQUENCE = 0
_R2_MODULE_DIR = Path(__file__).resolve().parent
_DEPENDENCIES = (
    ("r31", "iteration41_okx_m01_r31_root_startup_prepare_r1.py", R31_SOURCE_SHA256),
    ("r32", "iteration41_okx_m01_r32_external_parent_budget_r1.py", R32_SOURCE_SHA256),
    ("launcher", "iteration41_okx_l03_l04_v4_root_launcher.py", LAUNCHER_SOURCE_SHA256),
    ("image", "iteration41_suspended_child_image_r2.py", IMAGE_SOURCE_SHA256),
    ("bootstrap", "iteration41_okx_m01_r33_child_bootstrap_r1.py", R1_BOOTSTRAP_SOURCE_SHA256),
)


class ParentAdapterBlocked(ValueError):
    """A fixed source, prepared-child, or lifecycle boundary failed closed."""


def _check(value: Any, reason: str) -> None:
    if not value:
        raise ParentAdapterBlocked(reason)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _read_pinned(path: Path, expected: str, maximum: int = 64 * 1024 * 1024) -> bytes:
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise ParentAdapterBlocked("pinned_source_read") from None
    _check(0 < len(raw) <= maximum, "pinned_source_size")
    _check(_sha(raw) == expected, "pinned_source_digest")
    return raw


def _next_module_name(prefix: str) -> str:
    global _MODULE_SEQUENCE
    with _MODULE_LOCK:
        _MODULE_SEQUENCE += 1
        return f"_{prefix}_{_MODULE_SEQUENCE:08d}"


def _load_exact_module(
    path: Path,
    expected: str,
    module_name: str,
    *,
    owned_names: Optional[list[str]] = None,
):
    raw = _read_pinned(path, expected)
    module = types.ModuleType(module_name)
    module.__file__ = str(path)
    module.__package__ = ""
    try:
        compile(raw, str(path), "exec", dont_inherit=True)
        sys.modules[module_name] = module
        exec(compile(raw, str(path), "exec", dont_inherit=True), module.__dict__)
        if owned_names is not None:
            owned_names.append(module_name)
    except BaseException:
        sys.modules.pop(module_name, None)
        raise ParentAdapterBlocked("pinned_source_load") from None
    return module, raw


def _load_private_r2():
    """Load one exact R2 source object and its fixed, freshly loaded pins."""
    r2_path = _R2_MODULE_DIR / R2_FILENAME
    module_name = _next_module_name("m01_r33_r2_r4")
    owned_names: list[str] = []
    r2, raw = _load_exact_module(
        r2_path, R2_SOURCE_SHA256, module_name, owned_names=owned_names
    )

    def load_fixed_dependencies():
        loaded = {}
        for role, filename, digest in _DEPENDENCIES:
            path = _R2_MODULE_DIR / filename
            name = _next_module_name(f"m01_r33_r4_{role}")
            module, source = _load_exact_module(
                path, digest, name, owned_names=owned_names
            )
            loaded[role] = (module, source)
        r31, _r31_raw = loaded["r31"]
        r32, _r32_raw = loaded["r32"]
        launcher, _launcher_raw = loaded["launcher"]
        image, _image_raw = loaded["image"]
        bootstrap, bootstrap_raw = loaded["bootstrap"]
        _check(getattr(bootstrap, "CUV2_PUBLIC_SOURCE_SHA256", None) == CUV2_SOURCE_SHA256, "bootstrap_cuv2_pin")
        return r31, r32, launcher, image, bootstrap, bootstrap_raw

    # This is the one fixed dependency loader expected by pinned R2. It does
    # not copy arbitrary module attributes or reuse import-cache code objects.
    r2._load_public_modules = load_fixed_dependencies
    return r2, raw, owned_names


def _drop_private_module_names(names: list[str]) -> None:
    for name in names:
        sys.modules.pop(name, None)


def _bootstrap_bytes() -> bytes:
    path = _R2_MODULE_DIR / R3_BOOTSTRAP_FILENAME
    raw = _read_pinned(path, R3_BOOTSTRAP_SHA256, maximum=64 * 1024)
    try:
        compile(raw, str(path), "exec", dont_inherit=True)
    except BaseException:
        raise ParentAdapterBlocked("r3_bootstrap_compile") from None
    return raw


def _load_r3_bootstrap():
    path = _R2_MODULE_DIR / R3_BOOTSTRAP_FILENAME
    name = _next_module_name("m01_r33_r3_bootstrap_r4")
    module, raw = _load_exact_module(path, R3_BOOTSTRAP_SHA256, name)
    return module, raw


@dataclass(frozen=True)
class PreparedM01Child:
    """R4-owned fixed-field copy, independent of any R2 module instance."""

    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    stdin_descriptor: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    bootstrap_bytes: bytes
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str


def _copy_prepared_from_r2(prepared: Any, r2: Any, raw: bytes) -> PreparedM01Child:
    _check(type(prepared) is r2.PreparedM01Child, "r2_prepared_type")
    bootstrap = _bootstrap_bytes()
    command = tuple(prepared.command[:-1]) + (bootstrap.decode("utf-8"),)
    binding = dict(prepared.binding)
    binding["schema"] = "iteration41.okx.m01.r33.prepared-child-binding.r4.v1"
    binding["bootstrap_sha256"] = _sha(bootstrap)
    binding["bootstrap_variant"] = "instance-isolated-r2-held-plan-validator"
    binding["r2_source_sha256"] = _sha(raw)
    binding_sha = _sha(
        r2._canonical_json(
            {
                "binding": binding,
                "command": list(command[:-1]) + [_sha(command[-1].encode("utf-8"))],
                "cwd": prepared.cwd,
            }
        )
    )
    result = PreparedM01Child(
        command=command,
        cwd=prepared.cwd,
        environment=dict(prepared.environment),
        stdin_descriptor=prepared.stdin_descriptor,
        source_map_bytes=prepared.source_map_bytes,
        runner_bytes=prepared.runner_bytes,
        bootstrap_bytes=bootstrap,
        binding=binding,
        binding_sha256=binding_sha,
        plan_disposition=prepared.plan_disposition,
    )
    _validate_r4_prepared(result)
    return result


def _canonical_json(value: Any) -> bytes:
    try:
        return json.dumps(
            value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode("ascii")
    except BaseException:
        raise ParentAdapterBlocked("prepared_binding_json") from None


def _validate_r4_prepared(prepared: Any) -> None:
    _check(type(prepared) is PreparedM01Child, "prepared_child_type")
    bootstrap_module, raw = _load_r3_bootstrap()
    try:
        _check(prepared.bootstrap_bytes == raw, "prepared_bootstrap_bytes")
        _check(
            type(prepared.command) is tuple
            and len(prepared.command) == 8
            and all(type(part) is str for part in prepared.command)
            and prepared.command[:7]
            == (FIXED_EXECUTABLE, "-I", "-S", "-B", "-X", "utf8", "-c")
            and prepared.command[7].encode("utf-8") == raw,
            "prepared_command",
        )
        _check(
            type(prepared.cwd) is str
            and type(prepared.environment) is dict
            and type(prepared.stdin_descriptor) is bytes
            and type(prepared.source_map_bytes) is bytes
            and type(prepared.runner_bytes) is bytes
            and type(prepared.binding_sha256) is str
            and type(prepared.plan_disposition) is str,
            "prepared_process_fields",
        )
        _check(set(prepared.environment).issubset(_SAFE_ENV_KEYS), "prepared_environment_keys")
        _check(
            all(
                type(k) is str
                and type(v) is str
                and "\x00" not in k
                and "\x00" not in v
                and len(k) <= 128
                and len(v) <= 32767
                for k, v in prepared.environment.items()
            ),
            "prepared_environment_values",
        )
        _check(type(prepared.binding) is dict, "prepared_binding_shape")
        descriptor = bootstrap_module._validate_descriptor(prepared.stdin_descriptor)
        source_map = bootstrap_module._validate_source_map(
            prepared.source_map_bytes, descriptor
        )
        _check(descriptor["root"] == prepared.cwd, "prepared_cwd_binding")
        _check(_sha(prepared.runner_bytes) == descriptor["runner_sha256"], "prepared_runner_bytes")
        _check(
            descriptor["plan_disposition"] == prepared.plan_disposition,
            "prepared_disposition",
        )
        expected_binding = {
            "schema": "iteration41.okx.m01.r33.prepared-child-binding.r4.v1",
            "owner_image_path": FIXED_EXECUTABLE,
            "cuv2_path": descriptor["cuv2_path"],
            "source_map_sha256": descriptor["source_map_sha256"],
            "source_map_path": descriptor["source_map_path"],
            "runner_sha256": descriptor["runner_sha256"],
            "runner_path": descriptor["runner_path"],
            "bootstrap_sha256": R3_BOOTSTRAP_SHA256,
            "cuv2_sha256": descriptor["cuv2_sha256"],
            "manifest_binding_sha256": descriptor["manifest_binding_sha256"],
            "root": descriptor["root"],
            "runtime_namespace": descriptor["runtime_namespace"],
            "plan_sha256": source_map["plan_sha256"],
            "plan_disposition": descriptor["plan_disposition"],
            "source_map_counts": {"public": 118, "software": 36, "canonical": 154},
            "budgets": descriptor["budgets"],
            "bootstrap_variant": "instance-isolated-r2-held-plan-validator",
            "r2_source_sha256": R2_SOURCE_SHA256,
        }
        _check(prepared.binding == expected_binding, "prepared_binding_fields")
        expected_digest = _sha(
            _canonical_json(
                {
                    "binding": prepared.binding,
                    "command": list(prepared.command[:-1])
                    + [_sha(prepared.command[-1].encode("utf-8"))],
                    "cwd": prepared.cwd,
                }
            )
        )
        _check(prepared.binding_sha256 == expected_digest, "prepared_binding_digest")
    finally:
        _drop_private_module_names([bootstrap_module.__name__])


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Build the R3 descriptor/command using a fresh, source-pinned R2 copy."""
    r2, raw, owned_names = _load_private_r2()
    try:
        prepared = r2.prepare_r33_child(prepared_r31, root_metadata, environment=environment)
        return _copy_prepared_from_r2(prepared, r2, raw)
    finally:
        _drop_private_module_names(owned_names)


class M01WindowsParentAdapter:
    """Per-instance R2 namespace with owner-supervision launch admission."""

    def __init__(
        self,
        prepared_child: Any,
        *,
        scope_authenticator: Callable[[Any, dict[str, Any], float], Any],
        fake_leaves: bool = False,
        native: Any = None,
        process_factory: Optional[Callable[..., Any]] = None,
        launcher_module: Any = None,
        image_module: Any = None,
        clock: Callable[[], Any] = time.monotonic,
        sleeper: Callable[[float], Any] = time.sleep,
    ):
        _validate_r4_prepared(prepared_child)
        _check(callable(scope_authenticator), "scope_authenticator_required")
        _check(type(fake_leaves) is bool, "fake_leaves_shape")
        _check(fake_leaves or (launcher_module is None and image_module is None), "real_dependency_injection")
        self.prepared = prepared_child
        self.fake_leaves = fake_leaves
        self._owner_thread = threading.get_ident()
        self._supervising = False
        self._scope_callback_verified = False
        self._r2_module, self._r2_source, owned_names = _load_private_r2()
        try:
            self._r2_prepared = self._r2_module.PreparedM01Child(
                command=prepared_child.command,
                cwd=prepared_child.cwd,
                environment=dict(prepared_child.environment),
                stdin_descriptor=prepared_child.stdin_descriptor,
                source_map_bytes=prepared_child.source_map_bytes,
                runner_bytes=prepared_child.runner_bytes,
                bootstrap_bytes=prepared_child.bootstrap_bytes,
                binding=dict(prepared_child.binding),
                binding_sha256=prepared_child.binding_sha256,
                plan_disposition=prepared_child.plan_disposition,
            )
            self._inner = self._r2_module.M01WindowsParentAdapter(
                self._r2_prepared,
                scope_authenticator=scope_authenticator,
                fake_leaves=fake_leaves,
                native=native,
                process_factory=process_factory,
                launcher_module=launcher_module,
                image_module=image_module,
                clock=clock,
                sleeper=sleeper,
            )
        finally:
            _drop_private_module_names(owned_names)
        self._original_launch_suspended = self._inner.launch_suspended
        self._inner.launch_suspended = self._launch_suspended_instance_gate

    @property
    def clock(self):
        return self._inner.clock

    @property
    def sleeper(self):
        return self._inner.sleeper

    def verify_source_scope(self, source_scope: Any, timeout_seconds: float) -> bool:
        if (
            threading.get_ident() != self._owner_thread
            or not self._supervising
            or self._scope_callback_verified
            or self.prepared.plan_disposition != "READY_TO_RUN"
        ):
            return False
        accepted = self._r2_module.M01WindowsParentAdapter.verify_source_scope(
            self._inner, source_scope, timeout_seconds
        )
        if type(accepted) is bool and accepted:
            self._scope_callback_verified = True
        return type(accepted) is bool and accepted

    def _launch_suspended_instance_gate(self, timeout_seconds: float):
        if (
            threading.get_ident() != self._owner_thread
            or not self._supervising
            or not self._scope_callback_verified
            or self.prepared.plan_disposition != "READY_TO_RUN"
        ):
            return None
        if self.fake_leaves:
            return self._original_launch_suspended(timeout_seconds)
        _check(self._r2_module.ROOT_REAL_ADAPTER_ENABLED is False, "private_gate_preopened")
        self._r2_module.ROOT_REAL_ADAPTER_ENABLED = True
        try:
            return self._original_launch_suspended(timeout_seconds)
        finally:
            self._r2_module.ROOT_REAL_ADAPTER_ENABLED = False

    def supervise(
        self,
        source_scope: Any,
        release_source_scope: Callable[[Any, float], Any],
        *,
        retention_registry: Any = None,
    ):
        _check(callable(release_source_scope), "scope_release_required")
        if not _GATE_LOCK.acquire(blocking=False):
            raise ParentAdapterBlocked("r4_adapter_already_supervising")
        try:
            _check(threading.get_ident() == self._owner_thread, "supervise_owner_thread")
            _check(not self._supervising, "supervise_reentry")
            self._supervising = True
            self._scope_callback_verified = False
            self._r2_module.ROOT_REAL_ADAPTER_ENABLED = False
            args = {}
            if retention_registry is not None:
                args["retention_registry"] = retention_registry
            return self._inner._r32.supervise_external_parent(
                self._inner,
                source_scope,
                self.verify_source_scope,
                release_source_scope,
                clock=self.clock,
                sleeper=self.sleeper,
                **args,
            )
        finally:
            self._r2_module.ROOT_REAL_ADAPTER_ENABLED = False
            self._inner._scope_authenticated = False
            self._scope_callback_verified = False
            self._supervising = False
            _GATE_LOCK.release()

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._inner.summarize_result(result)

    def __getattr__(self, name: str):
        return getattr(self._inner, name)

