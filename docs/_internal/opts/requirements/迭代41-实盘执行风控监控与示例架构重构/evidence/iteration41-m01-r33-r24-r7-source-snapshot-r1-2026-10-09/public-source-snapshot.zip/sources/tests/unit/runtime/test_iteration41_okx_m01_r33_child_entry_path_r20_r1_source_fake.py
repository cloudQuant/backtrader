"""R20 source fakes for the generated R28 Path-shaped self-path call."""

from __future__ import annotations

import hashlib
import json
import ntpath
import types
from pathlib import Path

import pytest

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as r13
from scripts import iteration41_okx_m01_r33_source_map_gate_r17_r1 as r17
from scripts import iteration41_okx_m01_r33_child_source_scope_r19_r1 as r19
from scripts import iteration41_okx_m01_r33_child_entry_path_r20_r1 as r20
from tests.unit.runtime import test_iteration41_okx_m01_r33_returned_result_observer_r11_r1 as r11_tests
from tests.unit.runtime import test_iteration41_okx_m01_r33_child_source_scope_r19_r1_source_fake as r19_tests


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _key(path: str) -> str:
    return ntpath.normcase(ntpath.normpath(str(path).replace("/", "\\")))


@pytest.fixture(scope="module")
def generated_r20(tmp_path_factory):
    """Build exact generated R13/R17/R19 bytes, then apply the R20 entry edit."""
    tmp_path = tmp_path_factory.mktemp("m01-r20-generated")
    prepared_r11, base_held = r11_tests._r11_prepared(tmp_path)
    r17_source = r17._self_source()
    r19_source = r19._self_source()
    r20_source = r20._self_source()
    runtime_map_path = r17._runtime_source_map_path(prepared_r11)
    original_outer = r13._active_outer_source
    r19_outer_bytes = {}

    def transformed_r20_outer(*args, **kwargs):
        base_outer = original_outer(*args, **kwargs)
        r17_outer = r17._apply_active_outer_transform(
            base_outer,
            runtime_map_path,
            r17_source[0],
            r17_source[2],
            r17._R17_OUTER_SUPPORT,
        )
        r19_outer = r19._apply_active_outer_transform(
            r17_outer,
            r19_source[0],
            r19_source[2],
            r19_source[1],
            r19._R19_OUTER_SUPPORT,
        )
        r19_outer_bytes["raw"] = r19_outer
        return r20._apply_active_outer_transform(
            r19_outer,
            r20_source[0],
            r20_source[2],
            r20_source[1],
            r20._R20_OUTER_SUPPORT,
        )

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(r13, "_active_outer_source", transformed_r20_outer)
        prepared_r13 = r13._compose(prepared_r11)

    runtime_map, descriptor, canonical_held = r19_tests._map_bytes(prepared_r13, base_held)
    map_path = Path(descriptor["source_map_path"])
    map_path.parent.mkdir(parents=True, exist_ok=True)
    map_path.write_bytes(prepared_r13.source_map_bytes)
    self_path = Path(runtime_map["runtime_namespace"]["self_path"])
    self_path.parent.mkdir(parents=True, exist_ok=True)
    self_path.write_bytes(prepared_r13.active_outer_source)
    self_path = self_path.resolve(strict=True)

    r19_outer = types.ModuleType("_m01_r20_r19_generated_active_outer")
    r19_outer.__file__ = str(self_path)
    exec(compile(r19_outer_bytes["raw"], str(self_path), "exec", dont_inherit=True), r19_outer.__dict__)
    r20_source_bytes = prepared_r13.active_outer_source
    r20_outer = types.ModuleType("_m01_r20_generated_active_outer")
    r20_outer.__file__ = str(self_path)
    exec(compile(r20_source_bytes, str(self_path), "exec", dont_inherit=True), r20_outer.__dict__)

    template_path = Path(r13._R10._repo_root()) / r13._R10.R28_OUTER_TEMPLATE_REL
    template_raw = template_path.read_bytes()
    assert _sha(template_raw) == r13._R10.R28_OUTER_TEMPLATE_SHA256
    assert b"self_path = Path(__file__).resolve(strict=True)" in template_raw
    assert b"self_path=self_path" in template_raw
    assert r20_source_bytes.count(b"if isinstance(self_path, Path):\n        self_path = str(self_path)\n") == 1

    return {
        "prepared_r13": prepared_r13,
        "runtime_map": runtime_map,
        "descriptor": descriptor,
        "canonical_held": canonical_held,
        "outer_r19": r19_outer,
        "outer_r20": r20_outer,
        "self_path": self_path,
        "plan_raw": next(
            raw for path, raw in canonical_held.items()
            if _key(path) == _key(runtime_map["runtime_namespace"]["plan_path"])
        ),
    }


class _StopBeforeProtectedIo(Exception):
    pass


class _FakePrivate:
    def __init__(self, events):
        self.events = events

    def _api(self):
        self.events.append("protected_io_boundary")
        raise _StopBeforeProtectedIo()


class _FakeScope:
    def __init__(self, rows, events, *, mode="good", runtime_map_path=""):
        self.rows = rows
        self.events = events
        self.mode = mode
        self.runtime_map_path = runtime_map_path

    def __enter__(self):
        self.events.append(("scope_enter", len(self.rows)))
        rows = dict(self.rows)
        if self.mode == "missing_runtime_map" and len(rows) == 2:
            rows.pop(self.runtime_map_path)
        elif self.mode == "missing_r17_helper" and len(rows) == 2:
            rows.pop(r17._self_source()[0])
        elif self.mode == "tampered_runtime_map" and len(rows) == 2:
            path = self.runtime_map_path
            rows[path] = rows[path] + b" "
        elif self.mode == "tampered_r17_helper" and len(rows) == 2:
            path = r17._self_source()[0]
            rows[path] = rows[path] + b" "
        return _FakePrivate(self.events), object(), rows

    def __exit__(self, *_args):
        self.events.append("scope_exit")
        return False


def _run_generated_outer(generated_r20, *, r20_enabled=True, mode="good"):
    prepared_r13 = generated_r20["prepared_r13"]
    runtime_map = generated_r20["runtime_map"]
    descriptor = generated_r20["descriptor"]
    canonical_held = generated_r20["canonical_held"]
    events = []
    source_map_bytes = prepared_r13.source_map_bytes
    r17_path, r17_raw, r17_sha = r17._self_source()
    support_rows = {
        descriptor["source_map_path"]: source_map_bytes,
        r17_path: r17_raw,
    }
    outer = generated_r20["outer_r20" if r20_enabled else "outer_r19"]

    class _Custody:
        PRIVATE = outer.PRIVATE_REL
        PRIVATE_SHA = outer.PRIVATE_SHA256
        CLI = outer.CLI_REL
        CLI_SHA = outer.CLI_SHA256

        @staticmethod
        def held_public_sources(public, software):
            if public:
                assert len(public) == 118 and len(software) == 36
                rows = canonical_held
            else:
                assert public == {}
                assert software == {
                    descriptor["source_map_path"]: _sha(source_map_bytes),
                    r17_path: r17_sha,
                }
                rows = support_rows
            return _FakeScope(
                rows,
                events,
                mode=mode,
                runtime_map_path=descriptor["source_map_path"],
            )

    real_check = outer._check

    def observed_check(value, code):
        if not value:
            events.append(("check_failure", code))
        return real_check(value, code)

    outer._check = observed_check
    real_runtime_map = outer._r19_read_runtime_map

    def observed_runtime_map(plan_raw, self_path, self_sha256):
        events.append(("runtime_map_self_path_type", type(self_path).__name__))
        return real_runtime_map(plan_raw, self_path, self_sha256)

    outer._r19_read_runtime_map = observed_runtime_map
    real_verify = outer._r13_verify_generated_active_outer

    def observed_verify(held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map):
        events.append(("verify_self_path_type", type(self_path).__name__))
        try:
            result = real_verify(
                held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map
            )
        except BaseException as error:
            events.append(("verify_error", type(error).__name__, str(error)))
            raise
        events.append("real_r13_r17_r19_r20_activation_passed")
        return result

    outer._r13_verify_generated_active_outer = observed_verify
    real_exact = outer._r13_exact_held

    def observed_exact(held, path):
        events.append(("exact_held_path_type", type(path).__name__, _key(path)))
        return real_exact(held, path)

    outer._r13_exact_held = observed_exact

    def closure(held, *_args, **kwargs):
        events.append("r28_closure_fake")
        assert len(canonical_held) == 154
        assert len(held) == 156
        for path, raw in support_rows.items():
            assert [value for key, value in held.items() if _key(key) == _key(path)] == [raw]
        assert kwargs["outer_template_sha256"] == outer._sha(
            next(
                raw for path, raw in canonical_held.items()
                if _key(path) == _key(str(outer.SELF_TEMPLATE_PATH))
            )
        )

    outer._verify_held_closure = closure
    case_map = {
        "schema": "iteration41.okx.m01.case-source-map.v23-diagnostic",
        "source_pins": {"case-%02d.py" % index: "%064x" % (index + 1) for index in range(34)},
    }
    case_map_before = json.dumps(case_map, sort_keys=True)
    result = outer.run_prelaunch(
        _Custody(),
        self_path=generated_r20["self_path"],
        self_sha256=_sha(prepared_r13.active_outer_source),
        plan_raw=generated_r20["plan_raw"],
        public=runtime_map["public_pins"],
        software=runtime_map["software_pins"],
        package_index={},
        source_map=case_map,
        source_index={},
        source_checkpoint={},
        record={},
        projection={},
        popen_factory=None,
        environ={},
        postverify=lambda _public, _software: True,
        now_utc=None,
    )
    assert json.dumps(case_map, sort_keys=True) == case_map_before
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0 and result["suite_ready"] is False
    return result, events, support_rows, runtime_map


def test_r19_source_fake_reproduces_real_r28_path_shape_binding_failure(generated_r20):
    result, events, _support_rows, _runtime_map = _run_generated_outer(
        generated_r20,
        r20_enabled=False,
    )

    assert ("check_failure", "r19_runtime_map_binding") in events
    assert "protected_io_boundary" not in events
    assert result["status"] == "BLOCKED"
    assert result["route_invocations"] == 0
    assert "provider" not in result


def test_r20_normalizes_real_r28_path_call_once_before_strict_gates(generated_r20):
    result, events, support_rows, runtime_map = _run_generated_outer(generated_r20)

    assert [event for event in events if isinstance(event, tuple) and event[0] == "scope_enter"] == [
        ("scope_enter", 154),
        ("scope_enter", 2),
    ]
    assert ("runtime_map_self_path_type", "str") in events
    assert ("verify_self_path_type", "str") in events
    assert "real_r13_r17_r19_r20_activation_passed" in events, (
        result.get("reason"),
        [event for event in events if isinstance(event, tuple)
         and event[0] in {"check_failure", "runtime_map_self_path_type", "verify_self_path_type", "verify_error"}],
        [event for event in events if type(event) is str],
    )
    assert "r28_closure_fake" in events
    assert events.index("real_r13_r17_r19_r20_activation_passed") < events.index("protected_io_boundary")
    exact_self_types = [event[1] for event in events if isinstance(event, tuple)
                        and event[0] == "exact_held_path_type"
                        and event[2] == _key(runtime_map["runtime_namespace"]["self_path"])]
    assert exact_self_types and all(kind == "str" for kind in exact_self_types)
    assert len(support_rows) == 2
    assert result["status"] == "BLOCKED"
    assert result["route_invocations"] == 0
    assert "provider" not in result


@pytest.mark.parametrize(
    "mode",
    ["missing_runtime_map", "missing_r17_helper", "tampered_runtime_map", "tampered_r17_helper"],
)
def test_r20_real_generated_outer_rejects_missing_or_changed_support(generated_r20, mode):
    result, events, _support_rows, _runtime_map = _run_generated_outer(generated_r20, mode=mode)

    assert "real_r13_r17_r19_r20_activation_passed" not in events
    assert "protected_io_boundary" not in events
    assert result["status"] == "BLOCKED"
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0 and result["suite_ready"] is False
    assert "provider" not in result
