"""Source-fake contracts for exact R13 transport forwarding through R14."""

from __future__ import annotations

import copy
import dataclasses
import hashlib
import time

import pytest

from scripts import iteration41_okx_l03_l04_v4_root_launcher as launcher
from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as r13
from scripts import iteration41_okx_m01_r33_parent_adapter_transport_r14_r1 as r14
from scripts import iteration41_suspended_child_image_r2 as image_observer
from tests.unit.runtime import test_iteration41_okx_m01_r33_returned_result_observer_r11_r1 as r11_tests


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _fixture(tmp_path):
    prepared_r11, held = r11_tests._r11_prepared(tmp_path)
    prepared_r13 = r13.prepare_from_r11(prepared_r11)
    r13._validate_prepared(prepared_r13)
    prepared_r14 = r14.prepare_from_r13(prepared_r13)
    r14._validate_prepared(prepared_r14)
    return prepared_r13, prepared_r14, held


@pytest.fixture(scope="module")
def prepared_pair(tmp_path_factory):
    return _fixture(tmp_path_factory.mktemp("m01-r14-parent-adapter"))


def _fake_adapter_kwargs(process_calls, auth_calls):
    def authenticate(scope, binding, timeout_seconds):
        auth_calls.append((scope, binding, timeout_seconds))
        return binding.get("schema") == r13.R13_BINDING_SCHEMA

    def process_factory(*_args, **_kwargs):
        process_calls.append(True)
        return None

    return {
        "scope_authenticator": authenticate,
        "fake_leaves": True,
        "native": object(),
        "process_factory": process_factory,
        "launcher_module": launcher,
        "image_module": image_observer,
        "clock": time.monotonic,
        "sleeper": time.sleep,
    }


def _assert_transport(view, prepared):
    assert view.command == prepared.command
    assert view.descriptor_json == prepared.descriptor_json
    assert view.stdin_descriptor == prepared.stdin_descriptor
    assert view.source_map_bytes == prepared.source_map_bytes
    assert view.runner_bytes == prepared.runner_bytes
    assert view.binding == prepared.binding
    assert view.binding_sha256 == prepared.binding_sha256


def test_r14_real_constructor_forwards_final_r13_transport_and_keeps_154_map(prepared_pair):
    prepared_r13, prepared_r14, _held = prepared_pair
    r14_addition = r14.parent_hold_addition(prepared_r14)
    assert r14.verify_parent_hold_addition(prepared_r14, r14_addition)
    assert r14_addition["canonical_child_map_count"] == 154
    assert len(prepared_r13.source_map_bytes) > 0

    process_calls = []
    auth_calls = []
    kwargs = _fake_adapter_kwargs(process_calls, auth_calls)

    # Establish the old behavior with the frozen adapter itself. Construction
    # only binds Python objects; it does not supervise or launch anything.
    legacy = r13.M01WindowsParentAdapter(prepared_r13, **kwargs)
    old_nested = legacy._r12._r11._r10._r9.prepared
    assert old_nested.command == prepared_r13.r10_prepared.command
    assert old_nested.stdin_descriptor == prepared_r13.r10_prepared.stdin_descriptor
    assert old_nested.stub_bytes == prepared_r13.r10_prepared.stub_bytes
    assert old_nested.binding == prepared_r13.r10_prepared.binding
    assert old_nested.command != prepared_r13.command
    assert old_nested.stdin_descriptor != prepared_r13.stdin_descriptor

    # The R14 constructor naturally builds the real frozen R12/R11/R10/R9
    # chain, then forwards the final R13 transport through R10's real rebind.
    adapter = r14.M01WindowsParentAdapter(prepared_r14, **kwargs)
    r9_adapter = adapter._r12._r11._r10._r9
    _assert_transport(r9_adapter.prepared, prepared_r13)
    assert r9_adapter.prepared.stub_bytes == prepared_r13.stub_bytes
    assert r9_adapter.prepared.sidecar_path == prepared_r13.sidecar_path
    assert r9_adapter.prepared.sidecar_sha256 == prepared_r13.sidecar_sha256
    assert r9_adapter.prepared.sidecar_size_bytes == prepared_r13.sidecar_size_bytes
    assert r9_adapter.prepared.windows_command_line_units == prepared_r13.windows_command_line_units

    r4_view = adapter._r8_adapter._r5.prepared
    assert r4_view.command == prepared_r13.command
    assert r4_view.stdin_descriptor == prepared_r13.stdin_descriptor
    assert r4_view.source_map_bytes == prepared_r13.source_map_bytes
    assert r4_view.runner_bytes == prepared_r13.runner_bytes
    assert r4_view.bootstrap_bytes == prepared_r13.stub_bytes
    assert r4_view.binding == prepared_r13.binding
    assert r4_view.binding_sha256 == prepared_r13.binding_sha256

    r2_view = adapter._r8_adapter._r5._base._r2_prepared
    assert r2_view.command == prepared_r13.command
    assert r2_view.stdin_descriptor == prepared_r13.stdin_descriptor
    assert r2_view.source_map_bytes == prepared_r13.source_map_bytes
    assert r2_view.runner_bytes == prepared_r13.runner_bytes
    assert r2_view.bootstrap_bytes == prepared_r13.stub_bytes
    assert r2_view.binding == prepared_r13.binding
    assert r2_view.binding_sha256 == prepared_r13.binding_sha256

    assert adapter.prepared.binding == prepared_r13.binding
    assert prepared_r14.adapter_binding["r13_binding_sha256"] == prepared_r13.binding_sha256
    assert prepared_r14.adapter_binding["r13_sidecar_path"] == prepared_r13.sidecar_path
    assert prepared_r14.adapter_binding["r13_sidecar_sha256"] == prepared_r13.sidecar_sha256
    assert prepared_r14.adapter_binding["r13_windows_command_line_units"] == prepared_r13.windows_command_line_units
    assert process_calls == []
    assert auth_calls == []


def test_r14_parent_hold_adds_exact_source_pin_and_rejects_mutations(prepared_pair):
    _prepared_r13, prepared_r14, _held = prepared_pair
    base = r13.parent_hold_addition(prepared_r14.r13_prepared)
    addition = r14.parent_hold_addition(prepared_r14)
    assert addition["schema"] == r14.R14_HOLD_SCHEMA
    assert addition["r13_hold_schema"] == base["schema"]
    assert addition["canonical_child_map_count"] == 154
    assert addition["r13_binding_sha256"] == prepared_r14.r13_prepared.binding_sha256
    assert addition["r14_binding_sha256"] == prepared_r14.adapter_binding_sha256

    path = prepared_r14.helper_path
    entry = addition["entries"][path]
    assert entry == {
        "sha256": prepared_r14.helper_sha256,
        "size_bytes": len(prepared_r14.helper_bytes),
        "role": r14.R14_SOURCE_ROLE,
        "origin": "repository_source:" + r14.R14_RELATIVE_PATH,
    }
    assert len(addition["entries"]) == len(base["entries"]) + 1
    assert r14.verify_parent_hold_addition(prepared_r14, addition)

    for field, changed in (
        ("sha256", "0" * 64),
        ("size_bytes", entry["size_bytes"] + 1),
        ("role", "unbound_role"),
        ("origin", "unbound_origin"),
    ):
        bad = copy.deepcopy(addition)
        bad["entries"][path][field] = changed
        assert not r14.verify_parent_hold_addition(prepared_r14, bad)

    missing = copy.deepcopy(addition)
    del missing["entries"][path]
    assert not r14.verify_parent_hold_addition(prepared_r14, missing)

    altered_source = dataclasses.replace(prepared_r14, helper_bytes=prepared_r14.helper_bytes + b"x")
    with pytest.raises(r14.ParentAdapterTransportBlocked, match="r14_helper_source_binding"):
        r14._validate_prepared(altered_source)


def test_r14_rejects_changed_r13_transport_and_binding_before_adapter_construction(prepared_pair):
    prepared_r13, prepared_r14, _held = prepared_pair
    changed_stdin = prepared_r13.stdin_descriptor[:-1] + bytes([prepared_r13.stdin_descriptor[-1] ^ 1])
    changed_r13 = dataclasses.replace(prepared_r13, stdin_descriptor=changed_stdin)
    changed_r14 = dataclasses.replace(prepared_r14, r13_prepared=changed_r13)

    with pytest.raises(r13.ActiveOuterActivationBlocked, match="prepared_binding"):
        r14._validate_prepared(changed_r14)

    bad_hold = r14.parent_hold_addition(prepared_r14)
    bad_hold["r14_binding_sha256"] = "0" * 64
    assert not r14.verify_parent_hold_addition(prepared_r14, bad_hold)

