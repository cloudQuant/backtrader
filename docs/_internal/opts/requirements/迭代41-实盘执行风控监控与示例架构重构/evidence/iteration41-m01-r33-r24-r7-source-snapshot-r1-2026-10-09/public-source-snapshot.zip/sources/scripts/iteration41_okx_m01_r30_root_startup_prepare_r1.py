"""Prepare a disabled R30 ROOT startup closure from the frozen R29 public bytes.

R30 keeps the R29 wrapper bytes and adds a narrow, exact outer-source lifecycle
fix: the deployment wrapper must already be present, protected, identity-held,
and byte-matched; the per-activation claim is created with exclusive-create,
flushed, and reopened under the bounded reader before child launch.

This builder only returns bytes and maps. It never opens a ROOT scope, writes
deployment files, imports an SDK, or starts a process.
"""

from __future__ import annotations

import copy
import hashlib
import importlib
import json
import ntpath
import re
from pathlib import Path
from typing import Any


R29_MODULE = "scripts.iteration41_okx_m01_r29_root_startup_prepare_r1"
R29_HELPER_SHA256 = "9db45f47a89673b323fca2926a3d2c077a872620a8741b63d5895462962d849a"
R29_TEST_SHA256 = "83f54cc0547913434c1187952f7bb347ece3a432ec81193cf71d13b86ea154a7"
R29_SCOPEFIX_HELPER_SHA256 = "a4e8f943e00dd8de1cb05b27c166dfde0043ff1fdae7094992c5d418fa13b14e"
R29_SCOPEFIX_TEST_SHA256 = "033ef472836e3a89c67c0730e647740d4c0eb96bb0098ec48abf52927a11588b"
R30_PREPARATION_SCHEMA = "iteration41.okx.m01.v6.root-startup-public-manifest.r30.r1.v1"
R30_RUNNER_SCHEMA = "iteration41.okx.m01.v6.root-startup-runner-template.r30.r1.v1"
R30_CLAIM_SCHEMA = "iteration41.okx.m01.v6.root-attempt-claim.r30.v1"
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")


class StartupPreparationBlocked(RuntimeError):
    """A fixed public-source, namespace, or manifest check failed."""

    _CODES = frozenset(
        {
            "dependency_pin_mismatch",
            "namespace_shape",
            "plan_digest_shape",
            "r29_prepare_failed",
            "r29_source_shape",
            "outer_patch_anchor",
            "outer_patch_compile",
            "outer_patch_contract",
            "manifest_shape",
            "manifest_binding",
            "runner_compile",
        }
    )

    def __init__(self, code: str):
        self.code = code if code in self._CODES else "startup_preparation_blocked"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _r29():
    try:
        module = importlib.import_module(R29_MODULE)
        raw = Path(module.__file__).read_bytes()
    except BaseException as exc:
        raise StartupPreparationBlocked("dependency_pin_mismatch") from exc
    if _sha(raw) != R29_HELPER_SHA256:
        raise StartupPreparationBlocked("dependency_pin_mismatch")
    for relative, expected in (
        ("tests/unit/runtime/test_iteration41_okx_m01_r29_root_startup_prepare_r1.py", R29_TEST_SHA256),
        ("tests/unit/runtime/test_iteration41_okx_m01_r29_root_metadata_scopefix_r1.py", R29_SCOPEFIX_TEST_SHA256),
    ):
        try:
            path = Path(module.__file__).resolve().parents[1] / relative
            digest = _sha(path.read_bytes())
        except BaseException as exc:
            raise StartupPreparationBlocked("dependency_pin_mismatch") from exc
        if digest != expected:
            raise StartupPreparationBlocked("dependency_pin_mismatch")
    if module.R29_SCOPEFIX_HELPER_SHA256 != R29_SCOPEFIX_HELPER_SHA256:
        raise StartupPreparationBlocked("dependency_pin_mismatch")
    return module


def _replace_once(raw: bytes, old: bytes, new: bytes) -> bytes:
    if raw.count(old) != 1:
        raise StartupPreparationBlocked("outer_patch_anchor")
    return raw.replace(old, new, 1)


_LEAF_FUNCTIONS = b'''R30_MAX_WRAPPER_BYTES = 2 * 1024 * 1024
R30_MAX_CLAIM_BYTES = 4096
R30_CLAIM_SCHEMA = "iteration41.okx.m01.v6.root-attempt-claim.r30.v1"


def _r30_predeployed_wrapper(private, cli, api, sid, stack, held):
    """Hold and verify the exact predeployed wrapper and directory chain."""
    deployment_handle, deployment_identity = _hold_directory_chain(
        stack, api, DEPLOYMENT, sid=sid
    )
    wrapper_parent = ACTIVE_WRAPPER_PATH.parent
    wrapper_parent_handle, wrapper_parent_identity = _hold_directory_chain(
        stack, api, wrapper_parent, sid=sid
    )
    wrapper_handle = stack.enter_context(
        cli._locked_readonly_file(ACTIVE_WRAPPER_PATH, private, api)
    )
    api.verify_acl(wrapper_handle, sid)
    wrapper_identity = cli._locked_file_identity(api, wrapper_handle, private)
    wrapper_bytes = cli._read_bounded_handle(api, wrapper_handle, R30_MAX_WRAPPER_BYTES)
    held_bytes = _r30_held_wrapper_bytes(held)
    _check(
        type(wrapper_bytes) is bytes
        and 0 < len(wrapper_bytes) <= R30_MAX_WRAPPER_BYTES
        and type(held_bytes) is bytes
        and wrapper_bytes == held_bytes
        and _sha(wrapper_bytes) == ACTIVE_WRAPPER_SHA256,
        "deployment_wrapper_pin",
    )
    _check(
        api.info(deployment_handle, directory=True) == deployment_identity
        and api.info(wrapper_parent_handle, directory=True) == wrapper_parent_identity
        and cli._locked_file_identity(api, wrapper_handle, private) == wrapper_identity,
        "deployment_identity_changed",
    )
    return (
        deployment_handle,
        deployment_identity,
        wrapper_parent_handle,
        wrapper_parent_identity,
        wrapper_handle,
        wrapper_identity,
        wrapper_bytes,
    )


def _r30_verify_deployment(private, cli, api, sid, held, bindings):
    """Recheck held directory/file identities and the bounded wrapper bytes."""
    (
        deployment_handle,
        deployment_identity,
        wrapper_parent_handle,
        wrapper_parent_identity,
        wrapper_handle,
        wrapper_identity,
        wrapper_bytes,
    ) = bindings
    api.verify_acl(deployment_handle, sid, directory=True)
    api.verify_acl(wrapper_parent_handle, sid, directory=True)
    api.verify_acl(wrapper_handle, sid)
    current = cli._read_bounded_handle(api, wrapper_handle, R30_MAX_WRAPPER_BYTES)
    held_bytes = _r30_held_wrapper_bytes(held)
    _check(
        api.info(deployment_handle, directory=True) == deployment_identity
        and api.info(wrapper_parent_handle, directory=True) == wrapper_parent_identity
        and cli._locked_file_identity(api, wrapper_handle, private) == wrapper_identity,
        "deployment_identity_changed",
    )
    _check(
        type(current) is bytes
        and current == wrapper_bytes
        and current == held_bytes
        and _sha(current) == ACTIVE_WRAPPER_SHA256,
        "deployment_wrapper_pin",
    )


def _r30_held_wrapper_bytes(held):
    """Resolve one exact absolute wrapper key across Windows case normalization."""
    target = os.path.normcase(os.path.normpath(str(Path(ACTIVE_WRAPPER_PATH))))
    matches = []
    for path, raw in held.items():
        if (
            type(path) is str
            and os.path.isabs(path)
            and os.path.normpath(path) == path
            and os.path.normcase(path) == target
        ):
            matches.append(raw)
    _check(len(matches) == 1 and type(matches[0]) is bytes, "deployment_wrapper_pin")
    return matches[0]


def _r30_claim_payload(activation_id, plan_raw):
    _check(type(plan_raw) is bytes and len(plan_raw) <= MAX_PLAN_BYTES, "attempt_claim_plan_shape")
    document = {
        "schema": R30_CLAIM_SCHEMA,
        "activation_id": activation_id,
        "plan_sha256": _sha(plan_raw),
        "wrapper_sha256": ACTIVE_WRAPPER_SHA256,
    }
    raw = _canonical(document)
    _check(0 < len(raw) <= R30_MAX_CLAIM_BYTES, "attempt_claim_shape")
    return raw


def _r30_create_attempt_claim(private, cli, api, sid, stack, activation_id, plan_raw):
    """Atomically claim this activation, flush it, and verify under a read lease."""
    claim_raw = _r30_claim_payload(activation_id, plan_raw)
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    if hasattr(os, "O_BINARY"):
        flags |= os.O_BINARY
    try:
        descriptor = os.open(str(ATTEMPT_CLAIM), flags, 0o600)
    except FileExistsError as exc:
        raise PrelaunchBlocked("route_already_claimed") from exc
    try:
        with os.fdopen(descriptor, "wb", closefd=True) as claim_file:
            written = claim_file.write(claim_raw)
            _check(written == len(claim_raw), "attempt_claim_write")
            claim_file.flush()
            os.fsync(claim_file.fileno())
    except PrelaunchBlocked:
        raise
    except BaseException as exc:
        raise PrelaunchBlocked("attempt_claim_write") from exc
    claim_handle = stack.enter_context(
        cli._locked_readonly_file(ATTEMPT_CLAIM, private, api)
    )
    api.verify_acl(claim_handle, sid)
    claim_identity = cli._locked_file_identity(api, claim_handle, private)
    verified = cli._read_bounded_handle(api, claim_handle, R30_MAX_CLAIM_BYTES)
    _check(
        verified == claim_raw
        and _sha(verified) == _sha(claim_raw)
        and cli._locked_file_identity(api, claim_handle, private) == claim_identity,
        "attempt_claim_verify",
    )
    return claim_handle, claim_identity, claim_raw


def _r30_verify_attempt_claim(private, cli, api, sid, claim_handle, claim_identity, claim_raw):
    api.verify_acl(claim_handle, sid)
    verified = cli._read_bounded_handle(api, claim_handle, R30_MAX_CLAIM_BYTES)
    _check(
        cli._locked_file_identity(api, claim_handle, private) == claim_identity
        and verified == claim_raw
        and _sha(verified) == _sha(claim_raw),
        "attempt_claim_identity_changed",
    )


def _r30_create_fresh_capture(private, capture_path):
    """Create the activation-specific capture directory only when absent."""
    _check(not os.path.lexists(capture_path), "child_capture_already_exists")
    return private.create_private_directory(capture_path)


def _r30_prepare_child_launch(private, cli, api, sid, stack, held, activation_id, plan_raw):
    """Run the predeploy, one-shot claim, and fresh-capture gates in order."""
    deployment_bindings = _r30_predeployed_wrapper(private, cli, api, sid, stack, held)
    claim_handle, claim_identity, claim_raw = _r30_create_attempt_claim(
        private, cli, api, sid, stack, activation_id, plan_raw
    )
    capture_path = CONTROL / ("child-capture-r28-" + activation_id)
    capture_dir = _r30_create_fresh_capture(private, capture_path)
    return (
        deployment_bindings,
        claim_handle,
        claim_identity,
        claim_raw,
        capture_path,
        capture_dir,
    )


'''


def _patch_outer(raw: bytes) -> bytes:
    if type(raw) is not bytes:
        raise StartupPreparationBlocked("r29_source_shape")
    before = b"def run_prelaunch(\n"
    patched = _replace_once(raw, before, _LEAF_FUNCTIONS + before)
    old_gate = (
        b'                _check(not os.path.lexists(ATTEMPT_CLAIM), "route_already_claimed")\n'
        b'                _check(not os.path.lexists(DEPLOYMENT), "deployment_already_exists")\n'
    )
    new_gate = (
        b"                (\n"
        b"                    deployment_bindings,\n"
        b"                    claim_handle,\n"
        b"                    claim_identity,\n"
        b"                    claim_raw,\n"
        b"                    capture_path,\n"
        b"                    capture_dir,\n"
        b"                ) = _r30_prepare_child_launch(\n"
        b"                    private, cli, api, sid, stack, held,\n"
        b"                    plan_doc[\"activation_id\"], plan_raw\n"
        b"                )\n"
    )
    patched = _replace_once(patched, old_gate, new_gate)
    old_capture = (
        b'                _check(not os.path.lexists(capture_path), "child_capture_already_exists")\n'
        b"                capture_dir = private.create_private_directory(capture_path)\n"
    )
    new_capture = b"                capture_dir.verify()\n"
    patched = _replace_once(patched, old_capture, new_capture)
    old_post = (
        b'                if api.info(control_handle, directory=True) != control_identity:\n'
        b'                    failure = failure or "control_identity_changed_after_child"\n'
        b"                if cli._locked_file_identity(api, plan_handle, private) != plan_identity:\n"
        b'                    failure = failure or "plan_identity_changed_after_child"\n'
    )
    new_post = (
        old_post
        + b"                try:\n"
        + b"                    _r30_verify_deployment(private, cli, api, sid, held, deployment_bindings)\n"
        + b"                except PrelaunchBlocked as error:\n"
        + b"                    failure = failure or error.code\n"
        + b"                try:\n"
        + b"                    _r30_verify_attempt_claim(\n"
        + b"                        private, cli, api, sid, claim_handle, claim_identity, claim_raw\n"
        + b"                    )\n"
        + b"                except PrelaunchBlocked as error:\n"
        + b"                    failure = failure or error.code\n"
    )
    patched = _replace_once(patched, old_post, new_post)
    try:
        compile(patched, "<r30-filled-outer>", "exec", dont_inherit=True)
    except SyntaxError as exc:
        raise StartupPreparationBlocked("outer_patch_compile") from exc
    required = (
        b"def _r30_predeployed_wrapper(",
        b"def _r30_create_attempt_claim(",
        b"def _r30_prepare_child_launch(",
        b"os.O_EXCL",
        b"claim_file.flush()",
        b"os.fsync(claim_file.fileno())",
        b"_r30_verify_deployment(private, cli, api, sid, held, deployment_bindings)",
        b"_r30_create_fresh_capture(private, capture_path)",
    )
    if any(item not in patched for item in required) or patched.count(b"os.path.lexists(DEPLOYMENT)") != 0:
        raise StartupPreparationBlocked("outer_patch_contract")
    return patched


def _runner_source(manifest: dict) -> bytes:
    r29 = _r29()
    r2 = r29._r2()
    compact = json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    prefix = (
        "# Generated from the frozen R28 source/review closure and R30 predeployment/claim gates. "
        "ROOT activation remains UNSET.\n"
    )
    source = (
        "from __future__ import annotations\n"
        "import json\n"
        + prefix
        + "MANIFEST = json.loads(" + repr(compact) + ")\n"
        + r2._RUNNER_BODY
    )
    try:
        compile(source, "<r30-root-runner-template>", "exec", dont_inherit=True)
    except SyntaxError as exc:
        raise StartupPreparationBlocked("runner_compile") from exc
    return source.encode("utf-8")


def _manifest_digest(manifest: dict) -> str:
    payload = dict(manifest)
    payload.pop("manifest_binding_sha256", None)
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return _sha(raw)


def _seal(manifest: dict) -> None:
    manifest["manifest_binding_sha256"] = _manifest_digest(manifest)


def _validate_manifest(manifest: Any) -> None:
    if (
        type(manifest) is not dict
        or manifest.get("schema") != R30_PREPARATION_SCHEMA
        or manifest.get("runner_template_schema") != R30_RUNNER_SCHEMA
        or manifest.get("status") != "SOURCE_FAKE_ONLY_DISABLED"
        or manifest.get("manifest_binding_sha256") != _manifest_digest(manifest)
    ):
        raise StartupPreparationBlocked("manifest_binding")
    public = manifest.get("public_pins")
    software = manifest.get("software_pins")
    combined = manifest.get("canonical_pins")
    if (
        type(public) is not dict
        or type(software) is not dict
        or type(combined) is not dict
        or len(public) != 118
        or len(software) != 36
        or len(combined) != 154
        or any(combined.get(path) != digest for path, digest in software.items())
        or manifest.get("map_counts")
        != {"public_pin_count": 118, "software_pin_count": 36, "canonical_pin_count": 154}
        or manifest.get("candidate", {}).get("default_flags", {}).get("generated_runner_enabled") is not False
        or manifest.get("safety", {}).get("runner_default_enabled") is not False
        or manifest.get("once", {}).get("parse_allowed") is not False
        or manifest.get("outer_timeouts")
        != {
            "capture_seconds": 405,
            "cleanup_seconds": 5,
            "external_parent_envelope_seconds": None,
            "external_parent_envelope_established": False,
        }
    ):
        raise StartupPreparationBlocked("manifest_shape")


def _build(namespace: Any, plan_sha256: str):
    if type(plan_sha256) is not str or _HEX64.fullmatch(plan_sha256) is None:
        raise StartupPreparationBlocked("plan_digest_shape")
    r29 = _r29()
    try:
        base = r29.prepare_root_startup(namespace, plan_sha256=plan_sha256)
    except BaseException as exc:
        raise StartupPreparationBlocked("r29_prepare_failed") from exc
    old = base.get("manifest")
    outer_r29 = base.get("active_outer_source")
    wrapper = base.get("active_wrapper_source")
    if (
        type(old) is not dict
        or type(outer_r29) is not bytes
        or type(wrapper) is not bytes
        or _sha(wrapper) != old.get("candidate", {}).get("active_wrapper_sha256")
    ):
        raise StartupPreparationBlocked("r29_source_shape")
    outer = _patch_outer(outer_r29)
    manifest = copy.deepcopy(old)
    manifest["schema"] = R30_PREPARATION_SCHEMA
    manifest["runner_template_schema"] = R30_RUNNER_SCHEMA
    manifest["candidate"]["active_outer_sha256"] = _sha(outer)
    self_key = r29._r2()._canonical(manifest["runtime_namespace"]["self_path"])
    wrapper_key = r29._r2()._canonical(manifest["runtime_namespace"]["active_wrapper_path"])
    plan_key = r29._r2()._canonical(manifest["runtime_namespace"]["plan_path"])
    software = dict(manifest["software_pins"])
    if (
        self_key not in software
        or wrapper_key not in software
        or plan_key not in software
        or software[wrapper_key] != _sha(wrapper)
        or software[plan_key] != plan_sha256
    ):
        raise StartupPreparationBlocked("manifest_shape")
    software[self_key] = _sha(outer)
    manifest["software_pins"] = dict(sorted(software.items()))
    combined = dict(manifest["canonical_pins"])
    for path, digest in software.items():
        if path not in combined:
            raise StartupPreparationBlocked("manifest_shape")
        combined[path] = digest
    manifest["canonical_pins"] = dict(sorted(combined.items()))
    manifest["runtime_outputs"]["root_prelaunch_source"]["sha256"] = _sha(outer)
    manifest["runtime_outputs"]["root_actual_wrapper_source"]["sha256"] = _sha(wrapper)
    manifest["r29_source_change"]["active_outer_sha256"] = _sha(outer_r29)
    manifest["r30_source_change"] = {
        "base_outer_sha256": _sha(outer_r29),
        "active_outer_sha256": _sha(outer),
        "wrapper_sha256": _sha(wrapper),
        "predeployment_check": "protected-directory-and-file-identity-acl-exact-bytes",
        "attempt_claim": "CREATE_NEW_FLUSH_BOUNDED_READBACK_HELD_THROUGH_CHILD",
        "capture_directory": "fresh-activation-specific-private-directory",
        "business_validators_changed": False,
        "frozen_r29_r28_r27_bytes_modified": False,
    }
    manifest["safety"]["activation_written_or_deployed"] = False
    manifest["safety"]["active_sources_created_in_memory"] = True
    manifest["safety"]["predeployment_required_before_outer"] = True
    manifest["safety"]["attempt_claim_written_by_outer_before_child"] = True
    manifest["safety"]["external_parent_supervision_established"] = False
    _seal(manifest)
    _validate_manifest(manifest)
    return manifest, outer, wrapper


def build_public_manifest(namespace: Any, *, plan_sha256: str) -> dict:
    manifest, _outer, _wrapper = _build(namespace, plan_sha256)
    return manifest


def scope_maps(manifest: dict) -> tuple[dict[str, str], dict[str, str]]:
    _validate_manifest(manifest)
    return dict(manifest["public_pins"]), dict(manifest["software_pins"])


def render_root_runner_template(manifest: dict) -> bytes:
    _validate_manifest(manifest)
    return _runner_source(manifest)


def prepare_root_startup(namespace: Any, *, plan_sha256: str) -> dict[str, Any]:
    manifest, outer, wrapper = _build(namespace, plan_sha256)
    runner = _runner_source(manifest)
    return {
        "manifest": manifest,
        "public_pins": dict(manifest["public_pins"]),
        "software_pins": dict(manifest["software_pins"]),
        "canonical_pins": dict(manifest["canonical_pins"]),
        "active_outer_source": outer,
        "active_wrapper_source": wrapper,
        "runner_template_source": runner,
        "runner_template_sha256": _sha(runner),
        "status": "SOURCE_FAKE_ONLY_DISABLED",
    }


def default_test_namespace(root: str = r"Z:\r30-source-fake") -> dict[str, str]:
    base = ntpath.normpath(root)
    return {
        "control_dir": ntpath.join(base, "control"),
        "deployment_dir": ntpath.join(base, "deployment"),
        "plan_path": ntpath.join(base, "control", "plan.json"),
        "self_path": ntpath.join(base, "control", "root_prelaunch_active.py"),
        "active_wrapper_path": ntpath.join(base, "deployment", "root_actual_wrapper.py"),
        "attempt_claim_path": ntpath.join(base, "control", "attempt.claim"),
    }


if __name__ == "__main__":
    raise SystemExit("Call prepare_root_startup() with a fresh namespace and exact plan digest.")
