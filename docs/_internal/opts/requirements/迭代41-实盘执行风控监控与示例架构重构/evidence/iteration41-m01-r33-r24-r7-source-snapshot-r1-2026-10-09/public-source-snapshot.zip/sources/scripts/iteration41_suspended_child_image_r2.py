"""Root-only, read-only image observation before a suspended child is resumed.

The caller owns the process handle, suspended creation, Job assignment, and the
physical lease on the fixed executable.  This leaf neither resumes the child nor
claims that those caller-owned conditions have been established.
"""

import ctypes
import ntpath
import os
from ctypes import wintypes


FIXED_EXECUTABLE = "C:/anaconda3/python.exe"
ROOT_NATIVE_ENABLED = False
STILL_ACTIVE = 259
WAIT_TIMEOUT = 258
MAX_IMAGE_PATH_CHARS = 32768


class ChildImageBlocked(ValueError):
    """A finite, non-secret reason for refusing to resume a child."""


def _require(condition, code):
    if not condition:
        raise ChildImageBlocked(code)


def _validate_observation(expected_pid, observed_pid, exit_code, image_path, wait_status):
    """Validate scalar observations; this pure function is not native proof."""
    _require(type(expected_pid) is int and expected_pid > 0, "child_pid_invalid")
    _require(type(observed_pid) is int and observed_pid == expected_pid, "child_pid_mismatch")
    _require(
        type(wait_status) is int and wait_status == WAIT_TIMEOUT,
        "child_signaled_or_wait_failed",
    )
    _require(type(exit_code) is int and exit_code == STILL_ACTIVE, "child_not_active")
    _require(type(image_path) is str, "child_image_type")
    _require(0 < len(image_path) < MAX_IMAGE_PATH_CHARS, "child_image_length")
    _require("\x00" not in image_path, "child_image_nul")
    _require(ntpath.isabs(image_path), "child_image_not_absolute")
    _require(
        ntpath.normcase(ntpath.normpath(image_path))
        == ntpath.normcase(ntpath.normpath(FIXED_EXECUTABLE)),
        "child_image_mismatch",
    )


def observe_suspended_child_image(process):
    """Query the existing child handle without executing or resuming the child.

    Root must enable this exact held module in memory.  A successful return only
    establishes the handle's PID, active status, and fixed executable path at the
    observation boundary.  No SDK, DLL, Job, suspension, custody, cleanup,
    account, or whole-command acceptance is implied.
    """
    _require(ROOT_NATIVE_ENABLED is True, "root_native_disabled")
    _require(os.name == "nt", "windows_required")
    expected_pid = getattr(process, "pid", None)
    _require(type(expected_pid) is int and expected_pid > 0, "child_pid_invalid")
    raw_handle = getattr(process, "_handle", None)
    _require(raw_handle is not None, "child_handle_missing")
    try:
        handle_value = int(raw_handle)
    except (TypeError, ValueError, OverflowError):
        raise ChildImageBlocked("child_handle_invalid") from None
    _require(handle_value not in (0, -1), "child_handle_invalid")

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    get_pid = kernel.GetProcessId
    get_pid.argtypes = [wintypes.HANDLE]
    get_pid.restype = wintypes.DWORD
    get_exit = kernel.GetExitCodeProcess
    get_exit.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
    get_exit.restype = wintypes.BOOL
    query_image = kernel.QueryFullProcessImageNameW
    query_image.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD),
    ]
    query_image.restype = wintypes.BOOL
    wait_process = kernel.WaitForSingleObject
    wait_process.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    wait_process.restype = wintypes.DWORD
    handle = wintypes.HANDLE(handle_value)
    observed_pid = int(get_pid(handle))
    _require(observed_pid != 0, "child_pid_query_failed")
    exit_code = wintypes.DWORD()
    _require(bool(get_exit(handle, ctypes.byref(exit_code))), "child_exit_query_failed")
    image_buffer = ctypes.create_unicode_buffer(MAX_IMAGE_PATH_CHARS)
    image_length = wintypes.DWORD(MAX_IMAGE_PATH_CHARS)
    _require(
        bool(query_image(handle, 0, image_buffer, ctypes.byref(image_length))),
        "child_image_query_failed",
    )
    _require(0 < image_length.value < MAX_IMAGE_PATH_CHARS, "child_image_length")
    image_path = image_buffer[: image_length.value]
    # An exited process may have exit code 259; require its handle nonsignaled.
    wait_status = int(wait_process(handle, 0))
    _validate_observation(
        expected_pid, observed_pid, int(exit_code.value), image_path, wait_status
    )
    return {
        "schema": "iteration41.suspended-child-image-observation.v2",
        "child_pid": observed_pid,
        "fixed_executable_path_observed": True,
        "active_at_observation": True,
        "suspension_verified": False,
        "job_assignment_verified": False,
        "physical_image_custody_verified": False,
        "whole_command_g1": False,
        "strict_cases_passed": 0,
        "authority": False,
    }
