"""Bind R17's generated support sources in the inner CUV2 scope.

R19 is an additive same-call layer over R17.  It keeps the 154 canonical
source-map rows in their original CUV2 scope and holds the runtime source map
and R17 helper in a separate exact support scope.  The exact R19 helper bytes
are embedded in the generated outer for source replay and remain separately
held by the parent.  R13/R17 source validation and the R14 constructor remain
live.
"""

from __future__ import annotations

import copy
import dataclasses
import ast
import hashlib
import ntpath
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as _R13
from scripts import iteration41_okx_m01_r33_final_output_hold_r16_r1 as _R16
from scripts import iteration41_okx_m01_r33_parent_adapter_constructor_r18_r1 as _R18
from scripts import iteration41_okx_m01_r33_parent_adapter_transport_r14_r1 as _R14
from scripts import iteration41_okx_m01_r33_source_map_gate_r17_r1 as _R17


R19_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_child_source_scope_r19_r1.py"
R19_RESULT_SCHEMA = "iteration41.okx.m01.r33.child-source-scope-r19.root-preparation.v1"
R19_ADAPTER_RESULT_SCHEMA = "iteration41.okx.m01.r33.child-source-scope-r19.parent-adapter.v1"
R19_SOURCE_ROLE = "r19_inner_child_source_scope_source"
R19_MAX_SOURCE_BYTES = 2097152
R19_MAX_OUTER_BYTES = 2097152
R19_PINNED_R18_SHA256 = "f9dd76909adeff5b0f6e76a9664c427b213e10a2915109e1f7dda32b1ea47902"
R19_R17_OUTER_MARKER = b"iteration41.okx.m01.r33.held-runtime-source-map-gate-r17.r1.v1"
R19_CHILD_SUPPORT_COUNT = 2
R19_FAILURE_CODES = frozenset(
    {
        "r19_module_name",
        "r19_module_path",
        "r19_source_unavailable",
        "r19_source_size",
        "r19_source_binding",
        "r19_r18_source_pin",
        "r19_r17_source_pin",
        "r19_r13_source_pin",
        "r19_r16_source_pin",
        "r19_r14_source_pin",
        "r19_r17_function_identity",
        "r19_patch_context_busy",
        "r19_patch_owner_thread",
        "r19_patch_context_changed",
        "r19_descriptor_rejected",
        "r19_descriptor_input_changed",
        "r19_runtime_map_path_unbound",
        "r19_runtime_map_unavailable",
        "r19_runtime_map_size",
        "r19_runtime_map_json",
        "r19_runtime_map_binding",
        "r19_canonical_map_shape",
        "r19_canonical_map_collision",
        "r19_support_path_shape",
        "r19_support_collision",
        "r19_support_scope_shape",
        "r19_support_scope_rows",
        "r19_support_row_bytes",
        "r19_support_merge_collision",
        "r19_active_outer_transform",
        "r19_r16_composite_blocked",
        "r19_r16_result_type",
        "r19_r17_result_binding",
        "r19_hold_schema",
        "r19_hold_collision",
        "r19_hold_digest",
        "r19_prepared_binding",
        "r19_r14_result",
        "r19_recompose_count",
        "r19_outer_transform_count",
        "r19_adapter_binding",
    }
)


class ChildSourceScopeR19Blocked(ValueError):
    """A fixed R19 source, held-scope, transform, or adapter contract failed."""

    def __init__(self, code: str):
        self.code = code if code in R19_FAILURE_CODES else "r19_adapter_binding"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ChildSourceScopeR19Blocked(code)


def _canonical_json(value: Any) -> bytes:
    return _R17._canonical_json(value)


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R19_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r19_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R19_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r19_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R19_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ChildSourceScopeR19Blocked("r19_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R19_MAX_SOURCE_BYTES, "r19_source_size")
    return str(path), raw, _sha(raw)


_R19_OUTER_SUPPORT = br'''
import ast
import contextlib
import hashlib
import ntpath
import os
from pathlib import Path

R19_CHILD_SOURCE_SCOPE_MARKER = b"iteration41.okx.m01.r33.inner-child-source-scope-r19.r1.v1"
R19_HELPER_PATH = __R19_HELPER_PATH__
R19_HELPER_SHA256 = __R19_HELPER_SHA256__
R19_HELPER_SOURCE_BYTES = __R19_HELPER_SOURCE_BYTES__
R19_MAX_SOURCE_BYTES = 2097152
R19_RUNTIME_MAP_MAX_BYTES = 1048576
R19_CANONICAL_PUBLIC_COUNT = 118
R19_CANONICAL_SOFTWARE_COUNT = 36
R19_CHILD_SUPPORT_COUNT = 2


def _r19_normalized(path):
    return ntpath.normcase(ntpath.normpath(str(path).replace("/", "\\")))


def _r19_expected_map(public, software, root):
    _check(
        type(public) is dict and len(public) == R19_CANONICAL_PUBLIC_COUNT
        and type(software) is dict and len(software) == R19_CANONICAL_SOFTWARE_COUNT,
        "r19_canonical_map_shape",
    )
    expected = {}
    for relative, digest in public.items():
        _check(
            type(relative) is str and type(digest) is str and len(digest) == 64
            and all(char in "0123456789abcdef" for char in digest),
            "r19_canonical_map_shape",
        )
        key = _r19_normalized(ntpath.join(root, relative))
        _check(key not in expected, "r19_canonical_map_collision")
        expected[key] = digest
    for path, digest in software.items():
        _check(
            type(path) is str and ntpath.isabs(path)
            and type(digest) is str and len(digest) == 64
            and all(char in "0123456789abcdef" for char in digest),
            "r19_canonical_map_shape",
        )
        key = _r19_normalized(path)
        _check(key not in expected, "r19_canonical_map_collision")
        expected[key] = digest
    _check(len(expected) == 154, "r19_canonical_map_shape")
    return expected


def _r19_read_runtime_map(plan_raw, self_path, self_sha256):
    path = R17_RUNTIME_SOURCE_MAP_PATH
    _check(
        type(path) is str and ntpath.isabs(path)
        and ntpath.normpath(path) == path and "\x00" not in path,
        "r19_support_path_shape",
    )
    try:
        with Path(path).open("rb") as stream:
            before = os.fstat(stream.fileno())
            raw = stream.read(R19_RUNTIME_MAP_MAX_BYTES + 1)
            after = os.fstat(stream.fileno())
    except BaseException:
        raise ValueError("r19_runtime_map_unavailable") from None
    first = (
        before.st_dev, before.st_ino, before.st_size,
        getattr(before, "st_mtime_ns", None), getattr(before, "st_ctime_ns", None),
    )
    second = (
        after.st_dev, after.st_ino, after.st_size,
        getattr(after, "st_mtime_ns", None), getattr(after, "st_ctime_ns", None),
    )
    _check(
        first == second and type(raw) is bytes
        and 0 < len(raw) <= R19_RUNTIME_MAP_MAX_BYTES
        and before.st_size == len(raw),
        "r19_runtime_map_size",
    )
    try:
        value = _strict_json(raw, R19_RUNTIME_MAP_MAX_BYTES)
    except BaseException:
        raise ValueError("r19_runtime_map_json") from None
    _check(
        type(value) is dict and frozenset(value) == R17_SOURCE_MAP_KEYS,
        "r19_runtime_map_binding",
    )
    namespace = value.get("runtime_namespace")
    plan_sha256 = _sha(plan_raw) if type(plan_raw) is bytes else None
    _check(
        value.get("schema") == R17_SOURCE_MAP_SCHEMA
        and namespace == R13_EXPECTED_NAMESPACE
        and value.get("plan_sha256") == R13_EXPECTED_PLAN_SHA256 == plan_sha256
        and value.get("map_counts") == {"public": 118, "software": 36, "canonical": 154}
        and type(value.get("root")) is str and ntpath.isabs(value["root"])
        and type(self_path) is str and type(self_sha256) is str
        and _r19_normalized(self_path) == _r19_normalized(namespace.get("self_path")),
        "r19_runtime_map_binding",
    )
    _r13_map_pin(value.get("software_pins"), self_path, self_sha256, "r19_runtime_map_binding")
    _r13_map_pin(
        value.get("software_pins"), namespace["plan_path"], plan_sha256,
        "r19_runtime_map_binding",
    )
    return raw, value, hashlib.sha256(raw).hexdigest()


def _r19_hold_rows(custody, public, software, plan_raw, self_path, self_sha256):
    raw, runtime_map, map_sha256 = _r19_read_runtime_map(plan_raw, self_path, self_sha256)
    canonical = _r19_expected_map(public, software, runtime_map["root"])
    support_paths = (
        R17_RUNTIME_SOURCE_MAP_PATH,
        R17_HELPER_PATH,
    )
    support_pins = (
        map_sha256,
        R17_HELPER_SHA256,
    )
    support_keys = []
    for path, digest in zip(support_paths, support_pins):
        _check(
            type(path) is str and ntpath.isabs(path)
            and ntpath.normpath(path) == path
            and type(digest) is str and len(digest) == 64
            and all(char in "0123456789abcdef" for char in digest),
            "r19_support_path_shape",
        )
        key = _r19_normalized(path)
        _check(key not in canonical and key not in support_keys, "r19_support_collision")
        support_keys.append(key)
    _check(len(support_keys) == R19_CHILD_SUPPORT_COUNT, "r19_support_scope_shape")
    return raw, canonical, dict(zip(support_paths, support_pins))


def _r19_check_held_rows(held, expected):
    _check(type(held) is dict and len(held) == len(expected), "r19_support_scope_rows")
    actual = {}
    for path, raw in held.items():
        _check(type(path) is str and type(raw) is bytes, "r19_support_scope_rows")
        key = _r19_normalized(path)
        _check(key not in actual, "r19_support_scope_rows")
        actual[key] = raw
    _check(set(actual) == {_r19_normalized(path) for path in expected}, "r19_support_scope_rows")
    values = {}
    for path, digest in expected.items():
        raw = actual[_r19_normalized(path)]
        _check(
            type(raw) is bytes and 0 < len(raw) <= 2 * 1024 * 1024
            and hashlib.sha256(raw).hexdigest() == digest,
            "r19_support_row_bytes",
        )
        values[_r19_normalized(path)] = raw
    return values


@contextlib.contextmanager
def _r19_held_public_sources(custody, public, software, self_path, self_sha256, plan_raw):
    raw, canonical_expected, support_expected = _r19_hold_rows(
        custody, public, software, plan_raw, self_path, self_sha256
    )
    with contextlib.ExitStack() as stack:
        private, cli, canonical_held = stack.enter_context(
            custody.held_public_sources(public, software)
        )
        _check(type(canonical_held) is dict, "r19_canonical_map_shape")
        canonical_actual = {}
        for path, value in canonical_held.items():
            _check(type(path) is str and type(value) is bytes, "r19_canonical_map_shape")
            key = _r19_normalized(path)
            _check(key not in canonical_actual, "r19_canonical_map_collision")
            canonical_actual[key] = hashlib.sha256(value).hexdigest()
        _check(canonical_actual == canonical_expected, "r19_canonical_map_shape")

        _support_private, _support_cli, support_held = stack.enter_context(
            custody.held_public_sources({}, support_expected)
        )
        support_actual = _r19_check_held_rows(support_held, support_expected)
        _check(
            support_actual[_r19_normalized(R17_RUNTIME_SOURCE_MAP_PATH)] == raw,
            "r19_support_row_bytes",
        )
        merged = dict(canonical_held)
        for path, value in support_held.items():
            key = _r19_normalized(path)
            _check(
                all(_r19_normalized(existing) != key for existing in merged),
                "r19_support_merge_collision",
            )
            merged[path] = value
        _check(len(merged) == 154 + R19_CHILD_SUPPORT_COUNT, "r19_support_scope_rows")
        yield private, cli, merged


def _r19_rebuild_exact_active_outer(base_r10_outer, outer, *, held):
    regenerated = _r17_rebuild_exact_active_outer(base_r10_outer, outer, held=held)
    helper_raw = R19_HELPER_SOURCE_BYTES
    _check(
        type(helper_raw) is bytes and 0 < len(helper_raw) <= 2 * 1024 * 1024
        and hashlib.sha256(helper_raw).hexdigest() == R19_HELPER_SHA256,
        "r19_helper_held_pin",
    )
    try:
        assignments, functions = _r13_source_nodes(helper_raw)
        support_template = ast.literal_eval(assignments["_R19_OUTER_SUPPORT"])
        relative_path = ast.literal_eval(assignments["R19_RELATIVE_PATH"])
        result_schema = ast.literal_eval(assignments["R19_RESULT_SCHEMA"])
        source_limit = ast.literal_eval(assignments["R19_MAX_SOURCE_BYTES"])
        outer_limit = ast.literal_eval(assignments["R19_MAX_OUTER_BYTES"])
        r17_marker = ast.literal_eval(assignments["R19_R17_OUTER_MARKER"])
        transform = _r13_compile_function(
            {
                "hashlib": hashlib,
                "ntpath": ntpath,
                "R19_MAX_SOURCE_BYTES": source_limit,
                "R19_MAX_OUTER_BYTES": outer_limit,
                "R19_R17_OUTER_MARKER": r17_marker,
            },
            functions,
            "_apply_active_outer_transform",
            "_r19_apply_active_outer_transform",
        )
    except BaseException:
        raise ValueError("r19_helper_transform_unavailable") from None
    _check(
        type(support_template) is bytes
        and relative_path == "scripts/iteration41_okx_m01_r33_child_source_scope_r19_r1.py"
        and result_schema == "iteration41.okx.m01.r33.child-source-scope-r19.root-preparation.v1"
        and type(source_limit) is int and 0 < source_limit <= 2 * 1024 * 1024
        and type(outer_limit) is int and 0 < outer_limit <= 2 * 1024 * 1024
        and type(r17_marker) is bytes,
        "r19_helper_source_constants",
    )
    return transform(
        regenerated,
        R19_HELPER_PATH,
        R19_HELPER_SHA256,
        helper_raw,
        support_template,
    )
'''


def _apply_active_outer_transform(
    raw: bytes,
    helper_path: str,
    helper_sha256: str,
    helper_raw: bytes,
    support_template: bytes,
) -> bytes:
    """Add exact inner support leases and source replay to the R17 active outer."""
    if type(raw) is not bytes or not 0 < len(raw) <= R19_MAX_OUTER_BYTES:
        raise ValueError("r19_outer_input_size")
    if R19_R17_OUTER_MARKER not in raw or b"inner-child-source-scope-r19.r1.v1" in raw:
        raise ValueError("r19_transform_input")
    if (
        type(helper_path) is not str or not ntpath.isabs(helper_path)
        or ntpath.normpath(helper_path) != helper_path or "\x00" in helper_path
        or type(helper_sha256) is not str or len(helper_sha256) != 64
        or any(char not in "0123456789abcdef" for char in helper_sha256)
        or type(helper_raw) is not bytes or not 0 < len(helper_raw) <= R19_MAX_SOURCE_BYTES
        or hashlib.sha256(helper_raw).hexdigest() != helper_sha256
        or type(support_template) is not bytes
    ):
        raise ValueError("r19_transform_input_shape")
    support = support_template
    for placeholder, replacement in {
        b"__R19_HELPER_PATH__": ascii(helper_path).encode("ascii"),
        b"__R19_HELPER_SHA256__": ascii(helper_sha256).encode("ascii"),
        b"__R19_HELPER_SOURCE_BYTES__": repr(helper_raw).encode("ascii"),
    }.items():
        if support.count(placeholder) != 1:
            raise ValueError("r19_support_placeholder")
        support = support.replace(placeholder, replacement, 1)

    old_rebuild = b"regenerated = _r17_rebuild_exact_active_outer(\n"
    new_rebuild = b"regenerated = _r19_rebuild_exact_active_outer(\n"
    if raw.count(old_rebuild) != 1:
        raise ValueError("r19_rebuild_anchor")
    result = raw.replace(old_rebuild, new_rebuild, 1)
    old_active_driver = b"            active_driver = held.get(str(Path(self_path)))\n"
    new_active_driver = b"            active_driver = _r13_exact_held(held, self_path)\n"
    if result.count(old_active_driver) != 1:
        raise ValueError("r19_active_driver_held_anchor")
    result = result.replace(old_active_driver, new_active_driver, 1)
    old_plan = b"            plan_held = held.get(str(Path(PLAN_PATH)))\n"
    new_plan = b"            plan_held = _r13_exact_held(held, str(PLAN_PATH))\n"
    if result.count(old_plan) != 1:
        raise ValueError("r19_plan_held_anchor")
    result = result.replace(old_plan, new_plan, 1)
    old_scope = b"        with custody.held_public_sources(public, software) as (private, cli, held):\n"
    new_scope = (
        b"        with _r19_held_public_sources(\n"
        b"            custody, public, software, self_path, self_sha256, plan_raw\n"
        b"        ) as (private, cli, held):\n"
    )
    if result.count(old_scope) != 1:
        raise ValueError("r19_child_scope_anchor")
    result = result.replace(old_scope, new_scope, 1)
    support_anchor = b"def run_prelaunch(\n"
    if result.count(support_anchor) != 1:
        raise ValueError("r19_support_insertion_anchor")
    result = result.replace(support_anchor, support + support_anchor, 1)
    if (
        len(result) > R19_MAX_OUTER_BYTES
        or result.count(new_rebuild) != 1
        or result.count(old_rebuild) != 0
        or result.count(new_active_driver) != 1
        or result.count(old_active_driver) != 0
        or result.count(new_plan) != 1
        or result.count(old_plan) != 0
        or result.count(new_scope) != 1
        or b"inner-child-source-scope-r19.r1.v1" not in result
    ):
        raise ValueError("r19_transformed_outer_contract")
    try:
        compile(result, "<r19-transformed-active-outer>", "exec", dont_inherit=True)
    except BaseException:
        raise ValueError("r19_transformed_outer_compile") from None
    return result


_ORIGINAL_R13_COMPOSE = _R13._compose
_ORIGINAL_R13_ACTIVE_OUTER_SOURCE = _R13._active_outer_source
_ORIGINAL_R17_APPLY = _R17._apply_active_outer_transform
_ORIGINAL_R17_RUNTIME_MAP_PATH = _R17._runtime_source_map_path
_ORIGINAL_R17_ADD_HOLD_ROW = _R17._add_r17_hold_row
_ORIGINAL_R17_VERIFY_SOURCE_PINS = _R17._verify_source_pins
_ORIGINAL_R16_PREPARE = _R17._ORIGINAL_R16_PREPARE


@dataclasses.dataclass(frozen=True)
class R19RootPreparedHold:
    """R17 composite with the R19 source row and child-scope transform."""

    schema: str
    r17_result: Any
    r19_helper_path: str
    r19_helper_bytes: bytes
    r19_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def prepared_r13(self) -> Any:
        return self.r17_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r17_result.prepared_r14

    @property
    def runtime_source_map_path(self) -> str:
        return self.r17_result.runtime_source_map_path

    @property
    def runtime_source_map_sha256(self) -> str:
        return self.r17_result.runtime_source_map_sha256


def _verify_sources(r17_source, r18_source, r19_source) -> None:
    _check(_R13._compose is _ORIGINAL_R13_COMPOSE, "r19_r13_source_pin")
    _check(
        _R13._active_outer_source is _ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
        "r19_r13_source_pin",
    )
    _check(_R17._apply_active_outer_transform is _ORIGINAL_R17_APPLY,
           "r19_r17_function_identity")
    _check(_R17._runtime_source_map_path is _ORIGINAL_R17_RUNTIME_MAP_PATH,
           "r19_r17_function_identity")
    _check(_R17._add_r17_hold_row is _ORIGINAL_R17_ADD_HOLD_ROW,
           "r19_r17_function_identity")
    _check(_R17._verify_source_pins is _ORIGINAL_R17_VERIFY_SOURCE_PINS,
           "r19_r17_function_identity")
    _check(_R17._ORIGINAL_R16_PREPARE is _ORIGINAL_R16_PREPARE,
           "r19_r16_source_pin")
    _R17._verify_source_pins(r17_source)
    _check(type(r18_source) is tuple and r18_source[2] == R19_PINNED_R18_SHA256,
           "r19_r18_source_pin")
    _check(type(r19_source) is tuple and len(r19_source) == 3
           and _sha(r19_source[1]) == r19_source[2], "r19_source_binding")


def _add_r19_hold_row(r17_result: Any, r19_source: tuple[str, bytes, str]):
    path, raw, digest = r19_source
    _check(_R13._R10._R9._absolute_windows_path(path), "r19_hold_schema")
    _check(type(raw) is bytes and _sha(raw) == digest, "r19_source_binding")
    addition = copy.deepcopy(r17_result.hold_addition)
    entries = dict(addition.get("entries", {}))
    target = _R13._R10._R9._normalized(path)
    _check(
        all(_R13._R10._R9._normalized(existing) != target for existing in entries),
        "r19_hold_collision",
    )
    entries[path] = {
        "sha256": digest,
        "size_bytes": len(raw),
        "role": R19_SOURCE_ROLE,
        "origin": "repository_source:" + R19_RELATIVE_PATH,
    }
    addition["entries"] = dict(sorted(entries.items()))
    _check(
        addition.get("schema") == _R16._R15.R15_HOLD_SCHEMA
        and addition.get("canonical_child_map_count") == 154,
        "r19_hold_schema",
    )
    return addition, _sha(_canonical_json(addition))


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R19RootPreparedHold:
    """Run the exact R16 preparation under same-call R17 + R19 transforms."""
    global _R17
    r19_source = _self_source()
    r17_source = _R17._self_source()
    r18_source = _R18._self_source()
    _verify_sources(r17_source, r18_source, r19_source)
    if not _R17._PATCH_LOCK.acquire(blocking=False):
        raise ChildSourceScopeR19Blocked("r19_patch_context_busy")
    if _R17._PATCH_OWNER_THREAD is not None:
        _R17._PATCH_LOCK.release()
        raise ChildSourceScopeR19Blocked("r19_patch_context_changed")

    owner = threading.get_ident()
    _R17._PATCH_OWNER_THREAD = owner
    context: dict[str, Any] = {"source_map_path": None}
    original_compose = _R13._compose
    original_outer = _R13._active_outer_source
    wrappers_installed = False
    wrappers_intact = True
    result: Any = None
    operation_error: Optional[BaseException] = None

    try:
        _check(
            original_compose is _ORIGINAL_R13_COMPOSE
            and original_outer is _ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
            "r19_patch_context_changed",
        )

        def assert_owner() -> None:
            _check(
                _R17._PATCH_OWNER_THREAD == owner == threading.get_ident(),
                "r19_patch_owner_thread",
            )
            _check(
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper,
                "r19_patch_context_changed",
            )

        def compose_wrapper(base_r11: Any) -> Any:
            assert_owner()
            try:
                path = _R17._runtime_source_map_path(base_r11)
            except BaseException:
                raise ChildSourceScopeR19Blocked("r19_descriptor_rejected") from None
            previous = context["source_map_path"]
            _check(previous is None or previous == path, "r19_descriptor_input_changed")
            context["source_map_path"] = path
            return original_compose(base_r11)

        def outer_wrapper(*args: Any, **kwargs: Any) -> bytes:
            assert_owner()
            path = context.get("source_map_path")
            _check(type(path) is str, "r19_runtime_map_path_unbound")
            base_outer = original_outer(*args, **kwargs)
            try:
                r17_outer = _ORIGINAL_R17_APPLY(
                    base_outer,
                    path,
                    r17_source[0],
                    r17_source[2],
                    _R17._R17_OUTER_SUPPORT,
                )
                return _apply_active_outer_transform(
                    r17_outer,
                    r19_source[0],
                    r19_source[2],
                    r19_source[1],
                    _R19_OUTER_SUPPORT,
                )
            except BaseException:
                raise ChildSourceScopeR19Blocked("r19_active_outer_transform") from None

        _R13._compose = compose_wrapper
        _R13._active_outer_source = outer_wrapper
        wrappers_installed = True
        try:
            result = _ORIGINAL_R16_PREPARE(
                prepared_r31,
                root_metadata,
                environment=environment,
            )
        except BaseException as exc:
            operation_error = exc
    except BaseException as exc:
        operation_error = exc
    finally:
        if wrappers_installed:
            wrappers_intact = (
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper
            )
            _R13._compose = original_compose
            _R13._active_outer_source = original_outer
        _R17._PATCH_OWNER_THREAD = None
        _R17._PATCH_LOCK.release()

    if operation_error is not None:
        if isinstance(operation_error, ChildSourceScopeR19Blocked):
            raise operation_error
        if isinstance(operation_error, _R17.SourceMapGateR17Blocked):
            raise operation_error
        if isinstance(operation_error, _R16.FinalOutputHoldR16Blocked):
            raise operation_error
        raise ChildSourceScopeR19Blocked("r19_r16_composite_blocked") from None
    _check(wrappers_intact, "r19_patch_context_changed")
    runtime_map_path = context.get("source_map_path")
    _check(type(runtime_map_path) is str, "r19_runtime_map_path_unbound")
    _check(type(result) is _R16.R16RootPreparedHold, "r19_r16_result_type")

    try:
        r17_addition, r17_digest, runtime_map_sha = _ORIGINAL_R17_ADD_HOLD_ROW(
            result,
            r17_source[0],
            r17_source[1],
            r17_source[2],
            runtime_map_path,
        )
        r17_result = _R17.R17RootPreparedHold(
            schema=_R17.R17_RESULT_SCHEMA,
            r16_result=result,
            r17_helper_path=r17_source[0],
            r17_helper_bytes=r17_source[1],
            r17_helper_sha256=r17_source[2],
            runtime_source_map_path=runtime_map_path,
            runtime_source_map_sha256=runtime_map_sha,
            hold_addition=r17_addition,
            hold_addition_sha256=r17_digest,
        )
        _check(_R17.verify_hold_addition(r17_result), "r19_r17_result_binding")
        addition, addition_sha = _add_r19_hold_row(r17_result, r19_source)
    except ChildSourceScopeR19Blocked:
        raise
    except BaseException:
        raise ChildSourceScopeR19Blocked("r19_r17_result_binding") from None
    return R19RootPreparedHold(
        schema=R19_RESULT_SCHEMA,
        r17_result=r17_result,
        r19_helper_path=r19_source[0],
        r19_helper_bytes=r19_source[1],
        r19_helper_sha256=r19_source[2],
        hold_addition=addition,
        hold_addition_sha256=addition_sha,
    )


def verify_root_hold(value: Any) -> bool:
    try:
        if type(value) is not R19RootPreparedHold or value.schema != R19_RESULT_SCHEMA:
            return False
        source = _self_source()
        if (value.r19_helper_path, value.r19_helper_bytes, value.r19_helper_sha256) != source:
            return False
        if not _R17.verify_hold_addition(value.r17_result):
            return False
        addition, digest = _add_r19_hold_row(
            value.r17_result,
            (value.r19_helper_path, value.r19_helper_bytes, value.r19_helper_sha256),
        )
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False


@dataclasses.dataclass(frozen=True)
class R19ParentAdapterResult:
    """Real R14 adapter and the exact R18/R19 parent source rows."""

    schema: str
    prepared_hold: R19RootPreparedHold
    adapter: Any
    r18_helper_path: str
    r18_helper_bytes: bytes
    r18_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    r13_recompose_calls: int
    r13_outer_transform_calls: int
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def r17_result(self) -> Any:
        return self.prepared_hold.r17_result

    @property
    def prepared_r13(self) -> Any:
        return self.prepared_hold.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.prepared_hold.prepared_r14

    @property
    def r19_helper_path(self) -> str:
        return self.prepared_hold.r19_helper_path

    @property
    def r19_helper_bytes(self) -> bytes:
        return self.prepared_hold.r19_helper_bytes

    @property
    def r19_helper_sha256(self) -> str:
        return self.prepared_hold.r19_helper_sha256


def construct_parent_adapter(
    prepared_hold: Any,
    *,
    adapter_kwargs: Optional[dict[str, Any]] = None,
) -> R19ParentAdapterResult:
    """Recompose the exact R19 outer under the frozen real R14 constructor."""
    r19_source = _self_source()
    r18_source = _R18._self_source()
    r17_source = _R17._self_source()
    _verify_sources(r17_source, r18_source, r19_source)
    _check(verify_root_hold(prepared_hold), "r19_prepared_binding")
    r17_result = prepared_hold.r17_result
    try:
        _R18._validated_inputs(r17_result, r18_source)
    except BaseException:
        raise ChildSourceScopeR19Blocked("r19_prepared_binding") from None
    runtime_map_path = r17_result.runtime_source_map_path
    base_r11 = r17_result.prepared_r13.base_r11_prepared
    if not _R17._PATCH_LOCK.acquire(blocking=False):
        raise ChildSourceScopeR19Blocked("r19_patch_context_busy")

    owner = threading.get_ident()
    original_compose = _R13._compose
    original_outer = _R13._active_outer_source
    context: dict[str, Any] = {"runtime_map_path": None, "compose_calls": 0, "outer_calls": 0}
    wrappers_installed = False
    wrappers_intact = True
    adapter = None
    operation_error: Optional[BaseException] = None
    kwargs = dict(adapter_kwargs or {})

    try:
        _check(
            original_compose is _ORIGINAL_R13_COMPOSE
            and original_outer is _ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
            "r19_patch_context_changed",
        )

        def assert_owner() -> None:
            _check(
                threading.get_ident() == owner,
                "r19_patch_owner_thread",
            )
            _check(
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper,
                "r19_patch_context_changed",
            )

        def compose_wrapper(current_base_r11: Any) -> Any:
            assert_owner()
            current_path = _R17._runtime_source_map_path(current_base_r11)
            _check(current_path == runtime_map_path, "r19_descriptor_input_changed")
            previous = context["runtime_map_path"]
            _check(previous is None or previous == current_path, "r19_descriptor_input_changed")
            context["runtime_map_path"] = current_path
            context["compose_calls"] += 1
            return original_compose(current_base_r11)

        def outer_wrapper(*args: Any, **outer_kwargs: Any) -> bytes:
            assert_owner()
            _check(context["runtime_map_path"] == runtime_map_path, "r19_runtime_map_path_unbound")
            context["outer_calls"] += 1
            base_outer = original_outer(*args, **outer_kwargs)
            try:
                r17_outer = _ORIGINAL_R17_APPLY(
                    base_outer,
                    runtime_map_path,
                    r17_source[0],
                    r17_source[2],
                    _R17._R17_OUTER_SUPPORT,
                )
                return _apply_active_outer_transform(
                    r17_outer,
                    r19_source[0],
                    r19_source[2],
                    r19_source[1],
                    _R19_OUTER_SUPPORT,
                )
            except BaseException:
                raise ChildSourceScopeR19Blocked("r19_active_outer_transform") from None

        _R13._compose = compose_wrapper
        _R13._active_outer_source = outer_wrapper
        wrappers_installed = True
        try:
            adapter = _R14.M01WindowsParentAdapter(
                prepared_hold.prepared_r14,
                **kwargs,
            )
        except BaseException as exc:
            operation_error = exc
    except BaseException as exc:
        operation_error = exc
    finally:
        if wrappers_installed:
            wrappers_intact = (
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper
            )
            _R13._compose = original_compose
            _R13._active_outer_source = original_outer
        _R17._PATCH_LOCK.release()

    if operation_error is not None:
        if type(operation_error) is _R13.ActiveOuterActivationBlocked:
            raise operation_error
        if type(operation_error) is _R14.ParentAdapterTransportBlocked:
            raise operation_error
        if type(operation_error) is ChildSourceScopeR19Blocked:
            raise operation_error
        raise ChildSourceScopeR19Blocked("r19_r14_result") from None
    _check(wrappers_intact, "r19_patch_context_changed")
    _check(type(adapter) is _R14.M01WindowsParentAdapter, "r19_r14_result")
    _check(adapter.prepared is prepared_hold.prepared_r14, "r19_adapter_binding")
    _check(context["compose_calls"] == 1, "r19_recompose_count")
    _check(context["outer_calls"] == 1, "r19_outer_transform_count")

    try:
        addition, _r18_digest = _R18._r18_add_hold_row(r17_result, r18_source)
        entries = dict(addition.get("entries", {}))
        entries[prepared_hold.r19_helper_path] = {
            "sha256": prepared_hold.r19_helper_sha256,
            "size_bytes": len(prepared_hold.r19_helper_bytes),
            "role": R19_SOURCE_ROLE,
            "origin": "repository_source:" + R19_RELATIVE_PATH,
        }
        addition["entries"] = dict(sorted(entries.items()))
        hold_digest = _sha(_canonical_json(addition))
        _check(
            addition.get("schema") == _R16._R15.R15_HOLD_SCHEMA
            and addition.get("canonical_child_map_count") == 154,
            "r19_hold_schema",
        )
    except ChildSourceScopeR19Blocked:
        raise
    except BaseException:
        raise ChildSourceScopeR19Blocked("r19_hold_digest") from None
    result = R19ParentAdapterResult(
        schema=R19_ADAPTER_RESULT_SCHEMA,
        prepared_hold=prepared_hold,
        adapter=adapter,
        r18_helper_path=r18_source[0],
        r18_helper_bytes=r18_source[1],
        r18_helper_sha256=r18_source[2],
        hold_addition=addition,
        hold_addition_sha256=hold_digest,
        r13_recompose_calls=context["compose_calls"],
        r13_outer_transform_calls=context["outer_calls"],
    )
    _check(verify_parent_adapter_result(result), "r19_hold_digest")
    return result


def verify_parent_adapter_result(value: Any) -> bool:
    """Freshly verify R17/R18/R19 pins, R14 adapter, and final hold digest."""
    try:
        if type(value) is not R19ParentAdapterResult or value.schema != R19_ADAPTER_RESULT_SCHEMA:
            return False
        if not verify_root_hold(value.prepared_hold):
            return False
        r19_source = _self_source()
        r18_source = _R18._self_source()
        r17_source = _R17._self_source()
        _verify_sources(r17_source, r18_source, r19_source)
        if (value.r18_helper_path, value.r18_helper_bytes, value.r18_helper_sha256) != r18_source:
            return False
        if type(value.adapter) is not _R14.M01WindowsParentAdapter:
            return False
        if value.adapter.prepared is not value.prepared_r14:
            return False
        if value.r13_recompose_calls != 1 or value.r13_outer_transform_calls != 1:
            return False
        if _sha(_canonical_json(value.hold_addition)) != value.hold_addition_sha256:
            return False
        expected, _digest = _R18._r18_add_hold_row(value.r17_result, r18_source)
        entries = dict(expected.get("entries", {}))
        entries[value.r19_helper_path] = {
            "sha256": value.r19_helper_sha256,
            "size_bytes": len(value.r19_helper_bytes),
            "role": R19_SOURCE_ROLE,
            "origin": "repository_source:" + R19_RELATIVE_PATH,
        }
        expected["entries"] = dict(sorted(entries.items()))
        if value.hold_addition != expected:
            return False
        return value.hold_addition.get("canonical_child_map_count") == 154
    except BaseException:
        return False

