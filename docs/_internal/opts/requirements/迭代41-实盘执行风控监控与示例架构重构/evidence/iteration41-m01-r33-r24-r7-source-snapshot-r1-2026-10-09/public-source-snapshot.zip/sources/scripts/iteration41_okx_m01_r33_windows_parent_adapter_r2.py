"""R33 source-bound external-parent adapter for the M01 startup runner.

The checked-in adapter keeps native execution disabled. It binds the fixed
child bootstrap to an actual R31 preparation object, its canonical 154-row
map, the generated runner bytes, the public CUv2 snapshot, and the unchanged
inner budgets. Tests may inject bottom-level fake leaves, but fake mode can
never open the real gate or produce a readiness/certification result.

Job assignment and descriptor write/flush/close share the remaining parent
active deadline. If a pipe operation outlives it, pending operations prevent
the adapter from claiming that pipes or the Job are closed.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import math
import ntpath
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional


ROOT_REAL_ADAPTER_ENABLED = False
RESULT_SCHEMA = "iteration41.okx.m01.r33.windows-parent-adapter-result.v1"
ROOT_METADATA_SCHEMA = "iteration41.okx.m01.r33.root-owned-bootstrap-metadata.v1"
SOURCE_MAP_SCHEMA = "iteration41.okx.m01.r33.public-source-map.v1"
BOOTSTRAP_SCHEMA = "iteration41.okx.m01.r33.child-launch-descriptor.v1"
FIXED_EXECUTABLE = "C:/anaconda3/python.exe"
CUV2_PUBLIC_SOURCE_SHA256 = "e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246"
R31_HELPER_SHA256 = "c95f72c6d168352893339bad5f53e5f48e5b201219a30de8b2de6d90f50e441a"
R32_HELPER_SHA256 = "5f9986146991188be4f0121e754c0a1e231e90700d167fe265464154cab8af1e"
JOB_LAUNCHER_SHA256 = "0b8076f4cd8aa4419a29a0bbc3f1884e24c2610e2ba5b6cf2000c0cdf861c023"
IMAGE_OBSERVER_SHA256 = "3f14b2771a73e056b7902f48f65bfebbf17e93a62202a55f66de6ac3ff12d0cc"
CHILD_BOOTSTRAP_SHA256 = "0cea3ea9331fa5fc132ddf0924084d413b051d005effb7fe9664a23870670ee0"
MAX_DESCRIPTOR_BYTES = 4096
MAX_SOURCE_MAP_BYTES = 1024 * 1024
MAX_STDOUT_BYTES = 128 * 1024
MAX_STDERR_BYTES = 128 * 1024
CREATE_SUSPENDED = 0x00000004
_SAFE_ENV_KEYS = frozenset({"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "TEMP", "TMP"})
_NAMESPACE_KEYS = frozenset(
    {
        "control_dir",
        "deployment_dir",
        "plan_path",
        "self_path",
        "active_wrapper_path",
        "attempt_claim_path",
    }
)
_HEX = frozenset("0123456789abcdef")
_MISSING = object()


class ParentAdapterBlocked(ValueError):
    """A source binding, injected leaf, or bounded operation failed."""


def _check(value: Any, code: str) -> None:
    if not value:
        raise ParentAdapterBlocked(code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _is_sha(value: Any) -> bool:
    return (
        type(value) is str
        and len(value) == 64
        and all(character in _HEX for character in value)
    )


def _canonical_json(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("ascii")
    except BaseException:
        raise ParentAdapterBlocked("canonical_json_invalid") from None


def _absolute_windows_path(value: Any) -> bool:
    return (
        type(value) is str
        and 0 < len(value) <= 32767
        and "\x00" not in value
        and ntpath.isabs(value)
    )


def _module_source(module: Any, expected_sha256: str) -> bytes:
    path = getattr(module, "__file__", None)
    _check(_absolute_windows_path(path), "module_path_invalid")
    try:
        raw = Path(path).read_bytes()
    except BaseException:
        raise ParentAdapterBlocked("module_source_unavailable") from None
    _check(_sha(raw) == expected_sha256, "module_source_pin_mismatch")
    return raw


def _load_public_modules():
    try:
        r31 = importlib.import_module("scripts.iteration41_okx_m01_r31_root_startup_prepare_r1")
        r32 = importlib.import_module("scripts.iteration41_okx_m01_r32_external_parent_budget_r1")
        launcher = importlib.import_module("scripts.iteration41_okx_l03_l04_v4_root_launcher")
        image = importlib.import_module("scripts.iteration41_suspended_child_image_r2")
        bootstrap = importlib.import_module("scripts.iteration41_okx_m01_r33_child_bootstrap_r1")
    except BaseException:
        raise ParentAdapterBlocked("public_dependency_unavailable") from None
    _module_source(r31, R31_HELPER_SHA256)
    _module_source(r32, R32_HELPER_SHA256)
    _module_source(launcher, JOB_LAUNCHER_SHA256)
    _module_source(image, IMAGE_OBSERVER_SHA256)
    bootstrap_raw = _module_source(bootstrap, CHILD_BOOTSTRAP_SHA256)
    _check(
        getattr(bootstrap, "BOOTSTRAP_SCHEMA", None) == BOOTSTRAP_SCHEMA
        and getattr(bootstrap, "CUV2_PUBLIC_SOURCE_SHA256", None)
        == CUV2_PUBLIC_SOURCE_SHA256,
        "bootstrap_source_contract",
    )
    return r31, r32, launcher, image, bootstrap, bootstrap_raw


def _literal_assignment(raw: bytes, name: str) -> Any:
    import ast

    try:
        tree = ast.parse(raw.decode("utf-8"))
    except BaseException:
        raise ParentAdapterBlocked("generated_source_invalid") from None
    values = []
    for node in tree.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == name
            and isinstance(node.value, ast.Constant)
        ):
            values.append(node.value.value)
    _check(len(values) == 1, "generated_source_flag_missing")
    return values[0]


def _normalized_path(value: str) -> str:
    return ntpath.normcase(ntpath.normpath(value))


def _pin_for_path(pin_map: dict, path: str) -> Optional[str]:
    target = _normalized_path(path)
    matches = [digest for key, digest in pin_map.items() if _normalized_path(key) == target]
    return matches[0] if len(matches) == 1 else None


def _validate_prepared(prepared: Any, r31: Any) -> dict[str, Any]:
    _check(type(prepared) is dict, "prepared_result_shape")
    _check(prepared.get("status") == "SOURCE_FAKE_ONLY_DISABLED", "prepared_status")
    manifest = prepared.get("manifest")
    _check(type(manifest) is dict, "prepared_manifest_shape")
    try:
        public_pins, software_pins = r31.scope_maps(manifest)
    except BaseException:
        raise ParentAdapterBlocked("prepared_manifest_rejected") from None
    canonical = manifest.get("canonical_pins")
    root = manifest.get("root")
    _check(_absolute_windows_path(root), "prepared_root_path")
    _check(public_pins == prepared.get("public_pins"), "prepared_public_map_mismatch")
    _check(software_pins == prepared.get("software_pins"), "prepared_software_map_mismatch")
    _check(type(canonical) is dict and canonical == prepared.get("canonical_pins"), "prepared_canonical_map_mismatch")
    _check(len(public_pins) == 118 and len(software_pins) == 36 and len(canonical) == 154, "prepared_map_counts")
    projected = {
        _normalized_path(ntpath.join(root, path)): digest
        for path, digest in public_pins.items()
    }
    projected.update({_normalized_path(path): digest for path, digest in software_pins.items()})
    normalized_canonical = {_normalized_path(path): digest for path, digest in canonical.items()}
    _check(len(projected) == 154 and projected == normalized_canonical, "prepared_map_projection")
    namespace = manifest.get("runtime_namespace")
    _check(
        type(namespace) is dict
        and frozenset(namespace) == _NAMESPACE_KEYS
        and all(_absolute_windows_path(value) for value in namespace.values()),
        "prepared_namespace",
    )
    outer = prepared.get("active_outer_source")
    wrapper = prepared.get("active_wrapper_source")
    runner = prepared.get("runner_template_source")
    _check(type(outer) is bytes and type(wrapper) is bytes and type(runner) is bytes, "prepared_source_bytes")
    _check(_pin_for_path(canonical, namespace["self_path"]) == _sha(outer), "prepared_outer_pin")
    _check(_pin_for_path(canonical, namespace["active_wrapper_path"]) == _sha(wrapper), "prepared_wrapper_pin")
    _check(_sha(runner) == prepared.get("runner_template_sha256"), "prepared_runner_pin")
    _check(_literal_assignment(runner, "ROOT_RUNNER_ENABLED") is False, "prepared_runner_not_disabled")
    _check(_literal_assignment(outer, "ROOT_PRELAUNCH_ENABLED") is True, "prepared_outer_prelaunch_shape")
    _check(_literal_assignment(wrapper, "ROOT_ACTUAL_ENABLED") is True, "prepared_wrapper_diagnostic_shape")
    _check(
        manifest.get("once", {}).get("child_timeout_seconds") == 180
        and manifest.get("once", {}).get("child_cleanup_timeout_seconds") == 5
        and manifest.get("once", {}).get("spawn_total_budget_seconds") == 5
        and manifest.get("once", {}).get("parse_allowed") is False,
        "inner_budget_binding",
    )
    _check(
        manifest.get("outer_timeouts")
        == {
            "capture_seconds": 405,
            "cleanup_seconds": 5,
            "external_parent_envelope_seconds": None,
            "external_parent_envelope_established": False,
        },
        "outer_budget_binding",
    )
    safety = manifest.get("safety")
    _check(
        type(safety) is dict
        and safety.get("provider_request") is False
        and safety.get("account_access") is False
        and safety.get("candidate_activation_performed") is False
        and safety.get("external_parent_supervision_established") is False,
        "prepared_safety_binding",
    )
    binding = manifest.get("manifest_binding_sha256")
    _check(_is_sha(binding), "prepared_manifest_binding")
    plan_path = namespace["plan_path"]
    plan_sha = _pin_for_path(canonical, plan_path)
    _check(_is_sha(plan_sha), "prepared_plan_pin")
    runner_schema = manifest.get("runner_template_schema")
    _check(type(runner_schema) is str and runner_schema.startswith("iteration41.okx.m01.v6.root-startup-runner-template.r31."), "prepared_runner_schema")
    return {
        "manifest": manifest,
        "root": root,
        "public_pins": dict(public_pins),
        "software_pins": dict(software_pins),
        "canonical_pins": canonical,
        "runtime_namespace": dict(namespace),
        "active_outer_source": outer,
        "active_wrapper_source": wrapper,
        "runner_template_source": runner,
        "runner_template_sha256": _sha(runner),
        "runner_template_schema": runner_schema,
        "manifest_binding_sha256": binding,
        "plan_sha256": plan_sha,
    }


@dataclass(frozen=True)
class PreparedM01Child:
    """Exact command and bounded stdin metadata derived from R31 bytes."""

    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    stdin_descriptor: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    bootstrap_bytes: bytes
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Build a fixed `python -I -S -B -X utf8 -c` child descriptor.

    `root_metadata` contains Root-supplied CUv2 identity and plan disposition;
    the physical metadata must still be authenticated by the callback passed to
    `M01WindowsParentAdapter` before any process is created.
    """
    r31, _r32, _launcher, _image, bootstrap, bootstrap_raw = _load_public_modules()
    _check(
        type(root_metadata) is dict
        and frozenset(root_metadata)
        == frozenset({"schema", "cuv2_path", "cuv2_sha256", "owner_image_path", "plan_disposition"}),
        "root_metadata_shape",
    )
    _check(root_metadata.get("schema") == ROOT_METADATA_SCHEMA, "root_metadata_schema")
    _check(_absolute_windows_path(root_metadata.get("cuv2_path")), "root_cuv2_path")
    _check(root_metadata.get("cuv2_sha256") == CUV2_PUBLIC_SOURCE_SHA256, "root_cuv2_sha")
    _check(_absolute_windows_path(root_metadata.get("owner_image_path")), "root_owner_image")
    _check(
        _normalized_path(root_metadata["owner_image_path"])
        == _normalized_path(FIXED_EXECUTABLE),
        "root_owner_image",
    )
    _check(root_metadata.get("plan_disposition") in {"NON_ACTUAL_PLAN", "READY_TO_RUN"}, "root_plan_disposition")
    parts = _validate_prepared(prepared_r31, r31)
    namespace = parts["runtime_namespace"]
    root_dir = parts["root"]
    _check(_absolute_windows_path(root_dir), "prepared_root_path")
    control_dir = namespace["control_dir"]
    runner_path = ntpath.join(control_dir, "root_runner_template_r31.py")
    source_map_path = ntpath.join(control_dir, "root_public_source_map_r33.json")
    source_map_document = {
        "schema": SOURCE_MAP_SCHEMA,
        "public_pins": dict(sorted(parts["public_pins"].items())),
        "software_pins": dict(sorted(parts["software_pins"].items())),
        "canonical_pins": dict(sorted(parts["canonical_pins"].items())),
        "map_counts": {"public": 118, "software": 36, "canonical": 154},
        "root": parts["root"],
        "runtime_namespace": namespace,
        "runner_template_sha256": parts["runner_template_sha256"],
        "runner_template_schema": parts["runner_template_schema"],
        "manifest_binding_sha256": parts["manifest_binding_sha256"],
        "plan_sha256": parts["plan_sha256"],
        "plan_disposition": root_metadata["plan_disposition"],
    }
    source_map_bytes = _canonical_json(source_map_document)
    _check(len(source_map_bytes) <= MAX_SOURCE_MAP_BYTES, "source_map_size")
    budgets = {
        "parent_seconds": 100,
        "parent_cleanup_seconds": 5,
        "once_child_seconds": 180,
        "once_cleanup_seconds": 5,
        "outer_capture_seconds": 405,
        "outer_cleanup_seconds": 5,
    }
    descriptor = {
        "schema": BOOTSTRAP_SCHEMA,
        "runner_path": runner_path,
        "runner_sha256": parts["runner_template_sha256"],
        "runner_template_schema": parts["runner_template_schema"],
        "manifest_binding_sha256": parts["manifest_binding_sha256"],
        "root": parts["root"],
        "source_map_path": source_map_path,
        "source_map_sha256": _sha(source_map_bytes),
        "cuv2_path": root_metadata["cuv2_path"],
        "cuv2_sha256": root_metadata["cuv2_sha256"],
        "runtime_namespace": namespace,
        "plan_disposition": root_metadata["plan_disposition"],
        "budgets": budgets,
    }
    from_bootstrap = bootstrap._validate_descriptor(
        _canonical_json(descriptor)
    )
    _check(from_bootstrap == descriptor, "descriptor_roundtrip")
    descriptor_bytes = _canonical_json(descriptor)
    _check(len(descriptor_bytes) <= MAX_DESCRIPTOR_BYTES, "descriptor_size")
    _check(bootstrap_raw and _sha(bootstrap_raw) == _sha(Path(bootstrap.__file__).read_bytes()), "bootstrap_digest")
    command = (
        FIXED_EXECUTABLE,
        "-I",
        "-S",
        "-B",
        "-X",
        "utf8",
        "-c",
        bootstrap_raw.decode("utf-8"),
    )
    _check(sum(len(part) + 1 for part in command) < 32767, "command_line_size")
    if environment is None:
        env = {}
    else:
        _check(type(environment) is dict, "environment_shape")
        _check(set(environment).issubset(_SAFE_ENV_KEYS), "environment_key")
        _check(
            all(
                type(key) is str
                and type(value) is str
                and "\x00" not in key
                and "\x00" not in value
                and len(key) <= 128
                and len(value) <= 32767
                for key, value in environment.items()
            ),
            "environment_value_shape",
        )
        env = dict(environment)
    binding = {
        "schema": "iteration41.okx.m01.r33.prepared-child-binding.v1",
        "owner_image_path": FIXED_EXECUTABLE,
        "cuv2_path": descriptor["cuv2_path"],
        "source_map_sha256": descriptor["source_map_sha256"],
        "source_map_path": descriptor["source_map_path"],
        "runner_sha256": descriptor["runner_sha256"],
        "runner_path": descriptor["runner_path"],
        "bootstrap_sha256": _sha(bootstrap_raw),
        "cuv2_sha256": descriptor["cuv2_sha256"],
        "manifest_binding_sha256": parts["manifest_binding_sha256"],
        "root": parts["root"],
        "runtime_namespace": dict(namespace),
        "plan_sha256": parts["plan_sha256"],
        "plan_disposition": root_metadata["plan_disposition"],
        "source_map_counts": {"public": 118, "software": 36, "canonical": 154},
        "budgets": budgets,
    }
    binding_sha = _sha(_canonical_json({"binding": binding, "command": list(command[:-1]) + [_sha(command[-1].encode("utf-8"))], "cwd": root_dir}))
    return PreparedM01Child(
        command=command,
        cwd=root_dir,
        environment=env,
        stdin_descriptor=descriptor_bytes,
        source_map_bytes=source_map_bytes,
        runner_bytes=parts["runner_template_source"],
        bootstrap_bytes=bootstrap_raw,
        binding=binding,
        binding_sha256=binding_sha,
        plan_disposition=root_metadata["plan_disposition"],
    )


def _valid_timeout(value: Any, maximum: float) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(float(value)) and 0.0 < float(value) <= maximum
    except (OverflowError, ValueError):
        return False


def _bounded_call(
    function: Callable[[], Any], timeout: float, *, session: Any = None
) -> Any:
    """Run a potentially blocking process/native/pipe leaf on a daemon worker."""
    done = threading.Event()
    state: dict[str, Any] = {}
    pending_lock = getattr(session, "pending_lock", None)
    if pending_lock is not None:
        with pending_lock:
            session.pending_operations += 1

    def run():
        try:
            state["value"] = function()
        except BaseException:
            state["failed"] = True
        finally:
            if pending_lock is not None:
                with pending_lock:
                    session.pending_operations -= 1
            done.set()

    started = False
    try:
        worker = threading.Thread(target=run, name="m01-r33-bounded-leaf", daemon=True)
        worker.start()
        started = True
        if not done.wait(timeout):
            return _MISSING
    except BaseException:
        if pending_lock is not None and not started:
            with pending_lock:
                session.pending_operations -= 1
        return _MISSING
    if state.get("failed") is True:
        return _MISSING
    return state.get("value", _MISSING)


class _BoundedDrain:
    """Continuously drain one pipe while keeping only a fixed prefix."""

    def __init__(self, stream: Any, maximum: int, name: str):
        self.stream = stream
        self.maximum = maximum
        self.data = bytearray()
        self.eof = False
        self.overflow = False
        self.failed = False
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self._run, name=name, daemon=True)

    def start(self) -> None:
        self.thread.start()

    def _run(self) -> None:
        try:
            while True:
                chunk = self.stream.read(8192)
                if type(chunk) is not bytes:
                    with self.lock:
                        self.failed = True
                    return
                if not chunk:
                    with self.lock:
                        self.eof = True
                    return
                with self.lock:
                    remaining = self.maximum - len(self.data)
                    if remaining > 0:
                        self.data.extend(chunk[:remaining])
                    if len(chunk) > remaining:
                        self.overflow = True
        except BaseException:
            with self.lock:
                self.failed = True

    def snapshot(self) -> tuple[bytes, bool, bool, bool]:
        with self.lock:
            return bytes(self.data), self.eof, self.overflow, self.failed


@dataclass
class _Session:
    job: Any
    process: Any
    native: Any
    stdout_drain: _BoundedDrain
    stderr_drain: _BoundedDrain
    assigned: bool = False
    job_policy_verified: bool = False
    target_verified: bool = False
    resume_attempted: bool = False
    resumed: bool = False
    launch_error: bool = False
    stdin_descriptor_written: bool = False
    stdin_closed: bool = False
    terminated: bool = False
    pipes_are_closed: bool = False
    job_is_closed: bool = False
    returncode: Optional[int] = None
    assignment_attempted: bool = False
    pending_operations: int = 0
    pending_lock: Any = field(default_factory=threading.Lock, repr=False)


class M01WindowsParentAdapter:
    """Pinned Job/image adapter implementing the R32 parent-session protocol."""

    def __init__(
        self,
        prepared_child: PreparedM01Child,
        *,
        scope_authenticator: Callable[[Any, dict[str, Any], float], Any],
        fake_leaves: bool = False,
        native: Any = None,
        process_factory: Optional[Callable[..., Any]] = None,
        launcher_module: Any = None,
        image_module: Any = None,
        clock: Callable[[], Any] = time.monotonic,
        sleeper: Callable[[float], Any] = time.sleep,
    ):
        _check(type(prepared_child) is PreparedM01Child, "prepared_child_type")
        _check(callable(scope_authenticator), "scope_authenticator_required")
        _check(type(fake_leaves) is bool, "fake_mode_shape")
        _check(callable(clock) and callable(sleeper), "clock_contract")
        _r31, self._r32, default_launcher, default_image, bootstrap, raw = _load_public_modules()
        self.launcher = default_launcher if launcher_module is None else launcher_module
        self.image = default_image if image_module is None else image_module
        _module_source(self.launcher, JOB_LAUNCHER_SHA256)
        _module_source(self.image, IMAGE_OBSERVER_SHA256)
        self._bootstrap = bootstrap
        self._bootstrap_raw = raw
        self.prepared = prepared_child
        self.scope_authenticator = scope_authenticator
        self.fake_leaves = fake_leaves
        self.native = native
        self.process_factory = process_factory
        self.clock = clock
        self.sleeper = sleeper
        self._owner_thread = threading.get_ident()
        self._scope_authenticated = False
        self._retained_late: list[Any] = []
        self._job_policy_source_proof = self._verify_job_policy_source()
        if fake_leaves:
            _check(native is not None and callable(process_factory), "fake_leaves_incomplete")
        else:
            _check(native is None and process_factory is None, "real_leaf_injection_rejected")

    def _verify_job_policy_source(self) -> bool:
        raw = _module_source(self.launcher, JOB_LAUNCHER_SHA256)
        import ast

        try:
            tree = ast.parse(raw.decode("utf-8"))
        except BaseException:
            return False
        classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "_WinJobNative"]
        if len(classes) != 1:
            return False
        methods = [node for node in classes[0].body if isinstance(node, ast.FunctionDef) and node.name == "create_job"]
        if len(methods) != 1:
            return False
        has_kill_close = any(
            isinstance(node, ast.Assign)
            and isinstance(node.value, ast.Constant)
            and node.value.value == 0x2000
            and any(isinstance(target, ast.Attribute) and target.attr == "limit_flags" for target in node.targets)
            for node in ast.walk(methods[0])
        )
        has_apply = any(
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "SetInformationJobObject"
            for node in ast.walk(methods[0])
        )
        return has_kill_close and has_apply

    def verify_source_scope(self, source_scope: Any, timeout_seconds: float) -> bool:
        if (
            threading.get_ident() != self._owner_thread
            or not _valid_timeout(timeout_seconds, 100.0)
            or self.prepared.plan_disposition != "READY_TO_RUN"
            and ROOT_REAL_ADAPTER_ENABLED is True
        ):
            return False
        try:
            accepted = self.scope_authenticator(
                source_scope, dict(self.prepared.binding), float(timeout_seconds)
            )
        except BaseException:
            accepted = False
        self._scope_authenticated = type(accepted) is bool and accepted
        return self._scope_authenticated

    def supervise(
        self,
        source_scope: Any,
        release_source_scope: Callable[[Any, float], Any],
        *,
        retention_registry: Any = None,
    ):
        _check(callable(release_source_scope), "scope_release_required")
        args = {}
        if retention_registry is not None:
            args["retention_registry"] = retention_registry
        return self._r32.supervise_external_parent(
            self,
            source_scope,
            self.verify_source_scope,
            release_source_scope,
            clock=self.clock,
            sleeper=self.sleeper,
            **args,
        )

    def summarize_result(self, result: Any) -> dict[str, Any]:
        """Expose fixed supervision facts, never child payload or case outcome."""
        if type(result) is not self._r32.ParentEnvelopeResult:
            raise ParentAdapterBlocked("parent_result_type")
        return {
            "schema": result.schema,
            "status": result.status,
            "reason": result.reason,
            "cleanup_reason": result.cleanup_reason,
            "child_returncode": result.child_returncode,
            "capture_complete": result.capture_complete,
            "cleanup_complete": result.cleanup_complete,
            "scope_released": result.scope_released,
            "scope_retained": result.scope_retained,
            "stdout_bytes": len(result.stdout),
            "stderr_bytes": len(result.stderr),
            "authority": False,
            "strict_cases_passed": 0,
        }

    def _new_native(self):
        if self.fake_leaves:
            return self.native
        if ROOT_REAL_ADAPTER_ENABLED is not True or self.prepared.plan_disposition != "READY_TO_RUN":
            return None
        if not self._scope_authenticated:
            return None
        try:
            return self.launcher._WinJobNative()
        except BaseException:
            return None

    def launch_suspended(self, timeout_seconds: float):
        if not _valid_timeout(timeout_seconds, 100.0):
            return None
        if not self.fake_leaves and ROOT_REAL_ADAPTER_ENABLED is not True:
            return None
        if not self.fake_leaves and (
            self.prepared.plan_disposition != "READY_TO_RUN" or not self._scope_authenticated
        ):
            return None
        native = self._new_native()
        if native is None:
            return None
        state: dict[str, Any] = {}
        lock = threading.Lock()
        expired = threading.Event()
        finished = threading.Event()

        def create_session():
            job = None
            process = None
            try:
                job = self.launcher._WindowsProcessJob(native=native)
                factory = self.process_factory if self.fake_leaves else self.launcher.subprocess.Popen
                process = factory(
                    list(self.prepared.command),
                    cwd=self.prepared.cwd,
                    env=dict(self.prepared.environment),
                    stdin=self.launcher.subprocess.PIPE,
                    stdout=self.launcher.subprocess.PIPE,
                    stderr=self.launcher.subprocess.PIPE,
                    close_fds=True,
                    shell=False,
                    creationflags=CREATE_SUSPENDED,
                    bufsize=0,
                )
                _check(type(getattr(process, "pid", None)) is int and process.pid > 0, "process_pid")
                _check(getattr(process, "stdin", None) is not None, "process_stdin")
                _check(getattr(process, "stdout", None) is not None, "process_stdout")
                _check(getattr(process, "stderr", None) is not None, "process_stderr")
                stdout_drain = _BoundedDrain(process.stdout, MAX_STDOUT_BYTES, "m01-r33-stdout")
                stderr_drain = _BoundedDrain(process.stderr, MAX_STDERR_BYTES, "m01-r33-stderr")
                stdout_drain.start()
                stderr_drain.start()
                session = _Session(job, process, native, stdout_drain, stderr_drain)
                with lock:
                    if expired.is_set():
                        state["late"] = session
                    else:
                        state["session"] = session
                if expired.is_set():
                    self._late_cleanup(session)
            except BaseException:
                if job is not None:
                    try:
                        native.close(job._handle)
                    except BaseException:
                        self._retained_late.append(job)
                if process is not None:
                    self._retained_late.append(process)
                with lock:
                    state["failed"] = True
            finally:
                finished.set()

        try:
            worker = threading.Thread(target=create_session, name="m01-r33-launch", daemon=True)
            worker.start()
            if not finished.wait(float(timeout_seconds)):
                with lock:
                    session = state.get("session")
                    if session is None:
                        expired.set()
                        session = state.get("late")
                if session is not None:
                    self._late_cleanup(session)
                    return None
                return None
        except BaseException:
            return None
        with lock:
            return state.get("session")

    def _late_cleanup(self, session: _Session) -> None:
        """Try bounded cleanup for a launch that completed after its deadline."""
        self._retained_late.append(session)
        try:
            session.process.kill()
        except BaseException:
            pass
        try:
            session.process.wait(timeout=1.0)
        except BaseException:
            pass
        try:
            if session.process.stdin is not None and not session.process.stdin.closed:
                session.process.stdin.close()
        except BaseException:
            pass
        try:
            if session.job is not None and session.job._handle:
                session.native.close(session.job._handle)
                session.job_is_closed = True
                session.job._handle = None
        except BaseException:
            pass

    def assign_to_job(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 100.0) or session.launch_error:
            return False
        if session.assigned or session.job_is_closed:
            return False
        deadline = time.monotonic() + float(timeout_seconds)
        session.assignment_attempted = True
        result = _bounded_call(
            lambda: session.native.assign(session.job._handle, session.process),
            max(0.0, deadline - time.monotonic()),
            session=session,
        )
        if result is _MISSING:
            return False
        session.assigned = True
        try:
            payload = self.prepared.stdin_descriptor
            if len(payload) > MAX_DESCRIPTOR_BYTES:
                session.launch_error = True
                return False
            def write_descriptor() -> tuple[int, bool]:
                written = session.process.stdin.write(payload)
                if type(written) is not int or written != len(payload):
                    raise ParentAdapterBlocked("descriptor_write_incomplete")
                flush = getattr(session.process.stdin, "flush", None)
                if callable(flush):
                    flush()
                session.process.stdin.close()
                return written, getattr(session.process.stdin, "closed", False) is True

            remaining = deadline - time.monotonic()
            if remaining <= 0.0:
                session.launch_error = True
                return False
            written = _bounded_call(
                write_descriptor,
                remaining,
                session=session,
            )
            if written != (len(payload), True):
                session.launch_error = True
                return False
            session.stdin_descriptor_written = True
            session.stdin_closed = True
        except BaseException:
            session.launch_error = True
            return False
        return True

    def verify_job_policy(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 100.0):
            return False
        if not session.assigned or session.job_is_closed or not self._job_policy_source_proof:
            return False
        if not session.job._handle:
            return False
        session.job_policy_verified = True
        return True

    def verify_target(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 100.0):
            return False
        if (
            not session.assigned
            or not session.job_policy_verified
            or session.resume_attempted
            or not session.stdin_closed
        ):
            return False
        observer = getattr(self.image, "observe_suspended_child_image", None)
        if not callable(observer):
            return False
        observation = _bounded_call(lambda: observer(session.process), float(timeout_seconds))
        if type(observation) is not dict:
            return False
        expected = {
            "schema": "iteration41.suspended-child-image-observation.v2",
            "child_pid": session.process.pid,
            "fixed_executable_path_observed": True,
            "active_at_observation": True,
            "suspension_verified": False,
            "job_assignment_verified": False,
            "physical_image_custody_verified": False,
            "whole_command_g1": False,
            "strict_cases_passed": 0,
            "authority": False,
        }
        if observation != expected:
            return False
        session.target_verified = True
        return True

    def resume(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 100.0):
            return False
        if (
            not session.assigned
            or not session.job_policy_verified
            or not session.target_verified
            or session.resume_attempted
        ):
            return False
        session.resume_attempted = True
        result = _bounded_call(
            lambda: session.native.resume_initial_thread(session.process.pid),
            float(timeout_seconds),
        )
        if result is _MISSING:
            return False
        session.resumed = True
        return True

    def wait(self, session: _Session, timeout_seconds: float):
        if not _valid_timeout(timeout_seconds, 100.0):
            return None
        try:
            result = session.process.wait(timeout=float(timeout_seconds))
        except BaseException:
            return None
        if type(result) is int:
            session.returncode = result
        return result if type(result) is int else None

    def capture_bounded(
        self,
        session: _Session,
        timeout_seconds: float,
        max_stdout: int,
        max_stderr: int,
    ) -> tuple[bytes, bytes, bool]:
        if (
            not _valid_timeout(timeout_seconds, 105.0)
            or type(max_stdout) is not int
            or type(max_stderr) is not int
            or not 0 < max_stdout <= MAX_STDOUT_BYTES
            or not 0 < max_stderr <= MAX_STDERR_BYTES
        ):
            return b"", b"", False
        try:
            deadline = time.monotonic() + float(timeout_seconds)
            for drain in (session.stdout_drain, session.stderr_drain):
                drain.thread.join(max(0.0, deadline - time.monotonic()))
            out, out_eof, out_overflow, out_failed = session.stdout_drain.snapshot()
            err, err_eof, err_overflow, err_failed = session.stderr_drain.snapshot()
            complete = (
                out_eof
                and err_eof
                and not out_overflow
                and not err_overflow
                and not out_failed
                and not err_failed
                and not session.stdout_drain.thread.is_alive()
                and not session.stderr_drain.thread.is_alive()
            )
            return out[:max_stdout], err[:max_stderr], complete
        except BaseException:
            return b"", b"", False

    def is_reaped(self, session: _Session):
        result = _bounded_call(lambda: session.process.poll(), 0.5)
        if result is _MISSING:
            return None
        return type(result) is int

    def job_assigned(self, session: _Session) -> bool:
        if type(session.assigned) is not bool:
            return None
        # An AssignProcessToJobObject call that exceeded its deadline may
        # still complete late. Terminate the Job conservatively and retain it
        # if the operation does not settle before cleanup closes resources.
        return session.assigned or session.assignment_attempted

    def terminate_job(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 5.0) or not session.assigned or session.job_is_closed:
            return False
        result = _bounded_call(
            lambda: session.native.terminate(session.job._handle), float(timeout_seconds)
        )
        if result is _MISSING:
            return False
        session.terminated = True
        return True

    def terminate_process(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 5.0):
            return False
        result = _bounded_call(lambda: session.process.kill(), float(timeout_seconds))
        if result is _MISSING:
            return False
        session.terminated = True
        return True

    def active_process_count(self, session: _Session, timeout_seconds: float):
        if not _valid_timeout(timeout_seconds, 5.0) or session.job_is_closed:
            return None
        result = _bounded_call(
            lambda: session.native.active_processes(session.job._handle),
            float(timeout_seconds),
        )
        if type(result) is not int or result < 0:
            return None
        return result

    def close_pipes(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 5.0):
            return False
        deadline = time.monotonic() + float(timeout_seconds)
        for drain in (session.stdout_drain, session.stderr_drain):
            drain.thread.join(max(0.0, deadline - time.monotonic()))
        if session.stdout_drain.thread.is_alive() or session.stderr_drain.thread.is_alive():
            return False
        streams = (session.process.stdin, session.process.stdout, session.process.stderr)
        for stream in streams:
            if stream is not None and not getattr(stream, "closed", False):
                result = _bounded_call(
                    stream.close,
                    max(0.001, deadline - time.monotonic()),
                    session=session,
                )
                if result is _MISSING:
                    return False
        with session.pending_lock:
            if session.pending_operations != 0:
                return False
        session.pipes_are_closed = self.pipes_closed(session)
        return session.pipes_are_closed

    def pipes_closed(self, session: _Session) -> bool:
        try:
            return (
                all(
                    stream is None or getattr(stream, "closed", False) is True
                    for stream in (session.process.stdin, session.process.stdout, session.process.stderr)
                )
                and not session.stdout_drain.thread.is_alive()
                and not session.stderr_drain.thread.is_alive()
            )
        except BaseException:
            return False

    def close_job(self, session: _Session, timeout_seconds: float) -> bool:
        if not _valid_timeout(timeout_seconds, 5.0) or session.job_is_closed:
            return False
        if not session.job._handle:
            return False
        with session.pending_lock:
            if session.pending_operations != 0:
                return False
        result = _bounded_call(
            lambda: session.native.close(session.job._handle), float(timeout_seconds)
        )
        if result is _MISSING:
            return False
        session.job._handle = None
        session.job_is_closed = True
        return True

    def job_closed(self, session: _Session) -> bool:
        return session.job_is_closed is True and session.job._handle is None


