"""R7 finite result observation composed over the frozen R4/R6 source path.

The observer is inserted at the single R4 call to the generated runner's real
``_safe_result``. It never examines a rejected result: ``None`` is reported as
one fixed token. A validator-approved ``UNCERTAIN`` result is reduced to
ordinals from the exact embedded public manifest and a few bounded lifecycle
categories. The R6 phase frame and R32 parent limits remain unchanged.
"""

from __future__ import annotations

import ast
import dataclasses
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Callable, Optional

from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r6 as _R6


R4_FILENAME = "iteration41_okx_m01_r33_child_bootstrap_r4.py"
R4_SHA256 = "4fe4131a69e8a36e354b3bd4d7babba25ec2de9eeb52258336209dee6677b778"
R6_FILENAME = "iteration41_okx_m01_r33_windows_parent_adapter_r6.py"
R6_SHA256 = "cc12ad98a17275c5781be50314a1de6c9084603ffb7f0207d07218280a22b7aa"
RESULT_SCHEMA = "iteration41.okx.m01.r33.runner-result-observation.r7.r2.v1"
RESULT_PREFIX = b"M01R7:"
RESULT_MAX_BYTES = 32
MAX_RUNNER_BYTES = 4 * 1024 * 1024
MAX_REASON_COUNT = 256
MAX_PAIR_COUNT = 14
_ANCHOR = b"        safe_result = runner._safe_result(runner_result)\n"
_FINISH_ANCHOR = b"        phase_sink.finish()\n"
_MAIN_GUARD_ANCHOR = b"\nif __name__ == \"__main__\":\n"
_HEX2 = re.compile(rb"[0-9a-f]{2}\Z")
_HEX1 = re.compile(rb"[0-9a-e]\Z")


class ResultObserverBlocked(ValueError):
    """A pinned source or finite result-observation contract failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise ResultObserverBlocked(reason)


def _read_pinned(name: str, expected: str, maximum: int) -> bytes:
    path = Path(__file__).resolve().with_name(name)
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise ResultObserverBlocked("pinned_source_read") from None
    _check(0 < len(raw) <= maximum, "pinned_source_size")
    _check(_sha(raw) == expected, "pinned_source_digest")
    return raw


def _r4_source() -> bytes:
    return _read_pinned(R4_FILENAME, R4_SHA256, 64 * 1024)


def _r6_source() -> bytes:
    path = Path(_R6.__file__).resolve()
    _check(path.name == R6_FILENAME, "r6_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(MAX_RUNNER_BYTES + 1)
    except BaseException:
        raise ResultObserverBlocked("r6_source_read") from None
    _check(0 < len(raw) <= MAX_RUNNER_BYTES, "r6_source_size")
    _check(_sha(raw) == R6_SHA256, "r6_source_digest")
    return raw


_R6_SOURCE = _r6_source()


_RESULT_OBSERVER_SOURCE = r'''
def _r7_emit_result_frame(phase_sink, safe_result, runner):
    """Emit only a fixed rejection token or an approved finite projection."""
    if safe_result is None:
        frame = b"M01R7:N\n"
    elif type(safe_result) is dict and safe_result.get("disposition") == "UNCERTAIN":
        manifest = getattr(runner, "MANIFEST", None)
        once = manifest.get("once") if type(manifest) is dict else None
        reasons = once.get("allowed_result_reasons") if type(once) is dict else None
        pairs = once.get("inner_diagnostic_pairs") if type(once) is dict else None
        if (
            type(reasons) is not list
            or not reasons
            or len(reasons) > 256
            or any(type(item) is not str for item in reasons)
            or reasons != sorted(set(reasons))
            or type(pairs) is not list
            or len(pairs) > 14
            or any(type(item) is not list or len(item) != 2 or any(type(part) is not str for part in item) for item in pairs)
            or pairs != sorted(pairs)
            or len({tuple(item) for item in pairs}) != len(pairs)
        ):
            return
        reason = safe_result.get("reason")
        try:
            reason_index = reasons.index(reason)
        except (ValueError, TypeError):
            return
        stage = safe_result.get("inner_stage")
        code = safe_result.get("inner_code")
        if (stage, code) == (None, None):
            pair_index = 0
        else:
            try:
                pair_index = pairs.index([stage, code]) + 1
            except (ValueError, TypeError):
                return
        lifecycle = safe_result.get("lifecycle")
        if type(lifecycle) is not dict:
            return
        routes = lifecycle.get("route_invocations")
        native = lifecycle.get("native_operations")
        provider = lifecycle.get("provider_requests")
        bound = lifecycle.get("source_review_bound")
        route_code = "N" if routes is None else str(routes)
        native_code = "N" if native is None else ("0" if native == 0 else "P")
        provider_code = "N" if provider is None else ("1" if provider else "0")
        bound_code = "1" if bound is True else "0" if bound is False else None
        if (
            reason_index > 255
            or pair_index > 14
            or route_code not in {"N", "0", "1"}
            or native_code not in {"N", "0", "P"}
            or provider_code not in {"N", "0", "1"}
            or bound_code is None
        ):
            return
        body = ("U%02x%x%s%s%s%s" % (reason_index, pair_index, route_code, native_code, provider_code, bound_code)).encode("ascii")
        frame = b"M01R7:" + body + b"\n"
    else:
        return
    if len(frame) > 32:
        return
    stream = getattr(phase_sink, "_stream", None)
    if stream is None:
        return
    try:
        phase_sink._r7_result_frame = frame
    except BaseException:
        return


def _r7_write_pending_result_frame(phase_sink):
    """Append the one pending frame only after the R6 phase line is closed."""
    frame = getattr(phase_sink, "_r7_result_frame", None)
    if (
        type(frame) is not bytes
        or len(frame) > 32
        or getattr(phase_sink, "_closed", False) is not True
        or getattr(phase_sink, "_broken", True) is not False
    ):
        return
    stream = getattr(phase_sink, "_stream", None)
    if stream is None:
        return
    try:
        stream.write(frame)
        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()
    except BaseException:
        try:
            phase_sink._broken = True
        except BaseException:
            return
'''.lstrip()


def compose_bootstrap(r4_raw: Optional[bytes] = None) -> bytes:
    """Derive an R7 bootstrap from exact R4 bytes and one fixed source anchor."""
    if r4_raw is None:
        r4_raw = _r4_source()
    _check(type(r4_raw) is bytes and _sha(r4_raw) == R4_SHA256, "r4_source_digest")
    _check(r4_raw.count(_ANCHOR) == 1, "r4_safe_result_anchor")
    _check(r4_raw.count(_FINISH_ANCHOR) == 1, "r4_phase_finish_anchor")
    source = r4_raw.replace(
        _ANCHOR,
        _ANCHOR + b"        _r7_emit_result_frame(phase_sink, safe_result, runner)\n",
        1,
    )
    source = source.replace(
        _FINISH_ANCHOR,
        _FINISH_ANCHOR + b"        _r7_write_pending_result_frame(phase_sink)\n",
        1,
    )
    _check(source.count(_MAIN_GUARD_ANCHOR) == 1, "r4_main_guard_anchor")
    source = source.replace(
        _MAIN_GUARD_ANCHOR,
        b"\n" + _RESULT_OBSERVER_SOURCE.encode("ascii") + _MAIN_GUARD_ANCHOR,
        1,
    )
    _check(len(source) <= 72 * 1024, "r7_bootstrap_size")
    try:
        compile(source, "<m01-r7-composed-bootstrap>", "exec", dont_inherit=True)
    except BaseException:
        raise ResultObserverBlocked("r7_bootstrap_compile") from None
    return source


def _runner_manifest_tables(runner_raw: bytes) -> tuple[list[str], list[list[str]]]:
    _check(type(runner_raw) is bytes and 0 < len(runner_raw) <= MAX_RUNNER_BYTES, "runner_source_size")
    try:
        tree = ast.parse(runner_raw)
    except BaseException:
        raise ResultObserverBlocked("runner_source_parse") from None
    assignments = [
        node
        for node in tree.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "MANIFEST" for target in node.targets)
    ]
    _check(len(assignments) == 1, "runner_manifest_assignment")
    value = assignments[0].value
    _check(
        isinstance(value, ast.Call)
        and isinstance(value.func, ast.Attribute)
        and isinstance(value.func.value, ast.Name)
        and value.func.value.id == "json"
        and value.func.attr == "loads"
        and len(value.args) == 1
        and isinstance(value.args[0], ast.Constant)
        and type(value.args[0].value) is str,
        "runner_manifest_literal",
    )
    try:
        manifest = json.loads(value.args[0].value)
    except BaseException:
        raise ResultObserverBlocked("runner_manifest_json") from None
    once = manifest.get("once") if type(manifest) is dict else None
    reasons = once.get("allowed_result_reasons") if type(once) is dict else None
    pairs = once.get("inner_diagnostic_pairs") if type(once) is dict else None
    _check(
        type(reasons) is list
        and 0 < len(reasons) <= MAX_REASON_COUNT
        and all(type(item) is str and re.fullmatch(r"[a-z0-9_]{1,96}", item) for item in reasons)
        and reasons == sorted(set(reasons)),
        "runner_reason_table",
    )
    _check(
        type(pairs) is list
        and len(pairs) <= MAX_PAIR_COUNT
        and all(
            type(item) is list
            and len(item) == 2
            and all(type(part) is str and re.fullmatch(r"[a-z0-9_]{1,96}", part) for part in item)
            for item in pairs
        )
        and pairs == sorted(pairs)
        and len({tuple(item) for item in pairs}) == len(pairs),
        "runner_pair_table",
    )
    return reasons, pairs


def _unobserved_result() -> dict[str, Any]:
    return {
        "schema": RESULT_SCHEMA,
        "status": "UNOBSERVED",
        "category": "UNOBSERVED",
        "disposition": "UNVERIFIED",
        "reason_ordinal": None,
        "diagnostic_pair_ordinal": None,
        "lifecycle": "UNOBSERVED",
        "verification": "UNVERIFIED",
        "authority": False,
        "strict_cases_passed": 0,
    }


def _unclassified_result() -> dict[str, Any]:
    return {
        "schema": RESULT_SCHEMA,
        "status": "OBSERVED_FIXED_RESULT",
        "category": "UNCLASSIFIED",
        "disposition": "UNVERIFIED",
        "reason_ordinal": None,
        "diagnostic_pair_ordinal": None,
        "lifecycle": "UNOBSERVED",
        "verification": "UNVERIFIED",
        "authority": False,
        "strict_cases_passed": 0,
    }


def _parse_result_frame(raw: bytes, runner_raw: bytes) -> dict[str, Any]:
    if type(raw) is not bytes or len(raw) > RESULT_MAX_BYTES or not raw.endswith(b"\n"):
        return _unobserved_result()
    if raw == RESULT_PREFIX + b"N\n":
        return _unclassified_result()
    if not raw.startswith(RESULT_PREFIX) or raw.count(b"\n") != 1:
        return _unobserved_result()
    body = raw[len(RESULT_PREFIX) : -1]
    if (
        len(body) != 8
        or body[:1] != b"U"
        or _HEX2.fullmatch(body[1:3]) is None
        or _HEX1.fullmatch(body[3:4]) is None
        or body[4:5] not in b"N01"
        or body[5:6] not in b"N0P"
        or body[6:7] not in b"N01"
        or body[7:8] not in b"01"
    ):
        return _unobserved_result()
    try:
        reasons, pairs = _runner_manifest_tables(runner_raw)
        reason_ordinal = int(body[1:3], 16)
        pair_ordinal = int(body[3:4], 16)
    except BaseException:
        return _unobserved_result()
    if reason_ordinal >= len(reasons) or pair_ordinal > len(pairs):
        return _unobserved_result()
    routes = {b"N": None, b"0": 0, b"1": 1}[body[4:5]]
    native = {b"N": "UNSET", b"0": "ZERO", b"P": "POSITIVE_REPORTED"}[body[5:6]]
    provider = {b"N": "UNSET", b"0": "NO_REQUEST_REPORTED", b"1": "REQUEST_REPORTED"}[body[6:7]]
    return {
        "schema": RESULT_SCHEMA,
        "status": "OBSERVED_FIXED_RESULT",
        "category": "VALIDATOR_APPROVED_UNCERTAIN",
        "disposition": "UNCERTAIN",
        "reason_ordinal": reason_ordinal,
        "diagnostic_pair_ordinal": pair_ordinal,
        "route_invocations_reported": routes,
        "native_operations_reported": native,
        "provider_requests_reported": provider,
        "source_review_bound_reported": body[7:8] == b"1",
        "strict_cases_passed": 0,
        "case_result": False,
        "verification": "UNVERIFIED",
        "authority": False,
    }


def _parse_result_and_phase(raw: Any, runner_raw: bytes) -> tuple[dict[str, Any], dict[str, Any]]:
    if type(raw) is not bytes or len(raw) > RESULT_MAX_BYTES + _R6.MAX_PHASE_FRAME_BYTES:
        return _unobserved_result(), _R6._unobserved_phase()
    if raw.startswith(_R6.PHASE_PREFIX) and raw.count(b"\n") == 2:
        if not raw.endswith(b"\n") or raw.count(b"\n") != 2:
            return _unobserved_result(), _R6._unobserved_phase()
        first, second, trailing = raw.split(b"\n")
        if trailing != b"":
            return _unobserved_result(), _R6._unobserved_phase()
        phase = _R6._parse_phase_frame(first + b"\n")
        result = _parse_result_frame(second + b"\n", runner_raw)
        if (
            result["status"] != "OBSERVED_FIXED_RESULT"
            or phase["status"] != "OBSERVED_FIXED_STAGE"
            or phase["stage"] != "RUNNER_RESULT_UNSAFE"
        ):
            return _unobserved_result(), _R6._unobserved_phase()
        return result, phase
    phase = _R6._parse_phase_frame(raw)
    return _unobserved_result(), phase


def _from_r5(base: Any):
    """Pin an R7 inline bootstrap over the already validated R6 preparation."""
    prepared_r6 = _R6._from_r5(base)
    bootstrap = compose_bootstrap()
    command = tuple(base.command[:-1]) + (bootstrap.decode("utf-8"),)
    binding = dict(prepared_r6.binding)
    binding.update(
        {
            "schema": "iteration41.okx.m01.r33.prepared-child-binding.r7.r2.result-observer.v1",
            "bootstrap_sha256": _sha(bootstrap),
            "bootstrap_variant": "r4-single-safe-result-observer-r7-r2.v1",
            "result_schema": RESULT_SCHEMA,
            "result_prefix": RESULT_PREFIX.decode("ascii"),
            "result_max_bytes": RESULT_MAX_BYTES,
        }
    )
    digest = _R6._canonical_binding_digest(binding, command, base.cwd)
    return dataclasses.replace(
        prepared_r6,
        command=command,
        bootstrap_bytes=bootstrap,
        binding=binding,
        binding_sha256=digest,
    )


def _validate_prepared(value: Any) -> None:
    _check(type(value) is _R6.PreparedM01Child, "prepared_child_type")
    base = value.r5_prepared
    try:
        expected = _from_r5(base)
    except BaseException:
        raise ResultObserverBlocked("prepared_child_source") from None
    _check(
        value.command == expected.command
        and value.cwd == expected.cwd
        and value.environment == expected.environment
        and value.stdin_descriptor == expected.stdin_descriptor
        and value.source_map_bytes == expected.source_map_bytes
        and value.runner_bytes == expected.runner_bytes
        and value.bootstrap_bytes == expected.bootstrap_bytes
        and value.binding == expected.binding
        and value.binding_sha256 == expected.binding_sha256
        and value.plan_disposition == expected.plan_disposition,
        "prepared_child_binding",
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
):
    """Create an R7 child from the frozen R6/R5 public preparation chain."""
    prepared_r6 = _R6.prepare_r33_child(
        prepared_r31, root_metadata, environment=environment
    )
    return _from_r5(prepared_r6.r5_prepared)


class M01WindowsParentAdapter(_R6.M01WindowsParentAdapter):
    """R6 supervisor with one extra post-release finite result projection."""

    def __init__(self, prepared_child: Any, **kwargs: Any):
        _validate_prepared(prepared_child)
        base = prepared_child.r5_prepared
        prepared_r6 = _R6._from_r5(base)
        super().__init__(prepared_r6, **kwargs)
        r4_prepared = dataclasses.replace(
            base,
            command=prepared_child.command,
            bootstrap_bytes=prepared_child.bootstrap_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
        )
        internal = _R6._r2_prepared(self._r5, prepared_child)
        self._r5.prepared = r4_prepared
        self._r5._base.prepared = r4_prepared
        self._r5._base._r2_prepared = internal
        self._r5._inner.prepared = internal
        self.prepared = prepared_child

    def supervise(
        self,
        source_scope: Any,
        release_source_scope: Callable[[Any, float], Any],
        *,
        retention_registry: Any = None,
    ):
        raw_result = self._r5.supervise(
            source_scope,
            release_source_scope,
            retention_registry=retention_registry,
        )
        return self._project_r7_parent_result(raw_result)

    def summarize_result(self, result: Any) -> dict[str, Any]:
        result_type = self._r5._inner._r32.ParentEnvelopeResult
        if type(result) is _R6.M01ParentDiagnosticResult:
            return {
                "schema": result.schema,
                "status": result.status,
                "reason": result.reason,
                "cleanup_reason": result.cleanup_reason,
                "child_returncode": result.child_returncode,
                "capture_complete": result.capture_complete,
                "cleanup_complete": result.cleanup_complete,
                "scope_released": result.scope_released,
                "scope_retained": result.scope_retained,
                "stdout_bytes": result.stdout_bytes,
                "stderr_bytes": result.stderr_bytes,
                "authority": False,
                "strict_cases_passed": 0,
                "child_phase": dict(result.child_phase),
            }
        _check(type(result) is result_type, "parent_result_type")
        return self.summarize_result(self._project_r7_parent_result(result))

    def _project_r7_parent_result(self, result: Any):
        result_type = self._r5._inner._r32.ParentEnvelopeResult
        _check(type(result) is result_type, "parent_result_type")
        if _R6._safe_to_read_phase(result):
            summary = self._r5.summarize_result(result)
            observed, phase = _parse_result_and_phase(result.stderr, self.prepared.runner_bytes)
        else:
            summary = {
                "schema": result.schema,
                "status": result.status,
                "reason": result.reason,
                "cleanup_reason": result.cleanup_reason,
                "child_returncode": result.child_returncode,
                "capture_complete": result.capture_complete,
                "cleanup_complete": result.cleanup_complete,
                "scope_released": result.scope_released,
                "scope_retained": result.scope_retained,
                "stdout_bytes": None,
                "stderr_bytes": None,
                "authority": False,
                "strict_cases_passed": 0,
            }
            observed, phase = _unobserved_result(), _R6._unobserved_phase()
        phase = dict(phase)
        phase["runner_result"] = observed
        return _R6.M01ParentDiagnosticResult(
            schema=summary["schema"],
            status=summary["status"],
            reason=summary["reason"],
            cleanup_reason=summary["cleanup_reason"],
            child_returncode=summary["child_returncode"],
            capture_complete=summary["capture_complete"],
            cleanup_complete=summary["cleanup_complete"],
            scope_released=summary["scope_released"],
            scope_retained=summary["scope_retained"],
            stdout_bytes=summary["stdout_bytes"],
            stderr_bytes=summary["stderr_bytes"],
            child_phase=phase,
        )

    def __getattr__(self, name: str):
        return getattr(self._r5, name)
