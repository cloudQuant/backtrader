"""R23 source fakes keep R12 UNKNOWN and add only a bound reason ordinal.

The generated R28 entry/return is exercised with fake custody/private leaves
and the real public R19/map/plan predicates. The R28 package-closure validator
is shape-faked here; no opaque archive is parsed, imported, or executed.
"""

from __future__ import annotations

import copy
import dataclasses
import hashlib
import io
import time
import uuid
from datetime import datetime, timedelta, timezone
from types import ModuleType

import pytest

pytest_plugins = (
    "tests.unit.runtime.test_iteration41_okx_m01_r33_r21_main_map_callshape_source_fake",
)

from scripts import iteration41_okx_m01_r31_root_startup_prepare_r1 as r31
from scripts import iteration41_okx_m01_r34_plan_prepare_r1 as r34
from scripts import iteration41_okx_m01_r33_root_reason_class_r23_r1 as r23
from tests.unit.runtime import test_iteration41_okx_m01_r33_r21_main_map_callshape_source_fake as r21_tests


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


@pytest.fixture(scope="module")
def root_inputs():
    namespace = r31.default_test_namespace(
        r"Z:\r23-root-reason-class-source-fake-" + uuid.uuid4().hex
    )
    seed = r31.prepare_root_startup(namespace, plan_sha256="0" * 64)
    now = datetime.now(timezone.utc)
    draft = r34.prepare_root_plan_draft(
        seed,
        activation_id=str(uuid.uuid4()),
        created_at_utc=(now - timedelta(seconds=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        expires_at_utc=(now + timedelta(minutes=6)).strftime("%Y-%m-%dT%H:%M:%SZ"),
    )
    assert draft["status"] == "DRAFT_ONLY_NO_AUTHORITY"
    metadata = {
        "schema": "iteration41.okx.m01.r33.root-owned-bootstrap-metadata.v1",
        "cuv2_path": "D:/temp/iteration41-root-public-custody-v2.py",
        "cuv2_sha256": "e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246",
        "owner_image_path": "C:/anaconda3/python.exe",
        "plan_disposition": "READY_TO_RUN",
    }
    return draft["prepared_r31"], metadata


@pytest.fixture(scope="module")
def prepared_r23(root_inputs):
    prepared_r31, metadata = root_inputs
    return r23.prepare_root_hold(prepared_r31, metadata, environment={})


def test_r23_composite_adds_one_source_row_and_recomposes_parent_adapter(prepared_r23):
    prepared = prepared_r23
    assert type(prepared) is r23.R23RootPreparedHold
    assert prepared.authority is False
    assert prepared.strict_cases_passed == 0 and prepared.case_result is False
    assert prepared.hold_addition["canonical_child_map_count"] == 154
    assert prepared.hold_addition["entries"][prepared.r23_helper_path] == {
        "sha256": prepared.r23_helper_sha256,
        "size_bytes": len(prepared.r23_helper_bytes),
        "role": r23.R23_SOURCE_ROLE,
        "origin": "repository_source:" + r23.R23_RELATIVE_PATH,
    }
    assert b"R23_REASON_CLASS_SCHEMA" in prepared.prepared_r13.bootstrap_bytes
    assert b"_r23_emit_child_reason_class_frame(phase_sink, safe_result, runner)" in prepared.prepared_r13.bootstrap_bytes
    assert b"_r23_write_pending_child_reason_class_frame(phase_sink)" in prepared.prepared_r13.bootstrap_bytes
    assert r23._R12._compose_bootstrap is r23._ORIGINAL_COMPOSE_BOOTSTRAP
    assert r23.verify_root_hold(prepared)

    altered = copy.copy(prepared)
    tampered = copy.deepcopy(prepared.hold_addition)
    tampered["entries"][prepared.r23_helper_path]["sha256"] = "0" * 64
    object.__setattr__(altered, "hold_addition", tampered)
    assert not r23.verify_root_hold(altered)

    adapter_result = r23.construct_parent_adapter(
        prepared,
        adapter_kwargs={
            "scope_authenticator": lambda *_args: True,
            "clock": time.monotonic,
            "sleeper": time.sleep,
        },
    )
    assert type(adapter_result) is r23.R23ParentAdapterResult
    assert adapter_result.prepared_hold is prepared
    assert adapter_result.r13_recompose_calls == 1
    assert adapter_result.r13_outer_transform_calls == 1
    assert adapter_result.hold_addition["canonical_child_map_count"] == 154
    assert adapter_result.hold_addition["entries"][prepared.r23_helper_path] == prepared.hold_addition["entries"][prepared.r23_helper_path]
    assert r23._R12._compose_bootstrap is r23._ORIGINAL_COMPOSE_BOOTSTRAP
    assert r23.verify_parent_adapter_result(adapter_result)


def test_generated_run_prelaunch_return_maps_only_to_a_source_listed_class(generated_r21):
    result, events, fixture, _support_rows = r21_tests._run(generated_r21)
    assert result["status"] == "BLOCKED"
    assert result["reason"] == "outer_prelaunch_failed"
    assert result["route_invocations"] == 0
    assert "real_r13_r17_r19_r21_activation_passed" in events
    assert "r28_closure_fake" in events
    assert events.index("real_r13_r17_r19_r21_activation_passed") < events.index("protected_io_boundary")
    assert fixture["runtime_map"]["map_counts"] == {"public": 118, "software": 36, "canonical": 154}

    binding = r23._binding_from_prepared(generated_r21["prepared_r13"], r23._self_source())
    projected = r23.classify_reason(result["reason"], binding)
    expected = binding.reason_table.index("outer_prelaunch_failed") + 1
    assert projected["status"] == "OBSERVED_SOURCE_LITERAL_REASON_CLASS"
    assert projected["reason_class_ordinal"] == expected
    assert projected["reason_class_form"] == "DIRECT_LITERAL"
    assert projected["authority"] is False
    assert r23.classify_reason("root_child_r19_canonical_map_shape", binding)["reason_class_ordinal"] == (
        binding.reason_table.index("r19_canonical_map_shape") + 1
    )
    assert r23.classify_reason("root_child_unlisted_private_value", binding)["reason_class_ordinal"] == 0
    assert r23.classify_reason("r19_canonical_map_shape\nraw", binding)["reason_class_ordinal"] == 0


def test_generated_bootstrap_preserves_r12_unknown_and_emits_a_bounded_r23_frame(prepared_r23):
    prepared = prepared_r23.prepared_r13
    module = ModuleType("_m01_r23_bootstrap_source_fake")
    exec(compile(prepared.bootstrap_bytes, "<r23-source-fake-bootstrap>", "exec"), module.__dict__)
    manifest = r23._R13._R10._manifest_from_runner(prepared.runner_bytes)

    class _Runner:
        MANIFEST = manifest

        @staticmethod
        def _safe_result(value):
            return value

        @staticmethod
        def _canonical(path):
            return r23._R13._R10._R9._normalized(path)

    reason = next(
        value
        for value in manifest["once"]["allowed_result_reasons"]
        if value == "r28_outer_candidate_captured"
    )
    source_reason = "outer_prelaunch_failed"
    safe_result = {
        "schema": manifest["once"]["result_schema"],
        "disposition": "OUTER_CAPTURED",
        "reason": reason,
        "parse_allowed": False,
        "projection": {
            "outer_status": "BLOCKED",
            "outer_reason": "root_child_" + source_reason,
            "outer_route_invocations": 0,
        },
        "inner_stage": None,
        "inner_code": None,
        "lifecycle": {
            "route_invocations": 0,
            "native_operations": 0,
            "provider_requests": False,
            "source_review_bound": True,
            "strict_cases_passed": 0,
            "case_result": False,
        },
    }

    class _Sink:
        _closed = False
        _broken = False

        def __init__(self):
            self._stream = io.BytesIO()

    sink = _Sink()
    module._r12_emit_outer_reason_ordinal_frame(sink, safe_result, _Runner)
    module._r23_emit_child_reason_class_frame(sink, safe_result, _Runner)
    assert sink._r12_outer_reason_frame == b"M01R12:O0000\n"
    assert sink._r23_child_reason_class_frame == (
        b"M01R23:C%04x\n" % (prepared_r23.reason_binding.reason_table.index(source_reason) + 1)
    )
    sink._closed = True
    module._r12_write_pending_outer_reason_ordinal_frame(sink)
    module._r23_write_pending_child_reason_class_frame(sink)
    written = sink._stream.getvalue()
    assert written == b"M01R12:O0000\n" + sink._r23_child_reason_class_frame
    assert b"outer_prelaunch_failed" not in written

    projected = r23._parse_reason_class_frame(
        sink._r23_child_reason_class_frame, prepared_r23.reason_binding
    )
    assert projected["reason_class_ordinal"] == prepared_r23.reason_binding.reason_table.index(source_reason) + 1
    assert projected["reason_class_form"] == "CHILD_PREFIX_LITERAL"
    unknown = r23._parse_reason_class_frame(b"M01R23:U0000\n", prepared_r23.reason_binding)
    assert unknown["status"] == "OBSERVED_UNKNOWN_REASON_CLASS"
    assert unknown["reason_class_ordinal"] == 0
    assert r23._parse_reason_class_frame(b"M01R23:Cffff\n", prepared_r23.reason_binding)["status"] == "UNOBSERVED"


def test_r23_parent_projection_preserves_r12_and_bounds_the_fifth_frame(prepared_r23):
    binding = prepared_r23.reason_binding
    r12 = r23._R12
    base_lines = (
        r12._R11._R6.PHASE_PREFIX + b"fixture\n",
        r12._R11._R8.PHASE_PREFIX + b"fixture\n",
        r12._R11.R11_FRAME_PREFIX + b"fixture\n",
        r12.R12_FRAME_PREFIX + b"fixture\n",
    )
    frame = b"M01R23:C%04x\n" % (binding.reason_table.index("outer_prelaunch_failed") + 1)

    @dataclasses.dataclass(frozen=True)
    class _Envelope:
        status: str
        capture_complete: bool
        cleanup_complete: bool
        scope_released: bool
        scope_retained: bool
        child_returncode: int
        stderr: bytes
        stderr_bytes: int

    @dataclasses.dataclass(frozen=True)
    class _Projected:
        child_phase: dict
        stderr_bytes: int

    result = _Envelope(
        "CHILD_EXITED", True, True, True, False, 2, b"".join(base_lines) + frame, 0
    )
    calls = []

    def original(_adapter, envelope, _prepared, _fallback):
        calls.append(envelope.stderr)
        return _Projected(
            {
                "returned_result": {"status": "OBSERVED_FIXED_RETURNED_RESULT"},
                "outer_reason_result": {"status": "OBSERVED_FIXED_REASON_ORDINAL"},
            },
            len(envelope.stderr),
        )

    projected = r23._r23_parent_projection(original, object(), result, object(), lambda value: value, binding)
    assert calls == [b"".join(base_lines)]
    assert projected.stderr_bytes == len(result.stderr)
    returned = projected.child_phase["returned_result"]
    assert returned["reason_class_ordinal"] == binding.reason_table.index("outer_prelaunch_failed") + 1
    assert returned["reason_class_form"] == "CHILD_PREFIX_LITERAL"
    assert projected.child_phase["outer_reason_result"]["status"] == "OBSERVED_FIXED_REASON_ORDINAL"

    malformed = dataclasses.replace(result, stderr=b"".join(base_lines) + b"M01R23:Cffff\n")
    unobserved = r23._r23_parent_projection(original, object(), malformed, object(), lambda value: value, binding)
    assert unobserved.child_phase["returned_result"]["status"] == "OBSERVED_FIXED_RETURNED_RESULT"
    assert "reason_class_ordinal" not in unobserved.child_phase["returned_result"]
    assert unobserved.stderr_bytes == len(malformed.stderr)
