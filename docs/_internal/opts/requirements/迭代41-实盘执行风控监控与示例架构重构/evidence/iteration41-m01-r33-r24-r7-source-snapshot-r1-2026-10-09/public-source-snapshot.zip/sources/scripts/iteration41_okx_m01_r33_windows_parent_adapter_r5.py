"""R5 image-gate bridge for the isolated M01 R33 R4 parent adapter.

R5 keeps R4, R2, and the pinned image observer unchanged. It opens the R4
instance's exact pinned image module only around the bounded, pre-resume
observer call, and counts that observer worker as a pending session operation
so an uncertain timeout cannot release the source scope or expose output.
"""

from __future__ import annotations

import hashlib
import sys
import threading
import types
from pathlib import Path
from typing import Any, Callable, Optional


R4_FILENAME = "iteration41_okx_m01_r33_windows_parent_adapter_r4.py"
R4_SOURCE_SHA256 = "2a1ea13020b54d54fe41ace3fca2a1f05c4f0cdb89d71b8c06c66de1a8bd140c"
IMAGE_SOURCE_SHA256 = "3f14b2771a73e056b7902f48f65bfebbf17e93a62202a55f66de6ac3ff12d0cc"
_MAX_R4_BYTES = 1024 * 1024


class ParentAdapterBlocked(ValueError):
    """A fixed R4 dependency or image observation boundary failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise ParentAdapterBlocked(reason)


def _read_pinned_file(path: Path, expected_sha256: str, maximum: int) -> bytes:
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise ParentAdapterBlocked("pinned_source_read") from None
    _check(0 < len(raw) <= maximum, "pinned_source_size")
    _check(_sha(raw) == expected_sha256, "pinned_source_digest")
    return raw


def _load_pinned_r4():
    path = Path(__file__).resolve().with_name(R4_FILENAME)
    raw = _read_pinned_file(path, R4_SOURCE_SHA256, _MAX_R4_BYTES)
    name = "_iteration41_okx_m01_r33_r4_exact_for_r5"
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__package__ = ""
    try:
        code = compile(raw, str(path), "exec", dont_inherit=True)
        sys.modules[name] = module
        exec(code, module.__dict__)
    except BaseException:
        sys.modules.pop(name, None)
        raise ParentAdapterBlocked("r4_source_load") from None
    sys.modules.pop(name, None)
    return module


_R4 = _load_pinned_r4()
PreparedM01Child = _R4.PreparedM01Child


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Use the frozen R4 constructor and its validated R3 child descriptor."""
    return _R4.prepare_r33_child(
        prepared_r31, root_metadata, environment=environment
    )


class M01WindowsParentAdapter:
    """R4 adapter with an owner-bound gate for its private pinned image leaf."""

    def __init__(
        self,
        prepared_child: Any,
        *,
        scope_authenticator: Callable[[Any, dict[str, Any], float], Any],
        fake_leaves: bool = False,
        native: Any = None,
        process_factory: Optional[Callable[..., Any]] = None,
        launcher_module: Any = None,
        image_module: Any = None,
        clock: Callable[[], Any],
        sleeper: Callable[[float], Any],
    ):
        self._base = _R4.M01WindowsParentAdapter(
            prepared_child,
            scope_authenticator=scope_authenticator,
            fake_leaves=fake_leaves,
            native=native,
            process_factory=process_factory,
            launcher_module=launcher_module,
            image_module=image_module,
            clock=clock,
            sleeper=sleeper,
        )
        self.prepared = self._base.prepared
        self.fake_leaves = self._base.fake_leaves
        self._owner_thread = self._base._owner_thread
        self._r2_module = self._base._r2_module
        self._inner = self._base._inner
        self._image = self._inner.image
        _read_pinned_file(Path(_R4.__file__), R4_SOURCE_SHA256, _MAX_R4_BYTES)
        image_path = getattr(self._image, "__file__", None)
        _check(type(image_path) is str, "image_module_path")
        _read_pinned_file(Path(image_path), IMAGE_SOURCE_SHA256, 64 * 1024)
        self._target_observation_attempted = False
        # R32 calls the R2 adapter object directly. Rebind only this instance's
        # target gate; the method still calls the exact pinned image observer.
        self._inner.verify_target = self.verify_target

    @property
    def clock(self):
        return self._base.clock

    @property
    def sleeper(self):
        return self._base.sleeper

    def verify_target(self, session: Any, timeout_seconds: float) -> bool:
        """Open the pinned image leaf only for one bounded pre-resume check."""
        if (
            threading.get_ident() != self._owner_thread
            or not self._base._supervising
            or not self._base._scope_callback_verified
            or self.prepared.plan_disposition != "READY_TO_RUN"
            or self._target_observation_attempted
        ):
            return False
        if not self._r2_module._valid_timeout(timeout_seconds, 100.0):
            return False
        if type(session) is not self._r2_module._Session:
            return False
        if (
            not session.assigned
            or not session.job_policy_verified
            or session.resume_attempted
            or not session.stdin_closed
        ):
            return False
        observer = getattr(self._image, "observe_suspended_child_image", None)
        if not callable(observer) or getattr(self._image, "ROOT_NATIVE_ENABLED", None) is not False:
            return False
        if type(getattr(session.process, "pid", None)) is not int or session.process.pid <= 0:
            return False

        # One attempt only: timeout or exception must not trigger a late retry.
        self._target_observation_attempted = True
        self._image.ROOT_NATIVE_ENABLED = True
        try:
            observation = self._r2_module._bounded_call(
                lambda: observer(session.process),
                float(timeout_seconds),
                session=session,
            )
        finally:
            # Keep the private pinned leaf closed after success, failure, or
            # timeout; pending_operations retains the session if its worker is late.
            self._image.ROOT_NATIVE_ENABLED = False

        if observation is self._r2_module._MISSING or type(observation) is not dict:
            return False
        expected = {
            "schema": "iteration41.suspended-child-image-observation.v2",
            "child_pid": session.process.pid,
            "fixed_executable_path_observed": True,
            "active_at_observation": True,
            "suspension_verified": False,
            "job_assignment_verified": False,
            "physical_image_custody_verified": False,
            "whole_command_g1": False,
            "strict_cases_passed": 0,
            "authority": False,
        }
        if observation != expected:
            return False
        session.target_verified = True
        return True

    def verify_source_scope(self, source_scope: Any, timeout_seconds: float) -> bool:
        return self._base.verify_source_scope(source_scope, timeout_seconds)

    def supervise(
        self,
        source_scope: Any,
        release_source_scope: Callable[[Any, float], Any],
        *,
        retention_registry: Any = None,
    ):
        return self._base.supervise(
            source_scope,
            release_source_scope,
            retention_registry=retention_registry,
        )

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._base.summarize_result(result)

    def __getattr__(self, name: str):
        return getattr(self._base, name)
