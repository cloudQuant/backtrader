"""Pure-Python parent-budget coordinator for the M01 R28/R31 runner.

The caller must provide a trusted adapter that launches a suspended child,
assigns it to a process Job, verifies its target, and resumes it only after
those gates pass. Every adapter operation must honor its timeout argument.
This module does not implement or exercise Windows APIs, launch processes, or
interpret child output as a readiness or certification result.
"""

from __future__ import annotations

import math
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional


RESULT_SCHEMA = "iteration41.okx.m01.external-parent-budget-result.r32.v1"
PARENT_TIMEOUT_SECONDS = 100.0
PARENT_CLEANUP_SECONDS = 5.0
MAX_STDOUT_BYTES = 128 * 1024
MAX_STDERR_BYTES = 128 * 1024


@dataclass(frozen=True)
class ParentEnvelopeResult:
    """Finite process-supervision outcome; child bytes are never interpreted here."""

    schema: str
    status: str
    reason: str
    cleanup_reason: str
    child_returncode: Optional[int]
    stdout: bytes
    stderr: bytes
    capture_complete: bool
    cleanup_complete: bool
    scope_released: bool
    scope_retained: bool


class StrongRetentionRegistry:
    """Keep uncertain source scope and process references alive in this process."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries = []

    def retain(self, resources: tuple[Any, ...]) -> bool:
        if type(resources) is not tuple or not resources:
            return False
        with self._lock:
            self._entries.append(resources)
        return True

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._entries)


_DEFAULT_RETENTION_REGISTRY = StrongRetentionRegistry()


def _valid_time(value: Any) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(float(value))
    except (OverflowError, ValueError):
        return False


def _remaining(clock: Callable[[], Any], deadline: float) -> float:
    try:
        now = clock()
    except BaseException:
        return 0.0
    if not _valid_time(now):
        return 0.0
    return max(0.0, deadline - float(now))


def _valid_adapter(adapter: Any) -> bool:
    required = (
        "launch_suspended",
        "assign_to_job",
        "verify_job_policy",
        "verify_target",
        "resume",
        "wait",
        "capture_bounded",
        "is_reaped",
        "job_assigned",
        "terminate_job",
        "terminate_process",
        "active_process_count",
        "close_pipes",
        "pipes_closed",
        "close_job",
        "job_closed",
    )
    try:
        return all(callable(getattr(adapter, name, None)) for name in required)
    except BaseException:
        return False


def _capture_shape(value: Any) -> Optional[tuple[bytes, bytes, bool]]:
    if type(value) is not tuple or len(value) != 3:
        return None
    stdout, stderr, complete = value
    if (
        type(stdout) is not bytes
        or type(stderr) is not bytes
        or type(complete) is not bool
        or len(stdout) > MAX_STDOUT_BYTES
        or len(stderr) > MAX_STDERR_BYTES
    ):
        return None
    return stdout, stderr, complete


def _cleanup_session(
    adapter: Any,
    session: Any,
    state: dict[str, Any],
    deadline: float,
    clock: Callable[[], Any],
    sleeper: Callable[[float], Any],
) -> None:
    """Best-effort bounded process teardown. Called only on a daemon worker."""

    try:
        def budget() -> float:
            return _remaining(clock, deadline)

        def exact_bool(value: Any) -> bool:
            return type(value) is bool and value

        assigned = adapter.job_assigned(session)
        if type(assigned) is not bool:
            state["reason"] = "job_assignment_state_unknown"
            return
        if state.get("resume_attempted") is True and not assigned:
            state["reason"] = "job_assignment_lost_after_resume"
            return

        reaped = adapter.is_reaped(session)
        if type(reaped) is not bool:
            state["reason"] = "process_reap_state_unknown"
            return

        if not reaped:
            remaining = budget()
            if remaining <= 0.0:
                state["reason"] = "cleanup_deadline_exhausted"
                return
            if assigned:
                adapter.terminate_job(session, remaining)
            else:
                adapter.terminate_process(session, remaining)
            remaining = budget()
            if remaining <= 0.0:
                state["reason"] = "cleanup_deadline_exhausted"
                return
            returncode = adapter.wait(session, remaining)
            if type(returncode) is not int:
                state["reason"] = "process_reap_unconfirmed"
                return
            state["returncode"] = returncode
            reaped = adapter.is_reaped(session)
            if type(reaped) is not bool or not reaped:
                state["reason"] = "process_reap_unconfirmed"
                return

        if not state["capture_complete"]:
            remaining = budget()
            if remaining > 0.0:
                try:
                    raw_capture = adapter.capture_bounded(
                        session,
                        remaining,
                        MAX_STDOUT_BYTES,
                        MAX_STDERR_BYTES,
                    )
                    capture = _capture_shape(raw_capture)
                except BaseException:
                    capture = None
                if capture is not None:
                    state["stdout"], state["stderr"], state["capture_complete"] = capture

        while True:
            remaining = budget()
            if remaining <= 0.0:
                state["reason"] = "cleanup_deadline_exhausted"
                return
            count = adapter.active_process_count(session, remaining)
            if type(count) is not int or count < 0:
                state["reason"] = "job_accounting_unknown"
                return
            if count == 0:
                break
            if not assigned:
                state["reason"] = "unassigned_process_tree_present"
                return
            remaining = budget()
            if remaining <= 0.0 or not exact_bool(
                adapter.terminate_job(session, remaining)
            ):
                state["reason"] = "job_termination_unconfirmed"
                return
            pause = min(0.05, budget())
            if pause <= 0.0:
                state["reason"] = "cleanup_deadline_exhausted"
                return
            sleeper(pause)

        remaining = budget()
        if remaining <= 0.0 or not exact_bool(adapter.close_pipes(session, remaining)):
            state["reason"] = "pipe_close_unconfirmed"
            return
        if adapter.pipes_closed(session) is not True:
            state["reason"] = "pipe_close_unconfirmed"
            return

        remaining = budget()
        if remaining <= 0.0:
            state["reason"] = "cleanup_deadline_exhausted"
            return
        count = adapter.active_process_count(session, remaining)
        if type(count) is not int or count != 0:
            state["reason"] = "job_not_empty_before_close"
            return

        remaining = budget()
        if remaining <= 0.0 or not exact_bool(adapter.close_job(session, remaining)):
            state["reason"] = "job_close_unconfirmed"
            return
        if adapter.job_closed(session) is not True:
            state["reason"] = "job_close_unconfirmed"
            return

        if adapter.is_reaped(session) is not True:
            state["reason"] = "process_reap_unconfirmed"
            return
        state["clean"] = budget() > 0.0
        state["reason"] = (
            "process_cleanup_complete" if state["clean"] else "cleanup_deadline_exhausted"
        )
    except BaseException:
        state["reason"] = "cleanup_adapter_error"
        state["clean"] = False


def supervise_external_parent(
    adapter: Any,
    source_scope: Any,
    verify_source_scope: Callable[[Any, float], Any],
    release_source_scope: Callable[[Any, float], Any],
    *,
    retention_registry: Optional[StrongRetentionRegistry] = None,
    clock: Callable[[], Any] = time.monotonic,
    sleeper: Callable[[float], Any] = time.sleep,
) -> ParentEnvelopeResult:
    """Run a child under a fixed 100s parent budget and 5s cleanup window.

    The injected adapter is the only process boundary. It must start suspended,
    assign the child to a kill-on-close Job, verify the requested target, and
    resume only after those checks pass. Adapter calls must honor the timeout
    passed to them. Scope verification and release stay on this calling thread
    because the held-source lease may be thread-affine; those callbacks must
    honor their timeout arguments. Uncertain cleanup retains scope and process
    references.
    """

    registry = (
        _DEFAULT_RETENTION_REGISTRY
        if retention_registry is None
        else retention_registry
    )
    stdout = b""
    stderr = b""
    capture_complete = False
    returncode: Optional[int] = None
    session = None
    primary_status = "ADAPTER_CONTRACT_ERROR"
    primary_reason = "adapter_contract_invalid"
    cleanup_reason = "not_started"
    scope_released = False
    scope_retained = False
    resume_attempted = False

    if (
        not callable(verify_source_scope)
        or not callable(release_source_scope)
        or not callable(clock)
        or not callable(sleeper)
    ):
        try:
            scope_retained = registry.retain((source_scope, adapter)) is True
        except BaseException:
            scope_retained = False
        return ParentEnvelopeResult(
            RESULT_SCHEMA,
            "ADAPTER_CONTRACT_ERROR",
            "caller_contract_invalid",
            "not_started",
            None,
            b"",
            b"",
            False,
            False,
            False,
            scope_retained,
        )

    try:
        started = clock()
    except BaseException:
        started = None
    if not _valid_time(started) or not _valid_adapter(adapter):
        try:
            scope_retained = registry.retain((source_scope, adapter)) is True
        except BaseException:
            scope_retained = False
        return ParentEnvelopeResult(
            RESULT_SCHEMA,
            "ADAPTER_CONTRACT_ERROR",
            "adapter_contract_invalid",
            "not_started",
            None,
            b"",
            b"",
            False,
            False,
            False,
            scope_retained,
        )

    active_deadline = float(started) + PARENT_TIMEOUT_SECONDS
    if not _valid_time(active_deadline):
        try:
            scope_retained = registry.retain((source_scope, adapter)) is True
        except BaseException:
            scope_retained = False
        return ParentEnvelopeResult(
            RESULT_SCHEMA,
            "ADAPTER_CONTRACT_ERROR",
            "clock_contract_invalid",
            "not_started",
            None,
            b"",
            b"",
            False,
            False,
            False,
            scope_retained,
        )

    def remaining() -> float:
        return _remaining(clock, active_deadline)

    try:
        timeout = remaining()
        if timeout <= 0.0:
            primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
        elif verify_source_scope(source_scope, timeout) is not True:
            primary_status, primary_reason = "ADMISSION_BLOCKED", "source_scope_unverified"
        elif remaining() <= 0.0:
            primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
        else:
            session = adapter.launch_suspended(timeout)
            if session is None:
                primary_status, primary_reason = "LAUNCH_FAILED", "launch_failed"
            elif remaining() <= 0.0:
                primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
            elif adapter.assign_to_job(session, remaining()) is not True:
                primary_status, primary_reason = "ADMISSION_BLOCKED", "job_assignment_failed"
            elif remaining() <= 0.0:
                primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
            elif adapter.verify_job_policy(session, remaining()) is not True:
                primary_status, primary_reason = "ADMISSION_BLOCKED", "job_policy_unverified"
            elif remaining() <= 0.0:
                primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
            elif adapter.verify_target(session, remaining()) is not True:
                primary_status, primary_reason = "ADMISSION_BLOCKED", "target_verification_failed"
            elif remaining() <= 0.0:
                primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
            elif remaining() <= 0.0:
                primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
            else:
                resume_attempted = True
                resumed = adapter.resume(session, remaining())
                if resumed is not True:
                    primary_status, primary_reason = "ADMISSION_BLOCKED", "resume_failed"
                elif remaining() <= 0.0:
                    primary_status, primary_reason = "PARENT_TIMEOUT", "parent_deadline_exhausted"
                else:
                    value = adapter.wait(session, remaining())
                    if remaining() <= 0.0 or value is None:
                        primary_status, primary_reason = (
                            "PARENT_TIMEOUT",
                            "parent_deadline_exhausted",
                        )
                    elif type(value) is not int:
                        primary_status, primary_reason = "ADAPTER_ERROR", "wait_contract_invalid"
                    else:
                        returncode = value
                        capture = _capture_shape(
                            adapter.capture_bounded(
                                session,
                                remaining(),
                                MAX_STDOUT_BYTES,
                                MAX_STDERR_BYTES,
                            )
                        )
                        if remaining() <= 0.0:
                            primary_status, primary_reason = (
                                "PARENT_TIMEOUT",
                                "parent_deadline_exhausted",
                            )
                        elif capture is None:
                            primary_status, primary_reason = (
                                "OUTPUT_INCOMPLETE",
                                "capture_contract_invalid",
                            )
                        else:
                            stdout, stderr, capture_complete = capture
                            if capture_complete:
                                primary_status, primary_reason = (
                                    "CHILD_EXITED",
                                    "child_exit_observed",
                                )
                            else:
                                primary_status, primary_reason = (
                                    "OUTPUT_INCOMPLETE",
                                    "capture_incomplete",
                                )
    except BaseException:
        primary_status, primary_reason = "ADAPTER_ERROR", "adapter_operation_failed"

    if session is None:
        cleanup_state = {"clean": False, "reason": "session_unavailable"}
        worker = None
    else:
        try:
            cleanup_started = clock()
            cleanup_deadline = (
                float(cleanup_started) + PARENT_CLEANUP_SECONDS
                if _valid_time(cleanup_started)
                else float("nan")
            )
        except BaseException:
            cleanup_deadline = float("nan")
        cleanup_state = {
            "clean": False,
            "reason": "cleanup_uncertain",
            "returncode": returncode,
            "stdout": stdout,
            "stderr": stderr,
            "capture_complete": capture_complete,
            "resume_attempted": resume_attempted,
        }
        worker = threading.Thread(
            target=_cleanup_session,
            args=(
                adapter,
                session,
                cleanup_state,
                cleanup_deadline,
                clock,
                sleeper,
            ),
            name="m01-r32-parent-cleanup",
            daemon=True,
        )
        try:
            worker.start()
            worker.join(PARENT_CLEANUP_SECONDS)
        except BaseException:
            cleanup_state["reason"] = "cleanup_worker_failed"
        if worker.is_alive():
            cleanup_state["reason"] = "cleanup_deadline_exhausted"

    process_cleanup_complete = (
        cleanup_state.get("clean") is True and worker is not None and not worker.is_alive()
    )
    cleanup_reason = cleanup_state.get("reason", "cleanup_uncertain")
    cleanup_complete = False
    if process_cleanup_complete:
        if type(cleanup_state.get("returncode")) is int:
            returncode = cleanup_state["returncode"]
        if not capture_complete:
            final_capture = _capture_shape(
                (
                    cleanup_state.get("stdout"),
                    cleanup_state.get("stderr"),
                    cleanup_state.get("capture_complete"),
                )
            )
            if final_capture is not None:
                stdout, stderr, capture_complete = final_capture
        release_budget = _remaining(clock, cleanup_deadline)
        if release_budget > 0.0:
            try:
                scope_released = release_source_scope(source_scope, release_budget) is True
            except BaseException:
                scope_released = False
        if scope_released and _remaining(clock, cleanup_deadline) > 0.0:
            cleanup_complete = True
            cleanup_reason = "clean"
        elif scope_released:
            cleanup_reason = "cleanup_deadline_exhausted"
        else:
            cleanup_reason = "scope_release_unconfirmed"

    if not cleanup_complete:
        try:
            scope_retained = registry.retain(
                (source_scope, adapter, session, cleanup_state, worker)
            ) is True
        except BaseException:
            scope_retained = False

    status = primary_status if cleanup_complete else "CLEANUP_UNCERTAIN"
    reason = primary_reason
    if primary_status == "CHILD_EXITED" and not capture_complete:
        status, reason = "OUTPUT_INCOMPLETE", "capture_incomplete"
    if not (status == "CHILD_EXITED" and cleanup_complete and scope_released and capture_complete):
        stdout, stderr = b"", b""
    return ParentEnvelopeResult(
        RESULT_SCHEMA,
        status,
        reason,
        cleanup_reason,
        returncode,
        stdout,
        stderr,
        capture_complete,
        cleanup_complete,
        scope_released,
        scope_retained,
    )
