"""Source-fake tests for bounded R6 child-phase diagnostics."""

from __future__ import annotations

import copy
import dataclasses
import hashlib
import io
import json
import ntpath
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

from scripts import iteration41_okx_l03_l04_v4_root_launcher as launcher
from scripts import iteration41_okx_m01_r31_root_startup_prepare_r1 as r31
from scripts import iteration41_okx_m01_r33_child_bootstrap_r3 as old_bootstrap
from scripts import iteration41_okx_m01_r33_child_bootstrap_r4 as bootstrap
from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r6 as r6
from scripts import iteration41_suspended_child_image_r2 as image_observer
from tests.unit.runtime.test_iteration41_okx_m01_r33_windows_parent_adapter_r2 import (
    _CUV2,
    _FakeClock,
    _FakeKernel,
)


_REPOSITORY_ROOT = Path(__file__).resolve().parents[3]
_R28_PACKET = (
    _REPOSITORY_ROOT
    / "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence"
    / "iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07"
)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _canonical(path: str) -> str:
    return ntpath.normcase(ntpath.normpath(path.replace("/", "\\")))


def _plan_fixture(outer, now_utc):
    created = now_utc - timedelta(seconds=1)
    expires = now_utc + timedelta(minutes=5)
    document = {
        "schema": outer.PLAN_SCHEMA,
        "status": "READY_TO_RUN",
        "activation_id": str(uuid.uuid4()),
        "created_at_utc": created.isoformat().replace("+00:00", "Z"),
        "expires_at_utc": expires.isoformat().replace("+00:00", "Z"),
        "profile": outer.PROFILE,
        "case_id": outer.CASE_ID,
        "review_ref": outer.REVIEW_REF,
        "review_json_sha256": outer.R28_REVIEW_JSON_SHA256,
        "review_bundle_sha256": outer.R28_REVIEW_BUNDLE_SHA256,
        "source_map_sha256": outer.SOURCE_MAP_SHA256,
        "source_index_sha256": outer.SOURCE_INDEX_SHA256,
        "source_zip_sha256": outer.SOURCE_ZIP_SHA256,
        "source_checkpoint_sha256": outer.SOURCE_CHECKPOINT_SHA256,
        "wrapper_sha256": outer.ACTIVE_WRAPPER_SHA256,
        "root_helper_sha256": outer.CUSTODY_SHA256,
        "pyyaml_record_sha256": outer.PYAML_RAW_RECORD_SHA256,
        "pyyaml_projection_sha256": "44ff41822cc39e84b7ee3cd08a9f22ecd5518c2cc6e533c9bab93ace2dd73541",
        "python_exe_sha256": outer.PYTHON_SHA256,
        "python_dll_sha256": outer.PYTHON_DLL_SHA256,
        "max_route_invocations": 1,
    }
    return document, outer._canonical(document)


def _r4_binding(descriptor, source_map):
    binding = {
        "schema": "iteration41.okx.m01.r33.prepared-child-binding.r4.v1",
        "owner_image_path": r6._R4.FIXED_EXECUTABLE,
        "cuv2_path": descriptor["cuv2_path"],
        "source_map_sha256": descriptor["source_map_sha256"],
        "source_map_path": descriptor["source_map_path"],
        "runner_sha256": descriptor["runner_sha256"],
        "runner_path": descriptor["runner_path"],
        "bootstrap_sha256": r6._R4.R3_BOOTSTRAP_SHA256,
        "cuv2_sha256": descriptor["cuv2_sha256"],
        "manifest_binding_sha256": descriptor["manifest_binding_sha256"],
        "root": descriptor["root"],
        "runtime_namespace": descriptor["runtime_namespace"],
        "plan_sha256": source_map["plan_sha256"],
        "plan_disposition": descriptor["plan_disposition"],
        "source_map_counts": {"public": 118, "software": 36, "canonical": 154},
        "budgets": descriptor["budgets"],
        "bootstrap_variant": "instance-isolated-r2-held-plan-validator",
        "r2_source_sha256": r6._R4.R2_SOURCE_SHA256,
    }
    return binding


def _synthetic_full_prepared(tmp_path, *, invalid_plan=False):
    """Build a full fake 154-map around the real generated runner and plan gate."""
    namespace = r31.default_test_namespace(str(tmp_path / "runtime"))
    prepared_r31 = r31.prepare_root_startup(namespace, plan_sha256="a" * 64)
    metadata = {
        "schema": r6.ROOT_METADATA_SCHEMA,
        "cuv2_path": str(_CUV2),
        "cuv2_sha256": r6.CUV2_PUBLIC_SOURCE_SHA256,
        "owner_image_path": r6.FIXED_EXECUTABLE,
        "plan_disposition": "READY_TO_RUN",
    }
    first = r6.prepare_r33_child(
        prepared_r31, metadata, environment={"SYSTEMROOT": "C:\\Windows"}
    )
    base = first.r5_prepared
    descriptor = json.loads(base.stdin_descriptor)
    manifest = copy.deepcopy(prepared_r31["manifest"])
    root = manifest["root"]
    runtime_namespace = dict(manifest["runtime_namespace"])

    outer_raw = prepared_r31["active_outer_source"]
    wrapper_raw = prepared_r31["active_wrapper_source"]
    outer = old_bootstrap._load_source(
        outer_raw, runtime_namespace["self_path"], "_r6_synthetic_outer_fixture"
    )
    if invalid_plan:
        plan_raw = b"{}"
    else:
        _document, plan_raw = _plan_fixture(outer, datetime.now(timezone.utc))

    held = {}
    for relative, digest in manifest["public_pins"].items():
        path = Path(root).joinpath(*relative.replace("\\", "/").split("/"))
        raw = path.read_bytes()
        assert _sha(raw) == digest
        held[_canonical(ntpath.join(root, relative))] = raw

    software = dict(manifest["software_pins"])
    plan_key = _canonical(runtime_namespace["plan_path"])
    self_key = _canonical(runtime_namespace["self_path"])
    wrapper_key = _canonical(runtime_namespace["active_wrapper_path"])
    for index, path in enumerate(sorted(software)):
        key = _canonical(path)
        if key == plan_key:
            raw = plan_raw
        elif key == self_key:
            raw = outer_raw
        elif key == wrapper_key:
            raw = wrapper_raw
        else:
            # The software map is a temporary in-memory fixture. No runtime,
            # SDK, PyYAML installation, or native payload is read.
            raw = f"r6-source-fake-software-{index}".encode("ascii")
        software[path] = _sha(raw)
        assert key not in held
        held[key] = raw

    manifest["software_pins"] = dict(sorted(software.items()))
    combined = {
        _canonical(ntpath.join(root, relative)): digest
        for relative, digest in manifest["public_pins"].items()
    }
    combined.update({_canonical(path): digest for path, digest in software.items()})
    assert len(combined) == 154
    manifest["canonical_pins"] = dict(sorted(combined.items()))
    r31._seal(manifest)
    r31._validate_manifest(manifest)
    runner_raw = r31.render_root_runner_template(manifest)

    source_map = json.loads(base.source_map_bytes)
    source_map.update(
        {
            "public_pins": dict(manifest["public_pins"]),
            "software_pins": dict(manifest["software_pins"]),
            "canonical_pins": dict(manifest["canonical_pins"]),
            "map_counts": {"public": 118, "software": 36, "canonical": 154},
            "root": root,
            "runtime_namespace": runtime_namespace,
            "runner_template_sha256": _sha(runner_raw),
            "runner_template_schema": manifest["runner_template_schema"],
            "manifest_binding_sha256": manifest["manifest_binding_sha256"],
            "plan_sha256": _sha(plan_raw),
            "plan_disposition": "READY_TO_RUN",
        }
    )
    source_map_raw = json.dumps(
        source_map, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")
    descriptor.update(
        {
            "runner_sha256": _sha(runner_raw),
            "source_map_sha256": _sha(source_map_raw),
            "manifest_binding_sha256": manifest["manifest_binding_sha256"],
            "root": root,
            "runtime_namespace": runtime_namespace,
            "plan_disposition": "READY_TO_RUN",
        }
    )
    descriptor_raw = json.dumps(
        descriptor, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")
    binding = _r4_binding(descriptor, source_map)
    binding_sha256 = _sha(
        r6._R4._canonical_json(
            {
                "binding": binding,
                "command": list(base.command[:-1])
                + [_sha(base.command[-1].encode("utf-8"))],
                "cwd": base.cwd,
            }
        )
    )
    synthetic_base = dataclasses.replace(
        base,
        stdin_descriptor=descriptor_raw,
        source_map_bytes=source_map_raw,
        runner_bytes=runner_raw,
        binding=binding,
        binding_sha256=binding_sha256,
        plan_disposition="READY_TO_RUN",
    )
    r6._R4._validate_r4_prepared(synthetic_base)
    prepared = r6._from_r5(synthetic_base)

    for key, raw in (
        (descriptor["runner_path"], runner_raw),
        (descriptor["source_map_path"], source_map_raw),
    ):
        path = Path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    return prepared, descriptor, source_map, held


class _FakeScope:
    def __init__(self, held, events, *, fail_exit=False):
        self.held = held
        self.events = events
        self.fail_exit = fail_exit

    def __enter__(self):
        self.events.append("cuv2_scope_enter")
        return object(), object(), self.held

    def __exit__(self, *_args):
        self.events.append("cuv2_scope_exit")
        if self.fail_exit:
            raise OSError("fake postverify fault")
        return False


def _fake_cuv2(held, events, *, fail_exit=False):
    scope = _FakeScope(held, events, fail_exit=fail_exit)

    class Cuv2:
        @staticmethod
        def held_public_sources(public, software):
            events.append("cuv2_hold_requested")
            assert len(public) == 118
            assert len(software) == 36
            return scope

    return Cuv2


def _fake_outer_port(**_kwargs):
    document = {
        "schema": "iteration41.okx.m01.v6.root-prelaunch-result.r28.v1",
        "status": "UNSET",
        "reason": "root_prelaunch_unset",
        "case_id": "M01",
        "route_invocations": 0,
        "strict_cases_passed": 0,
        "suite_ready": False,
    }
    raw = json.dumps(
        document, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii") + b"\n"
    return {
        "stdout": raw,
        "stderr": b"",
        "returncode": 2,
        "reason": "synthetic_source_fake",
        "cleanup_clean": True,
        "source_custody_retained": False,
    }


def _install_fake_child_bottoms(monkeypatch, held, events, *, fail_exit=False):
    real_load = bootstrap._load_source
    cuv2 = _fake_cuv2(held, events, fail_exit=fail_exit)

    def load(raw, path, name):
        if name == "_iteration41_m01_r33_cuv2":
            return cuv2
        module = real_load(raw, path, name)
        if name == "_iteration41_m01_r33_runner":
            real_held_map = module._held_map

            def observed_held_map(value):
                events.append("real_154_held_map")
                return real_held_map(value)

            module._held_map = observed_held_map
            real_load_once = module._load_once

            def load_once(raw_once):
                once = real_load_once(raw_once)
                once.R28_TEST_OUTER_PORT = _fake_outer_port
                events.append("fake_outer_process_port_installed")
                return once

            module._load_once = load_once
        elif name == "_iteration41_m01_r33_held_outer":
            real_validator = module._validate_plan

            def observed_plan_validator(*args, **kwargs):
                events.append("real_plan_validator")
                try:
                    return real_validator(*args, **kwargs)
                except BaseException as exc:
                    events.append("real_plan_validator_exception_" + type(exc).__name__)
                    raise

            module._validate_plan = observed_plan_validator
        return module

    monkeypatch.setattr(bootstrap, "_load_source", load)


def _run_child(prepared, descriptor, held, monkeypatch, *, fail_exit=False):
    events = []
    _install_fake_child_bottoms(monkeypatch, held, events, fail_exit=fail_exit)
    output = io.StringIO()
    phase = io.BytesIO()
    code = bootstrap.run_descriptor(
        prepared.stdin_descriptor,
        stdout=output,
        phase_stream=phase,
    )
    return code, output.getvalue(), phase.getvalue(), events


def test_real_bootstrap_154_map_plan_gate_runner_and_finite_stage_frame(tmp_path, monkeypatch):
    prepared, descriptor, _source_map, held = _synthetic_full_prepared(tmp_path)

    code, output, phase, events = _run_child(prepared, descriptor, held, monkeypatch)

    assert output, (code, r6._parse_phase_frame(phase), events)
    result = json.loads(output)
    assert code == 0
    assert result["status"] == "OUTER_CAPTURED"
    assert result["reason"] == "r28_outer_candidate_captured"
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0
    assert phase == b"M01P1:DSHhPpRrVX\n"
    assert events.count("real_154_held_map") == 2
    assert events.count("real_plan_validator") == 1
    assert events.count("fake_outer_process_port_installed") == 1
    assert r6._parse_phase_frame(phase)["stage"] == "CHILD_CUV2_POSTVERIFY_REPORTED"
    assert r6._parse_phase_frame(phase)["verification"] == "UNVERIFIED"
    assert r6._parse_phase_frame(phase)["authority"] is False
    assert "provider" not in result


def test_held_map_and_plan_validator_failures_have_distinct_unverified_stages(tmp_path, monkeypatch):
    prepared, descriptor, _source_map, held = _synthetic_full_prepared(tmp_path)
    partial = {}
    code, output, phase, _events = _run_child(
        prepared, descriptor, partial, monkeypatch
    )
    assert code == 2 and output == ""
    stage = r6._parse_phase_frame(phase)
    assert stage["stage"] == "HELD_MAP_GATE_INCOMPLETE"
    assert stage["category"] == "UNEXPECTED_EXCEPTION"
    assert stage["verification"] == "UNVERIFIED"

    invalid, invalid_descriptor, _invalid_map, invalid_held = _synthetic_full_prepared(
        tmp_path / "invalid-plan", invalid_plan=True
    )
    events = []
    _install_fake_child_bottoms(monkeypatch, invalid_held, events)
    output = io.StringIO()
    phase_stream = io.BytesIO()
    code = bootstrap.run_descriptor(
        invalid.stdin_descriptor,
        stdout=output,
        phase_stream=phase_stream,
    )
    assert code == 2 and output.getvalue() == ""
    stage = r6._parse_phase_frame(phase_stream.getvalue())
    assert stage["stage"] == "PLAN_GATE_INCOMPLETE"
    assert stage["category"] == "UNEXPECTED_EXCEPTION"
    assert stage["verification"] == "UNVERIFIED"
    assert "real_plan_validator" in events


def test_safe_result_with_failed_child_postverify_stays_unpublished(tmp_path, monkeypatch):
    prepared, descriptor, _source_map, held = _synthetic_full_prepared(tmp_path)
    code, output, phase, events = _run_child(
        prepared, descriptor, held, monkeypatch, fail_exit=True
    )

    assert code == 2 and output == ""
    assert events[-1] == "cuv2_scope_exit", (phase, events)
    stage = r6._parse_phase_frame(phase)
    assert stage["stage"] == "CHILD_CUV2_POSTVERIFY_FAILED"
    assert stage["category"] == "CHILD_POSTVERIFY_FAILED"
    assert stage["verification"] == "UNVERIFIED"
    assert stage["authority"] is False


def test_phase_parser_rejects_unknown_trailing_oversize_and_secret_bytes():
    sentinel = b"private-provider-secret-sentinel"
    bad_frames = (
        b"M01P1:DSHhPpRrVX?\n",
        b"M01P1:DSHhPpRrVX\n" + sentinel,
        b"M01P1:DSHhPpRrVX" + sentinel + b"\n",
        b"M01P1:" + b"D" * r6.MAX_PHASE_FRAME_BYTES + b"\n",
        b"M01P1:DSHhPpRrVXD\n",
        b"M01P1:DU\n",
        b"M01P1:DSHQ\n",
        b"M01P1:DSHhPpRrVX\n\n",
    )
    for raw in bad_frames:
        summary = r6._parse_phase_frame(raw)
        assert summary == r6._unobserved_phase()
        assert sentinel.decode("ascii") not in repr(summary)


def test_clean_parent_malformed_phase_is_unobserved_and_raw_bytes_are_not_returned(
    tmp_path,
):
    prepared, _descriptor, _source_map, _held = _synthetic_full_prepared(tmp_path)
    adapter = r6.M01WindowsParentAdapter(
        prepared,
        scope_authenticator=lambda *_args: True,
        fake_leaves=True,
        native=object(),
        process_factory=lambda *_args, **_kwargs: None,
        launcher_module=launcher,
        image_module=image_observer,
        clock=time.monotonic,
        sleeper=time.sleep,
    )
    result_type = adapter._r5._inner._r32.ParentEnvelopeResult
    sentinel = b"private-sentinel"
    raw_result = result_type(
        schema="iteration41.okx.m01.external-parent-budget-result.r32.v1",
        status="CHILD_EXITED",
        reason="child_exit_observed",
        cleanup_reason="clean",
        child_returncode=2,
        stdout=sentinel,
        stderr=b"M01P1:D" + sentinel + b"\n",
        capture_complete=True,
        cleanup_complete=True,
        scope_released=True,
        scope_retained=False,
    )

    projected = adapter._project_parent_result(raw_result)
    summary = adapter.summarize_result(projected)

    assert projected.child_phase == r6._unobserved_phase()
    assert not hasattr(projected, "stdout") and not hasattr(projected, "stderr")
    assert sentinel.decode("ascii") not in repr(projected)
    assert sentinel.decode("ascii") not in repr(summary)
    assert summary["stdout_bytes"] == len(sentinel)
    assert summary["stderr_bytes"] == len(b"M01P1:D" + sentinel + b"\n")


def test_parent_deadline_expiry_withholds_phase_and_does_not_release_source_scope(
    tmp_path, monkeypatch
):
    prepared, _descriptor, _source_map, _held = _synthetic_full_prepared(tmp_path)
    clock = _FakeClock()
    source_scope = object()
    released = []
    launched = []
    parsed = []

    def expire_during_scope_authentication(scope, binding, timeout):
        assert scope is source_scope
        assert binding["phase_schema"] == r6.PHASE_SCHEMA
        assert timeout == r6.PARENT_TIMEOUT_SECONDS
        clock.sleep(r6.PARENT_TIMEOUT_SECONDS + 1.0)
        return True

    adapter = r6.M01WindowsParentAdapter(
        prepared,
        scope_authenticator=expire_during_scope_authentication,
        fake_leaves=True,
        native=object(),
        process_factory=lambda *_args, **_kwargs: launched.append(True),
        launcher_module=launcher,
        image_module=image_observer,
        clock=clock,
        sleeper=clock.sleep,
    )
    monkeypatch.setattr(r6, "_parse_phase_frame", lambda raw: parsed.append(raw))

    result = adapter.supervise(
        source_scope,
        lambda scope, _timeout: released.append(scope) or True,
    )
    summary = adapter.summarize_result(result)

    assert result.status == "CLEANUP_UNCERTAIN"
    assert result.reason == "parent_deadline_exhausted"
    assert result.scope_released is False
    assert result.scope_retained is True
    assert released == []
    assert launched == []
    assert parsed == []
    assert result.child_phase == r6._unobserved_phase()
    assert not hasattr(result, "stdout") and not hasattr(result, "stderr")
    assert summary["child_phase"] == r6._unobserved_phase()
    assert summary["stdout_bytes"] is None
    assert summary["stderr_bytes"] is None


class _BlockingPipe:
    def __init__(self):
        self._condition = threading.Condition()
        self._buffer = bytearray()
        self._closed = False

    @property
    def closed(self):
        with self._condition:
            return self._closed

    def feed(self, raw: bytes):
        with self._condition:
            self._buffer.extend(raw)
            self._condition.notify_all()

    def close(self):
        with self._condition:
            self._closed = True
            self._condition.notify_all()

    def read(self, maximum: int):
        with self._condition:
            while not self._buffer and not self._closed:
                self._condition.wait(0.1)
            if not self._buffer:
                return b""
            value = bytes(self._buffer[:maximum])
            del self._buffer[:maximum]
            return value


class _CapturingInput:
    def __init__(self, events):
        self.events = events
        self.payload = bytearray()
        self.closed = False

    def write(self, raw):
        self.events.append("descriptor_write")
        self.payload.extend(raw)
        return len(raw)

    def flush(self):
        self.events.append("descriptor_flush")
        return None

    def close(self):
        self.closed = True
        self.events.append("stdin_close")


class _BootstrapProcess:
    def __init__(self, kernel, command, events, run_child):
        self.pid = kernel.pid
        self._handle = 77
        self.returncode = None
        self.stdin = _CapturingInput(events)
        self.stdout = _BlockingPipe()
        self.stderr = _BlockingPipe()
        self.kernel = kernel
        self.command = tuple(command)
        self.events = events
        self._run_child = run_child

    def simulate_resume(self):
        assert self.stdin.closed is True
        self.events.append("fake_child_resume")
        output, phase = self._run_child(bytes(self.stdin.payload), self.command)
        self.stdout.feed(output.encode("ascii"))
        self.stderr.feed(phase)
        self.stdout.close()
        self.stderr.close()
        self.returncode = 0 if output else 2
        self.kernel.active_count = 0

    def poll(self):
        return self.returncode

    def wait(self, timeout=None):
        assert timeout is not None and timeout > 0
        self.events.append("wait")
        return self.returncode

    def kill(self):
        self.returncode = -9
        self.kernel.active_count = 0
        self.stdout.close()
        self.stderr.close()
        self.events.append("kill")


def test_r32_parent_fake_bottom_captures_phase_only_after_clean_release(tmp_path, monkeypatch):
    prepared, descriptor, _source_map, held = _synthetic_full_prepared(tmp_path)
    events = []
    kernel = _FakeKernel()
    kernel.events = events
    process_box = {}

    def resume_thread(_thread):
        events.append("resume")
        process_box["process"].simulate_resume()
        return 1

    kernel.functions["ResumeThread"] = resume_thread
    monkeypatch.setattr(launcher.C, "WinDLL", lambda *_args, **_kwargs: kernel)
    monkeypatch.setattr(image_observer.ctypes, "WinDLL", lambda *_args, **_kwargs: kernel)
    monkeypatch.setattr(image_observer.os, "name", "nt")
    monkeypatch.setattr(image_observer, "ROOT_NATIVE_ENABLED", False)
    native = launcher._WinJobNative()
    clock = _FakeClock()

    def run_child(payload, command):
        assert payload == prepared.stdin_descriptor
        assert command == prepared.command
        output = io.StringIO()
        phase = io.BytesIO()
        _install_fake_child_bottoms(monkeypatch, held, events)
        code = bootstrap.run_descriptor(
            payload, stdout=output, phase_stream=phase
        )
        assert code == 0
        return output.getvalue(), phase.getvalue()

    def process_factory(command, **_kwargs):
        assert tuple(command) == prepared.command
        process = _BootstrapProcess(kernel, command, events, run_child)
        process_box["process"] = process
        events.append("process_created_suspended")
        return process

    adapter = r6.M01WindowsParentAdapter(
        prepared,
        scope_authenticator=lambda scope, binding, _timeout: (
            scope is source_scope
            and binding["schema"]
            == "iteration41.okx.m01.r33.prepared-child-binding.r6.phase.v1"
            and binding["phase_schema"] == r6.PHASE_SCHEMA
            and binding["phase_max_bytes"] == r6.MAX_PHASE_FRAME_BYTES
        ),
        fake_leaves=True,
        native=native,
        process_factory=process_factory,
        launcher_module=launcher,
        image_module=image_observer,
        clock=clock,
        sleeper=clock.sleep,
    )
    source_scope = object()
    released = []

    result = adapter.supervise(
        source_scope,
        lambda scope, _timeout: released.append(scope) or True,
    )
    summary = adapter.summarize_result(result)

    assert result.status == "CHILD_EXITED", (
        result.status,
        result.reason,
        result.cleanup_reason,
        result.cleanup_complete,
        result.capture_complete,
        events,
    )
    assert result.child_returncode == 0
    assert result.capture_complete is True
    assert result.cleanup_complete is True
    assert result.scope_released is True
    assert released == [source_scope]
    assert summary["child_phase"]["stage"] == "CHILD_CUV2_POSTVERIFY_REPORTED"
    assert summary["child_phase"]["verification"] == "UNVERIFIED"
    assert summary["child_phase"]["authority"] is False
    assert summary["child_phase"]["strict_cases_passed"] == 0
    assert result.child_phase == summary["child_phase"]
    assert not hasattr(result, "stdout") and not hasattr(result, "stderr")
    assert events.index("process_created_suspended") < events.index("assign")
    assert events.index("assign") < events.index("descriptor_write")
    assert events.index("descriptor_write") < events.index("image_pid")
    assert events.index("image_path") < events.index("resume")
    assert events.index("resume") < events.index("real_154_held_map")


def test_uncertain_parent_result_never_parses_phase_or_releases_scope(tmp_path, monkeypatch):
    prepared, _descriptor, _source_map, _held = _synthetic_full_prepared(tmp_path)
    adapter = r6.M01WindowsParentAdapter(
        prepared,
        scope_authenticator=lambda *_args: True,
        fake_leaves=True,
        native=object(),
        process_factory=lambda *_args, **_kwargs: None,
        launcher_module=launcher,
        image_module=image_observer,
        clock=time.monotonic,
        sleeper=time.sleep,
    )
    result_type = adapter._r5._inner._r32.ParentEnvelopeResult
    uncertain = result_type(
        schema="iteration41.okx.m01.external-parent-budget-result.r32.v1",
        status="CLEANUP_UNCERTAIN",
        reason="parent_deadline_exhausted",
        cleanup_reason="cleanup_deadline_exhausted",
        child_returncode=None,
        stdout=b"do not inspect stdout",
        stderr=b"M01P1:DSHhPpRrVX\n",
        capture_complete=False,
        cleanup_complete=False,
        scope_released=False,
        scope_retained=True,
    )
    parsed = []
    monkeypatch.setattr(r6, "_parse_phase_frame", lambda _raw: parsed.append(True))

    summary = adapter.summarize_result(uncertain)

    assert parsed == []
    assert summary["child_phase"] == r6._unobserved_phase()
    assert summary["stdout_bytes"] is None
    assert summary["stderr_bytes"] is None
