"""Source-fake contracts for the additive R10 once/predeployment handoff."""

from __future__ import annotations

import contextlib
import ast
import dataclasses
import hashlib
import io
import json
import ntpath
import os
import stat
import sys
import types
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from scripts import iteration41_okx_m01_r30_root_startup_prepare_r1 as r30
from scripts import iteration41_okx_m01_r33_bootstrap_sidecar_transport_r9_r1 as r9
from scripts import iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1 as r10
from scripts import iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1 as r8
from scripts import iteration41_okx_m01_r33_runner_result_observer_r7_r2 as r7
from scripts import iteration41_okx_m01_r31_root_startup_prepare_r1 as r31
from scripts import iteration41_okx_m01_r34_plan_prepare_r1 as r34
from tests.unit.runtime import test_iteration41_okx_m01_r33_windows_parent_adapter_r6 as r6_tests
from tests.unit.runtime import test_iteration41_okx_m01_r31_root_startup_prepare_r1 as r31_tests


R34_HELPER_SHA256 = "9488be3f169232464f3939f439be0f015f757dbde6aa8278e801aec970cb9a4b"
R34_TEST_SHA256 = "e51256289b0b9b85af52212309a7fc17669fac287b920c4c5f688a0a97d652ec"


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _canonical(path: str) -> str:
    return ntpath.normcase(ntpath.normpath(str(path).replace("/", "\\")))


def _opaque_runtime_blob(repo, evidence_name, index_sha256, schema, member_name, member_sha256, size):
    opaque_root = (
        repo
        / "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence"
        / evidence_name
    )
    index_raw = r10._bounded_public(opaque_root / "index.json", 16 * 1024, index_sha256)
    metadata = json.loads(index_raw)
    assert metadata["schema"] == schema
    assert metadata["binary_execution_allowed"] is False
    assert metadata["native_import_allowed"] is False
    assert metadata["pe_parsing_allowed"] is False
    assert metadata["member"] == {
        "path": member_name,
        "sha256": member_sha256,
        "size_bytes": size,
    }
    raw = r10._bounded_public(opaque_root / member_name, size, member_sha256)
    assert len(raw) == size
    return opaque_root / member_name, raw


def _indexed_pyyaml_public_bindings(root, outer_values, manifest, held):
    """Resolve only the pinned R28 pure-YAML projection into already held public bytes."""
    package_index_sha = r10._source_literal(outer_values, "PACKAGE_INDEX_SHA256")
    record_sha = r10._source_literal(outer_values, "PYAML_MANIFEST_SHA256")
    package_index_rel = f"{r10.R28_PACKET_REL}/package/PACKAGE-INDEX.json"
    record_rel = f"{r10.R28_PACKET_REL}/package/pyyaml-installed-record-r5.json"

    def public_key(relative):
        return ntpath.normcase(ntpath.normpath(relative.replace("/", "\\"))).replace("\\", "/")

    def held_public(relative, expected_sha):
        assert manifest["public_pins"].get(public_key(relative)) == expected_sha
        key = _canonical(ntpath.join(manifest["root"], relative.replace("/", "\\")))
        raw = held.get(key)
        assert type(raw) is bytes and _sha(raw) == expected_sha
        return raw

    package_index = json.loads(held_public(package_index_rel, package_index_sha))
    record = json.loads(held_public(record_rel, record_sha))
    assert package_index["schema"] == "iteration41.okx.m01.v6.root-wrapper-package-index.r27.v1"
    assert len(package_index["members"]) == 38
    assert len(record["hashed_record_payloads"]) == 26
    projection_rel = "runtime/pyyaml-pure/PROJECTION.json"
    projection_member = package_index["members"][projection_rel]
    assert set(projection_member) == {"sha256", "size"}
    projection_package_rel = f"{r10.R28_PACKET_REL}/package/{projection_rel}"
    projection = json.loads(held_public(projection_package_rel, projection_member["sha256"]))
    assert projection["schema"] == "iteration41.okx.m01.pyyaml-pure-projection.v1"
    assert projection["native_extension_included"] is False
    assert projection["members"] == record["runtime_projection_members"]

    record_by_path = {item["path"]: item for item in record["hashed_record_payloads"]}
    sources = [
        {
            "runtime_path": item["runtime_path"],
            "package_member_rel": f"{projection['runtime_root']}/{item['runtime_path']}",
            "source_record_path": item["source_record_path"],
            "sha256": item["sha256"],
            "size": item["size"],
        }
        for item in projection["members"]
    ]
    license_item = projection["license"]
    license_member = package_index["members"][license_item["runtime_path"]]
    sources.append(
        {
            "runtime_path": license_item["runtime_path"],
            "package_member_rel": license_item["runtime_path"],
            "source_record_path": license_item["source_record_path"],
            "sha256": license_item["sha256"],
            "size": license_member["size"],
        }
    )

    software_by_key = {_canonical(path): path for path in manifest["software_pins"]}
    bindings = []
    for item in sources:
        source_record_path = item["source_record_path"]
        row = record_by_path[source_record_path]
        assert row["actual_sha256"] == item["sha256"]
        assert row["record_size"] == item["size"]
        package_member_rel = item["package_member_rel"]
        indexed = package_index["members"][package_member_rel]
        assert indexed == {"sha256": item["sha256"], "size": item["size"]}
        public_rel = f"{r10.R28_PACKET_REL}/package/{package_member_rel}"
        raw = held_public(public_rel, item["sha256"])
        assert len(raw) == item["size"]
        target = str(Path(record["site_packages_root"]) / source_record_path)
        target_key = _canonical(target)
        assert target_key in software_by_key
        bindings.append((software_by_key[target_key], public_rel, raw, item["sha256"], item["size"]))
    assert len(bindings) == 18
    assert len({_canonical(item[0]) for item in bindings}) == 18
    return bindings


def _ready_child(tmp_path):
    r6 = r6_tests.r6
    prepared_r6, _descriptor, _source_map, held = r6_tests._synthetic_full_prepared(tmp_path)
    root = Path(r31.__file__).resolve().parents[1]
    manifest = r10._manifest_from_runner(prepared_r6.runner_bytes)
    custody_path = manifest["runtime_helper_origins"]["custody"]["runtime_path"]
    fixed_sources = {
        _canonical(custody_path): (
            root
            / "docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/"
            "evidence/iteration41-cuv2-public-source-snapshot-r1-2026-10-08/cuv2-source.py",
            "e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246",
            2 * 1024 * 1024,
        )
    }
    outer_template_raw = r10._bounded_public(
        root / r10.R28_OUTER_TEMPLATE_REL,
        2 * 1024 * 1024,
        r10.R28_OUTER_TEMPLATE_SHA256,
    )
    outer_values = r10._source_assignments(outer_template_raw)
    python_source_path = r10._source_literal(outer_values, "PYTHON")
    python_source_sha = r10._source_literal(outer_values, "PYTHON_SHA256")
    python_blob_path, python_blob = _opaque_runtime_blob(
        root,
        "iteration41-m01-public-python-image-opaque-snapshot-r1-2026-10-08",
        "a7b7d8cce24046baaa069635b5c1332871f36dc75da087e0cb983e8133740559",
        "iteration41.m01.public-python-image-opaque-snapshot.r1",
        "python-image.bin.blob",
        python_source_sha,
        92160,
    )
    fixed_sources[_canonical(python_source_path)] = (
        python_blob_path,
        python_source_sha,
        92160,
    )
    python_dll_path = r10._source_literal(outer_values, "PYTHON_DLL")
    python_dll_sha = r10._source_literal(outer_values, "PYTHON_DLL_SHA256")
    python_dll_blob_path, _python_dll_blob = _opaque_runtime_blob(
        root,
        "iteration41-m01-public-python-dll-opaque-snapshot-r1-2026-10-08",
        "1d83ee3ae0309eb878ff20b2fff6f77d4be9f91e103345bd894f2482bded3f90",
        "iteration41.m01.public-python-dll-opaque-snapshot.r1",
        "python-dll.bin.blob",
        python_dll_sha,
        5991424,
    )
    fixed_sources[_canonical(python_dll_path)] = (
        python_dll_blob_path,
        python_dll_sha,
        5991424,
    )
    git_source_path = r10._source_literal(outer_values, "GIT_EXE")
    git_source_sha = r10._source_literal(outer_values, "GIT_EXE_SHA256")
    git_blob_path, _git_blob = _opaque_runtime_blob(
        root,
        "iteration41-m01-public-git-image-opaque-snapshot-r1-2026-10-08",
        "2e3206f529050e7fbb82523f4e4cd2e9f9fc05dd9d3b70c642d53e7acc24b981",
        "iteration41.m01.public-git-image-opaque-snapshot.r1",
        "git-image.bin.blob",
        git_source_sha,
        45048,
    )
    fixed_sources[_canonical(git_source_path)] = (git_blob_path, git_source_sha, 45048)
    public_fixed_bytes = {}
    for key, (path, expected_sha, maximum_size) in fixed_sources.items():
        raw = r10._bounded_public(path, maximum_size, expected_sha)
        assert _sha(raw) == expected_sha
        public_fixed_bytes[key] = raw

    software = dict(manifest["software_pins"])
    for path in list(software):
        key = _canonical(path)
        if key in public_fixed_bytes:
            raw = public_fixed_bytes[key]
            software[path] = _sha(raw)
            held[key] = raw
    for path, _public_rel, raw, digest, size in _indexed_pyyaml_public_bindings(
        root, outer_values, manifest, held
    ):
        assert len(raw) == size and _sha(raw) == digest
        key = _canonical(path)
        assert key in held
        software[path] = digest
        held[key] = raw
    manifest["software_pins"] = dict(sorted(software.items()))
    canonical_pins = dict(manifest["canonical_pins"])
    canonical_pins.update({_canonical(path): digest for path, digest in software.items()})
    manifest["canonical_pins"] = dict(sorted(canonical_pins.items()))
    r31._seal(manifest)
    r31._validate_manifest(manifest)
    runner_raw = r31.render_root_runner_template(manifest)

    source_map = json.loads(prepared_r6.source_map_bytes)
    source_map.update(
        {
            "public_pins": dict(manifest["public_pins"]),
            "software_pins": dict(manifest["software_pins"]),
            "canonical_pins": dict(manifest["canonical_pins"]),
            "map_counts": {"public": 118, "software": 36, "canonical": 154},
            "root": manifest["root"],
            "runtime_namespace": dict(manifest["runtime_namespace"]),
            "runner_template_sha256": _sha(runner_raw),
            "runner_template_schema": manifest["runner_template_schema"],
            "manifest_binding_sha256": manifest["manifest_binding_sha256"],
        }
    )
    source_map_raw = json.dumps(
        source_map, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")
    descriptor = json.loads(prepared_r6.stdin_descriptor)
    descriptor.update(
        {
            "runner_sha256": _sha(runner_raw),
            "source_map_sha256": _sha(source_map_raw),
            "manifest_binding_sha256": manifest["manifest_binding_sha256"],
            "runner_template_schema": manifest["runner_template_schema"],
        }
    )
    descriptor_raw = json.dumps(
        descriptor, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")
    r10._R9._R4._validate_descriptor(descriptor_raw)
    r10._R9._R4._validate_source_map(source_map_raw, descriptor)
    binding = r6_tests._r4_binding(descriptor, source_map)
    base = prepared_r6.r5_prepared
    binding_sha = _sha(
        r6._R4._canonical_json(
            {
                "binding": binding,
                "command": list(base.command[:-1])
                + [_sha(base.command[-1].encode("utf-8"))],
                "cwd": base.cwd,
            }
        )
    )
    synthetic_base = dataclasses.replace(
        base,
        stdin_descriptor=descriptor_raw,
        source_map_bytes=source_map_raw,
        runner_bytes=runner_raw,
        binding=binding,
        binding_sha256=binding_sha,
        plan_disposition="READY_TO_RUN",
    )
    r6._R4._validate_r4_prepared(synthetic_base)
    prepared_r6 = r6._from_r5(synthetic_base)
    prepared_r7 = r7._from_r5(prepared_r6.r5_prepared)
    prepared_r8 = r8._from_r7(prepared_r7)
    prepared_r9 = r9._from_r8(prepared_r8)
    prepared = r10._compose(prepared_r9)
    r10._validate_prepared(prepared)
    base_manifest = r10._manifest_from_runner(prepared.r9_prepared.runner_bytes)
    base_source_map = json.loads(prepared.r9_prepared.source_map_bytes)
    base_outer, active_wrapper = r10._r31_active_outputs(base_manifest, base_source_map)
    active_outer = r10._r10_active_outer_source(
        base_outer,
        active_wrapper,
        base_manifest,
        base_source_map["plan_sha256"],
        prepared.external_parent_sources,
    )
    namespace = base_manifest["runtime_namespace"]
    held[_canonical(namespace["self_path"])] = active_outer
    held[_canonical(namespace["active_wrapper_path"])] = active_wrapper
    return prepared, held


def _write_new(path: str, raw: bytes) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        assert stream.write(raw) == len(raw)
        stream.flush()
        os.fsync(stream.fileno())


def _predeploy_tmp_path_outputs(prepared, held):
    descriptor = json.loads(prepared.descriptor_json)
    namespace = descriptor["runtime_namespace"]
    Path(namespace["control_dir"]).mkdir(parents=True, exist_ok=True)
    Path(namespace["deployment_dir"]).mkdir(parents=True, exist_ok=True)
    dynamic = (
        (namespace["plan_path"], held[_canonical(namespace["plan_path"])]),
        (namespace["self_path"], held[_canonical(namespace["self_path"])]),
        (namespace["active_wrapper_path"], held[_canonical(namespace["active_wrapper_path"])]),
        (prepared.once_path, prepared.once_bytes),
        (descriptor["runner_path"], prepared.runner_bytes),
        (descriptor["source_map_path"], prepared.source_map_bytes),
    )
    for path, raw in dynamic:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    sidecar_addition = r9.create_bootstrap_sidecar(prepared.r9_prepared)
    assert sidecar_addition["entries"][prepared.sidecar_path]["sha256"] == prepared.sidecar_sha256
    return descriptor


def _source_scope(held, prepared, events):
    class Scope:
        def __init__(self, values):
            self.values = values

        def __enter__(self):
            events.append("nested_scope_enter")
            return object(), object(), self.values

        def __exit__(self, *_args):
            events.append("nested_scope_exit")
            return False

    class Custody:
        @staticmethod
        def held_public_sources(public, software):
            public_keys = set(public)
            requested = dict(public)
            requested.update(software)
            exact = {}
            external = {
                _canonical(path): raw
                for _name, path, raw, _digest, _role, _origin in prepared.external_parent_sources
            }
            for ordinal, (path, digest) in enumerate(requested.items()):
                key = _canonical(path)
                raw = prepared.once_bytes if key == _canonical(prepared.once_path) else held.get(key)
                if raw is None:
                    raw = external.get(key)
                if type(raw) is not bytes or _sha(raw) != digest:
                    suffix = Path(path).suffix.lower()
                    if suffix in {".exe", ".dll", ".pyd", ".so", ".dylib"}:
                        events.append(
                            (
                                "scope_hold_rejected",
                                "opaque_binary_sample_unavailable",
                                "software",
                                ordinal,
                            )
                        )
                        raise AssertionError
                    events.append(
                        (
                            "scope_hold_rejected",
                            "missing" if raw is None else "digest_mismatch",
                            "public" if path in public_keys else "software",
                            "external" if key in external else "held_map" if key in held else "other",
                            ordinal,
                        )
                    )
                    raise AssertionError
                exact[path] = raw
            events.append(("nested_scope_requested", len(public), len(software), len(exact)))
            return Scope(exact)

    return Custody


def _actual_r28_closure_verdict(prepared, held):
    """Run the generated R10 outer closure over only available fake held bytes."""
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    source_map = json.loads(prepared.source_map_bytes)
    namespace = manifest["runtime_namespace"]
    active_outer = held.get(_canonical(namespace["self_path"]))
    active_wrapper = held.get(_canonical(namespace["active_wrapper_path"]))
    if type(active_outer) is not bytes or type(active_wrapper) is not bytes:
        return "active_output_unavailable"
    module = types.ModuleType("_r10_actual_r28_closure_probe")
    module.__file__ = namespace["self_path"]
    exec(compile(active_outer, "<r10-active-r31-generated-source>", "exec", dont_inherit=True), module.__dict__)
    if module.ACTIVE_WRAPPER_SHA256 != _sha(active_wrapper):
        return "active_wrapper_constant_pin_mismatch"
    built = module._build_pin_sets(
        self_path=module.SELF_PATH,
        self_sha256=_sha(active_outer),
        plan_sha256=source_map["plan_sha256"],
    )
    public, software, package_index, r28_source_map, source_index, source_checkpoint, record, projection, _c01 = built
    requested = {}
    for relative, digest in public.items():
        path = str(Path(module.ROOT) / Path(*relative.split("/")))
        raw = held.get(_canonical(path))
        if type(raw) is bytes and _sha(raw) == digest:
            requested[path] = raw
    for path, digest in software.items():
        raw = held.get(_canonical(path))
        if type(raw) is bytes and _sha(raw) == digest:
            requested[path] = raw
    outer_template = held.get(_canonical(str(module.SELF_TEMPLATE_PATH)))
    assert type(outer_template) is bytes and _sha(outer_template) == public[module.SELF_TEMPLATE_REL]
    try:
        module._verify_held_closure(
            requested,
            package_index,
            r28_source_map,
            source_index,
            source_checkpoint,
            record,
            projection,
            outer_template_sha256=_sha(outer_template),
        )
    except BaseException as exc:
        code = getattr(exc, "code", None)
        if type(exc) is module.PrelaunchBlocked and type(code) is str:
            return code
        if type(exc) is KeyError:
            return "builtin_key_error"
        if type(exc) is AssertionError:
            return "builtin_assertion_error"
        return "other"
    return "returned"


class _FakePipe(io.BytesIO):
    pass


class _FakeProcess:
    def __init__(self, command, stdout_bytes, stderr_bytes, events):
        self.args = command
        self.stdout = _FakePipe(stdout_bytes)
        self.stderr = _FakePipe(stderr_bytes)
        self.returncode = 2
        self.was_forced = False
        self.events = events

    def wait(self, timeout=None):
        self.events.append("fake_process_wait")
        return self.returncode

    def poll(self):
        return self.returncode


class _FakeCapture:
    def __init__(self, events):
        self.files = {}
        self.events = events

    def write_bytes(self, name, raw):
        assert type(raw) is bytes
        self.files[name] = raw
        self.events.append("fake_capture_write")


class _FakePrivate:
    def __init__(self, events):
        self.events = events
        self.capture = _FakeCapture(events)

    def create_private_directory(self, path):
        self.events.append("fake_capture_directory")
        return self.capture


class _FakeCli:
    def __init__(self, tmp_path):
        self.tmp_path = tmp_path

    def _known_local_app_data(self):
        return self.tmp_path


def _install_once_bottom_fakes(once, held, prepared, tmp_path, events, stdout_bytes):
    real_load = once._load_module
    fake_private = _FakePrivate(events)
    fake_cli = _FakeCli(tmp_path)

    def observe(module, function_name):
        original = getattr(module, function_name)

        def wrapped(*args, **kwargs):
            events.append(("function_enter", function_name))
            try:
                value = original(*args, **kwargs)
            except BaseException as exc:
                code = getattr(exc, "code", None)
                if code not in {"pyyaml_record_payload", "pyyaml_record_file", "pyyaml_wheel_file"}:
                    code = "other"
                events.append(("function_raised", function_name, type(exc).__name__, code))
                raise
            events.append(("function_return", function_name))
            return value

        setattr(module, function_name, wrapped)

    def fake_popen(command, **_kwargs):
        events.append("fake_process_factory")
        return _FakeProcess(command, stdout_bytes, b"", events)

    fake_subprocess = types.SimpleNamespace(Popen=fake_popen)

    class FakeJob:
        def __init__(self):
            self._native = None
            self.was_forced = False
            self._process = None

        def __enter__(self):
            return self

        def spawn(self, command, **kwargs):
            events.append("fake_job_spawn")
            self._process = self.subprocess.Popen(command, **kwargs)
            return self._process

    class FakeCleanup:
        @staticmethod
        def _bounded_job_cleanup(
            job,
            bounded,
            *,
            cleanup_seconds,
            terminate,
            stdout,
            stderr,
            capture_complete,
            persist_partial,
        ):
            assert cleanup_seconds <= 5
            assert terminate is False
            assert capture_complete is True
            persist_partial()
            events.append("fake_cleanup_complete")
            return {
                "clean": True,
                "reason": "synthetic_source_fake_cleanup",
                "count": 0,
                "returncode": 2,
                "streams_closed": True,
                "job_closed": True,
                "persist_done": True,
                "persist_failed": False,
                "raw_capture_saved": True,
            }

    def load(raw, path, name):
        if name == "_r28_once_custody":
            return _source_scope(held, prepared, events)
        if name == "_r28_once_job":
            return types.SimpleNamespace(
                subprocess=fake_subprocess,
                _minimal_environment=lambda: {"SYSTEMROOT": "C:\\Windows"},
                _WindowsProcessJob=FakeJob,
            )
        if name == "_r28_once_cleanup":
            return FakeCleanup
        module = real_load(raw, path, name)
        if name == "_r28_once_active_outer":
            for function_name in (
                "_validate_plan",
                "_build_pin_sets",
                "_verify_held_closure",
            ):
                observe(module, function_name)
            events.append("real_plan_validator_module_loaded")
            module._load_exact_module = lambda raw_bytes, module_path, module_name: {
                "_r28_once_private": fake_private,
                "_r28_once_cli": fake_cli,
            }[module_name]
        return module

    once._load_module = load
    observe(once, "_prepare_active_sources")
    observe(once, "_execute_outer_process")


def _run_short_stub(prepared, held, tmp_path, monkeypatch, stdout_bytes):
    _predeploy_tmp_path_outputs(prepared, held)
    child = types.ModuleType("__main__")
    child.__file__ = "<r10-short-stub-source-fake>"
    output = io.StringIO()
    phase = io.BytesIO()
    events = []
    boxes = {}
    external_targets = {}
    external_root = tmp_path / "external-parent-sources"
    for name, path, raw, digest, role, origin in prepared.external_parent_sources:
        assert _sha(raw) == digest and len(raw) > 0 and role and origin
        target = external_root / (name + ".py")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        external_targets[_canonical(path)] = (target, name)
    original_path_open = Path.open

    def open_external_from_tmp_path(path, *args, **kwargs):
        selected = external_targets.get(_canonical(str(path)))
        if selected is not None:
            target, name = selected
            events.append(("external_source_read", name))
            return original_path_open(target, *args, **kwargs)
        return original_path_open(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", open_external_from_tmp_path)

    def load(raw, path, name):
        if name == "_iteration41_m01_r33_cuv2":
            return r6_tests._fake_cuv2(held, events)
        module = child._r10_real_load_source(raw, path, name)
        if name == "_iteration41_m01_r33_runner":
            boxes["runner"] = module
            real_held_map = module._held_map

            def observed_held_map(value):
                result = real_held_map(value)
                events.append("real_154_held_map")
                return result

            module._held_map = observed_held_map
            real_main = module.main

            def observed_main(*args, **kwargs):
                result = real_main(*args, **kwargs)
                events.append(("runner_main_return", type(result).__name__))
                events.append(("runner_result_safe", module._safe_result(result) is not None))
                if type(result) is dict:
                    events.append(
                        (
                            "runner_result_fields",
                            result.get("reason"),
                            result.get("disposition"),
                            result.get("inner_stage"),
                            result.get("inner_code"),
                        )
                    )
                return result

            module.main = observed_main
            real_load_once = module._load_once

            def load_once(raw_once):
                once = real_load_once(raw_once)
                assert _sha(raw_once) == prepared.once_sha256
                assert not hasattr(once, "R28_TEST_OUTER_PORT")
                events.append("real_r10_once_loaded")
                _install_once_bottom_fakes(
                    once, held, prepared, tmp_path, events, stdout_bytes
                )
                boxes["once"] = once
                return once

            module._load_once = load_once
        if name == "_iteration41_m01_r33_held_outer":
            real_plan_validator = module._validate_plan

            def observed_plan_validator(*args, **kwargs):
                events.append("real_plan_validator")
                return real_plan_validator(*args, **kwargs)

            module._validate_plan = observed_plan_validator
        return module

    def install_loader(frame, event, _arg):
        if (
            event == "call"
            and frame.f_code.co_name == "main"
            and frame.f_code.co_filename == prepared.sidecar_path
        ):
            child._r10_real_load_source = child._load_source
            child._load_source = load
            sys.settrace(None)
            return None
        return install_loader

    monkeypatch.setattr(sys, "stdin", types.SimpleNamespace(buffer=io.BytesIO(prepared.stdin_descriptor)))
    monkeypatch.setattr(sys, "stdout", output)
    monkeypatch.setattr(sys, "stderr", types.SimpleNamespace(buffer=phase))
    sys.settrace(install_loader)
    try:
        with pytest.raises(SystemExit) as raised:
            exec(compile(prepared.stub_bytes, "<r10-short-command>", "exec", dont_inherit=True), child.__dict__)
    finally:
        sys.settrace(None)
    return raised.value.code, output.getvalue(), phase.getvalue(), events, boxes


def test_prepare_binds_new_once_composer_runner_and_source_map_without_changing_154_map(tmp_path):
    prepared, _held = _ready_child(tmp_path)
    descriptor = json.loads(prepared.descriptor_json)
    source_map = json.loads(prepared.source_map_bytes)
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    addition = r10.parent_hold_addition(prepared)

    assert prepared.plan_disposition == "READY_TO_RUN"  # source-fake fixture only
    assert source_map["map_counts"] == {"public": 118, "software": 36, "canonical": 154}
    assert len(source_map["canonical_pins"]) == 154
    assert manifest["once"]["path"] == prepared.once_path
    assert manifest["once"]["sha256"] == prepared.once_sha256
    assert manifest["r10_once_predeployment"]["source_composer_path"] == prepared.composer_path
    assert manifest["r10_once_predeployment"]["source_composer_sha256"] == prepared.composer_sha256
    assert prepared.composer_bytes == Path(prepared.composer_path).read_bytes()
    assert _sha(prepared.composer_bytes) == prepared.composer_sha256
    assert descriptor["runner_sha256"] == _sha(prepared.runner_bytes)
    assert descriptor["source_map_sha256"] == _sha(prepared.source_map_bytes)
    assert prepared.windows_command_line_units == r9._command_line_units(prepared.command)
    assert prepared.windows_command_line_units <= r9.MAX_COMMAND_LINE_UNITS
    assert len(prepared.stdin_descriptor) <= r9.MAX_STDIN_BYTES
    assert len(addition["entries"]) == 18
    assert addition["entries"][prepared.once_path] == {
        "sha256": prepared.once_sha256,
        "size_bytes": len(prepared.once_bytes),
        "role": r10.R10_ONCE_ROLE,
    }
    assert addition["entries"][prepared.composer_path]["role"] == r10.R10_COMPOSER_ROLE
    assert addition["entries"][prepared.sidecar_path]["role"] == "r9_r8_bootstrap_sidecar"
    external = manifest["r10_once_predeployment"]["external_parent_sources"]
    expected_external_names = ["cli", "job", "cleanup"] + [
        spec[0] for spec in r10.R10_ACTIVATION_SOURCE_SPECS
    ]
    assert [item[0] for item in prepared.external_parent_sources] == expected_external_names
    assert len(external) == len(expected_external_names) == 13
    for item, (name, path, raw, digest, role, origin) in zip(
        external, prepared.external_parent_sources
    ):
        assert item == {
            "name": name,
            "path": path,
            "sha256": digest,
            "size_bytes": len(raw),
            "role": role,
            "origin": origin,
        }
        assert addition["entries"][path] == {
            "sha256": digest,
            "size_bytes": len(raw),
            "role": role,
            "origin": origin,
        }
    assert manifest["r10_once_predeployment"]["external_source_reader"]["checks"] == [
        "seek_to_offset_zero",
        "descriptor_identity_before_after",
        "exact_pinned_size",
        "exact_sha256",
    ]
    assert addition["canonical_child_map_count"] == 154


def test_parent_hold_addition_rejects_any_changed_predeployment_artifact(tmp_path):
    prepared, _held = _ready_child(tmp_path)
    addition = r10.parent_hold_addition(prepared)
    assert r10.verify_parent_hold_addition(prepared, addition)
    changed = json.loads(json.dumps(addition))
    changed["entries"][prepared.once_path]["sha256"] = "0" * 64
    assert not r10.verify_parent_hold_addition(prepared, changed)
    changed = json.loads(json.dumps(addition))
    changed["entries"][prepared.composer_path]["size_bytes"] += 1
    assert not r10.verify_parent_hold_addition(prepared, changed)
    extra_path = prepared.external_parent_sources[0][1]
    for field, replacement in (
        ("sha256", "0" * 64),
        ("size_bytes", 1),
        ("role", "wrong-role"),
        ("origin", "unbound-origin"),
    ):
        changed = json.loads(json.dumps(addition))
        changed["entries"][extra_path][field] = replacement
        assert not r10.verify_parent_hold_addition(prepared, changed)
    changed = json.loads(json.dumps(addition))
    del changed["entries"][extra_path]
    assert not r10.verify_parent_hold_addition(prepared, changed)
    changed = json.loads(json.dumps(addition))
    changed["entries"][extra_path + ".renamed"] = changed["entries"].pop(extra_path)
    assert not r10.verify_parent_hold_addition(prepared, changed)
    with pytest.raises(r10.OncePredeploymentBlocked):
        r10._once_successor_source(
            prepared.once_bytes + b"# mutation",
            r10._manifest_from_runner(prepared.runner_bytes),
            active_outer_size_bytes=1,
            active_wrapper_size_bytes=1,
            external_parent_sources=prepared.external_parent_sources,
        )


def test_external_sources_are_bound_to_fixed_ast_origins_and_pins():
    repo = r10._repo_root()
    base_once = r10._bounded_public(repo / r10.R28_ONCE_REL, r10.R10_MAX_ONCE_BYTES, r10.R28_ONCE_SHA256)
    outer_template = r10._bounded_public(
        repo / r10.R28_OUTER_TEMPLATE_REL,
        2 * 1024 * 1024,
        r10.R28_OUTER_TEMPLATE_SHA256,
    )
    root = str(repo)
    sources = r10._external_parent_sources(root, base_once, outer_template)
    assert [item[0] for item in sources] == ["cli", "job", "cleanup"] + [
        spec[0] for spec in r10.R10_ACTIVATION_SOURCE_SPECS
    ]
    assert all(item[2] and _sha(item[2]) == item[3] for item in sources)
    assert [item[5] for item in sources[:3]] == [
        "R28_ONCE.R28_CLI_HELPER_SHA256+R28_OUTER.CLI_REL+CLI_SHA256",
        "R28_ONCE.R28_JOB_PATH+R28_JOB_SHA256",
        "R28_ONCE.R28_CLEANUP_PATH+R28_CLEANUP_SHA256",
    ]
    assert [item[3] for item in sources[3:]] == [
        spec[2] for spec in r10.R10_ACTIVATION_SOURCE_SPECS
    ]
    assert [item[5] for item in sources[3:]] == [
        spec[3] for spec in r10.R10_ACTIVATION_SOURCE_SPECS
    ]

    wrong_outer = outer_template.replace(
        b'CLI_REL = "backtrader_runtime/certification_binance_roundtrip_r3_cli.py"',
        b'CLI_REL = "backtrader_runtime/not_the_pinned_cli.py"',
        1,
    )
    with pytest.raises(r10.OncePredeploymentBlocked):
        r10._external_parent_sources(root, base_once, wrong_outer)


def test_activation_regeneration_import_surface_is_standard_library_only():
    stdlib = sys.stdlib_module_names
    root = r10._repo_root()
    module_rows = [spec for spec in r10.R10_ACTIVATION_SOURCE_SPECS if spec[4] is not None]
    test_rows = [spec for spec in r10.R10_ACTIVATION_SOURCE_SPECS if spec[4] is None]
    assert len(module_rows) == 5
    assert len(test_rows) == 5
    for _name, relative, digest, _origin, _module_name in module_rows:
        raw = r10._bounded_public(root / relative, 2 * 1024 * 1024, digest)
        tree = ast.parse(raw.decode("utf-8"))
        imported_roots = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported_roots.update(alias.name.split(".", 1)[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module != "__future__":
                imported_roots.add((node.module or "").split(".", 1)[0])
        assert imported_roots <= stdlib
        assert not ({"pytest", "tests", "backtrader_runtime"} & imported_roots)
    assert all(module_name is None for _name, _rel, _digest, _origin, module_name in test_rows)
    assert {spec[0] for spec in module_rows} == {
        name for name, _rel, _digest, _origin, module_name in r10.R10_ACTIVATION_SOURCE_SPECS
        if module_name is not None
    }


def test_generated_bounded_source_reader_seeks_checks_size_hash_and_handle_stability(
    tmp_path, monkeypatch
):
    prepared, _held = _ready_child(tmp_path)
    module = types.ModuleType("_r10_external_reader_test")
    exec(compile(prepared.once_bytes, prepared.once_path, "exec", dont_inherit=True), module.__dict__)
    name, _source_path, raw, digest, _role, _origin = prepared.external_parent_sources[0]
    fixture = tmp_path / (name + "-reader.py")
    fixture.write_bytes(raw)
    original_open = Path.open

    def offset_open(path, *args, **kwargs):
        stream = original_open(path, *args, **kwargs)
        if Path(path) == fixture:
            stream.seek(3)
        return stream

    monkeypatch.setattr(Path, "open", offset_open)
    observed = module._r10_read_pinned_source(fixture, digest, len(raw), len(raw))
    assert observed == raw
    monkeypatch.setattr(Path, "open", original_open)

    fixture.write_bytes(b"x" * len(raw))
    with pytest.raises(ValueError, match="r10_external_source_pin"):
        module._r10_read_pinned_source(fixture, digest, len(raw), len(raw))
    fixture.write_bytes(raw + b"x")
    with pytest.raises(ValueError, match="r10_external_source_size"):
        module._r10_read_pinned_source(fixture, digest, len(raw), len(raw))
    with pytest.raises(ValueError, match="r10_external_source_unavailable"):
        module._r10_read_pinned_source(fixture.with_name("missing.py"), digest, len(raw), len(raw))

    fixture.write_bytes(raw)
    real_fstat = os.fstat
    count = 0

    def changed_fstat(fd):
        nonlocal count
        count += 1
        result = real_fstat(fd)
        if count == 1:
            return result
        return types.SimpleNamespace(
            st_dev=result.st_dev,
            st_ino=result.st_ino,
            st_size=result.st_size,
            st_mtime_ns=result.st_mtime_ns + 1,
            st_ctime_ns=result.st_ctime_ns,
        )

    monkeypatch.setattr(module.os, "fstat", changed_fstat)
    with pytest.raises(ValueError, match="r10_external_source_changed_during_read"):
        module._r10_read_pinned_source(fixture, digest, len(raw), len(raw))


def test_generated_once_uses_exact_held_sources_and_no_test_port_for_outer_process(tmp_path):
    prepared, held = _ready_child(tmp_path)
    source = prepared.once_bytes
    compile(source, prepared.once_path, "exec", dont_inherit=True)
    assert b"R28_TEST_OUTER_PORT" not in source
    assert b"_r10_held_bytes(root / R28_OUTER_REL)" in source
    assert b"_r10_held_bytes(R28_PLAN_PATH)" in source
    assert b"os.path.lexists(R28_CONTROL)" not in source
    assert b"os.path.lexists(R28_DEPLOYMENT)" not in source
    assert b"outer_module._validate_plan(plan_raw, now_utc=now)" in source
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    assert manifest["r10_once_predeployment"]["source_once_relative_path"] == r10.R28_ONCE_REL
    assert manifest["r10_once_predeployment"]["source_once_sha256"] == r10.R28_ONCE_SHA256
    assert manifest["r10_once_predeployment"]["path"] == prepared.once_path
    assert manifest["r10_once_predeployment"]["sha256"] == _sha(source)
    assert source != r10._bounded_public(
        r10._repo_root() / r10.R28_ONCE_REL,
        r10.R10_MAX_ONCE_BYTES,
        r10.R28_ONCE_SHA256,
    )
    namespace = json.loads(prepared.descriptor_json)["runtime_namespace"]
    active_outer = held[_canonical(namespace["self_path"])]
    assert b"_r30_predeployed_wrapper" in active_outer
    assert b"_r30_create_attempt_claim" in active_outer
    assert b"_r30_create_fresh_capture" in active_outer


def test_authorized_public_images_and_indexed_yaml_members_bind_to_software_keys(tmp_path):
    prepared, held = _ready_child(tmp_path)
    root = r10._repo_root()
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    outer_raw = r10._bounded_public(
        root / r10.R28_OUTER_TEMPLATE_REL,
        2 * 1024 * 1024,
        r10.R28_OUTER_TEMPLATE_SHA256,
    )
    outer_values = r10._source_assignments(outer_raw)
    software_by_key = {
        _canonical(path): digest for path, digest in manifest["software_pins"].items()
    }
    expected_images = (
        ("PYTHON", "PYTHON_SHA256", 92160),
        ("PYTHON_DLL", "PYTHON_DLL_SHA256", 5991424),
        ("GIT_EXE", "GIT_EXE_SHA256", 45048),
    )
    for path_name, digest_name, size in expected_images:
        path = r10._source_literal(outer_values, path_name)
        digest = r10._source_literal(outer_values, digest_name)
        key = _canonical(path)
        assert software_by_key[key] == digest
        assert len(held[key]) == size and _sha(held[key]) == digest

    custody_path = manifest["runtime_helper_origins"]["custody"]["runtime_path"]
    custody_key = _canonical(custody_path)
    assert len(held[custody_key]) == 2344
    assert _sha(held[custody_key]) == manifest["runtime_helper_origins"]["custody"]["sha256"]

    bindings = _indexed_pyyaml_public_bindings(root, outer_values, manifest, held)
    assert len(bindings) == 18
    assert {item[3] for item in bindings} == {
        item["actual_sha256"]
        for item in json.loads(
            held[
                _canonical(
                    ntpath.join(
                        manifest["root"],
                        f"{r10.R28_PACKET_REL}/package/pyyaml-installed-record-r5.json".replace(
                            "/", "\\"
                        ),
                    )
                )
            ]
        )["hashed_record_payloads"]
        if item["path"] == "pyyaml-6.0.1.dist-info/LICENSE"
        or (item["path"].startswith("yaml/") and not item["path"].endswith(".pyd"))
    }
    assert all(held[_canonical(path)] == raw for path, _rel, raw, _sha256, _size in bindings)
    assert not any(path.lower().endswith(".pyd") for path, _rel, _raw, _sha256, _size in bindings)


def test_git_opaque_sample_contract_rejects_path_digest_size_schema_and_index_drift(tmp_path):
    root = r10._repo_root()
    evidence_name = "iteration41-m01-public-git-image-opaque-snapshot-r1-2026-10-08"
    index_sha = "2e3206f529050e7fbb82523f4e4cd2e9f9fc05dd9d3b70c642d53e7acc24b981"
    schema = "iteration41.m01.public-git-image-opaque-snapshot.r1"
    blob_name = "git-image.bin.blob"
    digest = "134a3923dadcb35e4a017ea27cdeb3aa017c29e012a5566180866f37f9fbdf5f"
    with pytest.raises(AssertionError):
        _opaque_runtime_blob(root, evidence_name, index_sha, schema, "wrong.blob", digest, 45048)
    with pytest.raises(AssertionError):
        _opaque_runtime_blob(root, evidence_name, index_sha, schema, blob_name, "0" * 64, 45048)
    with pytest.raises(AssertionError):
        _opaque_runtime_blob(root, evidence_name, index_sha, schema, blob_name, digest, 45049)
    with pytest.raises(AssertionError):
        _opaque_runtime_blob(root, evidence_name, index_sha, "wrong-schema", blob_name, digest, 45048)
    with pytest.raises(r10.OncePredeploymentBlocked):
        _opaque_runtime_blob(root, evidence_name, "0" * 64, schema, blob_name, digest, 45048)


@pytest.mark.parametrize("tamper", ["missing", "renamed", "size", "digest"])
def test_real_r31_held_map_rejects_unheld_or_changed_git_image_pin(tmp_path, tamper):
    prepared, held = _ready_child(tmp_path)
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    outer_raw = r10._bounded_public(
        r10._repo_root() / r10.R28_OUTER_TEMPLATE_REL,
        2 * 1024 * 1024,
        r10.R28_OUTER_TEMPLATE_SHA256,
    )
    values = r10._source_assignments(outer_raw)
    git_path = r10._source_literal(values, "GIT_EXE")
    git_key = _canonical(git_path)
    altered = dict(held)
    raw = altered[git_key]
    if tamper == "missing":
        altered.pop(git_key)
    elif tamper == "renamed":
        altered.pop(git_key)
        altered[git_key + ".renamed"] = raw
    elif tamper == "size":
        altered[git_key] = raw + b"x"
    else:
        altered[git_key] = b"x" * len(raw)
    runner = {"__name__": "_r10_real_r31_held_map_test"}
    exec(compile(prepared.runner_bytes, "<r10-real-runner>", "exec", dont_inherit=True), runner)
    with pytest.raises(ValueError, match="held_source_(pin_mismatch|path_set_mismatch)"):
        runner["_held_map"]((None, None, altered))
    software_by_key = {
        _canonical(path): digest for path, digest in manifest["software_pins"].items()
    }
    assert runner["_expected_pins"]()[git_key] == software_by_key[git_key]


def test_short_stub_fails_closed_before_r28_closure_on_unavailable_public_pin(
    tmp_path, monkeypatch
):
    prepared, held = _ready_child(tmp_path)
    document = {
        "schema": "iteration41.okx.m01.v6.root-prelaunch-result.r28.v1",
        "status": "UNSET",
        "reason": "root_prelaunch_unset",
        "case_id": "M01",
        "route_invocations": 0,
        "strict_cases_passed": 0,
        "suite_ready": False,
    }
    stdout_bytes = json.dumps(document, sort_keys=True, separators=(",", ":")).encode("ascii") + b"\n"
    code, output, phase, events, boxes = _run_short_stub(
        prepared, held, tmp_path, monkeypatch, stdout_bytes
    )
    assert code == 2
    assert phase
    assert output == ""  # Frozen R7/R9 withholding remains in force on UNCERTAIN.
    assert "real_154_held_map" in events
    assert "real_plan_validator" in events, (output, phase, events)
    assert "real_r10_once_loaded" in events
    assert {event[1] for event in events if isinstance(event, tuple) and event[0] == "external_source_read"} == {
        "cli",
        "job",
        "cleanup",
    }
    scope_events = [
        event[:5]
        for event in events
        if isinstance(event, tuple)
        and event[0] in {"scope_hold_rejected", "nested_scope_requested", "nested_scope_enter"}
    ]
    assert any(
        event[0] == "scope_hold_rejected"
        and event[1] == "digest_mismatch"
        and event[2] == "public"
        for event in scope_events
    ), scope_events
    assert ("function_enter", "_verify_held_closure") not in events
    assert _actual_r28_closure_verdict(prepared, held) == "pyyaml_record_payload"
    assert ("runner_result_safe", True) in events
    assert "fake_job_spawn" not in events and "fake_process_factory" not in events
    assert "fake_cleanup_complete" not in events
    assert not hasattr(boxes["once"], "R28_TEST_OUTER_PORT")


def test_generated_r31_outer_keeps_frozen_r28_verifier_and_activation_binding(tmp_path):
    prepared, held = _ready_child(tmp_path)
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    source_map = json.loads(prepared.source_map_bytes)
    namespace = manifest["runtime_namespace"]
    active_outer = held[_canonical(namespace["self_path"])]
    active_wrapper = held[_canonical(namespace["active_wrapper_path"])]
    generated = types.ModuleType("_r10_generated_r31_outer_binding")
    generated.__file__ = namespace["self_path"]
    exec(compile(active_outer, "<r10-generated-r31-outer>", "exec", dont_inherit=True), generated.__dict__)

    root = r10._repo_root()
    frozen_outer = r10._bounded_public(
        root / r10.R28_OUTER_TEMPLATE_REL,
        2 * 1024 * 1024,
        r10.R28_OUTER_TEMPLATE_SHA256,
    )

    def function_node(raw, name):
        tree = ast.parse(raw.decode("utf-8"))
        matches = [
            node
            for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
        ]
        assert len(matches) == 1
        return ast.dump(matches[0], include_attributes=False)

    assert function_node(active_outer, "activate_wrapper") == function_node(
        frozen_outer, "activate_wrapper"
    )
    assert "_verify_held_closure" in generated.run_prelaunch.__code__.co_names
    assert "_r10_verify_r31_wrapper" in generated._verify_held_closure.__code__.co_names
    assert "activate_wrapper" not in generated._verify_held_closure.__code__.co_names
    assert generated.ACTIVE_WRAPPER_SHA256 == _sha(active_wrapper)

    wrapper_template = held[_canonical(str(generated.WRAPPER_TEMPLATE_PATH))]
    outer_template = held[_canonical(str(generated.SELF_TEMPLATE_PATH))]
    assert generated._r10_verify_r31_wrapper(
        held,
        active_wrapper,
        wrapper_template,
        outer_template,
        outer_template_sha256=_sha(outer_template),
    )
    assert _actual_r28_closure_verdict(prepared, held) == "pyyaml_record_payload"

    # The frozen callable still fails its historical R28 digest check; the
    # generated R10 outer uses the separate R31 regeneration gate above.
    with pytest.raises(generated.PrelaunchBlocked) as blocked:
        generated.activate_wrapper(wrapper_template, outer_template)
    assert blocked.value.code == "wrapper_activation_digest"


def test_held_r31_activation_verifier_rejects_output_namespace_plan_and_source_drift(tmp_path):
    prepared, held = _ready_child(tmp_path)
    manifest = r10._manifest_from_runner(prepared.runner_bytes)
    namespace = manifest["runtime_namespace"]
    active_outer = held[_canonical(namespace["self_path"])]
    active_wrapper = held[_canonical(namespace["active_wrapper_path"])]
    generated = types.ModuleType("_r10_activation_negative_gate")
    generated.__file__ = namespace["self_path"]
    exec(compile(active_outer, "<r10-activation-negative-gate>", "exec", dont_inherit=True), generated.__dict__)
    wrapper_template = held[_canonical(str(generated.WRAPPER_TEMPLATE_PATH))]
    outer_template = held[_canonical(str(generated.SELF_TEMPLATE_PATH))]
    kwargs = {"outer_template_sha256": _sha(outer_template)}

    with pytest.raises(generated.PrelaunchBlocked) as blocked:
        generated._r10_verify_r31_wrapper(
            held, active_wrapper + b"x", wrapper_template, outer_template, **kwargs
        )
    assert blocked.value.code == "r10_activation_held_wrapper_binding"

    altered = dict(held)
    altered.pop(_canonical(namespace["active_wrapper_path"]))
    with pytest.raises(generated.PrelaunchBlocked) as blocked:
        generated._r10_verify_r31_wrapper(
            altered, active_wrapper, wrapper_template, outer_template, **kwargs
        )
    assert blocked.value.code == "r10_activation_held_missing"

    altered = dict(held)
    plan_key = _canonical(namespace["plan_path"])
    altered[plan_key] = altered[plan_key] + b" "
    with pytest.raises(generated.PrelaunchBlocked) as blocked:
        generated._r10_verify_r31_wrapper(
            altered, active_wrapper, wrapper_template, outer_template, **kwargs
        )
    assert blocked.value.code == "r10_activation_plan_binding"

    row = generated.R10_ACTIVATION_SOURCE_ROWS[0]
    original_sha = row["sha256"]
    row["sha256"] = "0" * 64
    try:
        with pytest.raises(generated.PrelaunchBlocked) as blocked:
            generated._r10_verify_r31_wrapper(
                held, active_wrapper, wrapper_template, outer_template, **kwargs
            )
        assert blocked.value.code == "r10_activation_source_pin"
    finally:
        row["sha256"] = original_sha

    original_namespace = generated.R10_ACTIVATION_NAMESPACE
    generated.R10_ACTIVATION_NAMESPACE = dict(original_namespace)
    generated.R10_ACTIVATION_NAMESPACE["self_path"] += ".other"
    try:
        with pytest.raises(generated.PrelaunchBlocked) as blocked:
            generated._r10_verify_r31_wrapper(
                held, active_wrapper, wrapper_template, outer_template, **kwargs
            )
        assert blocked.value.code == "r10_activation_held_missing"
    finally:
        generated.R10_ACTIVATION_NAMESPACE = original_namespace


def test_r34_plan_and_r10_outer_binding_have_no_self_hash_cycle(tmp_path):
    assert _sha(Path(r34.__file__).read_bytes()) == R34_HELPER_SHA256
    r34_test_path = Path(__file__).with_name("test_iteration41_okx_m01_r34_plan_prepare_r1.py")
    assert _sha(r34_test_path.read_bytes()) == R34_TEST_SHA256
    candidate, held = _ready_child(tmp_path)
    candidate_manifest = r10._manifest_from_runner(candidate.runner_bytes)
    candidate_source_map = json.loads(candidate.source_map_bytes)
    candidate_namespace = candidate_manifest["runtime_namespace"]
    candidate_plan_raw = held[_canonical(candidate_namespace["plan_path"])]
    candidate_plan = json.loads(candidate_plan_raw)
    candidate_outer = held[_canonical(candidate_namespace["self_path"])]
    assert _sha(candidate_plan_raw) == candidate_source_map["plan_sha256"]
    assert candidate_plan["wrapper_sha256"] == candidate_manifest["candidate"]["active_wrapper_sha256"]
    assert not {"active_outer_sha256", "self_sha256"}.intersection(candidate_plan)
    assert candidate_manifest["software_pins"][_canonical(candidate_namespace["plan_path"])] == _sha(candidate_plan_raw)
    assert candidate_manifest["software_pins"][_canonical(candidate_namespace["self_path"])] == _sha(candidate_outer)
    assert _sha(candidate_outer).encode("ascii") not in candidate_plan_raw

    namespace = candidate_namespace
    seed = r31.prepare_root_startup(namespace, plan_sha256="a" * 64)
    now = datetime.now(timezone.utc).replace(microsecond=0)
    fmt = lambda value: value.isoformat().replace("+00:00", "Z")
    draft = r34.prepare_root_plan_draft(
        seed,
        activation_id=str(uuid.uuid4()),
        created_at_utc=fmt(now),
        expires_at_utc=fmt(now + timedelta(minutes=5)),
    )
    plan = json.loads(draft["plan_bytes"])
    final = draft["prepared_r31"]
    final_manifest = final["manifest"]
    final_outer = final["active_outer_source"]
    final_wrapper = final["active_wrapper_source"]
    plan_key = _canonical(namespace["plan_path"])
    self_key = _canonical(namespace["self_path"])

    assert plan["wrapper_sha256"] == _sha(final_wrapper)
    assert not {"active_outer_sha256", "self_sha256"}.intersection(plan)
    assert final_manifest["software_pins"][plan_key] == draft["plan_sha256"]
    assert final_manifest["software_pins"][self_key] == _sha(final_outer)
    assert final["active_outer_source"] == seed["active_outer_source"]

    transformed = r10._r10_active_outer_source(
        final_outer,
        final_wrapper,
        final_manifest,
        draft["plan_sha256"],
        _r10_sources_for_cycle_check(),
    )
    generated = types.ModuleType("_r10_plan_cycle_outer")
    exec(
        compile(transformed, "<r10-plan-cycle-outer>", "exec", dont_inherit=True),
        generated.__dict__,
    )
    assert generated.R10_ACTIVATION_PLAN_SHA256 == draft["plan_sha256"]
    assert _sha(transformed) != _sha(final_outer)
    assert _sha(transformed).encode("ascii") not in draft["plan_bytes"]


def _r10_sources_for_cycle_check():
    """Get the exact already-pinned public source tuple used by R10 prepare."""
    root = r10._verify_chain()
    once_raw = r10._bounded_public(
        root / r10.R28_ONCE_REL, r10.R10_MAX_ONCE_BYTES, r10.R28_ONCE_SHA256
    )
    outer_raw = r10._bounded_public(
        root / r10.R28_OUTER_TEMPLATE_REL,
        2 * 1024 * 1024,
        r10.R28_OUTER_TEMPLATE_SHA256,
    )
    return r10._external_parent_sources(str(root), once_raw, outer_raw)


def test_actual_main_rejects_changed_external_helper_bytes_before_spawn(tmp_path, monkeypatch):
    prepared, held = _ready_child(tmp_path)
    document = {
        "schema": "iteration41.okx.m01.v6.root-prelaunch-result.r28.v1",
        "status": "UNSET",
        "reason": "root_prelaunch_unset",
        "case_id": "M01",
        "route_invocations": 0,
        "strict_cases_passed": 0,
        "suite_ready": False,
    }
    stdout_bytes = json.dumps(document, sort_keys=True, separators=(",", ":")).encode("ascii") + b"\n"
    descriptor = json.loads(prepared.descriptor_json)
    _predeploy_tmp_path_outputs(prepared, held)
    child = types.ModuleType("__main__")
    child.__file__ = "<r10-unheld-source-fake>"
    output = io.StringIO()
    phase = io.BytesIO()
    events = []
    external_targets = {}
    external_root = tmp_path / "external-parent-sources-tamper"
    for name, path, raw, _digest, _role, _origin in prepared.external_parent_sources:
        target = external_root / (name + ".py")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw + (b" " if name == "job" else b""))
        external_targets[_canonical(path)] = (target, name)
    original_path_open = Path.open

    def open_tampered_external(path, *args, **kwargs):
        selected = external_targets.get(_canonical(str(path)))
        if selected is not None:
            target, name = selected
            events.append(("external_source_read", name))
            return original_path_open(target, *args, **kwargs)
        return original_path_open(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", open_tampered_external)

    def load(raw, path, name):
        if name == "_iteration41_m01_r33_cuv2":
            return r6_tests._fake_cuv2(held, events)
        module = child._r10_real_load_source(raw, path, name)
        if name == "_iteration41_m01_r33_runner":
            real_held_map = module._held_map
            module._held_map = lambda value: (events.append("real_154_held_map"), real_held_map(value))[1]
            real_load_once = module._load_once

            def load_once(raw_once):
                once = real_load_once(raw_once)
                _install_once_bottom_fakes(once, held, prepared, tmp_path, events, stdout_bytes)
                return once

            module._load_once = load_once
        if name == "_iteration41_m01_r33_held_outer":
            real_validate = module._validate_plan
            module._validate_plan = lambda *args, **kwargs: (
                events.append("real_plan_validator"), real_validate(*args, **kwargs)
            )[1]
        return module

    def install_loader(frame, event, _arg):
        if event == "call" and frame.f_code.co_name == "main" and frame.f_code.co_filename == prepared.sidecar_path:
            child._r10_real_load_source = child._load_source
            child._load_source = load
            sys.settrace(None)
            return None
        return install_loader

    monkeypatch.setattr(
        sys,
        "stdin",
        types.SimpleNamespace(buffer=io.BytesIO(prepared.stdin_descriptor)),
    )
    monkeypatch.setattr(sys, "stdout", output)
    monkeypatch.setattr(sys, "stderr", types.SimpleNamespace(buffer=phase))
    sys.settrace(install_loader)
    try:
        with pytest.raises(SystemExit) as raised:
            exec(compile(prepared.stub_bytes, "<r10-short-command-tampered-source>", "exec"), child.__dict__)
    finally:
        sys.settrace(None)
    assert raised.value.code == 2
    assert "real_154_held_map" in events and "real_plan_validator" in events
    assert ("external_source_read", "job") in events
    assert "fake_process_factory" not in events and "fake_job_spawn" not in events
    if output.getvalue():
        result = json.loads(output.getvalue().strip())
        assert result.get("disposition") != "OUTER_CAPTURED"


def test_r30_predeployment_gate_rejects_acl_identity_and_wrapper_hash_mismatch(tmp_path):
    prepared, held = _ready_child(tmp_path)
    descriptor = json.loads(prepared.descriptor_json)
    namespace = descriptor["runtime_namespace"]
    control = Path(namespace["control_dir"])
    deployment = Path(namespace["deployment_dir"])
    control.mkdir(parents=True, exist_ok=True)
    deployment.mkdir(parents=True, exist_ok=True)
    _write_new(namespace["plan_path"], held[_canonical(namespace["plan_path"])])
    _write_new(namespace["self_path"], held[_canonical(namespace["self_path"])])
    wrapper_path = namespace["active_wrapper_path"]
    _write_new(wrapper_path, held[_canonical(wrapper_path)])

    outer_source = held[_canonical(namespace["self_path"])]
    outer = {"__name__": "_r10_r30_gate_fixture"}
    exec(compile(outer_source, namespace["self_path"], "exec", dont_inherit=True), outer)
    r30_test_api = __import__(
        "tests.unit.runtime.test_iteration41_okx_m01_r30_root_startup_prepare_r1",
        fromlist=["_FakeApi"],
    )
    fake_api = r31_tests._FakeApi()
    private = r30_test_api._FakePrivate(fake_api)
    cli = r31_tests._FakeCli()
    sid = "source-fake-sid"
    exact_held = {str(Path(wrapper_path)): held[_canonical(wrapper_path)]}

    denied = r31_tests._FakeApi()
    denied.deny_acl.add(str(deployment))
    with contextlib.ExitStack() as stack:
        with pytest.raises(PermissionError):
            outer["_r30_predeployed_wrapper"](
                r30_test_api._FakePrivate(denied), cli, denied, sid, stack, exact_held
            )

    class IdentityApi(r31_tests._FakeApi):
        def __init__(self):
            super().__init__()
            self.flip_at = {}
            self.calls = {}

        def info(self, handle, *, directory=False):
            value = super().info(handle, directory=directory)
            key = os.path.normcase(str(Path(handle.path)))
            self.calls[key] = self.calls.get(key, 0) + 1
            if self.calls[key] >= self.flip_at.get(key, 10**9):
                return value + ("changed",)
            return value

    identity = IdentityApi()
    identity.flip_at[os.path.normcase(str(deployment))] = 2
    with contextlib.ExitStack() as stack:
        with pytest.raises(outer["PrelaunchBlocked"]) as changed:
            outer["_r30_predeployed_wrapper"](
                r30_test_api._FakePrivate(identity), cli, identity, sid, stack, exact_held
            )
    assert changed.value.code == "deployment_identity_changed"

    valid = r31_tests._FakeApi()
    with contextlib.ExitStack() as stack:
        bindings = outer["_r30_predeployed_wrapper"](
            r30_test_api._FakePrivate(valid), cli, valid, sid, stack, exact_held
        )
        Path(wrapper_path).write_bytes(b"tampered wrapper bytes")
        with pytest.raises(outer["PrelaunchBlocked"]) as mismatch:
            outer["_r30_verify_deployment"](
                r30_test_api._FakePrivate(valid), cli, valid, sid, exact_held, bindings
            )
    assert mismatch.value.code == "deployment_wrapper_pin"


def test_r10_held_lookup_and_generated_map_reject_path_or_payload_drift(tmp_path):
    prepared, held = _ready_child(tmp_path)
    once = types.ModuleType("_r10_held_lookup_test")
    exec(compile(prepared.once_bytes, prepared.once_path, "exec", dont_inherit=True), once.__dict__)
    once.R10_HELD_MAP = held
    namespace = json.loads(prepared.descriptor_json)["runtime_namespace"]
    expected = held[_canonical(namespace["active_wrapper_path"])]
    assert once._r10_held_bytes(Path(namespace["active_wrapper_path"])) == expected
    with pytest.raises(ValueError):
        once._r10_held_bytes(Path(namespace["active_wrapper_path"]) / ".." / "missing.py")

    wrong_held = dict(held)
    wrong_held[_canonical(namespace["active_wrapper_path"])] = b"wrong"
    with pytest.raises(ValueError, match="held_source_pin_mismatch"):
        runner = {"__name__": "_r10_runner_map_reject"}
        exec(compile(prepared.runner_bytes, "<r10-runner-map>", "exec"), runner)
        runner["_held_map"]((None, None, wrong_held))
