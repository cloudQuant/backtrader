"""PUBLIC R23 Root-driver draft; source-bound zero-write M01 diagnostic only."""
from pathlib import Path
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.machinery
import json
import math
import ntpath
import sys
import time
import types
import uuid

ROOT=Path('D:/source_code/backtrader')
E=ROOT/'docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence'
CU=Path('D:/temp/iteration41-root-public-custody-v2.py')
CU_SHA='e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246'
R31=ROOT/'scripts/iteration41_okx_m01_r31_root_startup_prepare_r1.py'
R31_SHA='c95f72c6d168352893339bad5f53e5f48e5b201219a30de8b2de6d90f50e441a'
R34=ROOT/'scripts/iteration41_okx_m01_r34_plan_prepare_r1.py'
R34_SHA='9488be3f169232464f3939f439be0f015f757dbde6aa8278e801aec970cb9a4b'
R13_READBACK=E/'iteration41-m01-r33-r13-root-public-readback-r1-2026-10-08/observation.json'
R13_READBACK_SHA='87e606164f2a3f1ac21213942cc417863ae2a8e8a5e8e315ec26ca93b1ba669b'
ADAPTER=ROOT/'scripts/iteration41_okx_m01_r33_active_outer_activation_r13_r1.py'
ADAPTER_SHA='23c98a7d0012499050309f3dcdd8cd8f2710698867654776125e8a3d9a1fe580'
R14_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_parent_adapter_transport_r14_r1.py'
R14_HELPER_SHA='fe2bd4fc008680fe5dc9099d0cb6782e4071070bf5ab259b53c3e763b6c413ef'
R15_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_final_output_hold_r15_r1.py'
R15_HELPER_SHA='7cc20345462859b92ddfe843caded7935ece3a759f8eff5a8371c10c7d94e79f'
R16_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_final_output_hold_r16_r1.py'
R16_HELPER_SHA='06e61947222e8639b700a8749c083d35e82202366b6c7105a354c8a7ff1b8e78'
R17_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_source_map_gate_r17_r1.py'
R17_HELPER_SHA='cb05433078bddcd779914c6eb0e9b99d942b3e1a55d5fb39e756928f3249fc5f'
R18_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_parent_adapter_constructor_r18_r1.py'
R18_HELPER_SHA='f9dd76909adeff5b0f6e76a9664c427b213e10a2915109e1f7dda32b1ea47902'
R19_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_child_source_scope_r19_r1.py'
R19_HELPER_SHA='424edf3aecc997f36bbe9ba713c3278b594132016ab893164ecf822d734aa1d4'
R20_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_child_entry_path_r20_r1.py'
R20_HELPER_SHA='18b47fd4681a59418f54cead5133e7a853b1db64acdfc144aafba23640c6180a'
R21_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_child_main_map_r21_r1.py'
R21_HELPER_SHA='02bc37a707093ed1afd9c7befcb167cccf1820a242e821357bba83f3b18aa770'
R22_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_root_prepare_r22_r1.py'
R22_HELPER_SHA='81f72804244407b1ef010ee9361b030980923c758624a4e1ced35fcd7162bf9b'
R23_HELPER=ROOT/'scripts/iteration41_okx_m01_r33_root_reason_class_r23_r1.py'
R23_HELPER_SHA='b6cb9226638d4394ee443a439499dada034aeca6213b8886f09c3afd438e7bda'
R7_READBACK=E/'iteration41-m01-r33-r9-root-public-readback-r1-2026-10-08/observation.json'
R7_READBACK_SHA='968d0cd4594ec8896ab9d6aa6b84c64cbafe11f8b44be45346c6e86705907555'
R34_READBACK=E/'iteration41-m01-r34-root-public-readback-r1-2026-10-08/observation.json'
R34_READBACK_SHA='84ebb9dfdc072876240e680098756e9a09bb64f72974ddfa8bbea69a9af98295'
OUT=E/'iteration41-m01-r33-r23-root-actual-parent-diagnostic-r1-2026-10-08'
RootGoalAuthorizesOkxM01ZeroWriteLocalDiagnostic=True
KEEPALIVE=[]
root_phase_seconds={}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def key(path):return ntpath.normcase(ntpath.normpath(str(path)))
def finish_phase(name,started):
 elapsed=time.monotonic()-started
 assert math.isfinite(elapsed) and elapsed>=0
 root_phase_seconds[name]=round(elapsed,6)
def bounded_child_summary(summary):
 out={'child_returncode':None,'child_returncode_observed':False,'child_cleanup_complete':None,'child_scope_released':None,'child_scope_retained':None}
 if type(summary) is not dict:return out
 code=summary.get('child_returncode')
 if type(code) is int and 0<=code<=255:
  out['child_returncode']=code;out['child_returncode_observed']=True
 for field in ('cleanup_complete','scope_released','scope_retained'):
  value=summary.get(field)
  if type(value) is bool:out['child_'+field]=value
 return out
def bounded_r23_reason_class(summary,binding,schema):
 out={'schema':schema,'status':'UNOBSERVED','category':'UNOBSERVED','reason_class_ordinal':None,'reason_class_form':'UNOBSERVED','reason_table_sha256':None,'authority':False}
 if binding is None:return out
 out['reason_table_sha256']=binding.reason_table_sha256
 phase=summary.get('child_phase') if type(summary) is dict else None
 candidate=phase.get('reason_class_result') if type(phase) is dict else None
 returned=phase.get('returned_result') if type(phase) is dict else None
 if type(candidate) is not dict or type(returned) is not dict:return out
 fields={'schema','status','category','reason_class_ordinal','reason_class_form','reason_table_sha256','authority'}
 if set(candidate)!=fields or candidate.get('schema')!=schema or candidate.get('reason_table_sha256')!=binding.reason_table_sha256 or candidate.get('authority') is not False:return out
 if any(returned.get(field)!=candidate.get(field) for field in ('reason_class_schema','reason_class_status','reason_class_category','reason_class_ordinal','reason_class_form','reason_class_table_sha256')):return out
 ordinal=candidate.get('reason_class_ordinal');status=candidate.get('status');category=candidate.get('category');form=candidate.get('reason_class_form')
 if type(ordinal) is not int or type(status) is not str or type(category) is not str or type(form) is not str:return out
 if status=='OBSERVED_UNKNOWN_REASON_CLASS' and category=='UNKNOWN' and ordinal==0 and form=='UNKNOWN':
  return {'schema':schema,'status':status,'category':category,'reason_class_ordinal':0,'reason_class_form':form,'reason_table_sha256':binding.reason_table_sha256,'authority':False}
 if status=='OBSERVED_SOURCE_LITERAL_REASON_CLASS' and category=='EXACT_SOURCE_LITERAL' and 1<=ordinal<=len(binding.reason_table) and form in {'DIRECT_LITERAL','CHILD_PREFIX_LITERAL'}:
  return {'schema':schema,'status':status,'category':category,'reason_class_ordinal':ordinal,'reason_class_form':form,'reason_table_sha256':binding.reason_table_sha256,'authority':False}
 return out
def exact(path,pin):
 path=Path(path);assert path.name.lower() not in {'.env','config.yaml','secrets.yaml','stdout.raw','stderr.raw'}
 before=path.stat();assert 0<before.st_size<=128*1024*1024
 with path.open('rb') as stream:raw=stream.read(before.st_size+1)
 after=path.stat();assert len(raw)==before.st_size and (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
 assert sha(raw)==pin,'public_software_pin_mismatch';return raw
def load(raw,path,name):
 m=types.ModuleType(name);m.__file__=str(path);m.__spec__=importlib.machinery.ModuleSpec(name,loader=None,origin=str(path));sys.modules[name]=m
 exec(compile(raw,str(path),'exec',dont_inherit=True),m.__dict__);return m
def _r14_prestart_cleanup(main_scope,extra_scope,main_retained,extra_retained,main_entered,extra_entered,main_postverified,extra_postverified):
 attempted=False
 if main_retained and main_entered:
  attempted=True
  try:main_scope.__exit__(None,None,None)
  except BaseException:pass
  else:main_retained=False;main_postverified=True
 if extra_retained and extra_entered:
  attempted=True
  try:extra_scope.__exit__(None,None,None)
  except BaseException:pass
  else:extra_retained=False;extra_postverified=True
 complete=not main_retained and not extra_retained
 return main_retained,extra_retained,main_postverified,extra_postverified,attempted,complete
assert sys.version_info[:3]==(3,11,5) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
assert key(sys.executable)==key('C:/anaconda3/python.exe') and RootGoalAuthorizesOkxM01ZeroWriteLocalDiagnostic is True
assert not OUT.exists()
r7read=json.loads(exact(R7_READBACK,R7_READBACK_SHA))
r34read=json.loads(exact(R34_READBACK,R34_READBACK_SHA))
extra={key(path):pin for path,pin in r7read['public_context_pins'].items()}
extra.update({key(R7_READBACK):R7_READBACK_SHA,key(R34_READBACK):R34_READBACK_SHA,key(CU):CU_SHA,
 key(R31):R31_SHA,key(R34):R34_SHA,key(ADAPTER):ADAPTER_SHA,key(R14_HELPER):R14_HELPER_SHA,key(R15_HELPER):R15_HELPER_SHA,key(R16_HELPER):R16_HELPER_SHA,key(R17_HELPER):R17_HELPER_SHA,key(R18_HELPER):R18_HELPER_SHA,key(R19_HELPER):R19_HELPER_SHA,key(R20_HELPER):R20_HELPER_SHA,
 key(R21_HELPER):R21_HELPER_SHA,key(R22_HELPER):R22_HELPER_SHA,key(R23_HELPER):R23_HELPER_SHA,
 key(R13_READBACK):R13_READBACK_SHA,key(Path(__file__)):sha(Path(__file__).read_bytes())})
extra.update({key(E/'iteration41-okx-m01-v6-r34-plan-draft-source-fake-r1-2026-10-08'/name):pin for name,pin in r34read['packet_pins'].items()})
extra.update({key(E/'iteration41-okx-m01-v6-r34-plan-draft-independent-review-r1-2026-10-08'/name):pin for name,pin in r34read['review_pins'].items()})
extra[key(ROOT/'backtrader_runtime/certification_roundtrip_private.py')]='b866194bdc56d91cc7a6678e83b0af8e4e018ee53a2c136325344c2ee8a5ecfd'
extra[key(ROOT/'backtrader_runtime/certification_binance_roundtrip_r3_cli.py')]='62b96a9040d530c8ec592471f0595154fb60239ca03bd6d3b56a6c094dfc7c76'
r10packet=E/'iteration41-okx-m01-r33-once-predeployment-handoff-source-fake-r10-r1-2026-10-08'
r10review=E/'iteration41-okx-m01-r33-once-predeployment-handoff-independent-review-r10-r2-2026-10-08'
r10packet_pins={'README.md':'73fbe6398fe23f56f9ee93b3bdbcdeb8a9092d7f2974852ac8748f02cd5c37ce','index.json':'70305207ad756230df7411c35654c00bfa53a776f9caad51fcee16b29e3ad1db','checkpoint.json':'587d6c5197db1b9d8b213b4f9991b11906019178c685d801a890708badbba08f','qa-summary.json':'35ac337366ae108d6ecc2cc8d399147eea3e4796fd3ddeb1d15908f0c478eff6','source-fake-bundle.zip':'aed3195e1e6ef71752aa35e019e370b3642405b4d1d6cbb9c2d5d9fdd897aab3','author-packet.json':'6ffecbdc9944088c5457c5bbcf92b8d32b03f91883f8066576598639f3f402f6'}
r10review_pins={'README.md':'f89cc6b1c7f0d57b35aa7d6a02866fa39a9482a87bab92937664fc45a2c72466','review.json':'05a746a0bddad8da0aae4a856b8dd2b692701c0129ac53d665eff22f5f950985','review-index.json':'afbef347196ff8832ad589fadda0a6ccbbb8db7bc567631e1ea86a050b57f5da','review-checkpoint.json':'6e19280e7bcd2033d5141029c0460106c10dedb9a40eeb845f246d230fbfe087','review-bundle.zip':'ccc13699ce6bfc2d790643cf5c6d1ed171899bf62a6a66c5306e9bd705df63c2'}
def add_extra(path,pin):
 k=key(path);assert k not in extra or extra[k]==pin
 extra[k]=pin
for directory,pins in ((r10packet,r10packet_pins),(r10review,r10review_pins)):
 for name,pin in pins.items():add_extra(directory/name,pin)
add_extra(E/'iteration41-okx-m01-r10-root-public-readback-r1-2026-10-08/observation.json','9c6ef26949ff199742e0bd12145fbd903641b65c364249b659516872b498ccf8')
r10index=json.loads(exact(r10packet/'index.json',r10packet_pins['index.json']))
indexed_paths=set()
for category in ('canonical_source_files','activation_regeneration_sources','additional_parent_hold_sources','r34_plan_cycle_test_dependencies'):
 for row in r10index[category]:
  path=ROOT/row.get('repo_relative_path',row['path'])
  assert path.is_relative_to(ROOT) and path.name.lower() not in {'.env','config.yaml','secrets.yaml','stdout.raw','stderr.raw'}
  add_extra(path,row['sha256']);indexed_paths.add(key(path))
assert len(indexed_paths)==17

r11packet=E/'iteration41-okx-m01-r33-returned-result-source-fake-r11-r1-2026-10-08'
r11review=E/'iteration41-okx-m01-r33-returned-result-independent-review-r11-r1-2026-10-08'
r11packet_pins={'README.md': '6e95ff2b62980550f8ce4c842f43b0cfc26890612e7a98513557fcc8206134a1', 'index.json': 'fd1a28adb80fddfbb1ff77bac6280cae1db7ffd17d36381c40f12d5730ed5af8', 'checkpoint.json': '1bd6f4064b72533f9b4019af56248041935fcee9bf867c51c7792f689dd517ca', 'qa-summary.json': 'f8f951cd4e652466a0c1fd4c31e1274cb62b231e2a329c893909e7910689682d', 'source-fake-bundle.zip': 'e58285904a0b1e0438f522e4aca5dbb79ad8f41cff3770a8913f903b03ede5d7', 'author-packet.json': '165328fd448bc4aeffb8ac402babdcabf4853b8d4d7c20e679b22583a0872476'}
r11review_pins={'README.md': 'c89266717431af6c3b3d453f1b078aff47d8336f0185f3148c07d4580355e98d', 'review.json': '50a9c0de34eea771c8af264cda713a479887324e0da513a11a2661f9cf5fcf50', 'review-index.json': 'dbf7bb68f2e0fbab94df593e94d77459b4ba00816c1a4ebefd43ec77253beeba', 'review-checkpoint.json': '26c75354ae445339796f29479e1701ed06f9beea8aa0ea735bb673e329b43b60', 'review-bundle.zip': '847450cdc4244b8a410e44155c78f9fb57e2d386abdfef00ccbd848e71e134af'}
for directory,pins in ((r11packet,r11packet_pins),(r11review,r11review_pins)):
 for name,pin in pins.items():add_extra(directory/name,pin)
r11index=json.loads(exact(r11packet/'index.json',r11packet_pins['index.json']))
r11reviewdoc=json.loads(exact(r11review/'review.json',r11review_pins['review.json']))
assert r11reviewdoc['decision']=='GO_SOURCE_FUNCTIONAL_QA_ONLY / ACTUAL_HOLD' and r11reviewdoc['reviewer_focus']['passed']==8
for name,row in r11reviewdoc['candidate_packet_artifacts'].items():assert row['sha256']==r11packet_pins[name]
r11indexed=set()
def collect_public_rows(value):
 if type(value) is dict:
  if type(value.get('path')) is str and type(value.get('sha256')) is str:
   path=ROOT/value['path']
   assert path.is_relative_to(ROOT) and path.name.lower() not in {'.env','config.yaml','secrets.yaml','stdout.raw','stderr.raw'}
   add_extra(path,value['sha256']);r11indexed.add(key(path))
  for item in value.values():collect_public_rows(item)
 elif type(value) is list:
  for item in value:collect_public_rows(item)
collect_public_rows(r11index)
r12packet=E/'iteration41-okx-m01-r33-outer-reason-ordinal-source-fake-r12-r2-2026-10-08'
r12review=E/'iteration41-okx-m01-r33-outer-reason-ordinal-independent-review-r12-r2-2026-10-08'
r12packet_pins={'README.md':'ef7f966983bcc241ad63de541f2aaf2236877f6ad0095ddba86d694b5bf6af81','index.json':'7b163efed20821e0333d6ab9a5e661d0db72ddcf337c0adba7b704b9a37a64ac','checkpoint.json':'0d42c152c5603e754a428b7e04125fd5a2e01d461dfa365b2acdf8d33d215f9d','qa-summary.json':'6669275ad6f1e1c715a66cd3fadd4b21c95222d61b68ccbde87788d9bd447557','source-fake-bundle.zip':'872938ff5a1279de2e2b29f195d9269597ae86b15e5bd9bc581256c19fe7d9d4','author-packet.json':'8f9260c6105c9d7cb640b4b86ca6329b12a2d013565917209e20905a755fbc3a'}
r12review_pins={'README.md':'97becf33fb4947e4f1e3266a38218f89b22c374289d524e2a8c561b5bc95143a','review.json':'5bc1f1d5c78a43fde04d70a6be0e085f9b716afc74be480a50a2fa69c645bdd8','review-index.json':'e43e5fddd29b9a49c1405b3ee0c91b4a1c06be97ca2242a0d6cc977beb7c56d8','review-checkpoint.json':'e9f1b4de02c80bc2e06d0b5fb70a19935569fca6e4bfe61fa69de9622ceae481','review-bundle.zip':'5ae17078f4ac32f52a6ca3d8a7bfa0e120fc32da79540815f65f696f6b98fc08'}
for directory,pins in ((r12packet,r12packet_pins),(r12review,r12review_pins)):
 for name,pin in pins.items():add_extra(directory/name,pin)
r12index=json.loads(exact(r12packet/'index.json',r12packet_pins['index.json']))
r12reviewdoc=json.loads(exact(r12review/'review.json',r12review_pins['review.json']))
assert r12reviewdoc['decision']=='GO_SOURCE_FUNCTIONAL_QA_ONLY / ACTUAL_HOLD' and r12reviewdoc['reviewer_focus']['passed']==7
for name,row in r12reviewdoc['candidate_packet_artifacts'].items():assert row['sha256']==r12packet_pins[name]
collect_public_rows(r12index)
r13packet=E/'iteration41-okx-m01-r33-active-outer-activation-source-fake-r13-r1-2026-10-08'
r13review=E/'iteration41-okx-m01-r33-active-outer-activation-independent-review-r13-r1-2026-10-08'
r13packet_pins={'README.md':'9bc3626d3bccce6ae2e91c0d1e2b6d26581718540fd5ad153411f43bfed9cf05','index.json':'4f792dfc51bdcd5a5d57f78dc531c0514f50e00f3621f553ca2ed07871f87309','checkpoint.json':'debca0b64f5df09f46c65749a1e1dc4660a6fc4294365281aa8ce67f6a174dcd','qa-summary.json':'705f4ea0cf730cd21ec70f49242ca61d17c23900917750e151bfff5d3e066ea7','source-fake-bundle.zip':'159179ccfe551ede27fa11840b9b33e59659e0851619f7987cf6f973a8870fae','author-packet.json':'5fd91563a69461a12e0f03e9ec691b85b8087bd62025bb393c9a00b808b2dc78'}
r13review_pins={'README.md':'3f52a3e11f230d46508f0751bed0b614396a265092a62a87d21d325a0d85124d','review.json':'25f9296b9471e26c2946059507e66ea22e6354c6780b5c52744a05679771daef','review-index.json':'f55b2fe2f88d8162c4f2bd00654fe1e94e4e2da539bda23c366a23583f7eb28a','review-checkpoint.json':'cd0411fbd097bf24151ebb15232ee64ef9b4166741a96ad077f63ef0881abacb','review-bundle.zip':'ae5807586a8ee3accca0913ee9b3e995b7a2e66050ea0060ffd2227d98dbb679'}
for directory,pins in ((r13packet,r13packet_pins),(r13review,r13review_pins)):
 for name,pin in pins.items():add_extra(directory/name,pin)
r13index=json.loads(exact(r13packet/'index.json',r13packet_pins['index.json']))
r13reviewdoc=json.loads(exact(r13review/'review.json',r13review_pins['review.json']))
r13read=json.loads(exact(R13_READBACK,R13_READBACK_SHA))
assert r13reviewdoc['decision']=='GO_SOURCE_FUNCTIONAL_QA_ONLY / ACTUAL_HOLD' and r13reviewdoc['reviewer_focus']['passed']==3
for name,row in r13reviewdoc['candidate_packet_artifacts'].items():assert row['sha256']==r13packet_pins[name]
assert r13read['status']=='PUBLIC_PINS_MATCH' and r13read['private_inputs_read'] is False and r13read['provider_started'] is False
assert r13read['packet_pins']==r13packet_pins and r13read['review_pins']==r13review_pins
assert r13read['indexed_source_records']==42 and r13read['unique_source_paths']==34 and r13read['bundle_members_verified']==31
r13indexed=set()
def collect_r13_paths(value):
 if type(value) is dict:
  if type(value.get('path')) is str and type(value.get('sha256')) is str:r13indexed.add(key(ROOT/value['path']))
  for item in value.values():collect_r13_paths(item)
 elif type(value) is list:
  for item in value:collect_r13_paths(item)
collect_r13_paths(r13index);collect_public_rows(r13index)
assert len(r13indexed)==34
for path,pin in extra.items():exact(path,pin)
cu=load(exact(CU,CU_SHA),CU,'_root_m01_r12_r2_cu')
extra_scope=cu.held_public_sources(extra,{})
extra_lease=[extra_scope,None,None,None];KEEPALIVE.append(extra_lease)
extra_entered=False;extra_retained=True;main_entered=False;main_retained=False;main_scope=None
phase='public_review_context_enter';namespace=None;plan_created=False;parent_started=False;parent_call_returned=False
main_postverified=False;extra_postverified=False;auth_called=False;auth_succeeded=False;release_called=False;release_succeeded=False
prestart_cleanup_attempted=False;prestart_cleanup_complete=False
try:
 private,cli,extra_held=extra_scope.__enter__();extra_entered=True
 extra_lease[1:]=[private,cli,extra_held]
 phase='public_review_context_held'
 assert {path:sha(raw) for path,raw in extra_held.items()}==extra
 sys.path.insert(0,str(ROOT))
 h=load(extra_held[key(R31)],R31,'_root_m01_r12_r2_r31')
 p=load(extra_held[key(R34)],R34,'_root_m01_r12_r2_r34')
 a=load(extra_held[key(ADAPTER)],ADAPTER,'scripts.iteration41_okx_m01_r33_active_outer_activation_r13_r1')
 r14=load(extra_held[key(R14_HELPER)],R14_HELPER,'scripts.iteration41_okx_m01_r33_parent_adapter_transport_r14_r1')
 assert extra_held[key(R14_HELPER)]==exact(R14_HELPER,R14_HELPER_SHA)
 r15=load(extra_held[key(R15_HELPER)],R15_HELPER,'scripts.iteration41_okx_m01_r33_final_output_hold_r15_r1')
 assert extra_held[key(R15_HELPER)]==exact(R15_HELPER,R15_HELPER_SHA)
 r16_helper_raw=extra_held[key(R16_HELPER)]
 assert r16_helper_raw==exact(R16_HELPER,R16_HELPER_SHA)
 r16=load(r16_helper_raw,R16_HELPER,'scripts.iteration41_okx_m01_r33_final_output_hold_r16_r1')
 r17_helper_raw=extra_held[key(R17_HELPER)]
 assert r17_helper_raw==exact(R17_HELPER,R17_HELPER_SHA)
 r17=load(r17_helper_raw,R17_HELPER,'scripts.iteration41_okx_m01_r33_source_map_gate_r17_r1')
 assert r17._R16 is r16 and r17._R13 is a
 r18_helper_raw=extra_held[key(R18_HELPER)]
 assert r18_helper_raw==exact(R18_HELPER,R18_HELPER_SHA)
 r18=load(r18_helper_raw,R18_HELPER,'scripts.iteration41_okx_m01_r33_parent_adapter_constructor_r18_r1')
 assert r18._R17 is r17 and r18._R14 is r14 and r18._R13 is a
 r19_helper_raw=extra_held[key(R19_HELPER)]
 assert r19_helper_raw==exact(R19_HELPER,R19_HELPER_SHA)
 r19=load(r19_helper_raw,R19_HELPER,'scripts.iteration41_okx_m01_r33_child_source_scope_r19_r1')
 assert r19._R18 is r18 and r19._R17 is r17 and r19._R14 is r14 and r19._R13 is a
 assert r19.R19_CHILD_SUPPORT_COUNT==2
 r20_helper_raw=extra_held[key(R20_HELPER)]
 assert r20_helper_raw==exact(R20_HELPER,R20_HELPER_SHA)
 r20=load(r20_helper_raw,R20_HELPER,'scripts.iteration41_okx_m01_r33_child_entry_path_r20_r1')
 assert r20._R19 is r19 and r20._R18 is r18 and r20._R17 is r17 and r20._R14 is r14 and r20._R13 is a
 r21_helper_raw=extra_held[key(R21_HELPER)]
 assert r21_helper_raw==exact(R21_HELPER,R21_HELPER_SHA)
 r21=load(r21_helper_raw,R21_HELPER,'scripts.iteration41_okx_m01_r33_child_main_map_r21_r1')
 assert r21._R20 is r20 and r21._R19 is r19 and r21._R17 is r17 and r21._R13 is a
 r22_helper_raw=extra_held[key(R22_HELPER)]
 assert r22_helper_raw==exact(R22_HELPER,R22_HELPER_SHA)
 r22=load(r22_helper_raw,R22_HELPER,'scripts.iteration41_okx_m01_r33_root_prepare_r22_r1')
 assert r22._R21 is r21 and r22._R20 is r20 and r22._R16 is r16 and r22._R13 is a
 r23_helper_raw=extra_held[key(R23_HELPER)]
 assert r23_helper_raw==exact(R23_HELPER,R23_HELPER_SHA)
 r23=load(r23_helper_raw,R23_HELPER,'scripts.iteration41_okx_m01_r33_root_reason_class_r23_r1')
 assert r23._R22 is r22 and r23._R13 is a and r23.R23_PINNED_R22_SHA256==R22_HELPER_SHA
 namespace=uuid.uuid4().hex
 base=Path('D:/temp')/('iteration41-m01-r33-r23-root-'+namespace)
 assert base.parent==Path('D:/temp') and not base.exists()
 ns=h.default_test_namespace(str(base))
 seed=h.prepare_root_startup(ns,plan_sha256='0'*64)
 phase='root_plan_draft_prepare';phase_started=time.monotonic()
 now=datetime.now(timezone.utc)
 draft=p.prepare_root_plan_draft(seed,activation_id=str(uuid.uuid4()),created_at_utc=(now-timedelta(seconds=1)).strftime('%Y-%m-%dT%H:%M:%SZ'),expires_at_utc=(now+timedelta(minutes=6)).strftime('%Y-%m-%dT%H:%M:%SZ'))
 finish_phase('plan_draft_prepare',phase_started)
 assert draft['status']=='DRAFT_ONLY_NO_AUTHORITY'
 final=draft['prepared_r31']
 phase='root_r23_composite_prepare_hold';phase_started=time.monotonic()
 r23_prepared_hold=r23.prepare_root_hold(final,{'schema':'iteration41.okx.m01.r33.root-owned-bootstrap-metadata.v1','cuv2_path':str(CU),'cuv2_sha256':CU_SHA,'owner_image_path':str(Path(sys.executable)),'plan_disposition':'READY_TO_RUN'},environment={})
 finish_phase('r23_composite_prepare_hold',phase_started)
 r22_prepared_hold=r23_prepared_hold.r22_result
 assert r23_prepared_hold.schema==r23.R23_RESULT_SCHEMA and r23_prepared_hold.authority is False and r23_prepared_hold.strict_cases_passed==0 and r23_prepared_hold.case_result is False
 assert r23.verify_root_hold(r23_prepared_hold)
 assert key(r23_prepared_hold.r23_helper_path)==key(R23_HELPER) and r23_prepared_hold.r23_helper_bytes==r23_helper_raw and r23_prepared_hold.r23_helper_sha256==R23_HELPER_SHA and len(r23_prepared_hold.r23_helper_bytes)==len(r23_helper_raw)
 assert r22_prepared_hold.schema==r22.R22_RESULT_SCHEMA and r22_prepared_hold.authority is False and r22_prepared_hold.strict_cases_passed==0 and r22_prepared_hold.case_result is False
 assert r22_prepared_hold.prepare_transform_calls==2
 assert r22_prepared_hold.prepare_outer_sha256==sha(r22_prepared_hold.prepared_r13.active_outer_source)
 assert key(r22_prepared_hold.r22_helper_path)==key(R22_HELPER) and r22_prepared_hold.r22_helper_bytes==r22_helper_raw and r22_prepared_hold.r22_helper_sha256==R22_HELPER_SHA and len(r22_prepared_hold.r22_helper_bytes)==len(r22_helper_raw)
 r21_prepared_hold=r22_prepared_hold.r21_result
 assert r21_prepared_hold.schema==r21.R21_RESULT_SCHEMA and r21_prepared_hold.authority is False and r21_prepared_hold.strict_cases_passed==0 and r21_prepared_hold.case_result is False
 assert r21.verify_root_hold(r21_prepared_hold)
 assert key(r21_prepared_hold.r21_helper_path)==key(R21_HELPER) and r21_prepared_hold.r21_helper_bytes==r21_helper_raw and r21_prepared_hold.r21_helper_sha256==R21_HELPER_SHA and len(r21_prepared_hold.r21_helper_bytes)==len(r21_helper_raw)
 r20_prepared_hold=r21_prepared_hold.r20_result
 assert r20_prepared_hold.schema==r20.R20_RESULT_SCHEMA and r20_prepared_hold.authority is False and r20_prepared_hold.strict_cases_passed==0 and r20_prepared_hold.case_result is False
 assert r20.verify_root_hold(r20_prepared_hold)
 assert key(r20_prepared_hold.r20_helper_path)==key(R20_HELPER) and r20_prepared_hold.r20_helper_bytes==r20_helper_raw and r20_prepared_hold.r20_helper_sha256==R20_HELPER_SHA and len(r20_prepared_hold.r20_helper_bytes)==len(r20_helper_raw)
 r19_prepared_hold=r20_prepared_hold.r19_result
 assert r19_prepared_hold.schema==r19.R19_RESULT_SCHEMA and r19_prepared_hold.authority is False and r19_prepared_hold.strict_cases_passed==0 and r19_prepared_hold.case_result is False
 assert r19.verify_root_hold(r19_prepared_hold)
 assert key(r19_prepared_hold.r19_helper_path)==key(R19_HELPER) and r19_prepared_hold.r19_helper_bytes==r19_helper_raw and r19_prepared_hold.r19_helper_sha256==R19_HELPER_SHA and len(r19_prepared_hold.r19_helper_bytes)==len(r19_helper_raw)
 r17_result=r19_prepared_hold.r17_result
 assert r17_result.schema==r17.R17_RESULT_SCHEMA and r17_result.authority is False and r17_result.strict_cases_passed==0 and r17_result.case_result is False
 assert r17.verify_hold_addition(r17_result)
 r16_result=r17_result.r16_result
 assert r16_result.schema==r16.R16_RESULT_SCHEMA and r16_result.authority is False and r16_result.strict_cases_passed==0 and r16_result.case_result is False
 assert key(r16_result.r16_helper_path)==key(R16_HELPER) and r16_result.r16_helper_bytes==r16_helper_raw and r16_result.r16_helper_sha256==R16_HELPER_SHA and len(r16_result.r16_helper_bytes)==len(r16_helper_raw)
 assert key(r17_result.r17_helper_path)==key(R17_HELPER) and r17_result.r17_helper_bytes==r17_helper_raw and r17_result.r17_helper_sha256==R17_HELPER_SHA and len(r17_result.r17_helper_bytes)==len(r17_helper_raw)
 prepared_r13=r16_result.prepared_r13
 prepared_r14=r16_result.prepared_r14
 prepared=r16_result.prepared_r15
 descriptor=json.loads(prepared_r13.descriptor_json)
 assert prepared_r13.source_map_bytes==prepared.source_map_bytes
 assert key(r17_result.runtime_source_map_path)==key(descriptor['source_map_path'])
 assert r17_result.runtime_source_map_sha256==sha(prepared_r13.source_map_bytes)
 hold_addition=r23_prepared_hold.hold_addition
 assert sha(r15._canonical_json(r16_result.hold_addition))==r16_result.hold_addition_sha256
 assert sha(r15._canonical_json(r17_result.hold_addition))==r17_result.hold_addition_sha256
 assert sha(r15._canonical_json(hold_addition))==r23_prepared_hold.hold_addition_sha256
 assert prepared.r14_prepared is prepared_r14 and prepared_r14.r13_prepared is prepared_r13 and prepared.binding==prepared_r13.binding
 assert key(descriptor['source_map_path'])==key(json.loads(prepared.descriptor_json)['source_map_path'])
 assert hold_addition['canonical_child_map_count']==154 and hold_addition['schema']==r15.R15_HOLD_SCHEMA
 r10=a._R10;lineage=prepared.base_r11_prepared.r10_prepared
 assert prepared.base_r11_prepared.r10_prepared is lineage
 assert prepared.r11_prepared.r10_prepared is prepared.r10_prepared
 assert sha(extra_held[key(Path(r10.__file__))])==a.R13_R10_SHA256
 assert prepared.r11_prepared.binding['r10_binding_sha256']==prepared.r10_prepared.binding_sha256
 assert hold_addition['r11_binding_sha256']==prepared.r11_prepared.binding_sha256
 assert hold_addition['canonical_child_map_count']==154
 assert hold_addition['once_path']==prepared.r10_prepared.once_path and hold_addition['once_sha256']==prepared.r10_prepared.once_sha256 and hold_addition['once_size_bytes']==prepared.r10_prepared.once_size_bytes
 assert hold_addition['sidecar_path']==prepared.sidecar_path and hold_addition['sidecar_sha256']==prepared.sidecar_sha256 and hold_addition['sidecar_size_bytes']==prepared.sidecar_size_bytes
 assert hold_addition['helper_path']==prepared_r13.helper_path and hold_addition['helper_sha256']==prepared_r13.helper_sha256
 assert hold_addition['r14_helper_path']==prepared_r14.helper_path and hold_addition['r14_helper_sha256']==prepared_r14.helper_sha256 and hold_addition['r14_helper_size_bytes']==len(prepared_r14.helper_bytes)
 assert hold_addition['r15_helper_path']==prepared.r15_helper_path and hold_addition['r15_helper_sha256']==prepared.r15_helper_sha256 and hold_addition['r15_helper_size_bytes']==len(prepared.r15_helper_bytes)
 assert hold_addition['final_runner_path']==descriptor['runner_path'] and hold_addition['final_runner_sha256']==sha(prepared.runner_bytes) and hold_addition['final_runner_size_bytes']==len(prepared.runner_bytes)
 assert hold_addition['final_source_map_path']==descriptor['source_map_path'] and hold_addition['final_source_map_sha256']==sha(prepared.source_map_bytes) and hold_addition['final_source_map_size_bytes']==len(prepared.source_map_bytes)
 assert hold_addition['r12_dependency_path']==prepared.r12_dependency[0] and hold_addition['r12_dependency_sha256']==prepared.r12_dependency[2]
 assert hold_addition['reason_table_sha256']==prepared.reason_table_sha256
 assert prepared.binding['r13_reason_table_count']==len(prepared.reason_table)
 assert hold_addition['r10_composer_sha256']==a.R13_R10_SHA256 and hold_addition['r10_composer_size_bytes']==len(prepared.r10_prepared.composer_bytes)
 assert len(hold_addition['r10_external_source_rows'])==13
 assert len({key(lineage.sidecar_path),key(prepared.base_r11_prepared.sidecar_path),key(prepared.sidecar_path)})==3
 base_manifest=r10._manifest_from_runner(lineage.r9_prepared.runner_bytes)
 base_source_map=json.loads(lineage.r9_prepared.source_map_bytes)
 base_outer,active_wrapper=r10._r31_active_outputs(base_manifest,base_source_map)
 base_r10_active_outer=r10._r10_active_outer_source(base_outer,active_wrapper,base_manifest,base_source_map['plan_sha256'],lineage.external_parent_sources)
 assert sha(base_r10_active_outer)==prepared.transform_binding['base_r10_active_outer_sha256']
 active_outer=prepared.active_outer_source
 active_manifest=r10._manifest_from_runner(prepared.runner_bytes)
 active_source_map=json.loads(prepared.source_map_bytes)
 assert sha(active_outer)==prepared.transform_binding['active_outer_sha256']==prepared.outer_binding['active_outer_sha256']
 assert sha(active_outer)==active_manifest['candidate']['active_outer_sha256']==active_source_map['software_pins'][key(ns['self_path'])]==active_source_map['canonical_pins'][key(ns['self_path'])]
 assert prepared.transform_binding['active_outer_path']==ns['self_path'] and prepared.transform_binding['namespace']==ns
 assert sha(active_wrapper)==active_manifest['candidate']['active_wrapper_sha256']==sha(final['active_wrapper_source'])
 assert sha(draft['plan_bytes'])==active_source_map['plan_sha256']==prepared.transform_binding['plan_sha256']
 assert prepared.transform_binding['source_map_sha256']==sha(prepared.source_map_bytes)
 phase='root_plan_contract_source_slice';phase_started=time.monotonic()
 p.validate_plan_contract_source_slice(final,draft['plan_bytes'])
 finish_phase('plan_contract_source_slice',phase_started)
 phase='root_r23_parent_adapter_construct';phase_started=time.monotonic()
 r23_adapter_result=r23.construct_parent_adapter(r23_prepared_hold,adapter_kwargs={
  'scope_authenticator':lambda scope,binding,remaining:authenticate(scope,binding,remaining),
  'clock':time.monotonic,'sleeper':time.sleep})
 finish_phase('r23_parent_adapter_construct',phase_started)
 assert r23_adapter_result.prepared_hold is r23_prepared_hold and r23.verify_parent_adapter_result(r23_adapter_result)
 r22_adapter_result=r23_adapter_result.r22_adapter_result
 assert r22_adapter_result.prepared_hold is r22_prepared_hold and r22.verify_parent_adapter_result(r22_adapter_result)
 assert r22_adapter_result.r13_recompose_calls==1 and r22_adapter_result.r13_outer_transform_calls==1
 assert r23_adapter_result.r13_recompose_calls==1 and r23_adapter_result.r13_outer_transform_calls==1
 r21_adapter_result=r22_adapter_result.r21_adapter_result
 r20_adapter_result=r21_adapter_result.r20_adapter_result
 assert r21_adapter_result.prepared_hold is r21_prepared_hold and r21.verify_parent_adapter_result(r21_adapter_result)
 assert r20_adapter_result.prepared_hold is r20_prepared_hold and r20.verify_parent_adapter_result(r20_adapter_result)
 assert r20_adapter_result.authority is False and r20_adapter_result.strict_cases_passed==0 and r20_adapter_result.case_result is False
 r19_adapter_result=r20_adapter_result.r19_adapter_result
 assert r19_adapter_result.prepared_hold is r19_prepared_hold and r19_adapter_result.r17_result is r17_result and r19.verify_parent_adapter_result(r19_adapter_result)
 assert r19_adapter_result.authority is False and r19_adapter_result.strict_cases_passed==0 and r19_adapter_result.case_result is False
 assert key(r19_adapter_result.r18_helper_path)==key(R18_HELPER) and r19_adapter_result.r18_helper_bytes==r18_helper_raw and r19_adapter_result.r18_helper_sha256==R18_HELPER_SHA and len(r19_adapter_result.r18_helper_bytes)==len(r18_helper_raw)
 assert r19_adapter_result.r13_recompose_calls==1 and r19_adapter_result.r13_outer_transform_calls==1
 adapter=r23_adapter_result.adapter
 KEEPALIVE.append(r23_adapter_result)
 hold_addition=r23_adapter_result.hold_addition
 assert hold_addition['canonical_child_map_count']==154 and r23_adapter_result.hold_addition_sha256==sha(r15._canonical_json(hold_addition))
 assert r23.verify_root_hold(r23_prepared_hold) and sha(r15._canonical_json(r23_prepared_hold.hold_addition))==r23_prepared_hold.hold_addition_sha256
 assert hold_addition["binding_sha256"]==prepared.binding_sha256 and hold_addition['r14_binding_sha256']==prepared_r14.adapter_binding_sha256 and hold_addition['r15_binding_sha256']==prepared.r15_binding_sha256
 assert key(Path(prepared.sidecar_path).parent)==key(ns["deployment_dir"])
 assert len(prepared.stdin_descriptor)<=4096 and prepared.windows_command_line_units<=32767
 phase='root_protected_create_new'
 private.create_private_directory(base).verify()
 control=private.create_private_directory(Path(ns['control_dir']));control.verify()
 deploy=private.create_private_directory(Path(ns['deployment_dir']));deploy.verify()
 protected_targets=(ns['plan_path'],ns['self_path'],ns['active_wrapper_path'],descriptor['runner_path'],descriptor['source_map_path'],lineage.sidecar_path,prepared.base_r11_prepared.sidecar_path,prepared.sidecar_path,prepared.r10_prepared.once_path)
 assert len(protected_targets)==9 and len({key(path) for path in protected_targets})==9
 control.write_bytes(Path(ns['plan_path']).name,draft['plan_bytes'])
 control.write_bytes(Path(ns['self_path']).name,active_outer)
 deploy.write_bytes(Path(ns['active_wrapper_path']).name,active_wrapper)
 control.write_bytes(Path(descriptor['runner_path']).name,prepared.runner_bytes)
 control.write_bytes(Path(descriptor['source_map_path']).name,prepared.source_map_bytes)
 deploy.write_bytes(Path(lineage.sidecar_path).name,lineage.sidecar_bytes)
 deploy.write_bytes(Path(prepared.base_r11_prepared.sidecar_path).name,prepared.base_r11_prepared.sidecar_bytes)
 deploy.write_bytes(Path(prepared.sidecar_path).name,prepared.sidecar_bytes)
 control.write_bytes(Path(prepared.r10_prepared.once_path).name,prepared.r10_prepared.once_bytes)
 control.verify();deploy.verify();plan_created=True
 assert not Path(ns['attempt_claim_path']).exists()
 pub={key(ROOT/path):pin for path,pin in active_manifest['public_pins'].items()}
 soft={key(path):pin for path,pin in active_manifest['software_pins'].items()}
 expected={key(path):pin for path,pin in active_manifest['canonical_pins'].items()}
 assert len(pub)==118 and len(soft)==36 and len(expected)==154 and {**pub,**soft}==expected
 hold_addition_snapshot=r15._canonical_json(hold_addition)
 assert sha(hold_addition_snapshot)==r23_adapter_result.hold_addition_sha256 and r23.verify_parent_adapter_result(r23_adapter_result) and r22.verify_parent_adapter_result(r22_adapter_result) and r21.verify_parent_adapter_result(r21_adapter_result) and r20.verify_parent_adapter_result(r20_adapter_result) and r19.verify_parent_adapter_result(r19_adapter_result) and r17.verify_hold_addition(r17_result)
 assert hold_addition_snapshot==r15._canonical_json(hold_addition)
 pub_parent=dict(pub)
 assert r23_adapter_result.hold_addition==hold_addition and r23.verify_parent_adapter_result(r23_adapter_result) and r22.verify_parent_adapter_result(r22_adapter_result) and r21.verify_parent_adapter_result(r21_adapter_result) and r20.verify_parent_adapter_result(r20_adapter_result) and r19.verify_parent_adapter_result(r19_adapter_result)
 for path,row in hold_addition['entries'].items():
  k=key(path);assert k not in soft and (k not in pub_parent or pub_parent[k]==row['sha256'])
  pub_parent[k]=row['sha256']
 r16_key=key(r16_result.r16_helper_path)
 assert r16_key not in soft and (r16_key not in pub_parent or pub_parent[r16_key]==r16_result.r16_helper_sha256)
 pub_parent[r16_key]=r16_result.r16_helper_sha256
 r17_key=key(r17_result.r17_helper_path)
 r18_key=key(r19_adapter_result.r18_helper_path)
 r19_key=key(r19_prepared_hold.r19_helper_path)
 r20_key=key(r20_prepared_hold.r20_helper_path)
 r21_key=key(r21_prepared_hold.r21_helper_path)
 r22_key=key(r22_prepared_hold.r22_helper_path)
 r23_key=key(r23_prepared_hold.r23_helper_path)
 runtime_map_key=key(r17_result.runtime_source_map_path)
 entry_keys={key(path) for path in hold_addition['entries']}
 assert r17_key in entry_keys and r18_key in entry_keys and r19_key in entry_keys and r20_key in entry_keys and r21_key in entry_keys and r22_key in entry_keys and r23_key in entry_keys and runtime_map_key in entry_keys
 assert r17_key not in soft and r18_key not in soft and r19_key not in soft and r20_key not in soft and r21_key not in soft and r22_key not in soft and r23_key not in soft and runtime_map_key not in soft
 assert pub_parent[r17_key]==r17_result.r17_helper_sha256
 assert pub_parent[r18_key]==r19_adapter_result.r18_helper_sha256
 assert pub_parent[r19_key]==r19_prepared_hold.r19_helper_sha256==R19_HELPER_SHA
 assert pub_parent[r20_key]==r20_prepared_hold.r20_helper_sha256==R20_HELPER_SHA
 assert pub_parent[r21_key]==r21_prepared_hold.r21_helper_sha256==R21_HELPER_SHA
 assert pub_parent[r22_key]==r22_prepared_hold.r22_helper_sha256==R22_HELPER_SHA
 assert pub_parent[r23_key]==r23_prepared_hold.r23_helper_sha256==R23_HELPER_SHA
 assert pub_parent[runtime_map_key]==r17_result.runtime_source_map_sha256
 assert pub_parent[key(prepared.r10_prepared.once_path)]==prepared.r10_prepared.once_sha256 and pub_parent[key(prepared.r10_prepared.composer_path)]==prepared.r10_prepared.composer_sha256
 expected_parent={**expected,**{key(path):row['sha256'] for path,row in hold_addition['entries'].items()},r16_key:r16_result.r16_helper_sha256}
 assert len(pub_parent)+len(soft)==len(expected_parent)
 phase='root_parent_complete_custody_enter'
 main_scope=cu.held_public_sources(pub_parent,soft)
 main_lease=[main_scope,None,None,None,prepared];KEEPALIVE.append(main_lease);main_retained=True
 mp,mc,held=main_scope.__enter__();main_entered=True
 main_lease[1:4]=[mp,mc,held]
 assert {path:sha(raw) for path,raw in held.items()}=={**pub_parent,**soft}
 source_scope=(extra_scope,extra_held,main_scope,held)
 def authenticate(scope,binding,remaining):
  global auth_called,auth_succeeded
  assert not auth_called
  auth_called=True
  assert scope is source_scope and type(remaining) in (int,float) and 0<remaining<=100
  assert binding==prepared_r13.binding==prepared.binding and prepared.plan_disposition=='READY_TO_RUN'
  assert {path:sha(raw) for path,raw in held.items()}=={**pub_parent,**soft}
  assert {path:sha(raw) for path,raw in extra_held.items()}==extra
  assert held[r16_key]==r16_result.r16_helper_bytes and sha(held[r16_key])==r16_result.r16_helper_sha256==R16_HELPER_SHA
  assert extra_held[key(R17_HELPER)]==r17_result.r17_helper_bytes and sha(extra_held[key(R17_HELPER)])==r17_result.r17_helper_sha256==R17_HELPER_SHA
  assert extra_held[key(R18_HELPER)]==r19_adapter_result.r18_helper_bytes and sha(extra_held[key(R18_HELPER)])==r19_adapter_result.r18_helper_sha256==R18_HELPER_SHA
  assert extra_held[key(R19_HELPER)]==r19_prepared_hold.r19_helper_bytes and sha(extra_held[key(R19_HELPER)])==r19_prepared_hold.r19_helper_sha256==R19_HELPER_SHA
  assert extra_held[key(R20_HELPER)]==r20_prepared_hold.r20_helper_bytes and sha(extra_held[key(R20_HELPER)])==r20_prepared_hold.r20_helper_sha256==R20_HELPER_SHA
  assert extra_held[key(R21_HELPER)]==r21_prepared_hold.r21_helper_bytes and sha(extra_held[key(R21_HELPER)])==r21_prepared_hold.r21_helper_sha256==R21_HELPER_SHA
  assert extra_held[key(R22_HELPER)]==r22_prepared_hold.r22_helper_bytes and sha(extra_held[key(R22_HELPER)])==r22_prepared_hold.r22_helper_sha256==R22_HELPER_SHA
  assert extra_held[key(R23_HELPER)]==r23_prepared_hold.r23_helper_bytes and sha(extra_held[key(R23_HELPER)])==r23_prepared_hold.r23_helper_sha256==R23_HELPER_SHA
  assert held[r17_key]==r17_result.r17_helper_bytes and sha(held[r17_key])==r17_result.r17_helper_sha256==R17_HELPER_SHA
  assert held[r18_key]==r19_adapter_result.r18_helper_bytes and sha(held[r18_key])==r19_adapter_result.r18_helper_sha256==R18_HELPER_SHA
  assert held[r19_key]==r19_prepared_hold.r19_helper_bytes and sha(held[r19_key])==r19_prepared_hold.r19_helper_sha256==R19_HELPER_SHA
  assert held[r20_key]==r20_prepared_hold.r20_helper_bytes and sha(held[r20_key])==r20_prepared_hold.r20_helper_sha256==R20_HELPER_SHA
  assert held[r21_key]==r21_prepared_hold.r21_helper_bytes and sha(held[r21_key])==r21_prepared_hold.r21_helper_sha256==R21_HELPER_SHA
  assert held[r23_key]==r23_prepared_hold.r23_helper_bytes and sha(held[r23_key])==r23_prepared_hold.r23_helper_sha256==R23_HELPER_SHA
  assert held[runtime_map_key]==prepared_r13.source_map_bytes and sha(held[runtime_map_key])==r17_result.runtime_source_map_sha256
  assert held[key(lineage.sidecar_path)]==lineage.sidecar_bytes and len(held[key(lineage.sidecar_path)])==lineage.sidecar_size_bytes
  assert held[key(prepared.base_r11_prepared.sidecar_path)]==prepared.base_r11_prepared.sidecar_bytes and len(held[key(prepared.base_r11_prepared.sidecar_path)])==prepared.base_r11_prepared.sidecar_size_bytes
  assert held[key(prepared.sidecar_path)]==prepared.bootstrap_bytes and len(held[key(prepared.sidecar_path)])==prepared.sidecar_size_bytes
  assert held[key(prepared.r10_prepared.once_path)]==prepared.r10_prepared.once_bytes and held[key(prepared.r10_prepared.composer_path)]==prepared.r10_prepared.composer_bytes
  assert extra_held[key(ADAPTER)]==prepared_r13.helper_bytes and sha(extra_held[key(ADAPTER)])==prepared_r13.helper_sha256
  assert extra_held[key(R14_HELPER)]==prepared_r14.helper_bytes and sha(extra_held[key(R14_HELPER)])==prepared_r14.helper_sha256
  assert extra_held[key(R15_HELPER)]==prepared.r15_helper_bytes and sha(extra_held[key(R15_HELPER)])==prepared.r15_helper_sha256
  assert extra_held[key(R16_HELPER)]==r16_result.r16_helper_bytes and sha(extra_held[key(R16_HELPER)])==r16_result.r16_helper_sha256==R16_HELPER_SHA
  assert held[key(ns['self_path'])]==active_outer and held[key(ns['active_wrapper_path'])]==active_wrapper
  assert held[key(descriptor['runner_path'])]==prepared.runner_bytes and held[key(descriptor['source_map_path'])]==prepared.source_map_bytes
  assert r15._canonical_json(hold_addition)==hold_addition_snapshot and sha(hold_addition_snapshot)==r23_adapter_result.hold_addition_sha256 and r23.verify_parent_adapter_result(r23_adapter_result) and r22.verify_parent_adapter_result(r22_adapter_result) and r21.verify_parent_adapter_result(r21_adapter_result) and r20.verify_parent_adapter_result(r20_adapter_result) and r19.verify_parent_adapter_result(r19_adapter_result) and r17.verify_hold_addition(r17_result)
  assert hold_addition['entries'][r19_adapter_result.r18_helper_path]=={'sha256':R18_HELPER_SHA,'size_bytes':len(r18_helper_raw),'role':r18.R18_SOURCE_ROLE,'origin':'repository_source:'+r18.R18_RELATIVE_PATH}
  assert hold_addition['entries'][r19_prepared_hold.r19_helper_path]=={'sha256':R19_HELPER_SHA,'size_bytes':len(r19_helper_raw),'role':r19.R19_SOURCE_ROLE,'origin':'repository_source:'+r19.R19_RELATIVE_PATH}
  assert hold_addition['entries'][r20_prepared_hold.r20_helper_path]=={'sha256':R20_HELPER_SHA,'size_bytes':len(r20_helper_raw),'role':r20.R20_SOURCE_ROLE,'origin':'repository_source:'+r20.R20_RELATIVE_PATH}
  assert hold_addition['entries'][r21_prepared_hold.r21_helper_path]=={'sha256':R21_HELPER_SHA,'size_bytes':len(r21_helper_raw),'role':r21.R21_SOURCE_ROLE,'origin':'repository_source:'+r21.R21_RELATIVE_PATH}
  assert hold_addition['entries'][r22_prepared_hold.r22_helper_path]=={'sha256':R22_HELPER_SHA,'size_bytes':len(r22_helper_raw),'role':r22.R22_SOURCE_ROLE,'origin':'repository_source:'+r22.R22_RELATIVE_PATH}
  assert hold_addition['entries'][r23_prepared_hold.r23_helper_path]=={'sha256':R23_HELPER_SHA,'size_bytes':len(r23_helper_raw),'role':r23.R23_SOURCE_ROLE,'origin':'repository_source:'+r23.R23_RELATIVE_PATH}
  for path,row in hold_addition['entries'].items():assert sha(held[key(path)])==row['sha256'] and len(held[key(path)])==row['size_bytes']
  control.verify();deploy.verify();assert not Path(ns['attempt_claim_path']).exists()
  auth_succeeded=True;return True
 def release(scope,remaining):
  global main_retained,extra_retained,main_postverified,extra_postverified,release_called,release_succeeded
  assert not release_called
  release_called=True
  assert scope is source_scope and type(remaining) in (int,float) and remaining>0
  main_scope.__exit__(None,None,None);main_retained=False;main_postverified=True
  extra_scope.__exit__(None,None,None);extra_retained=False;extra_postverified=True
  release_succeeded=True
  return True
 assert adapter is r23_adapter_result.adapter
 phase='actual_parent_supervise';parent_started=True
 started=time.monotonic()
 try:
  result=adapter.supervise(source_scope,release);parent_call_returned=True
 finally:
  elapsed=time.monotonic()-started
  assert math.isfinite(elapsed) and elapsed>=0
  root_phase_seconds['actual_parent_supervise']=round(elapsed,6)
 summary=adapter.summarize_result(result)
 child_state=bounded_child_summary(summary)
 phase='actual_parent_returned'
 returned=summary['child_phase'].get('returned_result') if type(summary.get('child_phase')) is dict else None
 ordinal=returned.get('outer_reason_ordinal') if type(returned) is dict else None
 if type(ordinal) is not int or not (ordinal==0 or 1<=ordinal<=len(prepared.reason_table)):ordinal=None
 reason_literal='UNOBSERVED'
 if type(ordinal) is int and 1<=ordinal<=len(prepared.reason_table):reason_literal=prepared.reason_table[ordinal-1]
 reason_class=bounded_r23_reason_class(summary,r23_prepared_hold.reason_binding,r23.R23_CLASS_SCHEMA)
 record={'schema':'iteration41.m01.r33.r23.root-actual-parent-diagnostic.r1','status':summary['status'],'reason':summary['reason'],'outer_reason_ordinal':ordinal,'outer_reason_literal':reason_literal,'outer_reason_table_sha256':prepared.reason_table_sha256,'outer_reason_table_count':len(prepared.reason_table),'r23_reason_class':reason_class,
   'parent_result':summary,**child_state,'finite_child_phase':summary['child_phase'],'returned_result':summary['child_phase'].get('returned_result'),'namespace_id':namespace,'parent_elapsed_seconds':elapsed,'planned_parent_seconds':100,'planned_cleanup_seconds':5,
  'parent_source_rows':len(pub_parent)+len(soft),'child_required_source_rows':154,'extra_public_source_rows':len(extra),
  'root_phase_seconds':dict(root_phase_seconds),'current_protected_plan_created':True,'protected_create_new_files':len(protected_targets),'parent_hold_addition_entries':len(hold_addition['entries']),'r10_once_parent_map_bound':True,'r11_returned_result_binding_bound':True,'r13_reason_table_binding_bound':hold_addition['reason_table_sha256']==prepared.reason_table_sha256 and prepared.binding['r13_reason_table_count']==len(prepared.reason_table),'r10_lineage_sidecar_preserved':True,'r11_base_sidecar_parent_map_bound':True,'r13_sidecar_parent_map_bound':True,'r13_helper_parent_map_bound':True,'r14_helper_parent_map_bound':hold_addition['r14_helper_sha256']==prepared_r14.helper_sha256 and hold_addition['r14_helper_size_bytes']==len(prepared_r14.helper_bytes),'r15_helper_parent_map_bound':hold_addition['r15_helper_sha256']==prepared.r15_helper_sha256 and hold_addition['r15_helper_size_bytes']==len(prepared.r15_helper_bytes),'r15_final_runner_parent_map_bound':hold_addition['final_runner_sha256']==sha(prepared.runner_bytes),'r15_final_source_map_parent_map_bound':hold_addition['final_source_map_sha256']==sha(prepared.source_map_bytes),'r16_helper_parent_source_bound':extra_held[key(R16_HELPER)]==r16_result.r16_helper_bytes and sha(extra_held[key(R16_HELPER)])==r16_result.r16_helper_sha256==R16_HELPER_SHA and held[r16_key]==r16_result.r16_helper_bytes and sha(held[r16_key])==r16_result.r16_helper_sha256,'r12_dependency_parent_map_bound':True,'r13_active_outer_regeneration_bound':True,'sidecar_parent_map_bound':True,'sidecar_size_bytes':prepared.sidecar_size_bytes,'short_command_utf16_units_including_null':prepared.windows_command_line_units,'stdin_transport_size_bytes':len(prepared.stdin_descriptor),'root_scope_authenticator_called':auth_called,
  'actual_parent_started':parent_started,'actual_parent_returned':parent_call_returned,'root_scope_authenticator_called':auth_called,'root_scope_authenticator_succeeded':auth_succeeded,'root_scope_release_called':release_called,'root_scope_release_succeeded':release_succeeded,'parent_main_custody_postverified':main_postverified,'parent_extra_custody_postverified':extra_postverified,
  'r12_returned_result_frame_observed':type(returned) is dict and returned.get('status')=='OBSERVED_FIXED_RETURNED_RESULT',
  'r23_reason_class_frame_observed':reason_class['status']!='UNOBSERVED',
  'root_source_refs_retained':main_retained or extra_retained,'child_154_gate_or_plan_validation_observed':False,
  'child_output_parsed':False,'private_captures_opened':False,'late_results_parsed':False,'provider_activity':'UNOBSERVED',
  'private_account_inputs_read_by_parent':False,'strict_cases_passed':0,'case_pass':False}
 record.update({'r17_helper_parent_source_bound':extra_held[key(R17_HELPER)]==r17_result.r17_helper_bytes and sha(extra_held[key(R17_HELPER)])==r17_result.r17_helper_sha256==R17_HELPER_SHA and held[r17_key]==r17_result.r17_helper_bytes and sha(held[r17_key])==r17_result.r17_helper_sha256,'r17_runtime_source_map_child_held':held[runtime_map_key]==prepared_r13.source_map_bytes and sha(held[runtime_map_key])==r17_result.runtime_source_map_sha256,'r17_full_outer_rebuild_bound':sha(active_outer)==prepared.transform_binding['active_outer_sha256'] and b'iteration41.okx.m01.r33.held-runtime-source-map-gate-r17.r1.v1' in active_outer,
  'r18_helper_parent_source_bound':extra_held[key(R18_HELPER)]==r19_adapter_result.r18_helper_bytes and sha(extra_held[key(R18_HELPER)])==r19_adapter_result.r18_helper_sha256==R18_HELPER_SHA and held[r18_key]==r19_adapter_result.r18_helper_bytes and sha(held[r18_key])==r19_adapter_result.r18_helper_sha256,
  'r18_real_r14_constructor_recomposed':r19_adapter_result.r13_recompose_calls==1 and r19_adapter_result.r13_outer_transform_calls==1 and r19.verify_parent_adapter_result(r19_adapter_result),
  'r19_helper_parent_source_bound':extra_held[key(R19_HELPER)]==r19_prepared_hold.r19_helper_bytes and sha(extra_held[key(R19_HELPER)])==r19_prepared_hold.r19_helper_sha256==R19_HELPER_SHA and held[r19_key]==r19_prepared_hold.r19_helper_bytes and sha(held[r19_key])==r19_prepared_hold.r19_helper_sha256,
  'r19_two_inner_support_rows_configured':r19.R19_CHILD_SUPPORT_COUNT==2,
  'r19_full_outer_replay_bound':b'iteration41.okx.m01.r33.inner-child-source-scope-r19.r1.v1' in active_outer and r19.verify_parent_adapter_result(r19_adapter_result),
  'r20_helper_parent_source_bound':extra_held[key(R20_HELPER)]==r20_prepared_hold.r20_helper_bytes and sha(extra_held[key(R20_HELPER)])==r20_prepared_hold.r20_helper_sha256==R20_HELPER_SHA and held[r20_key]==r20_prepared_hold.r20_helper_bytes and sha(held[r20_key])==r20_prepared_hold.r20_helper_sha256,
   'r20_path_entry_normalized_once':active_outer.count(b'if isinstance(self_path, Path):\n        self_path = str(self_path)\n')==1 and r20.verify_parent_adapter_result(r20_adapter_result),
   'r21_helper_parent_source_bound':extra_held[key(R21_HELPER)]==r21_prepared_hold.r21_helper_bytes and sha(extra_held[key(R21_HELPER)])==r21_prepared_hold.r21_helper_sha256==R21_HELPER_SHA and held[r21_key]==r21_prepared_hold.r21_helper_bytes and sha(held[r21_key])==r21_prepared_hold.r21_helper_sha256 and hold_addition['entries'][r21_prepared_hold.r21_helper_path]=={'sha256':R21_HELPER_SHA,'size_bytes':len(r21_helper_raw),'role':r21.R21_SOURCE_ROLE,'origin':'repository_source:'+r21.R21_RELATIVE_PATH},
   'r21_exact_eight_omitted_public_rows_bound':len(r21._R21_OMITTED_PUBLIC)==8 and b'iteration41.okx.m01.r33.child-main-map-r21.r1.v1' in active_outer and r21.verify_parent_adapter_result(r21_adapter_result),
   'r22_helper_parent_source_bound':extra_held[key(R22_HELPER)]==r22_prepared_hold.r22_helper_bytes and sha(held[r22_key])==r22_prepared_hold.r22_helper_sha256==R22_HELPER_SHA and hold_addition['entries'][r22_prepared_hold.r22_helper_path]=={'sha256':R22_HELPER_SHA,'size_bytes':len(r22_helper_raw),'role':r22.R22_SOURCE_ROLE,'origin':'repository_source:'+r22.R22_RELATIVE_PATH},
   'r22_two_prepare_transform_outputs_identical':r22_prepared_hold.prepare_transform_calls==2 and r22_prepared_hold.prepare_outer_sha256==sha(active_outer),
  'r22_adapter_single_recomposition':r22_adapter_result.r13_recompose_calls==1 and r22_adapter_result.r13_outer_transform_calls==1 and r22.verify_parent_adapter_result(r22_adapter_result),
  'r23_helper_parent_source_bound':extra_held[key(R23_HELPER)]==r23_prepared_hold.r23_helper_bytes and sha(extra_held[key(R23_HELPER)])==r23_prepared_hold.r23_helper_sha256==R23_HELPER_SHA and held[r23_key]==r23_prepared_hold.r23_helper_bytes and sha(held[r23_key])==r23_prepared_hold.r23_helper_sha256 and hold_addition['entries'][r23_prepared_hold.r23_helper_path]=={'sha256':R23_HELPER_SHA,'size_bytes':len(r23_helper_raw),'role':r23.R23_SOURCE_ROLE,'origin':'repository_source:'+r23.R23_RELATIVE_PATH},
  'r23_parent_adapter_binding':r23_adapter_result.prepared_hold is r23_prepared_hold and r23_adapter_result.r13_recompose_calls==1 and r23_adapter_result.r13_outer_transform_calls==1 and r23.verify_parent_adapter_result(r23_adapter_result),
  'r23_reason_table_source_bound':r23_prepared_hold.reason_binding.r23_source_sha256==R23_HELPER_SHA and r23_prepared_hold.reason_binding.reason_table_sha256==reason_class['reason_table_sha256'] and reason_class['authority'] is False})
except BaseException as error:
 if not parent_started:
  (main_retained,extra_retained,main_postverified,extra_postverified,
   prestart_cleanup_attempted,prestart_cleanup_complete)=_r14_prestart_cleanup(
    main_scope,extra_scope,main_retained,extra_retained,main_entered,extra_entered,
    main_postverified,extra_postverified)
 phase_duration_key={'root_plan_draft_prepare':'plan_draft_prepare','root_r23_composite_prepare_hold':'r23_composite_prepare_hold','root_plan_contract_source_slice':'plan_contract_source_slice','root_r23_parent_adapter_construct':'r23_parent_adapter_construct'}.get(phase)
 if phase_duration_key is not None and phase_duration_key not in root_phase_seconds and 'phase_started' in locals():
  finish_phase(phase_duration_key,phase_started)
 safe_failure_code=None
 plan_draft_blocked_type=getattr(locals().get('p'),'PlanDraftBlocked',None)
 frozen_plan_failure_type=getattr(locals().get('p'),'FrozenPlanContractFailure',None)
 allowed_codes=getattr(plan_draft_blocked_type,'_CODES',frozenset())
 if isinstance(plan_draft_blocked_type,type) and isinstance(error,plan_draft_blocked_type):
  safe_failure_code=error.code if error.code in allowed_codes else 'plan_draft_blocked'
 elif isinstance(frozen_plan_failure_type,type) and isinstance(error,frozen_plan_failure_type):
  safe_failure_code=error.code if error.code in allowed_codes else 'frozen_plan_contract_failure'
 elif isinstance(getattr(locals().get('r23'),'ChildReasonClassR23Blocked',None),type) and type(error) is r23.ChildReasonClassR23Blocked:
  safe_failure_code=error.code if error.code in r23.R23_FAILURE_CODES else 'r23_prepared_binding'
 elif isinstance(getattr(locals().get('r22'),'ChildMainMapR22Blocked',None),type) and type(error) is r22.ChildMainMapR22Blocked:
  safe_failure_code=error.code if error.code in r22.R22_FAILURE_CODES else 'r22_hold_digest'
  nested_r16_code=error.nested_r16_code if error.nested_r16_code in r22.R16_FAILURE_CODES else None
  nested_r13_code=error.nested_r13_code if error.nested_r13_code in r22.R13_VALIDATE_FAILURE_CODES else None
 elif isinstance(getattr(locals().get('r19'),'ChildSourceScopeR19Blocked',None),type) and type(error) is r19.ChildSourceScopeR19Blocked:
  safe_failure_code=error.code if error.code in r19.R19_FAILURE_CODES else 'r19_adapter_binding'
 elif isinstance(getattr(locals().get('r20'),'ChildEntryPathR20Blocked',None),type) and type(error) is r20.ChildEntryPathR20Blocked:
  safe_failure_code=error.code if error.code in r20.R20_FAILURE_CODES else 'r20_adapter_binding'
 elif isinstance(getattr(locals().get('r21'),'ChildMainMapR21Blocked',None),type) and type(error) is r21.ChildMainMapR21Blocked:
  safe_failure_code=error.code if error.code in r21.R21_FAILURE_CODES else 'r21_hold_digest'
 elif isinstance(getattr(locals().get('r17'),'SourceMapGateR17Blocked',None),type) and type(error) is r17.SourceMapGateR17Blocked:
  safe_code=str(error)
  safe_failure_code=safe_code if safe_code in r17.R17_FAILURE_CODES else 'r17_final_hold_binding'
 elif isinstance(getattr(locals().get('r18'),'ParentAdapterConstructorR18Blocked',None),type) and type(error) is r18.ParentAdapterConstructorR18Blocked:
  safe_failure_code=error.code if error.code in r18.R18_FAILURE_CODES else 'r18_adapter_binding'
 elif isinstance(getattr(locals().get('a'),'ActiveOuterActivationBlocked',None),type) and type(error) is a.ActiveOuterActivationBlocked:
  safe_code=str(error)
  safe_failure_code=safe_code if safe_code in r18.R18_ACTIVE_OUTER_FAILURE_CODES else 'prepared_recompose'
 child_state=bounded_child_summary(locals().get('summary'))
 r23_schema=getattr(locals().get('r23'),'R23_CLASS_SCHEMA','iteration41.okx.m01.r33.child-reason-class-r23.v1')
 r23_binding=getattr(locals().get('r23_prepared_hold'),'reason_binding',None)
 r23_reason_class=bounded_r23_reason_class(locals().get('summary'),r23_binding,r23_schema)
 record={'schema':'iteration41.m01.r33.r23.root-actual-parent-diagnostic.r1','status':'ROOT_PREPARATION_OR_CALL_BLOCKED','root_phase':phase,'root_phase_seconds':dict(root_phase_seconds),'safe_failure_code':safe_failure_code,'nested_r16_code':locals().get('nested_r16_code'),'nested_r13_code':locals().get('nested_r13_code'),'namespace_id':namespace,'r23_reason_class':r23_reason_class,
  **child_state,
  'current_protected_plan_created':plan_created,'actual_parent_started':parent_started,'actual_parent_returned':parent_call_returned,'parent_elapsed_seconds':locals().get('elapsed'),'root_scope_authenticator_called':auth_called,'root_scope_authenticator_succeeded':auth_succeeded,'root_scope_release_called':release_called,'root_scope_release_succeeded':release_succeeded,
  'parent_main_custody_postverified':main_postverified,'parent_extra_custody_postverified':extra_postverified,
  'root_source_refs_retained':main_retained or extra_retained,'prestart_cleanup_attempted':prestart_cleanup_attempted,'prestart_cleanup_complete':prestart_cleanup_complete if prestart_cleanup_attempted or not parent_started else None,'extra_scope_entered':extra_entered,'main_scope_entered':main_entered,'error_category':type(error).__name__ if type(error).__name__ in {'AssertionError','ParentAdapterBlocked','ParentAdapterTransportBlocked','ParentAdapterConstructorR18Blocked','ChildSourceScopeR19Blocked','ChildEntryPathR20Blocked','ChildMainMapR21Blocked','ChildMainMapR22Blocked','ChildReasonClassR23Blocked','PlanDraftBlocked','FrozenPlanContractFailure','FinalOutputHoldR16Blocked','SourceMapGateR17Blocked','PrivateArtifactError','OncePredeploymentBlocked','StartupPreparationBlocked','OuterReasonOrdinalBlocked','ActiveOuterActivationBlocked'} else 'OtherError',
  'child_output_parsed':False,'private_captures_opened':False,'late_results_parsed':False,'provider_activity':'UNOBSERVED',
  'private_account_inputs_read_by_parent':False,'strict_cases_passed':0,'case_pass':False}
OUT.mkdir();body=(json.dumps(record,sort_keys=True,separators=(',',':'))+'\n').encode('ascii')
with (OUT/'observation.json').open('xb') as stream:stream.write(body)
print(json.dumps(record,sort_keys=True,separators=(',',':')),flush=True)
print('OBSERVATION_SHA256='+sha(body),flush=True)
print('ROOT_HOST_REMAIN_ALIVE='+str(main_retained or extra_retained),flush=True)
