"""Bind final R13 runner/source-map bytes into the parent hold.

R10's parent map records its initial runner and source-map bytes. R13 then
rebuilds both outputs at the same descriptor paths. R15 preserves the R13
preparation and R14 adapter, replacing only those two inherited parent-hold
rows with the exact, validated final R13 output bytes and adding this helper's
own source pin. The canonical child map remains 154 entries.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
from pathlib import Path
from typing import Any

from scripts import iteration41_okx_m01_r33_parent_adapter_transport_r14_r1 as _R14


R15_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_final_output_hold_r15_r1.py"
R15_PREPARED_SCHEMA = "iteration41.okx.m01.r33.final-output-hold-r15.r1.v1"
R15_HOLD_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition-r15.r1.v1"
R15_SOURCE_ROLE = "r15_final_output_hold_source"
R15_RUNNER_ROLE = "r15_final_generated_runner"
R15_SOURCE_MAP_ROLE = "r15_final_generated_source_map"
R15_MAX_SOURCE_BYTES = 2 * 1024 * 1024


class FinalOutputHoldBlocked(ValueError):
    """The exact R13 output or its parent-held source binding was invalid."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise FinalOutputHoldBlocked(code)


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R15_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r15_module_name")
    path = Path(__file__).resolve()
    root = Path(_R14._R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R15_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r15_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R15_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise FinalOutputHoldBlocked("r15_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R15_MAX_SOURCE_BYTES, "r15_source_size")
    return str(path), raw, _sha(raw)


def _validated_outputs(r14_prepared: Any) -> tuple[Any, dict[str, Any], dict[str, Any]]:
    _R14._validate_prepared(r14_prepared)
    r13_prepared = r14_prepared.r13_prepared
    r13 = _R14._R13
    r10 = r13._R10
    descriptor = r10._R9._R4._validate_descriptor(r13_prepared.descriptor_json)
    source_map = r10._R9._R4._validate_source_map(r13_prepared.source_map_bytes, descriptor)
    manifest = r10._manifest_from_runner(r13_prepared.runner_bytes)
    binding = r13_prepared.binding
    runner_sha256 = _sha(r13_prepared.runner_bytes)
    source_map_sha256 = _sha(r13_prepared.source_map_bytes)
    _check(binding.get("runner_sha256") == runner_sha256, "r15_runner_binding")
    _check(binding.get("source_map_sha256") == source_map_sha256, "r15_source_map_binding")
    _check(descriptor.get("runner_sha256") == runner_sha256, "r15_descriptor_runner")
    _check(descriptor.get("source_map_sha256") == source_map_sha256, "r15_descriptor_source_map")
    _check(source_map.get("runner_template_sha256") == runner_sha256, "r15_map_runner")
    _check(
        source_map.get("manifest_binding_sha256") == manifest.get("manifest_binding_sha256"),
        "r15_map_manifest",
    )
    _check(
        manifest.get("manifest_binding_sha256") == binding.get("manifest_binding_sha256"),
        "r15_manifest_binding",
    )
    _check(
        descriptor.get("runtime_namespace") == source_map.get("runtime_namespace"),
        "r15_namespace_binding",
    )
    namespace = descriptor["runtime_namespace"]
    r13_transform = binding.get("r13_transform_binding")
    _check(type(r13_transform) is dict, "r15_transform_binding")
    _check(namespace.get("plan_path") == r13_transform.get("plan_path"), "r15_plan_path_binding")
    _check(namespace.get("self_path") == r13_transform.get("active_outer_path"), "r15_outer_path_binding")
    _check(
        manifest.get("candidate", {}).get("active_outer_sha256") == r13_transform.get("active_outer_sha256"),
        "r15_manifest_outer_binding",
    )
    _check(
        namespace.get("active_wrapper_path")
        and manifest.get("candidate", {}).get("active_wrapper_sha256"),
        "r15_wrapper_binding",
    )
    runner_path = descriptor.get("runner_path")
    source_map_path = descriptor.get("source_map_path")
    _check(r10._R9._absolute_windows_path(runner_path), "r15_runner_path")
    _check(r10._R9._absolute_windows_path(source_map_path), "r15_source_map_path")
    _check(runner_path != source_map_path, "r15_output_path_collision")
    _check(binding.get("canonical_child_map_counts") == {"public": 118, "software": 36, "canonical": 154}, "r15_child_map_count")
    return descriptor, source_map, manifest


def _binding(r14_prepared: Any, source: tuple[str, bytes, str]) -> dict[str, Any]:
    helper_path, helper_raw, helper_sha256 = source
    descriptor, source_map, manifest = _validated_outputs(r14_prepared)
    r13_prepared = r14_prepared.r13_prepared
    r13_binding = r13_prepared.binding
    runner_sha256 = _sha(r13_prepared.runner_bytes)
    source_map_sha256 = _sha(r13_prepared.source_map_bytes)
    return {
        "schema": R15_PREPARED_SCHEMA,
        "helper_path": helper_path,
        "helper_sha256": helper_sha256,
        "helper_size_bytes": len(helper_raw),
        "helper_role": R15_SOURCE_ROLE,
        "r14_binding_sha256": r14_prepared.adapter_binding_sha256,
        "r13_binding_sha256": r13_prepared.binding_sha256,
        "plan_path": r13_binding["r13_transform_binding"]["plan_path"],
        "plan_sha256": r13_binding["r13_transform_binding"]["plan_sha256"],
        "active_outer_path": r13_binding["r13_transform_binding"]["active_outer_path"],
        "active_outer_sha256": r13_binding["r13_transform_binding"]["active_outer_sha256"],
        "active_wrapper_path": descriptor["runtime_namespace"]["active_wrapper_path"],
        "active_wrapper_sha256": manifest["candidate"]["active_wrapper_sha256"],
        "runner_path": descriptor["runner_path"],
        "runner_sha256": runner_sha256,
        "runner_size_bytes": len(r13_prepared.runner_bytes),
        "source_map_path": descriptor["source_map_path"],
        "source_map_sha256": source_map_sha256,
        "source_map_size_bytes": len(r13_prepared.source_map_bytes),
        "manifest_binding_sha256": manifest["manifest_binding_sha256"],
        "runtime_namespace": dict(descriptor["runtime_namespace"]),
        "canonical_child_map_counts": {"public": 118, "software": 36, "canonical": 154},
        "authority": False,
    }


def _binding_sha256(binding: dict[str, Any]) -> str:
    return _sha(_canonical_json(binding))


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R15 hold metadata over one exact R14/R13 prepared child."""

    r14_prepared: Any
    r15_helper_path: str
    r15_helper_bytes: bytes
    r15_helper_sha256: str
    r15_binding: dict[str, Any]
    r15_binding_sha256: str

    def __getattr__(self, name: str) -> Any:
        # Child command and binding remain the original R13 prepared values.
        return getattr(self.r14_prepared, name)


def prepare_from_r14(prepared_r14: Any) -> PreparedM01Child:
    _R14._validate_prepared(prepared_r14)
    source = _self_source()
    binding = _binding(prepared_r14, source)
    return PreparedM01Child(
        r14_prepared=prepared_r14,
        r15_helper_path=source[0],
        r15_helper_bytes=source[1],
        r15_helper_sha256=source[2],
        r15_binding=binding,
        r15_binding_sha256=_binding_sha256(binding),
    )


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "r15_prepared_type")
    _R14._validate_prepared(value.r14_prepared)
    source = _self_source()
    _check(
        value.r15_helper_path == source[0]
        and value.r15_helper_bytes == source[1]
        and value.r15_helper_sha256 == source[2],
        "r15_helper_source_binding",
    )
    expected = _binding(value.r14_prepared, source)
    _check(
        value.r15_binding == expected
        and value.r15_binding_sha256 == _binding_sha256(expected),
        "r15_prepared_binding",
    )


def _replace_exact_entry(
    entries: dict[str, Any],
    path: str,
    raw: bytes,
    role: str,
    origin: str,
    previous_raw: bytes,
    previous_role: str,
    code: str,
) -> None:
    r9 = _R14._R13._R10._R9
    _check(type(raw) is bytes and type(previous_raw) is bytes, code + "_bytes")
    _check(r9._absolute_windows_path(path), code + "_path")
    matches = [item for item in entries if r9._normalized(item) == r9._normalized(path)]
    _check(matches == [path], code + "_entry")
    old = entries[path]
    _check(
        old
        == {
            "sha256": _sha(previous_raw),
            "size_bytes": len(previous_raw),
            "role": previous_role,
        },
        code + "_predecessor",
    )
    entries[path] = {
        "sha256": _sha(raw),
        "size_bytes": len(raw),
        "role": role,
        "origin": origin,
    }


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    """Replace stale R10 output pins with final R13 bytes and add R15 source."""
    _validate_prepared(prepared)
    r14_prepared = prepared.r14_prepared
    base = _R14.parent_hold_addition(r14_prepared)
    _check(
        base.get("schema") == _R14.R14_HOLD_SCHEMA
        and base.get("canonical_child_map_count") == 154,
        "r15_r14_parent_hold",
    )
    descriptor, _source_map, _manifest = _validated_outputs(r14_prepared)
    r13_prepared = r14_prepared.r13_prepared
    old_r10 = r13_prepared.base_r11_prepared.r10_prepared
    entries = dict(base["entries"])
    origin = "generated_from_exact_r13_binding:" + r13_prepared.binding_sha256
    _replace_exact_entry(
        entries,
        descriptor["runner_path"],
        r13_prepared.runner_bytes,
        R15_RUNNER_ROLE,
        origin,
        old_r10.runner_bytes,
        "r10_generated_runner",
        "r15_runner_hold",
    )
    _replace_exact_entry(
        entries,
        descriptor["source_map_path"],
        r13_prepared.source_map_bytes,
        R15_SOURCE_MAP_ROLE,
        origin,
        old_r10.source_map_bytes,
        "r10_generated_source_map",
        "r15_source_map_hold",
    )
    r9 = _R14._R13._R10._R9
    _check(r9._absolute_windows_path(prepared.r15_helper_path), "r15_helper_path")
    helper_key = r9._normalized(prepared.r15_helper_path)
    _check(helper_key not in {r9._normalized(path) for path in entries}, "r15_helper_collision")
    entries[prepared.r15_helper_path] = {
        "sha256": prepared.r15_helper_sha256,
        "size_bytes": len(prepared.r15_helper_bytes),
        "role": R15_SOURCE_ROLE,
        "origin": "repository_source:" + R15_RELATIVE_PATH,
    }
    result = dict(base)
    result.update(
        {
            "schema": R15_HOLD_SCHEMA,
            "r14_hold_schema": base["schema"],
            "r14_binding_sha256": r14_prepared.adapter_binding_sha256,
            "r15_binding_sha256": prepared.r15_binding_sha256,
            "r15_helper_path": prepared.r15_helper_path,
            "r15_helper_sha256": prepared.r15_helper_sha256,
            "r15_helper_size_bytes": len(prepared.r15_helper_bytes),
            "r15_helper_role": R15_SOURCE_ROLE,
            "final_runner_path": descriptor["runner_path"],
            "final_runner_sha256": prepared.r15_binding["runner_sha256"],
            "final_runner_size_bytes": prepared.r15_binding["runner_size_bytes"],
            "final_source_map_path": descriptor["source_map_path"],
            "final_source_map_sha256": prepared.r15_binding["source_map_sha256"],
            "final_source_map_size_bytes": prepared.r15_binding["source_map_size_bytes"],
            "plan_path": prepared.r15_binding["plan_path"],
            "plan_sha256": prepared.r15_binding["plan_sha256"],
            "active_outer_path": prepared.r15_binding["active_outer_path"],
            "active_outer_sha256": prepared.r15_binding["active_outer_sha256"],
            "active_wrapper_path": prepared.r15_binding["active_wrapper_path"],
            "active_wrapper_sha256": prepared.r15_binding["active_wrapper_sha256"],
            "manifest_binding_sha256": prepared.r15_binding["manifest_binding_sha256"],
            "canonical_child_map_count": 154,
            "entries": dict(sorted(entries.items())),
        }
    )
    return result


def verify_parent_hold_addition(prepared: PreparedM01Child, value: Any) -> bool:
    try:
        return type(value) is dict and value == parent_hold_addition(prepared)
    except BaseException:
        return False


if __name__ == "__main__":
    raise SystemExit("Use prepare_from_r14() and hold the exact R15 addition.")
