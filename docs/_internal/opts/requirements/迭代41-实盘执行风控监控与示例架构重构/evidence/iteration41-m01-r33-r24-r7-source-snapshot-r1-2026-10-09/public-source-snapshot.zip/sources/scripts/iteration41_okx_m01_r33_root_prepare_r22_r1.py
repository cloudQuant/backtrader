"""Same-call R22 wrapper for the deterministic R21 outer recomposition."""

from __future__ import annotations

import copy
import dataclasses
import hashlib
import json
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_child_main_map_r21_r1 as _R21


_R20 = _R21._R20
_R19 = _R21._R19
_R18 = _R21._R18
_R17 = _R21._R17
_R16 = _R21._R20._R16
_R13 = _R21._R13
_R20_ORIGINAL_APPLY = _R21._R20_ORIGINAL_APPLY
_R13_ORIGINAL_VALIDATE = _R13._validate_prepared
R22_PINNED_R21_SHA256 = "02bc37a707093ed1afd9c7befcb167cccf1820a242e821357bba83f3b18aa770"

R22_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_root_prepare_r22_r1.py"
R22_RESULT_SCHEMA = "iteration41.okx.m01.r33.root-prepare-r22.root-preparation.v1"
R22_ADAPTER_RESULT_SCHEMA = "iteration41.okx.m01.r33.root-prepare-r22.parent-adapter.v1"
R22_SOURCE_ROLE = "r22_same_call_root_prepare_source"
R22_MAX_SOURCE_BYTES = 2097152
R22_MAX_OUTER_BYTES = 2097152
R22_FAILURE_CODES = frozenset(
    {
        "r22_module_name",
        "r22_module_path",
        "r22_source_unavailable",
        "r22_source_size",
        "r22_source_binding",
        "r22_r21_hold_binding",
        "r22_patch_context_busy",
        "r22_patch_context_changed",
        "r22_patch_owner_thread",
        "r22_r20_source_binding",
        "r22_outer_transform",
        "r22_transform_count",
        "r22_transform_bytes_changed",
        "r22_r20_prepare_blocked",
        "r22_r20_result_binding",
        "r22_r21_hold_binding",
        "r22_hold_collision",
        "r22_hold_digest",
        "r22_prepared_binding",
        "r22_r21_adapter_blocked",
        "r22_adapter_counts",
        "r22_adapter_binding",
    }
)

# These are the fixed literals raised by R16's exact composite validator.
R16_FAILURE_CODES = frozenset(
    {
        "r16_module_name",
        "r16_module_path",
        "r16_source_unavailable",
        "r16_source_size",
        "r16_final_r13_outputs",
        "r16_runner_binding",
        "r16_source_map_binding",
        "r16_descriptor_runner",
        "r16_descriptor_source_map",
        "r16_map_runner",
        "r16_map_manifest",
        "r16_manifest_binding",
        "r16_namespace_binding",
        "r16_transform_binding",
        "r16_plan_path_binding",
        "r16_outer_path_binding",
        "r16_manifest_outer_binding",
        "r16_wrapper_binding",
        "r16_runner_path",
        "r16_source_map_path",
        "r16_output_path_collision",
        "r16_child_map_count",
        "r16_facts_owner",
        "r16_facts_descriptor_changed",
        "r16_facts_map_changed",
        "r16_facts_runner_changed",
        "r16_facts_binding_changed",
        "r16_facts_transform_changed",
        "r16_facts_outer_changed",
        "r16_facts_binding_digest_changed",
        "r16_r11_child_map_count",
        "r16_r11_parent_hold",
        "r16_r10_composer_hold_missing",
        "r16_r10_composer_hold_binding",
        "r16_r10_external_hold_missing",
        "r16_r10_external_hold_binding",
        "r16_once_hold_anchor",
        "r16_once_hold_predecessor",
        "r16_r13_hold_path",
        "r16_r13_hold_digest",
        "r16_r13_hold_collision",
        "r16_r14_r13_parent_hold",
        "r16_r14_hold_path",
        "r16_r14_hold_collision",
        "r16_r14_hold_digest",
        "r16_r15_r14_parent_hold",
        "r16_runner_hold",
        "r16_source_map_hold",
        "r16_r15_helper_path",
        "r16_r15_helper_collision",
        "r16_r13_prepare",
        "r16_hold_assembly",
        "r16_final_child_map_count",
        "r16_final_hold_schema",
        "r16_final_hold_bindings",
    }
)
R13_VALIDATE_FAILURE_CODES = frozenset(
    {"prepared_type", "prepared_recompose", "prepared_binding"}
)


class ChildMainMapR22Blocked(ValueError):
    """A fixed R22 call, transform, source, or parent-hold contract failed."""

    def __init__(
        self,
        code: str,
        *,
        nested_r16_code: Optional[str] = None,
        nested_r13_code: Optional[str] = None,
    ) -> None:
        self.code = code if code in R22_FAILURE_CODES else "r22_hold_digest"
        self.nested_r16_code = (
            nested_r16_code if nested_r16_code in R16_FAILURE_CODES else None
        )
        self.nested_r13_code = (
            nested_r13_code if nested_r13_code in R13_VALIDATE_FAILURE_CODES else None
        )
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ChildMainMapR22Blocked(code)


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R22_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r22_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R22_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r22_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R22_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ChildMainMapR22Blocked("r22_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R22_MAX_SOURCE_BYTES, "r22_source_size")
    return str(path), raw, _sha(raw)


def _fixed_nested_codes(error: BaseException) -> tuple[Optional[str], Optional[str]]:
    r16_code = None
    r13_code = None
    if type(error) is _R16.FinalOutputHoldR16Blocked:
        candidate = str(error)
        if candidate in R16_FAILURE_CODES:
            r16_code = candidate
    if type(error) is _R13.ActiveOuterActivationBlocked:
        candidate = str(error)
        if candidate in R13_VALIDATE_FAILURE_CODES:
            r13_code = candidate
    return r16_code, r13_code


@dataclasses.dataclass(frozen=True)
class R22RootPreparedHold:
    """The exact R21 result plus R22 source row and two-call replay evidence."""

    schema: str
    r21_result: Any
    r22_helper_path: str
    r22_helper_bytes: bytes
    r22_helper_sha256: str
    prepare_transform_calls: int
    prepare_outer_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def r20_result(self) -> Any:
        return self.r21_result.r20_result

    @property
    def prepared_r13(self) -> Any:
        return self.r21_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r21_result.prepared_r14

    @property
    def r21_helper_path(self) -> str:
        return self.r21_result.r21_helper_path

    @property
    def r21_helper_bytes(self) -> bytes:
        return self.r21_result.r21_helper_bytes

    @property
    def r21_helper_sha256(self) -> str:
        return self.r21_result.r21_helper_sha256


def _add_r22_row(addition: dict[str, Any], source):
    path, raw, digest = source
    _check(_R13._R10._R9._absolute_windows_path(path), "r22_hold_digest")
    _check(type(raw) is bytes and _sha(raw) == digest, "r22_source_binding")
    result = copy.deepcopy(addition)
    entries = dict(result.get("entries", {}))
    target = _R13._R10._R9._normalized(path)
    _check(
        result.get("schema") == _R20._R16._R15.R15_HOLD_SCHEMA
        and result.get("canonical_child_map_count") == 154
        and all(_R13._R10._R9._normalized(existing) != target for existing in entries),
        "r22_hold_collision",
    )
    entries[path] = {
        "sha256": digest,
        "size_bytes": len(raw),
        "role": R22_SOURCE_ROLE,
        "origin": "repository_source:" + R22_RELATIVE_PATH,
    }
    result["entries"] = dict(sorted(entries.items()))
    return result, _sha(_canonical_json(result))


def _prepare_with_two_r21_transforms(call, r21_source, nested):
    if not _R21._PATCH_LOCK.acquire(blocking=False):
        raise ChildMainMapR22Blocked("r22_patch_context_busy")
    owner = threading.get_ident()
    previous_owner = _R21._PATCH_OWNER_THREAD
    original_apply = _R20._apply_active_outer_transform
    original_validate = _R13._validate_prepared
    transform_calls = 0
    transformed: list[bytes] = []
    wrappers_intact = True
    installed = False
    result = None
    call_error: Optional[BaseException] = None
    try:
        _check(
            _R21._PATCH_OWNER_THREAD is None
            and original_apply is _R20_ORIGINAL_APPLY
            and original_validate is _R13_ORIGINAL_VALIDATE,
            "r22_r20_source_binding",
        )
        _R21._PATCH_OWNER_THREAD = owner

        def apply_wrapper(*args: Any, **kwargs: Any) -> bytes:
            nonlocal transform_calls
            _check(threading.get_ident() == owner, "r22_patch_owner_thread")
            _check(
                _R21._PATCH_OWNER_THREAD == owner
                and _R20._apply_active_outer_transform is apply_wrapper,
                "r22_patch_context_changed",
            )
            transform_calls += 1
            _check(transform_calls <= 2, "r22_transform_count")
            try:
                r20_outer = original_apply(*args, **kwargs)
                r21_outer = _R21._r21_source_transform(r20_outer, r21_source)
                _check(
                    type(r21_outer) is bytes and 0 < len(r21_outer) <= R22_MAX_OUTER_BYTES,
                    "r22_outer_transform",
                )
                transformed.append(r21_outer)
                return r21_outer
            except ChildMainMapR22Blocked:
                raise
            except BaseException:
                raise ChildMainMapR22Blocked("r22_outer_transform") from None

        def validate_wrapper(prepared: Any) -> None:
            _check(threading.get_ident() == owner, "r22_patch_owner_thread")
            _check(
                _R21._PATCH_OWNER_THREAD == owner
                and _R13._validate_prepared is validate_wrapper,
                "r22_patch_context_changed",
            )
            try:
                original_validate(prepared)
            except BaseException as error:
                r16_code, r13_code = _fixed_nested_codes(error)
                if r16_code is not None:
                    nested["r16"] = r16_code
                if r13_code is not None:
                    nested["r13"] = r13_code
                raise

        installed = True
        _R20._apply_active_outer_transform = apply_wrapper
        _R13._validate_prepared = validate_wrapper
        try:
            result = call()
        except BaseException as error:
            call_error = error
    except BaseException as error:
        call_error = error
    finally:
        if installed:
            wrappers_intact = (
                _R20._apply_active_outer_transform is apply_wrapper
                and _R13._validate_prepared is validate_wrapper
            )
            _R20._apply_active_outer_transform = original_apply
            _R13._validate_prepared = original_validate
        _R21._PATCH_OWNER_THREAD = previous_owner
        _R21._PATCH_LOCK.release()

    if call_error is not None:
        r16_code, r13_code = _fixed_nested_codes(call_error)
        if r16_code is not None:
            nested["r16"] = r16_code
        if r13_code is not None:
            nested["r13"] = r13_code
        raise call_error
    _check(wrappers_intact and installed, "r22_patch_context_changed")
    _check(transform_calls == 2, "r22_transform_count")
    _check(transformed[0] == transformed[1], "r22_transform_bytes_changed")
    return result, tuple(transformed)


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R22RootPreparedHold:
    """Run actual R20/R16 preparation while replaying identical R21 bytes twice."""
    source = _self_source()
    r21_source = _R21._self_source()
    _check(
        type(r21_source) is tuple
        and len(r21_source) == 3
        and _sha(r21_source[1]) == r21_source[2] == R22_PINNED_R21_SHA256,
        "r22_r21_hold_binding",
    )
    nested: dict[str, Optional[str]] = {"r16": None, "r13": None}
    try:
        r20_result, transformed = _prepare_with_two_r21_transforms(
            lambda: _R20.prepare_root_hold(
                prepared_r31, root_metadata, environment=environment
            ),
            r21_source,
            nested,
        )
    except ChildMainMapR22Blocked as error:
        raise
    except BaseException as error:
        if nested["r16"] is not None or nested["r13"] is not None:
            raise ChildMainMapR22Blocked(
                "r22_r20_prepare_blocked",
                nested_r16_code=nested["r16"],
                nested_r13_code=nested["r13"],
            ) from None
        if type(error) is _R16.FinalOutputHoldR16Blocked:
            raise ChildMainMapR22Blocked(
                "r22_r20_prepare_blocked",
                nested_r16_code=_fixed_nested_codes(error)[0],
            ) from None
        if type(error) in (
            _R20.ChildEntryPathR20Blocked,
            _R19.ChildSourceScopeR19Blocked,
            _R17.SourceMapGateR17Blocked,
            _R18.ParentAdapterConstructorR18Blocked,
        ):
            raise
        raise ChildMainMapR22Blocked("r22_r20_prepare_blocked") from None

    _check(type(r20_result) is _R20.R20RootPreparedHold, "r22_r20_result_binding")
    _check(_R20.verify_root_hold(r20_result), "r22_r20_result_binding")
    prepared_outer = r20_result.prepared_r13.active_outer_source
    _check(
        type(prepared_outer) is bytes
        and _sha(prepared_outer) == _sha(transformed[0]) == _sha(transformed[1]),
        "r22_transform_bytes_changed",
    )
    try:
        r21_addition, r21_digest = _R21._add_r21_row(r20_result.hold_addition, r21_source)
        r21_result = _R21.R21RootPreparedHold(
            schema=_R21.R21_RESULT_SCHEMA,
            r20_result=r20_result,
            r21_helper_path=r21_source[0],
            r21_helper_bytes=r21_source[1],
            r21_helper_sha256=r21_source[2],
            hold_addition=r21_addition,
            hold_addition_sha256=r21_digest,
        )
        _check(_R21.verify_root_hold(r21_result), "r22_r21_hold_binding")
        addition, digest = _add_r22_row(r21_result.hold_addition, source)
    except ChildMainMapR22Blocked:
        raise
    except BaseException:
        raise ChildMainMapR22Blocked("r22_hold_digest") from None
    result = R22RootPreparedHold(
        schema=R22_RESULT_SCHEMA,
        r21_result=r21_result,
        r22_helper_path=source[0],
        r22_helper_bytes=source[1],
        r22_helper_sha256=source[2],
        prepare_transform_calls=2,
        prepare_outer_sha256=_sha(transformed[0]),
        hold_addition=addition,
        hold_addition_sha256=digest,
    )
    _check(verify_root_hold(result), "r22_hold_digest")
    return result


def verify_root_hold(value: Any) -> bool:
    try:
        if type(value) is not R22RootPreparedHold or value.schema != R22_RESULT_SCHEMA:
            return False
        source = _self_source()
        if (value.r22_helper_path, value.r22_helper_bytes, value.r22_helper_sha256) != source:
            return False
        if value.prepare_transform_calls != 2:
            return False
        if _sha(value.r21_result.prepared_r13.active_outer_source) != value.prepare_outer_sha256:
            return False
        if not _R21.verify_root_hold(value.r21_result):
            return False
        addition, digest = _add_r22_row(value.r21_result.hold_addition, source)
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False


@dataclasses.dataclass(frozen=True)
class R22ParentAdapterResult:
    """R21 adapter construction plus the R22 source row and final hold."""

    schema: str
    prepared_hold: R22RootPreparedHold
    r21_adapter_result: Any
    adapter: Any
    r22_helper_path: str
    r22_helper_bytes: bytes
    r22_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    r13_recompose_calls: int
    r13_outer_transform_calls: int
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def r21_result(self) -> Any:
        return self.prepared_hold.r21_result

    @property
    def r20_result(self) -> Any:
        return self.r21_result.r20_result

    @property
    def r19_result(self) -> Any:
        return self.r20_result.r19_result

    @property
    def prepared_r13(self) -> Any:
        return self.r21_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r21_result.prepared_r14


def construct_parent_adapter(
    prepared_hold: Any,
    *,
    adapter_kwargs: Optional[dict[str, Any]] = None,
) -> R22ParentAdapterResult:
    """Use R21's exact one-call adapter replay and bind the R22 source row."""
    source = _self_source()
    _check(verify_root_hold(prepared_hold), "r22_prepared_binding")
    try:
        r21_adapter = _R21.construct_parent_adapter(
            prepared_hold.r21_result,
            adapter_kwargs=adapter_kwargs,
        )
    except BaseException as error:
        if type(error) is ChildMainMapR22Blocked:
            raise
        r16_code, r13_code = _fixed_nested_codes(error)
        if r16_code is not None or r13_code is not None:
            raise ChildMainMapR22Blocked(
                "r22_r21_adapter_blocked",
                nested_r16_code=r16_code,
                nested_r13_code=r13_code,
            ) from None
        if type(error) in (
            _R21.ChildMainMapR21Blocked,
            _R20.ChildEntryPathR20Blocked,
            _R19.ChildSourceScopeR19Blocked,
            _R17.SourceMapGateR17Blocked,
            _R13.ActiveOuterActivationBlocked,
            _R18.ParentAdapterConstructorR18Blocked,
        ):
            raise
        raise ChildMainMapR22Blocked("r22_r21_adapter_blocked") from None
    _check(type(r21_adapter) is _R21.R21ParentAdapterResult, "r22_r21_adapter_blocked")
    _check(
        r21_adapter.r13_recompose_calls == 1
        and r21_adapter.r13_outer_transform_calls == 1,
        "r22_adapter_counts",
    )
    try:
        addition, digest = _add_r22_row(r21_adapter.hold_addition, source)
    except ChildMainMapR22Blocked:
        raise
    except BaseException:
        raise ChildMainMapR22Blocked("r22_hold_digest") from None
    result = R22ParentAdapterResult(
        schema=R22_ADAPTER_RESULT_SCHEMA,
        prepared_hold=prepared_hold,
        r21_adapter_result=r21_adapter,
        adapter=r21_adapter.adapter,
        r22_helper_path=source[0],
        r22_helper_bytes=source[1],
        r22_helper_sha256=source[2],
        hold_addition=addition,
        hold_addition_sha256=digest,
        r13_recompose_calls=r21_adapter.r13_recompose_calls,
        r13_outer_transform_calls=r21_adapter.r13_outer_transform_calls,
    )
    _check(verify_parent_adapter_result(result), "r22_adapter_binding")
    return result


def verify_parent_adapter_result(value: Any) -> bool:
    try:
        if type(value) is not R22ParentAdapterResult or value.schema != R22_ADAPTER_RESULT_SCHEMA:
            return False
        if not verify_root_hold(value.prepared_hold):
            return False
        source = _self_source()
        if (value.r22_helper_path, value.r22_helper_bytes, value.r22_helper_sha256) != source:
            return False
        if not _R21.verify_parent_adapter_result(value.r21_adapter_result):
            return False
        if value.adapter is not value.r21_adapter_result.adapter:
            return False
        if value.r13_recompose_calls != 1 or value.r13_outer_transform_calls != 1:
            return False
        addition, digest = _add_r22_row(value.r21_adapter_result.hold_addition, source)
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False
