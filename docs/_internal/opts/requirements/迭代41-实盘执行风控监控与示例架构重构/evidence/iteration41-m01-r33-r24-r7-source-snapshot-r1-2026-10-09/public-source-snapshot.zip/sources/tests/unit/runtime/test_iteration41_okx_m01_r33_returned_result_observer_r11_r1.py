"""Source-fake contracts for the additive M01 R11 returned-result frame."""

from __future__ import annotations

import hashlib
import io
import json
import sys
import time
import types
from pathlib import Path

import pytest

from scripts import iteration41_okx_m01_r32_external_parent_budget_r1 as r32
from scripts import iteration41_okx_m01_r33_returned_result_observer_r11_r1 as r11
from scripts import iteration41_okx_m01_r33_runner_result_observer_r7_r2 as r7
from scripts import iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1 as r8
from scripts import iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1 as r10
from scripts import iteration41_okx_l03_l04_v4_root_launcher as launcher
from scripts import iteration41_suspended_child_image_r2 as image_observer
from tests.unit.runtime import test_iteration41_okx_m01_r33_windows_parent_adapter_r6 as r6_tests
from tests.unit.runtime import test_iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1 as r10_tests


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _r11_prepared(tmp_path):
    prepared_r10, held = r10_tests._ready_child(tmp_path)
    prepared = r11.prepare_from_r10(prepared_r10)
    r11._validate_prepared(prepared)
    return prepared, held


def _captured_candidate(runner, *, outer_status="PASS", outer_routes=1):
    reason = "r28_outer_candidate_captured"
    assert reason in runner.MANIFEST["once"]["allowed_result_reasons"]
    value = {
        "schema": runner.MANIFEST["once"]["result_schema"],
        "disposition": "OUTER_CAPTURED",
        "reason": reason,
        "parse_allowed": False,
        "projection": {
            "outer_status": outer_status,
            "outer_reason": "root_prelaunch_unset",
            "outer_route_invocations": outer_routes,
        },
        "inner_stage": None,
        "inner_code": None,
        "lifecycle": {
            "route_invocations": 1,
            "native_operations": None,
            "provider_requests": False,
            "source_review_bound": True,
            "strict_cases_passed": 0,
            "case_result": False,
        },
    }
    safe = runner._safe_result(value)
    assert safe is value
    return safe


def _safe_result_frame(composed_bootstrap, runner):
    module = types.ModuleType("_m01_r11_composed_bootstrap_test")
    module.__file__ = "<r11-exact-composed-bootstrap>"
    exec(
        compile(composed_bootstrap, module.__file__, "exec", dont_inherit=True),
        module.__dict__,
    )
    stream = io.BytesIO()
    sink = types.SimpleNamespace(_stream=stream, _closed=False, _broken=False)
    safe = _captured_candidate(runner)
    module._r11_emit_returned_result_frame(sink, safe, runner)
    sink._closed = True
    module._r11_write_pending_returned_result_frame(sink)
    return stream.getvalue(), module


def _parent_envelope(
    stderr, *, capture=True, cleanup=True, released=True, retained=False,
    result_type=r32.ParentEnvelopeResult,
):
    return result_type(
        schema=r32.RESULT_SCHEMA,
        status="CHILD_EXITED" if capture and cleanup and released and not retained else "CLEANUP_UNCERTAIN",
        reason="child_exit_observed" if capture else "parent_capture_incomplete",
        cleanup_reason="clean" if cleanup else "cleanup_uncertain",
        child_returncode=0 if capture else None,
        stdout=b"{\"status\":\"OUTER_CAPTURED\"}\n" if capture else b"withheld",
        stderr=stderr,
        capture_complete=capture,
        cleanup_complete=cleanup,
        scope_released=released,
        scope_retained=retained,
    )


def _summary(result):
    return {
        "schema": result.schema,
        "status": result.status,
        "reason": result.reason,
        "cleanup_reason": result.cleanup_reason,
        "child_returncode": result.child_returncode,
        "capture_complete": result.capture_complete,
        "cleanup_complete": result.cleanup_complete,
        "scope_released": result.scope_released,
        "scope_retained": result.scope_retained,
        "stdout_bytes": len(result.stdout),
        "stderr_bytes": len(result.stderr),
        "authority": False,
        "strict_cases_passed": 0,
    }


def test_r11_preparation_preserves_r10_and_binds_new_sidecar_and_sources(tmp_path):
    prepared, _held = _r11_prepared(tmp_path)
    base = r10.parent_hold_addition(prepared.r10_prepared)
    addition = r11.parent_hold_addition(prepared)
    base_paths = {r11._R9._normalized(path) for path in base["entries"]}
    new_paths = {
        r11._R9._normalized(prepared.sidecar_path),
        r11._R9._normalized(prepared.helper_path),
        *(r11._R9._normalized(path) for path, *_rest in prepared.dependency_sources),
    }

    assert prepared.r10_prepared.sidecar_bytes == prepared.r10_prepared.r9_prepared.r8_bootstrap_bytes
    assert prepared.bootstrap_bytes == r11._compose_bootstrap(prepared.r10_prepared.sidecar_bytes)
    assert prepared.bootstrap_bytes != prepared.r10_prepared.sidecar_bytes
    assert prepared.runner_bytes == prepared.r10_prepared.runner_bytes
    assert prepared.source_map_bytes == prepared.r10_prepared.source_map_bytes
    assert prepared.descriptor_json == prepared.r10_prepared.descriptor_json
    assert len(json.loads(prepared.source_map_bytes)["canonical_pins"]) == 154
    assert prepared.sidecar_path != prepared.r10_prepared.sidecar_path
    assert prepared.sidecar_sha256 == _sha(prepared.bootstrap_bytes)
    assert prepared.sidecar_size_bytes == len(prepared.bootstrap_bytes)
    assert prepared.windows_command_line_units == r11._R9._command_line_units(prepared.command)
    assert prepared.windows_command_line_units <= r11._R9.MAX_COMMAND_LINE_UNITS
    assert len(prepared.stdin_descriptor) <= r11._R9.MAX_STDIN_BYTES
    assert addition["canonical_child_map_count"] == 154
    assert len(addition["entries"]) == len(base["entries"]) + len(new_paths - base_paths)
    assert addition["entries"][prepared.r10_prepared.sidecar_path]["role"] == "r9_r8_bootstrap_sidecar"
    assert addition["entries"][prepared.sidecar_path] == {
        "sha256": prepared.sidecar_sha256,
        "size_bytes": prepared.sidecar_size_bytes,
        "role": r11.R11_SIDECAR_ROLE,
        "origin": "generated_from_exact_r10_sidecar:" + prepared.r10_prepared.sidecar_sha256,
    }
    assert addition["entries"][prepared.helper_path]["sha256"] == prepared.helper_sha256
    assert len(prepared.dependency_sources) == 5
    assert r11.verify_parent_hold_addition(prepared, addition)

    tampered = json.loads(json.dumps(addition))
    tampered["entries"][prepared.sidecar_path]["sha256"] = "0" * 64
    assert not r11.verify_parent_hold_addition(prepared, tampered)
    tampered = json.loads(json.dumps(addition))
    tampered["entries"][prepared.helper_path]["role"] = "wrong-role"
    assert not r11.verify_parent_hold_addition(prepared, tampered)
    tampered = json.loads(json.dumps(addition))
    tampered["entries"][prepared.sidecar_path + ".renamed"] = tampered["entries"].pop(prepared.sidecar_path)
    assert not r11.verify_parent_hold_addition(prepared, tampered)
    tampered = json.loads(json.dumps(addition))
    dependency_path = prepared.dependency_sources[0][0]
    tampered["entries"][dependency_path]["size_bytes"] += 1
    assert not r11.verify_parent_hold_addition(prepared, tampered)


def test_exact_composition_emits_only_validator_approved_finite_fields(tmp_path):
    prepared, _held = _r11_prepared(tmp_path)
    runner = types.ModuleType("_m01_r11_generated_runner")
    runner.__file__ = "<exact-generated-r10-runner>"
    exec(compile(prepared.runner_bytes, runner.__file__, "exec", dont_inherit=True), runner.__dict__)

    frame, bootstrap = _safe_result_frame(prepared.bootstrap_bytes, runner)
    assert len(frame) == 18
    assert frame.startswith(r11.R11_FRAME_PREFIX)
    assert b"r28_outer_candidate_captured" not in frame
    assert b"root_prelaunch_unset" not in frame
    assert bootstrap._r11_emit_returned_result_frame.__code__.co_filename == "<r11-exact-composed-bootstrap>"
    assert prepared.bootstrap_bytes.count(b"        _r11_emit_returned_result_frame(phase_sink, safe_result, runner)\n") == 1
    assert prepared.bootstrap_bytes.index(b"_r7_emit_result_frame(phase_sink, safe_result, runner)") < prepared.bootstrap_bytes.index(
        b"_r11_emit_returned_result_frame(phase_sink, safe_result, runner)"
    )
    assert prepared.bootstrap_bytes.index(b"_r8_write_pending_phase_frame(phase_sink)") < prepared.bootstrap_bytes.index(
        b"_r11_write_pending_returned_result_frame(phase_sink)"
    )
    assert prepared.bootstrap_bytes.index(b"def _r11_emit_returned_result_frame") < prepared.bootstrap_bytes.index(
        b'if __name__ == "__main__":'
    )

    reasons, pairs = r7._runner_manifest_tables(prepared.runner_bytes)
    parsed = r11._parse_returned_result_frame(frame, prepared.runner_bytes)
    assert parsed["status"] == "OBSERVED_FIXED_RETURNED_RESULT"
    assert reasons[parsed["reason_ordinal"]] == "r28_outer_candidate_captured"
    assert parsed["diagnostic_pair_ordinal"] == 0
    assert len(pairs) == len(runner.MANIFEST["once"]["inner_diagnostic_pairs"])
    assert parsed["route_invocations_reported"] == 1
    assert parsed["native_operations_reported"] == "UNSET"
    assert parsed["provider_requests_reported"] == "NO_REQUEST_REPORTED"
    assert parsed["source_review_bound_reported"] is True
    assert parsed["outer_status"] == "PASS"
    assert parsed["outer_route_invocations"] == 1
    assert parsed["outer_reason_reported"] == "UNREPORTED"
    assert parsed["authority"] is False
    assert parsed["strict_cases_passed"] == 0
    assert parsed["case_result"] is False


def test_exact_r11_main_path_reaches_real_safe_result_after_real_map_and_plan_gates(
    tmp_path, monkeypatch
):
    prepared, held = _r11_prepared(tmp_path)
    base = prepared.r10_prepared
    r10_tests._predeploy_tmp_path_outputs(base, held)
    r10_tests._write_new(prepared.sidecar_path, prepared.bootstrap_bytes)

    response_doc = {
        "schema": "iteration41.okx.m01.v6.root-prelaunch-result.r28.v1",
        "status": "UNSET",
        "reason": "root_prelaunch_unset",
        "case_id": "M01",
        "route_invocations": 0,
        "strict_cases_passed": 0,
        "suite_ready": False,
    }
    response_raw = json.dumps(
        response_doc, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii") + b"\n"
    response = {
        "stdout": response_raw,
        "stderr": b"",
        "returncode": 2,
        "reason": "synthetic_source_fake",
        "cleanup_clean": True,
        "source_custody_retained": False,
    }

    child = types.ModuleType("__main__")
    child.__file__ = prepared.sidecar_path
    real_loader = None
    events = []
    fake_cuv2 = r6_tests._fake_cuv2(held, events)

    def load_source(raw, path, name):
        if name == "_iteration41_m01_r33_cuv2":
            return fake_cuv2
        module = real_loader(raw, path, name)
        if name == "_iteration41_m01_r33_held_outer":
            real_plan_validator = module._validate_plan

            def observed_plan_validator(*args, **kwargs):
                events.append("real_plan_validator")
                return real_plan_validator(*args, **kwargs)

            module._validate_plan = observed_plan_validator
        if name == "_iteration41_m01_r33_runner":
            real_held_map = module._held_map

            def observed_held_map(value):
                events.append("real_154_held_map")
                return real_held_map(value)

            module._held_map = observed_held_map
            real_main = module.main

            def fake_coordinator_after_real_outer_and_plan_gates(borrowed):
                events.append("synthetic_runner_coordinator_bottom")
                borrowed.__enter__()
                try:
                    once = module._load_once(module._R10_ONCE_SOURCE)
                    once._execute_outer_process = lambda *_args: response
                    captured = once._outer_response(
                        b"source-fake-active-outer",
                        b"source-fake-active-wrapper",
                        {},
                        {},
                        b"source-fake-fill",
                        None,
                    )
                    result = once._parse_outer_response(captured)
                    events.append(("real_once_parser", result.get("disposition")))
                    return result
                finally:
                    borrowed.__exit__(None, None, None)

            module.main = fake_coordinator_after_real_outer_and_plan_gates
            module.R11_TEST_ORIGINAL_RUNNER_MAIN = real_main
            module.R11_TEST_SAFE_RESULT = module._safe_result
        return module

    output = io.StringIO()
    phase = io.BytesIO()
    monkeypatch.setattr(sys, "stdin", types.SimpleNamespace(buffer=io.BytesIO(prepared.stdin_descriptor)))
    monkeypatch.setattr(sys, "stdout", output)
    monkeypatch.setattr(sys, "stderr", types.SimpleNamespace(buffer=phase))

    def trace(frame, event, _arg):
        nonlocal real_loader
        if (
            event == "call"
            and frame.f_code.co_name == "main"
            and frame.f_code.co_filename == prepared.sidecar_path
        ):
            real_loader = child._load_source
            child._load_source = load_source
            sys.settrace(None)
            return None
        return trace

    sys.settrace(trace)
    try:
        with pytest.raises(SystemExit) as raised:
            exec(compile(prepared.stub_bytes, "<r11-short-command>", "exec", dont_inherit=True), child.__dict__)
    finally:
        sys.settrace(None)

    assert raised.value.code == 0
    assert json.loads(output.getvalue())["status"] == "OUTER_CAPTURED"
    assert events.count("real_154_held_map") == 1
    assert events.count("real_plan_validator") == 1
    assert ("real_once_parser", "OUTER_CAPTURED") in events
    frames = phase.getvalue()
    assert frames.startswith(b"M01P1:DSHhPpRrVX\nM01R11:")
    assert len(frames.splitlines()) == 2
    assert b"r28_outer_candidate_captured" not in frames
    assert b"root_prelaunch_unset" not in frames
    assert not hasattr(child, "_RETAINED_SCOPES") or not child._RETAINED_SCOPES

    # The real child phase and R11 result frame are retained; the R8 success
    # line is an explicit protocol fixture because the synthetic runner-main
    # leaf above does not execute the outer once module's main function.
    completed_stderr = frames.splitlines(keepends=True)[0] + b"M01R8:OEORPEPR\n" + frames.splitlines(keepends=True)[1]
    parent_raw = _parent_envelope(completed_stderr)
    parent_layer = types.SimpleNamespace(
        _r5=types.SimpleNamespace(
            _inner=types.SimpleNamespace(_r32=types.SimpleNamespace(ParentEnvelopeResult=r32.ParentEnvelopeResult)),
            summarize_result=_summary,
        )
    )
    projected = r11._parent_projection(
        parent_layer,
        parent_raw,
        prepared.runner_bytes,
        lambda _result: pytest.fail("complete R11 frame fell back to the old parser"),
    )
    assert projected.child_phase["returned_result"]["status"] == "OBSERVED_FIXED_RETURNED_RESULT"
    assert projected.child_phase["outer_route_phase"]["outer_response"] == "RETURNED"


def test_parent_accepts_returned_result_only_after_capture_cleanup_release_and_phase_gates(
    tmp_path, monkeypatch,
):
    prepared, _held = _r11_prepared(tmp_path)
    runner = types.ModuleType("_m01_r11_runner_for_parent")
    runner.__file__ = "<exact-generated-r10-runner>"
    exec(compile(prepared.runner_bytes, runner.__file__, "exec", dont_inherit=True), runner.__dict__)
    frame, _bootstrap = _safe_result_frame(prepared.bootstrap_bytes, runner)
    stderr = b"M01P1:DSHhPpRrVX\nM01R8:OEORPEPR\n" + frame
    raw = _parent_envelope(stderr)
    fake_summary_layer = types.SimpleNamespace(
        _r5=types.SimpleNamespace(
            _inner=types.SimpleNamespace(_r32=types.SimpleNamespace(ParentEnvelopeResult=r32.ParentEnvelopeResult)),
            summarize_result=_summary,
        )
    )
    fallback_calls = []
    projected = r11._parent_projection(
        fake_summary_layer,
        raw,
        prepared.runner_bytes,
        lambda result: fallback_calls.append(result) or None,
    )
    assert type(projected) is r11._R6.M01ParentDiagnosticResult
    assert projected.capture_complete and projected.cleanup_complete and projected.scope_released
    assert not projected.scope_retained
    assert projected.child_phase["stage"] == "CHILD_CUV2_POSTVERIFY_REPORTED"
    assert projected.child_phase["outer_route_phase"]["stage"] == "COMPLETED"
    returned = projected.child_phase["returned_result"]
    assert returned["status"] == "OBSERVED_FIXED_RETURNED_RESULT"
    assert returned["outer_status"] == "PASS"
    assert returned["authority"] is False and returned["strict_cases_passed"] == 0
    assert fallback_calls == []

    monkeypatch.setattr(
        r11,
        "_parse_r11_parent_frames",
        lambda *_args: pytest.fail("incomplete parent lifecycle parsed child bytes"),
    )
    for gate in (
        {"capture": False},
        {"cleanup": False},
        {"released": False},
        {"retained": True},
    ):
        gated = _parent_envelope(stderr, **gate)
        fallback_value = r11._R6.M01ParentDiagnosticResult(
            schema=r32.RESULT_SCHEMA,
            status=gated.status,
            reason=gated.reason,
            cleanup_reason=gated.cleanup_reason,
            child_returncode=None,
            capture_complete=gated.capture_complete,
            cleanup_complete=gated.cleanup_complete,
            scope_released=gated.scope_released,
            scope_retained=gated.scope_retained,
            stdout_bytes=None,
            stderr_bytes=None,
            child_phase={},
        )
        calls = []
        withheld = r11._parent_projection(
            fake_summary_layer,
            gated,
            prepared.runner_bytes,
            lambda _result: calls.append(True) or fallback_value,
        )
        assert calls == [True]
        assert withheld.child_phase["returned_result"] == r11._unobserved_returned_result()
        assert withheld.stdout_bytes is None and withheld.stderr_bytes is None


def test_r11_adapter_installs_projection_per_instance_restores_and_consumes_once(tmp_path, monkeypatch):
    prepared, _held = _r11_prepared(tmp_path)
    runner = types.ModuleType("_m01_r11_runner_adapter")
    runner.__file__ = "<exact-generated-r10-runner>"
    exec(compile(prepared.runner_bytes, runner.__file__, "exec", dont_inherit=True), runner.__dict__)
    frame, _bootstrap = _safe_result_frame(prepared.bootstrap_bytes, runner)
    adapter = r11.M01WindowsParentAdapter(
        prepared,
        scope_authenticator=lambda *_args: True,
        fake_leaves=True,
        native=object(),
        process_factory=lambda *_args, **_kwargs: None,
        launcher_module=launcher,
        image_module=image_observer,
        clock=time.monotonic,
        sleeper=time.sleep,
    )
    result_type = adapter._r8_adapter._r5._inner._r32.ParentEnvelopeResult
    raw = _parent_envelope(
        b"M01P1:DSHhPpRrVX\nM01R8:OEORPEPR\n" + frame,
        result_type=result_type,
    )
    original_projector = adapter._r8_adapter._project_r7_parent_result

    def fake_r10_parent_turn(_scope, _release, **_kwargs):
        assert adapter._r8_adapter._project_r7_parent_result is not original_projector
        return adapter._r8_adapter._project_r7_parent_result(raw)

    monkeypatch.setattr(adapter._r10, "supervise", fake_r10_parent_turn)
    result = adapter.supervise(object(), lambda *_args: True)
    assert adapter._r8_adapter._project_r7_parent_result == original_projector
    summary = adapter.summarize_result(result)
    assert summary["child_phase"]["returned_result"]["status"] == "OBSERVED_FIXED_RETURNED_RESULT"
    assert summary["child_phase"]["returned_result"]["authority"] is False
    with pytest.raises(r11.ReturnedResultObserverBlocked, match="adapter_reentry"):
        adapter.supervise(object(), lambda *_args: True)


def test_unknown_stage_status_collision_and_trailing_payload_fail_closed(tmp_path):
    prepared, _held = _r11_prepared(tmp_path)
    runner = types.ModuleType("_m01_r11_runner_negative")
    runner.__file__ = "<exact-generated-r10-runner>"
    exec(compile(prepared.runner_bytes, runner.__file__, "exec", dont_inherit=True), runner.__dict__)
    frame, _bootstrap = _safe_result_frame(prepared.bootstrap_bytes, runner)
    sentinel = b"provider-private-sentinel"
    bad = (
        frame[:-2] + b"9\n",  # unknown outer status enum
        frame + sentinel,
        b"M01R11:Cff0N0P10\n",  # unknown manifest reason ordinal
        b"M01R11:C000N0P11\n",  # collision/unknown route code
        b"M01R11:C000N0P19\n",  # unknown outer route count
        b"M01R11:C000N0P10\n\n",
    )
    for raw in bad:
        assert r11._parse_returned_result_frame(raw, prepared.runner_bytes) == r11._unobserved_returned_result()
        assert sentinel.decode("ascii") not in repr(r11._parse_returned_result_frame(raw, prepared.runner_bytes))

    frames = b"M01P1:DSHhPpRrV\nM01R8:OEORPEPR\n" + frame
    parsed = r11._parse_r11_parent_frames(frames, prepared.runner_bytes)
    assert parsed[3] == r11._unobserved_returned_result()
    frames = b"M01P1:DSHhPpRrVX\nM01R8:OEORPEPX:00\n" + frame
    parsed = r11._parse_r11_parent_frames(frames, prepared.runner_bytes)
    assert parsed[3] == r11._unobserved_returned_result()
    frames = b"M01P1:DSHhPpRrVX\nM01R8:OEORPEPR\n" + frame + frame
    parsed = r11._parse_r11_parent_frames(frames, prepared.runner_bytes)
    assert parsed[3] == r11._unobserved_returned_result()
    assert sentinel.decode("ascii") not in repr(parsed)


def test_invalid_or_unclassified_runner_results_never_get_an_r11_frame(tmp_path):
    prepared, _held = _r11_prepared(tmp_path)
    runner = types.ModuleType("_m01_r11_runner_reject")
    runner.__file__ = "<exact-generated-r10-runner>"
    exec(compile(prepared.runner_bytes, runner.__file__, "exec", dont_inherit=True), runner.__dict__)
    safe = _captured_candidate(runner)
    module = types.ModuleType("_m01_r11_bootstrap_reject")
    exec(compile(prepared.bootstrap_bytes, "<r11-reject-source>", "exec", dont_inherit=True), module.__dict__)

    def emitted(value):
        stream = io.BytesIO()
        sink = types.SimpleNamespace(_stream=stream, _closed=False, _broken=False)
        module._r11_emit_returned_result_frame(sink, value, runner)
        return getattr(sink, "_r11_returned_result_frame", None)

    assert emitted(None) is None
    uncertain = dict(safe, disposition="UNCERTAIN")
    assert emitted(uncertain) is None
    unknown_status = dict(safe, projection=dict(safe["projection"], outer_status="UNKNOWN"))
    assert runner._safe_result(unknown_status) is None
    assert emitted(unknown_status) is None
    bad_lifecycle = dict(safe, lifecycle=dict(safe["lifecycle"], case_result=True))
    assert runner._safe_result(bad_lifecycle) is None
    assert emitted(bad_lifecycle) is None


def test_source_bindings_and_budget_constants_are_frozen_and_unchanged():
    r11._dependency_rows()
    assert r11._R10.R10_ONCE_FILENAME == "root_diagnostic_once_r10.py"
    assert r11._R9.MAX_COMMAND_LINE_UNITS == 32767
    assert r11._R6.PARENT_TIMEOUT_SECONDS == 100.0
    assert r11._R6.PARENT_CLEANUP_SECONDS == 5.0
    assert r11._R10.R10_MAX_ONCE_BYTES == 2 * 1024 * 1024
    assert r11._R8.PHASE_MAX_BYTES == 24
    assert r11.R11_FRAME_MAX_BYTES == 20
