"""Build a source-fake M01 plan draft from the frozen R31/R28 public closure.

The returned plan bytes are a draft only. ``READY_TO_RUN`` is retained inside
the frozen R28 plan schema, but the outer result is always
``DRAFT_ONLY_NO_AUTHORITY``. This module never writes a plan, creates a claim,
deploys a wrapper, or establishes Root authority.
"""

from __future__ import annotations

import ast
import hashlib
import importlib
import json
import ntpath
import re
from pathlib import Path
from typing import Any


R31_MODULE = "scripts.iteration41_okx_m01_r31_root_startup_prepare_r1"
R31_HELPER_SHA256 = "c95f72c6d168352893339bad5f53e5f48e5b201219a30de8b2de6d90f50e441a"
R31_TEST_REL = "tests/unit/runtime/test_iteration41_okx_m01_r31_root_startup_prepare_r1.py"
R31_TEST_SHA256 = "125df2d6e97ce9836fc6bd32b176277d610b7f4c59005968eb80911464484482"
R28_UNSET_WRAPPER_SHA256 = "ceb74afb99d33057cf355ce82a93d574ecfd186faeff85b4210a46776b2479e8"
R34_DRAFT_SCHEMA = "iteration41.okx.m01.v6.root-plan-draft.r34.r1.v1"
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_DYNAMIC_PLAN_FIELDS = frozenset(
    {"activation_id", "created_at_utc", "expires_at_utc"}
)


class PlanDraftBlocked(RuntimeError):
    """A fixed source, prepared-result, plan, or closure check failed."""

    _CODES = frozenset(
        {
            "dependency_pin_mismatch",
            "prepared_shape",
            "prepared_binding",
            "source_manifest_mismatch",
            "source_pin_mismatch",
            "source_pin_unset",
            "plan_gate_rejected",
            "plan_source_slice_invalid",
            "plan_digest_closure",
            "wrapper_digest_unstable",
            "r31_reprepare_failed",
            "root_plan_binding",
            "root_plan_expired",
            "root_plan_fields",
            "root_plan_not_canonical",
            "root_plan_time_shape",
        }
    )

    def __init__(self, code: str):
        self.code = code if code in self._CODES else "plan_draft_blocked"
        super().__init__(self.code)


class FrozenPlanContractFailure(RuntimeError):
    """A safe failure code raised by the exact frozen R28 plan-gate slice."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("ascii")


def _load_r31():
    try:
        r31 = importlib.import_module(R31_MODULE)
        module_path = Path(r31.__file__).resolve()
        repo_root = module_path.parents[1]
        helper_raw = module_path.read_bytes()
        test_raw = (repo_root / R31_TEST_REL).read_bytes()
    except BaseException as exc:
        raise PlanDraftBlocked("dependency_pin_mismatch") from exc
    if _sha(helper_raw) != R31_HELPER_SHA256 or _sha(test_raw) != R31_TEST_SHA256:
        raise PlanDraftBlocked("dependency_pin_mismatch")
    return r31


def _path_key(path: str) -> str:
    try:
        r31 = importlib.import_module(R31_MODULE)
        r30, _root = r31._r30()
        r29 = importlib.import_module(r30.R29_MODULE)
        return r29._r2()._canonical(path)
    except BaseException as exc:
        raise PlanDraftBlocked("source_manifest_mismatch") from exc


def _prepared_shape(prepared: Any) -> None:
    expected_keys = {
        "manifest",
        "public_pins",
        "software_pins",
        "canonical_pins",
        "active_outer_source",
        "active_wrapper_source",
        "runner_template_source",
        "runner_template_sha256",
        "status",
    }
    if type(prepared) is not dict or set(prepared) != expected_keys:
        raise PlanDraftBlocked("prepared_shape")
    if (
        prepared.get("status") != "SOURCE_FAKE_ONLY_DISABLED"
        or type(prepared.get("manifest")) is not dict
        or type(prepared.get("active_outer_source")) is not bytes
        or type(prepared.get("active_wrapper_source")) is not bytes
        or type(prepared.get("runner_template_source")) is not bytes
        or type(prepared.get("runner_template_sha256")) is not str
    ):
        raise PlanDraftBlocked("prepared_shape")


def _prepared_binding(prepared: Any, r31: Any) -> tuple[dict, str, dict]:
    _prepared_shape(prepared)
    manifest = prepared["manifest"]
    try:
        public_pins, software_pins = r31.scope_maps(manifest)
    except BaseException as exc:
        raise PlanDraftBlocked("prepared_binding") from exc
    if (
        prepared["public_pins"] != public_pins
        or prepared["software_pins"] != software_pins
        or prepared["canonical_pins"] != manifest.get("canonical_pins")
        or _sha(prepared["runner_template_source"])
        != prepared["runner_template_sha256"]
    ):
        raise PlanDraftBlocked("prepared_binding")

    namespace = manifest.get("runtime_namespace")
    runtime_plan = manifest.get("runtime_outputs", {}).get("plan")
    if (
        type(namespace) is not dict
        or type(runtime_plan) is not dict
        or type(runtime_plan.get("path")) is not str
        or runtime_plan.get("path") != namespace.get("plan_path")
    ):
        raise PlanDraftBlocked("source_manifest_mismatch")
    plan_sha256 = runtime_plan.get("sha256")
    plan_key = _path_key(runtime_plan["path"])
    if (
        type(plan_sha256) is not str
        or _HEX64.fullmatch(plan_sha256) is None
        or software_pins.get(plan_key) != plan_sha256
    ):
        raise PlanDraftBlocked("source_manifest_mismatch")

    candidate = manifest.get("candidate")
    if (
        type(candidate) is not dict
        or candidate.get("active_wrapper_sha256")
        != _sha(prepared["active_wrapper_source"])
        or candidate.get("active_outer_sha256")
        != _sha(prepared["active_outer_source"])
        or candidate.get("active_wrapper_sha256")
        != manifest.get("runtime_outputs", {})
        .get("root_actual_wrapper_source", {})
        .get("sha256")
    ):
        raise PlanDraftBlocked("prepared_binding")
    if candidate.get("active_outer_sha256") != manifest.get("runtime_outputs", {}).get(
        "root_prelaunch_source", {}
    ).get("sha256"):
        raise PlanDraftBlocked("prepared_binding")
    return namespace, plan_sha256, manifest


def _reprepare_and_compare(prepared: Any, r31: Any) -> tuple[dict, str, dict]:
    namespace, plan_sha256, manifest = _prepared_binding(prepared, r31)
    try:
        regenerated = r31.prepare_root_startup(namespace, plan_sha256=plan_sha256)
    except BaseException as exc:
        raise PlanDraftBlocked("r31_reprepare_failed") from exc
    if (
        regenerated.get("status") != prepared["status"]
        or regenerated.get("active_outer_source") != prepared["active_outer_source"]
        or regenerated.get("active_wrapper_source") != prepared["active_wrapper_source"]
        or regenerated.get("runner_template_source") != prepared["runner_template_source"]
        or regenerated.get("public_pins") != prepared["public_pins"]
        or regenerated.get("software_pins") != prepared["software_pins"]
        or regenerated.get("canonical_pins") != prepared["canonical_pins"]
        or _json_bytes(regenerated.get("manifest")) != _json_bytes(manifest)
    ):
        raise PlanDraftBlocked("prepared_binding")
    return namespace, plan_sha256, manifest


def _simple_assignment(function: ast.FunctionDef, name: str) -> ast.Assign:
    matches = [
        node
        for node in function.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == name
    ]
    if len(matches) != 1:
        raise PlanDraftBlocked("plan_source_slice_invalid")
    return matches[0]


def _contract_nodes(wrapper_raw: bytes) -> tuple[ast.Module, ast.FunctionDef, list[ast.stmt]]:
    if type(wrapper_raw) is not bytes:
        raise PlanDraftBlocked("plan_source_slice_invalid")
    try:
        tree = ast.parse(wrapper_raw.decode("utf-8"))
    except (UnicodeDecodeError, SyntaxError, ValueError) as exc:
        raise PlanDraftBlocked("plan_source_slice_invalid") from exc
    run_once = [
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_run_once"
    ]
    if len(run_once) != 1:
        raise PlanDraftBlocked("plan_source_slice_invalid")
    plan_blocks = []
    for node in ast.walk(run_once[0]):
        if not isinstance(node, ast.With):
            continue
        body = node.body
        plan_index = next(
            (
                index
                for index, child in enumerate(body)
                if isinstance(child, ast.Assign)
                and len(child.targets) == 1
                and isinstance(child.targets[0], ast.Name)
                and child.targets[0].id == "plan"
                and isinstance(child.value, ast.Call)
                and isinstance(child.value.func, ast.Name)
                and child.value.func.id == "parse"
            ),
            None,
        )
        control_index = next(
            (
                index
                for index, child in enumerate(body)
                if isinstance(child, ast.Assign)
                and len(child.targets) == 1
                and isinstance(child.targets[0], ast.Name)
                and child.targets[0].id == "control_dir"
            ),
            None,
        )
        if plan_index is not None and control_index is not None and plan_index < control_index:
            plan_blocks.append(body[plan_index:control_index])
    if len(plan_blocks) != 1:
        raise PlanDraftBlocked("plan_source_slice_invalid")
    statements = plan_blocks[0]
    required_count = sum(
        isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "required"
        for node in statements
    )
    expected_count = sum(
        isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "expected"
        for node in statements
    )
    if required_count != 1 or expected_count != 1:
        raise PlanDraftBlocked("plan_source_slice_invalid")
    return tree, run_once[0], statements


def _manifest_pin_for_suffix(pins: Any, suffix: str) -> str:
    if type(pins) is not dict:
        raise PlanDraftBlocked("source_manifest_mismatch")
    normalized_suffix = ntpath.normcase(suffix)
    matches = [
        value
        for path, value in pins.items()
        if type(path) is str and ntpath.normcase(path).endswith(normalized_suffix)
    ]
    if len(matches) != 1 or type(matches[0]) is not str:
        raise PlanDraftBlocked("source_manifest_mismatch")
    return matches[0]


def _static_wrapper_values(run_once: ast.FunctionDef) -> dict[str, Any]:
    names = (
        "PRIVATE_HELPER_SHA",
        "MAP_SHA",
        "INDEX_SHA",
        "ZIP_SHA",
        "CHECKPOINT_SHA",
        "RAW_RECORD_SHA",
        "PROJECTION_SHA",
        "EXE_SHA",
        "DLL_SHA",
        "REVIEW_REF",
        "PROFILE",
        "MAX_PLAN",
    )
    values = {}
    for name in names:
        node = _simple_assignment(run_once, name)
        try:
            namespace: dict[str, Any] = {"__builtins__": {}}
            module = ast.Module(body=[node], type_ignores=[])
            exec(
                compile(ast.fix_missing_locations(module), "<r28-plan-constant>", "exec"),
                namespace,
            )
            values[name] = namespace[name]
        except BaseException as exc:
            raise PlanDraftBlocked("plan_source_slice_invalid") from exc
    return values


def _validate_manifest_links(
    manifest: dict, wrapper_raw: bytes, static: dict[str, Any]
) -> None:
    candidate = manifest.get("candidate")
    review = manifest.get("review")
    origins = manifest.get("runtime_helper_origins")
    if type(candidate) is not dict or type(review) is not dict or type(origins) is not dict:
        raise PlanDraftBlocked("source_manifest_mismatch")
    lineage = candidate.get("r24_source_lineage")
    review_pins = review.get("pins")
    if type(lineage) is not dict or type(review_pins) is not dict:
        raise PlanDraftBlocked("source_manifest_mismatch")
    if candidate.get("packet_member_sha256", {}).get(
        "root_actual_wrapper_r28_unset.py"
    ) != R28_UNSET_WRAPPER_SHA256:
        raise PlanDraftBlocked("source_pin_mismatch")
    if (
        static["MAP_SHA"] != candidate.get("runtime_source_map_sha256")
        or static["INDEX_SHA"] != lineage.get("index_sha256")
        or static["ZIP_SHA"] != lineage.get("bundle_sha256")
        or static["CHECKPOINT_SHA"] != lineage.get("checkpoint_sha256")
        or static["REVIEW_REF"] != review.get("review_ref")
        or static["PRIVATE_HELPER_SHA"]
        != origins.get("custody", {}).get("sha256")
    ):
        raise PlanDraftBlocked("source_manifest_mismatch")

    public_pins = manifest.get("public_pins")
    software_pins = manifest.get("software_pins")
    if (
        _manifest_pin_for_suffix(public_pins, "package/source-packet-index.json")
        != static["INDEX_SHA"]
        or _manifest_pin_for_suffix(public_pins, "package/source-packet.zip")
        != static["ZIP_SHA"]
        or _manifest_pin_for_suffix(public_pins, "package/source-packet-checkpoint.json")
        != static["CHECKPOINT_SHA"]
        or _manifest_pin_for_suffix(public_pins, "runtime/pyyaml-pure/projection.json")
        != static["PROJECTION_SHA"]
        or _manifest_pin_for_suffix(software_pins, "pyyaml-6.0.1.dist-info/record")
        != static["RAW_RECORD_SHA"]
        or _manifest_pin_for_suffix(software_pins, "python.exe") != static["EXE_SHA"]
        or _manifest_pin_for_suffix(software_pins, "python311.dll") != static["DLL_SHA"]
    ):
        raise PlanDraftBlocked("source_manifest_mismatch")
    if (
        review_pins.get("review.json")
        != _manifest_pin_for_suffix(
            public_pins,
            "/" + review.get("directory", "") + "/review.json",
        )
        or review_pins.get("review-bundle.zip")
        != _manifest_pin_for_suffix(
            public_pins,
            "/" + review.get("directory", "") + "/review-bundle.zip",
        )
    ):
        raise PlanDraftBlocked("source_manifest_mismatch")

    digest_values = [
        static[name]
        for name in (
            "PRIVATE_HELPER_SHA",
            "MAP_SHA",
            "INDEX_SHA",
            "ZIP_SHA",
            "CHECKPOINT_SHA",
            "RAW_RECORD_SHA",
            "PROJECTION_SHA",
            "EXE_SHA",
            "DLL_SHA",
        )
    ]
    if any(type(value) is not str or _HEX64.fullmatch(value) is None for value in digest_values):
        raise PlanDraftBlocked("source_pin_unset")
    if any("UNSET" in value for value in digest_values):
        raise PlanDraftBlocked("source_pin_unset")
    if _sha(wrapper_raw) != candidate.get("active_wrapper_sha256"):
        raise PlanDraftBlocked("source_pin_mismatch")


def _synthetic_contract_globals(
    tree: ast.Module, run_once: ast.FunctionDef, manifest: dict, wrapper_raw: bytes
) -> dict[str, Any]:
    root_codes = [
        node
        for node in tree.body
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "ROOT_FAILURE_CODES"
    ]
    root_failure = [
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "RootWrapperFailure"
    ]
    function_defs = {
        node.name: node for node in run_once.body if isinstance(node, ast.FunctionDef)
    }
    needed_functions = [
        function_defs.get(name) for name in ("block", "canonical", "pairs", "parse")
    ]
    if (
        len(root_codes) != 1
        or len(root_failure) != 1
        or any(node is None for node in needed_functions)
    ):
        raise PlanDraftBlocked("plan_source_slice_invalid")
    safe = _simple_assignment(run_once, "SAFE")
    globals_ns: dict[str, Any] = {
        "json": json,
        "re": re,
        "uuid": importlib.import_module("uuid"),
    }
    module = ast.Module(
        body=[root_codes[0], root_failure[0], safe, *needed_functions],
        type_ignores=[],
    )
    try:
        exec(
            compile(ast.fix_missing_locations(module), "<r28-plan-contract-slice>", "exec"),
            globals_ns,
        )
    except BaseException as exc:
        raise PlanDraftBlocked("plan_source_slice_invalid") from exc

    static = _static_wrapper_values(run_once)
    _validate_manifest_links(manifest, wrapper_raw, static)
    for name in static:
        node = _simple_assignment(run_once, name)
        try:
            exec(
                compile(
                    ast.Module(body=[node], type_ignores=[]),
                    "<r28-plan-constant>",
                    "exec",
                ),
                globals_ns,
            )
        except BaseException as exc:
            raise PlanDraftBlocked("plan_source_slice_invalid") from exc

    globals_ns.update(
        {
            "MAX_PLAN": static["MAX_PLAN"],
            "Path": Path,
            "REVIEW_JSON": "review.json",
            "REVIEW_ZIP": "review-bundle.zip",
            "pins": {
                "review.json": manifest["review"]["pins"]["review.json"],
                "review-bundle.zip": manifest["review"]["pins"]["review-bundle.zip"],
            },
            "wrapper_sha": _sha(wrapper_raw),
            "UTC": importlib.import_module("datetime").timezone.utc,
            "datetime": importlib.import_module("datetime").datetime,
            "timedelta": importlib.import_module("datetime").timedelta,
        }
    )
    contract_statements = _contract_nodes(wrapper_raw)[2]
    required_assignment = next(
        node
        for node in contract_statements
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "required"
    )
    expected_assignment = next(
        node
        for node in contract_statements
        if isinstance(node, ast.Assign)
        and len(node.targets) == 1
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "expected"
    )
    try:
        exec(
            compile(
                ast.Module(body=[required_assignment, expected_assignment], type_ignores=[]),
                "<r28-plan-draft-fields>",
                "exec",
            ),
            globals_ns,
        )
    except BaseException as exc:
        raise PlanDraftBlocked("plan_source_slice_invalid") from exc
    required = globals_ns.get("required")
    expected = globals_ns.get("expected")
    if (
        type(required) is not set
        or type(expected) is not dict
        or required - set(expected) != _DYNAMIC_PLAN_FIELDS
    ):
        raise PlanDraftBlocked("plan_source_slice_invalid")
    globals_ns["required"] = required
    globals_ns["expected"] = expected
    return globals_ns


def validate_plan_contract_source_slice(
    prepared_r31: dict, plan_bytes: bytes
) -> dict[str, Any]:
    """Run only the exact R28 parsed-plan gate AST against in-memory bytes.

    This does not run ``main``, enter a protected directory, or touch a route.
    It exists for source-fake checks and delegates all plan field/time decisions
    to the frozen wrapper statements.
    """

    r31 = _load_r31()
    _namespace, _seed_digest, manifest = _reprepare_and_compare(prepared_r31, r31)
    wrapper_raw = prepared_r31["active_wrapper_source"]
    tree, run_once, statements = _contract_nodes(wrapper_raw)
    globals_ns = _synthetic_contract_globals(tree, run_once, manifest, wrapper_raw)
    function = ast.FunctionDef(
        name="_r34_validate_plan_contract_slice",
        args=ast.arguments(
            posonlyargs=[],
            args=[ast.arg(arg="raw")],
            kwonlyargs=[],
            kw_defaults=[],
            defaults=[],
        ),
        body=[
            ast.Assign(
                targets=[ast.Name(id="plan_raw", ctx=ast.Store())],
                value=ast.Name(id="raw", ctx=ast.Load()),
            ),
            *statements,
            ast.Return(value=ast.Name(id="plan", ctx=ast.Load())),
        ],
        decorator_list=[],
    )
    module = ast.Module(body=[function], type_ignores=[])
    try:
        code = compile(ast.fix_missing_locations(module), "<r28-plan-contract-slice>", "exec")
        exec(code, globals_ns)
        return globals_ns[function.name](plan_bytes)
    except FrozenPlanContractFailure:
        raise
    except BaseException as exc:
        code = getattr(exc, "code", None)
        if type(code) is str:
            raise FrozenPlanContractFailure(code) from exc
        raise PlanDraftBlocked("plan_source_slice_invalid") from exc


def _frozen_gate_globals(
    prepared_r31: dict, r31: Any, manifest: dict
) -> tuple[dict[str, Any], bytes, list[ast.stmt]]:
    wrapper_raw = prepared_r31["active_wrapper_source"]
    tree, run_once, statements = _contract_nodes(wrapper_raw)
    globals_ns = _synthetic_contract_globals(tree, run_once, manifest, wrapper_raw)
    return globals_ns, wrapper_raw, statements


def _canonical_plan_from_expected(
    prepared_r31: dict,
    r31: Any,
    manifest: dict,
    *,
    activation_id: str,
    created_at_utc: str,
    expires_at_utc: str,
) -> bytes:
    globals_ns, wrapper_raw, _statements = _frozen_gate_globals(prepared_r31, r31, manifest)
    plan = dict(globals_ns["expected"])
    plan.update(
        {
            "activation_id": activation_id,
            "created_at_utc": created_at_utc,
            "expires_at_utc": expires_at_utc,
        }
    )
    try:
        raw = globals_ns["canonical"](plan)
    except BaseException as exc:
        raise PlanDraftBlocked("plan_gate_rejected") from exc
    try:
        validate_plan_contract_source_slice(prepared_r31, raw)
    except FrozenPlanContractFailure as exc:
        raise PlanDraftBlocked(exc.code) from exc
    except PlanDraftBlocked:
        raise
    if _sha(wrapper_raw) != manifest["candidate"]["active_wrapper_sha256"]:
        raise PlanDraftBlocked("source_pin_mismatch")
    return raw


def prepare_root_plan_draft(
    prepared_r31: dict,
    *,
    activation_id: str,
    created_at_utc: str,
    expires_at_utc: str,
) -> dict[str, Any]:
    """Return an in-memory R28-compatible plan draft and final R31 source map.

    The caller supplies a current R31 ``SOURCE_FAKE_ONLY_DISABLED`` result and
    Root-created identity/timestamps. The returned plan is only a draft; a
    separate Root-owned gate must authorize any protected write.
    """

    r31 = _load_r31()
    namespace, _seed_digest, manifest = _reprepare_and_compare(prepared_r31, r31)
    wrapper_raw = prepared_r31["active_wrapper_source"]
    _tree, run_once, _statements = _contract_nodes(wrapper_raw)
    _static = _static_wrapper_values(run_once)
    _validate_manifest_links(manifest, wrapper_raw, _static)
    plan_bytes = _canonical_plan_from_expected(
        prepared_r31,
        r31,
        manifest,
        activation_id=activation_id,
        created_at_utc=created_at_utc,
        expires_at_utc=expires_at_utc,
    )
    plan_sha256 = _sha(plan_bytes)
    try:
        final_prepared = r31.prepare_root_startup(namespace, plan_sha256=plan_sha256)
    except BaseException as exc:
        raise PlanDraftBlocked("r31_reprepare_failed") from exc
    final_wrapper_sha256 = _sha(final_prepared.get("active_wrapper_source", b""))
    initial_wrapper_sha256 = _sha(wrapper_raw)
    final_plan = final_prepared.get("manifest", {}).get("runtime_outputs", {}).get("plan", {})
    final_software_pins = final_prepared.get("software_pins", {})
    plan_key = _path_key(namespace["plan_path"])
    if final_wrapper_sha256 != initial_wrapper_sha256:
        raise PlanDraftBlocked("wrapper_digest_unstable")
    if (
        final_prepared.get("status") != "SOURCE_FAKE_ONLY_DISABLED"
        or final_plan.get("sha256") != plan_sha256
        or final_software_pins.get(plan_key) != plan_sha256
        or final_prepared.get("manifest", {}).get("candidate", {}).get(
            "active_wrapper_sha256"
        )
        != initial_wrapper_sha256
    ):
        raise PlanDraftBlocked("plan_digest_closure")
    try:
        r31.scope_maps(final_prepared["manifest"])
    except BaseException as exc:
        raise PlanDraftBlocked("plan_digest_closure") from exc
    return {
        "schema": R34_DRAFT_SCHEMA,
        "status": "DRAFT_ONLY_NO_AUTHORITY",
        "authority_notice": (
            "DRAFT_ONLY_NO_AUTHORITY: prepared bytes grant no permission; only a separate "
            "Root gate may write the protected plan."
        ),
        "plan_bytes": plan_bytes,
        "plan_sha256": plan_sha256,
        "wrapper_sha256": initial_wrapper_sha256,
        "prepared_r31": final_prepared,
    }


if __name__ == "__main__":
    raise SystemExit("Call prepare_root_plan_draft() with a current disabled R31 result.")
