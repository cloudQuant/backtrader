"""R10 additive once/predeployment handoff for the frozen M01 source chain.

R10 composes an exact R28 once source successor and a generated R31 runner.
The R31 canonical map remains 118 public + 36 software entries. The new once
source, changed runner/source map, and the frozen R9 bootstrap sidecar are
separately bound in the parent hold addition. No deployment or activation is
performed by this module.
"""

from __future__ import annotations

import ast
import copy
import dataclasses
import hashlib
import json
import ntpath
import re
import subprocess
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r31_root_startup_prepare_r1 as _R31
from scripts import iteration41_okx_m01_r33_bootstrap_sidecar_transport_r9_r1 as _R9
from scripts import iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1 as _R8
from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r6 as _R6


R31_SHA256 = "c95f72c6d168352893339bad5f53e5f48e5b201219a30de8b2de6d90f50e441a"
R31_TEST_SHA256 = "125df2d6e97ce9836fc6bd32b176277d610b7f4c59005968eb80911464484482"
R9_SHA256 = "a5e4532170d41d571151b8a68151802297898c0d4ba5124a7cb06021f1b19dcf"
R8_SHA256 = "cfc7044f9863e76dc16499dd1c9b5047fc00309ddb437929ae990e148b27b38c"
R28_ONCE_SHA256 = "dd3da5e4678b4758e83006f635f88fbff01520cbbed43f103bbd317955e430a5"
R28_OUTER_TEMPLATE_SHA256 = "a143012f98af4579d416363cc2cb5b8551c7217dadbc5cb4ff826a48c89d4c4e"
R28_PACKET_REL = (
    "docs/_internal/opts/requirements/"
    "迭代41-实盘执行风控监控与示例架构重构/evidence/"
    "iteration41-okx-m01-v6-r28-pre-custody-diagnostic-source-fake-r1-2026-10-07"
)
R28_ONCE_REL = R28_PACKET_REL + "/root_diagnostic_once_r28_unset.py"
R10_PREPARATION_SCHEMA = "iteration41.okx.m01.r33.once-predeployment-preparation.r10.r1.v1"
R10_BINDING_SCHEMA = "iteration41.okx.m01.r33.prepared-child-binding.r10.once-predeployment.v1"
R10_HOLD_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition.r10.once-predeployment.v1"
R10_ONCE_ROLE = "r10_generated_r28_once_predeployment_successor"
R10_COMPOSER_ROLE = "r10_public_source_composer"
R10_EXTERNAL_SOURCE_ROLE = "r10_frozen_r28_outer_helper_dependency"
R10_ACTIVATION_SOURCE_ROLE = "r10_r31_activation_regeneration_source"
R10_ONCE_FILENAME = "root_diagnostic_once_r10.py"
R10_MAX_ONCE_BYTES = 2 * 1024 * 1024
R10_MAX_RUNNER_BYTES = 4 * 1024 * 1024
R10_MAX_SOURCE_MAP_BYTES = 1024 * 1024
R10_MAX_DESCRIPTOR_BYTES = 4096
R28_CLI_HELPER_SHA256 = "62b96a9040d530c8ec592471f0595154fb60239ca03bd6d3b56a6c094dfc7c76"
R28_JOB_SHA256 = "0b8076f4cd8aa4419a29a0bbc3f1884e24c2610e2ba5b6cf2000c0cdf861c023"
R28_CLEANUP_SHA256 = "88e566cc837440bcb5bf0f4dba696fb5f9c365f690abcf2a48e2939421f72a82"
R28_EXTERNAL_SOURCE_SPECS = (
    (
        "cli",
        "backtrader_runtime/certification_binance_roundtrip_r3_cli.py",
        R28_CLI_HELPER_SHA256,
    ),
    (
        "job",
        "scripts/iteration41_okx_l03_l04_v4_root_launcher.py",
        R28_JOB_SHA256,
    ),
    (
        "cleanup",
        R28_PACKET_REL + "/source-support/root-driver-r4.py",
        R28_CLEANUP_SHA256,
    ),
)
R28_OUTER_TEMPLATE_REL = R28_PACKET_REL + "/root_prelaunch_v6_candidate_r28.py"
R10_ACTIVATION_TRANSFORM_SCHEMA = (
    "iteration41.okx.m01.r33.r31-held-output-activation-verifier.r10.r1.v1"
)
R10_ACTIVATION_SOURCE_SPECS = (
    (
        "r31",
        "scripts/iteration41_okx_m01_r31_root_startup_prepare_r1.py",
        R31_SHA256,
        "R10.R31_SHA256",
        "scripts.iteration41_okx_m01_r31_root_startup_prepare_r1",
    ),
    (
        "r31_test",
        "tests/unit/runtime/test_iteration41_okx_m01_r31_root_startup_prepare_r1.py",
        R31_TEST_SHA256,
        "R10.R31_TEST_SHA256",
        None,
    ),
    (
        "r30",
        "scripts/iteration41_okx_m01_r30_root_startup_prepare_r1.py",
        "3869e2a8de8939870ea337245b8b6b4723944cef1377ef2779fa5052ff60a045",
        "R31.R30_HELPER_SHA256",
        "scripts.iteration41_okx_m01_r30_root_startup_prepare_r1",
    ),
    (
        "r30_test",
        "tests/unit/runtime/test_iteration41_okx_m01_r30_root_startup_prepare_r1.py",
        "3da52408c597c7461c100c35afd265768de446701fa63e0959e6ffb3effc653e",
        "R31.R30_TEST_SHA256",
        None,
    ),
    (
        "r29",
        "scripts/iteration41_okx_m01_r29_root_startup_prepare_r1.py",
        "9db45f47a89673b323fca2926a3d2c077a872620a8741b63d5895462962d849a",
        "R30.R29_HELPER_SHA256",
        "scripts.iteration41_okx_m01_r29_root_startup_prepare_r1",
    ),
    (
        "r29_test",
        "tests/unit/runtime/test_iteration41_okx_m01_r29_root_startup_prepare_r1.py",
        "83f54cc0547913434c1187952f7bb347ece3a432ec81193cf71d13b86ea154a7",
        "R30.R29_TEST_SHA256",
        None,
    ),
    (
        "r2",
        "scripts/iteration41_okx_m01_r28_root_startup_prepare_r2.py",
        "cb67ba1fe01f959176f92226369c2239fd922ee899b7055948d308e976ce06a3",
        "R29.R2_HELPER_SHA256",
        "scripts.iteration41_okx_m01_r28_root_startup_prepare_r2",
    ),
    (
        "r2_test",
        "tests/unit/runtime/test_iteration41_okx_m01_r28_root_startup_prepare_r2.py",
        "35335b924a6c8cfab8185ef67c3f1aa66fd29c0664bf8e58eb93886b3c940f57",
        "R29.R2_TEST_SHA256",
        None,
    ),
    (
        "scopefix",
        "scripts/iteration41_okx_m01_r29_root_metadata_scopefix_r1.py",
        "a4e8f943e00dd8de1cb05b27c166dfde0043ff1fdae7094992c5d418fa13b14e",
        "R29.R29_SCOPEFIX_HELPER_SHA256",
        "scripts.iteration41_okx_m01_r29_root_metadata_scopefix_r1",
    ),
    (
        "scopefix_test",
        "tests/unit/runtime/test_iteration41_okx_m01_r29_root_metadata_scopefix_r1.py",
        "033ef472836e3a89c67c0730e647740d4c0eb96bb0098ec48abf52927a11588b",
        "R29.R29_SCOPEFIX_TEST_SHA256",
        None,
    ),
)
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_R10_ACTIVE_OUTER_SUPPORT = br'''
R10_ACTIVATION_TRANSFORM_SCHEMA = __SCHEMA__
R10_ACTIVATION_PLAN_SHA256 = __PLAN_SHA256__
R10_R31_BASE_OUTER_SHA256 = __BASE_OUTER_SHA256__
R10_R31_BASE_OUTER_SIZE_BYTES = __BASE_OUTER_SIZE__
R10_R31_BASE_WRAPPER_SHA256 = __BASE_WRAPPER_SHA256__
R10_R31_BASE_WRAPPER_SIZE_BYTES = __BASE_WRAPPER_SIZE__
R10_ACTIVATION_NAMESPACE = json.loads(__NAMESPACE_JSON__)
R10_ACTIVATION_SOURCE_ROWS = json.loads(__SOURCE_ROWS_JSON__)
R10_ACTIVATION_SOURCE_NAMES = (
    "r31", "r31_test", "r30", "r30_test", "r29", "r29_test",
    "r2", "r2_test", "scopefix", "scopefix_test",
)
R10_ACTIVATION_MODULE_NAMES = {
    "r2": "scripts.iteration41_okx_m01_r28_root_startup_prepare_r2",
    "scopefix": "scripts.iteration41_okx_m01_r29_root_metadata_scopefix_r1",
    "r29": "scripts.iteration41_okx_m01_r29_root_startup_prepare_r1",
    "r30": "scripts.iteration41_okx_m01_r30_root_startup_prepare_r1",
    "r31": "scripts.iteration41_okx_m01_r31_root_startup_prepare_r1",
}


def _r10_activation_read_source(row):
    _check(
        type(row) is dict
        and set(row) == {"name", "relative", "path", "sha256", "size_bytes", "role", "origin", "module_name"}
        and type(row["name"]) is str
        and type(row["relative"]) is str
        and type(row["path"]) is str
        and type(row["sha256"]) is str
        and _HEX64.fullmatch(row["sha256"]) is not None
        and type(row["size_bytes"]) is int
        and 0 < row["size_bytes"] <= 2 * 1024 * 1024
        and row["role"] == "r10_r31_activation_regeneration_source:" + row["name"]
        and type(row["origin"]) is str
        and bool(row["origin"]),
        "r10_activation_source_shape",
    )
    expected_path = str(ROOT / Path(*row["relative"].split("/")))
    _check(
        os.path.normcase(os.path.normpath(row["path"]))
        == os.path.normcase(os.path.normpath(expected_path)),
        "r10_activation_source_path",
    )
    try:
        with Path(row["path"]).open("rb") as stream:
            before = os.fstat(stream.fileno())
            stream.seek(0)
            raw = stream.read(row["size_bytes"] + 1)
            after = os.fstat(stream.fileno())
    except BaseException:
        raise PrelaunchBlocked("r10_activation_source_unavailable") from None
    identity_before = (
        before.st_dev, before.st_ino, before.st_size,
        getattr(before, "st_mtime_ns", None), getattr(before, "st_ctime_ns", None),
    )
    identity_after = (
        after.st_dev, after.st_ino, after.st_size,
        getattr(after, "st_mtime_ns", None), getattr(after, "st_ctime_ns", None),
    )
    _check(identity_before == identity_after, "r10_activation_source_changed")
    _check(
        type(raw) is bytes
        and len(raw) == row["size_bytes"]
        and before.st_size == row["size_bytes"]
        and _sha(raw) == row["sha256"],
        "r10_activation_source_pin",
    )
    return raw


def _r10_activation_held_bytes(held, path):
    _check(type(held) is dict and type(path) is str, "r10_activation_held_shape")
    target = os.path.normcase(os.path.normpath(str(Path(path))))
    matches = [
        value
        for key, value in held.items()
        if type(key) is str
        and os.path.normcase(os.path.normpath(key)) == target
    ]
    _check(len(matches) == 1 and type(matches[0]) is bytes, "r10_activation_held_missing")
    return matches[0]


def _r10_regenerate_r31_outputs(plan_raw):
    _check(
        type(plan_raw) is bytes
        and 0 < len(plan_raw) <= MAX_PLAN_BYTES
        and _sha(plan_raw) == R10_ACTIVATION_PLAN_SHA256,
        "r10_activation_plan_binding",
    )
    rows = R10_ACTIVATION_SOURCE_ROWS
    _check(
        type(rows) is list
        and len(rows) == len(R10_ACTIVATION_SOURCE_NAMES)
        and [row.get("name") for row in rows if type(row) is dict]
        == list(R10_ACTIVATION_SOURCE_NAMES),
        "r10_activation_source_set",
    )
    _check(
        all(
            row.get("module_name") == R10_ACTIVATION_MODULE_NAMES.get(row.get("name"))
            for row in rows
        ),
        "r10_activation_module_binding",
    )
    source_bytes = {row["name"]: _r10_activation_read_source(row) for row in rows}
    saved_modules = {}
    sentinel = object()
    target_names = ["scripts", *R10_ACTIVATION_MODULE_NAMES.values()]
    for name in target_names:
        saved_modules[name] = sys.modules.get(name, sentinel)
    try:
        import types
        from importlib.machinery import ModuleSpec

        package = types.ModuleType("scripts")
        package.__package__ = "scripts"
        package.__path__ = []
        package.__spec__ = ModuleSpec("scripts", loader=None, is_package=True)
        sys.modules["scripts"] = package
        modules = {}
        for key in ("r2", "scopefix", "r29", "r30", "r31"):
            module_name = R10_ACTIVATION_MODULE_NAMES[key]
            row = next(item for item in rows if item["name"] == key)
            module = types.ModuleType(module_name)
            module.__file__ = row["path"]
            module.__package__ = "scripts"
            module.__spec__ = ModuleSpec(module_name, loader=None)
            sys.modules[module_name] = module
            setattr(package, module_name.rsplit(".", 1)[1], module)
            exec(
                compile(source_bytes[key], row["path"], "exec", dont_inherit=True),
                module.__dict__,
            )
            modules[key] = module
        prepared = modules["r31"].prepare_root_startup(
            dict(R10_ACTIVATION_NAMESPACE),
            plan_sha256=R10_ACTIVATION_PLAN_SHA256,
        )
    except PrelaunchBlocked:
        raise
    except BaseException:
        raise PrelaunchBlocked("r10_activation_regeneration_failed") from None
    finally:
        for name, previous in saved_modules.items():
            if previous is sentinel:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = previous
    _check(
        type(prepared) is dict
        and prepared.get("status") == "SOURCE_FAKE_ONLY_DISABLED"
        and type(prepared.get("manifest")) is dict
        and prepared["manifest"].get("runtime_namespace") == R10_ACTIVATION_NAMESPACE,
        "r10_activation_regenerated_manifest",
    )
    regenerated_software = prepared["manifest"].get("software_pins")
    _check(type(regenerated_software) is dict, "r10_activation_regenerated_software_map")
    plan_key = os.path.normcase(os.path.normpath(R10_ACTIVATION_NAMESPACE["plan_path"]))
    regenerated_plan_pins = [
        digest
        for path, digest in regenerated_software.items()
        if type(path) is str and os.path.normcase(os.path.normpath(path)) == plan_key
    ]
    _check(
        len(regenerated_plan_pins) == 1
        and regenerated_plan_pins[0] == R10_ACTIVATION_PLAN_SHA256,
        "r10_activation_regenerated_plan_pin",
    )
    outer = prepared.get("active_outer_source")
    wrapper = prepared.get("active_wrapper_source")
    _check(
        type(outer) is bytes
        and len(outer) == R10_R31_BASE_OUTER_SIZE_BYTES
        and _sha(outer) == R10_R31_BASE_OUTER_SHA256
        and type(wrapper) is bytes
        and len(wrapper) == R10_R31_BASE_WRAPPER_SIZE_BYTES
        and _sha(wrapper) == R10_R31_BASE_WRAPPER_SHA256,
        "r10_activation_regenerated_output_pin",
    )
    return prepared, outer, wrapper


def _r10_verify_r31_wrapper(
    held, active_wrapper, wrapper_template, outer_template, *, outer_template_sha256
):
    _check(
        type(wrapper_template) is bytes
        and _sha(wrapper_template) == WRAPPER_TEMPLATE_SHA256
        and type(outer_template) is bytes
        and _sha(outer_template) == outer_template_sha256,
        "r10_activation_original_template_binding",
    )
    held_wrapper = _r10_activation_held_bytes(
        held, R10_ACTIVATION_NAMESPACE["active_wrapper_path"]
    )
    held_plan = _r10_activation_held_bytes(held, R10_ACTIVATION_NAMESPACE["plan_path"])
    held_outer = _r10_activation_held_bytes(held, R10_ACTIVATION_NAMESPACE["self_path"])
    _check(
        type(active_wrapper) is bytes
        and held_wrapper == active_wrapper
        and _sha(active_wrapper) == ACTIVE_WRAPPER_SHA256,
        "r10_activation_held_wrapper_binding",
    )
    _check(
        type(held_outer) is bytes
        and R10_ACTIVATION_TRANSFORM_SCHEMA.encode("ascii") in held_outer,
        "r10_activation_active_outer_binding",
    )
    _prepared, _base_outer, regenerated_wrapper = _r10_regenerate_r31_outputs(held_plan)
    _check(
        regenerated_wrapper == active_wrapper
        and _sha(regenerated_wrapper) == ACTIVE_WRAPPER_SHA256,
        "r10_activation_r31_wrapper_mismatch",
    )
    return True


'''


class OncePredeploymentBlocked(ValueError):
    """A fixed public source, binding, or predeployment contract failed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise OncePredeploymentBlocked(reason)


def _bounded_public(path: Path, maximum: int, expected: Optional[str] = None) -> bytes:
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise OncePredeploymentBlocked("public_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= maximum, "public_source_size")
    if expected is not None:
        _check(_sha(raw) == expected, "public_source_pin")
    return raw


def _literal_source_value(node: ast.AST) -> str:
    """Read only literal string/Path expressions from pinned public source AST."""
    if isinstance(node, ast.Constant) and type(node.value) is str:
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _literal_source_value(node.left) + _literal_source_value(node.right)
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "Path"
        and len(node.args) == 1
        and not node.keywords
    ):
        return _literal_source_value(node.args[0])
    raise OncePredeploymentBlocked("external_source_origin_expression")


def _source_assignments(raw: bytes) -> dict[str, ast.AST]:
    try:
        tree = ast.parse(raw.decode("utf-8"))
    except (UnicodeDecodeError, SyntaxError, ValueError):
        raise OncePredeploymentBlocked("external_source_origin_parse") from None
    values: dict[str, ast.AST] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, ast.AnnAssign):
            targets = [node.target]
        else:
            continue
        for target in targets:
            if isinstance(target, ast.Name):
                values[target.id] = node.value
    return values


def _source_literal(values: dict[str, ast.AST], name: str) -> str:
    node = values.get(name)
    _check(node is not None, "external_source_origin_missing")
    return _literal_source_value(node)


def _external_parent_sources(
    root: str, once_raw: bytes, outer_template_raw: bytes
) -> tuple[tuple[str, str, bytes, str, str, str], ...]:
    """Collect exact public helper bytes and bind each to a frozen AST origin."""
    repo = _repo_root()
    once_values = _source_assignments(once_raw)
    outer_values = _source_assignments(outer_template_raw)
    root_key = ntpath.normcase(ntpath.normpath(root))
    specs = {name: (relative, expected) for name, relative, expected in R28_EXTERNAL_SOURCE_SPECS}
    origins = {
        "cli": (
            _source_literal(once_values, "R28_CLI_HELPER_SHA256")
            == specs["cli"][1]
            and _source_literal(outer_values, "CLI_REL") == specs["cli"][0]
            and _source_literal(outer_values, "CLI_SHA256") == specs["cli"][1],
            "R28_ONCE.R28_CLI_HELPER_SHA256+R28_OUTER.CLI_REL+CLI_SHA256",
        ),
        "job": (
            _source_literal(once_values, "R28_JOB_SHA256") == specs["job"][1]
            and ntpath.normcase(ntpath.normpath(_source_literal(once_values, "R28_JOB_PATH")))
            == ntpath.normcase(ntpath.normpath(ntpath.join(root, specs["job"][0]))),
            "R28_ONCE.R28_JOB_PATH+R28_JOB_SHA256",
        ),
        "cleanup": (
            _source_literal(once_values, "R28_CLEANUP_SHA256") == specs["cleanup"][1]
            and ntpath.normcase(ntpath.normpath(_source_literal(once_values, "R28_CLEANUP_PATH")))
            == ntpath.normcase(ntpath.normpath(ntpath.join(root, specs["cleanup"][0]))),
            "R28_ONCE.R28_CLEANUP_PATH+R28_CLEANUP_SHA256",
        ),
    }
    _check(root_key == ntpath.normcase(ntpath.normpath(str(repo))), "external_source_root_binding")
    for valid, _origin in origins.values():
        _check(valid, "external_source_ast_origin_mismatch")
    entries = []
    for name, relative, expected in R28_EXTERNAL_SOURCE_SPECS:
        path = ntpath.join(root, relative.replace("/", "\\"))
        _check(_R9._absolute_windows_path(path), "external_source_path")
        raw = _bounded_public(repo / Path(relative), 16 * 1024 * 1024, expected)
        entries.append(
            (
                name,
                path,
                raw,
                expected,
                R10_EXTERNAL_SOURCE_ROLE + ":" + name,
                origins[name][1],
            )
        )

    activation_raws = {}
    for name, relative, expected, _origin, _module_name in R10_ACTIVATION_SOURCE_SPECS:
        activation_raws[name] = _bounded_public(repo / Path(relative), 2 * 1024 * 1024, expected)
    r31_values = _source_assignments(activation_raws["r31"])
    r30_values = _source_assignments(activation_raws["r30"])
    r29_values = _source_assignments(activation_raws["r29"])
    activation_expected = {
        "r30": _source_literal(r31_values, "R30_HELPER_SHA256"),
        "r30_test": _source_literal(r31_values, "R30_TEST_SHA256"),
        "r29": _source_literal(r30_values, "R29_HELPER_SHA256"),
        "r29_test": _source_literal(r30_values, "R29_TEST_SHA256"),
        "scopefix": _source_literal(r30_values, "R29_SCOPEFIX_HELPER_SHA256"),
        "scopefix_test": _source_literal(r30_values, "R29_SCOPEFIX_TEST_SHA256"),
        "r2": _source_literal(r29_values, "R2_HELPER_SHA256"),
        "r2_test": _source_literal(r29_values, "R2_TEST_SHA256"),
    }
    _check(
        _source_literal(r31_values, "R30_MODULE")
        == "scripts.iteration41_okx_m01_r30_root_startup_prepare_r1"
        and _source_literal(r30_values, "R29_MODULE")
        == "scripts.iteration41_okx_m01_r29_root_startup_prepare_r1"
        and _source_literal(r29_values, "R2_MODULE")
        == "scripts.iteration41_okx_m01_r28_root_startup_prepare_r2"
        and _source_literal(r29_values, "R29_SCOPEFIX_MODULE")
        == "scripts.iteration41_okx_m01_r29_root_metadata_scopefix_r1",
        "activation_module_origin_mismatch",
    )
    for name, relative, expected, origin, module_name in R10_ACTIVATION_SOURCE_SPECS:
        raw = activation_raws[name]
        if name in activation_expected:
            _check(activation_expected[name] == expected, "activation_dependency_pin_mismatch")
        elif name == "r31":
            _check(expected == R31_SHA256, "activation_r31_pin_mismatch")
        elif name == "r31_test":
            _check(expected == R31_TEST_SHA256, "activation_r31_test_pin_mismatch")
        entries.append(
            (
                name,
                ntpath.join(root, relative.replace("/", "\\")),
                raw,
                expected,
                R10_ACTIVATION_SOURCE_ROLE + ":" + name,
                origin,
            )
        )
    return tuple(entries)


def _repo_root() -> Path:
    path = Path(_R31.__file__).resolve()
    _check(path.name == "iteration41_okx_m01_r31_root_startup_prepare_r1.py", "r31_module_path")
    return path.parents[1]


def _verify_chain() -> Path:
    root = _repo_root()
    source = _bounded_public(Path(_R31.__file__), 512 * 1024, R31_SHA256)
    test = _bounded_public(
        root / "tests/unit/runtime/test_iteration41_okx_m01_r31_root_startup_prepare_r1.py",
        512 * 1024,
        R31_TEST_SHA256,
    )
    r9 = _bounded_public(Path(_R9.__file__), 512 * 1024, R9_SHA256)
    r8 = _bounded_public(Path(_R8.__file__), 512 * 1024, R8_SHA256)
    _check(bool(source) and bool(test) and bool(r9) and bool(r8), "source_chain_empty")
    return root


def _composer_source() -> tuple[str, bytes, str]:
    path = Path(__file__).resolve()
    _check(path.name == "iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1.py", "composer_path")
    raw = _bounded_public(path, 512 * 1024)
    return str(path), raw, _sha(raw)


def _manifest_from_runner(raw: bytes) -> dict[str, Any]:
    try:
        tree = ast.parse(raw.decode("utf-8"))
    except (UnicodeDecodeError, SyntaxError, ValueError):
        raise OncePredeploymentBlocked("runner_manifest_parse") from None
    assignments = [
        node
        for node in tree.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "MANIFEST" for target in node.targets)
    ]
    _check(len(assignments) == 1, "runner_manifest_assignment")
    value = assignments[0].value
    _check(
        isinstance(value, ast.Call)
        and isinstance(value.func, ast.Attribute)
        and isinstance(value.func.value, ast.Name)
        and value.func.value.id == "json"
        and value.func.attr == "loads"
        and len(value.args) == 1
        and isinstance(value.args[0], ast.Constant)
        and type(value.args[0].value) is str,
        "runner_manifest_literal",
    )
    try:
        manifest = json.loads(value.args[0].value)
    except BaseException:
        raise OncePredeploymentBlocked("runner_manifest_json") from None
    _check(type(manifest) is dict, "runner_manifest_shape")
    return manifest


def _manifest_digest(manifest: dict[str, Any]) -> str:
    payload = dict(manifest)
    payload.pop("manifest_binding_sha256", None)
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return _sha(raw)


def _seal_manifest(manifest: dict[str, Any]) -> None:
    manifest["manifest_binding_sha256"] = _manifest_digest(manifest)


def _replace_once(raw: bytes, old: bytes, new: bytes, code: str) -> bytes:
    _check(type(raw) is bytes and raw.count(old) == 1, code)
    return raw.replace(old, new, 1)


def _replace_literal_path(raw: bytes, symbol: bytes, value: str) -> bytes:
    pattern = re.compile(rb"(?m)^" + re.escape(symbol) + rb" = Path\([^\r\n]*\)\r?$")
    replacement = symbol + b" = Path(" + repr(value).encode("utf-8") + b")"
    result, count = pattern.subn(lambda _match: replacement, raw, count=1)
    _check(count == 1, "once_namespace_anchor")
    return result


def _once_successor_source(
    base_raw: bytes,
    manifest: dict[str, Any],
    *,
    active_outer_size_bytes: int,
    active_wrapper_size_bytes: int,
    external_parent_sources: tuple[tuple[str, str, bytes, str, str, str], ...],
) -> bytes:
    _check(type(base_raw) is bytes and _sha(base_raw) == R28_ONCE_SHA256, "r28_once_pin")
    namespace = manifest.get("runtime_namespace")
    root = manifest.get("root")
    custody = manifest.get("runtime_helper_origins", {}).get("custody", {}).get("runtime_path")
    candidate = manifest.get("candidate")
    _check(
        type(namespace) is dict
        and type(root) is str
        and type(custody) is str
        and type(candidate) is dict,
        "manifest_namespace",
    )
    active_outer_path = namespace.get("self_path")
    active_wrapper_path = namespace.get("active_wrapper_path")
    active_outer_sha = candidate.get("active_outer_sha256")
    active_wrapper_sha = candidate.get("active_wrapper_sha256")
    _check(
        type(active_outer_path) is str
        and type(active_wrapper_path) is str
        and type(active_outer_sha) is str
        and _HEX64.fullmatch(active_outer_sha) is not None
        and type(active_wrapper_sha) is str
        and _HEX64.fullmatch(active_wrapper_sha) is not None
        and type(active_outer_size_bytes) is int
        and 0 < active_outer_size_bytes <= 2 * 1024 * 1024
        and type(active_wrapper_size_bytes) is int
        and 0 < active_wrapper_size_bytes <= 2 * 1024 * 1024,
        "manifest_active_source_pins",
    )
    external_by_name = {entry[0]: entry for entry in external_parent_sources}
    expected_external_names = {"cli", "job", "cleanup"} | {
        name for name, _relative, _expected, _origin, _module_name in R10_ACTIVATION_SOURCE_SPECS
    }
    _check(
        len(external_parent_sources) == len(expected_external_names)
        and len(external_by_name) == len(expected_external_names)
        and set(external_by_name) == expected_external_names,
        "external_source_set",
    )
    origin_by_name = {
        "cli": "R28_ONCE.R28_CLI_HELPER_SHA256+R28_OUTER.CLI_REL+CLI_SHA256",
        "job": "R28_ONCE.R28_JOB_PATH+R28_JOB_SHA256",
        "cleanup": "R28_ONCE.R28_CLEANUP_PATH+R28_CLEANUP_SHA256",
    }
    relative_by_name = {name: relative for name, relative, _expected in R28_EXTERNAL_SOURCE_SPECS}
    digest_by_name = {name: digest for name, _relative, digest in R28_EXTERNAL_SOURCE_SPECS}
    origin_by_name.update(
        {
            name: origin
            for name, _relative, _digest, origin, _module_name in R10_ACTIVATION_SOURCE_SPECS
        }
    )
    relative_by_name.update(
        {
            name: relative
            for name, relative, _digest, _origin, _module_name in R10_ACTIVATION_SOURCE_SPECS
        }
    )
    digest_by_name.update(
        {
            name: digest
            for name, _relative, digest, _origin, _module_name in R10_ACTIVATION_SOURCE_SPECS
        }
    )
    for name, path, source_raw, digest, role, origin in external_parent_sources:
        _check(
            type(name) is str
            and name in external_by_name
            and type(path) is str
            and type(source_raw) is bytes
            and type(digest) is str
            and _HEX64.fullmatch(digest) is not None
            and type(role) is str
            and type(origin) is str
            and len(source_raw) > 0
            and _sha(source_raw) == digest
            and digest == digest_by_name[name]
            and ntpath.normcase(ntpath.normpath(path))
            == ntpath.normcase(ntpath.normpath(ntpath.join(root, relative_by_name[name])))
            and role
            == (
                R10_EXTERNAL_SOURCE_ROLE + ":" + name
                if name in {"cli", "job", "cleanup"}
                else R10_ACTIVATION_SOURCE_ROLE + ":" + name
            )
            and origin == origin_by_name[name]
            and _R9._absolute_windows_path(path),
            "external_source_entry_shape",
        )
    raw = base_raw
    for symbol, value in (
        (b"R28_ROOT", root),
        (b"R28_CONTROL", namespace["control_dir"]),
        (b"R28_DEPLOYMENT", namespace["deployment_dir"]),
        (b"R28_CUSTODY_PATH", custody),
    ):
        raw = _replace_literal_path(raw, symbol, value)

    custody_assignment = (
        b"R28_CUSTODY_PATH = Path(" + repr(custody).encode("utf-8") + b")\n"
    )
    active_source_constants = (
        custody_assignment
        + b"R10_ACTIVE_OUTER_PATH = Path("
        + repr(active_outer_path).encode("utf-8")
        + b")\nR10_ACTIVE_OUTER_SHA256 = "
        + repr(active_outer_sha).encode("ascii")
        + b"\nR10_ACTIVE_OUTER_SIZE_BYTES = "
        + str(active_outer_size_bytes).encode("ascii")
        + b"\nR10_ACTIVE_WRAPPER_PATH = Path("
        + repr(active_wrapper_path).encode("utf-8")
        + b")\nR10_ACTIVE_WRAPPER_SHA256 = "
        + repr(active_wrapper_sha).encode("ascii")
        + b"\nR10_ACTIVE_WRAPPER_SIZE_BYTES = "
        + str(active_wrapper_size_bytes).encode("ascii")
        + b"\n"
    )
    for name, path, source_raw, digest, _role, _origin in external_parent_sources:
        upper = name.upper()
        active_source_constants += (
            f"R10_EXTERNAL_{upper}_PATH = Path({path!r})\n".encode("utf-8")
            + f"R10_EXTERNAL_{upper}_SHA256 = {digest!r}\n".encode("ascii")
            + f"R10_EXTERNAL_{upper}_SIZE_BYTES = {len(source_raw)}\n".encode("ascii")
        )
    raw = _replace_once(
        raw,
        custody_assignment,
        active_source_constants,
        "once_active_source_constants_anchor",
    )

    raw = _replace_once(
        raw,
        b'        str(R28_CONTROL / "root_prelaunch_active.py"),\n',
        b"        str(R10_ACTIVE_OUTER_PATH),\n",
        "once_outer_command_path_anchor",
    )

    # All named public source bytes are sourced from the already held 154 map.
    insert_anchor = b"def _prepare_active_sources(root_review_bytes):\n"
    held_lookup = b'''def _r10_held_bytes(path):
    held_map = R10_HELD_MAP
    _check(type(held_map) is dict, "r10_held_map_unavailable")
    target = os.path.normcase(os.path.normpath(str(Path(path))))
    matches = [
        raw for held_path, raw in held_map.items()
        if type(held_path) is str
        and os.path.isabs(held_path)
        and os.path.normcase(os.path.normpath(held_path)) == target
    ]
    _check(len(matches) == 1 and type(matches[0]) is bytes, "r10_held_source_missing")
    return matches[0]


def _r10_same_path(left, right):
    try:
        first = os.path.normcase(os.path.normpath(str(left)))
        second = os.path.normcase(os.path.normpath(str(right)))
    except BaseException:
        return False
    return bool(first) and first == second


def _r10_read_pinned_source(path, expected, maximum, expected_size):
    _check(type(expected) is str and len(expected) == 64, "r10_external_pin_shape")
    _check(type(maximum) is int and 0 < maximum <= 16 * 1024 * 1024, "r10_external_read_bound")
    _check(type(expected_size) is int and 0 < expected_size <= maximum, "r10_external_size_pin")
    try:
        with Path(path).open("rb") as stream:
            before = os.fstat(stream.fileno())
            stream.seek(0)
            raw = stream.read(maximum + 1)
            after = os.fstat(stream.fileno())
    except BaseException:
        raise ValueError("r10_external_source_unavailable") from None
    before_identity = (
        before.st_dev, before.st_ino, before.st_size,
        getattr(before, "st_mtime_ns", None), getattr(before, "st_ctime_ns", None),
    )
    after_identity = (
        after.st_dev, after.st_ino, after.st_size,
        getattr(after, "st_mtime_ns", None), getattr(after, "st_ctime_ns", None),
    )
    _check(before_identity == after_identity, "r10_external_source_changed_during_read")
    _check(type(raw) is bytes and len(raw) == expected_size and len(raw) <= maximum, "r10_external_source_size")
    _check(before.st_size == expected_size, "r10_external_source_handle_size")
    _check(_sha(raw) == expected, "r10_external_source_pin")
    return raw


'''
    raw = _replace_once(raw, insert_anchor, held_lookup + insert_anchor, "once_held_lookup_anchor")
    for old, new, code in (
        (b"    fill_raw = fill_path.read_bytes()\n", b"    fill_raw = _r10_held_bytes(fill_path)\n", "once_fill_read_anchor"),
        (b"    outer_template = (R28_ROOT / R28_OUTER_REL).read_bytes()\n", b"    outer_template = _r10_held_bytes(R28_ROOT / R28_OUTER_REL)\n", "once_outer_template_anchor"),
        (b"    inner_template = (R28_ROOT / R28_INNER_REL).read_bytes()\n", b"    inner_template = _r10_held_bytes(R28_ROOT / R28_INNER_REL)\n", "once_inner_template_anchor"),
    ):
        raw = _replace_once(raw, old, new, code)
    raw = _replace_once(
        raw,
        b'    _check(_sha(inner_template) == R28_INNER_TEMPLATE_SHA256, "r28_inner_template_pin_mismatch")\n',
        b'    _check(_sha(inner_template) == R28_INNER_TEMPLATE_SHA256, "r28_inner_template_pin_mismatch")\n'
        b'    outer_template_module = _load_module(outer_template, R28_ROOT / R28_OUTER_REL, "_r10_r28_outer_template")\n'
        b'    inner_template_module = _load_module(inner_template, R28_ROOT / R28_INNER_REL, "_r10_r28_inner_template")\n',
        "once_r28_template_module_anchor",
    )
    raw = _replace_once(
        raw,
        b"    return active_outer, active_inner, fill_raw\n",
        b'    _check(outer_template_module.normalize_driver_activation(active_outer) == outer_template, "r10_r28_fill_outer_template")\n'
        b'    _check(inner_template_module.normalize_activation_copy(active_inner) == inner_template, "r10_r28_fill_wrapper_template")\n'
        b"    active_outer = _r10_held_bytes(R10_ACTIVE_OUTER_PATH)\n"
        b"    active_inner = _r10_held_bytes(R10_ACTIVE_WRAPPER_PATH)\n"
        b'    _check(len(active_outer) == R10_ACTIVE_OUTER_SIZE_BYTES and _sha(active_outer) == R10_ACTIVE_OUTER_SHA256, "r10_active_outer_hold_pin")\n'
        b'    _check(len(active_inner) == R10_ACTIVE_WRAPPER_SIZE_BYTES and _sha(active_inner) == R10_ACTIVE_WRAPPER_SHA256, "r10_active_wrapper_hold_pin")\n'
        b"    return active_outer, active_inner, fill_raw\n",
        "once_active_output_handoff_anchor",
    )

    raw = _replace_once(
        raw,
        b"R28_TEST_OUTER_PORT = None\n",
        b"",
        "once_test_port_declaration_anchor",
    )

    # Once execution is delegated to the fixed R10 source successor. No
    # R28_TEST_OUTER_PORT branch is added or used.
    outer_start = raw.index(b"def _execute_outer_process(active_outer, active_inner, fill_raw):\n")
    outer_end = raw.index(b"\ndef _outer_response(", outer_start)
    current = raw[outer_start:outer_end]
    current = _replace_once(
        current,
        b'    outer_path = R28_CONTROL / "root_prelaunch_active.py"\n'
        b'    inner_path = R28_CONTROL / "root_actual_wrapper_r28.py"\n',
        b"    outer_path = R10_ACTIVE_OUTER_PATH\n"
        b"    inner_path = R10_ACTIVE_WRAPPER_PATH\n"
        b'    _check(len(active_outer) == R10_ACTIVE_OUTER_SIZE_BYTES and _sha(active_outer) == R10_ACTIVE_OUTER_SHA256 and _r10_held_bytes(outer_path) == active_outer, "r10_active_outer_runtime_pin")\n'
        b'    _check(len(active_inner) == R10_ACTIVE_WRAPPER_SIZE_BYTES and _sha(active_inner) == R10_ACTIVE_WRAPPER_SHA256 and _r10_held_bytes(inner_path) == active_inner, "r10_active_wrapper_runtime_pin")\n',
        "once_active_output_runtime_anchor",
    )
    current = _replace_once(
        current,
        b"    template = (root / R28_OUTER_REL).read_bytes()\n"
        b"    _check(\n"
        b"        outer_module.normalize_driver_activation(active_outer) == template, \"r28_outer_transform\"\n"
        b"    )\n",
        b"    template = _r10_held_bytes(root / R28_OUTER_REL)\n"
        b'    _check(_sha(template) == R28_OUTER_TEMPLATE_SHA256, "r28_outer_template_pin_mismatch")\n',
        "once_outer_source_anchor",
    )
    current = _replace_once(
        current,
        b"    custody_raw = R28_CUSTODY_PATH.read_bytes()\n",
        b"    custody_raw = _r10_held_bytes(R28_CUSTODY_PATH)\n",
        "once_custody_source_anchor",
    )
    current = _replace_once(
        current,
        b"    private_raw = (root / outer_module.PRIVATE_REL).read_bytes()\n",
        b"    private_raw = _r10_held_bytes(root / outer_module.PRIVATE_REL)\n",
        "once_private_source_anchor",
    )
    current = _replace_once(
        current,
        b"    cli_raw = (root / outer_module.CLI_REL).read_bytes()\n",
        b'    _check(outer_module.CLI_SHA256 == R28_CLI_HELPER_SHA256, "r10_cli_digest_origin")\n'
        b'    _check(_r10_same_path(root / outer_module.CLI_REL, R10_EXTERNAL_CLI_PATH), "r10_cli_path_origin")\n'
        b"    cli_raw = _r10_read_pinned_source(\n"
        b"        R10_EXTERNAL_CLI_PATH, R10_EXTERNAL_CLI_SHA256, R10_EXTERNAL_CLI_SIZE_BYTES, R10_EXTERNAL_CLI_SIZE_BYTES\n"
        b"    )\n",
        "once_cli_source_anchor",
    )
    for old, new, code in (
        (
            b'    _check(outer_path == outer_module.SELF_PATH, "r28_active_outer_path")\n',
            b'    _check(_r10_same_path(outer_path, outer_module.SELF_PATH), "r28_active_outer_path")\n',
            "once_outer_path_compare_anchor",
        ),
        (
            b'    _check(inner_path == outer_module.ACTIVE_WRAPPER_PATH, "r28_active_inner_path")\n',
            b'    _check(_r10_same_path(inner_path, outer_module.ACTIVE_WRAPPER_PATH), "r28_active_inner_path")\n',
            "once_inner_path_compare_anchor",
        ),
        (
            b'    _check(R28_CONTROL == outer_module.CONTROL, "r28_control_namespace")\n',
            b'    _check(_r10_same_path(R28_CONTROL, outer_module.CONTROL), "r28_control_namespace")\n',
            "once_control_path_compare_anchor",
        ),
        (
            b'    _check(R28_DEPLOYMENT == outer_module.DEPLOYMENT, "r28_deployment_namespace")\n',
            b'    _check(_r10_same_path(R28_DEPLOYMENT, outer_module.DEPLOYMENT), "r28_deployment_namespace")\n',
            "once_deployment_path_compare_anchor",
        ),
        (
            b'    _check(R28_CUSTODY_PATH == outer_module.CUSTODY_PATH, "r28_custody_path_binding")\n',
            b'    _check(_r10_same_path(R28_CUSTODY_PATH, outer_module.CUSTODY_PATH), "r28_custody_path_binding")\n',
            "once_custody_path_compare_anchor",
        ),
    ):
        current = _replace_once(current, old, new, code)
    old_missing = (
        b"    if os.path.lexists(R28_CONTROL) or os.path.lexists(R28_DEPLOYMENT):\n"
        b'        raise ValueError("r28_control_or_deployment_exists")\n'
    )
    new_missing = (
        b"    _check(os.path.isdir(R28_CONTROL), \"r10_control_not_predeployed\")\n"
        b"    _check(os.path.isdir(R28_DEPLOYMENT), \"r10_deployment_not_predeployed\")\n"
    )
    current = _replace_once(current, old_missing, new_missing, "once_predeployment_anchor")
    current = _replace_once(
        current,
        b"    control = private.create_private_directory(R28_CONTROL)\n",
        b"    control = None  # Root predeployed and externally holds this directory.\n",
        "once_control_create_anchor",
    )

    plan_start = current.index(b"    now = datetime.now(timezone.utc)\n")
    plan_end = current.index(b"    outer_values = outer_module._build_pin_sets(\n", plan_start)
    plan_block = current[plan_start:plan_end]
    plan_replacement = b'''    now = datetime.now(timezone.utc)
    plan_raw = _r10_held_bytes(R28_PLAN_PATH)
    plan = outer_module._validate_plan(plan_raw, now_utc=now)
    _check(
        type(plan) is dict
        and plan.get("status") == "READY_TO_RUN"
        and plan.get("wrapper_sha256") == _sha(active_inner),
        "r10_predeployed_plan_binding",
    )
'''
    _check(b"plan_raw = outer_module._canonical(plan)" in plan_block, "once_plan_block_shape")
    current = current[:plan_start] + plan_replacement + current[plan_end:]
    current = _replace_once(
        current,
        b"    control.write_bytes(\"plan.json\", plan_raw)\n"
        b"    control.write_bytes(\"root_prelaunch_active.py\", active_outer)\n"
        b"    control.write_bytes(\"root_actual_wrapper_r28.py\", active_inner)\n",
        b"    _check(_r10_held_bytes(outer_path) == active_outer, \"r10_outer_hold_mismatch\")\n"
        b"    _check(_r10_held_bytes(inner_path) == active_inner, \"r10_wrapper_hold_mismatch\")\n"
        b"    _check(_r10_held_bytes(R28_PLAN_PATH) == plan_raw, \"r10_plan_hold_mismatch\")\n",
        "once_predeploy_write_anchor",
    )
    current = _replace_once(
        current,
        b"    job_raw = R28_JOB_PATH.read_bytes()\n"
        b"    cleanup_raw = R28_CLEANUP_PATH.read_bytes()\n",
        b'    _check(_r10_same_path(R28_JOB_PATH, R10_EXTERNAL_JOB_PATH), "r10_job_path_origin")\n'
        b'    _check(_r10_same_path(R28_CLEANUP_PATH, R10_EXTERNAL_CLEANUP_PATH), "r10_cleanup_path_origin")\n'
        b'    _check(R28_JOB_SHA256 == R10_EXTERNAL_JOB_SHA256 and R28_CLEANUP_SHA256 == R10_EXTERNAL_CLEANUP_SHA256, "r10_job_digest_origin")\n'
        b"    job_raw = _r10_read_pinned_source(\n"
        b"        R10_EXTERNAL_JOB_PATH, R10_EXTERNAL_JOB_SHA256, R10_EXTERNAL_JOB_SIZE_BYTES, R10_EXTERNAL_JOB_SIZE_BYTES\n"
        b"    )\n"
        b"    cleanup_raw = _r10_read_pinned_source(\n"
        b"        R10_EXTERNAL_CLEANUP_PATH, R10_EXTERNAL_CLEANUP_SHA256, R10_EXTERNAL_CLEANUP_SIZE_BYTES, R10_EXTERNAL_CLEANUP_SIZE_BYTES\n"
        b"    )\n",
        "once_job_source_anchor",
    )
    raw = raw[:outer_start] + current + raw[outer_end:]

    outer_response_start = raw.index(b"def _outer_response(active_outer, active_inner, root_review_bytes, pins, fill_raw, output):\n")
    outer_response_end = raw.index(b"\ndef _parse_outer_response(", outer_response_start)
    outer_response = raw[outer_response_start:outer_response_end]
    old_test_port = (
        b"    test_port = R28_TEST_OUTER_PORT\n"
        b"    if test_port is None:\n"
        b"        response = _execute_outer_process(active_outer, active_inner, fill_raw)\n"
        b"    else:\n"
        b"        response = test_port(\n"
        b"            command=tuple(command),\n"
        b"            outer_bytes=active_outer,\n"
        b"            inner_bytes=active_inner,\n"
        b"            review_bytes=dict(root_review_bytes),\n"
        b"            review_pins=dict(pins),\n"
        b"        )\n"
    )
    outer_response = _replace_once(
        outer_response,
        b"    command = _outer_command(active_outer)\n",
        b"",
        "once_outer_command_anchor",
    )
    outer_response = _replace_once(
        outer_response,
        old_test_port,
        b"    response = _execute_outer_process(active_outer, active_inner, fill_raw)\n",
        "once_test_port_branch_anchor",
    )
    raw = raw[:outer_response_start] + outer_response + raw[outer_response_end:]

    try:
        compile(raw, "<r10-generated-once>", "exec", dont_inherit=True)
    except BaseException:
        raise OncePredeploymentBlocked("once_successor_compile") from None
    _check(b"os.path.lexists(R28_CONTROL)" not in raw, "once_control_absence_gate_remains")
    _check(b"os.path.lexists(R28_DEPLOYMENT)" not in raw, "once_deployment_absence_gate_remains")
    _check(b"R28_TEST_OUTER_PORT" not in raw and b"test_port(" not in raw, "once_test_port_remains")
    return raw


def _render_runner(manifest: dict[str, Any], once_raw: bytes) -> bytes:
    raw = _R31.render_root_runner_template(manifest)
    tree = ast.parse(raw.decode("utf-8"))
    assignments = [
        node
        for node in tree.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "MANIFEST" for target in node.targets)
    ]
    _check(len(assignments) == 1, "runner_manifest_assignment")
    lines = raw.splitlines(keepends=True)
    insert = sum(len(line) for line in lines[: assignments[0].end_lineno])
    embedded = b"_R10_ONCE_SOURCE = bytes.fromhex(" + repr(once_raw.hex()).encode("ascii") + b")\n"
    raw = raw[:insert] + embedded + raw[insert:]
    raw = _replace_once(
        raw,
        b"        once_raw = held.get(_canonical(_ONCE_PATH))\n",
        b"        once_raw = _R10_ONCE_SOURCE\n",
        "runner_once_loader_anchor",
    )
    raw = _replace_once(
        raw,
        b"        once = _load_once(once_raw)\n",
        b"        once = _load_once(once_raw)\n        once.R10_HELD_MAP = held\n",
        "runner_once_scope_anchor",
    )
    try:
        compile(raw, "<r10-generated-runner>", "exec", dont_inherit=True)
    except BaseException:
        raise OncePredeploymentBlocked("runner_compile") from None
    return raw


def _r31_active_outputs(
    manifest: dict[str, Any], source_map: dict[str, Any]
) -> tuple[bytes, bytes]:
    """Rebuild and cross-check the exact active R31 bytes already in the 154 map."""
    namespace = manifest.get("runtime_namespace")
    candidate = manifest.get("candidate")
    software = manifest.get("software_pins")
    canonical = source_map.get("canonical_pins")
    plan_sha256 = source_map.get("plan_sha256")
    _check(
        type(namespace) is dict
        and type(candidate) is dict
        and type(software) is dict
        and type(canonical) is dict
        and type(plan_sha256) is str
        and _HEX64.fullmatch(plan_sha256) is not None,
        "r31_output_inputs",
    )
    try:
        rebuilt = _R31.prepare_root_startup(namespace, plan_sha256=plan_sha256)
    except BaseException:
        raise OncePredeploymentBlocked("r31_output_rebuild") from None
    _check(rebuilt.get("status") == "SOURCE_FAKE_ONLY_DISABLED", "r31_output_status")
    outer = rebuilt.get("active_outer_source")
    wrapper = rebuilt.get("active_wrapper_source")
    _check(type(outer) is bytes and type(wrapper) is bytes, "r31_output_bytes")
    _check(
        0 < len(outer) <= 2 * 1024 * 1024
        and 0 < len(wrapper) <= 2 * 1024 * 1024,
        "r31_output_size",
    )
    expected = (
        (
            namespace.get("self_path"),
            outer,
            candidate.get("active_outer_sha256"),
        ),
        (
            namespace.get("active_wrapper_path"),
            wrapper,
            candidate.get("active_wrapper_sha256"),
        ),
    )
    for path, raw, candidate_sha in expected:
        _check(type(path) is str and type(candidate_sha) is str, "r31_output_path_pin")
        digest = _sha(raw)
        _check(digest == candidate_sha, "r31_candidate_output_pin")
        normalized = _R9._normalized(path)
        software_matches = [
            value
            for key, value in software.items()
            if type(key) is str and _R9._normalized(key) == normalized
        ]
        canonical_matches = [
            value
            for key, value in canonical.items()
            if type(key) is str and _R9._normalized(key) == normalized
        ]
        _check(
            len(software_matches) == 1
            and software_matches[0] == digest
            and len(canonical_matches) == 1
            and canonical_matches[0] == digest,
            "r31_source_map_output_pin",
        )
    return outer, wrapper


def _r10_active_outer_source(
    base_outer: bytes,
    base_wrapper: bytes,
    manifest: dict[str, Any],
    plan_sha256: str,
    external_parent_sources: tuple[tuple[str, str, bytes, str, str, str], ...],
) -> bytes:
    """Patch only the obsolete R28 activation equality gate in the R31 outer."""
    namespace = manifest.get("runtime_namespace")
    _check(
        type(namespace) is dict
        and set(namespace)
        == {
            "control_dir",
            "deployment_dir",
            "plan_path",
            "self_path",
            "active_wrapper_path",
            "attempt_claim_path",
        }
        and type(plan_sha256) is str
        and _HEX64.fullmatch(plan_sha256) is not None
        and type(base_outer) is bytes
        and type(base_wrapper) is bytes
        and 0 < len(base_outer) <= 2 * 1024 * 1024
        and 0 < len(base_wrapper) <= 2 * 1024 * 1024,
        "r10_active_outer_inputs",
    )
    external_by_name = {entry[0]: entry for entry in external_parent_sources}
    _check(
        len(external_by_name) == len(external_parent_sources)
        and set(external_by_name)
        == {name for name, _relative, _digest, _origin, _module in R10_ACTIVATION_SOURCE_SPECS}
        | {"cli", "job", "cleanup"},
        "r10_activation_source_set",
    )
    source_rows = []
    for name, relative, digest, origin, module_name in R10_ACTIVATION_SOURCE_SPECS:
        _key, path, raw, held_digest, role, held_origin = external_by_name[name]
        _check(
            held_digest == digest
            and _sha(raw) == digest
            and held_origin == origin
            and role == R10_ACTIVATION_SOURCE_ROLE + ":" + name
            and ntpath.normcase(ntpath.normpath(path))
            == ntpath.normcase(ntpath.normpath(ntpath.join(manifest["root"], relative.replace("/", "\\")))),
            "r10_activation_source_binding",
        )
        source_rows.append(
            {
                "name": name,
                "relative": relative,
                "path": path,
                "sha256": digest,
                "size_bytes": len(raw),
                "role": role,
                "origin": origin,
                "module_name": module_name,
            }
        )
    _check(type(manifest.get("candidate")) is dict, "r10_activation_base_candidate")
    _check(
        manifest["candidate"].get("active_outer_sha256") == _sha(base_outer),
        "r10_activation_base_outer_pin",
    )
    _check(
        manifest["candidate"].get("active_wrapper_sha256") == _sha(base_wrapper),
        "r10_activation_base_wrapper_pin",
    )
    source_plan_pins = [
        digest
        for path, digest in manifest.get("software_pins", {}).items()
        if type(path) is str
        and _R9._normalized(path) == _R9._normalized(namespace["plan_path"])
    ]
    _check(
        len(source_plan_pins) == 1 and source_plan_pins[0] == plan_sha256,
        "r10_activation_base_plan_pin",
    )
    support = _R10_ACTIVE_OUTER_SUPPORT
    substitutions = {
        b"__SCHEMA__": repr(R10_ACTIVATION_TRANSFORM_SCHEMA).encode("ascii"),
        b"__PLAN_SHA256__": repr(plan_sha256).encode("ascii"),
        b"__BASE_OUTER_SHA256__": repr(_sha(base_outer)).encode("ascii"),
        b"__BASE_OUTER_SIZE__": str(len(base_outer)).encode("ascii"),
        b"__BASE_WRAPPER_SHA256__": repr(_sha(base_wrapper)).encode("ascii"),
        b"__BASE_WRAPPER_SIZE__": str(len(base_wrapper)).encode("ascii"),
        b"__NAMESPACE_JSON__": repr(
            json.dumps(namespace, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        ).encode("ascii"),
        b"__SOURCE_ROWS_JSON__": repr(
            json.dumps(source_rows, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        ).encode("ascii"),
    }
    for marker, replacement in substitutions.items():
        _check(support.count(marker) == 1, "r10_active_outer_support_anchor")
        support = support.replace(marker, replacement, 1)
    old_gate = (
        b"    _check(\n"
        b"        active_wrapper == activate_wrapper(wrapper_template, outer_template),\n"
        b'        "wrapper_activation_copy",\n'
        b"    )\n"
    )
    new_gate = (
        b"    _r10_verify_r31_wrapper(\n"
        b"        held,\n"
        b"        active_wrapper,\n"
        b"        wrapper_template,\n"
        b"        outer_template,\n"
        b"        outer_template_sha256=outer_template_sha256,\n"
        b"    )\n"
    )
    result = _replace_once(base_outer, old_gate, new_gate, "r10_wrapper_activation_gate_anchor")
    run_anchor = b"def run_prelaunch(\n"
    result = _replace_once(result, run_anchor, support + run_anchor, "r10_activation_support_anchor")
    try:
        compile(result, "<r10-generated-r31-outer>", "exec", dont_inherit=True)
    except BaseException:
        raise OncePredeploymentBlocked("r10_active_outer_compile") from None
    _check(
        result.count(b"_r10_verify_r31_wrapper(") == 2
        and b"active_wrapper == activate_wrapper(wrapper_template, outer_template)" not in result,
        "r10_active_outer_gate_contract",
    )
    return result


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R10 prepared child with exact once successor and R9 sidecar lineage."""

    r9_prepared: Any
    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    descriptor_json: bytes
    stdin_descriptor: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    once_bytes: bytes
    once_path: str
    once_sha256: str
    once_size_bytes: int
    composer_path: str
    composer_bytes: bytes
    composer_sha256: str
    stub_bytes: bytes
    sidecar_path: str
    sidecar_sha256: str
    sidecar_size_bytes: int
    external_parent_sources: tuple[tuple[str, str, bytes, str, str, str], ...]
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str
    windows_command_line_units: int

    @property
    def sidecar_bytes(self) -> bytes:
        return self.r9_prepared.r8_bootstrap_bytes


def _compose(base: Any) -> PreparedM01Child:
    try:
        _R9._validate_prepared(base)
        descriptor = _R9._R4._validate_descriptor(base.descriptor_json)
        source_map = _R9._R4._validate_source_map(base.source_map_bytes, descriptor)
        manifest = _manifest_from_runner(base.runner_bytes)
    except BaseException:
        raise OncePredeploymentBlocked("r9_prepared_rejected") from None
    root = _verify_chain()
    composer_path, composer_bytes, composer_sha = _composer_source()
    once_path = ntpath.join(descriptor["runtime_namespace"]["control_dir"], R10_ONCE_FILENAME)
    _check(_R9._absolute_windows_path(once_path), "once_path")
    source_path = root / R28_ONCE_REL
    base_once = _bounded_public(source_path, R10_MAX_ONCE_BYTES, R28_ONCE_SHA256)
    outer_template = _bounded_public(
        root / R28_OUTER_TEMPLATE_REL, 2 * 1024 * 1024, R28_OUTER_TEMPLATE_SHA256
    )
    external_parent_sources = _external_parent_sources(
        manifest["root"], base_once, outer_template
    )
    r31_outer, active_wrapper = _r31_active_outputs(manifest, source_map)
    active_outer = _r10_active_outer_source(
        r31_outer,
        active_wrapper,
        manifest,
        source_map["plan_sha256"],
        external_parent_sources,
    )

    updated = copy.deepcopy(manifest)
    active_outer_sha = _sha(active_outer)
    updated["candidate"]["active_outer_sha256"] = active_outer_sha
    updated["runtime_outputs"]["root_prelaunch_source"]["sha256"] = active_outer_sha
    self_path = updated["runtime_namespace"]["self_path"]

    def rebind_path(mapping: dict[str, Any], path: str, digest: str, code: str) -> None:
        normalized = _R9._normalized(path)
        matches = [key for key in mapping if type(key) is str and _R9._normalized(key) == normalized]
        _check(len(matches) == 1, code)
        mapping[matches[0]] = digest

    rebind_path(updated["software_pins"], self_path, active_outer_sha, "r10_manifest_self_pin")
    rebind_path(updated["canonical_pins"], self_path, active_outer_sha, "r10_manifest_canonical_self_pin")
    updated["r10_active_outer_source_transform"] = {
        "schema": R10_ACTIVATION_TRANSFORM_SCHEMA,
        "role": "generated_r31_outer_with_held_output_activation_verifier",
        "base_r31_outer_sha256": _sha(r31_outer),
        "base_r31_outer_size_bytes": len(r31_outer),
        "active_outer_path": self_path,
        "active_outer_sha256": active_outer_sha,
        "active_outer_size_bytes": len(active_outer),
        "active_wrapper_path": updated["runtime_namespace"]["active_wrapper_path"],
        "active_wrapper_sha256": _sha(active_wrapper),
        "plan_path": updated["runtime_namespace"]["plan_path"],
        "plan_sha256": source_map["plan_sha256"],
        "source_count": len(R10_ACTIVATION_SOURCE_SPECS),
        "source_names": [name for name, *_rest in R10_ACTIVATION_SOURCE_SPECS],
        "source_paths": [
            path
            for name, path, _raw, _digest, _role, _origin in external_parent_sources
            if name in {item[0] for item in R10_ACTIVATION_SOURCE_SPECS}
        ],
        "parent_hold_required": True,
        "same_invocation_namespace_binding": True,
        "original_wrapper_template_lineage_retained": True,
        "original_activate_wrapper_function_changed": False,
        "business_validators_changed": False,
        "frozen_r28_r29_r30_r31_bytes_modified": False,
    }
    _seal_manifest(updated)
    try:
        _R31._validate_manifest(updated)
    except BaseException:
        raise OncePredeploymentBlocked("r31_manifest_rejected") from None

    once_raw = _once_successor_source(
        base_once,
        updated,
        active_outer_size_bytes=len(active_outer),
        active_wrapper_size_bytes=len(active_wrapper),
        external_parent_sources=external_parent_sources,
    )
    once_sha = _sha(once_raw)
    _check(0 < len(once_raw) <= R10_MAX_ONCE_BYTES, "once_size")

    updated["once"]["path"] = once_path
    updated["once"]["sha256"] = once_sha
    updated["r10_once_predeployment"] = {
        "schema": R10_PREPARATION_SCHEMA,
        "path": once_path,
        "sha256": once_sha,
        "size_bytes": len(once_raw),
        "role": R10_ONCE_ROLE,
        "source_once_relative_path": R28_ONCE_REL,
        "source_once_sha256": R28_ONCE_SHA256,
        "source_once_size_bytes": len(base_once),
        "active_outer_path": descriptor["runtime_namespace"]["self_path"],
        "active_outer_sha256": active_outer_sha,
        "active_outer_size_bytes": len(active_outer),
        "active_wrapper_path": descriptor["runtime_namespace"]["active_wrapper_path"],
        "active_wrapper_sha256": manifest["candidate"]["active_wrapper_sha256"],
        "active_wrapper_size_bytes": len(active_wrapper),
        "external_parent_sources": [
            {
                "name": name,
                "path": path,
                "sha256": digest,
                "size_bytes": len(raw),
                "role": role,
                "origin": origin,
            }
            for name, path, raw, digest, role, origin in external_parent_sources
        ],
        "external_source_reader": {
            "role": "r10_generated_bounded_from_start_stable_identity_reader",
            "implementation_function": "_r10_read_pinned_source",
            "implementation_generated_once_sha256": once_sha,
            "implementation_generated_once_size_bytes": len(once_raw),
            "max_read_bytes": "pinned_exact_size_plus_one",
            "checks": [
                "seek_to_offset_zero",
                "descriptor_identity_before_after",
                "exact_pinned_size",
                "exact_sha256",
            ],
            "generated_once_path": once_path,
            "source_composer_path": composer_path,
            "source_composer_sha256": composer_sha,
        },
        "fixed_source_transformations": [
            "bind_R28_paths_to_fresh_namespace",
            "validate_R28_fill_outputs_against_frozen_templates",
            "select_R31_active_outer_and_wrapper_from_exact_154_map",
            "bind_R31_output_path_sha256_size_and_bytes",
            "replace_frozen_R28_wrapper_activation_copy_gate_with_exact_held_R31_regeneration",
            "remove_test_port_entrypoint",
            "preserve_R30_predeployment_claim_capture_and_plan_gates",
        ],
        "r10_active_outer_source_transform": dict(updated["r10_active_outer_source_transform"]),
        "source_composer_path": composer_path,
        "source_composer_sha256": composer_sha,
        "source_composer_size_bytes": len(composer_bytes),
        "source_composer_role": R10_COMPOSER_ROLE,
        "embedded_in_runner": True,
        "external_parent_hold_required": True,
        "external_parent_source_hold_required": True,
        "root_predeployment_required": True,
        "control_and_deployment_absence_gate_removed": True,
        "claim_policy": "frozen_r30_create_new_flush_bounded_readback",
        "capture_policy": "frozen_r30_fresh_capture",
        "outer_process_entry": "frozen_r28_bounded_job_spawn_without_test_port",
    }
    _seal_manifest(updated)
    try:
        _R31._validate_manifest(updated)
    except BaseException:
        raise OncePredeploymentBlocked("r31_manifest_rejected") from None
    runner = _render_runner(updated, once_raw)
    _check(0 < len(runner) <= R10_MAX_RUNNER_BYTES, "runner_size")

    source_map = copy.deepcopy(source_map)
    rebind_path(
        source_map["software_pins"],
        descriptor["runtime_namespace"]["self_path"],
        active_outer_sha,
        "r10_source_map_software_self_pin",
    )
    rebind_path(
        source_map["canonical_pins"],
        descriptor["runtime_namespace"]["self_path"],
        active_outer_sha,
        "r10_source_map_canonical_self_pin",
    )
    source_map["runner_template_sha256"] = _sha(runner)
    source_map["manifest_binding_sha256"] = updated["manifest_binding_sha256"]
    source_map_raw = _canonical_json(source_map)
    _check(0 < len(source_map_raw) <= R10_MAX_SOURCE_MAP_BYTES, "source_map_size")

    descriptor = dict(descriptor)
    descriptor["runner_sha256"] = _sha(runner)
    descriptor["source_map_sha256"] = _sha(source_map_raw)
    descriptor["manifest_binding_sha256"] = updated["manifest_binding_sha256"]
    descriptor["runner_template_schema"] = updated["runner_template_schema"]
    descriptor_raw = _canonical_json(descriptor)
    _check(0 < len(descriptor_raw) <= R10_MAX_DESCRIPTOR_BYTES, "descriptor_size")
    _R9._R4._validate_descriptor(descriptor_raw)
    _R9._R4._validate_source_map(source_map_raw, descriptor)

    base_bootstrap = base.r8_bootstrap_bytes
    sidecar_path = base.sidecar_path
    sidecar_sha = base.sidecar_sha256
    sidecar_size = base.sidecar_size_bytes
    stub = _R9._stub_source(
        sidecar_path=sidecar_path,
        bootstrap_size=len(base_bootstrap),
        bootstrap_sha256=_sha(base_bootstrap),
        descriptor_size=len(descriptor_raw),
        descriptor_sha256=_sha(descriptor_raw),
    )
    stdin_raw = _R9._wire_prefix(base_bootstrap) + descriptor_raw
    _check(len(stdin_raw) <= _R9.MAX_STDIN_BYTES, "stdin_transport_limit")
    command = tuple(base.command[:7]) + (stub.decode("utf-8"),)
    units = _R9._command_line_units(command)

    binding = dict(base.binding)
    binding.update(
        {
            "schema": R10_BINDING_SCHEMA,
            "handoff_schema": R10_PREPARATION_SCHEMA,
            "runner_sha256": _sha(runner),
            "source_map_sha256": _sha(source_map_raw),
            "manifest_binding_sha256": updated["manifest_binding_sha256"],
            "descriptor_json_sha256": _sha(descriptor_raw),
            "descriptor_json_size_bytes": len(descriptor_raw),
            "stdin_transport_size_bytes": len(stdin_raw),
            "once_executor_path": once_path,
            "once_executor_sha256": once_sha,
            "once_executor_size_bytes": len(once_raw),
            "once_executor_role": R10_ONCE_ROLE,
            "source_composer_path": composer_path,
            "source_composer_sha256": composer_sha,
            "source_composer_size_bytes": len(composer_bytes),
            "source_composer_role": R10_COMPOSER_ROLE,
            "external_parent_sources": [
                {
                    "name": name,
                    "path": path,
                    "sha256": digest,
                    "size_bytes": len(raw),
                    "role": role,
                    "origin": origin,
                }
                for name, path, raw, digest, role, origin in external_parent_sources
            ],
            "r8_observed_once_path": once_path,
            "r8_observed_once_sha256": once_sha,
            "r9_bootstrap_sidecar_path": sidecar_path,
            "r9_bootstrap_sidecar_sha256": sidecar_sha,
            "r9_bootstrap_sidecar_size_bytes": sidecar_size,
            "windows_command_line_utf16_units_including_nul": units,
            "windows_command_line_limit_utf16_units_including_nul": _R9.MAX_COMMAND_LINE_UNITS,
            "canonical_map_counts": {"public": 118, "software": 36, "canonical": 154},
        }
    )
    binding_sha = _R6._canonical_binding_digest(binding, command, base.cwd)
    return PreparedM01Child(
        r9_prepared=base,
        command=command,
        cwd=base.cwd,
        environment=dict(base.environment),
        descriptor_json=descriptor_raw,
        stdin_descriptor=stdin_raw,
        source_map_bytes=source_map_raw,
        runner_bytes=runner,
        once_bytes=once_raw,
        once_path=once_path,
        once_sha256=once_sha,
        once_size_bytes=len(once_raw),
        composer_path=composer_path,
        composer_bytes=composer_bytes,
        composer_sha256=composer_sha,
        stub_bytes=stub,
        sidecar_path=sidecar_path,
        sidecar_sha256=sidecar_sha,
        sidecar_size_bytes=sidecar_size,
        external_parent_sources=external_parent_sources,
        binding=binding,
        binding_sha256=binding_sha,
        plan_disposition=base.plan_disposition,
        windows_command_line_units=units,
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Prepare R9 transport then bind the R10 once/predeployment successor."""
    _verify_chain()
    try:
        base = _R9.prepare_r33_child(prepared_r31, root_metadata, environment=environment)
    except BaseException:
        raise OncePredeploymentBlocked("r9_prepare_rejected") from None
    return _compose(base)


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "prepared_type")
    try:
        expected = _compose(value.r9_prepared)
    except BaseException:
        raise OncePredeploymentBlocked("prepared_recompose") from None
    _check(value == expected, "prepared_binding")


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    """Return all changed external files Root must hold in the same namespace."""
    _validate_prepared(prepared)
    r9_addition = _R9.parent_hold_addition(prepared.r9_prepared)
    entries = dict(r9_addition["entries"])
    additions = [
        (prepared.once_path, prepared.once_bytes, prepared.once_sha256, R10_ONCE_ROLE),
        (
            prepared.composer_path,
            prepared.composer_bytes,
            prepared.composer_sha256,
            R10_COMPOSER_ROLE,
        ),
        (
            json.loads(prepared.descriptor_json)["runner_path"],
            prepared.runner_bytes,
            _sha(prepared.runner_bytes),
            "r10_generated_runner",
        ),
        (
            json.loads(prepared.descriptor_json)["source_map_path"],
            prepared.source_map_bytes,
            _sha(prepared.source_map_bytes),
            "r10_generated_source_map",
        ),
    ]
    additions.extend(
        (path, raw, digest, role, origin)
        for _name, path, raw, digest, role, origin in prepared.external_parent_sources
    )
    for item in additions:
        _check(len(item) in (4, 5), "hold_entry_shape")
        path, raw, digest, role = item[:4]
        origin = item[4] if len(item) == 5 else None
        _check(_R9._absolute_windows_path(path), "hold_entry_path")
        _check(path not in entries, "hold_entry_collision")
        _check(type(raw) is bytes and _sha(raw) == digest, "hold_entry_digest")
        entry = {"sha256": digest, "size_bytes": len(raw), "role": role}
        if origin is not None:
            _check(type(origin) is str and origin, "hold_entry_origin")
            entry["origin"] = origin
        entries[path] = entry
    return {
        "schema": R10_HOLD_SCHEMA,
        "binding_sha256": prepared.binding_sha256,
        "entries": dict(sorted(entries.items())),
        "canonical_child_map_count": 154,
        "r9_sidecar_path": prepared.sidecar_path,
        "r10_once_path": prepared.once_path,
        "r10_once_sha256": prepared.once_sha256,
        "r10_once_size_bytes": prepared.once_size_bytes,
        "active_outer_path": json.loads(prepared.descriptor_json)["runtime_namespace"]["self_path"],
        "active_wrapper_path": json.loads(prepared.descriptor_json)["runtime_namespace"]["active_wrapper_path"],
        "external_parent_source_count": len(prepared.external_parent_sources),
        "external_parent_source_paths": [
            path for _name, path, _raw, _digest, _role, _origin in prepared.external_parent_sources
        ],
    }


def verify_parent_hold_addition(prepared: PreparedM01Child, value: Any) -> bool:
    try:
        expected = parent_hold_addition(prepared)
    except BaseException:
        return False
    return type(value) is dict and value == expected


def _rebind_r9_adapter(adapter: Any, prepared: PreparedM01Child) -> None:
    """Rebind only transport/prepared bytes after R9 has initialized its gates."""
    base_r9 = prepared.r9_prepared
    base_r8 = base_r9.r8_prepared
    base_r4 = base_r8.r5_prepared
    r4_child = dataclasses.replace(
        base_r4,
        command=prepared.command,
        stdin_descriptor=prepared.stdin_descriptor,
        source_map_bytes=prepared.source_map_bytes,
        runner_bytes=prepared.runner_bytes,
        bootstrap_bytes=prepared.stub_bytes,
        binding=dict(prepared.binding),
        binding_sha256=prepared.binding_sha256,
    )
    r6_child = dataclasses.replace(
        base_r8,
        command=prepared.command,
        stdin_descriptor=prepared.stdin_descriptor,
        source_map_bytes=prepared.source_map_bytes,
        runner_bytes=prepared.runner_bytes,
        bootstrap_bytes=prepared.stub_bytes,
        binding=dict(prepared.binding),
        binding_sha256=prepared.binding_sha256,
        r5_prepared=r4_child,
    )
    adapter._r8.prepared = dataclasses.replace(base_r8, runner_bytes=prepared.runner_bytes)
    internal = _R6._r2_prepared(adapter._r8._r5, r6_child)
    adapter._r8._r5.prepared = r4_child
    adapter._r8._r5._base.prepared = r4_child
    adapter._r8._r5._base._r2_prepared = internal
    adapter._r8._r5._inner.prepared = internal
    adapter.prepared = prepared


class M01WindowsParentAdapter:
    """R9 owner-thread supervisor with exact R10 prepared bytes rebound."""

    def __init__(self, prepared_child: PreparedM01Child, **kwargs: Any):
        _validate_prepared(prepared_child)
        self.prepared = prepared_child
        self._r9 = _R9.M01WindowsParentAdapter(prepared_child.r9_prepared, **kwargs)
        _rebind_r9_adapter(self._r9, prepared_child)

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        return self._r9.supervise(source_scope, release_source_scope, **kwargs)

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._r9.summarize_result(result)

    def __getattr__(self, name: str):
        return getattr(self._r9, name)


if __name__ == "__main__":
    raise SystemExit("Use prepare_r33_child() and the exact Root-held R10 file set.")
