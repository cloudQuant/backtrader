"""R21 source fakes exercise the real R28 map builder and generated call path.

Synthetic external software bytes exercise the production parsers and hash
checks, but this source fake does not verify external artifact authenticity or
real CUV2/Windows custody.
"""

from __future__ import annotations

import copy
import hashlib
import json
import ntpath
import types
from pathlib import Path

import pytest

pytest_plugins = (
    "tests.unit.runtime.test_iteration41_okx_m01_r33_child_entry_path_r20_r1_source_fake",
)

from scripts import iteration41_okx_m01_r33_child_main_map_r21_r1 as r21
from scripts import iteration41_okx_m01_r33_source_map_gate_r17_r1 as r17


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _key(path: str) -> str:
    return ntpath.normcase(ntpath.normpath(str(path).replace("/", "\\")))


class _StopBeforeProtectedIo(Exception):
    pass


class _FakePrivate:
    def __init__(self, events):
        self.events = events

    def _api(self):
        self.events.append("protected_io_boundary")
        raise _StopBeforeProtectedIo()


class _FakeScope:
    def __init__(self, rows, events, *, mode="good", runtime_map_path=""):
        self.rows = rows
        self.events = events
        self.mode = mode
        self.runtime_map_path = runtime_map_path

    def __enter__(self):
        self.events.append(("scope_enter", len(self.rows)))
        rows = dict(self.rows)
        if self.mode == "missing_runtime_map" and len(rows) == 2:
            rows.pop(self.runtime_map_path)
        elif self.mode == "tampered_runtime_map" and len(rows) == 2:
            rows[self.runtime_map_path] = rows[self.runtime_map_path] + b" "
        return _FakePrivate(self.events), object(), rows

    def __exit__(self, *_args):
        self.events.append("scope_exit")
        return False


@pytest.fixture(scope="module")
def generated_r21(generated_r20):
    prepared_r13 = generated_r20["prepared_r13"]
    source = r21._self_source()
    r21_raw = r21._r21_source_transform(prepared_r13.active_outer_source, source)
    outer = types.ModuleType("_m01_r21_generated_active_outer")
    outer.__file__ = str(generated_r20["self_path"])
    exec(compile(r21_raw, outer.__file__, "exec", dont_inherit=True), outer.__dict__)
    assert b"R21_CHILD_MAIN_MAP_MARKER =" in r21_raw
    return {**generated_r20, "outer_r21": outer, "r21_raw": r21_raw, "r21_source": source}


def _fixture_maps_from_builder(generated_r21):
    prepared_r13 = generated_r21["prepared_r13"]
    outer = generated_r21["outer_r21"]
    main_inputs = outer._build_pin_sets(
        self_path=generated_r21["self_path"],
        self_sha256=_sha(generated_r21["r21_raw"]),
        plan_sha256=_sha(generated_r21["plan_raw"]),
    )
    public, software, package_index, source_map, source_index, source_checkpoint, record, projection, _c01 = main_inputs
    assert type(public) is dict and type(software) is dict
    assert (len(public), len(software)) == (110, 36)
    assert type(source_map) is dict and len(source_map["source_pins"]) == 34
    assert type(package_index) is dict and type(source_index) is dict
    assert type(source_checkpoint) is dict and type(record) is dict and type(projection) is dict

    original_map = copy.deepcopy(generated_r21["runtime_map"])
    original_public = {_key(path): (path, digest) for path, digest in original_map["public_pins"].items()}
    original_software = {_key(path): (path, digest) for path, digest in original_map["software_pins"].items()}
    main_public = {_key(path): (path, digest) for path, digest in public.items()}
    main_software = {_key(path): (path, digest) for path, digest in software.items()}
    assert len(original_public) == 118 and len(original_software) == 36
    assert len(main_public) == 110 and len(main_software) == 36
    assert set(main_public) <= set(original_public)
    assert all(main_public[key][1] == original_public[key][1] for key in main_public)
    omitted = set(original_public) - set(main_public)
    expected_omitted = {_key(path) for path in r21._R21_OMITTED_PUBLIC}
    assert omitted == expected_omitted
    assert set(main_software) == set(original_software)

    # The older R19 fixture supplies only synthetic external software bytes.
    # Compare the 36 production builder digests to those fixture bytes before
    # adapting metadata; exactly 11 differ. Bind the fixture bytes to the exact
    # builder paths, then let unchanged production SHA gates inspect those
    # synthetic bytes. This does not verify external artifact bytes or custody.
    held_by_key = {_key(path): (path, raw) for path, raw in generated_r21["canonical_held"].items()}
    self_key = _key(str(generated_r21["self_path"]))
    held_by_key[self_key] = (
        held_by_key[self_key][0],
        generated_r21["r21_raw"],
    )
    assert set(main_software) == {key for key in main_software if key in held_by_key}
    fixture_software = {
        path: _sha(held_by_key[key][1])
        for key, (path, _digest) in main_software.items()
    }
    assert len(fixture_software) == 36
    pre_adaptation_software_digest_deltas = sum(
        main_software[key][1] != _sha(held_by_key[key][1]) for key in main_software
    )
    assert pre_adaptation_software_digest_deltas == 11

    completed_public = dict(public)
    for key in omitted:
        path, digest = original_public[key]
        completed_public[path] = digest
    assert len(completed_public) == 118

    # The fake R17 map is built from this same R28 production-builder result,
    # with the eight descriptor-bound R17 rows it intentionally omits. The
    # real R19 parser and custody validators still inspect every row and byte.
    runtime_map = original_map
    runtime_map["public_pins"] = completed_public
    runtime_map["software_pins"] = fixture_software
    desired_canonical = {}
    for relative, digest in completed_public.items():
        desired_canonical[_key(ntpath.join(runtime_map["root"], relative))] = digest
    for path, digest in fixture_software.items():
        desired_canonical[_key(path)] = digest
    old_canonical = runtime_map["canonical_pins"]
    assert len(old_canonical) == 154
    normalized_old = {_key(path): path for path in old_canonical}
    assert set(normalized_old) == set(desired_canonical)
    runtime_map["canonical_pins"] = {
        normalized_old[key]: digest for key, digest in desired_canonical.items()
    }

    canonical_held = dict(generated_r21["canonical_held"])
    for index, (path, raw) in enumerate(canonical_held.items()):
        if _key(path) == self_key:
            canonical_held[path] = generated_r21["r21_raw"]
            break
    else:
        raise AssertionError("fixture is missing the exact self-source row")
    for path, digest in desired_canonical.items():
        raw = next(raw for row_path, raw in canonical_held.items() if _key(row_path) == path)
        assert _sha(raw) == digest

    runtime_map_bytes = json.dumps(
        runtime_map, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    descriptor = generated_r21["descriptor"]
    Path(descriptor["source_map_path"]).write_bytes(runtime_map_bytes)
    return {
        "main_inputs": main_inputs,
        "public": public,
        "software": fixture_software,
        "source_map": source_map,
        "runtime_map": runtime_map,
        "runtime_map_bytes": runtime_map_bytes,
        "canonical_held": canonical_held,
        "pre_adaptation_software_digest_deltas": pre_adaptation_software_digest_deltas,
    }


def _run(generated_r21, *, mode="good", mutate_software=False, tamper_map=False):
    fixture = _fixture_maps_from_builder(generated_r21)
    outer = generated_r21["outer_r21"]
    prepared_r13 = generated_r21["prepared_r13"]
    descriptor = generated_r21["descriptor"]
    public = fixture["public"]
    software = dict(fixture["software"])
    if mutate_software:
        path = next(iter(software))
        software[path] = "0" * 64 if software[path] != "0" * 64 else "1" * 64
    events = []
    r17_path, r17_raw, r17_sha = r17._self_source()
    support_rows = {
        descriptor["source_map_path"]: fixture["runtime_map_bytes"],
        r17_path: r17_raw,
    }
    if tamper_map:
        changed = copy.deepcopy(fixture["runtime_map"])
        omitted_path = next(
            path for path in changed["public_pins"] if _key(path) in {_key(item) for item in r21._R21_OMITTED_PUBLIC}
        )
        changed["public_pins"][omitted_path] = "0" * 64
        changed["canonical_pins"][_key(ntpath.join(changed["root"], omitted_path))] = "0" * 64
        tampered = json.dumps(changed, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        Path(descriptor["source_map_path"]).write_bytes(tampered)

    class _Custody:
        PRIVATE = outer.PRIVATE_REL
        PRIVATE_SHA = outer.PRIVATE_SHA256
        CLI = outer.CLI_REL
        CLI_SHA = outer.CLI_SHA256

        @staticmethod
        def held_public_sources(actual_public, actual_software):
            if actual_public:
                if not tamper_map:
                    assert actual_public == fixture["runtime_map"]["public_pins"]
                else:
                    assert len(actual_public) == 118
                assert actual_software == fixture["software"] or mutate_software
                rows = fixture["canonical_held"]
            else:
                assert actual_public == {}
                rows = support_rows
            return _FakeScope(
                rows,
                events,
                mode=mode,
                runtime_map_path=descriptor["source_map_path"],
            )

    real_check = outer._check

    def observed_check(value, code):
        if not value:
            events.append(("check_failure", code))
        return real_check(value, code)

    outer._check = observed_check
    real_runtime_map = outer._r19_read_runtime_map

    def observed_runtime_map(plan_raw, self_path, self_sha256):
        events.append(("runtime_map_self_path_type", type(self_path).__name__))
        return real_runtime_map(plan_raw, self_path, self_sha256)

    outer._r19_read_runtime_map = observed_runtime_map
    real_verify = outer._r13_verify_generated_active_outer

    def observed_verify(held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map):
        events.append(("verify_self_path_type", type(self_path).__name__))
        result = real_verify(
            held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map
        )
        events.append("real_r13_r17_r19_r21_activation_passed")
        return result

    outer._r13_verify_generated_active_outer = observed_verify
    real_exact = outer._r13_exact_held

    def observed_exact(held, path):
        events.append(("exact_held_path_type", type(path).__name__, _key(path)))
        return real_exact(held, path)

    outer._r13_exact_held = observed_exact

    def closure(held, *_args, **kwargs):
        events.append("r28_closure_fake")
        assert len(fixture["canonical_held"]) == 154
        assert len(held) == 156
        for path, raw in support_rows.items():
            assert [value for key, value in held.items() if _key(key) == _key(path)] == [raw]
        assert kwargs["outer_template_sha256"] == public[outer.SELF_TEMPLATE_REL]

    outer._verify_held_closure = closure
    package_index = fixture["main_inputs"][2]
    source_index, source_checkpoint, record, projection = fixture["main_inputs"][4:8]
    case_map_before = json.dumps(fixture["source_map"], sort_keys=True)
    result = outer.run_prelaunch(
        _Custody(),
        self_path=generated_r21["self_path"],
        self_sha256=_sha(generated_r21["r21_raw"]),
        plan_raw=generated_r21["plan_raw"],
        public=public,
        software=software,
        package_index=package_index,
        source_map=fixture["source_map"],
        source_index=source_index,
        source_checkpoint=source_checkpoint,
        record=record,
        projection=projection,
        popen_factory=None,
        environ={},
        postverify=lambda _public, _software: True,
        now_utc=None,
    )
    assert json.dumps(fixture["source_map"], sort_keys=True) == case_map_before
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0 and result["suite_ready"] is False
    assert "provider" not in result
    return result, events, fixture, support_rows


def test_generated_r28_main_maps_reach_real_r21_and_r19_gates(generated_r21):
    result, events, fixture, _support_rows = _run(generated_r21)

    assert fixture["pre_adaptation_software_digest_deltas"] == 11
    assert [event for event in events if isinstance(event, tuple) and event[0] == "scope_enter"] == [
        ("scope_enter", 154),
        ("scope_enter", 2),
    ]
    assert ("runtime_map_self_path_type", "str") in events
    assert ("verify_self_path_type", "str") in events
    assert "real_r13_r17_r19_r21_activation_passed" in events
    assert "r28_closure_fake" in events
    assert events.index("real_r13_r17_r19_r21_activation_passed") < events.index("protected_io_boundary")
    assert events.index("r28_closure_fake") < events.index("protected_io_boundary")
    assert result["status"] == "BLOCKED"


@pytest.mark.parametrize(
    "kwargs,expected_code",
    [
        ({"mutate_software": True}, "r21_software_binding"),
        ({"tamper_map": True}, "r19_canonical_map_shape"),
        ({"mode": "missing_runtime_map"}, "r19_support_scope_rows"),
    ],
)
def test_r21_rejects_conflicting_software_tampered_omission_or_missing_map(
    generated_r21, kwargs, expected_code
):
    result, events, _fixture, _support_rows = _run(generated_r21, **kwargs)

    assert ("check_failure", expected_code) in events
    assert "protected_io_boundary" not in events
    assert "real_r13_r17_r19_r21_activation_passed" not in events
    assert result["status"] == "BLOCKED"
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0 and result["suite_ready"] is False
