"""R19 source fakes for the exact inner CUV2 support rows."""

from __future__ import annotations

import hashlib
import json
import ntpath
import types
from pathlib import Path

import pytest

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as r13
from scripts import iteration41_okx_m01_r33_source_map_gate_r17_r1 as r17
from scripts import iteration41_okx_m01_r33_child_source_scope_r19_r1 as r19
from tests.unit.runtime import test_iteration41_okx_m01_r33_returned_result_observer_r11_r1 as r11_tests


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _key(path: str) -> str:
    return ntpath.normcase(ntpath.normpath(path.replace("/", "\\")))


def _map_bytes(prepared_r13, base_held):
    runtime_map = json.loads(prepared_r13.source_map_bytes)
    descriptor = r13._R10._R9._R4._validate_descriptor(prepared_r13.descriptor_json)
    replacements = {
        _key(descriptor["runner_path"]): prepared_r13.runner_bytes,
        _key(runtime_map["runtime_namespace"]["self_path"]): prepared_r13.active_outer_source,
    }
    by_key = {_key(path): raw for path, raw in base_held.items()}
    selected = {}
    selected_keys = set()
    for relative, digest in runtime_map["public_pins"].items():
        path = str(Path(ntpath.join(runtime_map["root"], relative)))
        key = _key(path)
        raw = replacements.get(key, by_key.get(key))
        assert type(raw) is bytes and _sha(raw) == digest
        assert key not in selected_keys
        selected_keys.add(key)
        selected[path] = raw
    for path, digest in runtime_map["software_pins"].items():
        path = str(Path(path))
        key = _key(path)
        raw = replacements.get(key, by_key.get(key))
        assert type(raw) is bytes and _sha(raw) == digest
        assert key not in selected_keys
        selected_keys.add(key)
        selected[path] = raw
    assert len(selected) == 154
    assert selected_keys == set(runtime_map["canonical_pins"])
    return runtime_map, descriptor, selected


@pytest.fixture(scope="module")
def generated_r19(tmp_path_factory):
    """Compose the actual R13 outer with exact R17 then R19 transforms."""
    tmp_path = tmp_path_factory.mktemp("m01-r19-generated")
    prepared_r11, base_held = r11_tests._r11_prepared(tmp_path)
    r17_source = r17._self_source()
    r19_source = r19._self_source()
    runtime_map_path = r17._runtime_source_map_path(prepared_r11)
    original_outer = r13._active_outer_source

    def transformed_outer(*args, **kwargs):
        base_outer = original_outer(*args, **kwargs)
        r17_outer = r17._apply_active_outer_transform(
            base_outer,
            runtime_map_path,
            r17_source[0],
            r17_source[2],
            r17._R17_OUTER_SUPPORT,
        )
        return r19._apply_active_outer_transform(
            r17_outer,
            r19_source[0],
            r19_source[2],
            r19_source[1],
            r19._R19_OUTER_SUPPORT,
        )

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(r13, "_active_outer_source", transformed_outer)
        prepared_r13 = r13._compose(prepared_r11)
    runtime_map, descriptor, canonical_held = _map_bytes(prepared_r13, base_held)
    map_path = descriptor["source_map_path"]
    Path(map_path).parent.mkdir(parents=True, exist_ok=True)
    Path(map_path).write_bytes(prepared_r13.source_map_bytes)
    outer = types.ModuleType("_m01_r19_generated_active_outer")
    outer.__file__ = runtime_map["runtime_namespace"]["self_path"]
    assert b"active_driver = _r13_exact_held(held, self_path)" in prepared_r13.active_outer_source
    assert b"plan_held = _r13_exact_held(held, str(PLAN_PATH))" in prepared_r13.active_outer_source
    exec(
        compile(prepared_r13.active_outer_source, outer.__file__, "exec", dont_inherit=True),
        outer.__dict__,
    )
    return {
        "prepared_r11": prepared_r11,
        "prepared_r13": prepared_r13,
        "base_held": base_held,
        "runtime_map": runtime_map,
        "descriptor": descriptor,
        "canonical_held": canonical_held,
        "outer": outer,
        "plan_raw": next(
            raw for path, raw in canonical_held.items()
            if _key(path) == _key(runtime_map["runtime_namespace"]["plan_path"])
        ),
    }


class _StopBeforeProtectedIo(Exception):
    pass


class _FakePrivate:
    def __init__(self, events):
        self.events = events

    def _api(self):
        self.events.append("protected_io_boundary")
        raise _StopBeforeProtectedIo()


class _FakeScope:
    def __init__(self, rows, events, *, mode="good", runtime_map_path=""):
        self.rows = rows
        self.events = events
        self.mode = mode
        self.runtime_map_path = runtime_map_path

    def __enter__(self):
        self.events.append(("scope_enter", len(self.rows)))
        rows = dict(self.rows)
        if self.mode == "missing_runtime_map" and len(rows) == 2:
            rows.pop(self.runtime_map_path)
        elif self.mode == "missing_r17_helper" and len(rows) == 2:
            rows.pop(r17._self_source()[0])
        elif self.mode == "tampered_runtime_map" and len(rows) == 2:
            path = self.runtime_map_path
            rows[path] = rows[path] + b" "
        elif self.mode == "tampered_r17_helper" and len(rows) == 2:
            path = r17._self_source()[0]
            rows[path] = rows[path] + b" "
        return _FakePrivate(self.events), object(), rows

    def __exit__(self, *_args):
        self.events.append("scope_exit")
        return False


def _run_generated_outer(generated_r19, *, mode="good"):
    prepared_r13 = generated_r19["prepared_r13"]
    runtime_map = generated_r19["runtime_map"]
    descriptor = generated_r19["descriptor"]
    canonical_held = generated_r19["canonical_held"]
    events = []
    source_map_bytes = prepared_r13.source_map_bytes
    r17_path, r17_raw, r17_sha = r17._self_source()
    support_rows = {
        descriptor["source_map_path"]: source_map_bytes,
        r17_path: r17_raw,
    }
    all_rows = dict(canonical_held)
    for path, raw in support_rows.items():
        assert _key(path) not in {_key(existing) for existing in all_rows}
        all_rows[path] = raw

    outer = generated_r19["outer"]

    class _Custody:
        PRIVATE = outer.PRIVATE_REL
        PRIVATE_SHA = outer.PRIVATE_SHA256
        CLI = outer.CLI_REL
        CLI_SHA = outer.CLI_SHA256

        @staticmethod
        def held_public_sources(public, software):
            if public:
                assert len(public) == 118 and len(software) == 36
                rows = canonical_held
            else:
                assert public == {}
                assert software == {
                    descriptor["source_map_path"]: _sha(source_map_bytes),
                    r17_path: r17_sha,
                }
                rows = support_rows
            return _FakeScope(
                rows,
                events,
                mode=mode,
                runtime_map_path=descriptor["source_map_path"],
            )

    real_check = outer._check

    def observed_check(value, code):
        if not value:
            events.append(("check_failure", code))
        return real_check(value, code)

    outer._check = observed_check
    real_runtime_map = outer._r17_runtime_source_map

    def observed_runtime_map(held):
        try:
            return real_runtime_map(held)
        except BaseException as error:
            events.append(("runtime_map_failure", type(error).__name__, str(error)))
            raise

    outer._r17_runtime_source_map = observed_runtime_map
    real_verify = outer._r13_verify_generated_active_outer

    def observed_verify(held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map):
        events.append((
            "verify_arg_facts",
            type(active_driver) is bytes,
            type(self_sha256) is str and _sha(active_driver) == self_sha256 if type(active_driver) is bytes else False,
            type(candidate_template) is bytes and _sha(candidate_template) == outer.R13_EXPECTED_R28_TEMPLATE_SHA256,
            type(plan_raw) is bytes and _sha(plan_raw) == outer.R13_EXPECTED_PLAN_SHA256,
            self_path,
            [(path, _sha(raw)) for path, raw in held.items()
             if _key(path) == _key(self_path) and type(raw) is bytes],
        ))
        result = real_verify(
            held, active_driver, candidate_template, self_path, self_sha256, plan_raw, source_map
        )
        events.append("real_r13_r17_r19_activation_passed")
        return result

    outer._r13_verify_generated_active_outer = observed_verify
    real_exact = outer._r13_exact_held

    def observed_exact(held, path):
        events.append(("real_exact_held", _key(path)))
        return real_exact(held, path)

    outer._r13_exact_held = observed_exact

    def closure(held, *_args, **kwargs):
        events.append("r28_closure_fake")
        template_path = str(outer.SELF_TEMPLATE_PATH)
        template_value = held.get(template_path)
        assert len(canonical_held) == 154
        assert len(held) == 154 + r19.R19_CHILD_SUPPORT_COUNT
        for path, raw in support_rows.items():
            assert [value for key, value in held.items() if _key(key) == _key(path)] == [raw]
        assert kwargs["outer_template_sha256"] == outer._sha(
            next(
                raw for path, raw in canonical_held.items()
                if _key(path) == _key(str(outer.SELF_TEMPLATE_PATH))
            )
        )

    outer._verify_held_closure = closure
    case_map = {
        "schema": "iteration41.okx.m01.case-source-map.v23-diagnostic",
        "source_pins": {"case-%02d.py" % index: "%064x" % (index + 1) for index in range(34)},
    }
    case_map_before = json.dumps(case_map, sort_keys=True)
    public = runtime_map["public_pins"]
    software = runtime_map["software_pins"]
    result = outer.run_prelaunch(
        _Custody(),
        self_path=runtime_map["runtime_namespace"]["self_path"],
        self_sha256=_sha(prepared_r13.active_outer_source),
        plan_raw=generated_r19["plan_raw"],
        public=public,
        software=software,
        package_index={},
        source_map=case_map,
        source_index={},
        source_checkpoint={},
        record={},
        projection={},
        popen_factory=None,
        environ={},
        postverify=lambda _public, _software: True,
        now_utc=None,
    )
    assert json.dumps(case_map, sort_keys=True) == case_map_before
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0 and result["suite_ready"] is False
    return result, events, support_rows, all_rows, runtime_map


def test_r19_real_generated_outer_holds_support_rows_separately_from_canonical_154(generated_r19):
    result, events, support_rows, _all_rows, runtime_map = _run_generated_outer(generated_r19)

    assert [event for event in events if isinstance(event, tuple) and event[0] == "scope_enter"] == [
        ("scope_enter", 154),
        ("scope_enter", 2),
    ]
    assert "r28_closure_fake" in events, (result, events)
    assert "real_r13_r17_r19_activation_passed" in events, (
        result.get("reason"),
        [event for event in events if isinstance(event, tuple)
         and event[0] in {"check_failure", "runtime_map_failure", "real_exact_held", "verify_arg_facts"}],
    )
    verify_facts = next(event for event in events if isinstance(event, tuple) and event[0] == "verify_arg_facts")
    assert verify_facts[1:5] == (True, True, True, True)
    assert events.index("r28_closure_fake") < events.index("real_r13_r17_r19_activation_passed")
    assert "protected_io_boundary" in events, (
        result.get("reason"),
        [event for event in events if isinstance(event, tuple)
         and event[0] in {"check_failure", "runtime_map_failure", "real_exact_held", "verify_arg_facts"}],
    )
    assert events.index("real_r13_r17_r19_activation_passed") < events.index("protected_io_boundary")
    exact_calls = [event[1] for event in events if isinstance(event, tuple) and event[0] == "real_exact_held"]
    assert exact_calls == [
        _key(runtime_map["runtime_namespace"]["self_path"]),
        _key(generated_r19["descriptor"]["source_map_path"]),
        _key(runtime_map["runtime_namespace"]["self_path"]),
        _key(r17._self_source()[0]),
        _key(runtime_map["runtime_namespace"]["plan_path"]),
    ]
    assert len(support_rows) == 2
    assert result["status"] == "BLOCKED"
    assert result["route_invocations"] == 0
    assert "provider" not in result


@pytest.mark.parametrize(
    "mode",
    ["missing_runtime_map", "missing_r17_helper", "tampered_runtime_map", "tampered_r17_helper"],
)
def test_r19_generated_outer_rejects_missing_or_changed_inner_support_rows(generated_r19, mode):
    result, events, _support_rows, _all_rows, _runtime_map = _run_generated_outer(
        generated_r19, mode=mode
    )

    assert "real_r13_r17_r19_activation_passed" not in events
    assert "protected_io_boundary" not in events
    assert result["status"] == "BLOCKED"
    assert result["route_invocations"] == 0
    assert result["strict_cases_passed"] == 0 and result["suite_ready"] is False
    assert "provider" not in result

