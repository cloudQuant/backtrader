"""R9 short-command transport for the frozen M01 R8 bootstrap.

The exact R8 bootstrap is stored in one content-addressed sidecar under the
prepared deployment directory.  The child command remains short and receives
only a fixed 42-byte hash/length prefix followed by the unchanged R4 JSON
descriptor.  The generated stub verifies both inputs before executing the
exact R8 bytes with the original ``__main__`` semantics.

This module prepares source-fake material only.  Root must create the sidecar
under its protected deployment directory and include the returned one-entry
addition in its outer held-source map.  The R31 canonical 154-entry map and
all R28/R31/R7/R8 gates and time budgets remain unchanged.
"""

from __future__ import annotations

import dataclasses
import hashlib
import ntpath
import os
import re
import subprocess
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_child_bootstrap_r4 as _R4
from scripts import iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1 as _R8
from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r6 as _R6


R8_FILENAME = "iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1.py"
R8_SHA256 = "cfc7044f9863e76dc16499dd1c9b5047fc00309ddb437929ae990e148b27b38c"
R6_FILENAME = "iteration41_okx_m01_r33_windows_parent_adapter_r6.py"
R6_SHA256 = "cc12ad98a17275c5781be50314a1de6c9084603ffb7f0207d07218280a22b7aa"
R4_FILENAME = "iteration41_okx_m01_r33_child_bootstrap_r4.py"
R4_SHA256 = "4fe4131a69e8a36e354b3bd4d7babba25ec2de9eeb52258336209dee6677b778"
TRANSPORT_SCHEMA = "iteration41.okx.m01.r33.sidecar-transport.r9.r1.v1"
BINDING_SCHEMA = "iteration41.okx.m01.r33.prepared-child-binding.r9.r1.sidecar-transport.v1"
HOLD_ADDITION_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition.r9.r1.v1"
SIDE_CAR_PREFIX = "iteration41_okx_m01_r33_r9_r8_bootstrap_"
WIRE_PREFIX = b"M01R9:"
WIRE_PREFIX_BYTES = 42
MAX_STDIN_BYTES = 4096
MAX_BOOTSTRAP_BYTES = 96 * 1024
MAX_COMMAND_LINE_UNITS = 32767
_HEX_SHA = re.compile(r"[0-9a-f]{64}\Z")


class SidecarTransportBlocked(ValueError):
    """A fixed source, path, descriptor, or transport contract failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise SidecarTransportBlocked(reason)


def _r8_source() -> bytes:
    path = Path(_R8.__file__).resolve()
    _check(path.name == R8_FILENAME, "r8_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(MAX_BOOTSTRAP_BYTES + 1)
    except BaseException:
        raise SidecarTransportBlocked("r8_source_read") from None
    _check(0 < len(raw) <= MAX_BOOTSTRAP_BYTES, "r8_source_size")
    _check(_sha(raw) == R8_SHA256, "r8_source_digest")
    return raw


_R8_SOURCE = _r8_source()


def _verify_source_chain() -> None:
    for module, expected_name, expected_digest in (
        (_R8, R8_FILENAME, R8_SHA256),
        (_R6, R6_FILENAME, R6_SHA256),
        (_R4, R4_FILENAME, R4_SHA256),
    ):
        path = Path(module.__file__).resolve()
        _check(path.name == expected_name, "dependency_module_path")
        try:
            with path.open("rb") as stream:
                raw = stream.read(MAX_BOOTSTRAP_BYTES + 1)
        except BaseException:
            raise SidecarTransportBlocked("dependency_source_read") from None
        _check(0 < len(raw) <= MAX_BOOTSTRAP_BYTES, "dependency_source_size")
        _check(_sha(raw) == expected_digest, "dependency_source_digest")


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R9 transport fields plus the exact frozen R8 prepared child."""

    r8_prepared: Any
    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    descriptor_json: bytes
    stdin_descriptor: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    r8_bootstrap_bytes: bytes
    stub_bytes: bytes
    sidecar_path: str
    sidecar_sha256: str
    sidecar_size_bytes: int
    descriptor_sha256: str
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str
    windows_command_line_units: int

    @property
    def sidecar_bytes(self) -> bytes:
        """Exact R8 bytes Root must publish and hold at ``sidecar_path``."""
        return self.r8_bootstrap_bytes


def _normalized(value: str) -> str:
    return ntpath.normcase(ntpath.normpath(value))


def _absolute_windows_path(value: Any) -> bool:
    if type(value) is not str or not value or "\x00" in value or len(value) > 32767:
        return False
    drive, tail = ntpath.splitdrive(value)
    return bool(drive and tail and ntpath.isabs(value))


def _sidecar_path(deployment_dir: str, bootstrap_sha256: str) -> str:
    _check(_absolute_windows_path(deployment_dir), "deployment_path")
    _check(type(bootstrap_sha256) is str and _HEX_SHA.fullmatch(bootstrap_sha256), "bootstrap_digest")
    name = SIDE_CAR_PREFIX + bootstrap_sha256[:20] + ".py"
    path = ntpath.join(deployment_dir, name)
    _check(
        _absolute_windows_path(path)
        and _normalized(ntpath.dirname(path)) == _normalized(deployment_dir)
        and ntpath.basename(path) == name,
        "sidecar_path",
    )
    return path


def _wire_prefix(bootstrap: bytes) -> bytes:
    _check(type(bootstrap) is bytes and 0 < len(bootstrap) <= MAX_BOOTSTRAP_BYTES, "bootstrap_size")
    return WIRE_PREFIX + len(bootstrap).to_bytes(4, "big") + bytes.fromhex(_sha(bootstrap))


def _stub_source(
    *, sidecar_path: str, bootstrap_size: int, bootstrap_sha256: str,
    descriptor_size: int, descriptor_sha256: str,
) -> bytes:
    _check(_absolute_windows_path(sidecar_path), "sidecar_path")
    _check(type(bootstrap_size) is int and 0 < bootstrap_size <= MAX_BOOTSTRAP_BYTES, "bootstrap_size")
    _check(type(bootstrap_sha256) is str and _HEX_SHA.fullmatch(bootstrap_sha256), "bootstrap_digest")
    _check(type(descriptor_size) is int and 0 < descriptor_size <= MAX_STDIN_BYTES, "descriptor_size")
    _check(type(descriptor_sha256) is str and _HEX_SHA.fullmatch(descriptor_sha256), "descriptor_digest")
    prefix = WIRE_PREFIX + bootstrap_size.to_bytes(4, "big") + bytes.fromhex(bootstrap_sha256)
    _check(len(prefix) == WIRE_PREFIX_BYTES, "prefix_size")
    # This is intentionally a small fixed stdlib-only loader.  Validation
    # failures stop before exec and emit no descriptor, path, exception, or
    # sidecar bytes.  The original R8 source keeps its own __main__ guard.
    source = (
        "import hashlib as _r9_h, io as _r9_io, sys as _r9_s\n"
        f"_r9_path = {sidecar_path!r}\n"
        f"_r9_prefix = {prefix!r}\n"
        f"_r9_dlen = {descriptor_size}\n"
        f"_r9_dsha = {descriptor_sha256!r}\n"
        f"_r9_blen = {bootstrap_size}\n"
        f"_r9_bsha = {bootstrap_sha256!r}\n"
        "try:\n"
        "    _r9_wire = _r9_s.stdin.buffer.read(4097)\n"
        "    if len(_r9_wire) != len(_r9_prefix) + _r9_dlen or _r9_wire[:42] != _r9_prefix:\n"
        "        raise ValueError\n"
        "    _r9_desc = _r9_wire[42:]\n"
        "    if len(_r9_desc) != _r9_dlen or _r9_h.sha256(_r9_desc).hexdigest() != _r9_dsha:\n"
        "        raise ValueError\n"
        "    with open(_r9_path, 'rb') as _r9_f:\n"
        "        _r9_boot = _r9_f.read(_r9_blen + 1)\n"
        "    if len(_r9_boot) != _r9_blen or _r9_h.sha256(_r9_boot).hexdigest() != _r9_bsha:\n"
        "        raise ValueError\n"
        "except BaseException:\n"
        "    raise SystemExit(2) from None\n"
        "_r9_s.stdin = type('_M01R9Input', (), {'buffer': _r9_io.BytesIO(_r9_desc)})()\n"
        "exec(compile(_r9_boot, _r9_path, 'exec', dont_inherit=True), globals(), globals())\n"
    )
    try:
        raw = source.encode("utf-8")
        compile(raw, "<m01-r9-short-sidecar-loader>", "exec", dont_inherit=True)
    except BaseException:
        raise SidecarTransportBlocked("stub_compile") from None
    return raw


def _command_line_units(command: tuple[str, ...]) -> int:
    _check(
        type(command) is tuple and len(command) == 8
        and all(type(part) is str and "\x00" not in part for part in command),
        "command_shape",
    )
    try:
        quoted = subprocess.list2cmdline(list(command))
        units = len(quoted.encode("utf-16-le", errors="strict")) // 2 + 1
    except BaseException:
        raise SidecarTransportBlocked("command_encoding") from None
    _check(units <= MAX_COMMAND_LINE_UNITS, "windows_command_line_limit")
    return units


def _from_r8(prepared_r8: Any) -> PreparedM01Child:
    try:
        _verify_source_chain()
        _R8._validate_prepared(prepared_r8)
        r8_module_raw = _r8_source()
        _check(r8_module_raw == _R8_SOURCE, "r8_source_changed")
        descriptor = _R4._validate_descriptor(prepared_r8.stdin_descriptor)
    except BaseException:
        raise SidecarTransportBlocked("r8_prepared_rejected") from None
    bootstrap = prepared_r8.bootstrap_bytes
    descriptor_json = prepared_r8.stdin_descriptor
    descriptor_sha256 = _sha(descriptor_json)
    prefix = _wire_prefix(bootstrap)
    stdin_descriptor = prefix + descriptor_json
    _check(len(stdin_descriptor) <= MAX_STDIN_BYTES, "stdin_transport_limit")
    namespace = descriptor["runtime_namespace"]
    sidecar = _sidecar_path(namespace["deployment_dir"], _sha(bootstrap))
    stub = _stub_source(
        sidecar_path=sidecar,
        bootstrap_size=len(bootstrap),
        bootstrap_sha256=_sha(bootstrap),
        descriptor_size=len(descriptor_json),
        descriptor_sha256=descriptor_sha256,
    )
    command = tuple(prepared_r8.command[:7]) + (stub.decode("utf-8"),)
    units = _command_line_units(command)
    binding = dict(prepared_r8.binding)
    binding.update(
        {
            "schema": BINDING_SCHEMA,
            "transport_schema": TRANSPORT_SCHEMA,
            "r8_bootstrap_sha256": _sha(bootstrap),
            "r8_bootstrap_size_bytes": len(bootstrap),
            "bootstrap_sidecar_path": sidecar,
            "bootstrap_sidecar_sha256": _sha(bootstrap),
            "bootstrap_sidecar_size_bytes": len(bootstrap),
            "descriptor_json_sha256": descriptor_sha256,
            "descriptor_json_size_bytes": len(descriptor_json),
            "stdin_prefix_hex": prefix.hex(),
            "stdin_prefix_size_bytes": len(prefix),
            "stdin_transport_size_bytes": len(stdin_descriptor),
            "command_line_utf16_units_including_nul": units,
            "command_line_limit_utf16_units_including_nul": MAX_COMMAND_LINE_UNITS,
        }
    )
    binding_sha256 = _R6._canonical_binding_digest(binding, command, prepared_r8.cwd)
    return PreparedM01Child(
        r8_prepared=prepared_r8,
        command=command,
        cwd=prepared_r8.cwd,
        environment=dict(prepared_r8.environment),
        descriptor_json=descriptor_json,
        stdin_descriptor=stdin_descriptor,
        source_map_bytes=prepared_r8.source_map_bytes,
        runner_bytes=prepared_r8.runner_bytes,
        r8_bootstrap_bytes=bootstrap,
        stub_bytes=stub,
        sidecar_path=sidecar,
        sidecar_sha256=_sha(bootstrap),
        sidecar_size_bytes=len(bootstrap),
        descriptor_sha256=descriptor_sha256,
        binding=binding,
        binding_sha256=binding_sha256,
        plan_disposition=prepared_r8.plan_disposition,
        windows_command_line_units=units,
    )


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "prepared_type")
    try:
        expected = _from_r8(value.r8_prepared)
    except BaseException:
        raise SidecarTransportBlocked("prepared_source_rejected") from None
    _check(value == expected, "prepared_fields")


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Create the exact R8 prepared child and bind it to a compact sidecar transport."""
    try:
        _verify_source_chain()
        prepared_r8 = _R8.prepare_r33_child(
            prepared_r31, root_metadata, environment=environment
        )
    except BaseException:
        raise SidecarTransportBlocked("r8_prepare_rejected") from None
    return _from_r8(prepared_r8)


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    """Return the single extra outer-hold map entry for the bootstrap sidecar.

    The existing R31 canonical map stays at 154 entries.  Root must add this
    exact sidecar to its separate protected outer source map and authenticate
    the path, identity, ACL, size, and bytes before launch.
    """
    _validate_prepared(prepared)
    return {
        "schema": HOLD_ADDITION_SCHEMA,
        "entries": {
            prepared.sidecar_path: {
                "sha256": prepared.sidecar_sha256,
                "size_bytes": prepared.sidecar_size_bytes,
                "role": "r9_r8_bootstrap_sidecar",
            }
        },
        "binding_sha256": prepared.binding_sha256,
    }


def create_bootstrap_sidecar(prepared: PreparedM01Child) -> dict[str, Any]:
    """Create the prepared sidecar with exclusive create and bounded readback.

    This helper is for source-fake fixtures or a Root caller already operating
    in its protected deployment directory.  It does not establish ACL or
    physical custody; the caller must separately hold and postverify the file.
    """
    _validate_prepared(prepared)
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_BINARY", 0)
    try:
        fd = os.open(prepared.sidecar_path, flags, 0o600)
    except BaseException:
        raise SidecarTransportBlocked("sidecar_create_new") from None
    offset = 0
    try:
        while offset < len(prepared.r8_bootstrap_bytes):
            written = os.write(fd, prepared.r8_bootstrap_bytes[offset:])
            if type(written) is not int or written <= 0:
                raise SidecarTransportBlocked("sidecar_write")
            offset += written
        os.fsync(fd)
    except BaseException:
        raise SidecarTransportBlocked("sidecar_write") from None
    finally:
        try:
            os.close(fd)
        except BaseException:
            raise SidecarTransportBlocked("sidecar_close") from None
    try:
        with open(prepared.sidecar_path, "rb") as stream:
            observed = stream.read(prepared.sidecar_size_bytes + 1)
    except BaseException:
        raise SidecarTransportBlocked("sidecar_readback") from None
    _check(
        observed == prepared.r8_bootstrap_bytes
        and len(observed) == prepared.sidecar_size_bytes
        and _sha(observed) == prepared.sidecar_sha256,
        "sidecar_readback_mismatch",
    )
    return parent_hold_addition(prepared)


class M01WindowsParentAdapter:
    """R8 parent supervisor with only its fixed child transport replaced."""

    def __init__(self, prepared_child: PreparedM01Child, **kwargs: Any):
        _validate_prepared(prepared_child)
        self._r8 = _R8.M01WindowsParentAdapter(prepared_child.r8_prepared, **kwargs)
        # Keep R8's outer prepared object intact for its frozen frame parser.
        # Rebind only the nested frozen R4/R2 process inputs to this R9 command.
        base = prepared_child.r8_prepared.r5_prepared
        r4_prepared = dataclasses.replace(
            base,
            command=prepared_child.command,
            stdin_descriptor=prepared_child.stdin_descriptor,
            bootstrap_bytes=prepared_child.stub_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
        )
        r6_prepared = dataclasses.replace(
            prepared_child.r8_prepared,
            command=prepared_child.command,
            stdin_descriptor=prepared_child.stdin_descriptor,
            bootstrap_bytes=prepared_child.stub_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
            r5_prepared=r4_prepared,
        )
        internal = _R6._r2_prepared(self._r8._r5, r6_prepared)
        self._r8._r5.prepared = r4_prepared
        self._r8._r5._base.prepared = r4_prepared
        self._r8._r5._base._r2_prepared = internal
        self._r8._r5._inner.prepared = internal
        self.prepared = prepared_child

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        return self._r8.supervise(source_scope, release_source_scope, **kwargs)

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._r8.summarize_result(result)

    def __getattr__(self, name: str):
        return getattr(self._r8, name)


if __name__ == "__main__":
    raise SystemExit("Use prepare_r33_child() and the exact Root-held sidecar.")
