"""Add a finite OUTER_CAPTURED result frame to the frozen R10 child route.

R11 preserves the R10 runner, once source, source map, and all existing
deadlines. It composes a new versioned bootstrap from the exact R10-held R8
bootstrap bytes, binds a new sidecar and its source closure, and projects only
the validator-approved finite fields after R6/R8 parent gates succeed. The
projection is diagnostic only; it never proves provider activity or a case.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import re
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r6 as _R6
from scripts import iteration41_okx_m01_r33_runner_result_observer_r7_r2 as _R7
from scripts import iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1 as _R8
from scripts import iteration41_okx_m01_r33_bootstrap_sidecar_transport_r9_r1 as _R9
from scripts import iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1 as _R10


R6_FILENAME = "iteration41_okx_m01_r33_windows_parent_adapter_r6.py"
R6_SHA256 = "cc12ad98a17275c5781be50314a1de6c9084603ffb7f0207d07218280a22b7aa"
R7_FILENAME = "iteration41_okx_m01_r33_runner_result_observer_r7_r2.py"
R7_SHA256 = "5b205706b2836e78fb4b43999617ce91c7e0c3b2aecba595236152d9920a4feb"
R8_FILENAME = "iteration41_okx_m01_r33_outer_route_phase_observer_r8_r1.py"
R8_SHA256 = "cfc7044f9863e76dc16499dd1c9b5047fc00309ddb437929ae990e148b27b38c"
R9_FILENAME = "iteration41_okx_m01_r33_bootstrap_sidecar_transport_r9_r1.py"
R9_SHA256 = "a5e4532170d41d571151b8a68151802297898c0d4ba5124a7cb06021f1b19dcf"
R10_FILENAME = "iteration41_okx_m01_r33_once_predeployment_handoff_r10_r1.py"
R10_SHA256 = "96a8edc31f7dc2dc88158f1d9ccd5142bbe1d405d8f2c57ee3deed38aec69226"

R11_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_returned_result_observer_r11_r1.py"
R11_RESULT_SCHEMA = "iteration41.okx.m01.r33.returned-result-observation.r11.r1.v1"
R11_BINDING_SCHEMA = "iteration41.okx.m01.r33.prepared-child-binding.r11.returned-result.v1"
R11_HOLD_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition.r11.returned-result.v1"
R11_SIDECAR_ROLE = "r11_returned_result_bootstrap_sidecar"
R11_SOURCE_ROLE = "r11_returned_result_observer_source"
R11_FRAME_PREFIX = b"M01R11:"
R11_FRAME_MAX_BYTES = 20
_R11_RESULT_CALL_ANCHOR = b"        _r7_emit_result_frame(phase_sink, safe_result, runner)\n"
_R11_PHASE_WRITE_ANCHOR = b"        _r8_write_pending_phase_frame(phase_sink)\n"
_MAIN_GUARD = b'\nif __name__ == "__main__":\n'
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")


class ReturnedResultObserverBlocked(ValueError):
    """A pinned source, prepared binding, or finite observation failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise ReturnedResultObserverBlocked(reason)


def _bounded_file(path: Path, expected_name: str, maximum: int) -> bytes:
    _check(path.name == expected_name, "source_filename")
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise ReturnedResultObserverBlocked("source_read") from None
    _check(type(raw) is bytes and 0 < len(raw) <= maximum, "source_size")
    return raw


def _repo_root() -> Path:
    root = Path(_R10.__file__).resolve().parents[1]
    _check((root / "scripts" / R11_RELATIVE_PATH.rsplit("/", 1)[-1]).resolve() == Path(__file__).resolve(), "r11_module_path")
    return root


def _pinned_module_source(module: Any, name: str, digest: str) -> tuple[str, bytes, str]:
    _check(
        getattr(module, "__name__", None) == "scripts." + name[:-3],
        "dependency_module_name",
    )
    path = Path(getattr(module, "__file__", "")).resolve()
    _check(path.name == name, "dependency_filename")
    raw = _bounded_file(path, name, 4 * 1024 * 1024)
    _check(_sha(raw) == digest, "dependency_digest")
    return str(path), raw, digest


def _self_source() -> tuple[str, bytes, str]:
    _check(
        __name__ == R11_RELATIVE_PATH[:-3].replace("/", "."),
        "r11_module_name",
    )
    path = Path(__file__).resolve()
    root = _repo_root()
    _check(path == (root / Path(*R11_RELATIVE_PATH.split("/"))).resolve(), "r11_source_path")
    raw = _bounded_file(path, R11_RELATIVE_PATH.rsplit("/", 1)[-1], 2 * 1024 * 1024)
    return str(path), raw, _sha(raw)


def _dependency_rows() -> tuple[tuple[str, str, bytes, str, str], ...]:
    specs = (
        (_R6, R6_FILENAME, R6_SHA256, "r6_finite_parent_phase_parser"),
        (_R7, R7_FILENAME, R7_SHA256, "r7_finite_uncertain_result_parser"),
        (_R8, R8_FILENAME, R8_SHA256, "r8_outer_route_phase_parser"),
        (_R9, R9_FILENAME, R9_SHA256, "r9_sidecar_transport"),
        (_R10, R10_FILENAME, R10_SHA256, "r10_predeployment_handoff"),
    )
    rows = []
    for module, name, digest, role in specs:
        path, raw, observed = _pinned_module_source(module, name, digest)
        _check(observed == digest, "dependency_source_pin")
        rows.append((path, raw, digest, role, "repository_source:" + name))
    return tuple(rows)


_R11_OBSERVER_SOURCE = r'''
def _r11_emit_returned_result_frame(phase_sink, safe_result, runner):
    """Save one finite frame only for an exact validator-approved capture."""
    fields = {"schema", "disposition", "reason", "parse_allowed", "projection", "inner_stage", "inner_code", "lifecycle"}
    if type(safe_result) is not dict or set(safe_result) != fields:
        return
    if safe_result.get("disposition") != "OUTER_CAPTURED" or safe_result.get("parse_allowed") is not False:
        return
    manifest = getattr(runner, "MANIFEST", None)
    once = manifest.get("once") if type(manifest) is dict else None
    reasons = once.get("allowed_result_reasons") if type(once) is dict else None
    pairs = once.get("inner_diagnostic_pairs") if type(once) is dict else None
    result_schema = once.get("result_schema") if type(once) is dict else None
    if (
        type(result_schema) is not str
        or safe_result.get("schema") != result_schema
        or type(reasons) is not list
        or not reasons
        or len(reasons) > 256
        or any(type(item) is not str for item in reasons)
        or reasons != sorted(set(reasons))
        or type(pairs) is not list
        or len(pairs) > 14
        or any(type(item) is not list or len(item) != 2 or any(type(part) is not str for part in item) for item in pairs)
        or pairs != sorted(pairs)
        or len({tuple(item) for item in pairs}) != len(pairs)
    ):
        return
    reason = safe_result.get("reason")
    if type(reason) is not str:
        return
    try:
        reason_ordinal = reasons.index(reason)
    except (ValueError, TypeError):
        return
    inner_stage = safe_result.get("inner_stage")
    inner_code = safe_result.get("inner_code")
    if (inner_stage, inner_code) == (None, None):
        pair_ordinal = 0
    else:
        try:
            pair_ordinal = pairs.index([inner_stage, inner_code]) + 1
        except (ValueError, TypeError):
            return
    projection = safe_result.get("projection")
    if type(projection) is not dict or set(projection) != {"outer_status", "outer_reason", "outer_route_invocations"}:
        return
    outer_status = projection.get("outer_status")
    status_codes = {"PASS": 0, "FAILED": 1, "BLOCKED": 2, "UNSET": 3}
    if type(outer_status) is not str or outer_status not in status_codes:
        return
    outer_reason = projection.get("outer_reason")
    if (
        type(outer_reason) is not str
        or not 1 <= len(outer_reason) <= 96
        or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789_" for char in outer_reason)
    ):
        return
    outer_routes = projection.get("outer_route_invocations")
    if type(outer_routes) is not int or outer_routes not in (0, 1):
        return
    lifecycle = safe_result.get("lifecycle")
    lifecycle_fields = {"route_invocations", "native_operations", "provider_requests", "source_review_bound", "strict_cases_passed", "case_result"}
    if type(lifecycle) is not dict or set(lifecycle) != lifecycle_fields:
        return
    routes = lifecycle.get("route_invocations")
    native = lifecycle.get("native_operations")
    provider = lifecycle.get("provider_requests")
    bound = lifecycle.get("source_review_bound")
    if routes is not None and (type(routes) is not int or routes not in (0, 1)):
        return
    if native is not None and (type(native) is not int or native < 0):
        return
    if provider is not None and type(provider) is not bool:
        return
    if (
        type(bound) is not bool
        or bound is not True
        or type(lifecycle.get("strict_cases_passed")) is not int
        or lifecycle.get("strict_cases_passed") != 0
        or lifecycle.get("case_result") is not False
        or reason_ordinal > 255
        or pair_ordinal > 14
    ):
        return
    route_code = "N" if routes is None else str(routes)
    native_code = "N" if native is None else ("0" if native == 0 else "P")
    provider_code = "N" if provider is None else ("1" if provider else "0")
    bound_code = "1"
    route_status_code = status_codes[outer_status]
    frame_body = "C%02x%x%s%s%s%s%x%s" % (
        reason_ordinal, pair_ordinal, route_code, native_code, provider_code,
        bound_code, route_status_code, outer_routes,
    )
    frame = b"M01R11:" + frame_body.encode("ascii") + b"\n"
    if len(frame) != 18 or len(frame) > 20:
        return
    if getattr(phase_sink, "_closed", False) is not False or getattr(phase_sink, "_broken", True) is not False:
        return
    if getattr(phase_sink, "_stream", None) is None:
        return
    try:
        phase_sink._r11_returned_result_frame = frame
    except BaseException:
        return


def _r11_write_pending_returned_result_frame(phase_sink):
    frame = getattr(phase_sink, "_r11_returned_result_frame", None)
    if (
        type(frame) is not bytes
        or len(frame) != 18
        or len(frame) > 20
        or getattr(phase_sink, "_closed", False) is not True
        or getattr(phase_sink, "_broken", True) is not False
    ):
        return
    stream = getattr(phase_sink, "_stream", None)
    if stream is None:
        return
    try:
        written = stream.write(frame)
        if type(written) is int and written != len(frame):
            phase_sink._broken = True
            return
        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()
    except BaseException:
        try:
            phase_sink._broken = True
        except BaseException:
            return
'''.lstrip()


def _compose_bootstrap(r8_raw: bytes) -> bytes:
    _check(type(r8_raw) is bytes and 0 < len(r8_raw) <= _R9.MAX_BOOTSTRAP_BYTES, "r8_bootstrap_size")
    _check(r8_raw.count(_R11_RESULT_CALL_ANCHOR) == 1, "r7_result_anchor")
    _check(r8_raw.count(_R11_PHASE_WRITE_ANCHOR) == 1, "r8_phase_write_anchor")
    _check(r8_raw.count(_MAIN_GUARD) == 1, "main_guard_anchor")
    source = r8_raw.replace(
        _R11_RESULT_CALL_ANCHOR,
        _R11_RESULT_CALL_ANCHOR + b"        _r11_emit_returned_result_frame(phase_sink, safe_result, runner)\n",
        1,
    )
    source = source.replace(
        _R11_PHASE_WRITE_ANCHOR,
        _R11_PHASE_WRITE_ANCHOR + b"        _r11_write_pending_returned_result_frame(phase_sink)\n",
        1,
    )
    source = source.replace(
        _MAIN_GUARD,
        b"\n" + _R11_OBSERVER_SOURCE.encode("ascii") + _MAIN_GUARD,
        1,
    )
    _check(len(source) <= _R9.MAX_BOOTSTRAP_BYTES, "r11_bootstrap_size")
    try:
        compile(source, "<m01-r11-composed-bootstrap>", "exec", dont_inherit=True)
    except BaseException:
        raise ReturnedResultObserverBlocked("r11_bootstrap_compile") from None
    return source


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R11 transport and result frame bound to exact R10 preparation bytes."""

    r10_prepared: Any
    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    descriptor_json: bytes
    stdin_descriptor: bytes
    runner_bytes: bytes
    bootstrap_bytes: bytes
    stub_bytes: bytes
    sidecar_path: str
    sidecar_sha256: str
    sidecar_size_bytes: int
    helper_path: str
    helper_bytes: bytes
    helper_sha256: str
    dependency_sources: tuple[tuple[str, bytes, str, str, str], ...]
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str
    windows_command_line_units: int

    @property
    def sidecar_bytes(self) -> bytes:
        return self.bootstrap_bytes

    def __getattr__(self, name: str) -> Any:
        return getattr(self.r10_prepared, name)


def _compose(prepared_r10: Any) -> PreparedM01Child:
    _R10._validate_prepared(prepared_r10)
    r8_raw = prepared_r10.sidecar_bytes
    base_r8 = prepared_r10.r9_prepared.r8_prepared
    _R8._validate_prepared(base_r8)
    _check(r8_raw == base_r8.bootstrap_bytes, "r10_r8_sidecar_mismatch")
    bootstrap = _compose_bootstrap(r8_raw)
    descriptor = _R9._R4._validate_descriptor(prepared_r10.descriptor_json)
    descriptor_sha = _sha(prepared_r10.descriptor_json)
    sidecar_path = _R9._sidecar_path(
        descriptor["runtime_namespace"]["deployment_dir"], _sha(bootstrap)
    )
    stub = _R9._stub_source(
        sidecar_path=sidecar_path,
        bootstrap_size=len(bootstrap),
        bootstrap_sha256=_sha(bootstrap),
        descriptor_size=len(prepared_r10.descriptor_json),
        descriptor_sha256=descriptor_sha,
    )
    stdin_descriptor = _R9._wire_prefix(bootstrap) + prepared_r10.descriptor_json
    _check(len(stdin_descriptor) <= _R9.MAX_STDIN_BYTES, "stdin_transport_limit")
    command = tuple(prepared_r10.command[:7]) + (stub.decode("utf-8"),)
    units = _R9._command_line_units(command)
    helper_path, helper_bytes, helper_sha = _self_source()
    dependencies = _dependency_rows()
    binding = dict(prepared_r10.binding)
    binding.update(
        {
            "schema": R11_BINDING_SCHEMA,
            "result_observer_schema": R11_RESULT_SCHEMA,
            "result_observer_prefix": R11_FRAME_PREFIX.decode("ascii"),
            "result_observer_max_bytes": R11_FRAME_MAX_BYTES,
            "r10_binding_sha256": prepared_r10.binding_sha256,
            "r10_sidecar_path": prepared_r10.sidecar_path,
            "r10_sidecar_sha256": prepared_r10.sidecar_sha256,
            "r10_sidecar_size_bytes": prepared_r10.sidecar_size_bytes,
            "r11_sidecar_path": sidecar_path,
            "r11_sidecar_sha256": _sha(bootstrap),
            "r11_sidecar_size_bytes": len(bootstrap),
            "r11_helper_path": helper_path,
            "r11_helper_sha256": helper_sha,
            "r11_helper_size_bytes": len(helper_bytes),
            "r11_dependency_sources": [
                {"path": path, "sha256": digest, "size_bytes": len(raw), "role": role}
                for path, raw, digest, role, _origin in dependencies
            ],
            "windows_command_line_utf16_units_including_nul": units,
            "windows_command_line_limit_utf16_units_including_nul": _R9.MAX_COMMAND_LINE_UNITS,
            "canonical_child_map_counts": {"public": 118, "software": 36, "canonical": 154},
            "r11_result_fields": [
                "reason_ordinal",
                "diagnostic_pair_ordinal",
                "route_invocations_reported",
                "native_operations_reported",
                "provider_requests_reported",
                "source_review_bound_reported",
                "outer_status",
                "outer_route_invocations",
            ],
            "outer_reason_policy": "never_emitted",
            "authority": False,
            "strict_cases_passed": 0,
            "case_result": False,
        }
    )
    binding_sha = _R6._canonical_binding_digest(binding, command, prepared_r10.cwd)
    return PreparedM01Child(
        r10_prepared=prepared_r10,
        command=command,
        cwd=prepared_r10.cwd,
        environment=dict(prepared_r10.environment),
        descriptor_json=prepared_r10.descriptor_json,
        stdin_descriptor=stdin_descriptor,
        runner_bytes=prepared_r10.runner_bytes,
        bootstrap_bytes=bootstrap,
        stub_bytes=stub,
        sidecar_path=sidecar_path,
        sidecar_sha256=_sha(bootstrap),
        sidecar_size_bytes=len(bootstrap),
        helper_path=helper_path,
        helper_bytes=helper_bytes,
        helper_sha256=helper_sha,
        dependency_sources=dependencies,
        binding=binding,
        binding_sha256=binding_sha,
        plan_disposition=prepared_r10.plan_disposition,
        windows_command_line_units=units,
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Build R11 from the exact R10 prepared child; no activation is performed."""
    _R10._verify_chain()
    try:
        base = _R10.prepare_r33_child(prepared_r31, root_metadata, environment=environment)
    except BaseException:
        raise ReturnedResultObserverBlocked("r10_prepare_rejected") from None
    return prepare_from_r10(base)


def prepare_from_r10(prepared_r10: Any) -> PreparedM01Child:
    """Compose R11 over one exact frozen R10 prepared result."""
    return _compose(prepared_r10)


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "prepared_type")
    try:
        expected = _compose(value.r10_prepared)
    except BaseException:
        raise ReturnedResultObserverBlocked("prepared_source") from None
    _check(value == expected, "prepared_binding")


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    """Return the exact R10 hold closure plus R11 sidecar and helper sources."""
    _validate_prepared(prepared)
    base = _R10.parent_hold_addition(prepared.r10_prepared)
    entries = dict(base["entries"])
    additions = [
        (
            prepared.sidecar_path,
            prepared.bootstrap_bytes,
            prepared.sidecar_sha256,
            R11_SIDECAR_ROLE,
            "generated_from_exact_r10_sidecar:" + prepared.r10_prepared.sidecar_sha256,
        ),
        (prepared.helper_path, prepared.helper_bytes, prepared.helper_sha256, R11_SOURCE_ROLE, "repository_source:" + R11_RELATIVE_PATH),
    ]
    additions.extend(prepared.dependency_sources)
    normalized = {_R9._normalized(path) for path in entries}
    for path, raw, digest, role, origin in additions:
        _check(_R9._absolute_windows_path(path), "r11_hold_path")
        _check(type(raw) is bytes and _sha(raw) == digest, "r11_hold_digest")
        key = _R9._normalized(path)
        if key in normalized:
            matches = [existing for existing in entries if _R9._normalized(existing) == key]
            _check(matches == [path], "r11_hold_collision")
            existing_entry = entries[path]
            _check(
                type(existing_entry) is dict
                and existing_entry.get("sha256") == digest
                and existing_entry.get("size_bytes") == len(raw),
                "r11_hold_existing_source_mismatch",
            )
            continue
        normalized.add(key)
        entries[path] = {
            "sha256": digest,
            "size_bytes": len(raw),
            "role": role,
            "origin": origin,
        }
    return {
        "schema": R11_HOLD_SCHEMA,
        "binding_sha256": prepared.binding_sha256,
        "r10_binding_sha256": prepared.r10_prepared.binding_sha256,
        "entries": dict(sorted(entries.items())),
        "canonical_child_map_count": 154,
        "r10_sidecar_path": prepared.r10_prepared.sidecar_path,
        "r10_once_path": prepared.r10_prepared.once_path,
        "r10_once_sha256": prepared.r10_prepared.once_sha256,
        "r10_once_size_bytes": prepared.r10_prepared.once_size_bytes,
        "r11_sidecar_path": prepared.sidecar_path,
        "r11_sidecar_sha256": prepared.sidecar_sha256,
        "r11_sidecar_size_bytes": prepared.sidecar_size_bytes,
        "r11_helper_path": prepared.helper_path,
        "r11_helper_sha256": prepared.helper_sha256,
        "r11_dependency_source_count": len(prepared.dependency_sources),
        "active_outer_path": json.loads(prepared.descriptor_json)["runtime_namespace"]["self_path"],
        "active_wrapper_path": json.loads(prepared.descriptor_json)["runtime_namespace"]["active_wrapper_path"],
    }


def verify_parent_hold_addition(prepared: PreparedM01Child, value: Any) -> bool:
    try:
        expected = parent_hold_addition(prepared)
    except BaseException:
        return False
    return type(value) is dict and value == expected


def _unobserved_returned_result() -> dict[str, Any]:
    return {
        "schema": R11_RESULT_SCHEMA,
        "status": "UNOBSERVED",
        "category": "UNOBSERVED",
        "disposition": "UNVERIFIED",
        "reason_ordinal": None,
        "diagnostic_pair_ordinal": None,
        "route_invocations_reported": None,
        "native_operations_reported": "UNOBSERVED",
        "provider_requests_reported": "UNOBSERVED",
        "source_review_bound_reported": None,
        "outer_status": "UNOBSERVED",
        "outer_reason_reported": "UNREPORTED",
        "outer_route_invocations": None,
        "strict_cases_passed": 0,
        "case_result": False,
        "verification": "UNVERIFIED",
        "authority": False,
    }


def _parse_returned_result_frame(raw: Any, runner_raw: bytes) -> dict[str, Any]:
    if (
        type(raw) is not bytes
        or len(raw) != 18
        or len(raw) > R11_FRAME_MAX_BYTES
        or not raw.startswith(R11_FRAME_PREFIX)
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
        or b"\r" in raw
    ):
        return _unobserved_returned_result()
    body = raw[len(R11_FRAME_PREFIX) : -1]
    if (
        len(body) != 10
        or body[:1] != b"C"
        or re.fullmatch(rb"[0-9a-f]{2}", body[1:3]) is None
        or re.fullmatch(rb"[0-9a-e]", body[3:4]) is None
        or body[4:5] not in b"N01"
        or body[5:6] not in b"N0P"
        or body[6:7] not in b"N01"
        or body[7:8] != b"1"
        or body[8:9] not in b"0123"
        or body[9:10] not in b"01"
    ):
        return _unobserved_returned_result()
    try:
        reasons, pairs = _R7._runner_manifest_tables(runner_raw)
        reason_ordinal = int(body[1:3], 16)
        pair_ordinal = int(body[3:4], 16)
    except BaseException:
        return _unobserved_returned_result()
    if reason_ordinal >= len(reasons) or pair_ordinal > len(pairs):
        return _unobserved_returned_result()
    routes = {b"N": None, b"0": 0, b"1": 1}[body[4:5]]
    native = {b"N": "UNSET", b"0": "ZERO", b"P": "POSITIVE_REPORTED"}[body[5:6]]
    provider = {b"N": "UNSET", b"0": "NO_REQUEST_REPORTED", b"1": "REQUEST_REPORTED"}[body[6:7]]
    statuses = {b"0": "PASS", b"1": "FAILED", b"2": "BLOCKED", b"3": "UNSET"}
    return {
        "schema": R11_RESULT_SCHEMA,
        "status": "OBSERVED_FIXED_RETURNED_RESULT",
        "category": "VALIDATOR_APPROVED_OUTER_CAPTURED",
        "disposition": "OUTER_CAPTURED",
        "reason_ordinal": reason_ordinal,
        "diagnostic_pair_ordinal": pair_ordinal,
        "route_invocations_reported": routes,
        "native_operations_reported": native,
        "provider_requests_reported": provider,
        "source_review_bound_reported": True,
        "outer_status": statuses[body[8:9]],
        "outer_reason_reported": "UNREPORTED",
        "outer_route_invocations": int(body[9:10]),
        "strict_cases_passed": 0,
        "case_result": False,
        "verification": "UNVERIFIED",
        "authority": False,
    }


def _parse_r11_parent_frames(raw: Any, runner_raw: bytes):
    maximum = _R6.MAX_PHASE_FRAME_BYTES + _R8.PHASE_MAX_BYTES + R11_FRAME_MAX_BYTES
    if type(raw) is not bytes or len(raw) > maximum or not raw.endswith(b"\n"):
        return _R7._unobserved_result(), _R6._unobserved_phase(), _R8._unobserved_route_phase(), _unobserved_returned_result()
    lines = raw.splitlines(keepends=True)
    if (
        len(lines) != 3
        or not lines[0].startswith(_R6.PHASE_PREFIX)
        or not lines[1].startswith(_R8.PHASE_PREFIX)
        or not lines[2].startswith(R11_FRAME_PREFIX)
    ):
        return _R7._unobserved_result(), _R6._unobserved_phase(), _R8._unobserved_route_phase(), _unobserved_returned_result()
    phase = _R6._parse_phase_frame(lines[0])
    route_phase = _R8._parse_route_phase_frame(lines[1])
    returned = _parse_returned_result_frame(lines[2], runner_raw)
    if (
        phase.get("status") != "OBSERVED_FIXED_STAGE"
        or phase.get("stage") != "CHILD_CUV2_POSTVERIFY_REPORTED"
        or phase.get("category") != "NONE"
        or route_phase.get("status") != "OBSERVED_FIXED_STAGE"
        or route_phase.get("stage") != "COMPLETED"
        or route_phase.get("outer_response") != "RETURNED"
        or route_phase.get("parse_outer_response") != "RETURNED"
        or route_phase.get("exception_category") != "NONE"
        or returned.get("status") != "OBSERVED_FIXED_RETURNED_RESULT"
    ):
        return _R7._unobserved_result(), _R6._unobserved_phase(), _R8._unobserved_route_phase(), _unobserved_returned_result()
    return _R7._unobserved_result(), phase, route_phase, returned


def _parent_projection(r8_adapter: Any, result: Any, runner_raw: bytes, fallback: Any):
    try:
        result_type = r8_adapter._r5._inner._r32.ParentEnvelopeResult
    except BaseException:
        return fallback(result)
    if type(result) is not result_type:
        return fallback(result)
    if not _R6._safe_to_read_phase(result):
        projected = fallback(result)
        if type(projected) is _R6.M01ParentDiagnosticResult:
            phase = dict(projected.child_phase)
            phase["returned_result"] = _unobserved_returned_result()
            return dataclasses.replace(projected, child_phase=phase)
        return projected
    stderr = result.stderr
    maximum = _R6.MAX_PHASE_FRAME_BYTES + _R8.PHASE_MAX_BYTES + R11_FRAME_MAX_BYTES
    contains_r11 = (
        type(stderr) is bytes
        and len(stderr) <= maximum
        and R11_FRAME_PREFIX in stderr
    )
    if not contains_r11:
        projected = fallback(result)
        if type(projected) is _R6.M01ParentDiagnosticResult:
            phase = dict(projected.child_phase)
            phase["returned_result"] = _unobserved_returned_result()
            return dataclasses.replace(projected, child_phase=phase)
        return projected
    runner_result, phase, route_phase, returned = _parse_r11_parent_frames(stderr, runner_raw)
    if returned.get("status") != "OBSERVED_FIXED_RETURNED_RESULT":
        projected = fallback(result)
        if type(projected) is _R6.M01ParentDiagnosticResult:
            updated = dict(projected.child_phase)
            updated["returned_result"] = _unobserved_returned_result()
            return dataclasses.replace(projected, child_phase=updated)
        return projected
    summary = r8_adapter._r5.summarize_result(result)
    phase = dict(phase)
    phase["runner_result"] = runner_result
    phase["outer_route_phase"] = route_phase
    phase["returned_result"] = returned
    return _R6.M01ParentDiagnosticResult(
        schema=summary["schema"],
        status=summary["status"],
        reason=summary["reason"],
        cleanup_reason=summary["cleanup_reason"],
        child_returncode=summary["child_returncode"],
        capture_complete=summary["capture_complete"],
        cleanup_complete=summary["cleanup_complete"],
        scope_released=summary["scope_released"],
        scope_retained=summary["scope_retained"],
        stdout_bytes=summary["stdout_bytes"],
        stderr_bytes=summary["stderr_bytes"],
        child_phase=phase,
    )


class M01WindowsParentAdapter:
    """R10 parent adapter with a per-instance, post-release R11 parser hook."""

    def __init__(self, prepared_child: PreparedM01Child, **kwargs: Any):
        _validate_prepared(prepared_child)
        self.prepared = prepared_child
        self._r10 = _R10.M01WindowsParentAdapter(prepared_child.r10_prepared, **kwargs)
        runtime_view = dataclasses.replace(
            prepared_child.r10_prepared,
            command=prepared_child.command,
            stdin_descriptor=prepared_child.stdin_descriptor,
            stub_bytes=prepared_child.stub_bytes,
            sidecar_path=prepared_child.sidecar_path,
            sidecar_sha256=prepared_child.sidecar_sha256,
            sidecar_size_bytes=prepared_child.sidecar_size_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
            windows_command_line_units=prepared_child.windows_command_line_units,
        )
        _R10._rebind_r9_adapter(self._r10._r9, runtime_view)
        self._r8_adapter = self._r10._r9._r8
        self._base_projector = self._r8_adapter._project_r7_parent_result
        self._used_lock = threading.Lock()
        self._used = False

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        with self._used_lock:
            _check(self._used is False, "adapter_reentry")
            self._used = True
        projector = self._base_projector
        adapter = self._r8_adapter
        runner_raw = self.prepared.runner_bytes
        adapter._project_r7_parent_result = lambda result: _parent_projection(
            adapter, result, runner_raw, projector
        )
        try:
            return self._r10.supervise(source_scope, release_source_scope, **kwargs)
        finally:
            adapter._project_r7_parent_result = projector

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._r10.summarize_result(result)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._r10, name)


if __name__ == "__main__":
    raise SystemExit("Use prepare_r33_child() and hold the exact R11 addition.")
