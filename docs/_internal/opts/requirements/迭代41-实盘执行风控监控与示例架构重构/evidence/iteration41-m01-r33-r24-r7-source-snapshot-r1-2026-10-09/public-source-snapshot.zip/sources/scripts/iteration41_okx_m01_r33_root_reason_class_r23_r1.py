"""Add a separate source-bound child-reason class frame to the R22 route.

R23 preserves the four existing phase/result frames, including R12's UNKNOWN
result. It adds a fifth bounded ordinal frame for an exact literal from the
prepared active outer, optionally after the fixed ``root_child_`` prefix.
The ordinal is diagnostic only and never establishes a case result.
"""

from __future__ import annotations

import contextlib
import copy
import dataclasses
import hashlib
import ast
import json
import re
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_root_prepare_r22_r1 as _R22


_R13 = _R22._R13
_R12 = _R13._R12
R23_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_root_reason_class_r23_r1.py"
R23_RESULT_SCHEMA = "iteration41.okx.m01.r33.root-reason-class-r23.root-preparation.v1"
R23_ADAPTER_SCHEMA = "iteration41.okx.m01.r33.root-reason-class-r23.parent-adapter.v1"
R23_CLASS_SCHEMA = "iteration41.okx.m01.r33.child-reason-class-r23.v1"
R23_SOURCE_ROLE = "r23_child_reason_class_observer_source"
R23_FRAME_PREFIX = b"M01R23:"
R23_FRAME_MAX_BYTES = 16
R23_MAX_SOURCE_BYTES = 2 * 1024 * 1024
R23_MAX_BOOTSTRAP_BYTES = 2 * 1024 * 1024
R23_PINNED_R22_SHA256 = "81f72804244407b1ef010ee9361b030980923c758624a4e1ced35fcd7162bf9b"
R23_REASON_PREFIX_ANCHOR = "root_child_case_predicate_satisfied"
R23_REASON_PREFIX_SUFFIX = "case_predicate_satisfied"
R23_REASON_PREFIX = "root_child_"
_SAFE_REASON = re.compile(r"[a-z0-9_]{1,96}\Z")
_R23_CALL_ANCHOR = b"        _r12_emit_outer_reason_ordinal_frame(phase_sink, safe_result, runner)\n"
_R23_WRITE_ANCHOR = b"        _r12_write_pending_outer_reason_ordinal_frame(phase_sink)\n"
_MAIN_GUARD = b'\nif __name__ == "__main__":\n'
_PATCH_LOCK = threading.Lock()
_PATCH_OWNER_THREAD: Optional[int] = None
_ORIGINAL_COMPOSE_BOOTSTRAP = _R12._compose_bootstrap
_ORIGINAL_PARENT_PROJECTION = _R12._parent_projection

R23_FAILURE_CODES = frozenset(
    {
        "r23_module_name",
        "r23_module_path",
        "r23_source_unavailable",
        "r23_source_size",
        "r23_source_pin",
        "r23_r22_source_binding",
        "r23_patch_context_busy",
        "r23_patch_context_changed",
        "r23_patch_owner_thread",
        "r23_compose_input_binding",
        "r23_bootstrap_anchor",
        "r23_bootstrap_size",
        "r23_bootstrap_compile",
        "r23_reason_table_binding",
        "r23_reason_source_parse",
        "r23_prefix_binding",
        "r23_outer_binding",
        "r23_prepared_binding",
        "r23_hold_collision",
        "r23_hold_binding",
        "r23_adapter_binding",
    }
)


class ChildReasonClassR23Blocked(ValueError):
    """A fixed R23 source, transformation, or hold contract failed closed."""

    def __init__(self, code: str) -> None:
        self.code = code if code in R23_FAILURE_CODES else "r23_hold_binding"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _check(value: Any, code: str) -> None:
    if not value:
        raise ChildReasonClassR23Blocked(code)


def _self_source() -> tuple[str, bytes, str]:
    _check(__name__ == R23_RELATIVE_PATH[:-3].replace("/", "."), "r23_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected = (root / Path(*R23_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected, "r23_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R23_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ChildReasonClassR23Blocked("r23_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R23_MAX_SOURCE_BYTES, "r23_source_size")
    return str(path), raw, _sha(raw)


def _r22_source() -> tuple[str, bytes, str]:
    try:
        source = _R22._self_source()
    except BaseException:
        raise ChildReasonClassR23Blocked("r23_r22_source_binding") from None
    _check(
        type(source) is tuple
        and len(source) == 3
        and source[2] == R23_PINNED_R22_SHA256
        and _sha(source[1]) == source[2],
        "r23_r22_source_binding",
    )
    return source


@dataclasses.dataclass(frozen=True)
class _ReasonBinding:
    schema: str
    active_outer_sha256: str
    active_wrapper_sha256: str
    plan_sha256: str
    source_map_sha256: str
    r12_source_sha256: str
    r23_source_sha256: str
    reason_prefix: str
    reason_table: tuple[str, ...]
    reason_table_sha256: str


def _derive_prefix(table: tuple[str, ...]) -> str:
    _check(
        type(table) is tuple
        and R23_REASON_PREFIX_ANCHOR in table
        and R23_REASON_PREFIX_ANCHOR.endswith(R23_REASON_PREFIX_SUFFIX),
        "r23_prefix_binding",
    )
    prefix = R23_REASON_PREFIX_ANCHOR[: -len(R23_REASON_PREFIX_SUFFIX)]
    _check(prefix == R23_REASON_PREFIX, "r23_prefix_binding")
    return prefix


def _reason_class_table(active_outer: bytes, base_table: tuple[str, ...]) -> tuple[str, ...]:
    """Add only reason-bearing literals missed by R12's exact-reason table.

    R12 intentionally records exact outer reasons and leaves the dynamic
    ``root_child_`` composition unknown. R23 supplements that table from the
    generated outer's ``_safe_child_projection``/``run_prelaunch`` reason and
    failure expressions, including nested literal alternatives such as the
    fixed ``outer_prelaunch_failed`` fallback.
    """
    try:
        tree = ast.parse(active_outer)
    except (SyntaxError, ValueError, UnicodeDecodeError):
        raise ChildReasonClassR23Blocked("r23_reason_source_parse") from None
    functions = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name in {"_safe_child_projection", "run_prelaunch"}
    ]
    _check(
        sum(node.name == "_safe_child_projection" for node in functions) == 1
        and sum(node.name == "run_prelaunch" for node in functions) == 1,
        "r23_reason_source_parse",
    )
    literals = set(base_table)

    def collect(node: ast.AST) -> None:
        for child in ast.walk(node):
            if (
                isinstance(child, ast.Constant)
                and type(child.value) is str
                and _SAFE_REASON.fullmatch(child.value) is not None
            ):
                literals.add(child.value)

    for function in functions:
        for node in ast.walk(function):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id == "_check" and len(node.args) >= 2:
                    collect(node.args[1])
                elif isinstance(node.func, ast.Name) and node.func.id == "PrelaunchBlocked" and node.args:
                    collect(node.args[0])
                for keyword in node.keywords:
                    if keyword.arg in {"reason", "failure"}:
                        collect(keyword.value)
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if any(
                    isinstance(target, ast.Name) and target.id in {"reason", "failure"}
                    for target in targets
                ):
                    collect(node.value)
            if isinstance(node, ast.Dict):
                for key, value in zip(node.keys, node.values):
                    if isinstance(key, ast.Constant) and key.value in {"reason", "failure"}:
                        collect(value)
    _check(all(_SAFE_REASON.fullmatch(item) is not None for item in literals), "r23_reason_source_parse")
    result = tuple(sorted(literals))
    _check(0 < len(result) <= 0xFFFF, "r23_reason_source_parse")
    return result


def _make_reason_binding(
    active_outer: bytes,
    table: tuple[str, ...],
    outer: dict[str, Any],
    r23_source: tuple[str, bytes, str],
) -> _ReasonBinding:
    _check(
        type(active_outer) is bytes
        and 0 < len(active_outer) <= R23_MAX_BOOTSTRAP_BYTES
        and type(outer) is dict
        and type(table) is tuple,
        "r23_compose_input_binding",
    )
    try:
        expected_table = _R12._active_outer_reason_literals(active_outer)
        r12_path, r12_raw, r12_sha256 = _R13._pinned_r12_source()
    except BaseException:
        raise ChildReasonClassR23Blocked("r23_reason_table_binding") from None
    _check(table == expected_table, "r23_reason_table_binding")
    reason_table = _reason_class_table(active_outer, table)
    prefix = _derive_prefix(reason_table)
    _check(
        type(r23_source) is tuple
        and len(r23_source) == 3
        and type(r23_source[1]) is bytes
        and _sha(r23_source[1]) == r23_source[2],
        "r23_source_pin",
    )
    values = {
        "active_outer_sha256": _sha(active_outer),
        "active_wrapper_sha256": outer.get("active_wrapper_sha256"),
        "plan_sha256": outer.get("plan_sha256"),
        "source_map_sha256": outer.get("source_map_sha256"),
    }
    for key, value in values.items():
        _check(
            type(value) is str
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value),
            "r23_outer_binding",
        )
    _check(outer.get("active_outer_sha256") == values["active_outer_sha256"], "r23_outer_binding")
    table_sha256 = _sha(
        _canonical_json(
            {
                "schema": R23_CLASS_SCHEMA,
                **values,
                "r12_source_sha256": r12_sha256,
                "r23_source_sha256": r23_source[2],
                "reason_prefix": prefix,
                "reason_table": list(reason_table),
            }
        )
    )
    return _ReasonBinding(
        schema=R23_CLASS_SCHEMA,
        active_outer_sha256=values["active_outer_sha256"],
        active_wrapper_sha256=values["active_wrapper_sha256"],
        plan_sha256=values["plan_sha256"],
        source_map_sha256=values["source_map_sha256"],
        r12_source_sha256=r12_sha256,
        r23_source_sha256=r23_source[2],
        reason_prefix=prefix,
        reason_table=reason_table,
        reason_table_sha256=table_sha256,
    )


def _binding_from_prepared(prepared: Any, source: tuple[str, bytes, str]) -> _ReasonBinding:
    _check(
        type(getattr(prepared, "active_outer_source", None)) is bytes
        and type(getattr(prepared, "reason_table", None)) is tuple
        and type(getattr(prepared, "outer_binding", None)) is dict,
        "r23_prepared_binding",
    )
    outer = dict(prepared.outer_binding)
    outer["active_outer"] = prepared.active_outer_source
    binding = _make_reason_binding(
        prepared.active_outer_source, prepared.reason_table, outer, source
    )
    _check(
        binding.active_outer_sha256 == prepared.transform_binding.get("active_outer_sha256")
        and binding.active_outer_sha256 == prepared.outer_binding.get("active_outer_sha256")
        and binding.source_map_sha256 == _sha(prepared.source_map_bytes)
        and _R12._reason_table_digest(prepared.reason_table, outer)
        == prepared.reason_table_sha256,
        "r23_prepared_binding",
    )
    return binding


def _binding_payload(binding: _ReasonBinding) -> dict[str, Any]:
    return {
        "schema": binding.schema,
        "active_outer_sha256": binding.active_outer_sha256,
        "active_wrapper_sha256": binding.active_wrapper_sha256,
        "plan_sha256": binding.plan_sha256,
        "source_map_sha256": binding.source_map_sha256,
        "r12_source_sha256": binding.r12_source_sha256,
        "r23_source_sha256": binding.r23_source_sha256,
        "reason_prefix": binding.reason_prefix,
        "reason_table": list(binding.reason_table),
    }


_R23_OBSERVER_SOURCE = r'''
import hashlib
import json

R23_REASON_CLASS_SCHEMA = __R23_SCHEMA__
R23_REASON_PREFIX = __R23_PREFIX__
R23_REASON_TABLE = __R23_TABLE__
R23_REASON_TABLE_SHA256 = __R23_TABLE_SHA256__
R23_REASON_BINDING_JSON = __R23_BINDING_JSON__
R23_ACTIVE_OUTER_SHA256 = __R23_ACTIVE_OUTER_SHA256__
R23_ACTIVE_WRAPPER_SHA256 = __R23_ACTIVE_WRAPPER_SHA256__
R23_PLAN_SHA256 = __R23_PLAN_SHA256__
R23_SOURCE_MAP_SHA256 = __R23_SOURCE_MAP_SHA256__
R23_R12_SOURCE_SHA256 = __R23_R12_SOURCE_SHA256__
R23_SOURCE_SHA256 = __R23_SOURCE_SHA256__
R23_FRAME_PREFIX = b"M01R23:"
R23_FRAME_MAX_BYTES = 16


def _r23_emit_child_reason_class_frame(phase_sink, safe_result, runner):
    """Store an ordinal for a source-listed reason; never write source text."""
    r12_frame = getattr(phase_sink, "_r12_outer_reason_frame", None)
    if (
        type(r12_frame) is not bytes
        or len(r12_frame) != 13
        or not r12_frame.startswith(b"M01R12:O")
        or not r12_frame.endswith(b"\n")
    ):
        return
    fields = {"schema", "disposition", "reason", "parse_allowed", "projection", "inner_stage", "inner_code", "lifecycle"}
    if type(safe_result) is not dict or set(safe_result) != fields:
        return
    if safe_result.get("disposition") != "OUTER_CAPTURED" or safe_result.get("parse_allowed") is not False:
        return
    validator = getattr(runner, "_safe_result", None)
    try:
        if not callable(validator) or validator(safe_result) is not safe_result:
            return
    except BaseException:
        return
    manifest = getattr(runner, "MANIFEST", None)
    candidate = manifest.get("candidate") if type(manifest) is dict else None
    namespace = manifest.get("runtime_namespace") if type(manifest) is dict else None
    software_pins = manifest.get("software_pins") if type(manifest) is dict else None
    once = manifest.get("once") if type(manifest) is dict else None
    canonical = getattr(runner, "_canonical", None)
    try:
        plan_key = canonical(namespace.get("plan_path")) if type(namespace) is dict and callable(canonical) else None
    except BaseException:
        plan_key = None
    if (
        type(candidate) is not dict
        or candidate.get("active_outer_sha256") != R23_ACTIVE_OUTER_SHA256
        or candidate.get("active_wrapper_sha256") != R23_ACTIVE_WRAPPER_SHA256
        or type(namespace) is not dict
        or type(namespace.get("plan_path")) is not str
        or type(software_pins) is not dict
        or type(plan_key) is not str
        or software_pins.get(plan_key) != R23_PLAN_SHA256
        or type(once) is not dict
        or type(once.get("result_schema")) is not str
        or safe_result.get("schema") != once.get("result_schema")
        or type(R23_REASON_TABLE) is not tuple
        or not R23_REASON_TABLE
        or len(R23_REASON_TABLE) > 0xFFFF
        or any(type(reason) is not str for reason in R23_REASON_TABLE)
        or tuple(sorted(set(R23_REASON_TABLE))) != R23_REASON_TABLE
    ):
        return
    projection = safe_result.get("projection")
    if type(projection) is not dict or set(projection) != {"outer_status", "outer_reason", "outer_route_invocations"}:
        return
    if projection.get("outer_status") not in ("BLOCKED", "FAILED"):
        return
    reason = projection.get("outer_reason")
    if (
        type(reason) is not str
        or not 1 <= len(reason) <= 96
        or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789_" for char in reason)
    ):
        return
    if (
        type(R23_REASON_PREFIX) is not str
        or R23_REASON_PREFIX != "root_child_"
        or type(R23_REASON_BINDING_JSON) is not str
        or type(R23_REASON_TABLE_SHA256) is not str
        or type(R23_SOURCE_MAP_SHA256) is not str
        or type(R23_R12_SOURCE_SHA256) is not str
        or type(R23_SOURCE_SHA256) is not str
    ):
        return
    payload = {
        "schema": R23_REASON_CLASS_SCHEMA,
        "active_outer_sha256": R23_ACTIVE_OUTER_SHA256,
        "active_wrapper_sha256": R23_ACTIVE_WRAPPER_SHA256,
        "plan_sha256": R23_PLAN_SHA256,
        "source_map_sha256": R23_SOURCE_MAP_SHA256,
        "r12_source_sha256": R23_R12_SOURCE_SHA256,
        "r23_source_sha256": R23_SOURCE_SHA256,
        "reason_prefix": R23_REASON_PREFIX,
        "reason_table": list(R23_REASON_TABLE),
    }
    canonical = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if canonical != R23_REASON_BINDING_JSON:
        return
    if hashlib.sha256(canonical.encode("ascii")).hexdigest() != R23_REASON_TABLE_SHA256:
        return
    form = "U"
    ordinal = 0
    try:
        ordinal = R23_REASON_TABLE.index(reason) + 1
        form = "D"
    except ValueError:
        if reason.startswith(R23_REASON_PREFIX):
            suffix = reason[len(R23_REASON_PREFIX):]
            try:
                ordinal = R23_REASON_TABLE.index(suffix) + 1
                form = "C"
            except ValueError:
                ordinal = 0
    if not 0 <= ordinal <= 0xFFFF:
        return
    frame = R23_FRAME_PREFIX + (form + "%04x" % ordinal).encode("ascii") + b"\n"
    if len(frame) != 13 or len(frame) > R23_FRAME_MAX_BYTES:
        return
    if getattr(phase_sink, "_closed", False) is not False or getattr(phase_sink, "_broken", True) is not False:
        return
    if getattr(phase_sink, "_stream", None) is None:
        return
    try:
        phase_sink._r23_child_reason_class_frame = frame
    except BaseException:
        return


def _r23_write_pending_child_reason_class_frame(phase_sink):
    frame = getattr(phase_sink, "_r23_child_reason_class_frame", None)
    if (
        type(frame) is not bytes
        or len(frame) != 13
        or len(frame) > R23_FRAME_MAX_BYTES
        or not frame.startswith(R23_FRAME_PREFIX)
        or getattr(phase_sink, "_closed", False) is not True
        or getattr(phase_sink, "_broken", True) is not False
    ):
        return
    stream = getattr(phase_sink, "_stream", None)
    if stream is None:
        return
    try:
        written = stream.write(frame)
        if type(written) is int and written != len(frame):
            phase_sink._broken = True
            return
        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()
    except BaseException:
        try:
            phase_sink._broken = True
        except BaseException:
            return
'''.lstrip()


def _append_reason_class_bootstrap(
    base: bytes,
    table: tuple[str, ...],
    outer: dict[str, Any],
    source: tuple[str, bytes, str],
) -> tuple[bytes, _ReasonBinding]:
    binding = _make_reason_binding(outer.get("active_outer"), table, outer, source)
    _check(
        type(base) is bytes
        and 0 < len(base) <= R23_MAX_BOOTSTRAP_BYTES
        and base.count(_R23_CALL_ANCHOR) == 1
        and base.count(_R23_WRITE_ANCHOR) == 1
        and base.count(_MAIN_GUARD) == 1,
        "r23_bootstrap_anchor",
    )
    output = base.replace(
        _R23_CALL_ANCHOR,
        _R23_CALL_ANCHOR
        + b"        _r23_emit_child_reason_class_frame(phase_sink, safe_result, runner)\n",
        1,
    )
    output = output.replace(
        _R23_WRITE_ANCHOR,
        _R23_WRITE_ANCHOR
        + b"        _r23_write_pending_child_reason_class_frame(phase_sink)\n",
        1,
    )
    payload = _binding_payload(binding)
    substitutions = {
        b"__R23_SCHEMA__": repr(binding.schema).encode("ascii"),
        b"__R23_PREFIX__": repr(binding.reason_prefix).encode("ascii"),
        b"__R23_TABLE__": repr(binding.reason_table).encode("ascii"),
        b"__R23_TABLE_SHA256__": repr(binding.reason_table_sha256).encode("ascii"),
        b"__R23_BINDING_JSON__": repr(_canonical_json(payload).decode("ascii")).encode("ascii"),
        b"__R23_ACTIVE_OUTER_SHA256__": repr(binding.active_outer_sha256).encode("ascii"),
        b"__R23_ACTIVE_WRAPPER_SHA256__": repr(binding.active_wrapper_sha256).encode("ascii"),
        b"__R23_PLAN_SHA256__": repr(binding.plan_sha256).encode("ascii"),
        b"__R23_SOURCE_MAP_SHA256__": repr(binding.source_map_sha256).encode("ascii"),
        b"__R23_R12_SOURCE_SHA256__": repr(binding.r12_source_sha256).encode("ascii"),
        b"__R23_SOURCE_SHA256__": repr(binding.r23_source_sha256).encode("ascii"),
    }
    observer = _R23_OBSERVER_SOURCE.encode("ascii")
    for marker, replacement in substitutions.items():
        _check(observer.count(marker) == 1, "r23_bootstrap_anchor")
        observer = observer.replace(marker, replacement, 1)
    output = output.replace(_MAIN_GUARD, b"\n" + observer + _MAIN_GUARD, 1)
    _check(0 < len(output) <= R23_MAX_BOOTSTRAP_BYTES, "r23_bootstrap_size")
    try:
        compile(output, "<m01-r23-reason-class-bootstrap>", "exec", dont_inherit=True)
    except BaseException:
        raise ChildReasonClassR23Blocked("r23_bootstrap_compile") from None
    return output, binding


@contextlib.contextmanager
def _compose_patch(source: tuple[str, bytes, str]):
    global _PATCH_OWNER_THREAD
    if not _PATCH_LOCK.acquire(blocking=False):
        raise ChildReasonClassR23Blocked("r23_patch_context_busy")
    owner = threading.get_ident()
    original = _R12._compose_bootstrap
    installed = False
    wrapper = None
    calls = 0
    intact = True
    try:
        _check(
            _PATCH_OWNER_THREAD is None and original is _ORIGINAL_COMPOSE_BOOTSTRAP,
            "r23_patch_context_changed",
        )
        _PATCH_OWNER_THREAD = owner

        def compose_wrapper(r11_raw: bytes, table: tuple[str, ...], outer: dict[str, Any]) -> bytes:
            nonlocal calls
            _check(
                threading.get_ident() == owner
                and _PATCH_OWNER_THREAD == owner
                and _R12._compose_bootstrap is compose_wrapper,
                "r23_patch_owner_thread",
            )
            calls += 1
            _check(calls <= 32, "r23_patch_context_changed")
            try:
                base = original(r11_raw, table, outer)
                output, _binding = _append_reason_class_bootstrap(base, table, outer, source)
                return output
            except ChildReasonClassR23Blocked:
                raise
            except BaseException:
                raise ChildReasonClassR23Blocked("r23_compose_input_binding") from None

        wrapper = compose_wrapper
        _R12._compose_bootstrap = wrapper
        installed = True
        yield calls
    finally:
        if installed:
            intact = _R12._compose_bootstrap is wrapper
            _R12._compose_bootstrap = original
        _PATCH_OWNER_THREAD = None
        _PATCH_LOCK.release()
        if not intact:
            raise ChildReasonClassR23Blocked("r23_patch_context_changed")


def _add_r23_row(addition: dict[str, Any], source: tuple[str, bytes, str]):
    path, raw, digest = source
    r9 = _R13._R10._R9
    _check(r9._absolute_windows_path(path), "r23_hold_binding")
    _check(type(raw) is bytes and _sha(raw) == digest, "r23_source_pin")
    result = copy.deepcopy(addition)
    entries = dict(result.get("entries", {}))
    target = r9._normalized(path)
    _check(
        result.get("canonical_child_map_count") == 154
        and all(r9._normalized(existing) != target for existing in entries),
        "r23_hold_collision",
    )
    entries[path] = {
        "sha256": digest,
        "size_bytes": len(raw),
        "role": R23_SOURCE_ROLE,
        "origin": "repository_source:" + R23_RELATIVE_PATH,
    }
    result["entries"] = dict(sorted(entries.items()))
    return result, _sha(_canonical_json(result))


@dataclasses.dataclass(frozen=True)
class R23RootPreparedHold:
    """R22's same-call preparation plus the source-bound R23 parent row."""

    schema: str
    r22_result: Any
    r23_helper_path: str
    r23_helper_bytes: bytes
    r23_helper_sha256: str
    reason_binding: _ReasonBinding
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def prepared_r13(self) -> Any:
        return self.r22_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r22_result.prepared_r14

    @property
    def r20_result(self) -> Any:
        return self.r22_result.r20_result

    @property
    def r21_result(self) -> Any:
        return self.r22_result.r21_result

    @property
    def r22_helper_path(self) -> str:
        return self.r22_result.r22_helper_path

    @property
    def r22_helper_bytes(self) -> bytes:
        return self.r22_result.r22_helper_bytes

    @property
    def r22_helper_sha256(self) -> str:
        return self.r22_result.r22_helper_sha256


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R23RootPreparedHold:
    """Prepare exact R22 inputs while composing the bounded R23 frame."""
    source = _self_source()
    _r22_source()
    try:
        with _compose_patch(source):
            r22_result = _R22.prepare_root_hold(
                prepared_r31, root_metadata, environment=environment
            )
            binding = _binding_from_prepared(r22_result.prepared_r13, source)
            addition, digest = _add_r23_row(r22_result.hold_addition, source)
    except ChildReasonClassR23Blocked:
        raise
    except BaseException:
        raise ChildReasonClassR23Blocked("r23_prepared_binding") from None
    _check(_self_source() == source and _r22_source()[2] == R23_PINNED_R22_SHA256, "r23_source_pin")
    result = R23RootPreparedHold(
        schema=R23_RESULT_SCHEMA,
        r22_result=r22_result,
        r23_helper_path=source[0],
        r23_helper_bytes=source[1],
        r23_helper_sha256=source[2],
        reason_binding=binding,
        hold_addition=addition,
        hold_addition_sha256=digest,
    )
    _check(_verify_local_hold(result, source), "r23_hold_binding")
    return result


def _verify_local_hold(value: Any, source: tuple[str, bytes, str]) -> bool:
    try:
        if type(value) is not R23RootPreparedHold or value.schema != R23_RESULT_SCHEMA:
            return False
        if (value.r23_helper_path, value.r23_helper_bytes, value.r23_helper_sha256) != source:
            return False
        binding = _binding_from_prepared(value.prepared_r13, source)
        if value.reason_binding != binding:
            return False
        addition, digest = _add_r23_row(value.r22_result.hold_addition, source)
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False


def verify_root_hold(value: Any) -> bool:
    try:
        source = _self_source()
        if not _r22_source() or not _verify_local_hold(value, source):
            return False
        with _compose_patch(source):
            return _R22.verify_root_hold(value.r22_result)
    except BaseException:
        return False


def _parse_reason_class_frame(raw: Any, binding: _ReasonBinding) -> dict[str, Any]:
    unobserved = {
        "schema": R23_CLASS_SCHEMA,
        "status": "UNOBSERVED",
        "category": "UNOBSERVED",
        "reason_class_ordinal": None,
        "reason_class_form": "UNOBSERVED",
        "reason_table_sha256": None,
        "authority": False,
    }
    if (
        type(raw) is not bytes
        or len(raw) != 13
        or len(raw) > R23_FRAME_MAX_BYTES
        or not raw.startswith(R23_FRAME_PREFIX)
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
        or b"\r" in raw
    ):
        return unobserved
    body = raw[len(R23_FRAME_PREFIX) : -1]
    if len(body) != 5 or body[:1] not in (b"D", b"C", b"U"):
        return unobserved
    if any(char not in b"0123456789abcdef" for char in body[1:]):
        return unobserved
    ordinal = int(body[1:], 16)
    form = body[:1].decode("ascii")
    if form == "U":
        if ordinal != 0:
            return unobserved
        return {
            "schema": R23_CLASS_SCHEMA,
            "status": "OBSERVED_UNKNOWN_REASON_CLASS",
            "category": "UNKNOWN",
            "reason_class_ordinal": 0,
            "reason_class_form": "UNKNOWN",
            "reason_table_sha256": binding.reason_table_sha256,
            "authority": False,
        }
    if not 1 <= ordinal <= len(binding.reason_table):
        return unobserved
    return {
        "schema": R23_CLASS_SCHEMA,
        "status": "OBSERVED_SOURCE_LITERAL_REASON_CLASS",
        "category": "EXACT_SOURCE_LITERAL",
        "reason_class_ordinal": ordinal,
        "reason_class_form": "DIRECT_LITERAL" if form == "D" else "CHILD_PREFIX_LITERAL",
        "reason_table_sha256": binding.reason_table_sha256,
        "authority": False,
    }


def _r23_parent_projection(
    original,
    adapter: Any,
    result: Any,
    prepared: Any,
    fallback: Any,
    binding: _ReasonBinding,
):
    """Retain R12 parsing and add R23 only after that exact projection passes."""
    safe = _R12._R11._R6._safe_to_read_phase(result)
    raw = getattr(result, "stderr", None) if safe else None
    if type(raw) is not bytes:
        return original(adapter, result, prepared, fallback)
    maximum = (
        _R12._R11._R6.MAX_PHASE_FRAME_BYTES
        + _R12._R11._R8.PHASE_MAX_BYTES
        + _R12._R11.R11_FRAME_MAX_BYTES
        + _R12.R12_FRAME_MAX_BYTES
        + R23_FRAME_MAX_BYTES
    )
    if len(raw) > maximum or not raw.endswith(b"\n"):
        return original(adapter, result, prepared, fallback)
    lines = raw.splitlines(keepends=True)
    expected_prefixes = (
        _R12._R11._R6.PHASE_PREFIX,
        _R12._R11._R8.PHASE_PREFIX,
        _R12._R11.R11_FRAME_PREFIX,
        _R12.R12_FRAME_PREFIX,
    )
    if len(lines) != 5 or any(not line.startswith(prefix) for line, prefix in zip(lines[:4], expected_prefixes)):
        return original(adapter, result, prepared, fallback)
    try:
        r12_result = dataclasses.replace(result, stderr=b"".join(lines[:4]))
    except BaseException:
        return original(adapter, result, prepared, fallback)
    projected = original(adapter, r12_result, prepared, fallback)
    try:
        child_phase = dict(projected.child_phase)
        returned = child_phase.get("returned_result")
    except BaseException:
        return projected
    if (
        type(returned) is not dict
        or returned.get("status") != "OBSERVED_FIXED_RETURNED_RESULT"
        or type(child_phase.get("outer_reason_result")) is not dict
        or child_phase["outer_reason_result"].get("status") != "OBSERVED_FIXED_REASON_ORDINAL"
    ):
        try:
            return dataclasses.replace(projected, stderr_bytes=len(raw))
        except BaseException:
            return projected
    class_result = _parse_reason_class_frame(lines[4], binding)
    if class_result["status"] == "UNOBSERVED":
        try:
            return dataclasses.replace(projected, stderr_bytes=len(raw))
        except BaseException:
            return projected
    updated = dict(returned)
    updated["reason_class_schema"] = R23_CLASS_SCHEMA
    updated["reason_class_status"] = class_result["status"]
    updated["reason_class_category"] = class_result["category"]
    updated["reason_class_ordinal"] = class_result["reason_class_ordinal"]
    updated["reason_class_form"] = class_result["reason_class_form"]
    updated["reason_class_table_sha256"] = binding.reason_table_sha256
    child_phase["returned_result"] = updated
    child_phase["reason_class_result"] = class_result
    try:
        return dataclasses.replace(projected, child_phase=child_phase, stderr_bytes=len(raw))
    except BaseException:
        return projected


class R23ParentAdapter:
    """One-use R22 adapter wrapper that parses the separate R23 frame."""

    def __init__(self, base_adapter: Any, prepared_hold: R23RootPreparedHold) -> None:
        self._base_adapter = base_adapter
        self._prepared_hold = prepared_hold
        self._used_lock = threading.Lock()
        self._used = False

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        _check(verify_root_hold(self._prepared_hold), "r23_prepared_binding")
        with self._used_lock:
            _check(self._used is False, "r23_adapter_binding")
            self._used = True
        if not _PATCH_LOCK.acquire(blocking=False):
            raise ChildReasonClassR23Blocked("r23_patch_context_busy")
        global _PATCH_OWNER_THREAD
        owner = threading.get_ident()
        original = _R12._parent_projection
        installed = False
        intact = True
        try:
            _check(
                _PATCH_OWNER_THREAD is None and original is _ORIGINAL_PARENT_PROJECTION,
                "r23_patch_context_changed",
            )
            _PATCH_OWNER_THREAD = owner
            binding = _binding_from_prepared(self._prepared_hold.prepared_r13, _self_source())

            def projection_wrapper(adapter, result, prepared, fallback):
                _check(
                    threading.get_ident() == owner
                    and _PATCH_OWNER_THREAD == owner
                    and _R12._parent_projection is projection_wrapper,
                    "r23_patch_owner_thread",
                )
                return _r23_parent_projection(
                    original, adapter, result, prepared, fallback, binding
                )

            _R12._parent_projection = projection_wrapper
            installed = True
            return self._base_adapter.supervise(source_scope, release_source_scope, **kwargs)
        finally:
            if installed:
                intact = _R12._parent_projection is projection_wrapper
                _R12._parent_projection = original
            _PATCH_OWNER_THREAD = None
            _PATCH_LOCK.release()
            if not intact:
                raise ChildReasonClassR23Blocked("r23_patch_context_changed")

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._base_adapter.summarize_result(result)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._base_adapter, name)


@dataclasses.dataclass(frozen=True)
class R23ParentAdapterResult:
    """R22 adapter plus R23's separate source row and class projection."""

    schema: str
    prepared_hold: R23RootPreparedHold
    r22_adapter_result: Any
    adapter: R23ParentAdapter
    r23_helper_path: str
    r23_helper_bytes: bytes
    r23_helper_sha256: str
    reason_binding: _ReasonBinding
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    r13_recompose_calls: int
    r13_outer_transform_calls: int
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False


def construct_parent_adapter(
    prepared_hold: Any,
    *,
    adapter_kwargs: Optional[dict[str, Any]] = None,
) -> R23ParentAdapterResult:
    source = _self_source()
    _check(verify_root_hold(prepared_hold), "r23_prepared_binding")
    try:
        with _compose_patch(source):
            r22_adapter_result = _R22.construct_parent_adapter(
                prepared_hold.r22_result, adapter_kwargs=adapter_kwargs
            )
            binding = _binding_from_prepared(r22_adapter_result.prepared_r13, source)
            addition, digest = _add_r23_row(r22_adapter_result.hold_addition, source)
    except ChildReasonClassR23Blocked:
        raise
    except BaseException:
        raise ChildReasonClassR23Blocked("r23_adapter_binding") from None
    _check(_self_source() == source, "r23_source_pin")
    adapter = R23ParentAdapter(r22_adapter_result.adapter, prepared_hold)
    result = R23ParentAdapterResult(
        schema=R23_ADAPTER_SCHEMA,
        prepared_hold=prepared_hold,
        r22_adapter_result=r22_adapter_result,
        adapter=adapter,
        r23_helper_path=source[0],
        r23_helper_bytes=source[1],
        r23_helper_sha256=source[2],
        reason_binding=binding,
        hold_addition=addition,
        hold_addition_sha256=digest,
        r13_recompose_calls=r22_adapter_result.r13_recompose_calls,
        r13_outer_transform_calls=r22_adapter_result.r13_outer_transform_calls,
    )
    _check(verify_parent_adapter_result(result), "r23_adapter_binding")
    return result


def verify_parent_adapter_result(value: Any) -> bool:
    try:
        if type(value) is not R23ParentAdapterResult or value.schema != R23_ADAPTER_SCHEMA:
            return False
        if not verify_root_hold(value.prepared_hold):
            return False
        source = _self_source()
        if (value.r23_helper_path, value.r23_helper_bytes, value.r23_helper_sha256) != source:
            return False
        binding = _binding_from_prepared(value.prepared_hold.prepared_r13, source)
        if value.reason_binding != binding or value.r13_recompose_calls != 1 or value.r13_outer_transform_calls != 1:
            return False
        with _compose_patch(source):
            if not _R22.verify_parent_adapter_result(value.r22_adapter_result):
                return False
        if value.adapter._base_adapter is not value.r22_adapter_result.adapter:
            return False
        addition, digest = _add_r23_row(value.r22_adapter_result.hold_addition, source)
        return value.hold_addition == addition and value.hold_addition_sha256 == digest
    except BaseException:
        return False


def classify_reason(reason: Any, binding: _ReasonBinding) -> dict[str, Any]:
    """Pure finite projection used by source fakes and the embedded observer."""
    if (
        type(reason) is not str
        or not 1 <= len(reason) <= 96
        or any(character not in "abcdefghijklmnopqrstuvwxyz0123456789_" for character in reason)
    ):
        ordinal, form = 0, "UNKNOWN"
    elif reason in binding.reason_table:
        ordinal = binding.reason_table.index(reason) + 1
        form = "DIRECT_LITERAL"
    elif reason.startswith(binding.reason_prefix):
        suffix = reason[len(binding.reason_prefix) :]
        if suffix in binding.reason_table:
            ordinal = binding.reason_table.index(suffix) + 1
            form = "CHILD_PREFIX_LITERAL"
        else:
            ordinal, form = 0, "UNKNOWN"
    else:
        ordinal, form = 0, "UNKNOWN"
    if ordinal == 0:
        status, category = "OBSERVED_UNKNOWN_REASON_CLASS", "UNKNOWN"
    else:
        status, category = "OBSERVED_SOURCE_LITERAL_REASON_CLASS", "EXACT_SOURCE_LITERAL"
    return {
        "schema": R23_CLASS_SCHEMA,
        "status": status,
        "category": category,
        "reason_class_ordinal": ordinal,
        "reason_class_form": form,
        "reason_table_sha256": binding.reason_table_sha256,
        "authority": False,
    }


if __name__ == "__main__":
    raise SystemExit("Use prepare_root_hold() and hold the exact R23 addition.")
