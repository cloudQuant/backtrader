"""Add a source-bound ordinal for the frozen R28 outer reason field.

R12 composes a versioned sidecar from exact R11 prepared bytes. It binds a
small table of literal reasons extracted from the same generated R31-to-R10
active outer source, and reports only an ordinal (zero means UNKNOWN). The
ordinary R11 result, the R28 validators, and all supervision deadlines remain
unchanged.
"""

from __future__ import annotations

import ast
import dataclasses
import hashlib
import json
import re
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_returned_result_observer_r11_r1 as _R11


R11_FILENAME = "iteration41_okx_m01_r33_returned_result_observer_r11_r1.py"
R11_SHA256 = "b141a62f9d8578d5e24f86b6b7f42320d79da1ea2d7fa591d4ddaff2bce3fa48"
R12_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_outer_reason_ordinal_observer_r12_r2.py"
R12_RESULT_SCHEMA = "iteration41.okx.m01.r33.outer-reason-ordinal-observation.r12.r2.v1"
R12_BINDING_SCHEMA = "iteration41.okx.m01.r33.prepared-child-binding.r12.r2.outer-reason.v1"
R12_HOLD_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition.r12.r2.outer-reason.v1"
R12_REASON_TABLE_SCHEMA = "iteration41.okx.m01.r33.outer-reason-literal-table.r12.v1"
R12_SIDECAR_ROLE = "r12_outer_reason_ordinal_bootstrap_sidecar"
R12_SOURCE_ROLE = "r12_outer_reason_ordinal_observer_source"
R12_FRAME_PREFIX = b"M01R12:"
R12_FRAME_MAX_BYTES = 16
R12_UNKNOWN_ORDINAL = 0
R12_MAX_REASON_LITERALS = 0xFFFF

_R12_RESULT_CALL_ANCHOR = b"        _r11_emit_returned_result_frame(phase_sink, safe_result, runner)\n"
_R12_RESULT_WRITE_ANCHOR = b"        _r11_write_pending_returned_result_frame(phase_sink)\n"
_MAIN_GUARD = b'\nif __name__ == "__main__":\n'
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_SAFE_REASON = re.compile(r"[a-z0-9_]{1,96}\Z")
_EXPECTED_PREFLIGHT_STAGES = frozenset(
    {
        "setup",
        "imports",
        "interpreter_guard",
        "public_source",
        "package_metadata",
        "review",
        "activation",
        "protected_setup",
    }
)


class OuterReasonOrdinalBlocked(ValueError):
    """A source, prepared binding, or finite reason frame failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _check(value: Any, reason: str) -> None:
    if not value:
        raise OuterReasonOrdinalBlocked(reason)


def _bounded_file(path: Path, expected_name: str, maximum: int) -> bytes:
    _check(path.name == expected_name, "source_filename")
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise OuterReasonOrdinalBlocked("source_read") from None
    _check(type(raw) is bytes and 0 < len(raw) <= maximum, "source_size")
    return raw


def _repo_root() -> Path:
    root = Path(_R11.__file__).resolve().parents[1]
    expected = (root / Path(*R12_RELATIVE_PATH.split("/"))).resolve()
    _check(expected == Path(__file__).resolve(), "r12_module_path")
    return root


def _self_source() -> tuple[str, bytes, str]:
    _check(__name__ == R12_RELATIVE_PATH[:-3].replace("/", "."), "r12_module_name")
    path = Path(__file__).resolve()
    _check(path == (_repo_root() / Path(*R12_RELATIVE_PATH.split("/"))).resolve(), "r12_source_path")
    raw = _bounded_file(path, R12_RELATIVE_PATH.rsplit("/", 1)[-1], 2 * 1024 * 1024)
    return str(path), raw, _sha(raw)


def _pinned_r11_source() -> tuple[str, bytes, str]:
    _check(
        getattr(_R11, "__name__", None)
        == "scripts.iteration41_okx_m01_r33_returned_result_observer_r11_r1",
        "r11_module_name",
    )
    path = Path(getattr(_R11, "__file__", "")).resolve()
    _check(path.name == R11_FILENAME, "r11_filename")
    raw = _bounded_file(path, R11_FILENAME, 2 * 1024 * 1024)
    _check(_sha(raw) == R11_SHA256, "r11_digest")
    return str(path), raw, R11_SHA256


def _literal_string_collection(node: ast.AST) -> tuple[str, ...] | None:
    value = node
    if (
        isinstance(value, ast.Call)
        and isinstance(value.func, ast.Name)
        and value.func.id in {"frozenset", "set"}
        and not value.keywords
        and len(value.args) == 1
    ):
        value = value.args[0]
    if not isinstance(value, (ast.Set, ast.List, ast.Tuple)):
        return None
    strings = []
    for item in value.elts:
        if not isinstance(item, ast.Constant) or type(item.value) is not str:
            return None
        strings.append(item.value)
    if len(strings) != len(set(strings)):
        return None
    return tuple(strings)


def _reason_lookup(node: ast.AST) -> bool:
    if (
        isinstance(node, ast.Subscript)
        and isinstance(node.value, ast.Name)
        and node.value.id == "doc"
        and isinstance(node.slice, ast.Constant)
        and node.slice.value == "reason"
    ):
        return True
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "doc"
        and node.func.attr == "get"
        and bool(node.args)
        and isinstance(node.args[0], ast.Constant)
        and node.args[0].value == "reason"
        and not node.keywords
    )


def _active_outer_reason_literals(active_outer: bytes) -> tuple[str, ...]:
    """Extract only fixed reason literals from the generated outer contract."""
    _check(type(active_outer) is bytes and 0 < len(active_outer) <= 2 * 1024 * 1024, "outer_source_size")
    try:
        tree = ast.parse(active_outer)
    except (SyntaxError, ValueError, UnicodeDecodeError):
        raise OuterReasonOrdinalBlocked("outer_source_parse") from None

    assignments: dict[str, list[ast.AST]] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    assignments.setdefault(target.id, []).append(node.value)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            assignments.setdefault(node.target.id, []).append(node.value)

    stages_values = assignments.get("R28_PREFLIGHT_STAGES", [])
    _check(len(stages_values) == 1, "preflight_stage_table_shape")
    stages = _literal_string_collection(stages_values[0])
    _check(stages is not None and frozenset(stages) == _EXPECTED_PREFLIGHT_STAGES, "preflight_stage_table_binding")

    shape_functions = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and node.name == "_safe_child_projection"
    ]
    main_functions = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "main"
    ]
    _check(len(shape_functions) == 1 and len(main_functions) == 1, "outer_result_shape_functions")
    literals: set[str] = set()
    # Collect only exact literal reason sources in the pinned generated outer:
    # direct _check/PrelaunchBlocked codes, reason-field literals, and reason
    # assignments. Dynamic child reasons and regex/prefix acceptors are not
    # expanded; they necessarily resolve to UNKNOWN.
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id == "PrelaunchBlocked" and node.args:
                value = node.args[0]
                if isinstance(value, ast.Constant) and type(value.value) is str:
                    literals.add(value.value)
            elif node.func.id == "_check" and len(node.args) >= 2:
                value = node.args[1]
                if isinstance(value, ast.Constant) and type(value.value) is str:
                    literals.add(value.value)
        if isinstance(node, ast.Call):
            for keyword in node.keywords:
                if keyword.arg == "reason" and isinstance(keyword.value, ast.Constant) and type(keyword.value.value) is str:
                    literals.add(keyword.value.value)
        if isinstance(node, ast.Dict):
            for key, value in zip(node.keys, node.values):
                if (
                    isinstance(key, ast.Constant)
                    and key.value == "reason"
                    and isinstance(value, ast.Constant)
                    and type(value.value) is str
                ):
                    literals.add(value.value)
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(target, ast.Name) and target.id == "reason" for target in targets):
                value = node.value
                if isinstance(value, ast.Constant) and type(value.value) is str:
                    literals.add(value.value)
        if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq):
            if len(node.comparators) == 1:
                left, right = node.left, node.comparators[0]
                if _reason_lookup(left) and isinstance(right, ast.Constant) and type(right.value) is str:
                    literals.add(right.value)
                elif _reason_lookup(right) and isinstance(left, ast.Constant) and type(left.value) is str:
                    literals.add(left.value)

    # These fixed result branches are also declared directly by the generated
    # outer validator. FAILED/BLOCKED dynamic values and prefixes are omitted.
    literals.update(
        {
            "root_prelaunch_unset",
            "root_child_case_predicate_satisfied",
            *(
                "root_child_root_wrapper_preflight_"
                + stage
                + "_unexpected_failure"
                for stage in stages
            ),
        }
    )

    _check(all(_SAFE_REASON.fullmatch(item) is not None for item in literals), "outer_reason_literal_shape")
    table = tuple(sorted(literals))
    _check(0 < len(table) <= R12_MAX_REASON_LITERALS, "outer_reason_table_size")
    _check("root_prelaunch_unset" in table and "root_child_case_predicate_satisfied" in table, "outer_reason_fixed_literals")
    return table


def _outer_material(r10_prepared: Any) -> dict[str, Any]:
    """Rebuild the exact active outer through frozen R31 and R10 source helpers."""
    r10 = _R11._R10
    r9 = _R11._R9
    r10._validate_prepared(r10_prepared)
    descriptor = r9._R4._validate_descriptor(r10_prepared.descriptor_json)
    base_descriptor = r9._R4._validate_descriptor(r10_prepared.r9_prepared.descriptor_json)
    source_map = r9._R4._validate_source_map(r10_prepared.source_map_bytes, descriptor)
    base_source_map = r9._R4._validate_source_map(
        r10_prepared.r9_prepared.source_map_bytes, base_descriptor
    )
    _check(
        source_map.get("plan_sha256") == base_source_map.get("plan_sha256"),
        "outer_plan_lineage_binding",
    )
    # R10's final runner manifest pins the transformed outer. R31 generation
    # must use its preserved R9/base runner manifest, exactly as R10._compose
    # did, before applying the one fixed R10 gate replacement.
    base_manifest = r10._manifest_from_runner(r10_prepared.r9_prepared.runner_bytes)
    manifest = r10._manifest_from_runner(r10_prepared.runner_bytes)
    base_outer, active_wrapper = r10._r31_active_outputs(base_manifest, base_source_map)
    active_outer = r10._r10_active_outer_source(
        base_outer,
        active_wrapper,
        base_manifest,
        base_source_map["plan_sha256"],
        r10_prepared.external_parent_sources,
    )
    namespace = manifest.get("runtime_namespace")
    candidate = manifest.get("candidate")
    _check(type(namespace) is dict and type(candidate) is dict, "outer_manifest_shape")
    active_outer_path = namespace.get("self_path")
    active_wrapper_path = namespace.get("active_wrapper_path")
    plan_path = namespace.get("plan_path")
    plan_sha256 = source_map.get("plan_sha256")
    active_outer_sha256 = _sha(active_outer)
    active_wrapper_sha256 = _sha(active_wrapper)
    _check(
        type(active_outer_path) is str
        and type(active_wrapper_path) is str
        and type(plan_path) is str
        and type(plan_sha256) is str
        and _HEX64.fullmatch(plan_sha256) is not None
        and candidate.get("active_outer_sha256") == active_outer_sha256
        and candidate.get("active_wrapper_sha256") == active_wrapper_sha256,
        "outer_output_pin_binding",
    )
    plan_matches = [
        digest
        for path, digest in manifest.get("software_pins", {}).items()
        if type(path) is str and r9._normalized(path) == r9._normalized(plan_path)
    ]
    _check(plan_matches == [plan_sha256], "outer_plan_pin_binding")
    source_pins = source_map.get("canonical_pins")
    _check(type(source_pins) is dict, "outer_source_map_pins_shape")
    outer_matches = [
        digest
        for path, digest in source_pins.items()
        if type(path) is str and r9._normalized(path) == r9._normalized(active_outer_path)
    ]
    wrapper_matches = [
        digest
        for path, digest in source_pins.items()
        if type(path) is str and r9._normalized(path) == r9._normalized(active_wrapper_path)
    ]
    _check(
        outer_matches == [active_outer_sha256] and wrapper_matches == [active_wrapper_sha256],
        "outer_source_map_output_binding",
    )
    return {
        "active_outer": active_outer,
        "active_outer_path": active_outer_path,
        "active_outer_sha256": active_outer_sha256,
        "active_wrapper_path": active_wrapper_path,
        "active_wrapper_sha256": active_wrapper_sha256,
        "plan_path": plan_path,
        "plan_sha256": plan_sha256,
        "source_map_sha256": _sha(r10_prepared.source_map_bytes),
        "namespace": dict(namespace),
    }


def _reason_table_digest(table: tuple[str, ...], outer: dict[str, Any]) -> str:
    payload = {
        "schema": R12_REASON_TABLE_SCHEMA,
        "active_outer_path": outer["active_outer_path"],
        "active_outer_sha256": outer["active_outer_sha256"],
        "active_wrapper_path": outer["active_wrapper_path"],
        "active_wrapper_sha256": outer["active_wrapper_sha256"],
        "plan_path": outer["plan_path"],
        "plan_sha256": outer["plan_sha256"],
        "source_map_sha256": outer["source_map_sha256"],
        "reason_literals": list(table),
    }
    return _sha(_canonical_json(payload))


_R12_OBSERVER_SOURCE = r'''
R12_REASON_TABLE = __R12_REASON_TABLE__
R12_REASON_TABLE_SHA256 = __R12_REASON_TABLE_SHA256__
R12_ACTIVE_OUTER_SHA256 = __R12_ACTIVE_OUTER_SHA256__
R12_ACTIVE_WRAPPER_SHA256 = __R12_ACTIVE_WRAPPER_SHA256__
R12_PLAN_SHA256 = __R12_PLAN_SHA256__
R12_SOURCE_MAP_SHA256 = __R12_SOURCE_MAP_SHA256__
R12_REASON_UNKNOWN = 0


def _r12_is_hex64(value):
    return (
        type(value) is str
        and len(value) == 64
        and all(char in "0123456789abcdef" for char in value)
    )


def _r12_emit_outer_reason_ordinal_frame(phase_sink, safe_result, runner):
    """Encode an exact literal match, or UNKNOWN, after the real safe-result gate."""
    if type(safe_result) is not dict:
        return
    validator = getattr(runner, "_safe_result", None)
    if not callable(validator):
        return
    try:
        if validator(safe_result) is not safe_result:
            return
    except BaseException:
        return
    if safe_result.get("disposition") != "OUTER_CAPTURED" or safe_result.get("parse_allowed") is not False:
        return
    manifest = getattr(runner, "MANIFEST", None)
    candidate = manifest.get("candidate") if type(manifest) is dict else None
    namespace = manifest.get("runtime_namespace") if type(manifest) is dict else None
    software_pins = manifest.get("software_pins") if type(manifest) is dict else None
    once = manifest.get("once") if type(manifest) is dict else None
    canonical_path = getattr(runner, "_canonical", None)
    try:
        plan_key = canonical_path(namespace.get("plan_path")) if type(namespace) is dict and callable(canonical_path) else None
    except BaseException:
        plan_key = None
    if (
        type(candidate) is not dict
        or candidate.get("active_outer_sha256") != R12_ACTIVE_OUTER_SHA256
        or candidate.get("active_wrapper_sha256") != R12_ACTIVE_WRAPPER_SHA256
        or type(namespace) is not dict
        or type(namespace.get("plan_path")) is not str
        or type(software_pins) is not dict
        or type(plan_key) is not str
        or software_pins.get(plan_key) != R12_PLAN_SHA256
        or type(once) is not dict
        or type(once.get("result_schema")) is not str
        or safe_result.get("schema") != once.get("result_schema")
        or type(R12_REASON_TABLE) is not tuple
        or not R12_REASON_TABLE
        or len(R12_REASON_TABLE) > 0xFFFF
        or any(type(reason) is not str for reason in R12_REASON_TABLE)
        or tuple(sorted(set(R12_REASON_TABLE))) != R12_REASON_TABLE
        or not _r12_is_hex64(R12_REASON_TABLE_SHA256)
        or not _r12_is_hex64(R12_SOURCE_MAP_SHA256)
        or not _r12_is_hex64(R12_PLAN_SHA256)
    ):
        return
    projection = safe_result.get("projection")
    if type(projection) is not dict or set(projection) != {"outer_status", "outer_reason", "outer_route_invocations"}:
        return
    reason = projection.get("outer_reason")
    if type(reason) is not str:
        return
    try:
        ordinal = R12_REASON_TABLE.index(reason) + 1
    except ValueError:
        ordinal = R12_REASON_UNKNOWN
    if not 0 <= ordinal <= 0xFFFF:
        return
    body = ("O%04x" % ordinal).encode("ascii")
    frame = b"M01R12:" + body + b"\n"
    if len(frame) != 13 or len(frame) > 16:
        return
    if getattr(phase_sink, "_closed", False) is not False or getattr(phase_sink, "_broken", True) is not False:
        return
    if getattr(phase_sink, "_stream", None) is None:
        return
    try:
        phase_sink._r12_outer_reason_frame = frame
    except BaseException:
        return


def _r12_write_pending_outer_reason_ordinal_frame(phase_sink):
    frame = getattr(phase_sink, "_r12_outer_reason_frame", None)
    if (
        type(frame) is not bytes
        or len(frame) != 13
        or len(frame) > 16
        or getattr(phase_sink, "_closed", False) is not True
        or getattr(phase_sink, "_broken", True) is not False
    ):
        return
    stream = getattr(phase_sink, "_stream", None)
    if stream is None:
        return
    try:
        written = stream.write(frame)
        if type(written) is int and written != len(frame):
            phase_sink._broken = True
            return
        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()
    except BaseException:
        try:
            phase_sink._broken = True
        except BaseException:
            return
'''.lstrip()


def _compose_bootstrap(r11_raw: bytes, table: tuple[str, ...], outer: dict[str, Any]) -> bytes:
    _check(type(r11_raw) is bytes and 0 < len(r11_raw) <= _R11._R9.MAX_BOOTSTRAP_BYTES, "r11_bootstrap_size")
    _check(r11_raw.count(_R12_RESULT_CALL_ANCHOR) == 1, "r11_result_anchor")
    _check(r11_raw.count(_R12_RESULT_WRITE_ANCHOR) == 1, "r11_result_write_anchor")
    _check(r11_raw.count(_MAIN_GUARD) == 1, "main_guard_anchor")
    table_sha256 = _reason_table_digest(table, outer)
    source = r11_raw.replace(
        _R12_RESULT_CALL_ANCHOR,
        _R12_RESULT_CALL_ANCHOR
        + b"        _r12_emit_outer_reason_ordinal_frame(phase_sink, safe_result, runner)\n",
        1,
    )
    source = source.replace(
        _R12_RESULT_WRITE_ANCHOR,
        _R12_RESULT_WRITE_ANCHOR
        + b"        _r12_write_pending_outer_reason_ordinal_frame(phase_sink)\n",
        1,
    )
    observer = _R12_OBSERVER_SOURCE.encode("ascii")
    substitutions = {
        b"__R12_REASON_TABLE__": repr(table).encode("ascii"),
        b"__R12_REASON_TABLE_SHA256__": repr(table_sha256).encode("ascii"),
        b"__R12_ACTIVE_OUTER_SHA256__": repr(outer["active_outer_sha256"]).encode("ascii"),
        b"__R12_ACTIVE_WRAPPER_SHA256__": repr(outer["active_wrapper_sha256"]).encode("ascii"),
        b"__R12_PLAN_SHA256__": repr(outer["plan_sha256"]).encode("ascii"),
        b"__R12_SOURCE_MAP_SHA256__": repr(outer["source_map_sha256"]).encode("ascii"),
    }
    for marker, replacement in substitutions.items():
        _check(observer.count(marker) == 1, "r12_observer_anchor")
        observer = observer.replace(marker, replacement, 1)
    source = source.replace(_MAIN_GUARD, b"\n" + observer + _MAIN_GUARD, 1)
    _check(len(source) <= _R11._R9.MAX_BOOTSTRAP_BYTES, "r12_bootstrap_size")
    try:
        compile(source, "<m01-r12-r2-composed-bootstrap>", "exec", dont_inherit=True)
    except BaseException:
        raise OuterReasonOrdinalBlocked("r12_bootstrap_compile") from None
    return source


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R12 sidecar and reason table bound to one exact R11/R10 preparation."""

    r11_prepared: Any
    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    descriptor_json: bytes
    stdin_descriptor: bytes
    runner_bytes: bytes
    bootstrap_bytes: bytes
    stub_bytes: bytes
    sidecar_path: str
    sidecar_sha256: str
    sidecar_size_bytes: int
    helper_path: str
    helper_bytes: bytes
    helper_sha256: str
    r11_dependency: tuple[str, bytes, str]
    reason_table: tuple[str, ...]
    reason_table_sha256: str
    outer_binding: dict[str, Any]
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str
    windows_command_line_units: int

    @property
    def sidecar_bytes(self) -> bytes:
        return self.bootstrap_bytes

    @property
    def r10_prepared(self) -> Any:
        return self.r11_prepared.r10_prepared

    def __getattr__(self, name: str) -> Any:
        return getattr(self.r11_prepared, name)


def _compose(prepared_r11: Any) -> PreparedM01Child:
    _R11._validate_prepared(prepared_r11)
    outer = _outer_material(prepared_r11.r10_prepared)
    table = _active_outer_reason_literals(outer["active_outer"])
    table_sha256 = _reason_table_digest(table, outer)
    bootstrap = _compose_bootstrap(prepared_r11.bootstrap_bytes, table, outer)
    descriptor = _R11._R9._R4._validate_descriptor(prepared_r11.descriptor_json)
    descriptor_sha256 = _sha(prepared_r11.descriptor_json)
    sidecar_path = _R11._R9._sidecar_path(
        descriptor["runtime_namespace"]["deployment_dir"], _sha(bootstrap)
    )
    stub = _R11._R9._stub_source(
        sidecar_path=sidecar_path,
        bootstrap_size=len(bootstrap),
        bootstrap_sha256=_sha(bootstrap),
        descriptor_size=len(prepared_r11.descriptor_json),
        descriptor_sha256=descriptor_sha256,
    )
    stdin_descriptor = _R11._R9._wire_prefix(bootstrap) + prepared_r11.descriptor_json
    _check(len(stdin_descriptor) <= _R11._R9.MAX_STDIN_BYTES, "stdin_transport_limit")
    command = tuple(prepared_r11.command[:7]) + (stub.decode("utf-8"),)
    command_units = _R11._R9._command_line_units(command)
    _check(command_units <= _R11._R9.MAX_COMMAND_LINE_UNITS, "command_line_limit")
    helper_path, helper_bytes, helper_sha256 = _self_source()
    r11_path, r11_bytes, r11_sha256 = _pinned_r11_source()
    _check(r11_bytes == prepared_r11.helper_bytes and r11_sha256 == prepared_r11.helper_sha256, "r11_prepared_source_binding")

    binding = dict(prepared_r11.binding)
    binding.update(
        {
            "schema": R12_BINDING_SCHEMA,
            "result_observer_schema": R12_RESULT_SCHEMA,
            "result_observer_prefix": R12_FRAME_PREFIX.decode("ascii"),
            "result_observer_max_bytes": R12_FRAME_MAX_BYTES,
            "r11_binding_sha256": prepared_r11.binding_sha256,
            "r11_sidecar_path": prepared_r11.sidecar_path,
            "r11_sidecar_sha256": prepared_r11.sidecar_sha256,
            "r11_sidecar_size_bytes": prepared_r11.sidecar_size_bytes,
            "r12_sidecar_path": sidecar_path,
            "r12_sidecar_sha256": _sha(bootstrap),
            "r12_sidecar_size_bytes": len(bootstrap),
            "r12_helper_path": helper_path,
            "r12_helper_sha256": helper_sha256,
            "r12_helper_size_bytes": len(helper_bytes),
            "r12_r11_dependency": {
                "path": r11_path,
                "sha256": r11_sha256,
                "size_bytes": len(r11_bytes),
                "role": "r12_exact_r11_runtime_dependency",
            },
            "r12_reason_table_schema": R12_REASON_TABLE_SCHEMA,
            "r12_reason_table_sha256": table_sha256,
            "r12_reason_table_count": len(table),
            "r12_reason_table_literals": list(table),
            "r12_outer_source_binding": {
                **outer,
                "active_outer": None,
                "namespace": dict(outer["namespace"]),
            },
            "windows_command_line_utf16_units_including_nul": command_units,
            "windows_command_line_limit_utf16_units_including_nul": _R11._R9.MAX_COMMAND_LINE_UNITS,
            "canonical_child_map_counts": {"public": 118, "software": 36, "canonical": 154},
            "authority": False,
            "strict_cases_passed": 0,
            "case_result": False,
        }
    )
    binding["r12_outer_source_binding"].pop("namespace", None)
    binding_sha256 = _R11._R6._canonical_binding_digest(binding, command, prepared_r11.cwd)
    outer_binding = {
        key: value
        for key, value in outer.items()
        if key != "active_outer"
    }
    return PreparedM01Child(
        r11_prepared=prepared_r11,
        command=command,
        cwd=prepared_r11.cwd,
        environment=dict(prepared_r11.environment),
        descriptor_json=prepared_r11.descriptor_json,
        stdin_descriptor=stdin_descriptor,
        runner_bytes=prepared_r11.runner_bytes,
        bootstrap_bytes=bootstrap,
        stub_bytes=stub,
        sidecar_path=sidecar_path,
        sidecar_sha256=_sha(bootstrap),
        sidecar_size_bytes=len(bootstrap),
        helper_path=helper_path,
        helper_bytes=helper_bytes,
        helper_sha256=helper_sha256,
        r11_dependency=(r11_path, r11_bytes, r11_sha256),
        reason_table=table,
        reason_table_sha256=table_sha256,
        outer_binding=outer_binding,
        binding=binding,
        binding_sha256=binding_sha256,
        plan_disposition=prepared_r11.plan_disposition,
        windows_command_line_units=command_units,
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Prepare the R12 successor through exact R11/R10 public composition."""
    try:
        prepared_r11 = _R11.prepare_r33_child(
            prepared_r31, root_metadata, environment=environment
        )
    except BaseException:
        raise OuterReasonOrdinalBlocked("r11_prepare_rejected") from None
    return prepare_from_r11(prepared_r11)


def prepare_from_r11(prepared_r11: Any) -> PreparedM01Child:
    return _compose(prepared_r11)


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "prepared_type")
    try:
        expected = _compose(value.r11_prepared)
    except BaseException:
        raise OuterReasonOrdinalBlocked("prepared_source") from None
    _check(value == expected, "prepared_binding")


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    """Return the exact R11 closure plus R12 sidecar/helper and table binding."""
    _validate_prepared(prepared)
    base = _R11.parent_hold_addition(prepared.r11_prepared)
    entries = dict(base["entries"])
    r11_path, r11_raw, r11_digest = prepared.r11_dependency
    r12_additions = (
        (
            prepared.sidecar_path,
            prepared.bootstrap_bytes,
            prepared.sidecar_sha256,
            R12_SIDECAR_ROLE,
            "generated_from_exact_r11_sidecar:" + prepared.r11_prepared.sidecar_sha256,
        ),
        (
            prepared.helper_path,
            prepared.helper_bytes,
            prepared.helper_sha256,
            R12_SOURCE_ROLE,
            "repository_source:" + R12_RELATIVE_PATH,
        ),
    )
    normalized = {_R11._R9._normalized(path) for path in entries}
    for path, raw, digest, role, origin in r12_additions:
        _check(_R11._R9._absolute_windows_path(path), "r12_hold_path")
        _check(type(raw) is bytes and _sha(raw) == digest, "r12_hold_digest")
        key = _R11._R9._normalized(path)
        _check(key not in normalized, "r12_hold_collision")
        normalized.add(key)
        entries[path] = {
            "sha256": digest,
            "size_bytes": len(raw),
            "role": role,
            "origin": origin,
        }
    _check(
        _R11._R9._normalized(r11_path) in normalized
        and _sha(r11_raw) == r11_digest == R11_SHA256,
        "r12_r11_hold_binding",
    )
    existing_r11 = [
        entry
        for path, entry in entries.items()
        if _R11._R9._normalized(path) == _R11._R9._normalized(r11_path)
    ]
    _check(
        len(existing_r11) == 1
        and existing_r11[0].get("sha256") == r11_digest
        and existing_r11[0].get("size_bytes") == len(r11_raw),
        "r12_r11_hold_entry",
    )
    return {
        "schema": R12_HOLD_SCHEMA,
        "binding_sha256": prepared.binding_sha256,
        "r11_binding_sha256": prepared.r11_prepared.binding_sha256,
        "entries": dict(sorted(entries.items())),
        "canonical_child_map_count": 154,
        "r11_sidecar_path": prepared.r11_prepared.sidecar_path,
        "r11_sidecar_sha256": prepared.r11_prepared.sidecar_sha256,
        "r12_sidecar_path": prepared.sidecar_path,
        "r12_sidecar_sha256": prepared.sidecar_sha256,
        "r12_sidecar_size_bytes": prepared.sidecar_size_bytes,
        "r12_helper_path": prepared.helper_path,
        "r12_helper_sha256": prepared.helper_sha256,
        "reason_table_schema": R12_REASON_TABLE_SCHEMA,
        "reason_table_sha256": prepared.reason_table_sha256,
        "reason_table_count": len(prepared.reason_table),
        "outer_binding": dict(prepared.outer_binding),
    }


def verify_parent_hold_addition(prepared: PreparedM01Child, value: Any) -> bool:
    try:
        return type(value) is dict and value == parent_hold_addition(prepared)
    except BaseException:
        return False


def _unobserved_outer_reason() -> dict[str, Any]:
    return {
        "schema": R12_RESULT_SCHEMA,
        "status": "UNOBSERVED",
        "category": "UNOBSERVED",
        "outer_reason_ordinal": None,
        "outer_reason_code": "UNOBSERVED",
        "reason_table_sha256": None,
        "authority": False,
    }


def _parse_outer_reason_frame(raw: Any, prepared: PreparedM01Child) -> dict[str, Any]:
    if (
        type(raw) is not bytes
        or len(raw) != 13
        or len(raw) > R12_FRAME_MAX_BYTES
        or not raw.startswith(R12_FRAME_PREFIX)
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
        or b"\r" in raw
    ):
        return _unobserved_outer_reason()
    body = raw[len(R12_FRAME_PREFIX) : -1]
    if len(body) != 5 or body[:1] != b"O" or re.fullmatch(rb"[0-9a-f]{4}", body[1:]) is None:
        return _unobserved_outer_reason()
    try:
        ordinal = int(body[1:], 16)
    except (TypeError, ValueError):
        return _unobserved_outer_reason()
    if ordinal != R12_UNKNOWN_ORDINAL and not 1 <= ordinal <= len(prepared.reason_table):
        return _unobserved_outer_reason()
    return {
        "schema": R12_RESULT_SCHEMA,
        "status": "OBSERVED_FIXED_REASON_ORDINAL",
        "category": "UNKNOWN" if ordinal == R12_UNKNOWN_ORDINAL else "EXACT_SOURCE_LITERAL",
        "outer_reason_ordinal": ordinal,
        "outer_reason_code": "UNKNOWN" if ordinal == R12_UNKNOWN_ORDINAL else "ORDINAL",
        "reason_table_sha256": prepared.reason_table_sha256,
        "authority": False,
    }


def _parent_projection(r8_adapter: Any, result: Any, prepared: PreparedM01Child, fallback: Any):
    """Read R12 only after the full R11/R6/R8 and parent lifecycle gates pass."""
    result_type = r8_adapter._r5._inner._r32.ParentEnvelopeResult
    if type(result) is not result_type or not _R11._R6._safe_to_read_phase(result):
        return fallback(result)
    raw = result.stderr
    maximum = (
        _R11._R6.MAX_PHASE_FRAME_BYTES
        + _R11._R8.PHASE_MAX_BYTES
        + _R11.R11_FRAME_MAX_BYTES
        + R12_FRAME_MAX_BYTES
    )
    if type(raw) is not bytes or len(raw) > maximum or not raw.endswith(b"\n"):
        return fallback(result)
    lines = raw.splitlines(keepends=True)
    if (
        len(lines) != 4
        or not lines[0].startswith(_R11._R6.PHASE_PREFIX)
        or not lines[1].startswith(_R11._R8.PHASE_PREFIX)
        or not lines[2].startswith(_R11.R11_FRAME_PREFIX)
        or not lines[3].startswith(R12_FRAME_PREFIX)
    ):
        return fallback(result)
    r11_raw = b"".join(lines[:3])
    try:
        r11_result = dataclasses.replace(result, stderr=r11_raw)
    except BaseException:
        return fallback(result)
    projected = _R11._parent_projection(
        r8_adapter,
        r11_result,
        prepared.runner_bytes,
        fallback,
    )
    try:
        child_phase = dict(projected.child_phase)
        returned = child_phase.get("returned_result")
        route_phase = child_phase.get("outer_route_phase")
        phase = child_phase.get("stage")
    except BaseException:
        return fallback(result)
    if (
        type(returned) is not dict
        or returned.get("status") != "OBSERVED_FIXED_RETURNED_RESULT"
        or type(route_phase) is not dict
        or route_phase.get("stage") != "COMPLETED"
        or route_phase.get("outer_response") != "RETURNED"
        or route_phase.get("parse_outer_response") != "RETURNED"
        or phase != "CHILD_CUV2_POSTVERIFY_REPORTED"
    ):
        return fallback(result)
    reason = _parse_outer_reason_frame(lines[3], prepared)
    if reason.get("status") != "OBSERVED_FIXED_REASON_ORDINAL":
        return fallback(result)
    updated = dict(returned)
    updated["schema"] = R12_RESULT_SCHEMA
    updated["outer_reason_ordinal"] = reason["outer_reason_ordinal"]
    updated["outer_reason_code"] = reason["outer_reason_code"]
    updated["outer_reason_category"] = reason["category"]
    updated["outer_reason_table_sha256"] = prepared.reason_table_sha256
    child_phase["returned_result"] = updated
    child_phase["outer_reason_result"] = reason
    # R11 receives a three-frame prefix so it can validate its protocol. Its
    # summary therefore counts that prefix. R12 must restore the byte count
    # from the original complete capture after the fourth frame is accepted.
    return dataclasses.replace(projected, child_phase=child_phase, stderr_bytes=len(raw))


class M01WindowsParentAdapter:
    """R11 supervision with one additional post-gate reason-ordinal frame."""

    def __init__(self, prepared_child: PreparedM01Child, **kwargs: Any):
        _validate_prepared(prepared_child)
        self.prepared = prepared_child
        self._r11 = _R11.M01WindowsParentAdapter(prepared_child.r11_prepared, **kwargs)
        runtime_view = dataclasses.replace(
            prepared_child.r11_prepared,
            command=prepared_child.command,
            stdin_descriptor=prepared_child.stdin_descriptor,
            stub_bytes=prepared_child.stub_bytes,
            sidecar_path=prepared_child.sidecar_path,
            sidecar_sha256=prepared_child.sidecar_sha256,
            sidecar_size_bytes=prepared_child.sidecar_size_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
            windows_command_line_units=prepared_child.windows_command_line_units,
        )
        _R11._R10._rebind_r9_adapter(self._r11._r10._r9, runtime_view)
        self._r8_adapter = self._r11._r8_adapter
        self._base_projector = self._r11._base_projector
        self._used_lock = threading.Lock()
        self._used = False

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        with self._used_lock:
            _check(self._used is False, "adapter_reentry")
            self._used = True
        previous = self._r8_adapter._project_r7_parent_result
        adapter = self._r8_adapter
        prepared = self.prepared
        adapter._project_r7_parent_result = lambda result: _parent_projection(
            adapter, result, prepared, previous
        )
        try:
            return self._r11._r10.supervise(source_scope, release_source_scope, **kwargs)
        finally:
            adapter._project_r7_parent_result = previous

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._r11.summarize_result(result)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._r11, name)


if __name__ == "__main__":
    raise SystemExit("Use prepare_r33_child() and hold the exact R12 addition.")
