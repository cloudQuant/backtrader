"""Prepare the additive R31 ROOT startup source with bounded rereads from EOF.

R31 consumes the frozen R30 generated source and fixes the pinned CLI reader's
file-position behavior at the four held-wrapper/claim read sites. It does not
change the CLI, R28/R29/R30 bytes, maps, or budgets and only returns in-memory
source and manifests.
"""

from __future__ import annotations

import copy
import hashlib
import importlib
import json
import ntpath
import re
from pathlib import Path
from typing import Any


R30_MODULE = "scripts.iteration41_okx_m01_r30_root_startup_prepare_r1"
R30_HELPER_SHA256 = "3869e2a8de8939870ea337245b8b6b4723944cef1377ef2779fa5052ff60a045"
R30_TEST_SHA256 = "3da52408c597c7461c100c35afd265768de446701fa63e0959e6ffb3effc653e"
CLI_SOURCE_REL = "backtrader_runtime/certification_binance_roundtrip_r3_cli.py"
CLI_SOURCE_SHA256 = "62b96a9040d530c8ec592471f0595154fb60239ca03bd6d3b56a6c094dfc7c76"
R31_PREPARATION_SCHEMA = "iteration41.okx.m01.v6.root-startup-public-manifest.r31.r1.v1"
R31_RUNNER_SCHEMA = "iteration41.okx.m01.v6.root-startup-runner-template.r31.r1.v1"
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")


class StartupPreparationBlocked(RuntimeError):
    """A fixed public source, binding, or generated-source check failed."""

    _CODES = frozenset(
        {
            "dependency_pin_mismatch",
            "plan_digest_shape",
            "r30_prepare_failed",
            "cli_reader_binding",
            "outer_patch_anchor",
            "outer_patch_compile",
            "outer_patch_contract",
            "manifest_shape",
            "manifest_binding",
            "runner_compile",
            "namespace_shape",
        }
    )

    def __init__(self, code: str):
        self.code = code if code in self._CODES else "startup_preparation_blocked"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _r30():
    try:
        module = importlib.import_module(R30_MODULE)
        source = Path(module.__file__).read_bytes()
        root = Path(module.__file__).resolve().parents[1]
        test = (root / "tests/unit/runtime/test_iteration41_okx_m01_r30_root_startup_prepare_r1.py").read_bytes()
    except BaseException as exc:
        raise StartupPreparationBlocked("dependency_pin_mismatch") from exc
    if _sha(source) != R30_HELPER_SHA256 or _sha(test) != R30_TEST_SHA256:
        raise StartupPreparationBlocked("dependency_pin_mismatch")
    return module, root


def _literal_assignments(raw: bytes) -> dict[str, Any]:
    import ast

    try:
        tree = ast.parse(raw.decode("utf-8"))
    except (UnicodeDecodeError, SyntaxError, ValueError) as exc:
        raise StartupPreparationBlocked("cli_reader_binding") from exc
    values = {}
    for node in tree.body:
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in {"CLI_REL", "CLI_SHA256"}
            and isinstance(node.value, ast.Constant)
        ):
            values[node.targets[0].id] = node.value.value
    return values


def _verify_pinned_cli_reader(raw_outer: bytes, repo_root: Path) -> None:
    import ast

    values = _literal_assignments(raw_outer)
    if values != {"CLI_REL": CLI_SOURCE_REL, "CLI_SHA256": CLI_SOURCE_SHA256}:
        raise StartupPreparationBlocked("cli_reader_binding")
    try:
        cli_raw = (repo_root / CLI_SOURCE_REL).read_bytes()
        source = cli_raw.decode("utf-8")
        tree = ast.parse(source)
    except (OSError, UnicodeDecodeError, SyntaxError, ValueError) as exc:
        raise StartupPreparationBlocked("cli_reader_binding") from exc
    if _sha(cli_raw) != CLI_SOURCE_SHA256:
        raise StartupPreparationBlocked("cli_reader_binding")
    reader = [
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_read_bounded_handle"
    ]
    if len(reader) != 1:
        raise StartupPreparationBlocked("cli_reader_binding")
    attrs = [
        node.attr
        for node in ast.walk(reader[0])
        if isinstance(node, ast.Attribute)
    ]
    if "ReadFile" not in attrs or "SetFilePointerEx" in attrs or "seek" in attrs:
        raise StartupPreparationBlocked("cli_reader_binding")


_R31_SEEK_READER = b'''def _r31_read_bounded_from_start(cli, api, handle, maximum):
    """Seek one held Windows handle to byte zero before every bounded ReadFile."""
    import ctypes
    from ctypes import wintypes

    try:
        seek = api.kernel.SetFilePointerEx
        seek.argtypes = [
            wintypes.HANDLE,
            ctypes.c_longlong,
            ctypes.POINTER(ctypes.c_longlong),
            wintypes.DWORD,
        ]
        seek.restype = wintypes.BOOL
        position = ctypes.c_longlong()
        succeeded = seek(handle, ctypes.c_longlong(0), ctypes.byref(position), 0)
    except BaseException as exc:
        raise PrelaunchBlocked("held_file_seek_failed") from exc
    _check(
        succeeded and position.value == 0,
        "held_file_seek_failed",
    )
    try:
        raw = cli._read_bounded_handle(api, handle, maximum)
    except BaseException as exc:
        raise PrelaunchBlocked("held_file_read_failed") from exc
    _check(
        type(raw) is bytes and 0 <= len(raw) <= maximum,
        "held_file_read_bound",
    )
    return raw


'''


def _replace_once(raw: bytes, old: bytes, new: bytes) -> bytes:
    if raw.count(old) != 1:
        raise StartupPreparationBlocked("outer_patch_anchor")
    return raw.replace(old, new, 1)


def _patch_outer(raw: bytes) -> bytes:
    if type(raw) is not bytes:
        raise StartupPreparationBlocked("outer_patch_anchor")
    patched = _replace_once(
        raw,
        b"def _r30_predeployed_wrapper(",
        _R31_SEEK_READER + b"def _r30_predeployed_wrapper(",
    )
    for old, new, expected_count in (
        (
            b"wrapper_bytes = cli._read_bounded_handle(api, wrapper_handle, R30_MAX_WRAPPER_BYTES)",
            b"wrapper_bytes = _r31_read_bounded_from_start(cli, api, wrapper_handle, R30_MAX_WRAPPER_BYTES)",
            1,
        ),
        (
            b"current = cli._read_bounded_handle(api, wrapper_handle, R30_MAX_WRAPPER_BYTES)",
            b"current = _r31_read_bounded_from_start(cli, api, wrapper_handle, R30_MAX_WRAPPER_BYTES)",
            1,
        ),
        (
            b"verified = cli._read_bounded_handle(api, claim_handle, R30_MAX_CLAIM_BYTES)",
            b"verified = _r31_read_bounded_from_start(cli, api, claim_handle, R30_MAX_CLAIM_BYTES)",
            2,
        ),
    ):
        if patched.count(old) != expected_count:
            raise StartupPreparationBlocked("outer_patch_anchor")
        patched = patched.replace(old, new)
    try:
        compile(patched, "<r31-filled-outer>", "exec", dont_inherit=True)
    except SyntaxError as exc:
        raise StartupPreparationBlocked("outer_patch_compile") from exc
    required = (
        b"SetFilePointerEx",
        b"ctypes.POINTER(ctypes.c_longlong)",
        b"seek.restype = wintypes.BOOL",
        b"_r31_read_bounded_from_start(cli, api, wrapper_handle, R30_MAX_WRAPPER_BYTES)",
        b"_r31_read_bounded_from_start(cli, api, claim_handle, R30_MAX_CLAIM_BYTES)",
    )
    if any(item not in patched for item in required):
        raise StartupPreparationBlocked("outer_patch_contract")
    return patched


def _manifest_digest(manifest: dict) -> str:
    payload = dict(manifest)
    payload.pop("manifest_binding_sha256", None)
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return _sha(raw)


def _seal(manifest: dict) -> None:
    manifest["manifest_binding_sha256"] = _manifest_digest(manifest)


def _validate_manifest(manifest: Any) -> None:
    if (
        type(manifest) is not dict
        or manifest.get("schema") != R31_PREPARATION_SCHEMA
        or manifest.get("runner_template_schema") != R31_RUNNER_SCHEMA
        or manifest.get("status") != "SOURCE_FAKE_ONLY_DISABLED"
        or manifest.get("manifest_binding_sha256") != _manifest_digest(manifest)
    ):
        raise StartupPreparationBlocked("manifest_binding")
    if (
        type(manifest.get("public_pins")) is not dict
        or type(manifest.get("software_pins")) is not dict
        or type(manifest.get("canonical_pins")) is not dict
        or len(manifest["public_pins"]) != 118
        or len(manifest["software_pins"]) != 36
        or len(manifest["canonical_pins"]) != 154
        or manifest.get("map_counts")
        != {"public_pin_count": 118, "software_pin_count": 36, "canonical_pin_count": 154}
        or manifest.get("safety", {}).get("runner_default_enabled") is not False
        or manifest.get("once", {}).get("parse_allowed") is not False
        or manifest.get("outer_timeouts")
        != {
            "capture_seconds": 405,
            "cleanup_seconds": 5,
            "external_parent_envelope_seconds": None,
            "external_parent_envelope_established": False,
        }
    ):
        raise StartupPreparationBlocked("manifest_shape")


def _build(namespace: Any, plan_sha256: str):
    if type(plan_sha256) is not str or _HEX64.fullmatch(plan_sha256) is None:
        raise StartupPreparationBlocked("plan_digest_shape")
    r30, repo_root = _r30()
    try:
        base = r30.prepare_root_startup(namespace, plan_sha256=plan_sha256)
    except BaseException as exc:
        raise StartupPreparationBlocked("r30_prepare_failed") from exc
    _verify_pinned_cli_reader(base["active_outer_source"], repo_root)
    outer = _patch_outer(base["active_outer_source"])
    manifest = copy.deepcopy(base["manifest"])
    r2 = importlib.import_module(r30.R29_MODULE)._r2()
    manifest["schema"] = R31_PREPARATION_SCHEMA
    manifest["runner_template_schema"] = R31_RUNNER_SCHEMA
    manifest["candidate"]["active_outer_sha256"] = _sha(outer)
    self_key = r2._canonical(manifest["runtime_namespace"]["self_path"])
    plan_key = r2._canonical(manifest["runtime_namespace"]["plan_path"])
    wrapper_key = r2._canonical(manifest["runtime_namespace"]["active_wrapper_path"])
    software = dict(manifest["software_pins"])
    if (
        self_key not in software
        or plan_key not in software
        or wrapper_key not in software
        or software[plan_key] != plan_sha256
        or software[wrapper_key] != _sha(base["active_wrapper_source"])
    ):
        raise StartupPreparationBlocked("manifest_shape")
    software[self_key] = _sha(outer)
    manifest["software_pins"] = dict(sorted(software.items()))
    combined = dict(manifest["canonical_pins"])
    for path, digest in software.items():
        if path not in combined:
            raise StartupPreparationBlocked("manifest_shape")
        combined[path] = digest
    manifest["canonical_pins"] = dict(sorted(combined.items()))
    manifest["runtime_outputs"]["root_prelaunch_source"]["sha256"] = _sha(outer)
    manifest["runtime_outputs"]["root_actual_wrapper_source"]["sha256"] = _sha(
        base["active_wrapper_source"]
    )
    manifest["r31_source_change"] = {
        "base_outer_sha256": _sha(base["active_outer_source"]),
        "active_outer_sha256": _sha(outer),
        "active_wrapper_sha256": _sha(base["active_wrapper_source"]),
        "pinned_cli_relative_path": CLI_SOURCE_REL,
        "pinned_cli_sha256": CLI_SOURCE_SHA256,
        "bounded_reader": "SetFilePointerEx(FILE_BEGIN)+pinned_ReadFile",
        "reread_sites": [
            "predeployed_wrapper_initial_read",
            "predeployed_wrapper_post_child_read",
            "attempt_claim_initial_readback",
            "attempt_claim_post_child_readback",
        ],
        "business_validators_changed": False,
        "frozen_r30_r29_r28_r27_bytes_modified": False,
    }
    manifest["safety"]["active_sources_created_in_memory"] = True
    manifest["safety"]["activation_written_or_deployed"] = False
    _seal(manifest)
    _validate_manifest(manifest)
    runner = r30._runner_source(manifest)
    old_comment = (
        b"# Generated from the frozen R28 source/review closure and R30 predeployment/claim gates. "
        b"ROOT activation remains UNSET.\n"
    )
    new_comment = (
        b"# Generated from frozen R28/R30 closure with R31 handle-position-safe rereads. "
        b"ROOT activation remains UNSET.\n"
    )
    runner = _replace_once(runner, old_comment, new_comment)
    try:
        compile(runner, "<r31-root-runner-template>", "exec", dont_inherit=True)
    except SyntaxError as exc:
        raise StartupPreparationBlocked("runner_compile") from exc
    return manifest, outer, base["active_wrapper_source"], runner


def build_public_manifest(namespace: Any, *, plan_sha256: str) -> dict:
    return _build(namespace, plan_sha256)[0]


def scope_maps(manifest: dict) -> tuple[dict[str, str], dict[str, str]]:
    _validate_manifest(manifest)
    return dict(manifest["public_pins"]), dict(manifest["software_pins"])


def render_root_runner_template(manifest: dict) -> bytes:
    _validate_manifest(manifest)
    r30, _root = _r30()
    raw = r30._runner_source(manifest)
    old_comment = (
        b"# Generated from the frozen R28 source/review closure and R30 predeployment/claim gates. "
        b"ROOT activation remains UNSET.\n"
    )
    new_comment = (
        b"# Generated from frozen R28/R30 closure with R31 handle-position-safe rereads. "
        b"ROOT activation remains UNSET.\n"
    )
    result = _replace_once(raw, old_comment, new_comment)
    compile(result, "<r31-root-runner-template>", "exec", dont_inherit=True)
    return result


def prepare_root_startup(namespace: Any, *, plan_sha256: str) -> dict[str, Any]:
    manifest, outer, wrapper, runner = _build(namespace, plan_sha256)
    return {
        "manifest": manifest,
        "public_pins": dict(manifest["public_pins"]),
        "software_pins": dict(manifest["software_pins"]),
        "canonical_pins": dict(manifest["canonical_pins"]),
        "active_outer_source": outer,
        "active_wrapper_source": wrapper,
        "runner_template_source": runner,
        "runner_template_sha256": _sha(runner),
        "status": "SOURCE_FAKE_ONLY_DISABLED",
    }


def default_test_namespace(root: str = r"Z:\r31-source-fake") -> dict[str, str]:
    base = ntpath.normpath(root)
    return {
        "control_dir": ntpath.join(base, "control"),
        "deployment_dir": ntpath.join(base, "deployment"),
        "plan_path": ntpath.join(base, "control", "plan.json"),
        "self_path": ntpath.join(base, "control", "root_prelaunch_active.py"),
        "active_wrapper_path": ntpath.join(base, "deployment", "root_actual_wrapper.py"),
        "attempt_claim_path": ntpath.join(base, "control", "attempt.claim"),
    }


if __name__ == "__main__":
    raise SystemExit("Call prepare_root_startup() with a fresh namespace and exact plan digest.")
