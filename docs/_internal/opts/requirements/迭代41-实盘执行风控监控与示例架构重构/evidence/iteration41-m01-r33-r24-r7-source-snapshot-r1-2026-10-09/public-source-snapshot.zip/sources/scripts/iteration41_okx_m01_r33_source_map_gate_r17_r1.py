"""Bind the R13 active-outer gate to the held R4 runtime source map.

R17 is an additive, same-call transform around frozen R13/R16 composition.
It keeps R28's case source map unchanged, and never leaves R13 patched after
the R16 preparation call returns.
"""

from __future__ import annotations

import ast
import dataclasses
import hashlib
import ntpath
import threading
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as _R13
from scripts import iteration41_okx_m01_r33_final_output_hold_r16_r1 as _R16


R17_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_source_map_gate_r17_r1.py"
R17_RESULT_SCHEMA = "iteration41.okx.m01.r33.source-map-gate-r17.root-preparation.v1"
R17_SOURCE_ROLE = "r17_runtime_source_map_gate_source"
R17_MAX_SOURCE_BYTES = 2 * 1024 * 1024
R17_MAX_SOURCE_MAP_BYTES = 1024 * 1024
R17_FAILURE_CODES = frozenset(
    {
        "r17_module_name",
        "r17_module_path",
        "r17_source_unavailable",
        "r17_source_size",
        "r17_patch_context_busy",
        "r17_r13_source_pin",
        "r17_r16_source_pin",
        "r17_r13_compose_identity",
        "r17_r13_outer_identity",
        "r17_r13_prepare_identity",
        "r17_r16_prepare_identity",
        "r17_r16_r13_module_identity",
        "r17_source_tuple",
        "r17_source_digest",
        "r17_patch_owner_thread",
        "r17_patch_context_changed",
        "r17_descriptor_rejected",
        "r17_source_map_path",
        "r17_source_map_normalization",
        "r17_control_dir",
        "r17_source_map_path_collision",
        "r17_source_map_control_namespace",
        "r17_descriptor_input_changed",
        "r17_runtime_map_path_unbound",
        "r17_active_outer_transform",
        "r17_r16_composite_blocked",
        "r17_runtime_map_path_missing",
        "r17_r16_result_type",
        "r17_final_descriptor_map_path",
        "r17_runtime_map_hold_missing",
        "r17_runtime_map_hold_binding",
        "r17_hold_path",
        "r17_helper_hold_collision",
        "r17_helper_hold_digest",
        "r17_child_map_count",
        "r17_final_hold_binding",
    }
)
R17_PINNED_R13_SHA256 = "23c98a7d0012499050309f3dcdd8cd8f2710698867654776125e8a3d9a1fe580"
R17_PINNED_R16_SHA256 = "06e61947222e8639b700a8749c083d35e82202366b6c7105a354c8a7ff1b8e78"


class SourceMapGateR17Blocked(ValueError):
    """A fixed R17 source, descriptor, transform, or hold contract failed."""

    def __init__(self, code: str):
        self.code = code if code in R17_FAILURE_CODES else "r17_final_hold_binding"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise SourceMapGateR17Blocked(code)


def _canonical_json(value: Any) -> bytes:
    return _R16._canonical_json(value)


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R17_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r17_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R17_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r17_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R17_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise SourceMapGateR17Blocked("r17_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R17_MAX_SOURCE_BYTES, "r17_source_size")
    return str(path), raw, _sha(raw)


_R17_OUTER_SUPPORT = br'''
R17_ACTIVE_OUTER_GATE_MARKER = b"iteration41.okx.m01.r33.held-runtime-source-map-gate-r17.r1.v1"
R17_RUNTIME_SOURCE_MAP_PATH = __R17_RUNTIME_SOURCE_MAP_PATH__
R17_HELPER_PATH = __R17_HELPER_PATH__
R17_HELPER_SHA256 = __R17_HELPER_SHA256__
R17_SOURCE_MAP_SCHEMA = "iteration41.okx.m01.r33.public-source-map.v1"
R17_SOURCE_MAP_MAX_BYTES = 1048576
R17_SOURCE_MAP_KEYS = frozenset({
    "schema", "public_pins", "software_pins", "canonical_pins", "map_counts",
    "root", "runtime_namespace", "runner_template_sha256", "runner_template_schema",
    "manifest_binding_sha256", "plan_sha256", "plan_disposition",
})


def _r17_runtime_source_map(held):
    raw = _r13_exact_held(held, R17_RUNTIME_SOURCE_MAP_PATH)
    _check(
        type(raw) is bytes and 0 < len(raw) <= R17_SOURCE_MAP_MAX_BYTES,
        "r17_runtime_map_size",
    )
    try:
        value = _strict_json(raw, R17_SOURCE_MAP_MAX_BYTES)
    except BaseException:
        raise ValueError("r17_runtime_map_json") from None
    _check(
        type(value) is dict and frozenset(value) == R17_SOURCE_MAP_KEYS,
        "r17_runtime_map_shape",
    )
    _check(
        value.get("schema") == R17_SOURCE_MAP_SCHEMA
        and value.get("runtime_namespace") == R13_EXPECTED_NAMESPACE
        and value.get("plan_sha256") == R13_EXPECTED_PLAN_SHA256
        and value.get("map_counts") == {"public": 118, "software": 36, "canonical": 154},
        "r17_runtime_map_binding",
    )
    return value


def _r17_rebuild_exact_active_outer(base_r10_outer, outer, *, held):
    regenerated = _r13_rebuild_exact_active_outer(base_r10_outer, outer)
    helper_raw = _r13_exact_held(held, R17_HELPER_PATH)
    _check(
        type(helper_raw) is bytes
        and 0 < len(helper_raw) <= 2 * 1024 * 1024
        and _sha(helper_raw) == R17_HELPER_SHA256,
        "r17_helper_held_pin",
    )
    try:
        assignments, functions = _r13_source_nodes(helper_raw)
        support_template = ast.literal_eval(assignments["_R17_OUTER_SUPPORT"])
        relative_path = ast.literal_eval(assignments["R17_RELATIVE_PATH"])
        source_schema = ast.literal_eval(assignments["R17_RESULT_SCHEMA"])
        transform = _r13_compile_function(
            {"ntpath": ntpath},
            functions,
            "_apply_active_outer_transform",
            "_r17_apply_active_outer_transform",
        )
    except BaseException:
        raise ValueError("r17_helper_transform_unavailable") from None
    _check(
        type(support_template) is bytes
        and relative_path == "scripts/iteration41_okx_m01_r33_source_map_gate_r17_r1.py"
        and source_schema == "iteration41.okx.m01.r33.source-map-gate-r17.root-preparation.v1",
        "r17_helper_source_constants",
    )
    return transform(
        regenerated,
        R17_RUNTIME_SOURCE_MAP_PATH,
        R17_HELPER_PATH,
        R17_HELPER_SHA256,
        support_template,
    )
'''


def _apply_active_outer_transform(
    raw: bytes,
    runtime_source_map_path: str,
    helper_path: str,
    helper_sha256: str,
    support_template: bytes,
) -> bytes:
    """Apply the one fixed R17 source-map argument and replay transform."""
    if type(raw) is not bytes or not 0 < len(raw) <= 2 * 1024 * 1024:
        raise ValueError("r17_outer_input_size")
    for value, code in (
        (runtime_source_map_path, "r17_runtime_map_path"),
        (helper_path, "r17_helper_path"),
    ):
        if (
            type(value) is not str
            or not 0 < len(value) <= 32767
            or "\x00" in value
            or not ntpath.isabs(value)
            or ntpath.normpath(value) != value
        ):
            raise ValueError(code)
    if (
        type(helper_sha256) is not str
        or len(helper_sha256) != 64
        or any(char not in "0123456789abcdef" for char in helper_sha256)
        or type(support_template) is not bytes
    ):
        raise ValueError("r17_transform_input_shape")
    marker = b"iteration41.okx.m01.r33.held-runtime-source-map-gate-r17.r1.v1"
    if marker in raw:
        raise ValueError("r17_transform_already_applied")
    substitutions = {
        b"__R17_RUNTIME_SOURCE_MAP_PATH__": ascii(runtime_source_map_path).encode("ascii"),
        b"__R17_HELPER_PATH__": ascii(helper_path).encode("ascii"),
        b"__R17_HELPER_SHA256__": ascii(helper_sha256).encode("ascii"),
    }
    support = support_template
    for placeholder, replacement in substitutions.items():
        if support.count(placeholder) != 1:
            raise ValueError("r17_support_placeholder")
        support = support.replace(placeholder, replacement, 1)

    old_map_argument = (
        b"                held, active_driver, candidate_template, self_path, self_sha256, "
        b"plan_raw, source_map\n"
    )
    new_map_argument = (
        b"                held, active_driver, candidate_template, self_path, self_sha256, "
        b"plan_raw, _r17_runtime_source_map(held)\n"
    )
    if raw.count(old_map_argument) != 1:
        raise ValueError("r17_runtime_map_argument_anchor")
    result = raw.replace(old_map_argument, new_map_argument, 1)

    old_rebuild_name = b"regenerated = _r13_rebuild_exact_active_outer(\n"
    new_rebuild_name = b"regenerated = _r17_rebuild_exact_active_outer(\n"
    if result.count(old_rebuild_name) != 1:
        raise ValueError("r17_rebuild_call_anchor")
    result = result.replace(old_rebuild_name, new_rebuild_name, 1)
    old_rebuild_close = (
        b'            "namespace": dict(namespace),\n'
        b"        },\n"
        b"    )\n"
        b"    _check(\n"
        b"        regenerated == active_driver"
    )
    new_rebuild_close = (
        b'            "namespace": dict(namespace),\n'
        b"        },\n"
        b"        held=held,\n"
        b"    )\n"
        b"    _check(\n"
        b"        regenerated == active_driver"
    )
    if result.count(old_rebuild_close) != 1:
        raise ValueError("r17_rebuild_held_argument_anchor")
    result = result.replace(old_rebuild_close, new_rebuild_close, 1)
    support_anchor = b"def run_prelaunch(\n"
    if result.count(support_anchor) != 1:
        raise ValueError("r17_support_insertion_anchor")
    result = result.replace(support_anchor, support + support_anchor, 1)
    if (
        len(result) > 2 * 1024 * 1024
        or marker not in result
        or result.count(new_map_argument) != 1
        or result.count(old_map_argument) != 0
    ):
        raise ValueError("r17_transformed_outer_contract")
    try:
        compile(result, "<r17-transformed-active-outer>", "exec", dont_inherit=True)
    except BaseException:
        raise ValueError("r17_transformed_outer_compile") from None
    return result


_PATCH_LOCK = threading.Lock()
_PATCH_OWNER_THREAD: Optional[int] = None
_ORIGINAL_R13_COMPOSE = _R13._compose
_ORIGINAL_R13_ACTIVE_OUTER_SOURCE = _R13._active_outer_source
_ORIGINAL_R13_PREPARE = _R13.prepare_r33_child
_ORIGINAL_R16_PREPARE = _R16.prepare_root_hold


@dataclasses.dataclass(frozen=True)
class R17RootPreparedHold:
    """R16 output plus the exact R17 helper pin and final hold digest."""

    schema: str
    r16_result: Any
    r17_helper_path: str
    r17_helper_bytes: bytes
    r17_helper_sha256: str
    runtime_source_map_path: str
    runtime_source_map_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def r16_helper_path(self) -> str:
        return self.r16_result.r16_helper_path

    @property
    def r16_helper_bytes(self) -> bytes:
        return self.r16_result.r16_helper_bytes

    @property
    def r16_helper_sha256(self) -> str:
        return self.r16_result.r16_helper_sha256

    @property
    def prepared_r13(self) -> Any:
        return self.r16_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r16_result.prepared_r14

    @property
    def prepared_r15(self) -> Any:
        return self.r16_result.prepared_r15


def _runtime_source_map_path(base_r11: Any) -> str:
    try:
        r10_prepared = base_r11.r10_prepared
        descriptor = _R13._R10._R9._R4._validate_descriptor(r10_prepared.descriptor_json)
        source_map_path = descriptor["source_map_path"]
        namespace = descriptor["runtime_namespace"]
        control_dir = namespace["control_dir"]
    except BaseException:
        raise SourceMapGateR17Blocked("r17_descriptor_rejected") from None
    r4 = _R13._R10._R9._R4
    _check(r4._absolute_windows_path(source_map_path), "r17_source_map_path")
    _check(ntpath.normpath(source_map_path) == source_map_path, "r17_source_map_normalization")
    _check(r4._absolute_windows_path(control_dir), "r17_control_dir")
    source_key = ntpath.normcase(ntpath.normpath(source_map_path))
    control_key = ntpath.normcase(ntpath.normpath(control_dir))
    path_keys = [
        ntpath.normcase(ntpath.normpath(path))
        for path in (
            descriptor["runner_path"],
            descriptor["cuv2_path"],
            *namespace.values(),
        )
    ]
    _check(source_key not in path_keys, "r17_source_map_path_collision")
    try:
        common = ntpath.normcase(ntpath.normpath(ntpath.commonpath([source_key, control_key])))
    except (TypeError, ValueError):
        raise SourceMapGateR17Blocked("r17_source_map_control_namespace") from None
    _check(common == control_key and source_key != control_key, "r17_source_map_control_namespace")
    return source_map_path


def _verify_source_pins(r17_source: tuple[str, bytes, str]) -> None:
    _check(_R13._self_source()[2] == R17_PINNED_R13_SHA256, "r17_r13_source_pin")
    _check(_R16._self_source()[2] == R17_PINNED_R16_SHA256, "r17_r16_source_pin")
    _check(_R13._compose is _ORIGINAL_R13_COMPOSE, "r17_r13_compose_identity")
    _check(_R13._active_outer_source is _ORIGINAL_R13_ACTIVE_OUTER_SOURCE, "r17_r13_outer_identity")
    _check(_R13.prepare_r33_child is _ORIGINAL_R13_PREPARE, "r17_r13_prepare_identity")
    _check(_R16.prepare_root_hold is _ORIGINAL_R16_PREPARE, "r17_r16_prepare_identity")
    _check(_R16._R13 is _R13, "r17_r16_r13_module_identity")
    _check(type(r17_source) is tuple and len(r17_source) == 3, "r17_source_tuple")
    _check(type(r17_source[1]) is bytes and _sha(r17_source[1]) == r17_source[2], "r17_source_digest")


def _add_r17_hold_row(
    r16_result: Any,
    helper_path: str,
    helper_raw: bytes,
    helper_sha256: str,
    runtime_source_map_path: str,
) -> tuple[dict[str, Any], str, str]:
    r9 = _R13._R10._R9
    descriptor = _R13._R10._R9._R4._validate_descriptor(r16_result.prepared_r13.descriptor_json)
    _check(
        descriptor["source_map_path"] == runtime_source_map_path,
        "r17_final_descriptor_map_path",
    )
    source_map_raw = r16_result.prepared_r13.source_map_bytes
    source_map_sha256 = _sha(source_map_raw)
    addition = dict(r16_result.hold_addition)
    entries = dict(addition.get("entries", {}))
    map_matches = [
        path for path in entries
        if r9._normalized(path) == r9._normalized(runtime_source_map_path)
    ]
    _check(len(map_matches) == 1, "r17_runtime_map_hold_missing")
    map_entry = entries[map_matches[0]]
    expected_map_entry = {
        "sha256": source_map_sha256,
        "size_bytes": len(source_map_raw),
        "role": _R16._R15.R15_SOURCE_MAP_ROLE,
        "origin": "generated_from_exact_r13_binding:" + r16_result.prepared_r13.binding_sha256,
    }
    _check(map_entry == expected_map_entry, "r17_runtime_map_hold_binding")
    _check(r9._absolute_windows_path(helper_path), "r17_hold_path")
    helper_key = r9._normalized(helper_path)
    _check(helper_key not in {r9._normalized(path) for path in entries}, "r17_helper_hold_collision")
    _check(type(helper_raw) is bytes and _sha(helper_raw) == helper_sha256, "r17_helper_hold_digest")
    entries[helper_path] = {
        "sha256": helper_sha256,
        "size_bytes": len(helper_raw),
        "role": R17_SOURCE_ROLE,
        "origin": "repository_source:" + R17_RELATIVE_PATH,
    }
    addition["entries"] = dict(sorted(entries.items()))
    _check(addition.get("canonical_child_map_count") == 154, "r17_child_map_count")
    digest = _sha(_canonical_json(addition))
    return addition, digest, source_map_sha256


def prepare_root_hold(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> R17RootPreparedHold:
    """Run R16 once with an owner-thread R13 transform, then restore R13."""
    global _PATCH_OWNER_THREAD
    r17_source = _self_source()
    if not _PATCH_LOCK.acquire(blocking=False):
        raise SourceMapGateR17Blocked("r17_patch_context_busy")

    operation_error: Optional[BaseException] = None
    result: Any = None
    wrappers_installed = False
    wrappers_intact = True
    context: dict[str, Any] = {"owner": threading.get_ident(), "source_map_path": None}
    try:
        _verify_source_pins(r17_source)
        owner = threading.get_ident()
        _PATCH_OWNER_THREAD = owner

        def _assert_owner() -> None:
            _check(
                _PATCH_OWNER_THREAD == owner == threading.get_ident(),
                "r17_patch_owner_thread",
            )
            _check(
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is active_outer_wrapper,
                "r17_patch_context_changed",
            )

        def compose_wrapper(base_r11: Any) -> Any:
            _assert_owner()
            path = _runtime_source_map_path(base_r11)
            previous = context["source_map_path"]
            _check(previous is None or previous == path, "r17_descriptor_input_changed")
            context["source_map_path"] = path
            return _ORIGINAL_R13_COMPOSE(base_r11)

        def active_outer_wrapper(*args: Any, **kwargs: Any) -> bytes:
            _assert_owner()
            path = context.get("source_map_path")
            _check(type(path) is str, "r17_runtime_map_path_unbound")
            original = _ORIGINAL_R13_ACTIVE_OUTER_SOURCE(*args, **kwargs)
            try:
                return _apply_active_outer_transform(
                    original,
                    path,
                    r17_source[0],
                    r17_source[2],
                    _R17_OUTER_SUPPORT,
                )
            except BaseException:
                raise SourceMapGateR17Blocked("r17_active_outer_transform") from None

        _R13._compose = compose_wrapper
        _R13._active_outer_source = active_outer_wrapper
        wrappers_installed = True
        try:
            result = _ORIGINAL_R16_PREPARE(
                prepared_r31,
                root_metadata,
                environment=environment,
            )
        except BaseException as exc:
            operation_error = exc
    except BaseException as exc:
        operation_error = exc
    finally:
        if wrappers_installed:
            wrappers_intact = (
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is active_outer_wrapper
            )
            _R13._compose = _ORIGINAL_R13_COMPOSE
            _R13._active_outer_source = _ORIGINAL_R13_ACTIVE_OUTER_SOURCE
        _PATCH_OWNER_THREAD = None
        _PATCH_LOCK.release()

    if operation_error is not None:
        if isinstance(operation_error, SourceMapGateR17Blocked):
            raise operation_error
        if isinstance(operation_error, _R16.FinalOutputHoldR16Blocked):
            raise operation_error
        raise SourceMapGateR17Blocked("r17_r16_composite_blocked") from None
    _check(wrappers_intact, "r17_patch_context_changed")
    runtime_source_map_path = context.get("source_map_path")
    _check(type(runtime_source_map_path) is str, "r17_runtime_map_path_missing")
    _check(type(result) is _R16.R16RootPreparedHold, "r17_r16_result_type")
    try:
        addition, hold_sha256, map_sha256 = _add_r17_hold_row(
            result,
            r17_source[0],
            r17_source[1],
            r17_source[2],
            runtime_source_map_path,
        )
    except SourceMapGateR17Blocked:
        raise
    except BaseException:
        raise SourceMapGateR17Blocked("r17_final_hold_binding") from None
    return R17RootPreparedHold(
        schema=R17_RESULT_SCHEMA,
        r16_result=result,
        r17_helper_path=r17_source[0],
        r17_helper_bytes=r17_source[1],
        r17_helper_sha256=r17_source[2],
        runtime_source_map_path=runtime_source_map_path,
        runtime_source_map_sha256=map_sha256,
        hold_addition=addition,
        hold_addition_sha256=hold_sha256,
    )


def verify_hold_addition(value: Any) -> bool:
    """Recheck the returned R17 hold digest and exact map/helper rows."""
    try:
        if type(value) is not R17RootPreparedHold or value.schema != R17_RESULT_SCHEMA:
            return False
        addition = value.hold_addition
        if type(addition) is not dict or _sha(_canonical_json(addition)) != value.hold_addition_sha256:
            return False
        entries = addition.get("entries")
        if type(entries) is not dict or addition.get("canonical_child_map_count") != 154:
            return False
        r9 = _R13._R10._R9
        helper_rows = [
            row for path, row in entries.items()
            if r9._normalized(path) == r9._normalized(value.r17_helper_path)
        ]
        if len(helper_rows) != 1 or helper_rows[0] != {
            "sha256": value.r17_helper_sha256,
            "size_bytes": len(value.r17_helper_bytes),
            "role": R17_SOURCE_ROLE,
            "origin": "repository_source:" + R17_RELATIVE_PATH,
        }:
            return False
        map_rows = [
            row for path, row in entries.items()
            if r9._normalized(path) == r9._normalized(value.runtime_source_map_path)
        ]
        if len(map_rows) != 1 or map_rows[0].get("sha256") != value.runtime_source_map_sha256:
            return False
        return True
    except BaseException:
        return False

