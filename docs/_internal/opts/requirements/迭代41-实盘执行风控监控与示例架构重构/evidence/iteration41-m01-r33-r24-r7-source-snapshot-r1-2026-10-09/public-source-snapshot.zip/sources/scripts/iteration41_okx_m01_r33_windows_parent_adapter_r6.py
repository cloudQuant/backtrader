"""R6 bounded child-phase diagnostics over the frozen R5 parent adapter.

R6 replaces only the child's pinned R3 bootstrap bytes with the additive R4
bootstrap, which sends a fixed finite stage frame on stderr. The R5 parent
supervisor, its budgets, and its cleanup behavior stay pinned. Phase bytes are
read only after a complete CHILD_EXITED capture, cleanup, and source-scope
release; they are never returned raw and never establish authority, provider
activity, a route, or a case result.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import sys
import threading
import types
from pathlib import Path
from typing import Any, Callable, Optional


R5_FILENAME = "iteration41_okx_m01_r33_windows_parent_adapter_r5.py"
R5_SOURCE_SHA256 = "5d11a2aae8af7d9e98e956dfc4258453709ea9a86d481591a15676b0aa7d5f3c"
PHASE_BOOTSTRAP_FILENAME = "iteration41_okx_m01_r33_child_bootstrap_r4.py"
PHASE_BOOTSTRAP_SHA256 = "4fe4131a69e8a36e354b3bd4d7babba25ec2de9eeb52258336209dee6677b778"
PHASE_SCHEMA = "iteration41.okx.m01.r33.child-phase.v1"
PHASE_PREFIX = b"M01P1:"
PHASE_ORDER = "DSHhPpRrVX"
PHASE_TERMINALS = frozenset("CEUQ")
MAX_PHASE_FRAME_BYTES = 32
MAX_R5_BYTES = 1024 * 1024
ROOT_METADATA_SCHEMA = "iteration41.okx.m01.r33.root-owned-bootstrap-metadata.v1"
CUV2_PUBLIC_SOURCE_SHA256 = "e856be8e4056835d4a7e54f5c6b449c69ab3f1c2ebb049bcbcc1c95a9ad3f246"
FIXED_EXECUTABLE = "C:/anaconda3/python.exe"
PARENT_TIMEOUT_SECONDS = 100.0
PARENT_CLEANUP_SECONDS = 5.0


class ParentDiagnosticBlocked(ValueError):
    """A fixed source, prepared-child, or finite phase boundary failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise ParentDiagnosticBlocked(reason)


def _read_pinned(path: Path, expected: str, maximum: int) -> bytes:
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
    except BaseException:
        raise ParentDiagnosticBlocked("pinned_source_read") from None
    _check(0 < len(raw) <= maximum, "pinned_source_size")
    _check(_sha(raw) == expected, "pinned_source_digest")
    return raw


def _load_pinned_r5():
    path = Path(__file__).resolve().with_name(R5_FILENAME)
    raw = _read_pinned(path, R5_SOURCE_SHA256, MAX_R5_BYTES)
    name = "_iteration41_okx_m01_r33_r5_exact_for_r6"
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__package__ = ""
    try:
        code = compile(raw, str(path), "exec", dont_inherit=True)
        sys.modules[name] = module
        exec(code, module.__dict__)
    except BaseException:
        sys.modules.pop(name, None)
        raise ParentDiagnosticBlocked("r5_source_load") from None
    sys.modules.pop(name, None)
    return module


_R5 = _load_pinned_r5()
_R4 = _R5._R4
PreparedR5Child = _R5.PreparedM01Child


def _phase_bootstrap_bytes() -> bytes:
    path = Path(__file__).resolve().with_name(PHASE_BOOTSTRAP_FILENAME)
    raw = _read_pinned(path, PHASE_BOOTSTRAP_SHA256, 64 * 1024)
    try:
        compile(raw, str(path), "exec", dont_inherit=True)
    except BaseException:
        raise ParentDiagnosticBlocked("phase_bootstrap_compile") from None
    return raw


def _canonical_binding_digest(binding: dict[str, Any], command: tuple[str, ...], cwd: str) -> str:
    encoded = json.dumps(
        {
            "binding": binding,
            "command": list(command[:-1]) + [_sha(command[-1].encode("utf-8"))],
            "cwd": cwd,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("ascii")
    return _sha(encoded)


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R6 command binding; the embedded phase bootstrap is hash-pinned."""

    command: tuple[str, ...]
    cwd: str
    environment: dict[str, str]
    stdin_descriptor: bytes
    source_map_bytes: bytes
    runner_bytes: bytes
    bootstrap_bytes: bytes
    binding: dict[str, Any]
    binding_sha256: str
    plan_disposition: str
    r5_prepared: Any


@dataclasses.dataclass(frozen=True)
class M01ParentDiagnosticResult:
    """Finite parent facts with child byte streams removed before return."""

    schema: str
    status: str
    reason: str
    cleanup_reason: str
    child_returncode: Optional[int]
    capture_complete: bool
    cleanup_complete: bool
    scope_released: bool
    scope_retained: bool
    stdout_bytes: Optional[int]
    stderr_bytes: Optional[int]
    child_phase: dict[str, Any]


def _from_r5(base: PreparedR5Child) -> PreparedM01Child:
    _check(type(base) is _R4.PreparedM01Child, "r5_prepared_type")
    _R4._validate_r4_prepared(base)
    bootstrap = _phase_bootstrap_bytes()
    command = tuple(base.command[:-1]) + (bootstrap.decode("utf-8"),)
    binding = dict(base.binding)
    binding.update(
        {
            "schema": "iteration41.okx.m01.r33.prepared-child-binding.r6.phase.v1",
            "bootstrap_sha256": _sha(bootstrap),
            "bootstrap_variant": "bounded-finite-child-phase-r4.v1",
            "phase_schema": PHASE_SCHEMA,
            "phase_max_bytes": MAX_PHASE_FRAME_BYTES,
        }
    )
    binding_sha256 = _canonical_binding_digest(binding, command, base.cwd)
    return PreparedM01Child(
        command=command,
        cwd=base.cwd,
        environment=dict(base.environment),
        stdin_descriptor=base.stdin_descriptor,
        source_map_bytes=base.source_map_bytes,
        runner_bytes=base.runner_bytes,
        bootstrap_bytes=bootstrap,
        binding=binding,
        binding_sha256=binding_sha256,
        plan_disposition=base.plan_disposition,
        r5_prepared=base,
    )


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "prepared_child_type")
    base = value.r5_prepared
    _check(type(base) is PreparedR5Child, "r5_prepared_type")
    _R4._validate_r4_prepared(base)
    bootstrap = _phase_bootstrap_bytes()
    _check(value.bootstrap_bytes == bootstrap, "phase_bootstrap_bytes")
    expected = _from_r5(base)
    _check(value.command == expected.command, "phase_command")
    _check(value.binding == expected.binding, "phase_binding")
    _check(value.binding_sha256 == expected.binding_sha256, "phase_binding_digest")
    _check(
        value.cwd == base.cwd
        and value.environment == base.environment
        and value.stdin_descriptor == base.stdin_descriptor
        and value.source_map_bytes == base.source_map_bytes
        and value.runner_bytes == base.runner_bytes
        and value.plan_disposition == base.plan_disposition,
        "phase_prepared_fields",
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
) -> PreparedM01Child:
    """Create an R5-prepared child with the exact finite-phase bootstrap bytes."""
    base = _R5.prepare_r33_child(
        prepared_r31, root_metadata, environment=environment
    )
    return _from_r5(base)


def _r2_prepared(adapter: Any, value: PreparedM01Child):
    r2 = adapter._r2_module
    return r2.PreparedM01Child(
        command=value.command,
        cwd=value.cwd,
        environment=dict(value.environment),
        stdin_descriptor=value.stdin_descriptor,
        source_map_bytes=value.source_map_bytes,
        runner_bytes=value.runner_bytes,
        bootstrap_bytes=value.bootstrap_bytes,
        binding=dict(value.binding),
        binding_sha256=value.binding_sha256,
        plan_disposition=value.plan_disposition,
    )


class M01WindowsParentAdapter:
    """R5 parent supervisor with gated, post-cleanup phase-frame projection."""

    def __init__(
        self,
        prepared_child: PreparedM01Child,
        *,
        scope_authenticator: Callable[[Any, dict[str, Any], float], Any],
        fake_leaves: bool = False,
        native: Any = None,
        process_factory: Optional[Callable[..., Any]] = None,
        launcher_module: Any = None,
        image_module: Any = None,
        clock: Callable[[], Any],
        sleeper: Callable[[float], Any],
    ):
        _validate_prepared(prepared_child)
        base = prepared_child.r5_prepared
        self._r5 = _R5.M01WindowsParentAdapter(
            base,
            scope_authenticator=scope_authenticator,
            fake_leaves=fake_leaves,
            native=native,
            process_factory=process_factory,
            launcher_module=launcher_module,
            image_module=image_module,
            clock=clock,
            sleeper=sleeper,
        )
        r4_prepared = dataclasses.replace(
            base,
            command=prepared_child.command,
            bootstrap_bytes=prepared_child.bootstrap_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
        )
        internal = _r2_prepared(self._r5, prepared_child)
        # R5 validated and constructed the exact frozen R4/R2 objects first.
        # Replace only their prepared fixed fields with this new pinned variant.
        self._r5.prepared = r4_prepared
        self._r5._base.prepared = r4_prepared
        self._r5._base._r2_prepared = internal
        self._r5._inner.prepared = internal
        self.prepared = prepared_child
        self.fake_leaves = self._r5.fake_leaves
        self._owner_thread = self._r5._owner_thread

    def supervise(
        self,
        source_scope: Any,
        release_source_scope: Callable[[Any, float], Any],
        *,
        retention_registry: Any = None,
    ):
        raw_result = self._r5.supervise(
            source_scope,
            release_source_scope,
            retention_registry=retention_registry,
        )
        return self._project_parent_result(raw_result)

    def summarize_result(self, result: Any) -> dict[str, Any]:
        result_type = self._r5._inner._r32.ParentEnvelopeResult
        if type(result) is M01ParentDiagnosticResult:
            return {
                "schema": result.schema,
                "status": result.status,
                "reason": result.reason,
                "cleanup_reason": result.cleanup_reason,
                "child_returncode": result.child_returncode,
                "capture_complete": result.capture_complete,
                "cleanup_complete": result.cleanup_complete,
                "scope_released": result.scope_released,
                "scope_retained": result.scope_retained,
                "stdout_bytes": result.stdout_bytes,
                "stderr_bytes": result.stderr_bytes,
                "authority": False,
                "strict_cases_passed": 0,
                "child_phase": dict(result.child_phase),
            }
        _check(type(result) is result_type, "parent_result_type")
        return self.summarize_result(self._project_parent_result(result))

    def _project_parent_result(self, result: Any) -> M01ParentDiagnosticResult:
        result_type = self._r5._inner._r32.ParentEnvelopeResult
        _check(type(result) is result_type, "parent_result_type")
        safe_to_read_phase = _safe_to_read_phase(result)
        if safe_to_read_phase:
            summary = self._r5.summarize_result(result)
            phase = _parse_phase_frame(result.stderr)
        else:
            summary = {
                "schema": result.schema,
                "status": result.status,
                "reason": result.reason,
                "cleanup_reason": result.cleanup_reason,
                "child_returncode": result.child_returncode,
                "capture_complete": result.capture_complete,
                "cleanup_complete": result.cleanup_complete,
                "scope_released": result.scope_released,
                "scope_retained": result.scope_retained,
                "stdout_bytes": None,
                "stderr_bytes": None,
                "authority": False,
                "strict_cases_passed": 0,
            }
            phase = _unobserved_phase()
        return M01ParentDiagnosticResult(
            schema=summary["schema"],
            status=summary["status"],
            reason=summary["reason"],
            cleanup_reason=summary["cleanup_reason"],
            child_returncode=summary["child_returncode"],
            capture_complete=summary["capture_complete"],
            cleanup_complete=summary["cleanup_complete"],
            scope_released=summary["scope_released"],
            scope_retained=summary["scope_retained"],
            stdout_bytes=summary["stdout_bytes"],
            stderr_bytes=summary["stderr_bytes"],
            child_phase=phase,
        )

    def __getattr__(self, name: str):
        return getattr(self._r5, name)


def _unobserved_phase() -> dict[str, Any]:
    return {
        "schema": PHASE_SCHEMA,
        "status": "UNOBSERVED",
        "stage": "UNOBSERVED",
        "category": "UNOBSERVED",
        "verification": "UNVERIFIED",
        "authority": False,
        "route_invocations": 0,
        "strict_cases_passed": 0,
    }


def _safe_to_read_phase(result: Any) -> bool:
    return (
        result.status == "CHILD_EXITED"
        and result.capture_complete is True
        and result.cleanup_complete is True
        and result.scope_released is True
        and result.scope_retained is False
        and type(result.child_returncode) is int
    )


def _phase_stage(sequence: str) -> str:
    if not sequence:
        return "UNOBSERVED"
    latest = sequence[-1]
    return {
        "D": "SCOPE_ENTRY_PENDING",
        "S": "HELD_MAP_GATE_PENDING",
        "H": "HELD_MAP_GATE_INCOMPLETE",
        "h": "PLAN_GATE_PENDING",
        "P": "PLAN_GATE_INCOMPLETE",
        "p": "RUNNER_GATE_PENDING",
        "R": "RUNNER_CALL_INCOMPLETE",
        "r": "SAFE_RESULT_GATE_PENDING",
        "V": "CHILD_CUV2_POSTVERIFY_PENDING",
        "X": "CHILD_CUV2_POSTVERIFY_REPORTED",
    }.get(latest, "UNOBSERVED")


def _parse_phase_frame(raw: Any) -> dict[str, Any]:
    if (
        type(raw) is not bytes
        or not PHASE_PREFIX
        or len(raw) > MAX_PHASE_FRAME_BYTES
        or not raw.startswith(PHASE_PREFIX)
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
    ):
        return _unobserved_phase()
    try:
        body = raw[len(PHASE_PREFIX) : -1].decode("ascii")
    except BaseException:
        return _unobserved_phase()
    if not body:
        return _unobserved_phase()
    terminal = body[-1] if body[-1] in PHASE_TERMINALS else None
    sequence = body[:-1] if terminal else body
    if sequence != PHASE_ORDER[: len(sequence)] or len(sequence) > len(PHASE_ORDER):
        return _unobserved_phase()
    if terminal and sequence.endswith("X"):
        return _unobserved_phase()
    if terminal == "U" and sequence != PHASE_ORDER[:8]:
        return _unobserved_phase()
    if terminal == "Q" and sequence != PHASE_ORDER[:9]:
        return _unobserved_phase()
    if any(code not in PHASE_ORDER for code in sequence):
        return _unobserved_phase()
    category = {
        "C": "CONTRACT_REJECTED",
        "E": "UNEXPECTED_EXCEPTION",
        "U": "UNSAFE_RUNNER_RESULT",
        "Q": "CHILD_POSTVERIFY_FAILED",
    }.get(terminal, "NONE")
    stage = _phase_stage(sequence)
    if terminal and not sequence:
        stage = "BOOTSTRAP_REJECTED" if terminal == "C" else "BOOTSTRAP_EXCEPTION"
    if terminal == "U":
        stage = "RUNNER_RESULT_UNSAFE"
    elif terminal == "Q":
        stage = "CHILD_CUV2_POSTVERIFY_FAILED"
    return {
        "schema": PHASE_SCHEMA,
        "status": "OBSERVED_FIXED_STAGE",
        "stage": stage,
        "category": category,
        "verification": "UNVERIFIED",
        "authority": False,
        "route_invocations": 0,
        "strict_cases_passed": 0,
    }
