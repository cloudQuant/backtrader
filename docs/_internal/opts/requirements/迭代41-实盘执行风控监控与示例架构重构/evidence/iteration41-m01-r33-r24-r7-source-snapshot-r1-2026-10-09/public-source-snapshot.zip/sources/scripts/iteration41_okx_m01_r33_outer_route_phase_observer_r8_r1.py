"""R8 finite observation of the exact frozen R28 outer response boundary.

The composed child is derived from the exact R7 bootstrap.  It wraps only the
held R28 once module's ``_outer_response`` and ``_parse_outer_response``
functions, verifies their code against that exact held source, and records at
most two call outcomes.  No arguments, results, exception messages, or payload
bytes enter the phase frame.  Parent parsing is gated by R6's completed
capture/cleanup/source-scope-release predicate.
"""

from __future__ import annotations

import ast
import dataclasses
import hashlib
import json
import re
from pathlib import Path
from typing import Any, Callable, Optional

from scripts import iteration41_okx_m01_r33_windows_parent_adapter_r6 as _R6
from scripts import iteration41_okx_m01_r33_runner_result_observer_r7_r2 as _R7


R7_FILENAME = "iteration41_okx_m01_r33_runner_result_observer_r7_r2.py"
R7_SHA256 = "5b205706b2836e78fb4b43999617ce91c7e0c3b2aecba595236152d9920a4feb"
RESULT_SCHEMA = "iteration41.okx.m01.r33.outer-route-phase-observation.r8.r1.v1"
PHASE_PREFIX = b"M01R8:"
PHASE_MAX_BYTES = 24
MAX_BOOTSTRAP_BYTES = 96 * 1024
MAX_RUNNER_BYTES = 4 * 1024 * 1024
_HEX2 = re.compile(rb"[0-9a-f]{2}\Z")
_MAIN_GUARD = b'\nif __name__ == "__main__":\n'
_RUNNER_CALL_ANCHOR = b"        runner_result = runner.main(borrowed)\n"
_WRITE_ANCHOR = b"        _r7_write_pending_result_frame(phase_sink)\n"


class RoutePhaseObserverBlocked(ValueError):
    """A pinned source or finite observation contract failed closed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, reason: str) -> None:
    if not value:
        raise RoutePhaseObserverBlocked(reason)


def _r7_source() -> bytes:
    path = Path(_R7.__file__).resolve()
    _check(path.name == R7_FILENAME, "r7_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(MAX_RUNNER_BYTES + 1)
    except BaseException:
        raise RoutePhaseObserverBlocked("r7_source_read") from None
    _check(0 < len(raw) <= MAX_RUNNER_BYTES, "r7_source_size")
    _check(_sha(raw) == R7_SHA256, "r7_source_digest")
    return raw


_R7_SOURCE = _r7_source()


_PHASE_OBSERVER_SOURCE = r'''
import threading as _r8_threading
import types as _types

_R8_PHASE_PREFIX = b"M01R8:"
_R8_PHASE_MAX_BYTES = 24
_R8_EXCEPTION_CODES = {
    ValueError: 0,
    TypeError: 1,
    OSError: 2,
    RuntimeError: 3,
    KeyError: 4,
    AssertionError: 5,
    ImportError: 6,
    NameError: 7,
    TimeoutError: 8,
}
_R8_EXCEPTION_NAMES = {
    0: "VALUE_ERROR",
    1: "TYPE_ERROR",
    2: "OS_ERROR",
    3: "RUNTIME_ERROR",
    4: "KEY_ERROR",
    5: "ASSERTION_ERROR",
    6: "IMPORT_ERROR",
    7: "NAME_ERROR",
    8: "TIMEOUT_ERROR",
    255: "OTHER",
}


class _R8PhaseState:
    __slots__ = (
        "enabled", "valid", "frozen", "thread_id", "events", "category",
        "original_outer", "original_parse", "original_main", "outer_hook",
        "parse_hook", "main_hook", "frame",
    )

    def __init__(self, enabled=False):
        self.enabled = enabled
        self.valid = enabled
        self.frozen = False
        self.thread_id = _r8_threading.get_ident()
        self.events = []
        self.category = None
        self.original_outer = None
        self.original_parse = None
        self.original_main = None
        self.outer_hook = None
        self.parse_hook = None
        self.main_hook = None
        self.frame = None

    def enter(self, stage):
        try:
            if not self.valid or self.frozen or _r8_threading.get_ident() != self.thread_id:
                self.valid = False
                return
            if len(self.events) >= 4:
                self.valid = False
                return
            if stage == "O" and self.events == []:
                self.events.append(("O", "E"))
                return
            if stage == "P" and self.events == [("O", "E"), ("O", "R")]:
                self.events.append(("P", "E"))
                return
            self.valid = False
        except BaseException:
            self.valid = False

    def leave(self, stage, error_type=None):
        try:
            if not self.valid or self.frozen or _r8_threading.get_ident() != self.thread_id:
                self.valid = False
                return
            expected = (stage, "E")
            if not self.events or self.events[-1] != expected or len(self.events) >= 4:
                self.valid = False
                return
            if error_type is None:
                self.events.append((stage, "R"))
            else:
                self.events.append((stage, "X"))
                self.category = _R8_EXCEPTION_CODES.get(error_type, 255)
        except BaseException:
            self.valid = False


def _r8_code_matches(actual, expected):
    if not isinstance(actual, _types.CodeType) or not isinstance(expected, _types.CodeType):
        return False
    fields = (
        "co_argcount", "co_posonlyargcount", "co_kwonlyargcount", "co_nlocals",
        "co_stacksize", "co_flags", "co_code", "co_consts", "co_names",
        "co_varnames", "co_freevars", "co_cellvars", "co_firstlineno",
        "co_linetable", "co_exceptiontable",
    )
    return all(getattr(actual, name, None) == getattr(expected, name, None) for name in fields)


def _r8_original_functions(once, once_raw, runner):
    manifest = getattr(runner, "MANIFEST", None)
    metadata = manifest.get("once") if type(manifest) is dict else None
    path = metadata.get("path") if type(metadata) is dict else None
    digest = metadata.get("sha256") if type(metadata) is dict else None
    if (
        type(path) is not str
        or not path
        or type(digest) is not str
        or _sha(once_raw) != digest
        or getattr(once, "__file__", None) != path
    ):
        return None
    spec = getattr(once, "__spec__", None)
    if getattr(spec, "origin", None) != path:
        return None
    try:
        module_code = compile(once_raw, path, "exec", dont_inherit=True)
    except BaseException:
        return None
    expected = {}
    for value in module_code.co_consts:
        if isinstance(value, _types.CodeType) and value.co_name in {
            "_outer_response", "_parse_outer_response", "main"
        }:
            if value.co_name in expected:
                return None
            expected[value.co_name] = value
    originals = []
    for name in ("_outer_response", "_parse_outer_response", "main"):
        function = getattr(once, name, None)
        code = expected.get(name)
        if (
            not callable(function)
            or code is None
            or getattr(function, "__globals__", None) is not getattr(once, "__dict__", None)
            or getattr(function, "__module__", None) != getattr(once, "__name__", None)
            or not _r8_code_matches(getattr(function, "__code__", None), code)
        ):
            return None
        if name in {"_outer_response", "_parse_outer_response"}:
            if getattr(function, "__defaults__", None) is not None or getattr(
                function, "__kwdefaults__", None
            ) is not None:
                return None
        elif (
            getattr(function, "__defaults__", None) is not None
            or getattr(function, "__kwdefaults__", None)
            != {"root_review_bytes": None, "output": None}
        ):
            return None
        originals.append(function)
    return originals[0], originals[1], originals[2]


def _r8_install_phase_observer(once, once_raw, runner, phase_sink):
    state = _R8PhaseState(enabled=True)
    try:
        originals = _r8_original_functions(once, once_raw, runner)
    except BaseException:
        originals = None
    if originals is None or getattr(phase_sink, "_r8_state", None) is not None:
        state.valid = False
        return state
    state.original_outer, state.original_parse, state.original_main = originals

    def outer_hook(*args, **kwargs):
        state.enter("O")
        try:
            value = state.original_outer(*args, **kwargs)
        except BaseException as error:
            state.leave("O", type(error))
            raise
        state.leave("O")
        return value

    def parse_hook(*args, **kwargs):
        state.enter("P")
        try:
            value = state.original_parse(*args, **kwargs)
        except BaseException as error:
            state.leave("P", type(error))
            raise
        state.leave("P")
        return value

    def main_hook(*args, **kwargs):
        try:
            return state.original_main(*args, **kwargs)
        finally:
            _r8_freeze_and_restore(state, once, phase_sink)

    state.outer_hook = outer_hook
    state.parse_hook = parse_hook
    state.main_hook = main_hook
    changed_outer = False
    try:
        once._outer_response = outer_hook
        changed_outer = True
        once._parse_outer_response = parse_hook
        once.main = main_hook
        if (
            once._outer_response is not outer_hook
            or once._parse_outer_response is not parse_hook
            or once.main is not main_hook
        ):
            raise RuntimeError("hook_binding")
        phase_sink._r8_state = state
    except BaseException:
        state.valid = False
        if changed_outer:
            try:
                once._outer_response = state.original_outer
            except BaseException:
                pass
        try:
            once._parse_outer_response = state.original_parse
        except BaseException:
            pass
        try:
            once.main = state.original_main
        except BaseException:
            pass
    return state


def _r8_freeze_and_restore(state, once, phase_sink):
    if not isinstance(state, _R8PhaseState) or state.frozen:
        return
    try:
        if getattr(once, "_outer_response", None) is state.outer_hook:
            once._outer_response = state.original_outer
        else:
            state.valid = False
        if getattr(once, "_parse_outer_response", None) is state.parse_hook:
            once._parse_outer_response = state.original_parse
        else:
            state.valid = False
        if getattr(once, "main", None) is state.main_hook:
            once.main = state.original_main
        else:
            state.valid = False
        if (
            getattr(once, "_outer_response", None) is not state.original_outer
            or getattr(once, "_parse_outer_response", None) is not state.original_parse
            or getattr(once, "main", None) is not state.original_main
        ):
            state.valid = False
    except BaseException:
        state.valid = False
    state.frozen = True
    if not state.valid:
        return
    events = state.events
    if events == [("O", "E"), ("O", "X")]:
        if state.category is not None:
            sequence = b"OEOX:"
        else:
            return
    elif events == [("O", "E"), ("O", "R"), ("P", "E"), ("P", "X")]:
        if state.category is not None:
            sequence = b"OEORPEPX:"
        else:
            return
    elif events == [("O", "E"), ("O", "R"), ("P", "E"), ("P", "R")]:
        if state.category is not None:
            return
        sequence = b"OEORPEPR"
    else:
        return
    category = ("%02x" % state.category).encode("ascii") if state.category is not None else b""
    if sequence.endswith(b":"):
        frame = _R8_PHASE_PREFIX + sequence + category + b"\n"
    else:
        frame = _R8_PHASE_PREFIX + sequence + b"\n"
    if 0 < len(frame) <= _R8_PHASE_MAX_BYTES:
        state.frame = frame
        try:
            phase_sink._r8_phase_frame = frame
        except BaseException:
            state.frame = None


def _r8_write_pending_phase_frame(phase_sink):
    state = getattr(phase_sink, "_r8_state", None)
    frame = getattr(phase_sink, "_r8_phase_frame", None)
    if (
        not isinstance(state, _R8PhaseState)
        or state.frozen is not True
        or state.valid is not True
        or type(frame) is not bytes
        or len(frame) > _R8_PHASE_MAX_BYTES
        or getattr(phase_sink, "_closed", False) is not True
        or getattr(phase_sink, "_broken", True) is not False
    ):
        return
    stream = getattr(phase_sink, "_stream", None)
    if stream is None:
        return
    try:
        stream.write(frame)
        flush = getattr(stream, "flush", None)
        if callable(flush):
            flush()
    except BaseException:
        try:
            phase_sink._broken = True
        except BaseException:
            return


def _r8_unobserved_phase():
    return {
        "schema": "iteration41.okx.m01.r33.outer-route-phase.r8.r1.v1",
        "status": "UNOBSERVED",
        "stage": "UNOBSERVED",
        "outer_response": "UNOBSERVED",
        "parse_outer_response": "UNOBSERVED",
        "exception_category": "UNOBSERVED",
        "verification": "UNVERIFIED",
        "authority": False,
        "provider_activity": "UNOBSERVED",
    }


def _r8_parse_phase_frame(raw):
    if (
        type(raw) is not bytes
        or len(raw) > PHASE_MAX_BYTES
        or not raw.startswith(PHASE_PREFIX)
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
        or b"\r" in raw
    ):
        return _r8_unobserved_phase()
    body = raw[len(PHASE_PREFIX):-1]
    categories = {
        b"00": "VALUE_ERROR",
        b"01": "TYPE_ERROR",
        b"02": "OS_ERROR",
        b"03": "RUNTIME_ERROR",
        b"04": "KEY_ERROR",
        b"05": "ASSERTION_ERROR",
        b"06": "IMPORT_ERROR",
        b"07": "NAME_ERROR",
        b"08": "TIMEOUT_ERROR",
        b"ff": "OTHER",
    }
    outer = "UNOBSERVED"
    parser = "UNOBSERVED"
    category = "NONE"
    stage = "COMPLETED"
    if body == b"OEORPEPR":
        outer, parser = "RETURNED", "RETURNED"
    elif body.startswith(b"OEOX:") and _HEX2.fullmatch(body[5:]) is not None:
        category = categories.get(body[5:])
        if category is None:
            return _r8_unobserved_phase()
        outer, parser, stage = "RAISED", "NOT_REACHED", "OUTER_RESPONSE"
    elif body.startswith(b"OEORPEPX:") and _HEX2.fullmatch(body[9:]) is not None:
        category = categories.get(body[9:])
        if category is None:
            return _r8_unobserved_phase()
        outer, parser, stage = "RETURNED", "RAISED", "PARSE_OUTER_RESPONSE"
    else:
        return _r8_unobserved_phase()
    return {
        "schema": "iteration41.okx.m01.r33.outer-route-phase.r8.r1.v1",
        "status": "OBSERVED_FIXED_STAGE",
        "stage": stage,
        "outer_response": outer,
        "parse_outer_response": parser,
        "exception_category": category,
        "verification": "POSTCAPTURE_RELEASE_GATED_UNVERIFIED",
        "authority": False,
        "provider_activity": "UNOBSERVED",
    }
'''.lstrip()


_RUNNER_LOADER_SOURCE = r'''
def _r8_install_runner_loader(runner, phase_sink):
    original = getattr(runner, "_load_once", None)
    state = {"original": original, "hook": None, "calls": 0, "phase": None}
    if not callable(original):
        state["valid"] = False
        return state
    state["valid"] = True

    def loader(raw):
        state["calls"] += 1
        once = original(raw)
        if state["calls"] != 1:
            state["valid"] = False
            phase = state.get("phase")
            if isinstance(phase, _R8PhaseState):
                phase.valid = False
            return once
        phase = _r8_install_phase_observer(once, raw, runner, phase_sink)
        state["phase"] = phase
        return once

    state["hook"] = loader
    try:
        runner._load_once = loader
        if runner._load_once is not loader:
            state["valid"] = False
    except BaseException:
        state["valid"] = False
    return state


def _r8_restore_runner_loader(runner, state):
    if type(state) is not dict:
        return
    original = state.get("original")
    hook = state.get("hook")
    try:
        if getattr(runner, "_load_once", None) is hook:
            runner._load_once = original
        else:
            state["valid"] = False
        if getattr(runner, "_load_once", None) is not original:
            state["valid"] = False
    except BaseException:
        state["valid"] = False
    if not state.get("valid", False):
        phase = state.get("phase")
        if isinstance(phase, _R8PhaseState):
            phase.valid = False
'''.lstrip()


def compose_bootstrap(r7_raw: Optional[bytes] = None) -> bytes:
    """Append the R8 observer to the exact R7 composition at fixed anchors."""
    expected = _R7.compose_bootstrap()
    if r7_raw is None:
        r7_raw = expected
    _check(type(r7_raw) is bytes and r7_raw == expected, "r7_bootstrap_binding")
    _check(r7_raw.count(_RUNNER_CALL_ANCHOR) == 1, "runner_call_anchor")
    _check(r7_raw.count(_WRITE_ANCHOR) == 1, "phase_write_anchor")
    _check(r7_raw.count(_MAIN_GUARD) == 1, "main_guard_anchor")
    source = r7_raw.replace(
        _RUNNER_CALL_ANCHOR,
        b"        _r8_loader_state = _r8_install_runner_loader(runner, phase_sink)\n"
        + b"        try:\n"
        + b"            runner_result = runner.main(borrowed)\n"
        + b"        finally:\n"
        + b"            _r8_restore_runner_loader(runner, _r8_loader_state)\n",
        1,
    )
    source = source.replace(
        _WRITE_ANCHOR,
        _WRITE_ANCHOR + b"        _r8_write_pending_phase_frame(phase_sink)\n",
        1,
    )
    definitions = _PHASE_OBSERVER_SOURCE + "\n" + _RUNNER_LOADER_SOURCE
    source = source.replace(_MAIN_GUARD, b"\n" + definitions.encode("ascii") + _MAIN_GUARD, 1)
    _check(len(source) <= MAX_BOOTSTRAP_BYTES, "bootstrap_size")
    try:
        compile(source, "<m01-r8-composed-bootstrap>", "exec", dont_inherit=True)
    except BaseException:
        raise RoutePhaseObserverBlocked("bootstrap_compile") from None
    return source


def _runner_once_binding(runner_raw: bytes) -> tuple[str, str]:
    _check(type(runner_raw) is bytes and 0 < len(runner_raw) <= MAX_RUNNER_BYTES, "runner_source_size")
    try:
        tree = ast.parse(runner_raw)
    except BaseException:
        raise RoutePhaseObserverBlocked("runner_source_parse") from None
    assignments = [
        node
        for node in tree.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "MANIFEST" for target in node.targets)
    ]
    _check(len(assignments) == 1, "runner_manifest_assignment")
    value = assignments[0].value
    _check(
        isinstance(value, ast.Call)
        and isinstance(value.func, ast.Attribute)
        and isinstance(value.func.value, ast.Name)
        and value.func.value.id == "json"
        and value.func.attr == "loads"
        and len(value.args) == 1
        and isinstance(value.args[0], ast.Constant)
        and type(value.args[0].value) is str,
        "runner_manifest_literal",
    )
    try:
        manifest = json.loads(value.args[0].value)
    except BaseException:
        raise RoutePhaseObserverBlocked("runner_manifest_json") from None
    once = manifest.get("once") if type(manifest) is dict else None
    path = once.get("path") if type(once) is dict else None
    digest = once.get("sha256") if type(once) is dict else None
    _check(
        type(path) is str
        and path
        and type(digest) is str
        and re.fullmatch(r"[0-9a-f]{64}", digest),
        "runner_once_binding",
    )
    return path, digest


def _unobserved_route_phase() -> dict[str, Any]:
    return {
        "schema": RESULT_SCHEMA,
        "status": "UNOBSERVED",
        "stage": "UNOBSERVED",
        "outer_response": "UNOBSERVED",
        "parse_outer_response": "UNOBSERVED",
        "exception_category": "UNOBSERVED",
        "verification": "UNVERIFIED",
        "authority": False,
        "provider_activity": "UNOBSERVED",
    }


def _parse_route_phase_frame(raw: Any) -> dict[str, Any]:
    if (
        type(raw) is not bytes
        or len(raw) > PHASE_MAX_BYTES
        or not raw.startswith(PHASE_PREFIX)
        or not raw.endswith(b"\n")
        or raw.count(b"\n") != 1
        or b"\r" in raw
    ):
        return _unobserved_route_phase()
    body = raw[len(PHASE_PREFIX) : -1]
    categories = {
        b"00": "VALUE_ERROR",
        b"01": "TYPE_ERROR",
        b"02": "OS_ERROR",
        b"03": "RUNTIME_ERROR",
        b"04": "KEY_ERROR",
        b"05": "ASSERTION_ERROR",
        b"06": "IMPORT_ERROR",
        b"07": "NAME_ERROR",
        b"08": "TIMEOUT_ERROR",
        b"ff": "OTHER",
    }
    outer = "UNOBSERVED"
    parser = "UNOBSERVED"
    category = "NONE"
    stage = "COMPLETED"
    if body == b"OEORPEPR":
        outer, parser = "RETURNED", "RETURNED"
    elif body.startswith(b"OEOX:") and _HEX2.fullmatch(body[5:]) is not None:
        category = categories.get(body[5:])
        if category is None:
            return _unobserved_route_phase()
        outer, parser, stage = "RAISED", "NOT_REACHED", "OUTER_RESPONSE"
    elif body.startswith(b"OEORPEPX:") and _HEX2.fullmatch(body[9:]) is not None:
        category = categories.get(body[9:])
        if category is None:
            return _unobserved_route_phase()
        outer, parser, stage = "RETURNED", "RAISED", "PARSE_OUTER_RESPONSE"
    else:
        return _unobserved_route_phase()
    return {
        "schema": RESULT_SCHEMA,
        "status": "OBSERVED_FIXED_STAGE",
        "stage": stage,
        "outer_response": outer,
        "parse_outer_response": parser,
        "exception_category": category,
        "verification": "POSTCAPTURE_RELEASE_GATED_UNVERIFIED",
        "authority": False,
        "provider_activity": "UNOBSERVED",
    }


def _from_r7(prepared_r7: Any):
    _R7._validate_prepared(prepared_r7)
    once_path, once_sha256 = _runner_once_binding(prepared_r7.runner_bytes)
    bootstrap = compose_bootstrap(prepared_r7.bootstrap_bytes)
    command = tuple(prepared_r7.command[:-1]) + (bootstrap.decode("utf-8"),)
    binding = dict(prepared_r7.binding)
    binding.update(
        {
            "schema": "iteration41.okx.m01.r33.prepared-child-binding.r8.r1.outer-route-phase.v1",
            "bootstrap_sha256": _sha(bootstrap),
            "bootstrap_variant": "r7-exact-r28-response-boundary-observer-r8-r1.v1",
            "r7_bootstrap_sha256": _sha(prepared_r7.bootstrap_bytes),
            "phase_schema": RESULT_SCHEMA,
            "phase_prefix": PHASE_PREFIX.decode("ascii"),
            "phase_max_bytes": PHASE_MAX_BYTES,
            "observed_once_path": once_path,
            "observed_once_sha256": once_sha256,
            "max_observed_calls": 2,
        }
    )
    digest = _R6._canonical_binding_digest(binding, command, prepared_r7.cwd)
    return dataclasses.replace(
        prepared_r7,
        command=command,
        bootstrap_bytes=bootstrap,
        binding=binding,
        binding_sha256=digest,
    )


def _validate_prepared(value: Any) -> None:
    _check(type(value) is _R6.PreparedM01Child, "prepared_child_type")
    try:
        expected_r7 = _R7._from_r5(value.r5_prepared)
        expected = _from_r7(expected_r7)
    except BaseException:
        raise RoutePhaseObserverBlocked("prepared_child_source") from None
    _check(
        value.command == expected.command
        and value.cwd == expected.cwd
        and value.environment == expected.environment
        and value.stdin_descriptor == expected.stdin_descriptor
        and value.source_map_bytes == expected.source_map_bytes
        and value.runner_bytes == expected.runner_bytes
        and value.bootstrap_bytes == expected.bootstrap_bytes
        and value.binding == expected.binding
        and value.binding_sha256 == expected.binding_sha256
        and value.plan_disposition == expected.plan_disposition,
        "prepared_child_binding",
    )


def prepare_r33_child(
    prepared_r31: Any,
    root_metadata: Any,
    *,
    environment: Optional[dict[str, str]] = None,
):
    """Compose R8 only over the frozen R7 preparation; authority stays held."""
    prepared_r7 = _R7.prepare_r33_child(
        prepared_r31, root_metadata, environment=environment
    )
    return _from_r7(prepared_r7)


class M01WindowsParentAdapter(_R7.M01WindowsParentAdapter):
    """R7 supervisor with a post-release R8 fixed phase projection."""

    def __init__(self, prepared_child: Any, **kwargs: Any):
        _validate_prepared(prepared_child)
        prepared_r7 = _R7._from_r5(prepared_child.r5_prepared)
        super().__init__(prepared_r7, **kwargs)
        base = prepared_child.r5_prepared
        r4_prepared = dataclasses.replace(
            base,
            command=prepared_child.command,
            bootstrap_bytes=prepared_child.bootstrap_bytes,
            binding=dict(prepared_child.binding),
            binding_sha256=prepared_child.binding_sha256,
        )
        internal = _R6._r2_prepared(self._r5, prepared_child)
        self._r5.prepared = r4_prepared
        self._r5._base.prepared = r4_prepared
        self._r5._base._r2_prepared = internal
        self._r5._inner.prepared = internal
        self.prepared = prepared_child

    def _project_r7_parent_result(self, result: Any):
        result_type = self._r5._inner._r32.ParentEnvelopeResult
        _check(type(result) is result_type, "parent_result_type")
        if _R6._safe_to_read_phase(result):
            summary = self._r5.summarize_result(result)
            runner_result, phase, route_phase = _parse_parent_frames(
                result.stderr, self.prepared.runner_bytes
            )
        else:
            summary = {
                "schema": result.schema,
                "status": result.status,
                "reason": result.reason,
                "cleanup_reason": result.cleanup_reason,
                "child_returncode": result.child_returncode,
                "capture_complete": result.capture_complete,
                "cleanup_complete": result.cleanup_complete,
                "scope_released": result.scope_released,
                "scope_retained": result.scope_retained,
                "stdout_bytes": None,
                "stderr_bytes": None,
                "authority": False,
                "strict_cases_passed": 0,
            }
            runner_result = _R7._unobserved_result()
            phase = _R6._unobserved_phase()
            route_phase = _unobserved_route_phase()
        phase = dict(phase)
        phase["runner_result"] = runner_result
        phase["outer_route_phase"] = route_phase
        return _R6.M01ParentDiagnosticResult(
            schema=summary["schema"],
            status=summary["status"],
            reason=summary["reason"],
            cleanup_reason=summary["cleanup_reason"],
            child_returncode=summary["child_returncode"],
            capture_complete=summary["capture_complete"],
            cleanup_complete=summary["cleanup_complete"],
            scope_released=summary["scope_released"],
            scope_retained=summary["scope_retained"],
            stdout_bytes=summary["stdout_bytes"],
            stderr_bytes=summary["stderr_bytes"],
            child_phase=phase,
        )

    def summarize_result(self, result: Any) -> dict[str, Any]:
        result_type = self._r5._inner._r32.ParentEnvelopeResult
        if type(result) is _R6.M01ParentDiagnosticResult:
            return {
                "schema": result.schema,
                "status": result.status,
                "reason": result.reason,
                "cleanup_reason": result.cleanup_reason,
                "child_returncode": result.child_returncode,
                "capture_complete": result.capture_complete,
                "cleanup_complete": result.cleanup_complete,
                "scope_released": result.scope_released,
                "scope_retained": result.scope_retained,
                "stdout_bytes": result.stdout_bytes,
                "stderr_bytes": result.stderr_bytes,
                "authority": False,
                "strict_cases_passed": 0,
                "child_phase": dict(result.child_phase),
            }
        _check(type(result) is result_type, "parent_result_type")
        return self.summarize_result(self._project_r7_parent_result(result))


def _parse_parent_frames(raw: Any, runner_raw: bytes):
    unobserved = _unobserved_route_phase()
    result_unobserved = _R7._unobserved_result()
    maximum = _R6.MAX_PHASE_FRAME_BYTES + _R7.RESULT_MAX_BYTES + PHASE_MAX_BYTES
    if type(raw) is not bytes or len(raw) > maximum or not raw.endswith(b"\n"):
        return result_unobserved, _R6._unobserved_phase(), unobserved
    lines = raw.splitlines(keepends=True)
    if len(lines) == 2:
        phase_line, second_line = lines
        if second_line.startswith(_R7.RESULT_PREFIX):
            r7_line, r8_line = second_line, None
        elif second_line.startswith(PHASE_PREFIX):
            r7_line, r8_line = None, second_line
        else:
            return result_unobserved, _R6._unobserved_phase(), unobserved
    elif len(lines) == 3:
        phase_line, r7_line, r8_line = lines
    else:
        return result_unobserved, _R6._unobserved_phase(), unobserved
    phase = _R6._parse_phase_frame(phase_line)
    if phase.get("status") != "OBSERVED_FIXED_STAGE":
        return result_unobserved, _R6._unobserved_phase(), unobserved
    runner_result = result_unobserved
    if r7_line is not None:
        if not r7_line.startswith(_R7.RESULT_PREFIX):
            return result_unobserved, _R6._unobserved_phase(), unobserved
        runner_result = _R7._parse_result_frame(r7_line, runner_raw)
        if runner_result.get("status") != "OBSERVED_FIXED_RESULT":
            return result_unobserved, _R6._unobserved_phase(), unobserved
        if phase.get("stage") != "RUNNER_RESULT_UNSAFE":
            return result_unobserved, _R6._unobserved_phase(), unobserved
    route_phase = _parse_route_phase_frame(r8_line) if r8_line is not None else unobserved
    return runner_result, phase, route_phase


if __name__ == "__main__":
    raise SystemExit("Use prepare_r33_child() with the exact prepared R31 result.")
