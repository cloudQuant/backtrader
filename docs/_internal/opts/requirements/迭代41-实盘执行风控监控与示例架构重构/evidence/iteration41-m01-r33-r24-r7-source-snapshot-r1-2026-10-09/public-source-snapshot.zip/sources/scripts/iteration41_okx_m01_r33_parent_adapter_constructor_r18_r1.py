"""Reconstruct R17's exact outer while the frozen R14 adapter validates it.

R18 is a one-call constructor boundary. It freshly checks the supplied R17
result, temporarily restores the exact R17 source transform around the real
R14 adapter constructor, and restores the frozen R13 functions on every exit.
It does not cache a validation result or change the 154-row child map.
"""

from __future__ import annotations

import dataclasses
import hashlib
import threading
import copy
from pathlib import Path
from typing import Any, Optional

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as _R13
from scripts import iteration41_okx_m01_r33_parent_adapter_transport_r14_r1 as _R14
from scripts import iteration41_okx_m01_r33_source_map_gate_r17_r1 as _R17


R18_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_parent_adapter_constructor_r18_r1.py"
R18_RESULT_SCHEMA = "iteration41.okx.m01.r33.parent-adapter-constructor-r18.r1.v1"
R18_SOURCE_ROLE = "r18_same_call_parent_adapter_constructor_source"
R18_MAX_SOURCE_BYTES = 2 * 1024 * 1024
R18_PINNED_R14_SHA256 = "fe2bd4fc008680fe5dc9099d0cb6782e4071070bf5ab259b53c3e763b6c413ef"
R18_PINNED_R17_SHA256 = "cb05433078bddcd779914c6eb0e9b99d942b3e1a55d5fb39e756928f3249fc5f"
R18_PINNED_R13_SHA256 = "23c98a7d0012499050309f3dcdd8cd8f2710698867654776125e8a3d9a1fe580"
R18_R17_OUTER_MARKER = b"iteration41.okx.m01.r33.held-runtime-source-map-gate-r17.r1.v1"
R18_ACTIVE_OUTER_FAILURE_CODES = frozenset({"prepared_recompose", "prepared_binding"})
R18_FAILURE_CODES = frozenset(
    {
        "r18_module_name",
        "r18_module_path",
        "r18_source_unavailable",
        "r18_source_size",
        "r18_source_binding",
        "r18_r17_result_type",
        "r18_r17_result_binding",
        "r18_r17_source_pin",
        "r18_r14_source_pin",
        "r18_r13_source_pin",
        "r18_prepared_r14_type",
        "r18_prepared_identity",
        "r18_runtime_map_path",
        "r18_runtime_map_binding",
        "r18_active_outer_binding",
        "r18_patch_context_busy",
        "r18_patch_owner_thread",
        "r18_patch_context_changed",
        "r18_recompose_count",
        "r18_outer_transform_count",
        "r18_adapter_type",
        "r18_adapter_binding",
        "r18_hold_binding",
        "r18_hold_schema",
        "r18_hold_path",
        "r18_hold_collision",
        "r18_hold_digest",
        "r18_child_map_count",
    }
)


class ParentAdapterConstructorR18Blocked(ValueError):
    """A fixed R18 source, adapter, temporary-transform, or hold gate failed."""

    def __init__(self, code: str):
        self.code = code if code in R18_FAILURE_CODES else "r18_adapter_binding"
        super().__init__(self.code)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ParentAdapterConstructorR18Blocked(code)


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R18_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r18_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R18_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r18_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R18_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ParentAdapterConstructorR18Blocked("r18_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R18_MAX_SOURCE_BYTES, "r18_source_size")
    return str(path), raw, _sha(raw)


@dataclasses.dataclass(frozen=True)
class R18ParentAdapterResult:
    """A real R14 adapter plus the exact source row used by its R18 check."""

    schema: str
    r17_result: Any
    adapter: Any
    r18_helper_path: str
    r18_helper_bytes: bytes
    r18_helper_sha256: str
    hold_addition: dict[str, Any]
    hold_addition_sha256: str
    r13_recompose_calls: int
    r13_outer_transform_calls: int
    authority: bool = False
    strict_cases_passed: int = 0
    case_result: bool = False

    @property
    def prepared_r13(self) -> Any:
        return self.r17_result.prepared_r13

    @property
    def prepared_r14(self) -> Any:
        return self.r17_result.prepared_r14


def _validated_inputs(r17_result: Any, r18_source: tuple[str, bytes, str]):
    _check(type(r17_result) is _R17.R17RootPreparedHold, "r18_r17_result_type")
    _check(_R17.verify_hold_addition(r17_result), "r18_r17_result_binding")
    r17_source = _R17._self_source()
    _check(r17_source[2] == R18_PINNED_R17_SHA256, "r18_r17_source_pin")
    _check(
        (r17_result.r17_helper_path, r17_result.r17_helper_bytes, r17_result.r17_helper_sha256)
        == r17_source,
        "r18_r17_result_binding",
    )
    _check(_sha(r18_source[1]) == r18_source[2], "r18_source_binding")
    r14_source = _R14._self_source()
    _check(r14_source[2] == R18_PINNED_R14_SHA256, "r18_r14_source_pin")
    r13_source = _R13._self_source()
    _check(r13_source[2] == R18_PINNED_R13_SHA256, "r18_r13_source_pin")
    _R17._verify_source_pins(r17_source)
    _check(_R17._R16._R14 is _R14, "r18_r14_source_pin")
    _check(_R13._compose is _R17._ORIGINAL_R13_COMPOSE, "r18_r13_source_pin")
    _check(
        _R13._active_outer_source is _R17._ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
        "r18_r13_source_pin",
    )
    _check(type(r17_result.prepared_r14) is _R14.PreparedM01Child, "r18_prepared_r14_type")
    _check(
        r17_result.prepared_r14.r13_prepared is r17_result.prepared_r13,
        "r18_prepared_identity",
    )
    base_r11 = r17_result.prepared_r13.base_r11_prepared
    runtime_map_path = _R17._runtime_source_map_path(base_r11)
    _check(
        runtime_map_path == r17_result.runtime_source_map_path,
        "r18_runtime_map_path",
    )
    _check(
        _sha(r17_result.prepared_r13.source_map_bytes)
        == r17_result.runtime_source_map_sha256,
        "r18_runtime_map_binding",
    )
    entries = r17_result.hold_addition["entries"]
    map_matches = [
        row
        for path, row in entries.items()
        if _R13._R10._R9._normalized(path) == _R13._R10._R9._normalized(runtime_map_path)
    ]
    expected_map_row = {
        "sha256": r17_result.runtime_source_map_sha256,
        "size_bytes": len(r17_result.prepared_r13.source_map_bytes),
        "role": _R17._R16._R15.R15_SOURCE_MAP_ROLE,
        "origin": "generated_from_exact_r13_binding:" + r17_result.prepared_r13.binding_sha256,
    }
    _check(map_matches == [expected_map_row], "r18_runtime_map_binding")
    active_outer = r17_result.prepared_r13.active_outer_source
    _check(
        type(active_outer) is bytes
        and _sha(active_outer) == r17_result.prepared_r13.transform_binding["active_outer_sha256"]
        and R18_R17_OUTER_MARKER in active_outer,
        "r18_active_outer_binding",
    )
    return r17_source, r14_source, base_r11, runtime_map_path


def _r18_add_hold_row(
    r17_result: Any,
    r18_source: tuple[str, bytes, str],
) -> tuple[dict[str, Any], str]:
    path, raw, digest = r18_source
    _check(_R13._R10._R9._absolute_windows_path(path), "r18_hold_path")
    addition = copy.deepcopy(r17_result.hold_addition)
    entries = dict(addition.get("entries", {}))
    normalized = {_R13._R10._R9._normalized(existing) for existing in entries}
    key = _R13._R10._R9._normalized(path)
    _check(key not in normalized, "r18_hold_collision")
    _check(type(raw) is bytes and _sha(raw) == digest, "r18_hold_digest")
    entries[path] = {
        "sha256": digest,
        "size_bytes": len(raw),
        "role": R18_SOURCE_ROLE,
        "origin": "repository_source:" + R18_RELATIVE_PATH,
    }
    addition["entries"] = dict(sorted(entries.items()))
    _check(addition.get("schema") == _R17._R16._R15.R15_HOLD_SCHEMA, "r18_hold_schema")
    _check(addition.get("canonical_child_map_count") == 154, "r18_child_map_count")
    return addition, _R17._sha(_R17._canonical_json(addition))


def construct_parent_adapter(
    r17_result: Any,
    *,
    adapter_kwargs: Optional[dict[str, Any]] = None,
) -> R18ParentAdapterResult:
    """Freshly recompose R17 bytes during the real R14 adapter constructor."""
    r18_source = _self_source()
    _check(_sha(r18_source[1]) == r18_source[2], "r18_source_binding")
    r17_source, _r14_source, base_r11, runtime_map_path = _validated_inputs(
        r17_result, r18_source
    )
    if not _R17._PATCH_LOCK.acquire(blocking=False):
        raise ParentAdapterConstructorR18Blocked("r18_patch_context_busy")

    owner = threading.get_ident()
    original_compose = _R13._compose
    original_outer = _R13._active_outer_source
    context = {"runtime_map_path": None, "compose_calls": 0, "outer_calls": 0}
    wrappers_installed = False
    wrappers_intact = True
    adapter = None
    operation_error: Optional[BaseException] = None
    kwargs = dict(adapter_kwargs or {})

    try:
        _check(
            original_compose is _R17._ORIGINAL_R13_COMPOSE
            and original_outer is _R17._ORIGINAL_R13_ACTIVE_OUTER_SOURCE,
            "r18_patch_context_changed",
        )

        def assert_owner() -> None:
            _check(
                threading.get_ident() == owner,
                "r18_patch_owner_thread",
            )
            _check(
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper,
                "r18_patch_context_changed",
            )

        def compose_wrapper(current_base_r11: Any) -> Any:
            assert_owner()
            current_path = _R17._runtime_source_map_path(current_base_r11)
            _check(current_path == runtime_map_path, "r18_runtime_map_path")
            prior = context["runtime_map_path"]
            _check(prior is None or prior == current_path, "r18_runtime_map_path")
            context["runtime_map_path"] = current_path
            context["compose_calls"] += 1
            return original_compose(current_base_r11)

        def outer_wrapper(*args: Any, **kwargs: Any) -> bytes:
            assert_owner()
            _check(context["runtime_map_path"] == runtime_map_path, "r18_runtime_map_path")
            context["outer_calls"] += 1
            base_outer = original_outer(*args, **kwargs)
            try:
                return _R17._apply_active_outer_transform(
                    base_outer,
                    runtime_map_path,
                    r17_source[0],
                    r17_source[2],
                    _R17._R17_OUTER_SUPPORT,
                )
            except BaseException:
                raise ParentAdapterConstructorR18Blocked("r18_active_outer_binding") from None

        _R13._compose = compose_wrapper
        _R13._active_outer_source = outer_wrapper
        wrappers_installed = True
        try:
            adapter = _R14.M01WindowsParentAdapter(
                r17_result.prepared_r14,
                **kwargs,
            )
        except BaseException as exc:
            operation_error = exc
    except BaseException as exc:
        operation_error = exc
    finally:
        if wrappers_installed:
            wrappers_intact = (
                _R13._compose is compose_wrapper
                and _R13._active_outer_source is outer_wrapper
            )
            _R13._compose = original_compose
            _R13._active_outer_source = original_outer
        _R17._PATCH_LOCK.release()

    if operation_error is not None:
        if type(operation_error) is _R13.ActiveOuterActivationBlocked:
            raise operation_error
        if type(operation_error) is _R14.ParentAdapterTransportBlocked:
            raise operation_error
        if type(operation_error) is ParentAdapterConstructorR18Blocked:
            raise operation_error
        raise ParentAdapterConstructorR18Blocked("r18_adapter_binding") from None
    _check(wrappers_intact, "r18_patch_context_changed")
    _check(type(adapter) is _R14.M01WindowsParentAdapter, "r18_adapter_type")
    _check(adapter.prepared is r17_result.prepared_r14, "r18_adapter_binding")
    _check(context["compose_calls"] == 1, "r18_recompose_count")
    _check(context["outer_calls"] == 1, "r18_outer_transform_count")
    hold_addition, hold_sha256 = _r18_add_hold_row(r17_result, r18_source)
    return R18ParentAdapterResult(
        schema=R18_RESULT_SCHEMA,
        r17_result=r17_result,
        adapter=adapter,
        r18_helper_path=r18_source[0],
        r18_helper_bytes=r18_source[1],
        r18_helper_sha256=r18_source[2],
        hold_addition=hold_addition,
        hold_addition_sha256=hold_sha256,
        r13_recompose_calls=context["compose_calls"],
        r13_outer_transform_calls=context["outer_calls"],
    )


def verify_parent_adapter_result(value: Any) -> bool:
    """Recheck source pins, adapter shape, and the mutable parent hold digest."""
    try:
        if type(value) is not R18ParentAdapterResult or value.schema != R18_RESULT_SCHEMA:
            return False
        r18_source = _self_source()
        if (value.r18_helper_path, value.r18_helper_bytes, value.r18_helper_sha256) != r18_source:
            return False
        if not _R17.verify_hold_addition(value.r17_result):
            return False
        if type(value.adapter) is not _R14.M01WindowsParentAdapter:
            return False
        if value.adapter.prepared is not value.r17_result.prepared_r14:
            return False
        if value.r13_recompose_calls != 1 or value.r13_outer_transform_calls != 1:
            return False
        if type(value.hold_addition) is not dict or value.hold_addition.get("canonical_child_map_count") != 154:
            return False
        if _R17._sha(_R17._canonical_json(value.hold_addition)) != value.hold_addition_sha256:
            return False
        expected_addition, expected_digest = _r18_add_hold_row(
            value.r17_result,
            (value.r18_helper_path, value.r18_helper_bytes, value.r18_helper_sha256),
        )
        if value.hold_addition != expected_addition or value.hold_addition_sha256 != expected_digest:
            return False
        entries = value.hold_addition.get("entries")
        if type(entries) is not dict:
            return False
        matches = [
            row for path, row in entries.items()
            if _R13._R10._R9._normalized(path) == _R13._R10._R9._normalized(value.r18_helper_path)
        ]
        return len(matches) == 1 and matches[0] == {
            "sha256": value.r18_helper_sha256,
            "size_bytes": len(value.r18_helper_bytes),
            "role": R18_SOURCE_ROLE,
            "origin": "repository_source:" + R18_RELATIVE_PATH,
        }
    except BaseException:
        return False
