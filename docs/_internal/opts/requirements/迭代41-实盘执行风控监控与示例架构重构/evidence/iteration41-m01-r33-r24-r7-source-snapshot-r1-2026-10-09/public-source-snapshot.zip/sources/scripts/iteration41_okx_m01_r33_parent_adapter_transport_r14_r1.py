"""R14 parent adapter that preserves the exact final R13 transport.

R14 reuses the frozen R13 preparation and the frozen R12 supervision chain.
It replaces only the stale R10 transport view passed during adapter wiring:
the nested R9/R8/R4/R6 objects receive R13's command, descriptor, source map,
runner, stub, sidecar metadata, binding and Windows command-line measurement.
R14 adds its own parent-held source pin and does not alter the canonical 154
child-map entries or the child binding used by source-scope authentication.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import threading
from pathlib import Path
from typing import Any

from scripts import iteration41_okx_m01_r33_active_outer_activation_r13_r1 as _R13


R14_RELATIVE_PATH = "scripts/iteration41_okx_m01_r33_parent_adapter_transport_r14_r1.py"
R14_PREPARED_SCHEMA = "iteration41.okx.m01.r33.parent-adapter-transport-r14.r1.v1"
R14_HOLD_SCHEMA = "iteration41.okx.m01.r33.parent-hold-addition-r14.r1.v1"
R14_SOURCE_ROLE = "r14_parent_adapter_transport_source"
R14_MAX_SOURCE_BYTES = 2 * 1024 * 1024


class ParentAdapterTransportBlocked(ValueError):
    """A fixed R14 source, prepared view, or held transport contract failed."""


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _check(value: Any, code: str) -> None:
    if not value:
        raise ParentAdapterTransportBlocked(code)


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("ascii")


def _self_source() -> tuple[str, bytes, str]:
    expected_name = R14_RELATIVE_PATH[:-3].replace("/", ".")
    _check(__name__ == expected_name, "r14_module_name")
    path = Path(__file__).resolve()
    root = Path(_R13._R10._repo_root()).resolve()
    expected_path = (root / Path(*R14_RELATIVE_PATH.split("/"))).resolve()
    _check(path == expected_path, "r14_module_path")
    try:
        with path.open("rb") as stream:
            raw = stream.read(R14_MAX_SOURCE_BYTES + 1)
    except BaseException:
        raise ParentAdapterTransportBlocked("r14_source_unavailable") from None
    _check(type(raw) is bytes and 0 < len(raw) <= R14_MAX_SOURCE_BYTES, "r14_source_size")
    return str(path), raw, _sha(raw)


def _adapter_binding(r13_prepared: Any, source: tuple[str, bytes, str]) -> dict[str, Any]:
    source_path, source_raw, source_sha256 = source
    _check(type(source_raw) is bytes and _sha(source_raw) == source_sha256, "r14_source_digest")
    return {
        "schema": R14_PREPARED_SCHEMA,
        "helper_path": source_path,
        "helper_sha256": source_sha256,
        "helper_size_bytes": len(source_raw),
        "helper_role": R14_SOURCE_ROLE,
        "r13_binding_sha256": r13_prepared.binding_sha256,
        "r13_command_sha256": _sha(_canonical_json(list(r13_prepared.command))),
        "r13_stdin_sha256": _sha(r13_prepared.stdin_descriptor),
        "r13_stdin_size_bytes": len(r13_prepared.stdin_descriptor),
        "r13_source_map_sha256": _sha(r13_prepared.source_map_bytes),
        "r13_source_map_size_bytes": len(r13_prepared.source_map_bytes),
        "r13_runner_sha256": _sha(r13_prepared.runner_bytes),
        "r13_runner_size_bytes": len(r13_prepared.runner_bytes),
        "r13_stub_sha256": _sha(r13_prepared.stub_bytes),
        "r13_stub_size_bytes": len(r13_prepared.stub_bytes),
        "r13_sidecar_path": r13_prepared.sidecar_path,
        "r13_sidecar_sha256": r13_prepared.sidecar_sha256,
        "r13_sidecar_size_bytes": r13_prepared.sidecar_size_bytes,
        "r13_windows_command_line_units": r13_prepared.windows_command_line_units,
    }


def _binding_sha256(binding: dict[str, Any]) -> str:
    return _sha(_canonical_json(binding))


@dataclasses.dataclass(frozen=True)
class PreparedM01Child:
    """R14's source pin bound to one exact, unchanged R13 prepared child."""

    r13_prepared: Any
    helper_path: str
    helper_bytes: bytes
    helper_sha256: str
    adapter_binding: dict[str, Any]
    adapter_binding_sha256: str

    def __getattr__(self, name: str) -> Any:
        # The child command/binding remain the R13 values. R14's helper binding
        # is deliberately separate and is never substituted for that authority.
        return getattr(self.r13_prepared, name)


def prepare_from_r13(prepared_r13: Any) -> PreparedM01Child:
    _R13._validate_prepared(prepared_r13)
    source = _self_source()
    binding = _adapter_binding(prepared_r13, source)
    return PreparedM01Child(
        r13_prepared=prepared_r13,
        helper_path=source[0],
        helper_bytes=source[1],
        helper_sha256=source[2],
        adapter_binding=binding,
        adapter_binding_sha256=_binding_sha256(binding),
    )


def _validate_prepared(value: Any) -> None:
    _check(type(value) is PreparedM01Child, "r14_prepared_type")
    _R13._validate_prepared(value.r13_prepared)
    source = _self_source()
    _check(
        value.helper_path == source[0]
        and value.helper_bytes == source[1]
        and value.helper_sha256 == source[2],
        "r14_helper_source_binding",
    )
    expected = _adapter_binding(value.r13_prepared, source)
    _check(
        value.adapter_binding == expected
        and value.adapter_binding_sha256 == _binding_sha256(expected),
        "r14_adapter_binding",
    )


def parent_hold_addition(prepared: PreparedM01Child) -> dict[str, Any]:
    """Extend the exact R13 parent hold with this adapter's source bytes."""
    _validate_prepared(prepared)
    base = _R13.parent_hold_addition(prepared.r13_prepared)
    _check(
        base.get("canonical_child_map_count") == 154
        and base.get("schema") == _R13.R13_HOLD_SCHEMA,
        "r14_r13_parent_hold",
    )
    entries = dict(base["entries"])
    normalized = {_R13._R10._R9._normalized(path) for path in entries}
    _check(_R13._R10._R9._absolute_windows_path(prepared.helper_path), "r14_hold_path")
    key = _R13._R10._R9._normalized(prepared.helper_path)
    _check(key not in normalized, "r14_hold_collision")
    _check(
        type(prepared.helper_bytes) is bytes
        and len(prepared.helper_bytes) == prepared.adapter_binding["helper_size_bytes"]
        and _sha(prepared.helper_bytes) == prepared.helper_sha256,
        "r14_hold_digest",
    )
    entries[prepared.helper_path] = {
        "sha256": prepared.helper_sha256,
        "size_bytes": len(prepared.helper_bytes),
        "role": R14_SOURCE_ROLE,
        "origin": "repository_source:" + R14_RELATIVE_PATH,
    }
    result = dict(base)
    result.update(
        {
            "schema": R14_HOLD_SCHEMA,
            "r13_hold_schema": base["schema"],
            "r13_binding_sha256": prepared.r13_prepared.binding_sha256,
            "r14_binding_sha256": prepared.adapter_binding_sha256,
            "r14_helper_path": prepared.helper_path,
            "r14_helper_sha256": prepared.helper_sha256,
            "r14_helper_size_bytes": len(prepared.helper_bytes),
            "r14_helper_role": R14_SOURCE_ROLE,
            "canonical_child_map_count": 154,
            "entries": dict(sorted(entries.items())),
        }
    )
    return result


def verify_parent_hold_addition(prepared: PreparedM01Child, value: Any) -> bool:
    try:
        return type(value) is dict and value == parent_hold_addition(prepared)
    except BaseException:
        return False


def _verify_rebound_chain(adapter: Any, prepared_r13: Any) -> None:
    expected = {
        "command": prepared_r13.command,
        "descriptor_json": prepared_r13.descriptor_json,
        "stdin_descriptor": prepared_r13.stdin_descriptor,
        "source_map_bytes": prepared_r13.source_map_bytes,
        "runner_bytes": prepared_r13.runner_bytes,
        "stub_bytes": prepared_r13.stub_bytes,
        "sidecar_path": prepared_r13.sidecar_path,
        "sidecar_sha256": prepared_r13.sidecar_sha256,
        "sidecar_size_bytes": prepared_r13.sidecar_size_bytes,
        "binding": prepared_r13.binding,
        "binding_sha256": prepared_r13.binding_sha256,
        "windows_command_line_units": prepared_r13.windows_command_line_units,
    }
    r9_adapter = adapter._r12._r11._r10._r9
    r9_view = r9_adapter.prepared
    for name, value in expected.items():
        _check(getattr(r9_view, name, None) == value, "r14_nested_r9_" + name)

    r8_adapter = adapter._r12._r8_adapter
    _check(r8_adapter.prepared.runner_bytes == prepared_r13.runner_bytes, "r14_nested_r8_runner")
    r4_view = r8_adapter._r5.prepared
    for name, value in (
        ("command", prepared_r13.command),
        ("stdin_descriptor", prepared_r13.stdin_descriptor),
        ("source_map_bytes", prepared_r13.source_map_bytes),
        ("runner_bytes", prepared_r13.runner_bytes),
        ("bootstrap_bytes", prepared_r13.stub_bytes),
        ("binding", prepared_r13.binding),
        ("binding_sha256", prepared_r13.binding_sha256),
    ):
        _check(getattr(r4_view, name, None) == value, "r14_nested_r4_" + name)
    r2_view = r8_adapter._r5._base._r2_prepared
    for name, value in (
        ("command", prepared_r13.command),
        ("stdin_descriptor", prepared_r13.stdin_descriptor),
        ("source_map_bytes", prepared_r13.source_map_bytes),
        ("runner_bytes", prepared_r13.runner_bytes),
        ("bootstrap_bytes", prepared_r13.stub_bytes),
        ("binding", prepared_r13.binding),
        ("binding_sha256", prepared_r13.binding_sha256),
    ):
        _check(getattr(r2_view, name, None) == value, "r14_nested_r2_" + name)


class M01WindowsParentAdapter:
    """R12 supervisor with the exact final R13 transport rebound before use."""

    def __init__(self, prepared_child: PreparedM01Child, **kwargs: Any):
        _validate_prepared(prepared_child)
        self.prepared = prepared_child
        prepared_r13 = prepared_child.r13_prepared
        self._r12 = _R13._R12.M01WindowsParentAdapter(
            prepared_r13.base_r12_prepared, **kwargs
        )
        runtime_view = dataclasses.replace(
            prepared_r13.r10_prepared,
            command=prepared_r13.command,
            descriptor_json=prepared_r13.descriptor_json,
            stdin_descriptor=prepared_r13.stdin_descriptor,
            source_map_bytes=prepared_r13.source_map_bytes,
            runner_bytes=prepared_r13.runner_bytes,
            stub_bytes=prepared_r13.stub_bytes,
            sidecar_path=prepared_r13.sidecar_path,
            sidecar_sha256=prepared_r13.sidecar_sha256,
            sidecar_size_bytes=prepared_r13.sidecar_size_bytes,
            binding=dict(prepared_r13.binding),
            binding_sha256=prepared_r13.binding_sha256,
            windows_command_line_units=prepared_r13.windows_command_line_units,
        )
        _R13._R10._rebind_r9_adapter(self._r12._r11._r10._r9, runtime_view)
        self._r8_adapter = self._r12._r8_adapter
        _verify_rebound_chain(self, prepared_r13)
        self._used_lock = threading.Lock()
        self._used = False

    def supervise(self, source_scope: Any, release_source_scope: Any, **kwargs: Any):
        with self._used_lock:
            _check(self._used is False, "r14_adapter_reentry")
            self._used = True
        adapter = self._r8_adapter
        previous = adapter._project_r7_parent_result
        prepared_r13 = self.prepared.r13_prepared
        adapter._project_r7_parent_result = lambda result: _R13._R12._parent_projection(
            adapter, result, prepared_r13, previous
        )
        try:
            return self._r12._r11._r10.supervise(source_scope, release_source_scope, **kwargs)
        finally:
            adapter._project_r7_parent_result = previous

    def summarize_result(self, result: Any) -> dict[str, Any]:
        return self._r12.summarize_result(result)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._r12, name)


if __name__ == "__main__":
    raise SystemExit("Use prepare_from_r13() and hold the exact R14 addition.")
