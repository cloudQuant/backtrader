"""Run the focused r2d pytest set with native SDK/network imports blocked."""

from __future__ import annotations

import builtins
import json
import os
import socket
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["BT_API_PY_LIGHT_IMPORT"] = "1"
os.chdir(root)
sys.path.insert(0, str(root))
import pytest  # noqa: E402

report_path = root / "evidence" / "focused-guard-report.json"
counters = {"blocked_sdk_import_attempts": [], "network_attempts": 0, "protected_path_attempts": []}
original_import = builtins.__import__
original_connect = socket.socket.connect
original_connect_ex = socket.socket.connect_ex
original_create_connection = socket.create_connection
original_getaddrinfo = socket.getaddrinfo

def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    prefixes = ("bt_api_py", "bt_api_ctp", "_ctp", "ctp_wrap", "thostmduserapi", "thosttraderapi")
    if any(name == prefix or name.startswith(prefix + ".") for prefix in prefixes):
        counters["blocked_sdk_import_attempts"].append(name)
        raise AssertionError("SDK/native imports are blocked in this candidate test")
    return original_import(name, globals, locals, fromlist, level)

def blocked_network(*_args, **_kwargs):
    counters["network_attempts"] += 1
    raise AssertionError("network access is blocked in this candidate test")

builtins.__import__ = guarded_import
socket.socket.connect = blocked_network
socket.socket.connect_ex = blocked_network
socket.create_connection = blocked_network
socket.getaddrinfo = blocked_network
args = [
    "-p", "no:asyncio",
    "tests/unit/stores/test_btapistore_iteration22.py::test_empty_incomplete_query_is_not_interpreted_as_zero_records",
    "tests/unit/stores/test_btapistore_iteration22.py::test_query_request_type_mismatch_fails_closed",
    "tests/unit/stores/test_btapistore_iteration22.py::test_preflight_rejects_trade_rows_outside_the_requested_scope",
    "tests/unit/stores/test_ctp_shared_session_read_port.py",
    "-q", "--tb=short",
    "--basetemp", str(root / "evidence" / "pytest-basetemp-focused"),
    "--junitxml", str(root / "evidence" / "candidate-focused.junit.xml"),
]
try:
    code = int(pytest.main(args))
finally:
    native_loaded = sorted(
        name for name in sys.modules
        if name.startswith(("bt_api_py", "bt_api_ctp", "_ctp", "ctp_wrap", "thostmduserapi", "thosttraderapi"))
    )
    report = {
        "pytest_exit_code": code,
        "blocked_sdk_import_attempts": counters["blocked_sdk_import_attempts"],
        "sdk_native_modules_loaded": native_loaded,
        "network_attempts": counters["network_attempts"],
        "scope": args,
    }
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if counters["blocked_sdk_import_attempts"] or native_loaded or counters["network_attempts"]:
        code = 2
    raise SystemExit(code)
