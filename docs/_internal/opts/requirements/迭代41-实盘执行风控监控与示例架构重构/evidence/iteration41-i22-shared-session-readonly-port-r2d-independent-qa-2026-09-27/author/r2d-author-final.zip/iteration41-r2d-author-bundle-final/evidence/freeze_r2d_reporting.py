from __future__ import annotations
import csv, hashlib, json, xml.etree.ElementTree as ET
from pathlib import Path
root = Path(__file__).resolve().parents[1]
ev = root / 'evidence'
base_junit = Path(r'D:\temp\iteration41-r2c-independent-qa-20260927\stores-runtime-reviewed-r2c.xml')
selected = {
    'test_empty_incomplete_query_is_not_interpreted_as_zero_records': 'migrate incomplete positions query contract',
    'test_query_request_type_mismatch_fails_closed': 'migrate typed query-kind mismatch',
    'test_preflight_rejects_trade_rows_outside_the_requested_scope': 'migrate trade scope contract',
}
class_path = ev / 'r2c-input-and-nodeid-classification.json'
classification = json.loads(class_path.read_text(encoding='utf-8'))
for row in classification['all_i22_failed_nodeids']:
    row['r2d_scope'] = selected.get(row['nodeid'], 'unchanged; not migrated in this slice')
classification['selected_migration_nodeids'] = [
    {'nodeid': nodeid, 'classification': 'query/preflight/scope/quote/settlement evidence',
     'r2b_failed': True, 'r2c_failed': True, 'r2d_scope': scope}
    for nodeid, scope in selected.items()
]
classification['r2d_migrated_original_nodeids'] = 3
classification['r2d_unmigrated_original_nodeids'] = 197
classification['r2d_status'] = 'three selected contracts migrated; remaining 197 unchanged and not run in this focused candidate'
class_path.write_text(json.dumps(classification, indent=2, sort_keys=True) + '\n', encoding='utf-8')
# Keep the CSV as a convenient exact-node lookup with the same slice disposition.
csv_path = ev / 'r2c-i22-nodeid-classification.csv'
with csv_path.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
fields = ['nodeid', 'classification', 'r2b_failed', 'r2c_failed', 'r2d_scope']
for row in rows:
    row['r2d_scope'] = selected.get(row['nodeid'], 'unchanged; not migrated in this slice')
with csv_path.open('w', encoding='utf-8', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=fields, lineterminator='\n')
    writer.writeheader(); writer.writerows(rows)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
base_cases = {}
for case in ET.parse(base_junit).iter('testcase'):
    name = case.attrib.get('name', '')
    if name in selected:
        failure = case.find('failure')
        base_cases[name] = {'nodeid': f"{case.attrib.get('classname')}::{name}", 'status': 'failed' if failure is not None else ('skipped' if case.find('skipped') is not None else 'passed'), 'failure_message': failure.attrib.get('message') if failure is not None else None}
cand_path = ev / 'candidate-focused.junit.xml'
cand_cases = {}
for case in ET.parse(cand_path).iter('testcase'):
    name = case.attrib.get('name', '')
    failure = case.find('failure')
    cand_cases[name] = {'nodeid': f"{case.attrib.get('classname')}::{name}", 'status': 'failed' if failure is not None else ('skipped' if case.find('skipped') is not None else 'passed'), 'failure_message': failure.attrib.get('message') if failure is not None else None}
assert set(base_cases) == set(selected), (set(base_cases), set(selected))
assert all(base_cases[n]['status'] == 'failed' and 'external account actor unavailable' in base_cases[n]['failure_message'] for n in selected)
assert all(cand_cases[n]['status'] == 'passed' for n in selected)
node_report = {
    'disposition': 'FAKE_READ_PORT_CONTRACT_ONLY',
    'baseline': {'path': str(base_junit), 'sha256': sha(base_junit), 'selected_original_nodeids': base_cases, 'failed_original_i22_nodeids': 200},
    'candidate': {'junit_path': str(cand_path), 'junit_sha256': sha(cand_path), 'focused_cases': cand_cases, 'original_i22_migrated': 3, 'original_i22_unmigrated': 197, 'unmigrated_original_nodeids': sorted(r['nodeid'] for r in classification['all_i22_failed_nodeids'] if r['nodeid'] not in selected)},
    'comparison': {'selected_original_nodeids': 3, 'baseline_failed_candidate_passed': 3, 'other_original_nodeids_changed': 0, 'other_original_nodeids_in_candidate_focus': 0},
    'limitations': ['Remaining 197 baseline failures were not rerun in this focused candidate.', 'Passing fake-port tests do not establish a real actor, authenticated identity, common snapshot, account scope, Store admission, production readiness or write authority.']
}
(ev / 'r2d-nodeid-baseline-candidate.json').write_text(json.dumps(node_report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
patch = ev / 'r2d-shared-session-readonly-port.patch'
files = ['backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_btapistore_iteration22.py','tests/unit/stores/test_ctp_shared_session_read_port.py']
hashes = {
    'disposition': 'FAKE_READ_PORT_CONTRACT_ONLY',
    'frozen_inputs': {
       'r2b_main_base_patch_sha256': '1a16aadb94edb99924553d6472bf72dcb02bd04c7f994276816d91991a729f37',
       'r2c_additive_patch_sha256': '4eeab367c80d1d4b5545892db56376dcb170557dd3098bc4787a5ac5bd8b14fc',
       'r2c_store_sha256': 'f3e0a04a8f264a4ea42e38ce3e781c6e7ef44270803ef85120224d659ddf4231',
       'r2c_actor_port_sha256': 'efe666f382d6d405f927562fd4f5c20583f3fa1e82aa5f21e9fee98feb8d4846',
       'original_i22_test_sha256': '30eeaa2c9816e6d0792e801a6ea2a8960cc1bcaa3728679111318e5178afa49d',
       'r2c_junit_sha256': sha(base_junit),
    },
    'candidate': {'patch_path': str(patch), 'patch_sha256': sha(patch), 'patch_files': files,
                  'junit_path': str(cand_path), 'junit_sha256': sha(cand_path),
                  'guard_report_sha256': sha(ev/'focused-guard-report.json'),
                  'nodeid_classification_json_sha256': sha(class_path), 'nodeid_classification_csv_sha256': sha(csv_path),
                  'baseline_candidate_comparison_sha256': sha(ev/'r2d-nodeid-baseline-candidate.json')},
}
(ev / 'r2d-artifact-hashes.json').write_text(json.dumps(hashes, indent=2, sort_keys=True)+'\n', encoding='utf-8')
print(json.dumps(hashes,indent=2))
