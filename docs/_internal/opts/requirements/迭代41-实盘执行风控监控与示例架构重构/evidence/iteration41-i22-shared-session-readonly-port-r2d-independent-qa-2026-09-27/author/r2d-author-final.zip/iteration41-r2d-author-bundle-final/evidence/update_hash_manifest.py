import json, hashlib
from pathlib import Path
p = Path('evidence/r2d-artifact-hashes.json')
raw = p.read_text(encoding='utf-8')
if raw.endswith(chr(92) + 'n'):
    raw = raw[:-2] + chr(10)
d = json.loads(raw)
root = Path('.')
c = d['candidate']
c['source_sha256'] = {x: hashlib.sha256((root/x).read_bytes()).hexdigest() for x in [
    'backtrader/stores/ctp_account_actor_port.py',
    'tests/unit/stores/test_btapistore_iteration22.py',
    'tests/unit/stores/test_ctp_shared_session_read_port.py']}
for key, rel in [('report_sha256','evidence/report.md'), ('guarded_log_sha256','evidence/guarded-focus.log'), ('ruff_log_sha256','evidence/ruff-check.log'), ('py_compile_log_sha256','evidence/py-compile.log')]:
    c[key] = hashlib.sha256(Path(rel).read_bytes()).hexdigest()
p.write_text(json.dumps(d, indent=2, sort_keys=True) + chr(10), encoding='utf-8')
print(json.dumps(c, indent=2))
