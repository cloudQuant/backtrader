# Exact focused verification commands for r2d.
$ErrorActionPreference = 'Stop'
python evidence\run_guarded_r2d.py *> evidence\guarded-focus.log
$pytestCode = $LASTEXITCODE
Add-Content evidence\guarded-focus.log "process_exit_code=$pytestCode"
if ($pytestCode -ne 0) { throw "guarded focus failed: $pytestCode" }
ruff check backtrader\stores\ctp_account_actor_port.py tests\unit\stores\test_btapistore_iteration22.py tests\unit\stores\test_ctp_shared_session_read_port.py *> evidence\ruff-check.log
$ruffCode = $LASTEXITCODE
Add-Content evidence\ruff-check.log "process_exit_code=$ruffCode"
if ($ruffCode -ne 0) { throw "ruff failed: $ruffCode" }
python -c "import py_compile; py_compile.compile('backtrader/stores/ctp_account_actor_port.py', doraise=True); py_compile.compile('tests/unit/stores/test_btapistore_iteration22.py', doraise=True); py_compile.compile('tests/unit/stores/test_ctp_shared_session_read_port.py', doraise=True); print('py_compile OK')" *> evidence\py-compile.log
$compileCode = $LASTEXITCODE
Add-Content evidence\py-compile.log "process_exit_code=$compileCode"
if ($compileCode -ne 0) { throw "py_compile failed: $compileCode" }
