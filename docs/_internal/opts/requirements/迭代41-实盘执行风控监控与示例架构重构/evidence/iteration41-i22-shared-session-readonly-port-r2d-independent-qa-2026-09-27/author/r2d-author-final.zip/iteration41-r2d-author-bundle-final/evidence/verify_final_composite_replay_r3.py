from __future__ import annotations
import hashlib, shutil, subprocess
from pathlib import Path
root=Path(r'D:\temp\iteration41-r2d-shared-session-readonly-port-20260927')
r2c=Path(r'D:\temp\iteration41-r2c-independent-qa-20260927')
seq=Path(r'D:\temp\iteration41-r2d-final-sequential-replay-r3-20260927')
expected=Path(r'D:\temp\iteration41-r2d-final-expected-composite-r3-20260927')
if seq.exists() or expected.exists(): raise SystemExit('replay destination already exists')
log=[]
def run(args,cwd):
    log.append('$ '+subprocess.list2cmdline([str(x) for x in args])+'  (cwd='+str(cwd)+')')
    result=subprocess.run([str(x) for x in args],cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log.append(result.stdout.rstrip()); log.append('exit_code='+str(result.returncode))
    if result.returncode: raise RuntimeError('command failed: '+str(args))
for base,src,rels in [(seq,r2c,['backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_btapistore_iteration22.py']),(expected,root,['backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_btapistore_iteration22.py','tests/unit/stores/test_ctp_shared_session_read_port.py'])]:
    for rel in rels:
        dst=base/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src/rel,dst)
query=Path(r'D:\temp\iteration41-ctp-query-pure-seam-r2b-20260927-r2\query-evidence-test-seam.patch')
r2d=root/'evidence/r2d-shared-session-readonly-port.patch'
for base,include_r2d in [(seq,True),(expected,False)]:
    run(['git','apply','--check','--ignore-space-change',query],base)
    run(['git','apply','--ignore-space-change',query],base)
    if include_r2d:
        run(['git','apply','--check','--ignore-space-change',r2d],base)
        run(['git','apply','--ignore-space-change',r2d],base)
rels=['backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_btapistore_iteration22.py','tests/unit/stores/test_ctp_shared_session_read_port.py','tests/unit/stores/test_btapistore_ctp_query_evidence_pure.py']
for rel in rels:
    a=(seq/rel).read_bytes().replace(bytes((13,10)),bytes((10,)))
    b=(expected/rel).read_bytes().replace(bytes((13,10)),bytes((10,)))
    same=a==b; log.append(rel+' normalized_equal='+str(same)+' sha256='+hashlib.sha256(a).hexdigest())
    if not same: raise RuntimeError('composite replay mismatch '+rel)
log.append('QUERY_SEAM_THEN_R2D_COMPOSITE_REPLAY_PASS')
(root/'evidence/patch-replay.log').write_text('\n'.join(log)+'\n',encoding='utf-8')
print('\n'.join(log))
