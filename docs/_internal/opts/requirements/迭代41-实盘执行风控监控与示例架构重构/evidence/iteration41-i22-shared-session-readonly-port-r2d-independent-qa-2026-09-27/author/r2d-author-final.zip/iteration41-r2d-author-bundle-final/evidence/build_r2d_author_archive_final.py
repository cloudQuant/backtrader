from __future__ import annotations
import hashlib, json, shutil, zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
ev=root/'evidence'
r2c=Path(r'D:\temp\iteration41-r2c-independent-qa-20260927')
bundle=ev/'r2d-author-bundle-final'
if bundle.exists(): raise SystemExit(f'refusing to overwrite {bundle}')
def put(src:Path,rel:str):
    if not src.is_file(): raise SystemExit(f'missing required archive input: {src}')
    dst=bundle/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
    if hashlib.sha256(src.read_bytes()).digest()!=hashlib.sha256(dst.read_bytes()).digest(): raise SystemExit(f'copy hash mismatch: {src}')
    return dst
pre={
 'backtrader/stores/ctp_account_actor_port.py':'preimage/backtrader/stores/ctp_account_actor_port.py',
 'backtrader/stores/btapistore.py':'preimage/backtrader/stores/btapistore.py',
 'tests/unit/stores/test_btapistore_iteration22.py':'preimage/tests/unit/stores/test_btapistore_iteration22.py',
}
for src_rel,dst_rel in pre.items(): put(r2c/src_rel,dst_rel)
outputs={
 'backtrader/stores/ctp_account_actor_port.py':'output/backtrader/stores/ctp_account_actor_port.py',
 'backtrader/stores/btapistore.py':'output/backtrader/stores/btapistore.py',
 'tests/unit/stores/test_btapistore_iteration22.py':'output/tests/unit/stores/test_btapistore_iteration22.py',
 'tests/unit/stores/test_ctp_shared_session_read_port.py':'output/tests/unit/stores/test_ctp_shared_session_read_port.py',
}
for src_rel,dst_rel in outputs.items(): put(root/src_rel,dst_rel)
put(ev/'r2d-shared-session-readonly-port.patch','patch/r2d-shared-session-readonly-port.patch')
put(Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r2b\r2b-main-base-apply.patch'),'inputs/parent-patches/r2b-main-base-apply.patch')
put(Path(r'D:\temp\iteration41-r2c-store-safety.patch'),'inputs/parent-patches/r2c-store-safety.patch')
put(Path(r'D:\temp\iteration41-ctp-query-pure-seam-r2b-20260927-r2\query-evidence-test-seam.patch'),'inputs/parent-patches/query-evidence-test-seam.patch')
put(r2c/'stores-runtime-reviewed-r2c.xml','baseline/r2c-stores-runtime.xml')
for rel in [
 'r2c-i22-nodeid-classification.csv','r2c-input-and-nodeid-classification.json',
 'r2d-nodeid-baseline-candidate.json','r2d-artifact-hashes.json','candidate-focused.junit.xml',
 'focused-guard-report.json','guarded-focus.log','ruff-check.log','py-compile.log','patch-replay.log','report.md',
 'run_guarded_r2d.py','capture_verification_r2d.ps1','make_r2d_patch.py',
 'freeze_r2d_reporting.py','update_hash_manifest.py','fix_request_exact_text.py','fix_timeout_validator.py',
 'update_final_report.py','update_final_hashes.py','verify_final_composite_replay_r3.py',
 'build_r2d_author_archive_final.py',
]: put(ev/rel,'evidence/'+rel)
absent={'path':'tests/unit/stores/test_ctp_shared_session_read_port.py','status_at_frozen_r2c_preimage':'ABSENT'}
(bundle/'preimage/new-file-state.json').write_text(json.dumps(absent,indent=2,sort_keys=True)+chr(10),encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
entries=[{'path':p.relative_to(bundle).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(bundle.rglob('*')) if p.is_file() and p.name!='manifest.json']
manifest={
 'name':'iteration41-r2d-shared-session-readonly-port-author-bundle-final',
 'disposition':'FAKE_READ_PORT_CONTRACT_ONLY',
 'source_root':'frozen r2c independent-QA source; r2d is not directly applicable to current main',
 'main_tree_modified':False,
 'scope':{'original_i22_migrated':3,'original_i22_unchanged':197,'candidate_focused_tests_passed':7},
 'explicit_absences':['private config','SDK/native binaries or modules','credentials','real CTP Store/SDK session','network or orders','account/session identity','common snapshot','settlement authority','Store runtime wiring'],
 'parent_patch_sha256':{
  'r2b-main-base-apply.patch':'1a16aadb94edb99924553d6472bf72dcb02bd04c7f994276816d91991a729f37',
  'r2c-store-safety.patch':'4eeab367c80d1d4b5545892db56376dcb170557dd3098bc4787a5ac5bd8b14fc',
  'query-evidence-test-seam.patch':sha(bundle/'inputs/parent-patches/query-evidence-test-seam.patch')},
 'preimage_hashes':{src:sha(bundle/dst) for src,dst in pre.items()},
 'output_hashes':{src:sha(bundle/dst) for src,dst in outputs.items()},
 'patch_sha256':sha(bundle/'patch/r2d-shared-session-readonly-port.patch'),
 'entries':entries,
}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+chr(10),encoding='utf-8')
zip_path=ev/'r2d-author-final.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(bundle.rglob('*')):
  if f.is_file(): z.write(f,Path('iteration41-r2d-author-bundle-final')/f.relative_to(bundle))
with zipfile.ZipFile(zip_path,'r') as z:
 bad=z.testzip(); names=z.namelist()
 if bad: raise SystemExit(f'ZIP CRC failure: {bad}')
receipt={'archive_path':str(zip_path),'archive_sha256':sha(zip_path),'archive_size_bytes':zip_path.stat().st_size,'member_count':len(names),'zip_crc':'PASS','manifest_sha256':sha(bundle/'manifest.json'),'manifest_payload_entries':len(entries)}
(ev/'r2d-author-final-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+chr(10),encoding='utf-8')
print(json.dumps(receipt,indent=2))
