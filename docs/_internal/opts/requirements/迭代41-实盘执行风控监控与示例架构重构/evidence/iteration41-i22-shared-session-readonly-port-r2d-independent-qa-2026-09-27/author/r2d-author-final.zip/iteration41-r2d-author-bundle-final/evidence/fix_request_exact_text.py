from pathlib import Path
port = Path('backtrader/stores/ctp_account_actor_port.py')
s = port.read_text(encoding='utf-8')
old = '''        _required_text(self.correlation_id, "correlation_id")
        if type(self.scope) is not CtpReadQueryScopeV1:
'''
new = '''        _required_read_text(self.correlation_id, "correlation_id")
        if type(self.scope) is not CtpReadQueryScopeV1:
'''
if old not in s: raise SystemExit('query request validation anchor missing')
s = s.replace(old,new,1)
old = '''        _required_text(self.correlation_id, "correlation_id")
        _required_text(self.exchange_id, "exchange_id")
        _required_text(self.instrument_id, "instrument_id")
        if (
            type(self.timeout_seconds) not in {int, float}
'''
new = '''        _required_read_text(self.correlation_id, "correlation_id")
        _required_read_text(self.exchange_id, "exchange_id")
        _required_read_text(self.instrument_id, "instrument_id")
        if (
            type(self.timeout_seconds) not in {int, float}
'''
if old not in s: raise SystemExit('quote request validation anchor missing')
s = s.replace(old,new,1)
port.write_text(s,encoding='utf-8',newline='')

test = Path('tests/unit/stores/test_ctp_shared_session_read_port.py')
s = test.read_text(encoding='utf-8')
anchor = '''def test_typed_port_constructor_rejects_invalid_quote_and_query_shapes():
    with pytest.raises(ValueError, match="positive exact integer"):
'''
replacement = '''def test_typed_port_constructor_rejects_invalid_quote_and_query_shapes():
    with pytest.raises(ValueError, match="surrounding whitespace"):
        CtpReadQueryRequestV1(
            kind=CtpReadQueryKindV1.POSITIONS,
            correlation_id=" padded ",
            scope=CtpReadQueryScopeV1("CZCE", "SA609", "20260909"),
            timeout_seconds=0.0,
        )
    for field in ("correlation_id", "exchange_id", "instrument_id"):
        values = {
            "correlation_id": "quote",
            "exchange_id": "CZCE",
            "instrument_id": "SA609",
            "timeout_seconds": 0.0,
        }
        values[field] = " padded "
        with pytest.raises(ValueError, match="surrounding whitespace"):
            CtpQuoteRequestV1(**values)

    with pytest.raises(ValueError, match="positive exact integer"):
'''
if anchor not in s: raise SystemExit('shape test anchor missing')
s = s.replace(anchor,replacement,1)
test.write_text(s,encoding='utf-8',newline='')
print('updated exact-text request validation and negative tests')
