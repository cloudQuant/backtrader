from pathlib import Path
p=Path('backtrader/stores/ctp_account_actor_port.py')
s=p.read_text(encoding='utf-8')
old='''        if (
            type(self.timeout_seconds) not in {int, float}
            or not math.isfinite(self.timeout_seconds)
            or self.timeout_seconds < 0
        ):
            raise ValueError("timeout_seconds must be finite and nonnegative")
'''
if s.count(old)!=2: raise SystemExit(f'expected 2 inline timeout validators, found {s.count(old)}')
s=s.replace(old,'''        _validate_read_timeout(self.timeout_seconds)
''',2)
p.write_text(s,encoding='utf-8',newline='')
t=Path('tests/unit/stores/test_ctp_shared_session_read_port.py')
s=t.read_text(encoding='utf-8')
anchor='''    with pytest.raises(ValueError, match="positive exact integer"):
        CtpQuoteReplyV1(
'''
insert='''    with pytest.raises(ValueError, match="timeout_seconds must be finite and nonnegative"):
        CtpReadQueryRequestV1(
            kind=CtpReadQueryKindV1.POSITIONS,
            correlation_id="position",
            scope=CtpReadQueryScopeV1("CZCE", "SA609", "20260909"),
            timeout_seconds=10**10000,
        )
    with pytest.raises(ValueError, match="timeout_seconds must be finite and nonnegative"):
        CtpQuoteRequestV1(
            correlation_id="quote",
            exchange_id="CZCE",
            instrument_id="SA609",
            timeout_seconds=10**10000,
        )

    with pytest.raises(ValueError, match="positive exact integer"):
        CtpQuoteReplyV1(
'''
if anchor not in s: raise SystemExit('timeout negative assertion anchor missing')
s=s.replace(anchor,insert,1)
t.write_text(s,encoding='utf-8',newline='')
print('both request validators use overflow-safe shared timeout validation; huge-int negatives added')
