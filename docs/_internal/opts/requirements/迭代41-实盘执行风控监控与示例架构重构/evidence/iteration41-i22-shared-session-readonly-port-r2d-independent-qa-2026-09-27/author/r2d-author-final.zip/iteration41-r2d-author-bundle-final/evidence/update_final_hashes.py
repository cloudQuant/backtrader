import json, hashlib
from pathlib import Path
p=Path('evidence/r2d-artifact-hashes.json')
d=json.loads(p.read_text(encoding='utf-8'))
c=d['candidate']
c['report_sha256']=hashlib.sha256(Path('evidence/report.md').read_bytes()).hexdigest()
c['patch_replay_log_sha256']=hashlib.sha256(Path('evidence/patch-replay.log').read_bytes()).hexdigest()
c['guarded_log_sha256']=hashlib.sha256(Path('evidence/guarded-focus.log').read_bytes()).hexdigest()
c['ruff_log_sha256']=hashlib.sha256(Path('evidence/ruff-check.log').read_bytes()).hexdigest()
c['py_compile_log_sha256']=hashlib.sha256(Path('evidence/py-compile.log').read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2,sort_keys=True)+chr(10),encoding='utf-8')
print(json.dumps(c,indent=2))
