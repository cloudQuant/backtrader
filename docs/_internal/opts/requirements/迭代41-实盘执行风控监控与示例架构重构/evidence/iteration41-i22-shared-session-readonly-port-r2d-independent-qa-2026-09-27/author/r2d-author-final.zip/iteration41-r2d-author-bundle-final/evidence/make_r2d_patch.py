import difflib
from pathlib import Path

candidate = Path(r'D:\temp\iteration41-r2d-shared-session-readonly-port-20260927')
base = Path(r'D:\temp\iteration41-r2c-independent-qa-20260927')
patch_path = candidate / 'evidence' / 'r2d-shared-session-readonly-port.patch'
paths = [
    'backtrader/stores/ctp_account_actor_port.py',
    'tests/unit/stores/test_btapistore_iteration22.py',
    'tests/unit/stores/test_ctp_shared_session_read_port.py',
]
chunks = []
for relative in paths:
    before = base / relative
    after = candidate / relative
    old = before.read_text(encoding='utf-8').splitlines(keepends=True) if before.exists() else []
    new = after.read_text(encoding='utf-8').splitlines(keepends=True)
    if old == new:
        raise SystemExit(f'no patch content for {relative}')
    chunks.append(f'diff --git a/{relative} b/{relative}\n')
    if not before.exists():
        chunks.append('new file mode 100644\n')
        fromfile = '/dev/null'
    else:
        fromfile = f'a/{relative}'
    tofile = f'b/{relative}'
    chunks.extend(difflib.unified_diff(old, new, fromfile=fromfile, tofile=tofile, n=3))
patch_path.write_text(''.join(chunks), encoding='utf-8', newline='')
print(f'Wrote {patch_path} ({patch_path.stat().st_size} bytes)')
