# Independent Anchor / Guardian Review Receipt

Date: 2026-09-26

## Frozen anchor r5

Snapshot: D:\temp\iteration41-anchor-pycache-prefix-20260926-r5

- Anchor SHA-256: 19fc85e9bc0d82a991efd0f7bfa15cc5bb3388a22c0931b4f2b857a7d4fc9db4
- Test SHA-256: a5526a31a319649cb4cdd1ad3261c4cb17f04860fc561f4f5ef798cb8a8c0917
- Independent focused result: 68 passed, one existing pytest-asyncio config warning. Ruff check and format check passed.
- Exact source import: the frozen test loads the anchor by spec_from_file_location from its own snapshot-derived path (test_ctp_i13_i15_guardian_deployment_anchor.py:18-26).
- Fixed cache-prefix behavior: GuardianDeploymentAnchor.pycache_prefix returns runtime_base_root\disabled-bytecode-cache and refuses access after anchor or execution leases close (ctp_i13_i15_guardian_deployment_anchor.py:1507-1513; test lines 244-251). A real Windows retained-handle enumeration test observes the leaf absent and then present after creating it (test lines 646-673).
- Scope: no blocker found in this frozen anchor slice. This does not prove runtime parser-to-worker integration or production ACL/deployment; frozen descriptor/dependency/runtime pins are intentionally zero and fail closed (anchor docstring/constants, lines 1-34).

Independent output and frozen author output are under anchor-r5/.

## Guardian OS-token route r1

Snapshot: D:\temp\iteration41-readonly-os-route-freeze-20260926-r1

- Service SHA-256: 20ff688f657000017833dfdb12f11fd3b1feabb25e019ae581f20503ad5c7561
- Test SHA-256: 82cb185686042ee7b3f129d809af7bc0e22db550f312160b9f91987d67d74863
- Frozen author focused result: 38 passed, no failures/errors/skips, one existing unknown asyncio config warning. Independent rerun with exact frozen service/test bytes in the expected temporary source/scripts and source/tests/unit/scripts layout: 38 passed in 26.30s, one existing pytest-asyncio warning; log/JUnit and runnable source-layout copies are preserved under guardian-r1/independent-layout-run/.
- Frozen source/test/manifest/JUnit/log are copied under guardian-r1/. windows_job_backend.py and outer_watchdog.py under guardian-r1/context-captured-after-freeze/ are contextual copies captured during this review, not files listed in the r1 freeze manifest.

### Finding 1 — cross-session stdio inheritance blocks normal service deployment

The frozen service captures a primary token from the actual pipe client (ctp_i13_i15_windows_guardian_service.py:1723-1800) and passes it with stdout/NUL handles to the process backend (:3038-3043). The backend sets bInheritHandles=True when this handle list is present (ctp_i13_i15_windows_job_backend.py:840-875) and calls CreateProcessAsUserW (:904-919).

A normal SCM service runs in Session 0; an interactive owner token retains the interactive session ID. The implementation does not inspect or change TokenSessionId. Microsoft documents that handles cannot be inherited across Terminal Services sessions and that bInheritHandles=TRUE requires the child to be in the caller's session: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessasuserw

Minimum repair: use a bounded named-pipe output channel opened by the worker, or fail closed on an explicitly verified session mismatch. Do not adjust TokenSessionId without a separate privilege/identity review. Fake tests do not exercise Session 0 versus interactive session inheritance.

### Finding 2 — failed RevertToSelf does not stop service follow-up

Token capture raises pipe_client_revert_failed if RevertToSelf fails (ctp_i13_i15_windows_guardian_service.py:1805-1814). The handler catches that exception broadly (:3102-3110), then continues to close execution leases, create a receipt and attempt a response (:3128-3198) on the same thread. That thread may still impersonate the caller.

Minimum repair: terminate the service process immediately on this failure and skip receipt/response/privileged follow-up; retiring only a thread is insufficient. Add an integration negative proving no follow-up occurs after failed revert. Existing low-level fake tests the error but does not prove thread retirement.

Known limit: synchronous anchor/setup and receipt I/O are outside caller IPC timeout; this route is not a whole-command hard-deadline/G1 acceptance.

## Artifact inventory

See review-receipt.json and copied-file-hashes.json for machine-readable findings and SHA-256 hashes. Author logs/JUnit and independent r5 logs/JUnit are preserved in the subdirectories.

