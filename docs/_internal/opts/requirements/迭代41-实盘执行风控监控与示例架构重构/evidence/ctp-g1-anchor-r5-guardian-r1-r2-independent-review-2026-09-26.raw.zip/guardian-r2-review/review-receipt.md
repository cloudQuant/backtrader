# Guardian r2 Independent Review

Snapshot: D:\temp\iteration41-readonly-os-route-failstop-20260926-r2
Manifest SHA-256: c244eb131d4613fc33add4312f11a0761ecec4ab585f89a981340635d8cf0108
Service SHA-256: 0307c26a0f88819ff18c5dd82bc26146bb7868318b89691ac643865473d5fdf4
Test SHA-256: 73250a7ff6a5e97c3a81492b557848a50f4065dfa40994988d536fd3adf5346b

## Test evidence

The frozen author run reports 39 passed with no failures/errors/skips. My first direct invocation against the flat snapshot failed 7 tests because the test calculates repo_root with parents[3]. I then recreated the expected temporary source/scripts and source/tests/unit/scripts layout, used the exact frozen service and test bytes, and independently got 39 passed in 26.40s with the existing asyncio configuration warning. Independent log, JUnit, and exit code are in independent-layout-run/. The test interception replaces the process termination sink; production TerminateProcess/os._exit was not executed.

## RevertToSelf path

The new primary-token helper raises GuardianServiceThreadFatalError when RevertToSelf fails (service lines 1838-1864). The route catches that type and terminates the service process before ordinary handler cleanup and receipt work (lines 3137-3142); the process-fatal helper attempts TerminateProcess then falls back to os._exit (lines 616-640). Integration test lines 2480-2518 asserts no pipe close, anchor cleanup, execution-lease close, receipt create/close, or response after the fatal boundary. This fixes the r1 failure for the new OS-token route.

### Residual legacy-helper issue

The separate _impersonated_pipe_client_sid helper still raises ordinary GuardianServiceError after a failed RevertToSelf (lines 1667-1685). It remains called in the legacy HMAC listener/request flows (lines 2568 and 2759); serve_one_inert_request catches that exception and returns (2759-2761). The legacy API is exported, so r2 does not establish module-wide fail-stop handling. Minimum repair: use process-fatal handling there too, or disable the callable legacy server under service execution; test with an injected fatal sink, never actual os._exit in pytest.

## Cross-session handle inheritance remains a deployment blocker

The r2 OS route still sends the client primary token and inherited stdio handles into the backend (service lines 3073-3087). The contextual backend sets bInheritHandles=True for a stdio handle list (lines 840-875) and calls CreateProcessAsUserW (lines 904-919). The token retains the client session; service is ordinarily Session 0. Microsoft documents that handles cannot be inherited across Terminal Services sessions and bInheritHandles=TRUE requires the child to be in the caller session: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessasuserw

Use a bounded named-pipe output channel with no inherited cross-session handles, or fail closed on a verified session mismatch. Do not change TokenSessionId absent a separate privilege and identity review.

No service install, real provider/native, private config, or actual cross-session process creation was performed. Service setup/receipt I/O remain outside an independent external watchdog; G1 is not passed.

See review-receipt.json and copied-file-hashes.json for machine-readable findings and copied artifacts.
