import ast
from pathlib import Path
import psutil
import sqlite3
import textwrap
import traceback
_original_connect = sqlite3.connect
_tracked_connections = []
class TrackingConnection(sqlite3.Connection):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.tracker_closed = False
    def close(self):
        self.tracker_closed = True
        return super().close()
def _tracked_connect(database, *args, **kwargs):
    kwargs['factory'] = TrackingConnection
    connection = _original_connect(database, *args, **kwargs)
    _tracked_connections.append((str(database), connection, ''.join(traceback.format_stack(limit=7))))
    return connection
sqlite3.connect = _tracked_connect
p = Path(r'D:\temp\iteration41-cancel-control-main-parent-overlay-r4-20260927\tests\test_iteration41_managed_cancellation_composition.py')
tree = ast.parse(p.read_text(encoding='utf-8'))
script = next(n.args[0].value for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'dedent' and n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str) and 'cancel.intent.unknown' in n.args[0].value)
script = textwrap.dedent(script).replace('__SCENARIO__', repr('offline_fake'))
needle='managed.close()'
replacement=needle+'; print("OPEN_FILES", [item.path for item in psutil.Process().open_files() if "monitor.sqlite3" in item.path]); print("UNTRACKED_CLOSED_FLAG", [(db, conn.tracker_closed, stack) for db, conn, stack in _tracked_connections if "monitor.sqlite3" in db and not conn.tracker_closed])'
if needle not in script:
    raise RuntimeError('could not find managed.close cleanup point')
script=script.replace(needle, replacement, 1)
exec(compile(script, '<cancel-openfile-diagnostic>', 'exec'), globals(), globals())
