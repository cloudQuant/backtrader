"""Root-only source review: no native leaf, socket I/O or private config."""
import hashlib
import importlib.abc
import json
import os
from pathlib import Path
import sys

ROOT = Path(r"D:\source_code\backtrader")
SDK = Path(r"D:\q\e")
OUT = Path(r"D:\temp\iteration41_sdk_md_profile_independent_20260926")
OUT.mkdir(exist_ok=True)
FILES = (
    SDK / "src/bt_api_ctp/ctp/client.py",
    SDK / "tests/test_ctp_callback_ingress_client.py",
    ROOT / "backtrader_runtime/ctp_simulation_query_evidence.py",
    ROOT / "tests/unit/runtime/test_ctp_simulation_query_evidence.py",
)

def hashes():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in FILES}

blocked = []
class DenyNative(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in {"_ctp", "bt_api_ctp.ctp._ctp"}:
            blocked.append(fullname)
            raise ImportError("offline review blocks native CTP leaf")
        return None

def audit(event, args):
    if event in {"socket.connect", "socket.connect_ex", "socket.bind", "socket.getaddrinfo"}:
        raise RuntimeError("offline review blocks network")
    if event == "open" and isinstance(args[0], (str, bytes, os.PathLike)):
        p = Path(os.fsdecode(args[0])).resolve()
        private = ROOT / "examples/013_3_sa_midfreq_simnow/runtime-ctp-private/config.yaml"
        if p == private or p == ROOT / ".env":
            raise RuntimeError("offline review blocks protected configuration")

sys.meta_path.insert(0, DenyNative())
sys.addaudithook(audit)
sys.path[:0] = [str(SDK / "src"), str(ROOT)]
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
before = hashes()
import bt_api_base
import bt_api_ctp
from bt_api_ctp.ctp import _ctp_base
import bt_api_ctp.ctp.client as client
import pytest

origins = {m.__name__: str(Path(m.__file__).resolve()) for m in (bt_api_base, bt_api_ctp, client)}
assert Path(client.__file__).resolve() == SDK / "src/bt_api_ctp/ctp/client.py"
assert Path(sys.prefix).resolve() in Path(bt_api_base.__file__).resolve().parents
status = pytest.main([
    "--noconftest", "-q", "--tb=short", "-o", "addopts=",
    str(FILES[1]), str(FILES[3]), "--junitxml=" + str(OUT / "result.xml"),
])
after = hashes()
assert before == after, "reviewed source changed during tests"
assert not _ctp_base.is_ctp_native_loaded()
assert "bt_api_ctp.ctp._ctp" not in sys.modules and "_ctp" not in sys.modules
receipt = {"exit_code": int(status), "python": sys.version, "prefix": sys.prefix,
           "origins": origins, "before": before, "after": after,
           "native_blocked_attempts": blocked, "native_loaded": False,
           "scope": "source-only SDK candidate plus installed base; no wheel acceptance"}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
raise SystemExit(status)
