from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); old=json.loads((root/'r1-candidate-manifest.json').read_text(encoding='utf-8-sig')); new=json.loads((root/'candidate-manifest.json').read_text(encoding='utf-8-sig'))
old_by={x['path']:x for x in old['files']}; new_by={x['path']:x for x in new['files']}
common=sorted(set(old_by)&set(new_by)); changed=[]; unchanged=[]; absent=[]
for rel in sorted(old_by):
    if rel not in new_by: absent.append(rel)
    elif old_by[rel]['sha256']==new_by[rel]['sha256']: unchanged.append(rel)
    else: changed.append(rel)
result={'r1_manifest_sha256':hashlib.sha256((root/'r1-candidate-manifest.json').read_bytes()).hexdigest(),'r2_manifest_sha256':hashlib.sha256((root/'candidate-manifest.json').read_bytes()).hexdigest(),'r1_payload_count':old.get('file_count'),'r2_payload_count':new.get('file_count'),'common_paths':len(common),'unchanged_common_paths':unchanged,'changed_common_paths':changed,'r1_only_paths':absent,'changed_functional_paths':[p for p in changed if p in ('ctp_simnow_settlement_consumer.py','tests/test_ctp_simnow_settlement_consumer.py')],'all_r1_shared_input_snapshots_unchanged':all(old_by[p]['sha256']==new_by[p]['sha256'] for p in common if p.startswith('input-snapshots/'))}
print(json.dumps(result,sort_keys=True,indent=2))
