from __future__ import annotations
import hashlib, json, sys, zipfile
from pathlib import Path
archive_path = Path(sys.argv[1])
sums_path = Path(sys.argv[2])
lines = sums_path.read_text(encoding="ascii").splitlines()
expected = {}
for line in lines:
    digest, rel = line.split("  ", 1)
    expected[rel.replace("\\", "/")] = digest
with zipfile.ZipFile(archive_path, "r") as zf:
    names = zf.namelist()
    duplicate_names = len(names) != len(set(names))
    bad_crc = zf.testzip()
    content_errors = []
    for rel, digest in expected.items():
        name = rel
        try:
            data = zf.read(name)
        except KeyError:
            content_errors.append("missing:" + rel)
            continue
        if hashlib.sha256(data).hexdigest() != digest:
            content_errors.append("hash:" + rel)
    expected_zip = set(expected) | {"SHA256SUMS.txt"}
    if set(names) != expected_zip:
        content_errors.append("member-set-mismatch")
    sums_data = zf.read("SHA256SUMS.txt")
    if hashlib.sha256(sums_data).hexdigest() != hashlib.sha256(sums_path.read_bytes()).hexdigest():
        content_errors.append("sums-mismatch")
result = {
    "archive_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "archive_members": len(names),
    "expected_payload_hashes_checked": len(expected),
    "duplicate_names": duplicate_names,
    "crc": "ok" if bad_crc is None else bad_crc,
    "content_errors": content_errors,
    "all_checks_passed": not duplicate_names and bad_crc is None and not content_errors,
}
print(json.dumps(result, sort_keys=True, indent=2))
if not result["all_checks_passed"]:
    raise SystemExit(1)
