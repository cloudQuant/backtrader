from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
lineage=Path(sys.argv[1]); canonical=Path(sys.argv[2]); frozen_r1=Path(sys.argv[3])
r1copy=lineage/'candidate-copy'
r1_manifest_raw=(r1copy/'candidate-manifest.json').read_bytes()
r1_manifest=json.loads(r1_manifest_raw)
r1_zip_hash=hashlib.sha256((r1copy/'candidate-evidence.zip').read_bytes()).hexdigest()
receipt=json.loads((lineage/'QA-RECEIPT.json').read_text(encoding='utf-8-sig'))
sums_path=canonical/'SHA256SUMS.txt'; sums=sums_path.read_bytes()
problems=[]
if hashlib.sha256(r1_manifest_raw).hexdigest()!='d39dbfa40185bd8f12704cd158c59a35d6737ef6a8d58d0a0aa165a144128486': problems.append('r1_manifest_sha')
if r1_manifest.get('file_count')!=24: problems.append('r1_payload_count')
if r1_zip_hash!='9f4e2f169384c56dd2b95e755074c4035684c0140946d7dba623114c1236e8bb': problems.append('r1_candidate_zip_sha')
if receipt.get('focused_tests',{}).get('passed')!=35 or receipt.get('adversarial_tests',{}).get('passed')!=21: problems.append('r1_qa_counts')
if hashlib.sha256(sums).hexdigest()!='517af45573d7dd3c0d70ed687b61656d851b9e49c46b919f11d842bc9eee0bd2': problems.append('r1_qa_sums_sha')
if (lineage/'REPORT.md').read_bytes()!=(canonical/'REPORT.md').read_bytes(): problems.append('r1_report_bytes')
checked=0
for line in sums.decode('ascii').splitlines():
    digest,rel=line.split('  ',1)
    p=lineage/Path(rel)
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
        problems.append('r1_lineage_payload:'+rel)
        break
    checked+=1
result={'r1_manifest_sha256':hashlib.sha256(r1_manifest_raw).hexdigest(),'r1_candidate_zip_sha256':r1_zip_hash,'r1_focus_passed':receipt.get('focused_tests',{}).get('passed'),'r1_adversarial_passed':receipt.get('adversarial_tests',{}).get('passed'),'r1_independent_package_files_checked':checked,'r1_canonical_qa_sums_sha256':hashlib.sha256(sums).hexdigest(),'r1_report_identical_to_prior_canonical':(lineage/'REPORT.md').read_bytes()==(canonical/'REPORT.md').read_bytes(),'all_checks_passed':not problems,'problems':problems}
print(json.dumps(result,sort_keys=True,indent=2)); sys.exit(bool(problems))
