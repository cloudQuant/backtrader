from __future__ import annotations
import hashlib,json,sys,zipfile
from pathlib import Path
zpath=Path(sys.argv[1]); sums_path=Path(sys.argv[2])
expected={}
for line in sums_path.read_text(encoding='ascii').splitlines():
    digest,rel=line.split('  ',1); expected[rel.replace('\\','/')]=digest
with zipfile.ZipFile(zpath) as zf:
    names=zf.namelist(); files={n for n in names if not n.endswith('/')}; dirs={n.rstrip('/') for n in names if n.endswith('/')}; errors=[]
    if len(names)!=len(set(names)): errors.append('duplicate-member')
    if zf.testzip() is not None: errors.append('crc')
    if files != set(expected)|{'SHA256SUMS.txt'}: errors.append('file-members')
    for d in dirs:
        if not any(n.startswith(d+'/') for n in files): errors.append('empty-dir:'+d)
    for rel,digest in expected.items():
        try: data=zf.read(rel)
        except KeyError: errors.append('missing:'+rel); continue
        if hashlib.sha256(data).hexdigest()!=digest: errors.append('hash:'+rel)
    if hashlib.sha256(zf.read('SHA256SUMS.txt')).hexdigest()!=hashlib.sha256(sums_path.read_bytes()).hexdigest(): errors.append('sums')
result={'zip_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'file_members':len(files),'directory_members':sorted(dirs),'payload_hashes_checked':len(expected),'crc':'ok' if zf.testzip() is None else 'failed','errors':errors,'all_checks_passed':not errors}
print(json.dumps(result,sort_keys=True,indent=2)); sys.exit(bool(errors))
