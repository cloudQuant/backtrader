from pathlib import Path
import shutil,hashlib
qa=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-independent-qa-20260927')
cand=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r0')
src=qa/'candidate-regression-copy'; dst=qa/'base-regression-copy'
assert not dst.exists()
shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache'))
base=cand/'input-sources'/'btapistore.py'
target=dst/'backtrader/stores/btapistore.py'
shutil.copy2(base,target)
actor=dst/'backtrader/stores/ctp_account_actor_port.py'
if actor.exists(): actor.unlink()
print('base Store sha256',hashlib.sha256(target.read_bytes()).hexdigest())
print('actor port removed',not actor.exists())
