from pathlib import Path
import zipfile,shutil
qa=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-independent-qa-20260927')
zp=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-r0-evidence.zip')
dst=qa/'candidate-regression-copy'
assert not dst.exists(),dst
with zipfile.ZipFile(zp) as z:
 for name in z.namelist():
  if name.endswith('/') or name.startswith('evidence/'):
   continue
  target=dst/name
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(z.read(name))
src=Path(r'D:\source_code\backtrader')
files=[
 'tests/unit/stores/test_managed_ctp_store_adapter.py',
 'tests/unit/stores/test_managed_execution_store_adapter.py',
 'tests/unit/stores/test_store_contract.py',
 'tests/unit/stores/test_credential_safety.py',
 'tests/unit/stores/test_btapistore.py',
 'tests/unit/stores/test_btapistore_normalized.py',
 'tests/unit/stores/test_btapistore_notifications.py',
 'tests/unit/stores/test_btapistore_iteration21.py',
 'tests/unit/stores/test_btapistore_iteration22.py',
 'tests/unit/stores/test_btapistore_edge_cases.py',
 'tests/unit/stores/test_btapistore_funding_refresh.py',
 'tests/unit/stores/test_btapistore_execution_evidence.py',
 'tests/unit/stores/test_btapistore_entry_approval_arm.py',
 'tests/integration/test_iteration41_gateway_store_composition.py',
 'tests/test_utils/iteration41_source_roots.py',
]
for rel in files:
 p=src/rel
 assert p.is_file(),rel
 out=dst/rel; out.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,out)
print('extracted candidate archive source and copied',len(files),'read-only test inputs')
