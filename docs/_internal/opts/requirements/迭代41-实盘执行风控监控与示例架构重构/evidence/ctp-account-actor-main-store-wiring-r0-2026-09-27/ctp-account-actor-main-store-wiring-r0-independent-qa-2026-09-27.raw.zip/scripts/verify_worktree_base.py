from pathlib import Path
import hashlib,json,shutil,subprocess
qa=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-independent-qa-20260927')
repo=Path(r'D:\source_code\backtrader')
cand=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r0')
copy=qa/'candidate-copy'; m=json.loads((cand/'evidence/candidate-manifest.json').read_text())
patch=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-r0-apply.patch')
sha=lambda b:hashlib.sha256(b).hexdigest()
# Current main worktree is the exact author source baseline: verify frozen input bytes.
main_store=(repo/'backtrader/stores/btapistore.py').read_bytes()
base_input=(cand/'input-sources/btapistore.py').read_bytes()
assert sha(main_store)==sha(base_input)==m['base_store_sha256']=='dba2989252db76fe010fbee7caacdcdba34a9b951e3702724156482b67fae826'
# Candidate snapshot's unchanged source/runtime/test files are compared against main.
patch_paths={'backtrader/stores/btapistore.py','backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py'}
records=[]; missing=[]; mismatches=[]
for item in m['files']:
 rel=item['path']
 if not rel.startswith(('backtrader/','backtrader_runtime/','tests/')) or rel in patch_paths: continue
 p=repo/Path(rel)
 if not p.is_file(): missing.append(rel); continue
 got=sha(p.read_bytes())
 if got!=item['sha256']: mismatches.append({'path':rel,'candidate':item['sha256'],'main':got})
 else: records.append(rel)
# Reconstruct the exact patch base for its only existing-file target and apply in a temp overlay.
base=qa/'reconstructed-main-base'
if base.exists(): shutil.rmtree(base)
store=base/'backtrader/stores/btapistore.py'; store.parent.mkdir(parents=True); store.write_bytes(base_input)
for rel in ['backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py']:
 p=base/rel
 if p.exists(): raise AssertionError('unexpected base file '+rel)
check=subprocess.run(['git','apply','--check',str(patch)],cwd=base,capture_output=True,text=True)
(qa/'worktree-base-patch-check.log').write_text('exit_code='+str(check.returncode)+'\nstdout:\n'+check.stdout+'\nstderr:\n'+check.stderr,encoding='utf-8')
apply=subprocess.run(['git','apply',str(patch)],cwd=base,capture_output=True,text=True)
(qa/'worktree-base-patch-apply.log').write_text('exit_code='+str(apply.returncode)+'\nstdout:\n'+apply.stdout+'\nstderr:\n'+apply.stderr,encoding='utf-8')
assert check.returncode==0 and apply.returncode==0,(check.stderr,apply.stderr)
outputs=[]
for rel in sorted(patch_paths):
 p=base/rel; c=copy/rel
 assert p.is_file() and c.is_file(),rel
 bh,ch=sha(p.read_bytes()),sha(c.read_bytes())
 # Git apply may leave CRLF format differences; compare both raw then normalized LF.
 normalized=(p.read_bytes().replace(b'\r\n',b'\n')==c.read_bytes().replace(b'\r\n',b'\n'))
 outputs.append({'path':rel,'applied_sha256':bh,'candidate_sha256':ch,'raw_equal':bh==ch,'lf_normalized_equal':normalized})
 assert normalized,rel
result={'schema':'actor_store_r0_worktree_base_patch.v1','main_head':'ad2c142b9a8b42cede85886528c681abdfcb8096',
 'main_store_raw_sha256':sha(main_store),'frozen_base_store_sha256':sha(base_input),'main_store_matches_frozen_input':True,
 'git_head_note':'HEAD commit is older than the dirty main working tree base: HEAD btapistore is 070c2c... raw blob and differs from frozen input; candidate uses exact Dba... working-tree snapshot, so patch was validated against that frozen main Store, not Git HEAD.',
 'candidate_unmodified_main_source_matches':len(records),'missing_unmodified_main_source':missing,'mismatched_unmodified_main_source':mismatches,
 'patch_check_exit':check.returncode,'patch_apply_exit':apply.returncode,'patch_output_files':outputs,
 'disposition':'patch applies to byte-exact frozen main Store input/current main file; strict Git HEAD-only application fails because it predates this main working-tree baseline'}
(qa/'worktree-base-patch-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
