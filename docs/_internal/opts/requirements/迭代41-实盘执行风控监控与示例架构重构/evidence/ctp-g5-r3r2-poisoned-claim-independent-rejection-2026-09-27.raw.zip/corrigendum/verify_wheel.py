import csv
import hashlib
import json
import zipfile
from pathlib import Path

wheel = Path(r'D:\q\unified-v20r3-wheelhouse-20260927\bt_api_execution-0.2.0-py3-none-any.whl')
consumer_receipt_path = Path(r'D:\temp\iteration41-unified-v20r3-consumer-20260927\receipt.json')
old_evidence_path = Path(r'D:\temp\iteration41-g5-cancel-issuer-r3r2-evidence.json')
site = Path(r'D:\q\unified-v20r3-consumer-20260927\Lib\site-packages')
direct_url_path = site / 'bt_api_execution-0.2.0.dist-info' / 'direct_url.json'
old_evidence = json.loads(old_evidence_path.read_text(encoding='utf-8-sig'))
consumer_receipt = json.loads(consumer_receipt_path.read_text(encoding='utf-8-sig'))
sha256 = lambda data: hashlib.sha256(data).hexdigest()
wheel_bytes = wheel.read_bytes()
actual_sha = sha256(wheel_bytes)
consumer_artifacts = [a for a in consumer_receipt['artifacts'] if a.get('distribution') == 'bt_api_execution']
if len(consumer_artifacts) != 1:
    raise SystemExit('expected exactly one execution artifact in frozen consumer receipt')
consumer_artifact = consumer_artifacts[0]
direct_url = json.loads(direct_url_path.read_text(encoding='utf-8-sig'))
with zipfile.ZipFile(wheel) as archive:
    names = set(archive.namelist())
    record_names = [name for name in names if name.endswith('.dist-info/RECORD')]
    if len(record_names) != 1:
        raise SystemExit('wheel must contain exactly one RECORD')
    rows = list(csv.reader(archive.read(record_names[0]).decode('utf-8').splitlines()))
    verified_rows = 0
    for name, encoded_hash, encoded_size in rows:
        if name not in names:
            raise SystemExit(f'RECORD names absent wheel member: {name}')
        data = archive.read(name)
        if encoded_size and str(len(data)) != encoded_size:
            raise SystemExit(f'RECORD size mismatch: {name}')
        if encoded_hash:
            mode, value = encoded_hash.split('=', 1)
            digest = hashlib.new(mode, data).digest()
            import base64
            actual_value = base64.urlsafe_b64encode(digest).decode('ascii').rstrip('=')
            if actual_value != value:
                raise SystemExit(f'RECORD digest mismatch: {name}')
            verified_rows += 1
    metadata_candidates = [name for name in names if name.endswith('.dist-info/METADATA')]
    if len(metadata_candidates) != 1:
        raise SystemExit('wheel must contain exactly one METADATA')
    metadata = archive.read(metadata_candidates[0]).decode('utf-8')
    wheel_version = next((line.split(': ', 1)[1] for line in metadata.splitlines() if line.startswith('Version: ')), None)
    record_sha = sha256(archive.read(record_names[0]))
old_sha = old_evidence['executionWheel']['sha256']
result = {
    'schema': 'iteration41.g5.execution-wheel-corrigendum.v2',
    'prior_evidence': {
        'path': str(old_evidence_path),
        'sha256': sha256(old_evidence_path.read_bytes()),
        'executionWheel_sha256_recorded': old_sha,
        'executionWheel_sha256_recorded_length': len(old_sha),
        'correction': 'prior value had one extra trailing e; original evidence file is preserved unchanged',
    },
    'corrected_artifact': {
        'path': str(wheel),
        'sha256': actual_sha,
        'size': len(wheel_bytes),
        'sha256_length': len(actual_sha),
        'wheel_metadata_version': wheel_version,
        'record_path': record_names[0],
        'record_sha256': record_sha,
        'record_rows': len(rows),
        'record_hashed_rows_verified': verified_rows,
    },
    'consumer_crosscheck': {
        'receipt_path': str(consumer_receipt_path),
        'receipt_sha256': sha256(consumer_receipt_path.read_bytes()),
        'receipt_distribution_wheel_path': consumer_artifact['wheel']['path'],
        'receipt_distribution_wheel_sha256': consumer_artifact['wheel']['sha256'],
        'receipt_source_manifest_sha256': consumer_receipt['source_provenance']['execution_v20_r3']['source_manifest_sha256'],
        'receipt_source_commit': consumer_receipt['source_provenance']['execution_v20_r3']['source_commit'],
        'installed_direct_url_path': str(direct_url_path),
        'installed_direct_url_sha256': sha256(direct_url_path.read_bytes()),
        'installed_direct_url': direct_url,
        'installed_package_origin': consumer_artifact['installed_package_origin'],
        'installed_record_sha256': consumer_artifact['installed_record_sha256'],
    },
    'checks': {
        'wheel_matches_consumer_receipt': actual_sha == consumer_artifact['wheel']['sha256'],
        'wheel_matches_installed_direct_url': actual_sha == direct_url['archive_info']['hashes']['sha256'],
        'wheel_path_matches_installed_direct_url': str(wheel).replace('\\', '/') in direct_url['url'],
        'wheel_metadata_matches_consumer_receipt': wheel_version == consumer_artifact['version'],
        'old_field_is_wrong_length': len(old_sha) == 65,
        'old_field_prefixes_actual_hash': old_sha[:-1] == actual_sha,
    },
}
if not all(result['checks'].values()):
    raise SystemExit('one or more wheel evidence crosschecks failed')
output = Path(r'D:\temp\iteration41-g5-evidence-corrigendum-v2\corrigendum.json')
output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(result, sort_keys=True))
