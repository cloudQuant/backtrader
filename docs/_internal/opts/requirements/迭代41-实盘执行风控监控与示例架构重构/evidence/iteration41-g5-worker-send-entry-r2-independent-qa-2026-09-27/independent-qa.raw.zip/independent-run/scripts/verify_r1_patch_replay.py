import hashlib, json, subprocess
from pathlib import Path
qa=Path(r"D:\temp\iteration41-g5-worker-projection-r2-independent-qa-20260927")
r1=qa/'r1-replay'
r2=qa/'isolated-r2'/'candidate'
expected_r1_manifest='5ddb3ca53bff3d61d287846a5feeaa8814fa9d211da109dd05f527c534351fbf'
expected_patch='48aa0096432bcb4e46ee93c886d659b67a0ad402522898db01e58a32926d4f48'
manifest_path=r1/'evidence'/'final-output-manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
errors=[]
if hashlib.sha256(manifest_path.read_bytes()).hexdigest()!=expected_r1_manifest: errors.append('r1_manifest_sha')
for row in manifest.get('outputs',[]):
    p=r1/Path(row['path'])
    if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
        errors.append('r1_output:'+row['path'])
patch=r2/'implementation'/'sdk_patch'/'G5_SEND_ENTRY_FAIL_CLOSED_R2.patch'
if hashlib.sha256(patch.read_bytes()).hexdigest()!=expected_patch: errors.append('r2_patch_sha')
check=subprocess.run(['git','apply','--check',str(patch)],cwd=r1,text=True,capture_output=True)
with (qa/'logs'/'r2-patch-apply-check.log').open('w',encoding='utf-8') as f:
    f.write(check.stdout); f.write(check.stderr)
if check.returncode: errors.append('git_apply_check:'+str(check.returncode))
apply=subprocess.run(['git','apply',str(patch)],cwd=r1,text=True,capture_output=True)
with (qa/'logs'/'r2-patch-apply.log').open('w',encoding='utf-8') as f:
    f.write(apply.stdout); f.write(apply.stderr)
if apply.returncode: errors.append('git_apply:'+str(apply.returncode))
r2man=json.loads((r2/'candidate-output-manifest.json').read_text(encoding='utf-8'))
r2files={row['path']:row for row in r2man['files']}
compare_paths=[
 'README.md',
 'implementation/sdk/src/bt_api_execution/ctp_single_worker_candidate.py',
 'implementation/tests/_g5_worker_test_support.py',
 'implementation/tests/test_g5_worker_send_entry_r2.py',
]
comparisons=[]
for name in compare_paths:
    replay=r1/Path(name); expected=r2/Path(name); row=r2files.get(name)
    ok=(row is not None and replay.is_file() and expected.is_file() and replay.read_bytes()==expected.read_bytes() and hashlib.sha256(replay.read_bytes()).hexdigest()==row['sha256'])
    comparisons.append({'path':name,'matches_r2_bytes_and_hash':ok,'sha256':hashlib.sha256(replay.read_bytes()).hexdigest() if replay.is_file() else None})
    if not ok: errors.append('r2_output_mismatch:'+name)
old_test=r1/'implementation'/'tests'/'test_g5_single_worker_action_handoff.py'
if old_test.exists(): errors.append('old_R1_worker_test_still_exists')
receipt={'format':'g5-send-entry-r1-to-r2-patch-replay.v1','r1_output_manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'r1_verified_output_count':len(manifest.get('outputs',[])),'r2_patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'git_apply_check_exit':check.returncode,'git_apply_exit':apply.returncode,'changed_outputs':comparisons,'old_R1_test_removed':not old_test.exists(),'errors':errors,'passed':not errors}
(qa/'logs'/'r1-to-r2-patch-replay.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(receipt,sort_keys=True))
if errors: raise SystemExit(1)
