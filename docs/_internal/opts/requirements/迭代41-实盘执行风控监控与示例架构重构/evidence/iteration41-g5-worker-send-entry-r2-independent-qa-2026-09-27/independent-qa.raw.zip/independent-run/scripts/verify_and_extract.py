import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

qa = Path(r"D:\temp\iteration41-g5-worker-projection-r2-independent-qa-20260927")
source_root = Path(r"D:\temp\iteration41-g5-worker-projection-r2-boundary-20260927")
archive = qa / "frozen-input" / "r2-candidate.zip"
manifest_path = qa / "frozen-input" / "candidate-output-manifest.json"
sidecar = qa / "frozen-input" / "candidate-output-manifest.sha256"
expected_zip = "1ce285ed3e90f778ad05f55ded4263e522a54e04c7a20e3a5c30009bb298e283"
expected_manifest = "2b92b0a4d777221714f6b13f93eb9b39388993b4d0a585b35113d1eb4d6ed5e3"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
zip_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
manifest_sha = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
sidecar_sha = sidecar.read_text(encoding="ascii").split()[0].lower()
errors = []
if zip_sha != expected_zip: errors.append("zip_sha_expected")
if manifest_sha != expected_manifest: errors.append("manifest_sha_expected")
if sidecar_sha != manifest_sha: errors.append("manifest_sidecar")
if manifest.get("files_count") != len(manifest.get("files", [])): errors.append("manifest_count")
expected_names = {row["path"] for row in manifest["files"]} | {manifest_path.name, sidecar.name}
extracted = qa / "isolated-r2" / "candidate"
extracted.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive, "r") as zf:
    if zf.testzip() is not None: errors.append("zip_crc")
    names = set(zf.namelist())
    if names != expected_names: errors.append("zip_member_set")
    for name in names:
        p = PurePosixPath(name)
        if p.is_absolute() or ".." in p.parts or "\\" in name or (p.parts and ":" in p.parts[0]):
            errors.append("unsafe_member:" + name)
    for row in manifest["files"]:
        name = row["path"]
        data = zf.read(name)
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            errors.append("archive_hash:" + name)
        src = source_root / "r2-candidate" / Path(name)
        if not src.is_file() or src.stat().st_size != row["bytes"] or hashlib.sha256(src.read_bytes()).hexdigest() != row["sha256"]:
            errors.append("extracted_source_hash:" + name)
    zf.extractall(extracted)

# Re-check extracted bytes independently of zip payload checks.
for row in manifest["files"]:
    path = extracted / Path(row["path"])
    if not path.is_file() or path.stat().st_size != row["bytes"] or hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
        errors.append("isolated_extract_hash:" + row["path"])
for name, expected in ((manifest_path.name, expected_manifest), (sidecar.name, hashlib.sha256(sidecar.read_bytes()).hexdigest())):
    p = extracted / name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != expected:
        errors.append("manifest_member:" + name)
receipt = {
    "format": "g5-send-entry-r2-independent-integrity.v1",
    "zip_sha256": zip_sha,
    "expected_zip_sha256": expected_zip,
    "manifest_sha256": manifest_sha,
    "expected_manifest_sha256": expected_manifest,
    "sidecar_matches": sidecar_sha == manifest_sha,
    "payload_file_count": len(manifest["files"]),
    "zip_member_count": len(names),
    "errors": errors,
    "passed": not errors,
    "isolated_candidate": str(extracted),
}
(qa / "logs" / "integrity-receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(receipt, sort_keys=True))
if errors: raise SystemExit(1)
