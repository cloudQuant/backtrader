import hashlib,json
from pathlib import Path
from zipfile import ZIP_DEFLATED,ZipFile
root=Path(r"D:\temp\iteration41-g5-worker-projection-r2-independent-qa-packet-20260927")
archive=root/'independent-qa.raw.zip'
include=[root/'frozen-input',root/'independent-run',root/'REPORT.md']
files=[]
for base in include:
    paths=[base] if base.is_file() else sorted(p for p in base.rglob('*') if p.is_file())
    for p in paths:
        b=p.read_bytes(); files.append({'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as zf:
    for row in files:
        p=root/Path(row['path'])
        zf.write(p,row['path'])
raw=archive.read_bytes()
manifest={'format':'iteration41-g5-send-entry-r2-independent-qa-packet.v1','verdict':'G5_NOT_ACCEPTED','r2_zip_sha256':'1ce285ed3e90f778ad05f55ded4263e522a54e04c7a20e3a5c30009bb298e283','r2_manifest_sha256':'2b92b0a4d777221714f6b13f93eb9b39388993b4d0a585b35113d1eb4d6ed5e3','r1_zip_sha256':'c75cba6adcf7db95e420d0d4cfafac39e7179eb6db985cce5096a4c49237d268','payload_file_count':len(files),'raw_zip':{'path':archive.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'files':files}
(root/'packet-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'payload_file_count':len(files),'zip_bytes':len(raw),'zip_sha256':manifest['raw_zip']['sha256'],'manifest_sha256':hashlib.sha256((root/'packet-manifest.json').read_bytes()).hexdigest()},sort_keys=True))
