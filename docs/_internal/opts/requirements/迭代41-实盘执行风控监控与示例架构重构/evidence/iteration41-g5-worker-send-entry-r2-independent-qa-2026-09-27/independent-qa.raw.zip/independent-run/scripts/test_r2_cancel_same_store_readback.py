from __future__ import annotations

from _g5_worker_test_support import _open, _prepared, _queue, _reserve_action, _seed_order, _target_projection
from bt_api_execution.ctp_single_worker_candidate import CtpManagedSingleWorkerCandidate


def test_cancel_final_ttl_gate_reads_claimed_projection_from_same_store(tmp_path, monkeypatch):
    store, authority, scope, lease = _open(tmp_path / "same-store-final-read.sqlite3")
    try:
        order = _seed_order(authority, scope, lease)
        action = _reserve_action(authority, scope, lease, order)
        prepared = _prepared(order)
        worker = CtpManagedSingleWorkerCandidate(store, scope, lease, authority)
        projection_handle = _target_projection(store, order, prepared)
        binding = worker.stage_prepared_dispatch(
            prepared,
            cancel_target_projection=projection_handle,
            action_identity=action,
        )
        staged = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert staged is not None
        binding = worker.record_managed_queue_receipt(
            prepared.command_id, binding, _queue(binding, staged)
        )

        expiry = projection_handle.projection.expires_at_ns
        times = [expiry - 1, expiry]
        samples = []

        def controlled_now():
            value = times.pop(0) if times else expiry
            samples.append(value)
            return value

        monkeypatch.setattr(store, "_monotonic_now_ns", controlled_now)
        original = store.require_fresh_ctp_cancel_target_for_dispatch
        readback = []

        def traced_same_store_readback(actual_scope, command_id):
            observed = store.read_ctp_dispatch_command(actual_scope, command_id)
            readback.append(
                {
                    "same_store": store is worker._store,
                    "same_scope": actual_scope == scope,
                    "command_id": command_id,
                    "durable_status_at_read": None if observed is None else observed.status,
                }
            )
            return original(actual_scope, command_id)

        monkeypatch.setattr(store, "require_fresh_ctp_cancel_target_for_dispatch", traced_same_store_readback)
        result = worker.dispatch_managed_command(prepared.command_id, binding)
        persisted = store.read_ctp_dispatch_command(scope, prepared.command_id)
        handoff = store._connection.execute(
            "SELECT state FROM g5_ctp_worker_handoffs WHERE account_key = ? AND command_id = ?",
            (scope.account_key, prepared.command_id),
        ).fetchone()

        assert samples[:2] == [expiry - 1, expiry]
        assert readback == [
            {
                "same_store": True,
                "same_scope": True,
                "command_id": prepared.command_id,
                "durable_status_at_read": "CLAIMED",
            }
        ]
        assert result.worker_state == "REJECTED"
        assert result.native_call_entered is False
        assert persisted is not None and persisted.status == "COMPLETED"
        assert persisted.native_receipt_payload == {
            "kind": "native_send_port_unavailable",
            "outcome": "REJECTED",
        }
        assert handoff is not None and handoff["state"] == "REJECTED"
    finally:
        store.close()


def test_private_port_replacement_is_not_an_os_or_object_integrity_boundary(tmp_path):
    """A caller already holding the worker object can monkeypatch Python internals."""
    store, authority, scope, lease = _open(tmp_path / "private-port-replacement.sqlite3")
    try:
        from _g5_worker_test_support import _prepared_submit

        order = _seed_order(authority, scope, lease)
        prepared = _prepared_submit(order)
        worker = CtpManagedSingleWorkerCandidate(store, scope, lease, authority)
        binding = worker.stage_prepared_dispatch(prepared)
        staged = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert staged is not None
        binding = worker.record_managed_queue_receipt(
            prepared.command_id, binding, _queue(binding, staged)
        )
        fake_native_entries = []

        class ReplacedPrivatePort:
            def dispatch(self, actual_store, actual_scope, command):
                fake_native_entries.append(
                    {
                        "same_store": actual_store is store,
                        "same_scope": actual_scope == scope,
                        "command_status": command.status,
                        "operation": command.operation,
                    }
                )

        # This is outside the public dispatch signature and models arbitrary
        # same-process code with a reference to the worker object. No real SDK
        # method is imported or called.
        worker._native_send_port = ReplacedPrivatePort()
        result = worker.dispatch_managed_command(prepared.command_id, binding)
        persisted = store.read_ctp_dispatch_command(scope, prepared.command_id)
        assert fake_native_entries == [
            {
                "same_store": True,
                "same_scope": True,
                "command_status": "CLAIMED",
                "operation": "SUBMIT",
            }
        ]
        # The fake port's side effect occurs, then dispatch still persists the
        # default unavailable rejection. COMPLETED is a local receipt status.
        assert result.worker_state == "REJECTED"
        assert result.native_call_entered is False
        assert persisted is not None and persisted.status == "COMPLETED"
        assert persisted.native_receipt_payload == {
            "kind": "native_send_port_unavailable",
            "outcome": "REJECTED",
        }
    finally:
        store.close()
