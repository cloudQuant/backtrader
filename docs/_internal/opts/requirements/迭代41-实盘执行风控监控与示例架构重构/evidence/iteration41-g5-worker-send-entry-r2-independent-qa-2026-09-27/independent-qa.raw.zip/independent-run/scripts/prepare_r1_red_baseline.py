from pathlib import Path
import hashlib,json
qa=Path(r"D:\temp\iteration41-g5-worker-projection-r2-independent-qa-20260927")
src=qa/'isolated-r2'/'candidate'/'evidence'/'r1-send-entry-regressions.py'
out=qa/'r1-red-tests'/'test_r1_send_entry_regressions.py'
text=src.read_text(encoding='utf-8')
old=r"D:\temp\iteration41-g5-worker-projection-r2-boundary-20260927\r1-frozen-candidate"
new=str(qa/'r1-red-baseline')
if old not in text: raise SystemExit('original frozen R1 path not found')
text=text.replace(old,new)
out.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'test_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'r1_root':new}))
