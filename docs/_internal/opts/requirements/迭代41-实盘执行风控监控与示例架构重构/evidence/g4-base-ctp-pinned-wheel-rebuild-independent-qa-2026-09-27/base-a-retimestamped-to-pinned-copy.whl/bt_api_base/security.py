"""
Security utilities for API key management and encryption.

Provides secure storage and retrieval of API credentials using encryption
and environment variable management.
"""

from __future__ import annotations

import base64
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False
    InvalidToken = Exception  # type: ignore[misc, assignment]


class SecureCredentialManager:
    """
    Manage API credentials securely with optional encryption.

    Features:
    - Environment variable loading with .env support
    - Optional encryption for stored credentials
    - Secure credential validation
    - Credential masking for logging
    """

    def __init__(self, encryption_key: str | None = None):
        """__init__ method"""
        self._encryption_key = encryption_key
        self._cipher = None
        self._salt = None

        if encryption_key and CRYPTO_AVAILABLE:
            self._cipher, self._salt = self._create_cipher(encryption_key)
        elif encryption_key and not CRYPTO_AVAILABLE:
            raise ImportError(
                "cryptography package required for encryption. "
                "Install with: pip install cryptography"
            )

    @staticmethod
    def _create_cipher(password: str, salt: bytes | None = None) -> tuple[Fernet, bytes]:
        if salt is None:
            salt = os.urandom(16)
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return Fernet(key), salt

    def encrypt_credential(self, credential: str) -> str:
        """encrypt_credential method"""
        if not self._cipher:
            return credential

        encrypted = self._cipher.encrypt(credential.encode())
        return base64.urlsafe_b64encode(encrypted).decode()

    def decrypt_credential(self, encrypted_credential: str) -> str:
        """decrypt_credential method"""
        if not self._cipher:
            return encrypted_credential

        encrypted_bytes = base64.urlsafe_b64decode(encrypted_credential.encode())
        decrypted = self._cipher.decrypt(encrypted_bytes)
        return decrypted.decode()

    @staticmethod
    def load_from_env(key: str, default: str | None = None) -> str | None:
        """load_from_env method"""
        return os.getenv(key, default)

    @staticmethod
    def mask_credential(credential: str, visible_chars: int = 4) -> str:
        """mask_credential method"""
        visible_chars = max(0, visible_chars)
        if not credential or len(credential) <= visible_chars * 2:
            return "****"

        start = credential[:visible_chars]
        end = credential[-visible_chars:] if visible_chars > 0 else ""
        return f"{start}{'*' * (len(credential) - visible_chars * 2)}{end}"

    @staticmethod
    def validate_api_key(api_key: str, min_length: int = 16) -> bool:
        """validate_api_key method"""
        if not api_key or not isinstance(api_key, str):
            return False

        normalized = api_key.strip()
        if len(normalized) < min_length:
            return False

        placeholders = ["your_api_key", "api_key_here", "placeholder", "example"]
        normalized_lower = normalized.lower()
        if normalized_lower in placeholders:
            return False
        return not (normalized_lower.startswith("your_") and normalized_lower.endswith("_here"))

    def get_exchange_credentials(self, exchange: str, encrypted: bool = False) -> dict[str, Any]:
        """get_exchange_credentials method"""
        exchange = exchange.upper()
        credentials = {}

        if exchange == "BINANCE":
            credentials = {
                "api_key": self.load_from_env("BINANCE_API_KEY"),
                "secret": self.load_from_env("BINANCE_SECRET"),
                "testnet": (self.load_from_env("BINANCE_TESTNET", "false") or "").lower() == "true",
            }
        elif exchange == "OKX":
            credentials = {
                "api_key": self.load_from_env("OKX_API_KEY"),
                "secret": self.load_from_env("OKX_SECRET"),
                "passphrase": self.load_from_env("OKX_PASSPHRASE"),
                "testnet": (self.load_from_env("OKX_TESTNET", "false") or "").lower() == "true",
            }
        elif exchange == "CTP":
            credentials = {
                "broker_id": self.load_from_env("CTP_BROKER_ID"),
                "user_id": self.load_from_env("CTP_USER_ID"),
                "password": self.load_from_env("CTP_PASSWORD"),
                "md_front": self.load_from_env("CTP_MD_FRONT"),
                "td_front": self.load_from_env("CTP_TD_FRONT"),
            }
        elif exchange == "IB":
            credentials = {
                "account_id": self.load_from_env("IB_ACCOUNT_ID"),
                "username": self.load_from_env("IB_USERNAME"),
                "password": self.load_from_env("IB_PASSWORD"),
            }

        if encrypted and self._cipher:
            for key, value in credentials.items():
                if value and isinstance(value, str) and key != "testnet":
                    try:
                        credentials[key] = self.decrypt_credential(value)
                    except (InvalidToken, ValueError, UnicodeDecodeError) as e:
                        logger.warning(f"Failed to decrypt credential for {exchange}.{key}: {e}")
                        credentials[key] = None

        return credentials


def load_credentials_from_env_file(env_file: str | Path = ".env") -> dict[str, str | None]:
    """load_credentials_from_env_file function"""
    try:
        from dotenv import dotenv_values

        return dotenv_values(env_file)
    except ImportError:
        env_vars: dict[str, str | None] = {}
        env_path = Path(env_file)

        if not env_path.exists():
            return env_vars

        with env_path.open(encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    env_vars[key.strip()] = value.strip().strip('"').strip("'")

        return env_vars


def create_env_template(output_file: str | Path = ".env.example") -> None:
    """create_env_template function"""
    template = """# Binance API Credentials
BINANCE_API_KEY=your_binance_api_key_here
BINANCE_SECRET=your_binance_secret_here
BINANCE_TESTNET=false

# OKX API Credentials
OKX_API_KEY=your_okx_api_key_here
OKX_SECRET=your_okx_secret_here
OKX_PASSPHRASE=your_okx_passphrase_here
OKX_TESTNET=false

# CTP Credentials
CTP_BROKER_ID=9999
CTP_USER_ID=your_ctp_user_id_here
CTP_PASSWORD=your_ctp_password_here
CTP_MD_FRONT=tcp://180.168.146.187:10211
CTP_TD_FRONT=tcp://180.168.146.187:10201

# Interactive Brokers Credentials
IB_ACCOUNT_ID=your_ib_account_id_here
IB_USERNAME=your_ib_username_here
IB_PASSWORD=your_ib_password_here

# Security Settings
ENCRYPTION_KEY=your_encryption_key_here

# Testing
SKIP_LIVE_TESTS=true
"""

    output_path = Path(output_file)
    with output_path.open("w", encoding="utf-8") as f:
        f.write(template)
