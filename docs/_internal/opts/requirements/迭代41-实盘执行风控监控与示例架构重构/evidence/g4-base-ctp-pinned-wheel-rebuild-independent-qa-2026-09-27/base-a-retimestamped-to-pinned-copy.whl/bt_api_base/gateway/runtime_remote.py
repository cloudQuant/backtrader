from __future__ import annotations

import contextlib
import logging
import threading
import time
from collections import deque
from typing import TYPE_CHECKING, Any

import zmq

from bt_api_base.gateway.health import ConnectionState, GatewayHealth, GatewayState
from bt_api_base.gateway.order_identity_map import OrderIdentityMap
from bt_api_base.gateway.order_ref_allocator import OrderRefAllocator
from bt_api_base.gateway.protocol import CHANNEL_EVENT, CHANNEL_MARKET, dumps_message, loads_message
from bt_api_base.gateway.registrar import GatewayRuntimeRegistrar
from bt_api_base.gateway.subscription_manager import SubscriptionManager
from bt_api_base.plugins.loader import PluginLoader
from bt_api_base.registry import ExchangeRegistry

if TYPE_CHECKING:
    from bt_api_base.gateway.adapters.base import BaseGatewayAdapter
    from bt_api_base.gateway.config import GatewayConfig
    from bt_api_base.gateway.storage.tick_writer import TickWriter

logger = logging.getLogger(__name__)

_WRITE_COMMANDS = frozenset({"place_order", "cancel_order"})
_TRADING_DISABLED_REASON = "gateway trading is disabled"


class GatewayRuntime:
    ADAPTER_REGISTRY: dict[str, type[BaseGatewayAdapter]] = {}
    _plugins_loaded = False
    _plugin_loader_lock = threading.Lock()

    def __init__(self, config: GatewayConfig, **kwargs: Any) -> None:
        self.config = config
        self.kwargs = dict(kwargs)
        self.context = zmq.Context.instance()
        self.command_socket: zmq.Socket | None = None
        self.event_socket: zmq.Socket | None = None
        self.market_socket: zmq.Socket | None = None
        self.poller = zmq.Poller()
        self.adapter = self._create_adapter()
        self.running = False
        self._adapter_connected = False
        self.thread: threading.Thread | None = None

        self.subscriptions = SubscriptionManager()
        self.order_map = OrderIdentityMap()
        self.health = GatewayHealth()
        self.order_ref_allocator: OrderRefAllocator | None = None
        self.tick_writer: TickWriter | None = None
        self._last_runtime_heartbeat_monotonic = 0.0
        self._recent_trades: deque[dict[str, Any]] = deque(
            maxlen=max(int(kwargs.get("recent_trades_limit") or 1000), 1)
        )

        if config.exchange_type == "CTP":
            state_dir = kwargs.get("state_dir") or config.base_dir or "/tmp/bt_gateway_state"  # nosec B108
            self.order_ref_allocator = OrderRefAllocator(config.account_id, state_dir=state_dir)

        tick_writer_cfg = kwargs.get("tick_writer")
        if isinstance(tick_writer_cfg, dict):
            from bt_api_base.gateway.storage.tick_writer import TickWriter as _TickWriter

            self.tick_writer = _TickWriter(
                base_dir=tick_writer_cfg.get("base_dir", "/tmp/bt_ticks"),  # nosec B108
                exchange=config.exchange_type,
                asset_type=config.asset_type,
                flush_count=tick_writer_cfg.get("flush_count", 1000),
                flush_interval_sec=tick_writer_cfg.get("flush_interval_sec", 5.0),
            )

        self.health.set_extra("exchange", config.exchange_type)
        self.health.set_extra("asset_type", config.asset_type)
        self.health.set_extra("account_id", config.account_id)

    def start(self) -> None:
        if self.running:
            return
        self.health.set_state(GatewayState.STARTING)
        self._adapter_connected = False
        try:
            self.command_socket = self.context.socket(zmq.ROUTER)
            self.event_socket = self.context.socket(zmq.PUB)
            self.market_socket = self.context.socket(zmq.PUB)
            self.command_socket.bind(self.config.command_endpoint)
            self.event_socket.bind(self.config.event_endpoint)
            self.market_socket.bind(self.config.market_endpoint)
            self.poller.register(self.command_socket, zmq.POLLIN)
        except zmq.ZMQError as exc:
            self.health.set_state(GatewayState.ERROR)
            self.health.record_error("runtime_start", f"{type(exc).__name__}: {exc}")
            logger.error(
                "GatewayRuntime failed to bind sockets for %s: %s: %s",
                self.config.exchange_type,
                type(exc).__name__,
                exc,
            )
            self._cleanup_sockets()
            self.running = False
            return
        if self.tick_writer is not None:
            self.tick_writer.start()
        self.running = True
        self.health.set_state(GatewayState.RUNNING)
        self._refresh_runtime_heartbeat(force=True)
        adapter_thread = threading.Thread(target=self._connect_adapter_background, daemon=True)
        adapter_thread.start()
        logger.info("GatewayRuntime started: %s", self.config.exchange_type)
        try:
            while self.running:
                try:
                    self._handle_commands()
                    if self._adapter_connected:
                        self._flush_adapter_output()
                    self._refresh_runtime_heartbeat()
                except zmq.ZMQError as exc:
                    if not self.running:
                        break
                    self._handle_runtime_failure("runtime_loop", exc)
                    return
                except Exception as exc:
                    if not self.running:
                        break
                    self._handle_runtime_failure("runtime_loop", exc)
                    return
        finally:
            self._cleanup_sockets()

    def start_in_thread(self) -> None:
        if self.thread is not None and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.start, daemon=True)
        self.thread.start()
        deadline = time.monotonic() + 2.0
        while (
            not self.running
            and self.health.state != GatewayState.ERROR
            and time.monotonic() < deadline
        ):
            time.sleep(0.05)

    def stop(self) -> None:
        self.health.set_state(GatewayState.STOPPING)
        self.running = False
        self._adapter_connected = False
        try:
            self.adapter.disconnect()
        except Exception as exc:
            logger.warning(
                "GatewayRuntime adapter disconnect failed for %s: %s: %s",
                self.config.exchange_type,
                type(exc).__name__,
                exc,
            )
            self.health.record_error("runtime_stop", f"{type(exc).__name__}: {exc}")
        self.health.update_market_connection(ConnectionState.DISCONNECTED)
        self.health.update_trade_connection(ConnectionState.DISCONNECTED)
        if self.tick_writer is not None:
            self.tick_writer.stop()
        if (
            self.thread is not None
            and self.thread.is_alive()
            and threading.current_thread() is not self.thread
        ):
            self.thread.join(timeout=1.0)
        self._cleanup_sockets()
        self.health.set_state(GatewayState.STOPPED)
        logger.info("GatewayRuntime stopped: %s", self.config.exchange_type)

    @classmethod
    def _ensure_plugins_loaded(cls) -> None:
        if cls._plugins_loaded:
            return
        with cls._plugin_loader_lock:
            if cls._plugins_loaded:
                return
            loader = PluginLoader(ExchangeRegistry(), GatewayRuntimeRegistrar)
            loader.load_all()
            cls._plugins_loaded = True

    @classmethod
    def register_adapter(cls, exchange_type: str, adapter_cls: type[BaseGatewayAdapter]) -> None:
        normalized = str(exchange_type).strip().upper()
        cls.ADAPTER_REGISTRY[normalized] = adapter_cls
        GatewayRuntimeRegistrar.register_adapter(normalized, adapter_cls)

    @classmethod
    def get_adapter_class(cls, exchange_type: str) -> type[BaseGatewayAdapter]:
        normalized = str(exchange_type).strip().upper()
        adapter_cls = cls.ADAPTER_REGISTRY.get(normalized)
        if adapter_cls is not None:
            return adapter_cls
        cls._ensure_plugins_loaded()
        adapter_cls = GatewayRuntimeRegistrar.get_adapter(normalized)
        if adapter_cls is None:
            raise ValueError(f"unsupported gateway exchange: {exchange_type}")
        cls.ADAPTER_REGISTRY[normalized] = adapter_cls
        return adapter_cls

    def _create_adapter(self) -> BaseGatewayAdapter:
        adapter_cls = self.get_adapter_class(self.config.exchange_type)
        return adapter_cls(**self.kwargs)

    def _handle_commands(self) -> None:
        sock = self.command_socket
        if sock is None:
            return
        events = dict(self.poller.poll(timeout=self.config.poll_timeout_ms))
        if sock not in events:
            return
        parts = sock.recv_multipart()
        identity = parts[0]
        payload = loads_message(parts[-1])
        request_id = str(payload.get("request_id") or "")
        command = str(payload.get("command") or "").lower()
        data = dict(payload.get("payload") or {})
        if request_id:
            data.setdefault("request_id", request_id)
            data.setdefault("command_request_id", request_id)
        try:
            result = self._dispatch(command, data)
            response = {"request_id": request_id, "status": "ok", "data": result}
        except Exception as exc:
            self.health.record_error(
                "command", f"{command or '<empty>'}: {type(exc).__name__}: {exc}"
            )
            logger.warning(
                "Gateway command failed for %s request_id=%s command=%s: %s: %s",
                self.config.exchange_type,
                request_id,
                command or "<empty>",
                type(exc).__name__,
                exc,
            )
            response = {"request_id": request_id, "status": "error", "error": str(exc)}
        if self.command_socket is not None:
            sock.send_multipart([identity, dumps_message(response)])
        self._publish(CHANNEL_EVENT, {"kind": "command_result", **response, "command": command})

    def _connect_adapter_background(self) -> None:
        max_retries = 3
        self.health.update_market_connection(ConnectionState.CONNECTING)
        for attempt in range(max_retries):
            if not self.running:
                return
            try:
                self.adapter.connect()
                self._adapter_connected = True
                self.health.update_market_connection(ConnectionState.CONNECTED)
                logger.info(
                    "Adapter connected: %s (attempt %d)",
                    self.config.exchange_type,
                    attempt + 1,
                )
                return
            except Exception as exc:
                next_state = (
                    ConnectionState.RECONNECTING
                    if attempt < max_retries - 1 and self.running
                    else ConnectionState.ERROR
                )
                self.health.update_market_connection(next_state)
                logger.warning(
                    "Adapter connect attempt %d/%d failed: %s: %s",
                    attempt + 1,
                    max_retries,
                    type(exc).__name__,
                    exc,
                )
                self.health.record_error(
                    "adapter_connect",
                    f"attempt {attempt + 1}/{max_retries} {type(exc).__name__}: {exc}",
                )
                if attempt < max_retries - 1 and self.running:
                    time.sleep(2.0)
        self._adapter_connected = False
        self.health.update_market_connection(ConnectionState.ERROR)
        logger.error(
            "Adapter failed to connect after %d attempts for %s",
            max_retries,
            self.config.exchange_type,
        )

    def _subscribe_for_strategy(self, strategy_id: str, symbols: list[str]) -> dict[str, Any]:
        requested_symbols = [str(symbol) for symbol in symbols if str(symbol)]
        if not requested_symbols:
            self._sync_health_counts()
            return {"subscribed": [], "accepted": [], "skipped": []}

        existing_symbols = self.subscriptions.get_active_symbols()
        already_active = [symbol for symbol in requested_symbols if symbol in existing_symbols]
        newly_requested = [symbol for symbol in requested_symbols if symbol not in existing_symbols]

        accepted_new = list(newly_requested)
        skipped_symbols: list[str] = []
        if newly_requested:
            adapter_result = self.adapter.subscribe_symbols(list(newly_requested))
            if isinstance(adapter_result, dict):
                accepted_candidate = (
                    adapter_result.get("accepted")
                    or adapter_result.get("symbols")
                    or adapter_result.get("subscribed")
                    or []
                )
                accepted_new = [str(symbol) for symbol in accepted_candidate if str(symbol)]
                skipped_candidate = (
                    adapter_result.get("skipped") or adapter_result.get("skipped_symbols") or []
                )
                skipped_symbols = [str(symbol) for symbol in skipped_candidate if str(symbol)]

        self.subscriptions.add(strategy_id, already_active)
        newly_subscribed = self.subscriptions.add(strategy_id, accepted_new)
        self._sync_health_counts()

        accepted_total = sorted({*already_active, *accepted_new})
        skipped_total = sorted(
            {symbol for symbol in skipped_symbols if symbol not in accepted_total}
        )
        return {
            "subscribed": sorted(newly_subscribed),
            "accepted": accepted_total,
            "skipped": skipped_total,
        }

    def _dispatch(self, command: str, payload: dict[str, Any]) -> Any:
        if command in _WRITE_COMMANDS and not self.config.enable_trading:
            raise PermissionError(_TRADING_DISABLED_REASON)
        if command == "ping":
            self.health.record_heartbeat()
            return {"ready": self._adapter_connected}
        if command == "register_strategy":
            strategy_id = str(payload.get("strategy_id") or "")
            symbols = list(payload.get("symbols") or [])
            if self._adapter_connected:
                result = self._subscribe_for_strategy(strategy_id, symbols)
                return {
                    "strategy_id": strategy_id,
                    "newly_subscribed": result["subscribed"],
                    "accepted": result["accepted"],
                    "skipped": result["skipped"],
                }
            newly = self.subscriptions.add(strategy_id, symbols)
            self._sync_health_counts()
            return {
                "strategy_id": strategy_id,
                "newly_subscribed": sorted(newly),
                "accepted": sorted(symbols),
                "skipped": [],
            }
        if command == "unregister_strategy":
            strategy_id = str(payload.get("strategy_id") or "")
            removed = self.subscriptions.remove_strategy(strategy_id)
            self._sync_health_counts()
            return {"strategy_id": strategy_id, "unsubscribed": sorted(removed)}
        if command == "health":
            return self.health.snapshot()
        if not self._adapter_connected:
            raise RuntimeError(f"adapter not yet connected, cannot execute: {command}")
        if command == "subscribe":
            symbols = list(payload.get("symbols") or [])
            strategy_id = str(payload.get("strategy_id") or "default")
            return self._subscribe_for_strategy(strategy_id, symbols)
        if command == "get_balance":
            return self.adapter.get_balance()
        if command == "get_positions":
            return self.adapter.get_positions()
        if command == "get_trades":
            symbol = str(payload.get("symbol") or "").strip() or None
            limit = int(payload.get("limit") or 100)
            return self.get_trades(symbol=symbol, limit=limit)
        if command == "place_order":
            request_id = str(payload.get("request_id") or "")
            strategy_id = str(payload.get("strategy_id") or "default")
            client_order_id = self._order_text(
                payload, "client_order_id", "order_ref", "bt_order_ref"
            )
            if client_order_id and not payload.get("client_order_id"):
                payload["client_order_id"] = client_order_id
            self.order_map.register(
                request_id,
                strategy_id,
                client_order_id=client_order_id,
                symbol=payload.get("symbol"),
            )
            if self.order_ref_allocator is not None:
                client_oid = self.order_ref_allocator.next()
                self.order_map.set_client_order_id(request_id, client_oid)
                payload["client_order_id"] = client_oid
            self.health.record_order()
            result = self.adapter.place_order(payload)
            self._record_order_result_ids(request_id, payload, result)
            return result
        if command == "cancel_order":
            return self.adapter.cancel_order(payload)
        if command == "get_bars":
            symbol = str(payload.get("symbol") or "")
            timeframe = str(payload.get("timeframe") or "M1")
            count = int(payload.get("count") or 100)
            return self.adapter.get_bars(symbol, timeframe, count)
        if command == "get_symbol_info":
            symbol = str(payload.get("symbol") or "")
            return self.adapter.get_symbol_info(symbol)
        if command == "get_open_orders":
            return self.adapter.get_open_orders()
        raise ValueError(f"unsupported command: {command}")

    @staticmethod
    def _order_text(row: dict[str, Any], *keys: str) -> str | None:
        for key in keys:
            value = row.get(key)
            if value not in (None, ""):
                return str(value).strip()
        return None

    @classmethod
    def _nested_order_text(cls, row: dict[str, Any], *keys: str) -> str | None:
        direct = cls._order_text(row, *keys)
        if direct:
            return direct
        details = row.get("details")
        if isinstance(details, dict):
            return cls._order_text(details, *keys)
        return None

    def _record_order_result_ids(
        self,
        request_id: str,
        payload: dict[str, Any],
        result: Any,
    ) -> None:
        rows: list[dict[str, Any]] = []
        if isinstance(result, dict):
            rows.append(result)
        elif isinstance(result, list):
            rows.extend(item for item in result if isinstance(item, dict))
        rows.append(payload)

        client_order_id = next(
            (
                value
                for row in rows
                if (
                    value := self._nested_order_text(
                        row,
                        "client_order_id",
                        "order_ref",
                        "bt_order_ref",
                        "clOrdId",
                        "clientOrderId",
                        "OrderRef",
                    )
                )
            ),
            None,
        )
        if client_order_id:
            self.order_map.set_client_order_id(request_id, client_order_id)

        venue_order_id = next(
            (
                value
                for row in rows
                if (
                    value := self._nested_order_text(
                        row,
                        "venue_order_id",
                        "external_order_id",
                        "order_id",
                        "ordId",
                        "OrderSysID",
                        "orderSysId",
                        "ticket",
                        "id",
                    )
                )
            ),
            None,
        )
        if venue_order_id:
            self.order_map.set_venue_order_id(request_id, venue_order_id)

    def _refresh_runtime_heartbeat(self, *, force: bool = False) -> None:
        if not self.running and not force:
            return
        now = time.monotonic()
        if not force and (now - self._last_runtime_heartbeat_monotonic) < 1.0:
            return
        self.health.record_heartbeat()
        self._last_runtime_heartbeat_monotonic = now

    def _flush_adapter_output(self) -> None:
        while True:
            item = self.adapter.poll_output()
            if item is None:
                return
            channel, payload = item
            if channel == CHANNEL_MARKET:
                self.health.record_tick()
                if self.tick_writer is not None and hasattr(payload, "symbol"):
                    self.tick_writer.write(payload)
            elif channel == CHANNEL_EVENT:
                payload = self._enrich_event_payload(payload)
                self._record_trade_event(payload)
            self._publish(channel, payload)

    def get_trades(self, symbol: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        limit = max(int(limit or 100), 1)
        getter = getattr(self.adapter, "get_trades", None)
        if callable(getter):
            try:
                rows = getter(symbol=symbol, limit=limit)
            except Exception as exc:
                self.health.record_error("get_trades", f"{type(exc).__name__}: {exc}")
                rows = []
            if rows:
                return self._filter_trade_rows(rows, symbol=symbol, limit=limit)
        return self._filter_trade_rows(list(self._recent_trades), symbol=symbol, limit=limit)

    def _record_trade_event(self, payload: Any) -> None:
        if not isinstance(payload, dict):
            return
        if str(payload.get("kind") or "").strip().lower() != "trade":
            return
        self._recent_trades.append(dict(payload))

    @classmethod
    def _filter_trade_rows(
        cls,
        rows: Any,
        *,
        symbol: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        if not isinstance(rows, (list, tuple)):
            return []
        out: list[dict[str, Any]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            if symbol and not cls._trade_symbol_matches(row, symbol):
                continue
            out.append(dict(row))
        return out[-limit:]

    @classmethod
    def _trade_symbol_matches(cls, row: dict[str, Any], symbol: str) -> bool:
        expected = cls._compact_symbol(symbol)
        if not expected:
            return True
        for key in (
            "symbol",
            "data_name",
            "instrument",
            "instrument_id",
            "InstrumentID",
            "instId",
            "position_symbol_name",
            "symbol_name",
        ):
            value = cls._compact_symbol(str(row.get(key) or ""))
            if value and value == expected:
                return True
        return False

    @staticmethod
    def _compact_symbol(symbol: str) -> str:
        return "".join(ch for ch in str(symbol or "").upper() if ch.isalnum())

    def _sync_health_counts(self) -> None:
        self.health.update_counts(
            strategy_count=self.subscriptions.strategy_count,
            symbol_count=self.subscriptions.symbol_count,
        )

    def _publish(self, channel: str, payload: Any) -> None:
        try:
            if channel == CHANNEL_MARKET and self.market_socket is not None:
                self.market_socket.send(
                    dumps_message(payload.to_dict() if hasattr(payload, "to_dict") else payload)
                )
            elif channel == CHANNEL_EVENT and self.event_socket is not None:
                self.event_socket.send(dumps_message(payload))
        except zmq.ZMQError:
            if self.running:
                raise

    def _enrich_event_payload(self, payload: Any) -> Any:
        if not isinstance(payload, dict):
            return payload
        event = dict(payload)
        entry = self._order_entry_for_event(event)
        if entry is None:
            return event

        event.setdefault("strategy_id", entry.strategy_id)
        event.setdefault("request_id", entry.request_id)
        if entry.client_order_id:
            event.setdefault("client_order_id", entry.client_order_id)
        if entry.venue_order_id:
            event.setdefault("venue_order_id", entry.venue_order_id)
        if entry.symbol:
            event.setdefault("symbol", entry.symbol)
            event.setdefault("data_name", entry.symbol)

        self._record_event_order_ids(entry, event)
        status = str(event.get("status") or "").strip()
        if status:
            self.order_map.update_status(entry.request_id, status)
        return event

    def _order_entry_for_event(self, event: dict[str, Any]) -> Any:
        for key in ("request_id", "command_request_id"):
            value = self._nested_order_text(event, key)
            if value:
                entry = self.order_map.by_request(value)
                if entry is not None:
                    return entry

        for key in (
            "client_order_id",
            "order_ref",
            "bt_order_ref",
            "ctp_order_ref",
            "clOrdId",
            "clientOrderId",
            "OrderRef",
        ):
            value = self._nested_order_text(event, key)
            if value:
                entry = self.order_map.by_client(value)
                if entry is not None:
                    return entry

        for key in (
            "venue_order_id",
            "external_order_id",
            "order_id",
            "ordId",
            "OrderSysID",
            "orderSysId",
            "ticket",
            "id",
        ):
            value = self._nested_order_text(event, key)
            if value:
                entry = self.order_map.by_venue(value)
                if entry is not None:
                    return entry
        return None

    def _record_event_order_ids(self, entry: Any, event: dict[str, Any]) -> None:
        client_order_id = self._nested_order_text(
            event,
            "client_order_id",
            "order_ref",
            "bt_order_ref",
            "ctp_order_ref",
            "clOrdId",
            "clientOrderId",
            "OrderRef",
        )
        if client_order_id and client_order_id != entry.client_order_id:
            self.order_map.set_client_order_id(entry.request_id, client_order_id)

        venue_order_id = self._nested_order_text(
            event,
            "venue_order_id",
            "external_order_id",
            "order_id",
            "ordId",
            "OrderSysID",
            "orderSysId",
            "ticket",
            "id",
        )
        if venue_order_id and venue_order_id != entry.venue_order_id:
            self.order_map.set_venue_order_id(entry.request_id, venue_order_id)

    def _handle_runtime_failure(self, source: str, exc: Exception) -> None:
        self.running = False
        self._adapter_connected = False
        self.health.set_state(GatewayState.ERROR)
        self.health.update_market_connection(ConnectionState.ERROR)
        self.health.update_trade_connection(ConnectionState.ERROR)
        self.health.record_error(source, f"{type(exc).__name__}: {exc}")
        logger.error(
            "GatewayRuntime failed for %s: %s: %s",
            self.config.exchange_type,
            type(exc).__name__,
            exc,
        )
        if self.tick_writer is not None:
            self.tick_writer.stop()
        try:
            self.adapter.disconnect()
        except Exception as disconnect_exc:
            logger.warning(
                "GatewayRuntime adapter disconnect failed during %s for %s: %s: %s",
                source,
                self.config.exchange_type,
                type(disconnect_exc).__name__,
                disconnect_exc,
            )
            self.health.record_error(
                f"{source}_disconnect",
                f"{type(disconnect_exc).__name__}: {disconnect_exc}",
            )

    def _cleanup_sockets(self) -> None:
        for socket in (self.command_socket, self.event_socket, self.market_socket):
            if socket is not None:
                with contextlib.suppress(KeyError):
                    self.poller.unregister(socket)
                try:
                    socket.close(0)
                except Exception as exc:
                    logger.warning(
                        "GatewayRuntime socket cleanup failed for %s: %s: %s",
                        self.config.exchange_type,
                        type(exc).__name__,
                        exc,
                    )
        self.command_socket = None
        self.event_socket = None
        self.market_socket = None
