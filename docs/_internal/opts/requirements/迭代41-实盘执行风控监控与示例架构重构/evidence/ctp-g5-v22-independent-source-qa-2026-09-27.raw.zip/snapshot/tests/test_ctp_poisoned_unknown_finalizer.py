from __future__ import annotations

import json
from dataclasses import replace

import pytest
from test_ctp_callback_session_router import (
    _active_owner,
    _Authority,
    _lease,
    _queue_and_complete,
    _reserve,
    _scope,
)

from bt_api_execution import (
    ContractValidationError,
    CtpDispatchReceipt,
    InvalidStateTransition,
    SqliteExecutionStore,
)


@pytest.mark.unit
def test_poisoned_claim_can_only_persist_exact_unknown_receipt(tmp_path):
    scope = _scope()
    store = SqliteExecutionStore(tmp_path / "session-poisoned-unknown-finalizer.sqlite3")
    lease = _lease(store, scope)
    try:
        owner = _active_owner(store, scope, lease)
        session = store._active_ctp_callback_sessions[owner.owner_intent_id]
        reservation = _reserve(
            store, scope, lease, session.session_generation_id, "poisoned-finalize"
        )
        request = {
            "InstrumentID": "rb2710",
            "ExchangeID": "SHFE",
            "OrderRef": reservation.order_ref,
            "Direction": "0",
            "CombOffsetFlag": "0",
            "CombHedgeFlag": "1",
            "LimitPrice": 100.0,
            "VolumeTotalOriginal": 1,
            "OrderPriceType": "2",
            "TimeCondition": "3",
        }
        staged, claim = _queue_and_complete(
            store,
            scope,
            lease,
            owner,
            reservation,
            "poisoned-command",
            request,
            411,
            complete=False,
        )
        assert staged.status == "READY"
        assert claim is not None and claim.command.status == "CLAIMED"
        command = claim.command
        receipt = CtpDispatchReceipt(
            receipt_type="ctp_dispatch_receipt.v2",
            command_id=command.command_id,
            account_key=command.account_key,
            scope_key=command.scope_key,
            trading_day=command.trading_day,
            operation=command.operation,
            request_payload_sha256=command.request_payload_sha256,
            reservation_managed_intent_id=command.reservation_managed_intent_id,
            order_ref=command.order_ref,
            cancel_target_order_ref=command.cancel_target_order_ref,
            cancel_target_exchange_id=command.cancel_target_exchange_id,
            cancel_target_order_sys_id=command.cancel_target_order_sys_id,
            cancel_target_front_id=command.cancel_target_front_id,
            cancel_target_session_id=command.cancel_target_session_id,
            approval_use_id=command.approval_use_id,
            approval_digest=command.approval_digest,
            session_binding_sha256=command.session_binding_sha256,
            outcome="UNKNOWN",
            native_receipt_payload={"request_id": 411, "dispatch_state": "ambiguous"},
            correlation_key=command.correlation_key,
            local_queue_receipt_id=command.local_queue_receipt_id,
        )

        poison = store.poison_ctp_callback_session_owner(owner, "owner_binding_mismatch")
        assert poison.durable_state == "POISONED"

        store._connection.execute(
            """CREATE TRIGGER fail_poisoned_unknown_finalize
               BEFORE UPDATE OF status ON ctp_dispatch_commands
               WHEN OLD.command_id = 'poisoned-command'
                 AND OLD.status = 'CLAIMED' AND NEW.status = 'UNKNOWN'
               BEGIN SELECT RAISE(ABORT, 'injected finalizer write failure'); END"""
        )
        with pytest.raises(Exception, match="transaction failed"):
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, receipt, owner_handle=owner, writer_lease=lease
            )
        failed_row = store._connection.execute(
            "SELECT status, native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?",
            (command.command_id,),
        ).fetchone()
        assert (failed_row["status"], failed_row["native_call_inflight"]) == ("CLAIMED", 1)
        assert (
            store._connection.execute(
                "SELECT owner_state FROM ctp_account_family_owner_generations WHERE generation = ?",
                (lease.family_generation,),
            ).fetchone()["owner_state"]
            == "POISONED"
        )
        store._connection.execute("DROP TRIGGER fail_poisoned_unknown_finalize")

        result = store.complete_poisoned_ctp_dispatch_unknown_for_session(
            scope, receipt, owner_handle=owner, writer_lease=lease
        )
        assert result.status == "UNKNOWN"
        assert result.native_receipt_payload == receipt.native_receipt_payload
        assert result.completion_echo_sha256 is not None
        assert (
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, receipt, owner_handle=owner, writer_lease=lease
            )
            == result
        )

        row = store._connection.execute(
            "SELECT status, native_call_inflight, native_receipt_payload_json, "
            "completion_echo_json FROM ctp_dispatch_commands WHERE command_id = ?",
            (command.command_id,),
        ).fetchone()
        assert row["status"] == "UNKNOWN"
        assert row["native_call_inflight"] == 0
        assert json.loads(row["native_receipt_payload_json"]) == dict(
            receipt.native_receipt_payload
        )
        assert json.loads(row["completion_echo_json"])["outcome"] == "UNKNOWN"

        with pytest.raises((ContractValidationError, InvalidStateTransition)):
            store.complete_ctp_dispatch_command_for_session(
                scope,
                replace(receipt, outcome="QUEUED"),
                owner_handle=owner,
                writer_lease=lease,
            )
        changed_receipt = replace(
            receipt, native_receipt_payload={"request_id": 411, "dispatch_state": "different"}
        )
        with pytest.raises((ContractValidationError, InvalidStateTransition)):
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, changed_receipt, owner_handle=owner, writer_lease=lease
            )
        assert (
            store.claim_ctp_dispatch_command_for_session(
                scope,
                command.command_id,
                owner_handle=owner,
                writer_lease=lease,
                authority_verifier=_Authority(),
                required_local_queue_receipt_id=command.local_queue_receipt_id,
            )
            is None
        )
        persisted = store.read_ctp_dispatch_command(scope, command.command_id)
        assert persisted is not None and persisted.status == "UNKNOWN"
    finally:
        store.close()
