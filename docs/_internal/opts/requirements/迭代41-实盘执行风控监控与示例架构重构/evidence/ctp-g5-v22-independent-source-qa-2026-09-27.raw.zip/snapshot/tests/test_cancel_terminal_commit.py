from __future__ import annotations

from decimal import Decimal

import pytest

from bt_api_execution import (
    CancelIntent,
    CancelObservation,
    CancelObservationCommitV1,
    ContractValidationError,
    ExecutionScope,
    ExecutionState,
    InvalidStateTransition,
    OrderIntent,
    ProviderObservation,
    Side,
    SqliteExecutionStore,
    WriterLeaseUnavailable,
    payload_sha256,
)


def _scope(strategy_id: str = "strategy.cancel") -> ExecutionScope:
    return ExecutionScope("FAKE", "simulation", "acct_cancel", strategy_id, "20260927")


def _setup(tmp_path, *, partial: bool = False):
    scope = _scope()
    store = SqliteExecutionStore(tmp_path / "execution.sqlite3")
    lease = store.acquire_or_renew_lease(scope, "writer.cancel", ttl_ns=30_000_000_000)
    order = OrderIntent.limit(
        intent_id="order.cancel",
        scope=scope,
        signal_id="signal.cancel",
        instrument="FAKE-PERP",
        side=Side.BUY,
        quantity=Decimal("2"),
        price=Decimal("100"),
        metadata_version="meta.1",
    )
    store.admit_intent(order, writer_lease=lease)
    store.activate_intent(order.intent_id, scope, writer_lease=lease)
    _record, claimed = store.claim_for_dispatch(order.intent_id, scope, writer_lease=lease)
    assert claimed is True
    store.record_observation(
        ProviderObservation.accepted(order.intent_id, "provider.order.cancel"),
        scope=scope,
        writer_lease=lease,
    )
    if partial:
        store.record_observation(
            ProviderObservation(
                order.intent_id,
                ExecutionState.PARTIALLY_FILLED,
                provider_order_id="provider.order.cancel",
                filled_quantity=Decimal("0.5"),
                average_price=Decimal("100.25"),
                cumulative_commission=Decimal("-0.01"),
            ),
            scope=scope,
            writer_lease=lease,
        )
    cancel = CancelIntent(
        cancel_id="cancel.terminal",
        scope=scope,
        target_intent_id=order.intent_id,
        provider_order_id="provider.order.cancel",
        metadata_version="meta.1",
    )
    store.admit_cancel(cancel, writer_lease=lease)
    store.activate_cancel(cancel.cancel_id, scope, "permit.cancel", writer_lease=lease)
    _cancel_record, claimed = store.claim_cancel_for_dispatch(
        cancel.cancel_id, scope, writer_lease=lease
    )
    assert claimed is True
    return store, scope, lease, order, cancel


def _cancelled(cancel: CancelIntent) -> CancelObservation:
    return CancelObservation.cancelled(
        cancel.cancel_id, cancel.target_intent_id, cancel.provider_order_id
    )


def _event_hash(event) -> str:
    if event.__class__.__name__ == "CancelEvent":
        document = {
            "sequence": event.sequence,
            "event_id": event.event_id,
            "cancel_id": event.cancel_id,
            "target_intent_id": event.target_intent_id,
            "scope_key": event.scope_key,
            "event_type": event.event_type,
            "state": event.state.value,
            "payload": dict(event.payload),
            "created_at_ns": event.created_at_ns,
        }
    else:
        document = {
            "sequence": event.sequence,
            "event_id": event.event_id,
            "intent_id": event.intent_id,
            "scope_key": event.scope_key,
            "event_type": event.event_type,
            "state": event.state.value,
            "payload": dict(event.payload),
            "created_at_ns": event.created_at_ns,
            "journal_incarnation_id": event.journal_incarnation_id,
        }
    return payload_sha256(document)


def test_terminal_commit_returns_bound_cancel_and_target_events_atomically(tmp_path) -> None:
    store, scope, lease, order, cancel = _setup(tmp_path, partial=True)
    try:
        commit = store.record_cancel_observation_with_commit(
            _cancelled(cancel), scope=scope, writer_lease=lease
        )
        assert type(commit) is CancelObservationCommitV1
        assert commit.cancel_intent == cancel
        assert commit.cancel_record.state is ExecutionState.CANCELLED
        assert commit.cancel_record.dispatch_attempts == 1
        assert commit.cancel_event.scope_key == scope.key
        assert commit.cancel_event.cancel_id == cancel.cancel_id
        assert commit.cancel_event.target_intent_id == order.intent_id
        assert commit.cancel_event.state is ExecutionState.CANCELLED
        assert commit.cancel_event.event_type == "cancel_provider_observation"
        assert commit.cancel_event.payload == {
            "provider_order_id": cancel.provider_order_id,
            "reason_code": None,
            "source": "provider",
        }
        assert commit.cancel_event_sha256 == _event_hash(commit.cancel_event)
        assert commit.source_evidence_sha256 == payload_sha256(
            {
                "source": "provider",
                "provider_order_id": cancel.provider_order_id,
                "reason_code": None,
            }
        )
        assert commit.target_record.state is ExecutionState.CANCELLED
        assert commit.target_record.filled_quantity == Decimal("0.5")
        assert commit.target_record.average_price == Decimal("100.25")
        assert commit.target_record.cumulative_commission == Decimal("-0.01")
        assert commit.target_record_sha256 == payload_sha256(commit.target_record)
        assert commit.target_event.event_type == "cancelled_by_cancel_intent"
        assert commit.target_event.payload["cancel_id"] == cancel.cancel_id
        assert commit.target_event_sha256 == _event_hash(commit.target_event)
        assert commit.writer_lease == lease
        assert commit.writer_lease.fencing_token == lease.fencing_token
        with pytest.raises(TypeError):
            commit.cancel_event.payload["source"] = "forged"

        before = store.read_cancel_outbox(scope=scope)
        repeated = store.record_cancel_observation_with_commit(
            _cancelled(cancel), scope=scope, writer_lease=lease
        )
        recovered = store.read_terminal_cancel_commit(scope, cancel.cancel_id, writer_lease=lease)
        after = store.read_cancel_outbox(scope=scope)
        assert repeated == commit
        assert repeated.cancel_event.event_id == commit.cancel_event.event_id
        assert recovered == commit
        assert [event.event_id for event in after] == [event.event_id for event in before]
    finally:
        store.close()


def test_rejected_commit_binds_open_target_exposure_and_reconcile_source(tmp_path) -> None:
    store, scope, lease, order, cancel = _setup(tmp_path, partial=True)
    try:
        observation = CancelObservation.rejected(
            cancel.cancel_id,
            cancel.target_intent_id,
            cancel.provider_order_id,
            "cancel_rejected",
        )
        commit = store.record_cancel_observation_with_commit(
            observation, scope=scope, source="reconcile", writer_lease=lease
        )
        assert commit.cancel_record.state is ExecutionState.REJECTED
        assert commit.cancel_event.event_type == "cancel_reconciled_observation"
        assert commit.cancel_event.payload["source"] == "reconcile"
        assert commit.cancel_event.payload["reason_code"] == "cancel_rejected"
        assert commit.source_evidence_sha256 == payload_sha256(
            {
                "source": "reconcile",
                "provider_order_id": cancel.provider_order_id,
                "reason_code": "cancel_rejected",
            }
        )
        assert commit.target_record.state is ExecutionState.PARTIALLY_FILLED
        assert commit.target_record.intent_id == order.intent_id
        assert commit.target_record.filled_quantity == Decimal("0.5")
        assert commit.target_event.state is ExecutionState.PARTIALLY_FILLED
        assert commit.target_event_sha256 == _event_hash(commit.target_event)
        assert store.get(order.intent_id, scope=scope).state is ExecutionState.PARTIALLY_FILLED
        assert (
            store.read_terminal_cancel_commit(scope, cancel.cancel_id, writer_lease=lease) == commit
        )
        before = store.read_cancel_outbox(scope=scope)
        altered = CancelObservation.rejected(
            cancel.cancel_id,
            cancel.target_intent_id,
            cancel.provider_order_id,
            "different_reason",
        )
        with pytest.raises(InvalidStateTransition):
            store.record_cancel_observation_with_commit(
                altered, scope=scope, source="reconcile", writer_lease=lease
            )
        assert store.read_cancel_outbox(scope=scope) == before
    finally:
        store.close()


def test_terminal_commit_readback_recovers_after_commit_and_lease_rotation(tmp_path) -> None:
    store, scope, lease, _order, cancel = _setup(tmp_path)
    path = tmp_path / "execution.sqlite3"
    try:
        store.record_cancel_observation(_cancelled(cancel), scope=scope, writer_lease=lease)
        event_ids_before = [event.event_id for event in store.read_cancel_outbox(scope=scope)]
        assert store.release_lease(scope, lease.owner_id, fencing_token=lease.fencing_token)
        new_lease = store.acquire_or_renew_lease(scope, "writer.restarted", ttl_ns=30_000_000_000)
        assert new_lease.fencing_token > lease.fencing_token
        with pytest.raises(WriterLeaseUnavailable):
            store.read_terminal_cancel_commit(scope, cancel.cancel_id, writer_lease=lease)
        recovered = store.read_terminal_cancel_commit(
            scope, cancel.cancel_id, writer_lease=new_lease
        )
        assert recovered.cancel_event.cancel_id == cancel.cancel_id
        assert recovered.cancel_event.event_id in event_ids_before
        assert [
            event.event_id for event in store.read_cancel_outbox(scope=scope)
        ] == event_ids_before
    finally:
        store.close()
    reopened = SqliteExecutionStore(path)
    try:
        recovered = reopened.read_terminal_cancel_commit(
            scope, cancel.cancel_id, writer_lease=new_lease
        )
        assert recovered.cancel_event.event_id in event_ids_before
    finally:
        reopened.close()


def test_terminal_commit_rejects_nonterminal_and_preserves_legacy_write_behavior(tmp_path) -> None:
    store, scope, lease, _order, cancel = _setup(tmp_path)
    try:
        before = store.read_cancel_outbox(scope=scope)
        with pytest.raises(ContractValidationError):
            store.record_cancel_observation_with_commit(
                CancelObservation.accepted(
                    cancel.cancel_id, cancel.target_intent_id, cancel.provider_order_id
                ),
                scope=scope,
                writer_lease=lease,
            )
        assert store.read_cancel_outbox(scope=scope) == before

        acked = store.record_cancel_observation(
            CancelObservation.accepted(
                cancel.cancel_id, cancel.target_intent_id, cancel.provider_order_id
            ),
            scope=scope,
            writer_lease=lease,
        )
        assert acked.state is ExecutionState.ACKED
        with pytest.raises(InvalidStateTransition):
            store.read_terminal_cancel_commit(scope, cancel.cancel_id, writer_lease=lease)
        with pytest.raises(ContractValidationError):
            CancelObservation(
                cancel.cancel_id,
                cancel.target_intent_id,
                cancel.provider_order_id,
                ExecutionState.UNKNOWN,
            )
    finally:
        store.close()


def test_terminal_commit_rejects_wrong_scope_identity_and_later_review_event(tmp_path) -> None:
    store, scope, lease, _order, cancel = _setup(tmp_path)
    try:
        wrong_scope = _scope("strategy.other")
        wrong_account = ExecutionScope(
            "FAKE", "simulation", "acct_other", "strategy.cancel", "20260927"
        )
        with pytest.raises(ContractValidationError):
            store.read_terminal_cancel_commit(wrong_account, cancel.cancel_id, writer_lease=lease)
        with pytest.raises(ContractValidationError):
            store.read_terminal_cancel_commit(wrong_scope, cancel.cancel_id, writer_lease=lease)
        with pytest.raises(ContractValidationError):
            store.read_terminal_cancel_commit(scope, "cancel.other", writer_lease=lease)

        wrong_provider = CancelObservation.cancelled(
            cancel.cancel_id, cancel.target_intent_id, "provider.other"
        )
        before = store.read_cancel_outbox(scope=scope)
        with pytest.raises(InvalidStateTransition):
            store.record_cancel_observation_with_commit(
                wrong_provider, scope=scope, writer_lease=lease
            )
        assert store.read_cancel_outbox(scope=scope) == before

        store.record_cancel_observation_with_commit(
            _cancelled(cancel), scope=scope, writer_lease=lease
        )
        store.mark_cancel_review_required(
            cancel.cancel_id, scope, "manual_followup", writer_lease=lease
        )
        with pytest.raises(InvalidStateTransition):
            store.read_terminal_cancel_commit(scope, cancel.cancel_id, writer_lease=lease)
    finally:
        store.close()


def test_terminal_commit_readback_recovers_lost_return_after_commit(tmp_path, monkeypatch) -> None:
    store, scope, lease, _order, cancel = _setup(tmp_path)
    try:
        before = store.read_cancel_outbox(scope=scope)
        original = store._record_cancel_observation_core

        def lose_response_after_core_commit(*args, **kwargs):
            original(*args, **kwargs)
            raise RuntimeError("simulated lost response after durable commit")

        monkeypatch.setattr(
            store, "_record_cancel_observation_core", lose_response_after_core_commit
        )
        with pytest.raises(RuntimeError, match="lost response after durable commit"):
            store.record_cancel_observation_with_commit(
                _cancelled(cancel), scope=scope, writer_lease=lease
            )

        recovered = store.read_terminal_cancel_commit(scope, cancel.cancel_id, writer_lease=lease)
        assert recovered.cancel_event.event_id
        assert len(store.read_cancel_outbox(scope=scope)) == len(before) + 1
        assert store.read_cancel_outbox(scope=scope)[-1].event_id == recovered.cancel_event.event_id
    finally:
        store.close()
