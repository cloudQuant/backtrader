"""Independent QA fault injection for command/owner/proof recovery writes."""

from __future__ import annotations

import pytest

from bt_api_execution import DurableStoreError, InvalidStateTransition, SqliteExecutionStore
from test_ctp_process_exit_recovery_v22 import (
    _FakeAuthority,
    _FakeProcessExitVerifier,
    _active_fixture,
    _read_owner_state,
)


@pytest.mark.parametrize(
    ("table", "predicate"),
    [
        ("ctp_dispatch_commands", "OLD.status = 'CLAIMED' AND NEW.status = 'UNKNOWN'"),
        (
            "ctp_dispatch_callback_session_owners",
            "OLD.owner_state = 'ACTIVE' AND NEW.owner_state = 'POISONED'",
        ),
        ("ctp_account_family_owners", "OLD.owner_state = 'ACTIVE' AND NEW.owner_state = 'POISONED'"),
    ],
)
def test_v22_recovery_write_abort_rolls_back_and_keeps_account_fenced(tmp_path, table, predicate):
    verifier = _FakeProcessExitVerifier()
    store, scope, lease, family_owner, owner, _, commands, claimed = _active_fixture(
        tmp_path, verifier=verifier, command_count=2
    )
    trigger = "qa_abort_recovery_boundary"
    store._connection.execute(
        f"CREATE TRIGGER {trigger} BEFORE UPDATE ON {table} "
        f"WHEN {predicate} BEGIN SELECT RAISE(ABORT, 'qa boundary abort'); END"
    )
    with pytest.raises(DurableStoreError, match="transaction failed"):
        store._recover_ctp_claims_after_verified_process_exit(scope)

    command = store._connection.execute(
        "SELECT status, native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?",
        (claimed.command_id,),
    ).fetchone()
    assert tuple(command) == ("CLAIMED", 1)
    assert tuple(_read_owner_state(store, owner)[:2]) == ("ACTIVE", None)
    assert store._connection.execute(
        "SELECT owner_state FROM ctp_account_family_owners WHERE family_key = ?",
        (family_owner.family_key,),
    ).fetchone()[0] == "ACTIVE"
    assert store._connection.execute(
        "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
    ).fetchone()[0] == 0

    # A second claim remains blocked by the unresolved in-flight command.
    with pytest.raises(InvalidStateTransition, match="unresolved CTP dispatch command"):
        store.claim_ctp_dispatch_command(
            scope,
            commands[1].command_id,
            writer_lease=lease,
            authority_verifier=_FakeAuthority(),
            _callback_session_owner=owner,
        )
    store._connection.execute(f"DROP TRIGGER {trigger}")
    path = store.path
    store.close()

    reopened = SqliteExecutionStore(path)
    try:
        command = reopened._connection.execute(
            "SELECT status, native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()
        assert tuple(command) == ("CLAIMED", 1)
        assert reopened._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0] == 0
        with pytest.raises(InvalidStateTransition):
            reopened.acquire_ctp_account_family_owner(scope)
        with pytest.raises(InvalidStateTransition, match="not configured"):
            reopened._recover_ctp_claims_after_verified_process_exit(scope)
    finally:
        reopened.close()


def test_v22_committed_unknown_poison_rejects_replay_redispatch_and_successor(tmp_path):
    verifier = _FakeProcessExitVerifier()
    store, scope, lease, family_owner, owner, _, commands, claimed = _active_fixture(
        tmp_path, verifier=verifier, command_count=2
    )
    try:
        assert store._recover_ctp_claims_after_verified_process_exit(scope) == (
            claimed.command_id,
        )
        row = store._connection.execute(
            "SELECT status, native_call_inflight FROM ctp_dispatch_commands WHERE command_id = ?",
            (claimed.command_id,),
        ).fetchone()
        assert tuple(row) == ("UNKNOWN", 0)
        assert tuple(_read_owner_state(store, owner)[:2]) == (
            "POISONED",
            "owner_process_exit_verified",
        )
        assert store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owners WHERE family_key = ?",
            (family_owner.family_key,),
        ).fetchone()[0] == "POISONED"
        assert store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owner_generations "
            "WHERE family_key = ? AND generation = ?",
            (family_owner.family_key, family_owner.generation),
        ).fetchone()[0] == "POISONED"

        with pytest.raises(InvalidStateTransition):
            store.claim_ctp_dispatch_command(
                scope,
                commands[1].command_id,
                writer_lease=lease,
                authority_verifier=_FakeAuthority(),
                _callback_session_owner=owner,
            )
        assert store.read_ctp_dispatch_command(scope, commands[1].command_id).status == "READY"
        with pytest.raises(InvalidStateTransition, match="uniquely active"):
            store._recover_ctp_claims_after_verified_process_exit(scope)
        assert len(verifier.calls) == 1
        with pytest.raises(InvalidStateTransition):
            store.recover_claimed_ctp_dispatch_commands(scope, writer_lease=lease)
        assert store.read_ctp_dispatch_command(scope, claimed.command_id).status == "UNKNOWN"
        path = store.path
    finally:
        store.close()

    reopened = SqliteExecutionStore(path)
    try:
        assert reopened.read_ctp_dispatch_command(scope, claimed.command_id).status == "UNKNOWN"
        assert reopened.read_ctp_dispatch_command(scope, commands[1].command_id).status == "READY"
        with pytest.raises(InvalidStateTransition):
            reopened.acquire_ctp_account_family_owner(scope)
    finally:
        reopened.close()
