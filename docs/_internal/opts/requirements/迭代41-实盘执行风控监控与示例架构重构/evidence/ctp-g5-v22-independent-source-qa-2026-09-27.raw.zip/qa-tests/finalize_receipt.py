"""Recheck frozen/copy hashes and write the independent source-QA receipt."""

from __future__ import annotations

import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path


QA = Path(r"D:\temp\iteration41_v22_g5_independent_qa_20260927")
SNAP = QA / "snapshot"
FREEZE = Path(r"D:\temp\iteration41_v22_g5_crash_recovery_r3r3_candidate_20260927")
CANDIDATE_MANIFEST = Path(
    r"D:\temp\iteration41_v22_g5_crash_recovery_qa_20260927\V22-CANDIDATE-MANIFEST.json"
)
BASELINE_SHA = "00577665667a33c9a7d62d331c0cad99b0b660790d0b475d0bd8c1b6caa6e2dd"
CANDIDATE_SHA = "8244038ab975f30de6c0ba56c140f033ddd5b5ce5fb3cabc9e60abb7bf24066d"
V20_STORE = Path(
    r"D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\src\bt_api_execution\store.py"
)
V21_STORE = Path(
    r"D:\temp\iteration41_v20_r3r3_v21_handoff_freeze_r1_20260927\src\bt_api_execution\store.py"
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(raw: str) -> Path:
    return Path(*Path(raw.replace("\\", "/")).parts)


def check(path: Path, expected_sha: str, expected_bytes: int | None = None) -> dict[str, object]:
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_sha.lower():
        raise AssertionError(f"SHA mismatch: {path}")
    if expected_bytes is not None and len(raw) != expected_bytes:
        raise AssertionError(f"byte-count mismatch: {path}")
    return {"path": str(path), "bytes": len(raw), "sha256": actual}


def junit_facts(path: Path) -> dict[str, object]:
    root = ET.parse(path).getroot()
    cases = list(root.iter("testcase"))
    skipped = []
    for case in cases:
        node = case.find("skipped")
        if node is not None:
            skipped.append(
                {
                    "node_id": f"{case.attrib.get('classname', '')}::{case.attrib.get('name', '')}",
                    "reason": node.attrib.get("message", "").strip(),
                }
            )
    failures = [case for case in cases if case.find("failure") is not None or case.find("error") is not None]
    return {
        "tests": len(cases),
        "passed": len(cases) - len(skipped) - len(failures),
        "skipped": skipped,
        "failed": len(failures),
        "junit": str(path),
        "junit_sha256": sha(path),
    }


def main() -> None:
    copy_receipt_path = QA / "copy-receipt.json"
    copy_receipt = json.loads(copy_receipt_path.read_text(encoding="utf-8"))
    assert copy_receipt["status"] == "VERIFIED_V22_SOURCE_COPY"
    assert copy_receipt["candidate_manifest_sha256"] == CANDIDATE_SHA
    assert copy_receipt["accepted_composite_manifest_sha256"] == BASELINE_SHA

    candidate_raw = CANDIDATE_MANIFEST.read_bytes()
    assert hashlib.sha256(candidate_raw).hexdigest() == CANDIDATE_SHA
    candidate = json.loads(candidate_raw.decode("utf-8"))
    base = candidate["base"]
    composite_path = FREEZE / "COMPOSITE-SOURCE-MANIFEST.json"
    composite_raw = composite_path.read_bytes()
    assert hashlib.sha256(composite_raw).hexdigest() == BASELINE_SHA
    composite = json.loads(composite_raw.decode("utf-8"))

    base_entries = {item["path"]: item for item in composite["source_files"]}
    deltas = {item["path"]: item for item in candidate["delta_files"]}
    final_entries = dict(base_entries)
    final_entries.update(deltas)
    assert len(base_entries) == 38
    assert len(final_entries) == 39
    root_source_checks = []
    for name, item in sorted(final_entries.items()):
        root_source_checks.append(
            check(FREEZE / relative(name), item["sha256"], item["bytes"])
        )
    assert len(root_source_checks) == 39

    copy_source_checks = []
    for item in copy_receipt["copied_source_entries"]:
        copy_source_checks.append(
            check(SNAP / relative(item["path"]), item["sha256"], item["bytes"])
        )
    assert len(copy_source_checks) == 39
    copied_base = check(
        SNAP / "COMPOSITE-SOURCE-MANIFEST.json", BASELINE_SHA
    )
    copied_candidate = check(
        SNAP / "V22-CANDIDATE-MANIFEST.json", CANDIDATE_SHA
    )

    expected_snapshot_files = set(final_entries)
    expected_snapshot_files.update(
        {"COMPOSITE-SOURCE-MANIFEST.json", "V22-CANDIDATE-MANIFEST.json"}
    )
    snapshot_files = {
        p.relative_to(SNAP).as_posix() for p in SNAP.rglob("*") if p.is_file()
    }
    generated_extras = sorted(snapshot_files - expected_snapshot_files)
    missing_files = sorted(expected_snapshot_files - snapshot_files)
    if missing_files:
        raise AssertionError(f"manifest-declared copy files missing after tests: {missing_files}")

    assert sha(V20_STORE) == str(candidate["migration"]["legacy_v20_store_sha256"]).lower()
    assert sha(V21_STORE) == str(candidate["migration"]["legacy_v21_store_sha256"]).lower()

    focused = junit_facts(QA / "logs" / "focused-final.xml")
    full = junit_facts(QA / "logs" / "full-final.xml")
    boundary = junit_facts(QA / "logs" / "boundary-final.xml")
    assert focused["failed"] == full["failed"] == boundary["failed"] == 0
    assert focused["passed"] == 240 and len(focused["skipped"]) == 2
    assert full["passed"] == 313 and len(full["skipped"]) == 2
    assert boundary["passed"] == 4 and not boundary["skipped"]
    for fact in (focused, full):
        for skip in fact["skipped"]:
            if "real_trader_client" in skip["node_id"] or "real_sdk_event" in skip["node_id"]:
                assert "provider/native import blocked" in skip["reason"]

    evidence_paths = [
        QA / "copy-receipt.json",
        QA / "logs" / "guard-self-check.log",
        QA / "logs" / "focused-collection.log",
        QA / "logs" / "focused-final.log",
        QA / "logs" / "focused-final.xml",
        QA / "logs" / "full-final.log",
        QA / "logs" / "full-final.xml",
        QA / "logs" / "boundary-final.log",
        QA / "logs" / "boundary-final.xml",
        QA / "logs" / "ruff.log",
        QA / "logs" / "qa-ruff.log",
        QA / "logs" / "pycompile.log",
        QA / "logs" / "v20-fixture-pristine.log",
        QA / "logs" / "v20-fixture-pristine-sha.log",
        QA / "logs" / "v20-migration-final.log",
        QA / "logs" / "v20-fixture-migrated-sha.log",
        QA / "qa-tests" / "build_v20_inflight_claim.py",
        QA / "qa-tests" / "verify_v20_claim_migration.py",
        QA / "qa-tests" / "test_v22_recovery_boundary_atomicity.py",
        QA / "qa-tests" / "finalize_receipt.py",
        QA / "fixtures" / "v20-claimed-inflight-pristine.sqlite3",
        QA / "fixtures" / "v20-claimed-inflight-migrated.sqlite3",
        QA / "logs" / "v22-v21-diff.patch",
        QA / "logs" / "v22-v21-diff-summary.txt",
    ]
    evidence = [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)} for path in evidence_paths]
    pre_fix = Path(
        r"D:\temp\iteration41_v22_g5_crash_recovery_qa_20260927\v22-full-pre-fix-failure-summary.json"
    )
    pre_fix_expected = "0ba506a5eacb5c75f0d6c731f223de877c08912f9ae9af82a2dd66fbc13c3ed7"
    check(pre_fix, pre_fix_expected, 3562)
    pre_fix_summary = json.loads(pre_fix.read_text(encoding="utf-8"))
    assert pre_fix_summary["result"] == {
        "passed": 287,
        "failed": 20,
        "skipped": 2,
        "duration_seconds": 28.93,
        "exit_status": "failure",
    }
    root_cause = pre_fix_summary["root_exception"]
    assert "no such table: execution_meta" in root_cause

    candidate_artifact_rows: dict[str, str | None] = {}
    for run in candidate.get("test_runs", []):
        if run.get("junit_path"):
            candidate_artifact_rows[run["junit_path"]] = run.get("junit_sha256")
        if run.get("stdout_path"):
            candidate_artifact_rows[run["stdout_path"]] = None
        if run.get("diagnostic_summary_path"):
            candidate_artifact_rows[run["diagnostic_summary_path"]] = run.get(
                "diagnostic_summary_sha256"
            )
    for artifact in candidate.get("validation_artifacts", []):
        candidate_artifact_rows[artifact["path"]] = artifact["sha256"]
    candidate_artifacts = []
    for raw_path, expected_hash in sorted(candidate_artifact_rows.items()):
        path = Path(raw_path)
        actual_hash = sha(path)
        if expected_hash is not None and actual_hash != expected_hash.lower():
            raise AssertionError(f"candidate-referenced evidence hash mismatch: {path}")
        candidate_artifacts.append(
            {"path": raw_path, "sha256": actual_hash, "manifest_sha256": expected_hash}
        )

    receipt = {
        "schema": "iteration41-v22-independent-source-qa-receipt.v1",
        "status": "SOURCE_QA_PASS_G5_BLOCKED",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "candidate_source_root": str(FREEZE),
        "candidate_manifest_path": str(CANDIDATE_MANIFEST),
        "candidate_manifest_sha256": CANDIDATE_SHA,
        "accepted_r3r3_v21_baseline_sha256": BASELINE_SHA,
        "package": "bt_api_execution",
        "version": "0.2.0",
        "source_only": True,
        "g5_authorized": False,
        "real_trading": False,
        "provider_or_native_calls": False,
        "external_network_access": False,
        "account_access": False,
        "manifest_integrity": {
            "baseline_source_entries": len(base_entries),
            "v22_delta_entries": len(deltas),
            "composed_source_entries": len(final_entries),
            "frozen_source_files_rechecked_after_tests": len(root_source_checks),
            "independent_copy_source_files_rechecked_after_tests": len(copy_source_checks),
            "frozen_source_hashes": root_source_checks,
            "copy_source_hashes": copy_source_checks,
            "copied_composite_manifest": copied_base,
            "copied_candidate_manifest": copied_candidate,
            "generated_unmanifested_snapshot_files": generated_extras,
            "missing_snapshot_files": missing_files,
        },
        "input_manifest_chain": {
            "cancel_manifest_sha256": base["cancel_input_manifest_sha256"],
            "v21_handoff_manifest_sha256": base["v21_handoff_input_manifest_sha256"],
            "v20_store_sha256": sha(V20_STORE),
            "v21_store_sha256": sha(V21_STORE),
        },
        "focused_suite": focused,
        "full_package_suite": full,
        "independent_write_boundary_adversarial_suite": boundary,
        "skipped_tests": focused["skipped"],
        "guard": {
            "self_check": "passed; CTP/provider imports and native library load blocked; external connect and DNS blocked",
            "external_test_skip_reason": "the two real CTP SDK path tests require provider/native imports, intentionally blocked by the guard",
        },
        "migration_checks": {
            "v20_empty_account_factory_migration": "passed in frozen V22 tests",
            "v20_nonempty_claimed_inflight_fixture": {
                "input_fixture_sha256": sha(QA / "fixtures" / "v20-claimed-inflight-pristine.sqlite3"),
                "input_state": "schema 20, CLAIMED, native_call_inflight=1, no process_generation_id",
                "migrated_fixture_sha256": sha(QA / "fixtures" / "v20-claimed-inflight-migrated.sqlite3"),
                "result": "schema 22; UNKNOWN; schema_upgrade_requires_ctp_v2_dispatch_cutover; native_call_inflight remains 1; process_generation_id NULL; no recovery proof; successor owner rejected",
                "callback_and_family_owner_state": "ACTIVE persisted rows, with successor acquisition still rejected by the durable owner and non-active family generation",
            },
            "v21_legacy_claim_without_process_binding": "passed frozen V22 test; CLAIMED migrated UNKNOWN, owner/family POISONED, no recovery proof, successor blocked",
            "malformed_nonempty_and_partial_schema_preflight": "passed frozen V22 test; no partial-schema repair or recovery proof",
        },
        "qa_harness_diagnostics": [
            "Initial QA-only V20 fixture build attempts exposed incorrect test fixture session-binding/native-seed parameters and an assumption that V20 had the V22 process_generation_id column; the final builder used the frozen V20 callback binding, native FrontID/SessionID seed, and V20 schema fields. A pristine V20 CLAIMED/inflight=1 fixture was rebuilt and hash-recorded before the final V22 migration check.",
            "These fixture-builder retries affected only separate QA temporary SQLite files; no frozen candidate or accepted baseline file was changed.",
        ],
        "process_generation_and_proof_checks": {
            "process_generation_binding": "passed local source contract: Store-issued generation bound across family owner, callback owner, and claimed rows",
            "process_generation_os_evidence": "not established; no production Windows supervisor/Job verifier or code pin is present",
            "fake_verifier_contract": "wrong persisted identities and bool process id rejected; exact-context fake capability accepted once; second recovery rejected before verifier replay; proof audit immutable",
            "trusted_windows_process_death_evidence": False,
        },
        "atomicity_and_no_redispatch": {
            "frozen_proof_insert_abort_test": "passed; command, callback owner, family owner and audit rolled back together",
            "qa_injected_abort_boundaries": "passed at CLAIMED->UNKNOWN command update, callback owner POISONED update, and family owner POISONED update; pre-state survived close/reopen",
            "committed_recovery": "UNKNOWN plus exact callback/family owner POISONED and one immutable audit row",
            "no_redispatch": "passed; another READY command remains READY and cannot be claimed after poison; generic claimed recovery rejected",
            "no_successor_owner": "passed before and after reopen",
        },
        "prior_pre_fix_diagnostic": {
            "artifact": str(pre_fix),
            "sha256": pre_fix_expected,
            "recorded_result": "287 passed, 20 failed, 2 skipped",
            "root_cause": root_cause,
            "root_cause_detail": pre_fix_summary["failure_class"],
            "fix_observed_in_frozen_candidate": "V21 preflight returns False for an empty SQLite schema before querying execution_meta; clean empty account-store creation/reopen test passes",
            "independent_reverification": "focused and full final suites passed on the exact copied V22 delta over the accepted composite",
            "diagnostic_limitation": "the prior failure summary records source_file_hash_at_run as not recorded and raw stdout was not persisted; the root cause is hash-bound to the summary but not to prior source bytes",
        },
        "candidate_referenced_evidence_hashes": candidate_artifacts,
        "commands": {
            "guard": "python guard/check_guard.py",
            "focused": "python -m pytest -p pytest_asyncio.plugin -c snapshot/pyproject.toml -q --junitxml logs/focused-final.xml <11 focused frozen test files> qa-tests/test_v22_recovery_boundary_atomicity.py",
            "full": "python -m pytest -p pytest_asyncio.plugin -c snapshot/pyproject.toml -q --junitxml logs/full-final.xml tests qa-tests/test_v22_recovery_boundary_atomicity.py",
            "ruff": "python -m ruff check . (snapshot); python -m ruff check qa-tests",
            "py_compile": "python -m py_compile src/bt_api_execution/store.py tests/test_ctp_process_exit_recovery_v22.py",
            "environment": {
                "python": "3.11.5",
                "pytest": "8.0.0",
                "pytest_asyncio": "0.23.0",
                "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONPATH": "<QA guard>;<independent snapshot>/src;<independent snapshot>/tests",
            },
        },
        "evidence_files": evidence,
    }
    (QA / "QA-RECEIPT.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    postcheck = {
        "status": "ALL_MANIFEST_HASHES_MATCH_AFTER_TESTS",
        "frozen_source_entries": len(root_source_checks),
        "copied_source_entries": len(copy_source_checks),
        "frozen_source_hashes": root_source_checks,
        "copied_source_hashes": copy_source_checks,
        "generated_unmanifested_snapshot_files": generated_extras,
        "missing_snapshot_files": missing_files,
        "receipt_sha256": sha(QA / "QA-RECEIPT.json"),
        "receipt_bytes": (QA / "QA-RECEIPT.json").stat().st_size,
    }
    (QA / "POSTTEST-INTEGRITY.json").write_text(
        json.dumps(postcheck, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(postcheck, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
