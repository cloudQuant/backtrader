"""Build a V20 CLAIMED/in-flight SQLite fixture with frozen fake-only code."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import test_ctp_callback_session_router as router_tests
import test_ctp_dispatch_commands as dispatch_tests
from bt_api_execution import CtpCallbackSessionStoreAdapter, SqliteExecutionStore


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: build_v20_inflight_claim.py <new database path>")
    database = Path(sys.argv[1])
    if database.exists():
        raise SystemExit(f"fixture destination already exists: {database}")
    database.parent.mkdir(parents=True, exist_ok=True)

    scope = dispatch_tests._scope()
    store = SqliteExecutionStore(database)
    try:
        store._bind_new_ctp_account_store_identity(scope, store._ctp_account_family_key(scope))
        family_owner = store.acquire_ctp_account_family_owner(scope)
        lease = store.acquire_or_renew_lease(
            scope,
            "v20-independent-qa-writer",
            ttl_ns=60_000_000_000,
            ctp_account_family_owner=family_owner,
        )
        owner = store.create_ctp_callback_session_owner(scope, writer_lease=lease)
        CtpCallbackSessionStoreAdapter(
            store,
            scope,
            owner,
            lease,
            lambda **kwargs: kwargs,
            router_tests.CtpTraderCallbackIngressRecordV2,
        )
        store.append_ctp_callback_ingress(
            owner,
            router_tests._record(
                owner, "OnFrontConnected", 1, phase="PRE_LOGIN", callback_class="PRE_LOGIN", generation=0
            ),
        )
        store.append_ctp_callback_ingress(
            owner,
            router_tests._record(
                owner,
                "OnRspAuthenticate",
                2,
                phase="PRE_LOGIN",
                callback_class="PRE_LOGIN",
                fields=((0, "BrokerID", "broker"), (0, "UserID", "user"), (1, "ErrorID", 0)),
            ),
        )
        login = router_tests._record(
            owner,
            "OnRspUserLogin",
            3,
            phase="PRE_LOGIN",
            callback_class="PRE_LOGIN",
            fields=(
                (0, "BrokerID", "broker"),
                (0, "UserID", "user"),
                (0, "TradingDay", scope.trading_day),
                (0, "FrontID", 31),
                (0, "SessionID", 41),
                (1, "ErrorID", 0),
            ),
        )
        store.append_ctp_callback_ingress(owner, login)
        binding = store.bind_ctp_callback_session(
            scope,
            owner,
            router_tests._LoginObservation(),
            router_tests._SourceTags(),
            3,
            writer_lease=lease,
        )
        reservation = store.seed_ctp_order_ref_and_reserve_identity(
            scope,
            router_tests._proof(scope, binding.session_generation_id),
            "v20-independent-qa-intent",
            dispatch_tests._runtime_id("v20-independent-qa-intent"),
            writer_lease=lease,
        )
        queue_id = "a" * 32
        command_id = "v20-independent-qa-claimed"
        command = store.stage_ctp_dispatch_command(
            scope,
            command_id,
            "SUBMIT",
            {
                "OrderRef": reservation.order_ref,
                "InstrumentID": "rb2710",
                "LimitPrice": "3510.5",
                "VolumeTotalOriginal": 1,
            },
            approval_use_id="v20-independent-qa-approval",
            approval_digest=hashlib.sha256(b"synthetic v20 QA approval").hexdigest(),
            session_binding=store._ctp_callback_session_binding_payload(binding),
            writer_lease=lease,
            managed_intent_id=reservation.managed_intent_id,
            order_ref=reservation.order_ref,
            managed_action_id=reservation.managed_intent_id,
            session_generation_id=binding.session_generation_id,
            dispatch_front_id=binding.dispatch_front_id,
            dispatch_session_id=binding.dispatch_session_id,
            native_request_id=dispatch_tests._native_request_id(command_id),
            local_queue_receipt_id=queue_id,
        )
        store.record_ctp_dispatch_queue_receipt(
            scope,
            command.command_id,
            {"kind": "command_receipt", "command": "submit", "receipt_id": queue_id, "queued": True},
            writer_lease=lease,
        )
        claim = store.claim_ctp_dispatch_command_for_session(
            scope,
            command.command_id,
            owner_handle=owner,
            writer_lease=lease,
            authority_verifier=dispatch_tests._authority_verifier(),
            required_local_queue_receipt_id=queue_id,
        )
        assert claim is not None and claim.command.status == "CLAIMED"
        row = store._connection.execute(
            "SELECT status, native_call_inflight "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (command.command_id,),
        ).fetchone()
        assert tuple(row) == ("CLAIMED", 1)
        output = {
            "fixture": str(database),
            "schema_version": store._connection.execute(
                "SELECT value FROM execution_meta WHERE key='schema_version'"
            ).fetchone()[0],
            "account_ref": scope.account_ref,
            "scope_key": scope.key,
            "family_key": family_owner.family_key,
            "callback_owner_intent_id": owner.owner_intent_id,
            "command_id": command.command_id,
            "legacy_status": row["status"],
            "legacy_native_call_inflight": row["native_call_inflight"],
            "legacy_process_generation_id": None,
            "provider_calls": 0,
            "network_calls": 0,
        }
        print(json.dumps(output, indent=2, sort_keys=True))
    finally:
        store.close()


if __name__ == "__main__":
    main()
