"""Open the V20 in-flight fixture with V22 and verify fail-closed recovery."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from bt_api_execution import DurableStoreError, ExecutionScope, InvalidStateTransition, SqliteExecutionStore


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_v20_claim_migration.py <database path>")
    database = Path(sys.argv[1])
    account_ref = "ctp-account-ref.v1:9f8a9f851daf9ba5f77d5e49218284e4567ca8dde518f6433f61cf86721dd47c"
    scope = ExecutionScope("ctp", "simulation", account_ref, "strategy.outbox", "20260925")
    store = SqliteExecutionStore(database)
    try:
        schema_version = store._connection.execute(
            "SELECT value FROM execution_meta WHERE key = 'schema_version'"
        ).fetchone()[0]
        assert schema_version == "22"
        command = store._connection.execute(
            "SELECT status, unknown_reason, native_call_inflight, process_generation_id, "
            "callback_owner_intent_id FROM ctp_dispatch_commands WHERE command_id = ?",
            ("v20-independent-qa-claimed",),
        ).fetchone()
        assert command is not None
        assert command["status"] == "UNKNOWN", tuple(command)
        assert command["unknown_reason"] == "schema_upgrade_requires_ctp_v2_dispatch_cutover"
        assert command["process_generation_id"] is None
        recovery_count = store._connection.execute(
            "SELECT COUNT(*) FROM ctp_process_exit_recoveries"
        ).fetchone()[0]
        assert recovery_count == 0
        owner = store._connection.execute(
            "SELECT owner_state, poison_code FROM ctp_dispatch_callback_session_owners "
            "WHERE owner_intent_id = ?",
            (command["callback_owner_intent_id"],),
        ).fetchone()
        family = store._connection.execute(
            "SELECT owner_state FROM ctp_account_family_owners WHERE account_key = ?",
            (scope.account_key,),
        ).fetchone()
        try:
            store.acquire_ctp_account_family_owner(scope)
        except (InvalidStateTransition, DurableStoreError) as exc:
            owner_acquisition = f"rejected: {type(exc).__name__}: {exc}"
        else:
            raise AssertionError("V22 admitted a successor family owner after legacy CLAIMED migration")
        output = {
            "schema_version": schema_version,
            "command_status": command["status"],
            "unknown_reason": command["unknown_reason"],
            "native_call_inflight_after_migration": command["native_call_inflight"],
            "process_generation_id": command["process_generation_id"],
            "recovery_proof_rows": recovery_count,
            "callback_owner_state": None if owner is None else owner["owner_state"],
            "callback_owner_poison_code": None if owner is None else owner["poison_code"],
            "family_owner_state": None if family is None else family["owner_state"],
            "successor_owner": owner_acquisition,
            "provider_calls": 0,
            "network_calls": 0,
        }
        print(json.dumps(output, indent=2, sort_keys=True))
    finally:
        store.close()


if __name__ == "__main__":
    main()
