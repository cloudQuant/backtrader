from __future__ import annotations
import hashlib, json
from pathlib import Path
root=Path(r'D:\temp\iteration41-g6-account-actor-server-core-r1-independent-qa-20260927')
files=[]
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name not in {'qa-manifest.json','qa-manifest.sha256'}:
        data=path.read_bytes()
        files.append({'path':str(path.relative_to(root)).replace('\\','/'),'size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={
 'record':'g6-p-account-actor-server-core-r1-independent-qa',
 'frozen_input':r'D:\temp\iteration41-g6-account-actor-server-core-freeze-20260927-r1',
 'frozen_manifest_sha256':'925a72915cca210431a25d7db1993d6290025f241b6d76fe170b0cbe8f9b0420',
 'python':'3.11.5',
 'focus':{'command':'python -B -m unittest discover -s tests -v','passed':50,'failed':0,'exit_code':0},
 'scope':'independent fake-only local SQLite core QA; no main production edits, SDK/native/provider/network/credentials/account access',
 'conclusion':'G6-P BLOCKED',
 'files':files,
}
p=root/'qa-manifest.json'
p.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
h=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'qa-manifest.sha256').write_text(h+'  qa-manifest.json\n',encoding='ascii')
print(h)
