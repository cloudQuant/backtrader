import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
patch = root / "evidence" / "local-replay.patch"
files = []
for path in sorted(item for item in root.rglob("*") if item.is_file()):
    relative = path.relative_to(root).as_posix()
    if relative == "manifest.json":
        continue
    payload = path.read_bytes()
    files.append({"path": relative, "size_bytes": len(payload),
                  "sha256": hashlib.sha256(payload).hexdigest().upper()})
manifest = {
    "schema_version": "iteration41.0133-local-replay-author-candidate.v2",
    "status": "ISOLATED_AUTHOR_CANDIDATE_FOR_INDEPENDENT_QA",
    "scope": "013_3 local synthetic ReplayClient replay; safe parent-package identity lookup; mixed-EOL apply",
    "main_worktree_modified_by_this_task": False,
    "release_or_ctp_acceptance": False,
    "r1_lineage": {
        "archive_sha256": "B544A4B670B1525AE39580CB0A3DCDC0CBDE0A2AE859DB4BBD7A3379B992C9CC",
        "manifest_sha256": "4A48DF277F79FDF1A8A00CF9782FB67F1AE8432997AB5DC9EB054FC98A9D0C73",
        "patch_sha256": "3BAD0CA164FD52CBB6BBFFE3912EFA9C22F8747815B69E65B9C11C03895DA055",
    },
    "r2_patch_sha256": hashlib.sha256(patch.read_bytes()).hexdigest().upper(),
    "r2_guarded_focus": "3 passed; provider import attempts 0; no native/provider/network/credential use",
    "files": files,
}
(root / "manifest.json").write_text(
    json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)