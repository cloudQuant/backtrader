from difflib import unified_diff
from pathlib import Path


baseline = Path(r"D:\temp\iteration41-0133-local-replay-r2b-baseline-20260927")
candidate = Path(r"D:\temp\iteration41-0133-local-replay-r2b-candidate-20260927")
files = (
    "examples/013_3_sa_midfreq_simnow/run.py",
    "tests/unit/runtime/test_iteration41_sa_ctp_replay_runtime.py",
)
parts = []
for relative in files:
    old = (baseline / relative).read_text(encoding="utf-8").splitlines(keepends=True)
    new = (candidate / relative).read_text(encoding="utf-8").splitlines(keepends=True)
    parts.extend(
        unified_diff(
            old,
            new,
            fromfile=f"a/{relative}",
            tofile=f"b/{relative}",
        )
    )
Path("evidence/local-replay.patch").write_text("".join(parts), encoding="utf-8")
