import hashlib
import json
from pathlib import Path


base = json.loads(
    (Path("evidence") / "structured-baseline" / "run-report.json").read_text(
        encoding="utf-8"
    )
)
candidate = json.loads(
    (Path("evidence") / "structured-candidate-verified" / "run-report.json").read_text(
        encoding="utf-8"
    )
)


def stable_projection(report):
    logger = report["trade_logger"]
    event_counts = dict(logger["event_counts"])
    event_counts.pop("store", None)
    return {
        "strategy": report["strategy"],
        "scenario": report["scenario"],
        "trading_day": report["trading_day"],
        "instrument": report["instrument"],
        "sa_midfreq": logger["extensions"]["sa_midfreq"],
        "event_counts_without_store_lifecycle": event_counts,
        "portfolio": logger["portfolio"],
        "positions": logger["positions"],
        "order_summaries": logger["order_summaries"],
        "trade_summaries": logger["trade_summaries"],
        "records_dropped": logger["records_dropped"],
    }


base_projection = stable_projection(base)
candidate_projection = stable_projection(candidate)
encoded = json.dumps(base_projection, sort_keys=True, separators=(",", ":")).encode()
comparison = {
    "stable_strategy_metric_risk_projection_equal": base_projection == candidate_projection,
    "stable_projection_sha256": hashlib.sha256(encoded).hexdigest(),
    "base_store_notification_count": base["trade_logger"]["event_counts"]["store"],
    "candidate_store_notification_count": candidate["trade_logger"]["event_counts"]["store"],
    "base_runtime_chain": base["runtime_chain"],
    "candidate_runtime_chain": candidate["runtime_chain"],
    "base_business_summary_hash": base["business_summary_hash"],
    "candidate_business_summary_hash": candidate["business_summary_hash"],
    "base_sdk_write_requests": base["sdk_write_requests"],
    "candidate_sdk_write_requests": candidate["sdk_write_requests"],
    "base_orders": base["orders"],
    "candidate_orders": candidate["orders"],
    "base_position_lots": base["position_lots"],
    "candidate_position_lots": candidate["position_lots"],
}
Path("evidence/report-comparison.json").write_text(
    json.dumps(comparison, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(json.dumps(comparison, indent=2, sort_keys=True))
