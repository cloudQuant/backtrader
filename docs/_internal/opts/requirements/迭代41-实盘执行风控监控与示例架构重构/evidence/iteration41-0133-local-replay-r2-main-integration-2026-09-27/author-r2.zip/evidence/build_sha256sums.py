import hashlib
from pathlib import Path

root = Path(__file__).resolve().parents[1]
output = root / "SHA256SUMS.txt"
lines = []
for path in sorted(item for item in root.rglob("*") if item.is_file() and item != output and item != root / "manifest.json"):
    rel = path.relative_to(root).as_posix()
    lines.append(f"{hashlib.sha256(path.read_bytes()).hexdigest().upper()}  {rel}")
output.write_text("\n".join(lines) + "\n", encoding="utf-8")