import atexit
import importlib.abc
import json
import os
from pathlib import Path
import sys

blocked_root = os.path.normcase(os.path.abspath(r'D:\bt_api_py'))
removed = []
for entry in tuple(sys.path):
    resolved = os.path.normcase(os.path.abspath(entry or os.getcwd()))
    if resolved == blocked_root or resolved.startswith(blocked_root + os.sep):
        sys.path.remove(entry)
        removed.append(entry)

class _RejectBtApiPy(importlib.abc.MetaPathFinder):
    def __init__(self):
        self.attempts = []

    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_py' or fullname.startswith('bt_api_py.'):
            self.attempts.append(fullname)
            raise AssertionError('bt_api_py import blocked in offline replay QA')

rejector = _RejectBtApiPy()
sys.meta_path.insert(0, rejector)
report_path = Path(__file__).resolve().parent.joinpath('evidence', 'provider-import-guard.json')
report_path.parent.mkdir(exist_ok=True)

def _write_guard_report():
    report_path.write_text(
        json.dumps({'blocked_root': blocked_root,
                    'removed_sys_path_entries': removed,
                    'import_hook_installed': True,
                    'provider_import_attempts': list(rejector.attempts)}, indent=2) + '\n',
        encoding='utf-8')

atexit.register(_write_guard_report)