# 013_3 local replay composition candidate

Status: isolated candidate for independent QA. No files in the main worktree were edited. This is not a production-route change or CTP/SimNow acceptance.


## R2 correction: import-safe identity probe and mixed-newline patch

The frozen r1 ZIP remains unchanged: SHA-256 `B544A4B670B1525AE39580CB0A3DCDC0CBDE0A2AE859DB4BBD7A3379B992C9CC`. Its all-CRLF patch remains available as `evidence/local-replay-r1.patch` (SHA-256 `3BAD0CA164FD52CBB6BBFFE3912EFA9C22F8747815B69E65B9C11C03895DA055`).

R2 addresses both the patch-application newline defect and a separate import-side-effect finding. The previous `module_identity()` called `importlib.util.find_spec()` for dotted `bt_api_py.*` names; Python can import the parent package to answer that request. A poisoned fake parent package demonstrated the risk. R2 uses a `PathFinder` component walk to resolve specs without executing any package initializer. The added regression test creates inert fake child modules and a parent `__init__.py` that writes a marker and raises; `runtime_component_identities()` reports the specs while leaving the marker absent and `bt_api_py` out of `sys.modules`.

The final mixed-newline patch is `evidence/local-replay.patch`, SHA-256 `B8DD2AE3B0BD108B4445E9D7B261515F0062DB678D6792364F4E22EF32034473` (111 CRLF and 274 lone-LF records). Both `git -c core.autocrlf=false apply --check` and `git apply` pass against main's original `run.py` (mixed/mostly CRLF) and LF-only test file. Application output is byte-identical to the r2 candidate: `run.py` SHA-256 `1C3D37A7485C05EC4EBB82BA1A66218B6B739063E04819D7B327BA4D8847B58E`; test SHA-256 `00F9DB83E22735539920A7F033AB0A888906ECF61109C156513BCFE1D9C64678`.

The exact-main test copy was assembled from current main `backtrader` and `backtrader_runtime`, the r2b Store wiring files (`btapistore.py` SHA-256 `24F8199E199BBE84BBB113C3EDBBEE9E71D4736FDD8573297E24EAD3298F2518`; `ctp_account_actor_port.py` SHA-256 `2E4B04D00C45BA9C6524C5AD0364273E6ECC1A1F653F595D21C3891BE2644EE3`), safe synthetic 013_3 fixture files, and the unpatched main `run.py` and acceptance test. No private config or credential file was copied.

The final guarded focused run passed 3 tests: the local-only Store/Broker contract, 013_3 replay with provider/network write guards, and the poisoned-parent identity regression. Its Python startup guard removed all 14 `D:\bt_api_py\...` source entries from `sys.path` and rejected any `bt_api_py` import; `provider_import_attempts` was empty. Test assertions report zero network attempts, provider constructions, provider order writes, inherited `BackBroker.next` calls, SDK writes, orders, and trades. Logs and JUnit are under `evidence/r2-apply/`. Pytest emitted one environment warning: the installed pytest does not recognize `asyncio_default_fixture_loop_scope`. `py_compile`, Ruff (`E4,E7,E9,F`), and Ruff preview `E305` checks all passed.

The earlier unguarded 2/2 run is preserved under `evidence/r2-pre-fix-import-contaminated/`. Root QA found its interpreter could expose the provider source through `sys.path`; treat it as potentially initializer-contaminated and do not count it as offline acceptance. Historical r1 test logs are retained unchanged in the r1 ZIP and are likewise not upgraded by this supplement.

R2 remains `ISOLATED_AUTHOR_CANDIDATE_FOR_INDEPENDENT_QA`. It does not alter the main worktree, inventory/route registration, `simulation/sandbox`, preflight, live status, or production behavior. It uses no native module, provider call, credential, account, network, order, or cancel and is not CTP/SimNow acceptance.

## Change

`run_replay` now composes an explicitly created `ReplayClient` with `LocalReplayStore`, the existing `BtApiFeed` labeled `local_replay`, and `LocalReplayBroker`. The local Store does not inherit from `BtApiStore`, has no provider identity, SDK factory, submit or cancel API, or default client. Its constructor accepts only an exact `ReplayClient`; `getdata` fixes the Feed class and local provider label.

The valuation broker subclasses `BackBroker` only for Backtrader portfolio/account interfaces. It rejects `submit`, `cancel`, `buy`, `sell`, `transmit`, `submit_accept`, and `add_order_history`. Its `next` never calls `BackBroker.next`; it fails if any pending/submitted/history queue is nonempty. Tests poison the inherited matcher to prove it is never reached.

The change is limited to the legacy 013_3 replay fixture code and its runtime acceptance test. It does not change inventory registration, `simulation/sandbox`, preflight, live status, SDK code, protected/private config, or default routing. The copied tree contains the tracked synthetic `config.yaml`, public runtime example, and synthetic replay fixture only; no `.env`, `runtime-ctp-private`, account state, credentials, or SDK checkout was copied or used.

## Verification

- Pre-r2b source baseline test: `1 passed`, one existing Quandl deprecation warning. Source hashes: `run.py` `16D6A184F1A57C0C2843511DD0BD7ADA4825D945402665BE1AAF8B624FC9576C`; test `146833DF60C0C847E5AC64C1F8239673E525F5C08DDA86453CF81B3B11327CD5`.
- r2b source before this patch: the focused replay test failed at `BtApiStore(provider="ctp")` with `BtApiStoreError: external account actor unavailable`; the original log is preserved at `evidence/pre-change.stdout.txt` and JUnit at `evidence/pre-change.junit.xml`.
- Historical r1/r2b focused run: two tests passed, but later import-side-effect review marked this unguarded run potentially contaminated; see `evidence/r2-pre-fix-import-contaminated/`. The final guarded r2 result is 3 passed and is recorded under `evidence/r2-apply/`.
- A separate unit contract rejects each broker order/cancel route, asserts empty broker order queues, and confirms a forged nonempty pending queue is rejected before `next` can reach the inherited matcher.
- `py_compile` passed. Ruff reported 52 existing whole-file findings; none were in the new Store/Broker or test blocks. The candidate does not claim a whole-file Ruff-clean result.

## Historical baseline comparison (r1; not rerun for r2)

This 18-file artifact comparison belongs to the r1 local-composition run before the r2 identity-probe fix. R2 reran the three focused tests with import guards but did not recapture the full 18-file output comparison. The r1 comparison uses the same synthetic `no_signal` fixture before and after, with the r2b Store applied only to the candidate tree. The stable strategy/metrics/risk projection is equal (`evidence/report-comparison.json`, SHA-256 `15174565912f33e435c1f757d7982e8336baf4bae235c73a28275a242ebfbb36`). Both reports show 7,500 qualified quotes/signals, 106 qualified bars, 64 closed bars, zero orders/trades, zero position lots, zero SDK write requests, zero risk failures, and the same observation window and portfolio value. `replay-risk.json`, `risk_events.jsonl`, quotes, bars, signals, daily report, reconciliation, and order/trade logs are byte-identical.

The output comparison contains 18 files: 15 are byte-identical; three differ and are accounted for explicitly:

1. `manifest.json`: expected source and run provenance changes (`code_hash`, `run_id`, start/end timestamps, source checkout paths, and Store SHA `DBA2989…` → r2b `24F819…`) plus timing-sensitive evidence-queue high-water counts (`quotes/signals 7340/7341 → 7343/7343`). Evidence totals, dropped totals, completion state, and order/trade counts are unchanged.
2. `trade-logger/monitor.log`: run timestamps/IDs differ; false `provider="ctp"` and `session_id="ctp-*"` are absent in the local replay candidate.
3. `trade-logger/system.log`: the baseline CTP-labeled fake Store emitted 10 Store lifecycle notifications (`connecting`, auth request, connected/ready, open-order sync, subscription and follow-up sync); the local Store emits no Store notifications. Both retain the strategy session start/status/stop records; the candidate has blank Store provider/session identity.

The changed log semantics remove the fake CTP lifecycle identity. The stored strategy extension remains equal; the overall business summary hash differs because the runtime chain and Store-notification count intentionally changed. Full per-file SHA comparison is `evidence/artifact-comparison.csv` / `.json`; exact manifest leaf differences are in `evidence/manifest-diff.json`.

## Lineage and limits

Candidate `backtrader/stores/btapistore.py` is copied from the r2b Store-wiring candidate and hashes to `24F8199E199BBE84BBB113C3EDBBEE9E71D4736FDD8573297E24EAD3298F2518`; `backtrader/stores/ctp_account_actor_port.py` hashes to `2E4B04D00C45BA9C6524C5AD0364273E6ECC1A1F653F595D21C3891BE2644EE3`. Baseline Store hash is `DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826`. No main-worktree change is part of this candidate.

The final guarded r2 run is fake-only composition and test evidence. The Feed remains the shared `BtApiFeed` implementation, but the selected replay source is a local synthetic `ReplayClient`; the startup guard excludes `D:\bt_api_py` source paths and blocks `bt_api_py` imports. `BackBroker` is not used as an order matching engine. The earlier unguarded run is explicitly unqualified due to the parent-package import risk. Private method invocation or direct mutation of arbitrary Python object internals remains outside the supported public contract. Independent QA is still required before considering any main-tree integration.

## Files

- `evidence/local-replay.patch`: r2 mixed-newline source/test diff that applies to the mixed-EOL main files.
- `evidence/local-replay-r1.patch`: original all-CRLF patch retained for lineage.
- `evidence/r2-apply/`: final patch-check/apply stdout/exit, guarded focused pytest stdout/JUnit/exit, import-block report, and startup guard source; py_compile and Ruff stdout/exit logs are included.
- `evidence/r2-pre-fix-import-contaminated/`: preserved, unqualified pre-fix 2/2 logs and patch, with an explicit contamination notice.
- `evidence/r2-application-receipt.json`: exact paths, hashes, newline comparison, test and guard counts.
- `evidence/candidate-verified-run/`: final focused pytest log/JUnit and run outputs.
- `evidence/baseline-test-run/`: pre-r2b source baseline log/JUnit and run outputs.
- `evidence/output-comparison-verified/`: raw baseline and candidate output artifacts.
- `evidence/structured-baseline/` and `evidence/structured-candidate-verified/`: returned report JSON used for the stable projection comparison.
- `evidence/artifact-comparison.csv`, `artifact-comparison.json`, `manifest-diff.json`, and `report-comparison.json`: output comparison details.
- `evidence/pre-change.*`: original r2b gate failure before the local-only composition was applied.
- `evidence/`: reproducible capture/comparison scripts and their stdout records.
