import hashlib
import json
from pathlib import Path


root = Path("evidence/output-comparison-verified")
baseline = root / "baseline"
candidate = root / "candidate"
entries = []
for baseline_path in sorted(path for path in baseline.rglob("*") if path.is_file()):
    relative = baseline_path.relative_to(baseline)
    candidate_path = candidate / relative
    baseline_hash = hashlib.sha256(baseline_path.read_bytes()).hexdigest()
    candidate_hash = hashlib.sha256(candidate_path.read_bytes()).hexdigest()
    entries.append(
        {
            "path": relative.as_posix(),
            "baseline_sha256": baseline_hash,
            "candidate_sha256": candidate_hash,
            "identical": baseline_hash == candidate_hash,
        }
    )
comparison = {
    "file_count": len(entries),
    "identical_count": sum(item["identical"] for item in entries),
    "changed_count": sum(not item["identical"] for item in entries),
    "files": entries,
}
(Path("evidence") / "artifact-comparison.json").write_text(
    json.dumps(comparison, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
(Path("evidence") / "artifact-comparison.csv").write_text(
    "path,identical,baseline_sha256,candidate_sha256\n"
    + "".join(
        f'{item["path"]},{str(item["identical"]).lower()},'
        f'{item["baseline_sha256"]},{item["candidate_sha256"]}\n'
        for item in entries
    ),
    encoding="utf-8",
)
print(
    f"{comparison['identical_count']}/{comparison['file_count']} byte-identical; "
    f"changed: {', '.join(item['path'] for item in entries if not item['identical'])}"
)
