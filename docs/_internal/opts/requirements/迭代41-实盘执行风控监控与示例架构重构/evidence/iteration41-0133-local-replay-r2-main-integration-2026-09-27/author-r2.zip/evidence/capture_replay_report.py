from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path


root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(root))
legacy = importlib.import_module("examples.013_3_sa_midfreq_simnow.run")
runtime = importlib.import_module("examples.013_3_sa_midfreq_simnow.run_runtime")
report = legacy.run_replay(
    runtime._legacy_replay_config(legacy),
    output_directory=output / "replay",
    scenario="no_signal",
    retention_root=None,
)
(output / "run-report.json").write_text(
    json.dumps(report, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8"
)
