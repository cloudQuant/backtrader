import json
from pathlib import Path


base = json.loads(
    (Path("evidence/output-comparison-verified/baseline/manifest.json")).read_text(
        encoding="utf-8"
    )
)
candidate = json.loads(
    (Path("evidence/output-comparison-verified/candidate/manifest.json")).read_text(
        encoding="utf-8"
    )
)


def diff(left, right, prefix=""):
    changes = []
    keys = sorted(set(left) | set(right)) if isinstance(left, dict) and isinstance(right, dict) else None
    if keys is None:
        if left != right:
            changes.append({"field": prefix, "baseline": left, "candidate": right})
        return changes
    for key in keys:
        path = f"{prefix}.{key}" if prefix else key
        if key not in left:
            changes.append({"field": path, "baseline": None, "candidate": right[key]})
        elif key not in right:
            changes.append({"field": path, "baseline": left[key], "candidate": None})
        else:
            changes.extend(diff(left[key], right[key], path))
    return changes


changes = diff(base, candidate)
Path("evidence/manifest-diff.json").write_text(
    json.dumps(changes, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
for change in changes:
    print(f"{change['field']}: {change['baseline']!r} -> {change['candidate']!r}")
