# Pre-fix replay log — contaminated/unqualified

These are the initial r2 newline-only run logs, captured before the import-safety audit. The then-current `module_identity()` called `importlib.util.find_spec()` on dotted `bt_api_py.*` names. A later QA review demonstrated that this can execute the parent `bt_api_py/__init__.py` when that source is on `sys.path`. The 2/2 result below is preserved as historical diagnostic evidence and is not an accepted offline replay result. The r1 ZIP and r1 contents remain unchanged.

- `local-replay-newline-only.patch` SHA-256: `09E705D4A872A7DE807DE1A752562F8993D24C75F4F7961F182F686CA190013E`.
- Focused result: 2 passed, but the process had no `bt_api_py` import-blocking guard and must be treated as potentially initializer-contaminated.
- Final guarded R2 result and corrected patch are in `evidence/r2-apply/` and `evidence/local-replay.patch`.