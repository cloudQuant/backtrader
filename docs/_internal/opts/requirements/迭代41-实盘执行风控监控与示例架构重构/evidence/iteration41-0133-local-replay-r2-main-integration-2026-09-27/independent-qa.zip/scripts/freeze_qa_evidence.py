from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

ROOT = Path(r"D:\temp\iteration41-0133-local-replay-r2-independent-qa-20260927")
EVIDENCE = ROOT / "evidence"
MANIFEST = EVIDENCE / "qa-manifest.json"
ARCHIVE = EVIDENCE / "qa-evidence.zip"
INDEX = EVIDENCE / "qa-index.json"
def sha_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()
def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()

paths = set()
for subdir in (ROOT / "logs", ROOT / "scripts", EVIDENCE):
    for path in subdir.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel in {"evidence/qa-manifest.json", "evidence/qa-evidence.zip", "evidence/qa-index.json"}:
            continue
        paths.add(rel)
for rel in ("source/guard/sitecustomize.py", "source/pytest.ini"):
    assert (ROOT / rel).is_file(), rel
    paths.add(rel)
records = []
for rel in sorted(paths):
    path = ROOT.joinpath(*rel.split("/"))
    records.append({"path": rel, "size_bytes": path.stat().st_size, "sha256": sha(path)})
manifest_data = {
    "schema": "iteration41-0133-local-replay-r2-independent-qa-v1",
    "verdict": "SAFE_TO_APPLY_LOCAL_REPLAY_ONLY",
    "file_count": len(records),
    "files": records,
}
manifest_raw = (json.dumps(manifest_data, sort_keys=True, indent=2) + "\n").encode("utf-8")
MANIFEST.write_bytes(manifest_raw)
with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for rel in sorted(paths | {"evidence/qa-manifest.json"}):
        path = ROOT.joinpath(*rel.split("/"))
        info = zipfile.ZipInfo(rel, date_time=(2026, 9, 27, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(ARCHIVE) as archive:
    bad = archive.testzip()
    assert bad is None, bad
    archive_names = set(archive.namelist())
    expected_names = paths | {"evidence/qa-manifest.json"}
    assert archive_names == expected_names
    for rel in paths:
        assert archive.read(rel) == ROOT.joinpath(*rel.split("/")).read_bytes(), rel
    assert archive.read("evidence/qa-manifest.json") == manifest_raw
receipt = EVIDENCE / "qa-receipt.md"
index_data = {
    "verdict": "SAFE_TO_APPLY_LOCAL_REPLAY_ONLY",
    "receipt_sha256": sha(receipt),
    "qa_manifest_sha256": sha(MANIFEST),
    "qa_archive_sha256": sha(ARCHIVE),
    "author_manifest_sha256": "14F75238DFAB2959DF32642017E52F9AB0E1D54C6B6E02BCC87FF47906A9642D",
    "author_patch_sha256": "B8DD2AE3B0BD108B4445E9D7B261515F0062DB678D6792364F4E22EF32034473",
    "author_zip_sha256": "EF6C629784077E016B1B6E8FFA34F3BD23ADB35C6184D68560A672B1F396A186",
    "qa_file_count": len(records),
    "qa_archive_entries": len(archive_names),
    "zip_testzip": bad,
}
INDEX.write_text(json.dumps(index_data, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps(index_data, sort_keys=True, indent=2))
