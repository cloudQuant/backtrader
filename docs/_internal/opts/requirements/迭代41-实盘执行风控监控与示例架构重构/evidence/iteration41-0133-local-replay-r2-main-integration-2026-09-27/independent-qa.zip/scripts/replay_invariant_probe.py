from __future__ import annotations

import importlib
import json
from pathlib import Path
import socket
import sys

import yaml

from backtrader_runtime import RegisteredRuntime, RuntimeRegistry, validate_runtime_config

QA_ROOT = Path(__file__).resolve().parents[1]
SOURCE = QA_ROOT / "source"
EXAMPLE = SOURCE / "examples" / "013_3_sa_midfreq_simnow"
RUNTIME_ROOT = QA_ROOT / "replay-invariant-output" / "runtime"
RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)

network_attempts = []
def reject_network(*args, **kwargs):
    network_attempts.append({"args": repr(args), "kwargs": repr(kwargs)})
    raise AssertionError("network call blocked by independent QA probe")

socket.getaddrinfo = reject_network
socket.create_connection = reject_network
socket.socket.connect = reject_network
socket.socket.connect_ex = reject_network
socket.socket.sendto = reject_network

runner = importlib.import_module("examples.013_3_sa_midfreq_simnow.run_runtime")
from backtrader.brokers.btapibroker import BtApiBroker
from backtrader.brokers.bbroker import BackBroker
from backtrader.stores.btapistore import BtApiStore

provider_calls = {"constructors": 0, "order_writes": 0, "inherited_matcher": 0}
def reject_provider_construction(*args, **kwargs):
    provider_calls["constructors"] += 1
    raise AssertionError("provider construction blocked by independent QA probe")
def reject_provider_write(*args, **kwargs):
    provider_calls["order_writes"] += 1
    raise AssertionError("provider order write blocked by independent QA probe")
def reject_inherited_matcher(*args, **kwargs):
    provider_calls["inherited_matcher"] += 1
    raise AssertionError("inherited BackBroker matcher blocked by independent QA probe")

BtApiBroker.__init__ = reject_provider_construction
BtApiBroker.submit = reject_provider_write
BtApiBroker.cancel = reject_provider_write
BtApiStore.__init__ = reject_provider_construction
BtApiStore.submit_order = reject_provider_write
BtApiStore.cancel_order = reject_provider_write
BackBroker.next = reject_inherited_matcher

raw = yaml.safe_load((EXAMPLE / "runtime" / "config.example.yaml").read_text(encoding="utf-8"))
raw["parameters"]["scenario"] = "no_signal"
config_path = RUNTIME_ROOT / "config.yaml"
config_path.write_text(yaml.safe_dump(raw), encoding="utf-8")
registry = RuntimeRegistry((RegisteredRuntime(
    runtime_dir=RUNTIME_ROOT,
    strategy_id=runner.STRATEGY_ID,
    allowed_presets=("replay",),
    allowed_parameter_keys=("scenario",),
),))
effective = validate_runtime_config(RUNTIME_ROOT, registry)
report = runner.run_runtime(RUNTIME_ROOT, registry=registry, effective=effective)
observation = report["observation_evidence"]
events = report["trade_logger"]["event_counts"]
metrics = {
    "status": report["status"],
    "runtime_scope": report["runtime_config"]["scope"],
    "research_status": report["runtime_config"]["research_status"],
    "simnow_admission_boundary": report["runtime_config"]["simnow_admission_boundary"],
    "qualified_quotes": observation["qualified_quotes"],
    "qualified_completed_bars": observation["qualified_completed_bars"],
    "closed_bars": report["closed_bars"],
    "orders": report["orders"],
    "order_events": events["orders"],
    "signal_events": events["signals"],
    "trade_events": events["trades"],
    "position_lots": report["position_lots"],
    "sdk_write_requests": report["sdk_write_requests"],
    "external_request_counts": report["external_request_counts"],
    "runtime_chain": report["runtime_chain"],
    "provider_calls": provider_calls,
    "network_attempts": network_attempts,
    "evidence_directory": report["evidence_directory"],
}
assert metrics["status"] == "LOCAL_REPLAY_PASS"
assert metrics["runtime_scope"] == "LOCAL_REPLAY_ONLY"
assert metrics["research_status"] == "RESEARCH_NOT_ESTABLISHED"
assert metrics["simnow_admission_boundary"] == "INDEPENDENT_SIMNOW_ADMISSION_REQUIRED"
assert metrics["qualified_quotes"] == 7500
assert metrics["qualified_completed_bars"] == 106
assert metrics["closed_bars"] == 64
assert metrics["orders"] == [] and metrics["order_events"] == 0 and metrics["trade_events"] == 0
assert metrics["signal_events"] == 0
assert metrics["position_lots"] == 0 and metrics["sdk_write_requests"] == 0
assert metrics["external_request_counts"] == {"network": 0, "order_write": 0}
assert metrics["runtime_chain"]["feed_provider"] == "local_replay"
assert metrics["runtime_chain"]["store"].endswith(".LocalReplayStore")
assert metrics["runtime_chain"]["broker"].endswith(".LocalReplayBroker")
assert provider_calls == {"constructors": 0, "order_writes": 0, "inherited_matcher": 0}
assert network_attempts == []
print(json.dumps(metrics, sort_keys=True, indent=2))
