# Independent QA receipt — 013_3 local replay r2b author candidate

**Verdict: `NEEDS_REVISION` for this frozen candidate bundle.** The LocalReplayStore/Broker composition, focused behavior, and recorded artifacts are internally consistent. Do not treat the current bundle as ready to integrate: the frozen patch does not apply with the ordinary Git command on its declared exact base, and the replay’s source-identity probe can initialize a dotted external SDK parent package when it is available. The focused `2 passed` result is preserved as an observed functional result, but is not strict no-SDK acceptance evidence because that import path was discovered afterward.

## Frozen input identity

- Candidate directory: `D:\temp\iteration41-0133-local-replay-r2b-candidate-20260927\author-package`
- Manifest SHA-256: `4A48DF277F79FDF1A8A00CF9782FB67F1AE8432997AB5DC9EB054FC98A9D0C73`
- Author ZIP: `D:\temp\iteration41-0133-local-replay-r2b-candidate-20260927\evidence\iteration41-0133-local-replay-r2b-author-candidate.zip`
- ZIP SHA-256: `B544A4B670B1525AE39580CB0A3DCDC0CBDE0A2AE859DB4BBD7A3379B992C9CC`
- Patch SHA-256: `3BAD0CA164FD52CBB6BBFFE3912EFA9C22F8747815B69E65B9C11C03895DA055`
- Manifest verification: all 60 listed payloads match their sizes and hashes; no unsafe or duplicate paths; ZIP `testzip()` returned `None`, with 61 file entries (60 listed payloads plus `manifest.json`) and no sensitive-path matches. This is a complete patch/evidence bundle, not a standalone copy of the full repository; replay requires the declared base tree.
- Candidate source identities checked: `run.py` `A9567D1875B71EC7E84FDA666014A12163990A44CB6E8AD18BB1B351426EEB36`; replay test `A532550147D102522F8970EFAB9EA12B2CDCF84C68E53F33EA51ABB8B51CE4EF`; r2b `btapistore.py` `24F8199E199BBE84BBB113C3EDBBEE9E71D4736FDD8573297E24EAD3298F2518`; r2b actor port `2E4B04D00C45BA9C6524C5AD0364273E6ECC1A1F653F595D21C3891BE2644EE3`.
- Synthetic input hashes in the independent source copy matched provenance: legacy `config.yaml` `AAF85B1E682D2E872022D2B15ABC9F56CF80023CD2DC59E03399FFCD079986F1`, runtime example `CD5C1AD50B88A0D85A94D1E51E36E51E46377236051BA47CFE1F2482E0319905`, replay fixture `6809517706D02D104DD6609E5F433A12B102EE30E82F3EE6A8AA6DFBA4E3387D`.

## Behavior and output checks

- Independent QA copy: `D:\temp\iteration41-0133-local-replay-r2b-independent-qa-20260927`. Focus nodes were run with the source tree copied from the isolated candidate, using `-B` and a fresh `pycache_prefix`. Result: `2 passed`; one environment `PytestConfigWarning` for the unavailable `asyncio_default_fixture_loop_scope` option.
- The two observed tests were `test_0133_local_replay_composition_has_no_provider_or_order_entry` and `test_real_replay_has_no_network_or_provider_writes[013_3]`. The tests’ socket poison, BtApiStore/BtApiBroker constructor and write poisons, and inherited `BackBroker.next` poison all remained at zero; the test fixtures also assert those counters and network attempts are empty.
- Independent AST/runtime probe: `LocalReplayStore` is a plain `object` subclass, is not a `BtApiStore`, has no `provider`, `submit_order`, or `cancel_order` attributes, and has no CTP runtime identity. `LocalReplayBroker` uses `BackBroker` as its valuation/account base, overrides buy/sell/submit/cancel/transmit/submit_accept/add_order_history/next, rejects all seven public order/cancel routes, and rejects a forged pending queue before any inherited matcher. Logs: `identity-poison.stdout.txt`.
- Recomputed raw artifact comparison: 18 files total, 15 byte-identical. The only differences are `manifest.json`, `trade-logger/monitor.log`, and `trade-logger/system.log`; the latter two remove the fake CTP provider/session identity and its 10 Store lifecycle notifications. Both baseline and candidate have 7,500 quote rows, 7,500 signal-evidence rows, 106 bar rows/qualified bars, 64 closed bars, zero strategy-emitted signal events, zero orders, zero trades, zero position lots, and zero SDK write requests. This is synthetic `no_signal` fixture evidence only.
- The candidate runtime chain is `LocalReplayStore` + `LocalReplayBroker` + `BtApiFeed(provider="local_replay")`. It does not establish real SimNow/CTP acceptance, account authority, or live writes.

## Blockers

1. **Frozen patch portability:** the original patch is all CRLF; the baseline `run.py` is mixed CRLF/LF and the baseline replay test is LF-only. Exact base hashes match the candidate provenance, but both `git apply --check` and `git -c core.autocrlf=false apply --check` fail at `tests/unit/runtime/test_iteration41_sa_ctp_replay_runtime.py:188`. `--ignore-space-change` passes in an isolated miniature repository and yields line-ending-normalized target contents equal to the candidate, but that does not make the frozen patch apply cleanly. See `patch-portability-negative.txt` and `patch-portability-reproduction.txt`.
2. **Potential SDK package initializer execution:** candidate `run.py:690` uses `importlib.util.find_spec(module_name)`. `runtime_component_identities()` at lines 722–728 calls this with dotted names `bt_api_py.bt_api` and `bt_api_py._execution_session`; it runs from the local replay at about line 3270. In Python, finding a dotted submodule may import its parent package. An inert fake `bt_api_py` package in `evidence/fake-sdk-root` proved the fake parent `__init__.py` executes on this exact candidate helper path; see `dotted-sdk-find-spec-verified.stdout.txt`. The venv resolves `bt_api_py` from `D:\bt_api_py\bt_api_py\__init__.py`. I did not inspect that package or call any SDK API. Because the first two replay tests had already run before this was discovered, preserve their logs but do not claim strict no-SDK acceptance from them. The corrected follow-up probe used only an inert fake package and no network/provider.

No main-tree files, private config, credentials, or source candidate files were edited. No actual client/order/cancel or network call was made intentionally. This QA does not authorize production routing. Re-review is required against the author’s re-frozen patch and a guard that prevents package initialization.

## Read-only SDK initializer impact check

After identifying the candidate’s dotted `find_spec` path, I read only `D:\bt_api_py\bt_api_py\__init__.py` as text. SHA-256: `B62BBA4631FA5C28119DF1E4E9883DEB13BFDAA8279124D3CEAC4F927660FB0E`. It imports broad `bt_api_base` and `bt_api_py` modules at top level; unless `BT_API_PY_LIGHT_IMPORT` is truthy, it also imports `BtApi` (`__init__.py:199–207`). No direct constructor, network call, or native module import is visible in that initializer, but this does not prove transitive imports are side-effect free. No transitive files were read or executed. Consequently the old 2/2 replay run is explicitly excluded from qualified no-SDK acceptance. See `bt-api-py-initializer-static-impact.md`.

## Reproduction/evidence files

- `focus-clean.stdout.txt`, `focus-clean.junit.xml` — focused result (observed, later marked contaminated for strict no-SDK acceptance)
- `verify_candidate.py`, `verify-candidate.stdout.txt` — all manifest/ZIP checks, byte comparison, metrics, and AST checks
- `identity_poison_probe.py`, `identity-poison.stdout.txt` — Store/Broker identity and order route checks
- `patch-portability-negative.txt`, `patch-portability-reproduction.txt` — exact apply failure and normalized isolated replay
- `dotted-sdk-find-spec-probe.py`, `dotted-sdk-find-spec-verified.stdout.txt` — inert fake parent package behavior; `dotted-sdk-find-spec-harness-error.stdout.txt` preserves an initial malformed fake-package harness attempt, not a candidate failure
- `offline_import_poison.py`, `offline-import-guard-exposure.stdout.txt` — import guard catches the candidate’s dotted `find_spec` behavior before any SDK package initializer is executed
