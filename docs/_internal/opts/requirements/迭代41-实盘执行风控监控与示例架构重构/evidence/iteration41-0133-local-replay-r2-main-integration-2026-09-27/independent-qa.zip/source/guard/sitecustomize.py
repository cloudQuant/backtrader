"""Independent QA startup guard for local replay tests."""
import atexit
import importlib.abc
import json
import os
import sys

SDK_ROOT = os.path.normcase(os.path.realpath(r"D:\bt_api_py"))
removed_paths = []
kept_paths = []
for entry in sys.path:
    resolved = os.path.normcase(os.path.realpath(entry or os.getcwd()))
    try:
        under_sdk = os.path.commonpath((SDK_ROOT, resolved)) == SDK_ROOT
    except ValueError:
        under_sdk = False
    if under_sdk:
        removed_paths.append(entry)
    else:
        kept_paths.append(entry)
sys.path[:] = kept_paths

provider_import_attempts = []
class RejectBtApiPy(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_py" or fullname.startswith("bt_api_py."):
            provider_import_attempts.append(fullname)
            raise RuntimeError("independent QA blocked bt_api_py import: " + fullname)
        return None

sys.meta_path.insert(0, RejectBtApiPy())
preloaded_provider_modules = sorted(
    name for name in sys.modules if name == "bt_api_py" or name.startswith("bt_api_py.")
)

def write_report():
    report_path = os.environ.get("ITER41_QA_GUARD_REPORT")
    if not report_path:
        return
    data = {
        "sdk_root": SDK_ROOT,
        "removed_sdk_sys_path_entries": removed_paths,
        "preloaded_provider_modules": preloaded_provider_modules,
        "provider_import_attempts": provider_import_attempts,
        "provider_modules_at_exit": sorted(
            name for name in sys.modules if name == "bt_api_py" or name.startswith("bt_api_py.")
        ),
        "native_ctp_modules_at_exit": sorted(
            name for name in sys.modules
            if any(token in name.lower() for token in ("thostmduserapi", "thosttraderapi", "ctp_native"))
        ),
    }
    with open(report_path, "w", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write("\n")

atexit.register(write_report)
