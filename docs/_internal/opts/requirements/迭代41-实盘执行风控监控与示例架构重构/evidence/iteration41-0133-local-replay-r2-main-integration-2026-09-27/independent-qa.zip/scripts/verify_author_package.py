from __future__ import annotations
import hashlib, json, os, zipfile
from pathlib import Path

PACKAGE = Path(r"D:\temp\iteration41-0133-local-replay-r2b-candidate-20260927\author-package-r2")
MANIFEST = PACKAGE / "manifest.json"
PATCH = PACKAGE / "evidence" / "local-replay.patch"
ZIP = Path(r"D:\temp\iteration41-0133-local-replay-r2b-candidate-20260927\evidence\iteration41-0133-local-replay-r2-author-candidate.zip")
EXPECTED = {
    "manifest": "14F75238DFAB2959DF32642017E52F9AB0E1D54C6B6E02BCC87FF47906A9642D",
    "patch": "B8DD2AE3B0BD108B4445E9D7B261515F0062DB678D6792364F4E22EF32034473",
    "zip": "EF6C629784077E016B1B6E8FFA34F3BD23ADB35C6184D68560A672B1F396A186",
}
def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()

manifest_hash = sha(MANIFEST)
patch_hash = sha(PATCH)
zip_hash = sha(ZIP)
assert manifest_hash == EXPECTED["manifest"]
assert patch_hash == EXPECTED["patch"]
assert zip_hash == EXPECTED["zip"]
manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
records = manifest["files"]
assert len(records) == 87, len(records)
seen = set()
for entry in records:
    rel = entry["path"].replace("\\", "/")
    assert rel not in seen, rel
    seen.add(rel)
    assert not rel.startswith("/") and ".." not in Path(rel).parts, rel
    path = PACKAGE.joinpath(*rel.split("/"))
    assert path.is_file(), rel
    assert path.stat().st_size == entry["size_bytes"], rel
    assert sha(path) == entry["sha256"].upper(), rel

with zipfile.ZipFile(ZIP) as archive:
    bad = archive.testzip()
    assert bad is None, bad
    names = [name.replace("\\", "/") for name in archive.namelist()]
    assert len(names) == len(set(names)), "duplicate ZIP members"
    expected_names = seen | {"manifest.json"}
    assert set(names) == expected_names, (len(names), len(expected_names), sorted(set(names) ^ expected_names)[:20])
    zipped_manifest = archive.read("manifest.json")
    assert hashlib.sha256(zipped_manifest).hexdigest().upper() == EXPECTED["manifest"]
    for rel in seen:
        assert archive.read(rel) == PACKAGE.joinpath(*rel.split("/")).read_bytes(), rel

output = {
    "manifest_sha256": manifest_hash,
    "patch_sha256": patch_hash,
    "zip_sha256": zip_hash,
    "payload_entries": len(records),
    "zip_entries_including_manifest": len(names),
    "zip_testzip": bad,
    "all_payload_sizes_and_sha256": "PASS",
    "zip_payloads_byte_match_package": "PASS",
    "contains_runtime_private_or_env_paths": any(
        "runtime-ctp-private" in name.lower() or name.lower().endswith("/.env")
        for name in names
    ),
}
assert not output["contains_runtime_private_or_env_paths"]
print(json.dumps(output, sort_keys=True, indent=2))
