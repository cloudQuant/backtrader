from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT = Path(r"D:\temp\iteration41-0133-local-replay-r2-independent-qa-20260927")
def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()
def tree_manifest(root: Path, output: Path):
    items = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or ".pytest_cache" in path.parts:
            continue
        items.append({"path": path.relative_to(root).as_posix(), "size_bytes": path.stat().st_size, "sha256": sha(path)})
    data = {"root": str(root), "file_count": len(items), "files": items}
    output.write_text(json.dumps(data, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return data
source = tree_manifest(ROOT / "source", ROOT / "evidence" / "qa-source-manifest.json")
output = tree_manifest(ROOT / "replay-invariant-output", ROOT / "evidence" / "replay-output-manifest.json")
print(json.dumps({
    "qa_source_file_count": source["file_count"],
    "qa_source_manifest_sha256": sha(ROOT / "evidence" / "qa-source-manifest.json"),
    "replay_output_file_count": output["file_count"],
    "replay_output_manifest_sha256": sha(ROOT / "evidence" / "replay-output-manifest.json"),
}, sort_keys=True, indent=2))
