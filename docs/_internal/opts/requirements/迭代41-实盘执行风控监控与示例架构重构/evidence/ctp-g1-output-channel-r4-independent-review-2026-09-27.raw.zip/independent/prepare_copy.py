from pathlib import Path
import hashlib, json, shutil
src = Path(r'D:\temp\iteration41-worker-output-channel-r4-20260927')
out = Path(r'D:\temp\iteration41-worker-output-r4-root-qa-20260927')
assert not out.exists()
manifest_raw = (src / 'manifest.json').read_bytes()
manifest = json.loads(manifest_raw)
assert len(manifest['files']) == 4
for row in manifest['files']:
    p = src / row['path']
    raw = p.read_bytes()
    assert len(raw) == row['size']
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    dest = out / row['path']
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
(out / 'source-manifest.json').write_bytes(manifest_raw)
print(json.dumps({'root': str(out), 'source_files': len(manifest['files']), 'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest()}))
