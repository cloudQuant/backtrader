from __future__ import annotations

import hashlib
import json
import os
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

import bt_api_execution.store as store_module
from bt_api_execution.contracts import ExecutionScope
from bt_api_execution.errors import ContractValidationError, InvalidStateTransition
from bt_api_execution.facade import ManagedExecutionFacade
from bt_api_execution.store import SqliteExecutionStore


def account_ref() -> str:
    return 'ctp-account-ref.v1:' + hashlib.sha256(b'synthetic-family-only').hexdigest()


def make_scope(environment: str, strategy: str, day: str) -> ExecutionScope:
    return ExecutionScope('ctp', environment, account_ref(), strategy, day)


def source_origin_check() -> str:
    expected_src = Path(os.environ['EXPECTED_BT_API_EXECUTION_SRC']).resolve()
    actual = Path(store_module.__file__).resolve()
    assert actual.is_relative_to(expected_src), f'unexpected source import: {actual}'
    return str(actual)


def sibling_scope_reuses_same_store_owner(root: Path) -> dict[str, object]:
    path = root / 'sibling.sqlite3'
    store = SqliteExecutionStore(path)
    try:
        first_scope = make_scope('simulation', 'strategy-a', '20260926')
        sibling_scope = make_scope('simulation', 'strategy-b', '20260927')
        first_facade = ManagedExecutionFacade(
            store, first_scope, writer_id='family-test-writer', allow_unprotected=True,
        )
        sibling_facade = ManagedExecutionFacade(
            store, sibling_scope, writer_id='family-test-writer', allow_unprotected=True,
        )
        first_lease = first_facade.acquire_writer_lease()
        sibling_lease = sibling_facade.acquire_writer_lease()
        same_store_handle = store.acquire_ctp_account_family_owner(first_scope)
        assert first_lease.family_key == sibling_lease.family_key
        assert first_lease.family_owner_intent_id == sibling_lease.family_owner_intent_id
        assert same_store_handle.owner_intent_id == first_lease.family_owner_intent_id
        assert first_lease.scope_key == sibling_lease.scope_key == first_scope.account_key
        store.assert_writer_lease(sibling_scope, sibling_lease)

        other_environment = make_scope('live', 'strategy-live', '20260927')
        live_facade = ManagedExecutionFacade(
            store, other_environment, writer_id='family-test-writer', allow_unprotected=True,
        )
        cross_environment_blocked = False
        try:
            live_facade.acquire_writer_lease()
        except InvalidStateTransition:
            cross_environment_blocked = True
        assert cross_environment_blocked

        other_store = SqliteExecutionStore(path)
        try:
            cross_store_blocked = False
            try:
                other_store.acquire_ctp_account_family_owner(sibling_scope)
            except InvalidStateTransition:
                cross_store_blocked = True
            assert cross_store_blocked
            forged_handle_blocked = False
            try:
                other_store.acquire_or_renew_lease(
                    sibling_scope,
                    'family-test-writer',
                    ctp_account_family_owner=same_store_handle,
                )
            except ContractValidationError:
                forged_handle_blocked = True
            assert forged_handle_blocked
        finally:
            other_store.close()
        return {
            'same_store_sibling_facades_share_exact_owner': True,
            'cross_environment_owner_rejected': cross_environment_blocked,
            'cross_store_reopen_rejected': cross_store_blocked,
            'cross_store_handle_rejected': forged_handle_blocked,
            'family_key': first_lease.family_key,
            'owner_id': first_lease.family_owner_intent_id,
        }
    finally:
        store.close()


def concurrent_sim_live_owner(root: Path) -> dict[str, object]:
    path = root / 'contended.sqlite3'
    stores = [SqliteExecutionStore(path), SqliteExecutionStore(path)]
    scopes = [
        make_scope('simulation', 'strategy-sim', '20260926'),
        make_scope('live', 'strategy-live', '20260926'),
    ]
    barrier = Barrier(2)

    def acquire(index: int):
        barrier.wait(timeout=5)
        try:
            handle = stores[index].acquire_ctp_account_family_owner(scopes[index])
            return ('acquired', index, handle)
        except InvalidStateTransition as error:
            return ('rejected', index, str(error))

    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(acquire, (0, 1)))
        successes = [row for row in outcomes if row[0] == 'acquired']
        rejects = [row for row in outcomes if row[0] == 'rejected']
        assert len(successes) == 1 and len(rejects) == 1, outcomes
        winner_index = successes[0][1]
        winner_handle = successes[0][2]
        loser_index = rejects[0][1]
        wrong_environment_lease_blocked = False
        try:
            stores[loser_index].acquire_or_renew_lease(
                scopes[loser_index],
                'contended-writer',
                ctp_account_family_owner=winner_handle,
            )
        except (ContractValidationError, InvalidStateTransition):
            wrong_environment_lease_blocked = True
        assert wrong_environment_lease_blocked
        return {
            'exactly_one_family_owner_winner': True,
            'winner_environment': scopes[winner_index].environment,
            'loser_environment': scopes[loser_index].environment,
            'loser_lease_rejected': wrong_environment_lease_blocked,
        }
    finally:
        for store in stores:
            store.close()


def canonical_aliases_rejected(root: Path) -> dict[str, object]:
    store = SqliteExecutionStore(root / 'aliases.sqlite3')
    reference = account_ref()
    uppercase_provider_rejected = False
    malformed_ref_rejected = False
    try:
        try:
            store.acquire_ctp_account_family_owner(
                ExecutionScope('CTP', 'simulation', reference, 'strategy-a', '20260926')
            )
        except ContractValidationError:
            uppercase_provider_rejected = True
        try:
            store.acquire_ctp_account_family_owner(
                ExecutionScope('ctp', 'simulation', reference.upper(), 'strategy-a', '20260926')
            )
        except ContractValidationError:
            malformed_ref_rejected = True
        assert uppercase_provider_rejected and malformed_ref_rejected
        return {
            'uppercase_provider_rejected': uppercase_provider_rejected,
            'malformed_account_ref_rejected': malformed_ref_rejected,
        }
    finally:
        store.close()


def main() -> None:
    actual_source = source_origin_check()
    root = Path(os.environ.get('V19_FAMILY_DB_DIR') or tempfile.mkdtemp(prefix='v19-family-owner-'))
    root.mkdir(parents=True, exist_ok=True)
    result = {
        'source': actual_source,
        'same_store_sibling_scopes': sibling_scope_reuses_same_store_owner(root),
        'concurrent_sim_live_stores': concurrent_sim_live_owner(root),
        'canonical_aliases': canonical_aliases_rejected(root),
        'native_provider_calls': 0,
    }
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
