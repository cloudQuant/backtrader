from __future__ import annotations

import json
import os
import tempfile
from decimal import Decimal
from pathlib import Path

import bt_api_execution.store as store_module
from bt_api_execution.contracts import (
    ExecutionScope,
    OrderIntent,
    OrderType,
    PositionEffect,
    Side,
)
from bt_api_execution.store import SqliteExecutionStore


def main() -> None:
    expected_src = Path(os.environ['EXPECTED_BT_API_EXECUTION_SRC']).resolve()
    actual_store = Path(store_module.__file__).resolve()
    assert actual_store.is_relative_to(expected_src), f'unexpected source origin: {actual_store}'
    db_dir = Path(os.environ.get('V19_STALE_DB_DIR') or tempfile.mkdtemp(prefix='v19-stale-lease-'))
    db_dir.mkdir(parents=True, exist_ok=True)
    scope = ExecutionScope('fake', 'offline', 'synthetic-stale-lease-account', 'strategy-a')
    store = SqliteExecutionStore(db_dir / 'execution.sqlite3')
    try:
        stale_lease = store.acquire_or_renew_lease(scope, 'same-writer-id')
        released = store.release_lease(
            scope, 'same-writer-id', fencing_token=stale_lease.fencing_token
        )
        new_lease = store.acquire_or_renew_lease(scope, 'same-writer-id')
        assert released is True
        assert new_lease.fencing_token == stale_lease.fencing_token
        assert new_lease.expires_at_ns > stale_lease.expires_at_ns

        stale_mutation_accepted = False
        stale_record = None
        try:
            stale_record = store.admit_intent(
                OrderIntent(
                    intent_id='stale-writer-mutation',
                    scope=scope,
                    signal_id='signal-stale',
                    instrument='FAKE.TEST',
                    side=Side.BUY,
                    position_effect=PositionEffect.OPEN,
                    order_type=OrderType.MARKET,
                    quantity=Decimal('1'),
                ),
                writer_lease=stale_lease,
            )
            stale_mutation_accepted = True
        except Exception:
            stale_mutation_accepted = False

        stale_release_deleted_new_lease = store.release_lease(
            scope, 'same-writer-id', fencing_token=stale_lease.fencing_token
        )
        new_lease_remains_valid = True
        try:
            store.assert_writer_lease(scope, new_lease)
        except Exception:
            new_lease_remains_valid = False

        print(json.dumps({
            'source': str(actual_store),
            'scope_account_key': scope.account_key,
            'lease_token_old': stale_lease.fencing_token,
            'lease_token_new': new_lease.fencing_token,
            'old_expiry_ns': stale_lease.expires_at_ns,
            'new_expiry_ns': new_lease.expires_at_ns,
            'release_old_succeeded': released,
            'stale_writer_mutation_accepted': stale_mutation_accepted,
            'stale_mutation_state': None if stale_record is None else stale_record.state.value,
            'old_release_deleted_new_lease': stale_release_deleted_new_lease,
            'new_lease_remains_valid_after_old_release': new_lease_remains_valid,
            'provider_calls': 0,
        }, sort_keys=True))
        assert not stale_mutation_accepted, 'stale WriterLease authorized a mutation'
        assert not stale_release_deleted_new_lease, 'stale release deleted a newer lease'
        assert new_lease_remains_valid, 'current lease was deleted by stale release'
    finally:
        store.close()


if __name__ == '__main__':
    main()
