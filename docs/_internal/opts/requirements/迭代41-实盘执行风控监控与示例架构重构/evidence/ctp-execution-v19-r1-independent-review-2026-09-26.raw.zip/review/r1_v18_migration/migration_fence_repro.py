from __future__ import annotations

import ast
import hashlib
import json
import os
import shutil
import sqlite3
from pathlib import Path

import bt_api_execution.store as store_module
from bt_api_execution.contracts import ExecutionScope
from bt_api_execution.errors import InvalidStateTransition
from bt_api_execution.store import SqliteExecutionStore


HISTORY_TABLES = (
    'execution_records',
    'execution_outbox',
    'cancellation_records',
    'cancellation_outbox',
    'execution_writer_leases',
    'ctp_order_identity_reservations',
    'ctp_order_target_projections',
    'ctp_dispatch_commands',
    'ctp_dispatch_callback_ledger',
    'ctp_dispatch_callback_session_owners',
    'ctp_dispatch_callback_ingress',
    'ctp_dispatch_trade_fact_ledger',
    'ctp_dispatch_order_cumulative_ledger',
    'ctp_dispatch_order_projection',
    'ctp_dispatch_cancel_projection',
    'ctp_dispatch_cancel_postconditions',
    'ctp_dispatch_cancel_terminal_observations',
    'ctp_dispatch_cancel_postcondition_resolutions',
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def readonly_snapshot(path: Path) -> dict[str, object]:
    connection = sqlite3.connect(f'file:{path.as_posix()}?mode=ro', uri=True)
    connection.row_factory = sqlite3.Row
    try:
        table_names = {
            str(row['name'])
            for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        result: dict[str, object] = {}
        for table in HISTORY_TABLES:
            if table not in table_names:
                continue
            cursor = connection.execute(f'SELECT * FROM "{table}"')
            columns = [str(column[0]) for column in cursor.description]
            rows = cursor.fetchall()
            result[table] = sorted(
                [
                    {
                        column: (type(value).__name__, repr(value))
                        for column, value in zip(columns, row)
                    }
                    for row in rows
                ],
                key=repr,
            )
        meta = connection.execute(
            "SELECT key, value FROM execution_meta WHERE key != 'schema_version' ORDER BY key"
        ).fetchall()
        result['execution_meta_non_version'] = [tuple(row) for row in meta]
        result['foreign_key_check'] = [tuple(row) for row in connection.execute('PRAGMA foreign_key_check')]
        result['schema_version'] = connection.execute(
            "SELECT value FROM execution_meta WHERE key='schema_version'"
        ).fetchone()[0]
        return result
    finally:
        connection.close()


def main() -> None:
    expected_src = Path(os.environ['EXPECTED_BT_API_EXECUTION_SRC']).resolve()
    actual_store = Path(store_module.__file__).resolve()
    assert actual_store.is_relative_to(expected_src), f'unexpected source origin: {actual_store}'
    fixture = Path(os.environ['V18_FIXTURE_PATH']).resolve()
    root = Path(os.environ['V19_MIGRATION_DB_DIR']).resolve()
    root.mkdir(parents=True, exist_ok=True)
    migrated_path = root / 'migrated-v18.sqlite3'
    shutil.copy2(fixture, migrated_path)
    before = readonly_snapshot(migrated_path)
    assert before['schema_version'] == '18'
    assert before['foreign_key_check'] == []
    before_hash = sha256(migrated_path)

    store = SqliteExecutionStore(migrated_path)
    try:
        fence = store._connection.execute(
            'SELECT reason_code, source_schema_version FROM ctp_account_family_legacy_fences '
            'WHERE fence_id=1'
        ).fetchone()
        assert fence is not None
        fence_data = (str(fence['reason_code']), str(fence['source_schema_version']))
        scope = ExecutionScope(
            'ctp', 'live',
            'ctp-account-ref.v1:' + hashlib.sha256(b'unseen-synthetic-account').hexdigest(),
            'new-canonical-scope', '20260928',
        )
        owner_blocked = False
        try:
            store.acquire_ctp_account_family_owner(scope)
        except InvalidStateTransition as error:
            owner_blocked = 'unmapped legacy execution history' in str(error)
        after_version = str(
            store._connection.execute(
                "SELECT value FROM execution_meta WHERE key='schema_version'"
            ).fetchone()[0]
        )
        owner_rows = int(
            store._connection.execute('SELECT COUNT(*) FROM ctp_account_family_owners').fetchone()[0]
        )
        assert owner_blocked
        assert after_version == '19'
        assert owner_rows == 0
    finally:
        store.close()

    after = readonly_snapshot(migrated_path)
    after_hash = sha256(migrated_path)
    unchanged: dict[str, bool] = {}
    for key in before:
        if key in {'schema_version', 'foreign_key_check'}:
            continue
        if key != 'ctp_dispatch_commands':
            unchanged[key] = before[key] == after[key]
            continue
        before_commands = before[key]
        after_commands = after[key]
        assert isinstance(before_commands, list) and isinstance(after_commands, list)
        before_by_id = {
            ast.literal_eval(row['command_id'][1]): row for row in before_commands
        }
        after_by_id = {
            ast.literal_eval(row['command_id'][1]): row for row in after_commands
        }
        assert set(before_by_id) == set(after_by_id)
        allowed_command_transition = True
        command_transitions = []
        for command_id, before_row in before_by_id.items():
            after_row = after_by_id[command_id]
            before_values = {
                name: ast.literal_eval(value[1]) for name, value in before_row.items()
            }
            after_values = {
                name: ast.literal_eval(value[1]) for name, value in after_row.items()
            }
            if before_values['status'] == 'READY':
                if (
                    after_values['status'] != 'UNKNOWN'
                    or after_values['unknown_reason']
                    != 'schema_upgrade_requires_ctp_v2_dispatch_cutover'
                    or int(after_values['unknown_at_ns']) <= 0
                ):
                    allowed_command_transition = False
                else:
                    command_transitions.append(
                        f"{command_id}:READY->UNKNOWN(schema-upgrade-fence)"
                    )
            else:
                for field in ('status', 'unknown_reason', 'unknown_at_ns'):
                    if before_values[field] != after_values[field]:
                        allowed_command_transition = False
            for field in before_values:
                if field in {'status', 'unknown_reason', 'unknown_at_ns'}:
                    continue
                if before_values[field] != after_values[field]:
                    allowed_command_transition = False
        unchanged[key] = allowed_command_transition
        assert allowed_command_transition, 'unexpected CTP dispatch command migration mutation'
    assert after['schema_version'] == '19'
    assert after['foreign_key_check'] == []
    print(json.dumps({
        'source': str(actual_store),
        'v18_fixture': str(fixture),
        'v18_fixture_sha256': sha256(fixture),
        'copied_db_sha256_before_open': before_hash,
        'migrated_db_sha256': after_hash,
        'schema_version_before_after': [before['schema_version'], after['schema_version']],
        'legacy_fence': fence_data,
        'v18_history_tables_unchanged': unchanged,
        'allowed_ctp_command_safety_transitions': command_transitions,
        'owner_creation_blocked': owner_blocked,
        'family_owner_rows': owner_rows,
        'foreign_key_check_before_after': [before['foreign_key_check'], after['foreign_key_check']],
        'native_provider_calls': 0,
    }, sort_keys=True))


if __name__ == '__main__':
    main()
