from __future__ import annotations

import json
import hashlib
import os
import tempfile
import time
from decimal import Decimal
from pathlib import Path

from bt_api_execution.cancellation import ManagedCancellationFacade
from bt_api_execution.contracts import (
    CancelIntent,
    ExecutionScope,
    ExecutionState,
    OrderIntent,
    OrderType,
    PositionEffect,
    ProviderObservation,
    Side,
)
from bt_api_execution.errors import InvalidStateTransition
from bt_api_execution.facade import ManagedExecutionFacade
from bt_api_execution.store import SqliteExecutionStore
import bt_api_execution.store as store_module


def make_intent(intent_id: str, scope: ExecutionScope) -> OrderIntent:
    return OrderIntent(
        intent_id=intent_id,
        scope=scope,
        signal_id='signal-' + intent_id,
        instrument='FAKE.TEST',
        side=Side.BUY,
        position_effect=PositionEffect.OPEN,
        order_type=OrderType.MARKET,
        quantity=Decimal('1'),
    )


def main() -> None:
    expected_src = Path(os.environ['EXPECTED_BT_API_EXECUTION_SRC']).resolve()
    actual_store_module = Path(store_module.__file__).resolve()
    assert actual_store_module.is_relative_to(expected_src), (
        f'execution source origin mismatch: {actual_store_module} != {expected_src}'
    )
    configured_root = os.environ.get('V19_REPRO_DB_DIR')
    temp_root = (
        Path(configured_root).resolve()
        if configured_root
        else Path(tempfile.mkdtemp(prefix='v19-account-gate-'))
    )
    temp_root.mkdir(parents=True, exist_ok=True)
    store_path = temp_root / 'execution.sqlite3'
    provider = 'ctp'
    environment = 'simulation'
    synthetic_ref = 'ctp-account-ref.v1:' + hashlib.sha256(
        b'v19-ctp-family-gate-only'
    ).hexdigest()
    scope_a = ExecutionScope(
        provider=provider, environment=environment, account_ref=synthetic_ref,
        strategy_id='strategy-a', trading_day='20260926',
    )
    scope_b = ExecutionScope(
        provider=provider, environment=environment, account_ref=synthetic_ref,
        strategy_id='strategy-b', trading_day='20260927',
    )
    assert scope_a.account_key == scope_b.account_key
    store = SqliteExecutionStore(store_path)
    ttl_ns = 200_000_000
    facade_a = ManagedExecutionFacade(
        store, scope_a, writer_id='shared-test-writer', lease_ttl_ns=ttl_ns,
        allow_unprotected=True,
    )
    facade_b = ManagedExecutionFacade(
        store, scope_b, writer_id='shared-test-writer', lease_ttl_ns=ttl_ns,
        allow_unprotected=True,
    )
    old_lease = facade_b.acquire_writer_lease()

    target = make_intent('target-order', scope_a)
    target_record = facade_a.submit(
        target,
        lambda intent: ProviderObservation.accepted(intent.intent_id, 'provider-order-1'),
    )
    assert target_record.state is ExecutionState.ACKED

    # This is A's one-time startup scan, completed before B writes its cancel.
    assert store.list_unknown_cancellations(scope_a) == []
    time.sleep(ttl_ns / 1_000_000_000 + 0.05)

    cancellation = ManagedCancellationFacade(
        store,
        scope_a,
        acquire_writer_lease=facade_a.acquire_writer_lease,
        allow_unprotected=True,
    )
    cancel_intent = CancelIntent(
        cancel_id='cancel-unknown-1', scope=scope_a,
        target_intent_id=target.intent_id, provider_order_id='provider-order-1',
    )
    cancel_record = cancellation.cancel(
        cancel_intent,
        lambda _intent: (_ for _ in ()).throw(RuntimeError('simulated crash after claim')),
    )
    assert cancel_record.state is ExecutionState.UNKNOWN
    current_lease = facade_b.acquire_writer_lease()
    assert current_lease.fencing_token > old_lease.fencing_token
    unresolved = store.get_cancel(cancel_intent.cancel_id, scope=scope_a)
    assert unresolved is not None and unresolved.state is ExecutionState.UNKNOWN
    # Intentionally do not call the bridge's separate risk-freeze writer.

    calls: list[str] = []
    next_intent = make_intent('post-unknown-submit', scope_b)
    blocked = False
    try:
        facade_b.submit(
            next_intent,
            lambda intent: calls.append(intent.intent_id)
            or ProviderObservation.accepted(intent.intent_id, 'provider-order-2'),
        )
    except InvalidStateTransition:
        blocked = True

    persisted = store.get(next_intent.intent_id, scope=scope_b)
    print(json.dumps({
        'db': str(store_path),
        'provider_scope': provider,
        'execution_store_module': str(actual_store_module),
        'startup_scan_empty': True,
        'cancel_state': cancel_record.state.value,
        'lease_token_before': old_lease.fencing_token,
        'lease_token_after': current_lease.fencing_token,
        'unresolved_cancellation_state': unresolved.state.value,
        'submit_blocked_before_dispatch': blocked,
        'submit_state': None if persisted is None else persisted.state.value,
        'submit_dispatch_attempts': None if persisted is None else persisted.dispatch_attempts,
        'provider_calls': calls,
        'risk_freeze_called': False,
    }, sort_keys=True), flush=True)
    assert blocked, 'pending cancel did not stop the new submit claim'
    assert calls == [], 'provider dispatcher ran despite pending cancel'
    assert persisted is not None
    assert persisted.state is ExecutionState.PENDING_DISPATCH
    assert persisted.dispatch_attempts == 0
    store.close()


if __name__ == '__main__':
    main()
