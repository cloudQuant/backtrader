from __future__ import annotations

import json
import os
import tempfile
from decimal import Decimal
from pathlib import Path

import bt_api_execution.store as store_module
from bt_api_execution.contracts import (
    ExecutionScope,
    ExecutionState,
    OrderIntent,
    OrderType,
    PositionEffect,
    Side,
)
from bt_api_execution.errors import WriterLeaseUnavailable
from bt_api_execution.store import SqliteExecutionStore


def intent(scope: ExecutionScope, intent_id: str) -> OrderIntent:
    return OrderIntent(
        intent_id=intent_id,
        scope=scope,
        signal_id='signal-' + intent_id,
        instrument='FAKE.TEST',
        side=Side.BUY,
        position_effect=PositionEffect.OPEN,
        order_type=OrderType.MARKET,
        quantity=Decimal('1'),
    )


def main() -> None:
    expected_src = Path(os.environ['EXPECTED_BT_API_EXECUTION_SRC']).resolve()
    actual_store = Path(store_module.__file__).resolve()
    assert actual_store.is_relative_to(expected_src), f'unexpected source origin: {actual_store}'
    db_dir = Path(os.environ.get('V19_STALE_DB_DIR') or tempfile.mkdtemp(prefix='v19-stale-lease-ok-'))
    db_dir.mkdir(parents=True, exist_ok=True)
    scope = ExecutionScope('fake', 'offline', 'synthetic-stale-lease-account', 'strategy-a')
    db_path = db_dir / 'execution.sqlite3'
    store = SqliteExecutionStore(db_path)
    try:
        stale_lease = store.acquire_or_renew_lease(scope, 'same-writer-id')
        assert store.release_lease(scope, 'same-writer-id', fencing_token=stale_lease.fencing_token)
        store.close()
        store = SqliteExecutionStore(db_path)
        current_lease = store.acquire_or_renew_lease(scope, 'same-writer-id')
        assert current_lease.fencing_token == stale_lease.fencing_token + 1
        assert current_lease.expires_at_ns > stale_lease.expires_at_ns

        stale_mutation_rejected = False
        try:
            store.admit_intent(intent(scope, 'old-lease-mutation'), writer_lease=stale_lease)
        except WriterLeaseUnavailable:
            stale_mutation_rejected = True
        assert stale_mutation_rejected

        stale_release_succeeded = store.release_lease(
            scope, 'same-writer-id', fencing_token=stale_lease.fencing_token
        )
        store.assert_writer_lease(scope, current_lease)
        fresh_record = store.admit_intent(intent(scope, 'current-lease-mutation'), writer_lease=current_lease)
        assert fresh_record.state is ExecutionState.PENDING_ADMISSION
        print(json.dumps({
            'source': str(actual_store),
            'lease_token_old': stale_lease.fencing_token,
            'lease_token_current': current_lease.fencing_token,
            'old_expiry_ns': stale_lease.expires_at_ns,
            'current_expiry_ns': current_lease.expires_at_ns,
            'stale_mutation_rejected': stale_mutation_rejected,
            'stale_release_succeeded': stale_release_succeeded,
            'current_lease_survived_stale_release': True,
            'current_mutation_state': fresh_record.state.value,
            'provider_calls': 0,
        }, sort_keys=True))
        assert not stale_release_succeeded
    finally:
        store.close()


if __name__ == '__main__':
    main()
