# G6-P / G8-P Production Path Audit

**Verdict:** G6-P is `F14_STRICT_BLOCKED / LIVE_NO_GO`; G8-P is `NOT_RUN / LIVE_NO_GO`; default production remains `NO_WRITE`. This is a read-only source audit. No tests were run, and no credentials, provider, SDK session, or network endpoint was accessed.

## Current path

- The default 013_3 private registration has only `simulation/sandbox`, `sandbox_write_policy=deny`, and declares `live/managed_live_direct` unavailable ([inventory.py:151](backtrader_runtime/inventory.py:151), [inventory.py:160](backtrader_runtime/inventory.py:160)). The registry rejects unavailable profiles during config validation ([registry.py:1422](backtrader_runtime/registry.py:1422)).
- `prepare_shared_ctp_managed_runner()` can bind a fresh sealed config/profile and a mode-specific selected pair into a **non-authorizing plan**. The production selector may perform credential-free TCP candidate selection when explicitly invoked, but its result hard-codes all approval, credential, execution, and write flags false ([ctp_shared_managed_runner.py:144](backtrader_runtime/ctp_shared_managed_runner.py:144), [ctp_production_managed_composition.py:45](backtrader_runtime/ctp_production_managed_composition.py:45)). It does not verify receipt signatures or installed artifact provenance.
- `open_shared_ctp_managed_runtime()` dispatches simulation to the existing SimNow opener. Its production adapter verifies registration/mode identity and then rejects with `production_native_session_authority_unavailable` before front probing, credentials, SDK import, or native session construction ([ctp_shared_managed_runtime.py:138](backtrader_runtime/ctp_shared_managed_runtime.py:138), [ctp_shared_managed_runtime.py:318](backtrader_runtime/ctp_shared_managed_runtime.py:318)).
- G5 still blocks the common path: the matrix records two OrderRef sources and no common transaction/reservation handoff between Store and execution journal; managed submit/cancel remain hard-rejected before dispatch ([ctp-current-acceptance-matrix.md:42](docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/ctp-current-acceptance-matrix.md:42)).

## F14 seams

`ctp_f14_external_admission.py` binds an exact request to account/config/artifact/session/action/approval facts and defines a `Protocol` for `claim_and_verify` plus `assert_active` ([ctp_f14_external_admission.py:88](backtrader_runtime/ctp_f14_external_admission.py:88), [ctp_f14_external_admission.py:249](backtrader_runtime/ctp_f14_external_admission.py:249)). The module itself says there is no authenticated implementation or route binding. The claim DTO is not self-authenticating; `authority_receipt_digest` is only a formatted digest, and the helper cannot prove the assertions came from a trusted service. `assert_active()` is a separate check before local native dispatch, so it cannot provide an atomic final fence against revocation.

`ctp_f14_signed_receipt_contract.py` verifies canonical receipt bytes, an injected issuer/key/audience policy, injected public-key resolution, request binding, same-version four-collection metadata, and a bounded TTL. It returns `CtpF14ReceiptContractObservation`, explicitly not an admission permit. Its local replay cache is process-local; optional SQLite is a host-local observation fence. Neither is a cross-host authority, snapshot source, dispatch journal, or final provider-call gate ([ctp_f14_signed_receipt_contract.py:152](backtrader_runtime/ctp_f14_signed_receipt_contract.py:152), [ctp_f14_signed_receipt_contract.py:199](backtrader_runtime/ctp_f14_signed_receipt_contract.py:199), [ctp_f14_signed_receipt_contract.py:286](backtrader_runtime/ctp_f14_signed_receipt_contract.py:286), [ctp_f14_signed_receipt_contract.py:582](backtrader_runtime/ctp_f14_signed_receipt_contract.py:582)). A repository-wide source search found no call site connecting these F14 APIs to the shared runner, Store, or production dispatch.

## Facts that must come from outside this repository

1. A named broker/service authority, its authenticated service identity and deployable trust root; public keys/certificates, audience, rotation/revocation, trusted time, and service build ownership.
2. The exact production account identity and complete writer inventory. The authority must control every writer or independently block direct SDK, older host/process, OS user, and manual-client bypasses.
3. The authority's monotonically increasing account epoch, cross-host exclusion, revoke/takeover/UNKNOWN rules, durable action dedupe, and atomic final-dispatch semantics.
4. A trustworthy full-account snapshot source and revision: funds, **all** open orders, trades, positions, complete pagination, account and TradingDay scope, same provider watermark/version, and evidence that the snapshot is held under the same fence.
5. A server-side dispatch receipt and reconciliation contract tying claim, command digest, request IDs, OrderRef/ActionRef, native session generation, callbacks, and terminal account evidence together.
6. Actual production SDK/session/artifact identities and the approved risk/monitor/recovery controls needed by G8-P. Synthetic profile selection cannot establish these facts.

**External service conclusion:** Yes. Real G6-P and production G8-P require a broker/gateway or user-supplied account-control service that is authoritative over the account and performs the final provider dispatch. A token/receipt service that leaves CTP credentials and direct `ReqOrderInsert`/`ReqOrderAction` access in the Backtrader process is insufficient. A user-operated gateway qualifies only if it owns the sole credential/session path and independently prevents or detects all bypass writers.

## Locally implementable code before acceptance

- Add a code-owned adapter seam that verifies the authority's signed bytes against deployment-owned pins and an injected trusted clock. The pin values, key lifecycle, and time source must come from the external service/deployment; do not put generated test keys or user config keys in the default registry.
- Strengthen DTO cross-field checks before such an adapter is wired: `snapshot_coverage_digest` must match the canonical coverage list, claim timestamps need current-time/max-TTL validation, and the signed claim must carry per-collection version and complete-pagination evidence. These checks validate consistency only; they do not prove that the signed snapshot is true.
- Implement the local durable action/OrderRef handoff as one authority, then bind the exact request digest to that reservation and native session generation. Keep production adapter and default live profile fail-closed until a server-owned final-dispatch API exists.

## Smallest safe offline test additions

Existing tests already cover local request binding and fake authority rejection (`test_ctp_f14_external_admission.py`), receipt signature/shape and non-authorizing observation (`test_ctp_f14_signed_receipt_contract.py`), early production rejection, and same-file mode-switch staleness (`test_ctp_shared_managed_runner.py::test_production_session_adapter_rejects_before_probe_credentials_or_sdk`, `::test_shared_session_and_bound_approval_journal_scope_go_stale_after_mode_switch`). They were inspected but not run for this audit.

1. Add one cross-module **no-write guard** test: verify a valid test-key receipt to an observation, attempt to use it as an F14 authority/admission, then call the synthetic live shared-session opener. Assert each step stays non-authorizing or rejects before probe, credential resolver, SDK import, client/session factory, and native-dispatch counters; expected route reason remains `production_native_session_authority_unavailable`. This closes the current test seam between modules without adding an executable route.
2. Only after a code-owned authority adapter exists, add one fake-service integration contract test for signed claim → one-use action → server-side `DispatchClaimedAction` final epoch check. Use a barrier to revoke/transfer between claim and dispatch; stale/revoked claims must yield zero fake dispatches and UNKNOWN must stay frozen. Keep the adapter unregistered and label results `LOCAL_CONTRACT_ONLY`; this test cannot satisfy G6-P.
3. No additional G8 parser test is needed before the production composition exists: existing same-file mode-switch coverage is the useful local scope test. Preserve its assertions that prior SimNow scope is stale and live opening has zero sensitive side effects.

The acceptance matrix says G6-P is blocked because public CTP queries provide no account-wide fence/common snapshot, and G8-P remains not run because the default live route, production session, unified journal, and external control are absent ([ctp-current-acceptance-matrix.md:105](docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/ctp-current-acceptance-matrix.md:105), [matrix:108](docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/ctp-current-acceptance-matrix.md:108)). No offline result changes `NO_WRITE / LIVE_NO_GO`.

## Source binding

See `source-hashes.json` for SHA-256 and byte length of every inspected source, test, and acceptance document. Audit base Git revision: `ad2c142b9a8b42cede85886528c681abdfcb8096`.
