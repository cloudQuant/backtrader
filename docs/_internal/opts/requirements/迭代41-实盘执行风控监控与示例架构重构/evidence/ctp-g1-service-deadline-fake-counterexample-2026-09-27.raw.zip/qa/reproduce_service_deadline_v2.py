import json
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

qa_root = Path(sys.argv[1]).resolve()
snapshot_root = qa_root / "snapshot"
sys.path.insert(0, str(snapshot_root))

from scripts import ctp_i13_i15_windows_guardian_service as service
from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand

expected_hashes = {
    "ctp_i13_i15_windows_guardian_service.py": "686b44cd11d73523a9293d8cd674599fc2a2141f294c06e2f1ebba59b970a117",
    "ctp_i13_i15_outer_watchdog.py": "f738f5deac1e7e5a7db101b72343677bb299f49451a8325cf1defe1305799a79",
    "ctp_i13_i15_windows_job_backend.py": "c1e83f7075f48fa16f5db862d0ef95aec1eed2e8551464c9e990dbb3ecd324fd",
    "ctp_i13_i15_windows_guardian.py": "70faa6da08b6ceaa0d2b618acecdd5b62e72e77133ba0b61e19558db79150641",
}
import hashlib
module_origins = {}
for name, expected in expected_hashes.items():
    path = snapshot_root / "scripts" / name
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise SystemExit(f"snapshot hash mismatch: {name}")
    if name == "ctp_i13_i15_windows_guardian_service.py":
        module = service
    else:
        module = __import__("scripts." + name[:-3], fromlist=["*"])
    origin = Path(module.__file__).resolve()
    if snapshot_root not in origin.parents:
        raise SystemExit(f"module did not import from snapshot: {name}: {origin}")
    module_origins[name] = str(origin)

# The seam is deliberately synthetic: no Windows API, SCM, pipe, anchor loader,
# SDK, CTP package, native module, configuration, or provider is invoked.
service.os = SimpleNamespace(name="nt")
service._bind_service_sid = lambda sid: None
service._verify_current_fixed_service_identity = lambda sid: None
deadline_elapsed = threading.Event()
receipt_entered = threading.Event()
release_receipt = threading.Event()
worker_job_empty = threading.Event()
response_writes = []
clock_lock = threading.Lock()

class Clock:
    def __init__(self):
        self.value = 1000.0
    def monotonic(self):
        with clock_lock:
            return self.value
    def monotonic_ns(self):
        return int(self.monotonic() * 1_000_000_000)
    def advance(self, value):
        with clock_lock:
            self.value = value
        deadline_elapsed.set()

clock = Clock()
request_deadline = clock.monotonic() + 10.5
request_id = "a" * 32
request_raw = json.dumps(
    {
        "schema": service.READONLY_OS_REQUEST_SCHEMA,
        "operation": "ctp_readonly_preflight",
        "request_id": request_id,
        "deadline_monotonic_ns": int(request_deadline * 1_000_000_000),
    },
    sort_keys=True,
    separators=(",", ":"),
).encode("ascii")

class FakeToken:
    handle = 0x101
    client_pid = 4242
    def close(self):
        return True

class FakeSession:
    process_created = True
    job_assignment_observed = True
    def resume_launcher(self):
        return True
    def poll_launcher_exit_code(self):
        return 0
    def poll_job_empty(self):
        return True
    def terminate_job(self):
        return True
    def terminate_launcher_process(self):
        return True
    def release_controls(self):
        worker_job_empty.set()
        return True

class FakeBackend:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.session = FakeSession()
    def create_suspended_in_job(self, command, *, deadline_monotonic):
        return self.session
    def retain_controls(self, session):
        return None

class FakeOutput:
    def __init__(self, read_handle, *, max_bytes):
        self.closed = False
    def poll_abort_reason(self):
        return None
    def read_after_job_empty(self, *, deadline_monotonic, monotonic):
        if not worker_job_empty.is_set():
            raise AssertionError("worker result read before fake Job-empty")
        return b"synthetic worker frame"
    def close(self):
        self.closed = True
        return True

class FakeAnchor:
    service_sid = "S-1-5-80-1-2-3-4-5"
    client_sid = "S-1-5-21-4242"
    pipe_address = r"\\.\pipe\backtrader-ctp-i13-i15-" + "b" * 32
    def verify_current(self):
        return None
    def verify_dependencies_current(self):
        return None
    def close_execution_leases(self):
        return None
    def create_receipt(self, supplied_request_id, raw):
        if supplied_request_id != request_id or raw != b"synthetic receipt":
            raise AssertionError("unexpected receipt inputs")
        # Model a synchronous service-side filesystem/API operation that has no
        # cancellation hook. Advance the request clock beyond its deadline,
        # then stay blocked until the independent test supervisor releases it.
        clock.advance(request_deadline + 1.0)
        receipt_entered.set()
        release_receipt.wait()
        return None
    def close_receipt_lease(self):
        return None

def fake_read_request(handle, *, max_bytes, deadline_monotonic, monotonic):
    return request_raw

service._create_readonly_pipe_server_handle = lambda address, **kwargs: 0x201
service._connect_readonly_pipe_server = lambda *args, **kwargs: None
service._read_readonly_pipe_message = fake_read_request
service._authenticated_pipe_client_primary_token = lambda *args, **kwargs: FakeToken()
service._client_pid_from_pipe = lambda handle: 4242
service._fixed_readonly_worker_command = lambda anchor, *, deadline_monotonic: FixedOuterCommand(
    [sys.executable, "-c", "pass"], str(qa_root), {}
)
service._create_worker_stdio_handles = lambda **kwargs: (0x301, 0x302, 0x303)
service._BoundedWorkerOutput = FakeOutput
service._close_readonly_native_handle = lambda handle: True
service._decode_readonly_worker_output = lambda raw: {"synthetic": True}
service._readonly_service_receipt = lambda **kwargs: b"synthetic receipt"

def capture_response(handle, payload, **kwargs):
    response_writes.append(bytes(payload))

service._write_readonly_pipe_message = capture_response

result_box = {}
exception_box = {}

def call_service():
    try:
        result_box["state"] = service._serve_one_readonly_os_request(
            FakeAnchor(),
            accept_timeout_seconds=4.0,
            monotonic=clock.monotonic,
            monotonic_ns=clock.monotonic_ns,
            backend_factory=FakeBackend,
        )
    except BaseException as exc:
        exception_box["error"] = repr(exc)

thread = threading.Thread(target=call_service, name="fake-g1-service-handler", daemon=True)
real_start = time.monotonic()
thread.start()
if not receipt_entered.wait(2.0):
    release_receipt.set()
    thread.join(1.0)
    raise SystemExit("receipt blocker was never entered")
was_job_empty = worker_job_empty.is_set()
clock_deadline_passed = clock.monotonic() >= request_deadline
thread.join(0.25)  # external bounded supervisor; not the request service itself
alive_after_supervisor_budget = thread.is_alive()
release_receipt.set()
thread.join(2.0)
alive_after_release = thread.is_alive()
if alive_after_release:
    raise SystemExit("service thread failed to leave after test released the fake block")
if exception_box:
    raise SystemExit("service handler raised: " + exception_box["error"])
if not was_job_empty or not clock_deadline_passed or not alive_after_supervisor_budget:
    raise SystemExit("hard-deadline reproduction did not meet expected blocked state")
if response_writes:
    raise SystemExit("response unexpectedly written after synthetic deadline")

result = {
    "request_id": request_id,
    "request_deadline_monotonic": request_deadline,
    "fake_clock_after_create_receipt_entered": clock.monotonic(),
    "deadline_elapsed_while_create_receipt_blocked": clock_deadline_passed,
    "run_outer_watchdog_used": True,
    "fake_worker_job_empty_and_controls_released_before_receipt_block": was_job_empty,
    "receipt_create_entered": receipt_entered.is_set(),
    "external_supervisor_join_budget_seconds": 0.25,
    "service_thread_alive_after_deadline_and_supervisor_budget": alive_after_supervisor_budget,
    "service_thread_alive_after_release": alive_after_release,
    "handler_return_state_after_release": result_box.get("state"),
    "response_writes_after_deadline": len(response_writes),
    "elapsed_wall_seconds": round(time.monotonic() - real_start, 6),
    "module_origins": module_origins,
    "ctp_package_imported": any(name == "bt_api_ctp" or name.startswith("bt_api_ctp.") for name in sys.modules),
}
if result["ctp_package_imported"]:
    raise SystemExit("unexpected CTP import")
(qa_root / "service-deadline-repro-v2.json").write_text(json.dumps(result, sort_keys=True, indent=2), encoding="utf-8")
print(json.dumps(result, sort_keys=True, indent=2))