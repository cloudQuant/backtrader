# Clean CTP Account Handoff: Read-Only Design Audit

Status: design only; no source changes or authorization for a lifecycle trust source.

## Reviewed snapshots

- V19 Store r1 manifest SHA-256: `2558c4248d6e6a202ead02b8fc88d4ed0a3ab3a686a90e55a7fc2b02e4387e10`
- V19 Store `store.py` SHA-256: `0e4b48443a9672df662e0799def92fe2442ebb3d5427f2bfb93a5049b4fe16c8`
- V19 Store `ctp_callback_session.py` SHA-256: `1e348a6f1be695f1042645a49094bbc253b143eed72668cd89a4763d89510d69`
- SDK source: `D:\q\e`, HEAD `29f8ff171f61a71038328a7067e0909bf44774b2`, clean
- SDK `ctp/client.py` SHA-256: `bf915128c41da83efdff517e3ea711c43d7555406bd831a0dfcd775b64840d1c`
- SDK `ctp/callback_ingress.py` SHA-256: `a49465dc36ad4a60ab6a81cde58fd8963ab230be740d3832a792dc0184f48002`
- Current main lifecycle candidate `backtrader_runtime/ctp_i9_account_session_candidate.py` SHA-256: `e80e23200acfb2f3148d914ef5d6076ddd077f39240644df53f4780147d4f2b6` (untracked candidate source at review time)

## Current V19 boundary

The family owner is one permanent row per CTP account family, with only ACTIVE/POISONED states and immutable identity. The callback-session owner is one durable row per account, with PREPARED/ACTIVE/POISONED states; it cannot be deleted or reactivated after poison. Reopening the Store cannot reissue its exact in-process handles, and creating a new session owner rejects if any prior owner exists.

The main candidate's `stop()` poisons the durable session/family owner before calling the abstract `CtpI9NativeLifecycleSupervisor.stop_client(client) -> None`. It returns no typed close proof and commits no clean-close fact. A successful client stop therefore still leaves the family permanently fenced. This is safe, but does not support clean same-file operator restart.

The SDK's frozen `CtpNativeStopReceipt` contains connection generation, Join-required/completed, Release-returned, Python Join-observer thread alive, and timeout fields. Its `complete` property is a local predicate. The SDK source describes Join as an observation of its API interface thread only; Release is marked complete when the Python Release call returns without exception. The receipt omits owner/session/source/API identities, native lifecycle generation, callback source high-watermark, callback/request reference counts, callback-detach success, and an issuer capability. It is a constructible frozen dataclass, not a Store authority. Its no-current-API path can return all-green values. The main supervisor contract returns None. Store has no close/handoff API that consumes lifecycle evidence.

## Proposed future protocol

1. Add append-only owner generations and a one-shot close-attempt ledger. Do not delete or unpoison the existing owner. The state flow should be ACTIVE -> DRAINING -> CLOSED; every timeout, crash, mismatched proof, unresolved fact, or ambiguous close leaves a durable permanent fence.
2. In one Store transaction, `begin_close` must verify the exact same-Store family/session handle and current unexpired writer lease, then atomically fence all new submit/cancel/native claims across all scopes and trading days in the account family. Existing verified callbacks may continue to append while DRAINING.
3. Drain the actor command queue and already-issued SDK requests. Apply all callback ingress through a final source-issued sequence barrier. No caller boolean or empty query count can stand in for the barrier.
4. An install-time code-owned SDK lifecycle adapter must produce a typed proof bound to the exact owner/session and client/API/SPI/source/native/connection generations. It must report the exact Join outcome if required, successful Release, successful callback detachment, zero in-flight native request/callback references, and final callback sequence. Current SDK receipt and main supervisor API do not expose this complete binding.
5. A final Store transaction must recheck all account-family facts and the exact lifecycle proof: no DISPATCHING/CLAIMED/UNKNOWN operations; all intents, cancels, and cancel postconditions terminal/resolved; all terminal-order and trade quantities reconciled; no pending or unapplied ingress; no owner/session poison or legacy fence; no in-flight native binding. If positions remain, carry their reconciled state forward rather than asserting flat.
6. In the same commit, write immutable close evidence, mark the old owner generation CLOSED, and tombstone/revoke the old writer lease generation. Only then may generation+1 be issued. The original owner and all close facts remain immutable.
7. A crash before the final commit remains DRAINING/POISONED and cannot be resumed by a caller-provided receipt. Recovery after process death requires a trusted external process/account supervisor that can prove the old process/native session is gone; no such implementation is currently present.

## Review limits

This is a local code/Store contract proposal, not a deployed account fence, native-provider guarantee, hostile in-process Python sandbox, or file-clone/reparse defense. Existing permanent refusal remains the correct behavior until the missing issuer and supervisor APIs are independently implemented and accepted.
