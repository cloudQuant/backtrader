from pathlib import Path
import hashlib
import json
import sqlite3
import sys

frozen = Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r0_20260926")
sys.path.insert(0, str(frozen / "src"))
from bt_api_execution import ExecutionScope, SqliteExecutionStore

out = Path(r"D:\temp\iteration41_v20_root_schema_probe_20260926")
out.mkdir(exist_ok=False)
db = out / "same-name-wrong-trigger.sqlite3"
scope = ExecutionScope("ctp", "simnow", "ctp-account-ref.v1:" + hashlib.sha256(b"synthetic-root-account").hexdigest(), "root-schema-probe", "20260926")
store = SqliteExecutionStore.open_ctp_account_store(db, scope)
identity_before = store.read_ctp_account_store_identity(scope)
store.close()
with sqlite3.connect(db) as connection:
    original_sql = connection.execute("SELECT sql FROM sqlite_master WHERE name='ctp_account_store_identity_immutable_update'").fetchone()[0]
    connection.execute("DROP TRIGGER ctp_account_store_identity_immutable_update")
    connection.execute("CREATE TRIGGER ctp_account_store_identity_immutable_update BEFORE UPDATE ON ctp_account_store_identity BEGIN SELECT 1; END")
before = hashlib.sha256(db.read_bytes()).hexdigest()
inspection = SqliteExecutionStore.inspect_ctp_account_store_file(db, scope)
store = SqliteExecutionStore.open_ctp_account_store(db, scope)
identity_after = store.read_ctp_account_store_identity(scope)
store.close()
result = {
    "schema": "iteration41.v20.root_schema_probe.v1",
    "store_source": str(frozen / "src/bt_api_execution/store.py"),
    "store_sha256": hashlib.sha256((frozen / "src/bt_api_execution/store.py").read_bytes()).hexdigest(),
    "database": str(db),
    "database_sha256_before_inspect": before,
    "database_sha256_after_open": hashlib.sha256(db.read_bytes()).hexdigest(),
    "original_trigger_sql": original_sql,
    "inspection_kind": inspection.kind,
    "factory_open_accepted": True,
    "identity_unchanged": identity_after == identity_before,
    "native_calls": 0,
    "scope": "Synthetic temporary SQLite only; unchanged names conceal an incorrect trigger definition. This is a schema-validation counterexample, not a filesystem attacker isolation claim.",
}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
