"""Fake-only contract prototype for recovering a crashed CTP dispatch owner.

This is intentionally not production code.  It models the minimum trust and
SQLite transition needed before a real process-supervisor integration exists.
"""

from __future__ import annotations

import sqlite3
import uuid
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path


class RecoveryBlocked(RuntimeError):
    pass


@dataclass(frozen=True)
class ProcessExitReceiptV1:
    supervisor_id: str
    owner_id: str
    process_generation_id: str
    job_id: str
    nonce: str
    process_exit_observed: bool
    job_empty_observed: bool
    controls_released: bool


class FakeProcessSupervisor:
    """External fake supervisor; its receipt registry is not stored in SQLite."""

    def __init__(self, supervisor_id: str = "fake-outer-supervisor") -> None:
        self.supervisor_id = supervisor_id
        self._workers: dict[tuple[str, str], dict[str, object]] = {}
        self._receipts: dict[str, ProcessExitReceiptV1] = {}

    def bind_worker(self, owner_id: str, generation_id: str, job_id: str) -> None:
        key = (owner_id, generation_id)
        if key in self._workers:
            raise RecoveryBlocked("process generation already bound")
        self._workers[key] = {
            "job_id": job_id,
            "process_exit_observed": False,
            "job_empty_observed": False,
            "controls_released": False,
            "job_sealed": False,
        }

    def observe_exit(
        self,
        owner_id: str,
        generation_id: str,
        *,
        process_exit_observed: bool,
        job_empty_observed: bool,
        controls_released: bool,
        job_sealed: bool,
    ) -> None:
        worker = self._workers[(owner_id, generation_id)]
        worker.update(
            process_exit_observed=process_exit_observed,
            job_empty_observed=job_empty_observed,
            controls_released=controls_released,
            job_sealed=job_sealed,
        )

    def issue_exit_receipt(
        self, owner_id: str, generation_id: str
    ) -> ProcessExitReceiptV1:
        worker = self._workers.get((owner_id, generation_id))
        if worker is None or not all(
            worker[name] is True
            for name in (
                "process_exit_observed",
                "job_empty_observed",
                "controls_released",
                "job_sealed",
            )
        ):
            raise RecoveryBlocked("supervisor has not proved process-tree exit")
        receipt = ProcessExitReceiptV1(
            supervisor_id=self.supervisor_id,
            owner_id=owner_id,
            process_generation_id=generation_id,
            job_id=str(worker["job_id"]),
            nonce=uuid.uuid4().hex,
            process_exit_observed=True,
            job_empty_observed=True,
            controls_released=True,
        )
        self._receipts[receipt.nonce] = receipt
        return receipt

    def verifies_exact_exit(
        self, receipt: ProcessExitReceiptV1, owner_id: str, generation_id: str
    ) -> bool:
        if type(receipt) is not ProcessExitReceiptV1:
            return False
        worker = self._workers.get((owner_id, generation_id))
        return bool(
            worker is not None
            and self._receipts.get(receipt.nonce) is receipt
            and receipt.supervisor_id == self.supervisor_id
            and receipt.owner_id == owner_id
            and receipt.process_generation_id == generation_id
            and receipt.job_id == worker["job_id"]
            and receipt.process_exit_observed is True
            and receipt.job_empty_observed is True
            and receipt.controls_released is True
            and worker["process_exit_observed"] is True
            and worker["job_empty_observed"] is True
            and worker["controls_released"] is True
            and worker["job_sealed"] is True
        )


class RecoveryContractStore:
    """Small SQLite model of one permanent family/session owner and a claim."""

    def __init__(self, path: Path, supervisor: FakeProcessSupervisor) -> None:
        self._db = sqlite3.connect(path, isolation_level=None)
        self._db.row_factory = sqlite3.Row
        self._supervisor = supervisor
        self._db.executescript(
            """
            PRAGMA foreign_keys = ON;
            CREATE TABLE IF NOT EXISTS family_owner (
                family_key TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL UNIQUE,
                process_generation_id TEXT NOT NULL,
                supervisor_id TEXT NOT NULL,
                state TEXT NOT NULL,
                poison_code TEXT
            );
            CREATE TABLE IF NOT EXISTS session_owner (
                owner_id TEXT PRIMARY KEY,
                state TEXT NOT NULL,
                process_generation_id TEXT NOT NULL,
                poison_code TEXT,
                FOREIGN KEY(owner_id) REFERENCES family_owner(owner_id)
            );
            CREATE TABLE IF NOT EXISTS command (
                command_id TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL,
                process_generation_id TEXT NOT NULL,
                status TEXT NOT NULL,
                native_call_inflight INTEGER NOT NULL,
                unknown_reason TEXT,
                FOREIGN KEY(owner_id) REFERENCES session_owner(owner_id)
            );
            CREATE TABLE IF NOT EXISTS owner_exit_recovery (
                owner_id TEXT PRIMARY KEY,
                process_generation_id TEXT NOT NULL,
                receipt_nonce TEXT NOT NULL UNIQUE,
                recovered_command_count INTEGER NOT NULL
            );
            """
        )
        self._issued_owner_handles: dict[str, object] = {}

    def close(self) -> None:
        self._db.close()

    def create_owner_for_test(self) -> tuple[str, str, object]:
        """Seed an owner bound to a supervisor-owned process generation."""

        owner_id = uuid.uuid4().hex
        generation_id = uuid.uuid4().hex
        job_id = uuid.uuid4().hex
        self._supervisor.bind_worker(owner_id, generation_id, job_id)
        self._db.execute("BEGIN IMMEDIATE")
        try:
            self._db.execute(
                "INSERT INTO family_owner VALUES (?, ?, ?, ?, 'ACTIVE', NULL)",
                (
                    "ctp-account-family.v1:fake",
                    owner_id,
                    generation_id,
                    self._supervisor.supervisor_id,
                ),
            )
            self._db.execute(
                "INSERT INTO session_owner VALUES (?, 'ACTIVE', ?, NULL)",
                (owner_id, generation_id),
            )
            self._db.commit()
        except BaseException:
            self._db.rollback()
            raise
        handle = object()
        self._issued_owner_handles[owner_id] = handle
        return owner_id, generation_id, handle

    def create_command_for_test(self, command_id: str, owner_id: str) -> None:
        owner = self._db.execute(
            "SELECT process_generation_id FROM session_owner WHERE owner_id = ?",
            (owner_id,),
        ).fetchone()
        self._db.execute(
            "INSERT INTO command VALUES (?, ?, ?, 'READY', 0, NULL)",
            (command_id, owner_id, owner["process_generation_id"]),
        )

    def claim_for_test(self, command_id: str, owner_id: str, handle: object) -> None:
        if self._issued_owner_handles.get(owner_id) is not handle:
            raise RecoveryBlocked("exact same-process owner handle required")
        self._db.execute("BEGIN IMMEDIATE")
        try:
            owner = self._db.execute(
                "SELECT state FROM session_owner WHERE owner_id = ?", (owner_id,)
            ).fetchone()
            family = self._db.execute(
                "SELECT state FROM family_owner WHERE owner_id = ?", (owner_id,)
            ).fetchone()
            if owner is None or owner["state"] != "ACTIVE" or family["state"] != "ACTIVE":
                raise RecoveryBlocked("owner is not active")
            changed = self._db.execute(
                "UPDATE command SET status='CLAIMED', native_call_inflight=1 "
                "WHERE command_id=? AND status='READY' AND owner_id=?",
                (command_id, owner_id),
            ).rowcount
            if changed != 1:
                raise RecoveryBlocked("command cannot be claimed")
            self._db.commit()
        except BaseException:
            self._db.rollback()
            raise

    def acquire_owner_after_restart(self) -> None:
        """There is intentionally no same-account owner recreation path."""

        row = self._db.execute("SELECT state FROM family_owner").fetchone()
        if row is not None:
            raise RecoveryBlocked("persisted CTP family owner is one-shot")
        raise RecoveryBlocked("fresh CTP owner requires the trusted factory path")

    def assert_native_call_authorized(
        self, command_id: str, owner_id: str, handle: object
    ) -> None:
        """Model the pre-Req gate: only the exact live same-Store owner may send."""

        if self._issued_owner_handles.get(owner_id) is not handle:
            raise RecoveryBlocked("exact same-process owner handle required")
        owner = self._db.execute(
            "SELECT state FROM session_owner WHERE owner_id = ?", (owner_id,)
        ).fetchone()
        family = self._db.execute(
            "SELECT state FROM family_owner WHERE owner_id = ?", (owner_id,)
        ).fetchone()
        if (
            owner is None
            or family is None
            or owner["state"] != "ACTIVE"
            or family["state"] != "ACTIVE"
        ):
            raise RecoveryBlocked("durable owner is fenced before native call")
        command = self._db.execute(
            "SELECT status,native_call_inflight,process_generation_id FROM command "
            "WHERE command_id=? AND owner_id=?",
            (command_id, owner_id),
        ).fetchone()
        owner_generation = self._db.execute(
            "SELECT process_generation_id FROM session_owner WHERE owner_id=?",
            (owner_id,),
        ).fetchone()[0]
        if (
            command is None
            or command["status"] != "CLAIMED"
            or command["native_call_inflight"] != 1
            or command["process_generation_id"] != owner_generation
        ):
            raise RecoveryBlocked("exact claimed command is not eligible for native call")
        unresolved_unknown = self._db.execute(
            "SELECT 1 FROM command WHERE owner_id=? AND status='UNKNOWN' LIMIT 1",
            (owner_id,),
        ).fetchone()
        if unresolved_unknown is not None:
            raise RecoveryBlocked("unresolved command blocks native call")

    def recover_stale_owner(self, *, before_commit: Callable[[], None] | None = None) -> int:
        """Ask the fixed supervisor for proof, then commit UNKNOWN + poison once."""

        owner = self._db.execute("SELECT * FROM family_owner").fetchone()
        session = self._db.execute(
            "SELECT * FROM session_owner WHERE owner_id = ?",
            (None if owner is None else owner["owner_id"],),
        ).fetchone()
        if owner is None or session is None:
            raise RecoveryBlocked("no persisted owner to recover")
        if owner["supervisor_id"] != self._supervisor.supervisor_id:
            raise RecoveryBlocked("recovery supervisor does not own this process generation")
        if owner["state"] != "ACTIVE" or session["state"] != "ACTIVE":
            raise RecoveryBlocked("owner is already fenced")
        owner_id = str(owner["owner_id"])
        generation_id = str(owner["process_generation_id"])
        receipt = self._supervisor.issue_exit_receipt(owner_id, generation_id)
        if not self._supervisor.verifies_exact_exit(receipt, owner_id, generation_id):
            raise RecoveryBlocked("process-exit proof does not match persisted owner")

        self._db.execute("BEGIN IMMEDIATE")
        try:
            current = self._db.execute(
                "SELECT * FROM family_owner WHERE owner_id = ?", (owner_id,)
            ).fetchone()
            current_session = self._db.execute(
                "SELECT * FROM session_owner WHERE owner_id = ?", (owner_id,)
            ).fetchone()
            if (
                current is None
                or current_session is None
                or current["process_generation_id"] != generation_id
                or current["supervisor_id"] != self._supervisor.supervisor_id
                or current["state"] != "ACTIVE"
                or current_session["state"] != "ACTIVE"
                or not self._supervisor.verifies_exact_exit(receipt, owner_id, generation_id)
            ):
                raise RecoveryBlocked("owner changed before crash recovery commit")
            rows = self._db.execute(
                "SELECT command_id,status,native_call_inflight FROM command "
                "WHERE owner_id=? AND process_generation_id=?",
                (owner_id, generation_id),
            ).fetchall()
            recovered = 0
            for row in rows:
                if row["status"] == "CLAIMED":
                    self._db.execute(
                        "UPDATE command SET status='UNKNOWN', native_call_inflight=0, "
                        "unknown_reason='owner_process_exit_inflight' "
                        "WHERE command_id=? AND status='CLAIMED'",
                        (row["command_id"],),
                    )
                    recovered += 1
            if before_commit is not None:
                before_commit()
            self._db.execute(
                "UPDATE session_owner SET state='POISONED', "
                "poison_code='owner_process_exit' WHERE owner_id=? AND state='ACTIVE'",
                (owner_id,),
            )
            self._db.execute(
                "UPDATE family_owner SET state='POISONED', "
                "poison_code='owner_process_exit' WHERE owner_id=? AND state='ACTIVE'",
                (owner_id,),
            )
            self._db.execute(
                "INSERT INTO owner_exit_recovery VALUES (?, ?, ?, ?)",
                (owner_id, generation_id, receipt.nonce, recovered),
            )
            self._db.commit()
            return recovered
        except BaseException:
            self._db.rollback()
            raise

    def state(self, owner_id: str) -> dict[str, object]:
        command = self._db.execute(
            "SELECT status,native_call_inflight,unknown_reason FROM command WHERE owner_id=?",
            (owner_id,),
        ).fetchall()
        owner = self._db.execute(
            "SELECT state,poison_code FROM session_owner WHERE owner_id=?", (owner_id,)
        ).fetchone()
        family = self._db.execute(
            "SELECT state,poison_code FROM family_owner WHERE owner_id=?", (owner_id,)
        ).fetchone()
        return {
            "commands": [tuple(row) for row in command],
            "owner": None if owner is None else tuple(owner),
            "family": None if family is None else tuple(family),
            "recoveries": self._db.execute(
                "SELECT COUNT(*) FROM owner_exit_recovery WHERE owner_id=?", (owner_id,)
            ).fetchone()[0],
        }

    def commit_forged_proof_for_test(self, receipt: ProcessExitReceiptV1) -> int:
        """Test hook: the public recovery API never accepts a caller receipt."""

        owner = self._db.execute("SELECT * FROM family_owner").fetchone()
        if owner is None or not self._supervisor.verifies_exact_exit(
            receipt, str(owner["owner_id"]), str(owner["process_generation_id"])
        ):
            raise RecoveryBlocked("supervisor did not issue exact process-exit proof")
        return self.recover_stale_owner()


def clone_receipt(receipt: ProcessExitReceiptV1) -> ProcessExitReceiptV1:
    """A caller can copy fields, but the supervisor will reject the clone."""

    return replace(receipt)
