from __future__ import annotations

import json
import sys
from pathlib import Path

CANDIDATE_ROOT = Path(r"D:\temp\iteration41-g5-independent-recovery-qa-20260927-01\r0-reconstructed")
sys.dont_write_bytecode = True
sys.path.insert(0, str(CANDIDATE_ROOT))
from recovery_contract import FakeProcessSupervisor, RecoveryContractStore  # noqa: E402

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "generation-mismatch.sqlite3"
if DB_PATH.exists():
    raise SystemExit("refusing to overwrite existing QA database")
supervisor = FakeProcessSupervisor()
store = RecoveryContractStore(DB_PATH, supervisor)
owner_id, generation_id, handle = store.create_owner_for_test()
store.create_command_for_test("cmd-generation-mismatch", owner_id)
store.claim_for_test("cmd-generation-mismatch", owner_id, handle)


def rows():
    family = store._db.execute(
        "SELECT state,process_generation_id,supervisor_id FROM family_owner WHERE owner_id=?",
        (owner_id,),
    ).fetchone()
    session = store._db.execute(
        "SELECT state,process_generation_id,poison_code FROM session_owner WHERE owner_id=?",
        (owner_id,),
    ).fetchone()
    command = store._db.execute(
        "SELECT status,native_call_inflight,unknown_reason,process_generation_id FROM command WHERE owner_id=?",
        (owner_id,),
    ).fetchone()
    return {
        "family": list(family),
        "session": list(session),
        "command": list(command),
        "recoveries": store._db.execute(
            "SELECT COUNT(*) FROM owner_exit_recovery WHERE owner_id=?", (owner_id,)
        ).fetchone()[0],
    }


before_corruption = rows()
store._db.execute(
    "UPDATE session_owner SET process_generation_id=? WHERE owner_id=?",
    ("mismatched-generation", owner_id),
)
before_recovery = rows()
supervisor.observe_exit(
    owner_id,
    generation_id,
    process_exit_observed=True,
    job_empty_observed=True,
    controls_released=True,
    job_sealed=True,
)
try:
    recovered_count = store.recover_stale_owner()
    recovery_result = {"accepted": True, "recovered_count": recovered_count}
except BaseException as exc:
    recovery_result = {"accepted": False, "error_type": type(exc).__name__}
after_recovery = rows()
store.close()
result = {
    "scope": "fake SQLite model only; no CTP/native/provider/SCM/network",
    "receipt": "exact fake supervisor proof for family owner generation",
    "session_generation_was_mismatched": True,
    "before_corruption": before_corruption,
    "before_recovery": before_recovery,
    "recovery_result": recovery_result,
    "after_recovery": after_recovery,
    "expected": "reject generation mismatch without changing rows",
    "finding": "REPRODUCED: r0 accepted proof despite session generation mismatch"
    if recovery_result["accepted"]
    else "NOT REPRODUCED: r0 rejected mismatch",
}
raw = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
(ROOT / "generation-mismatch-result.json").write_text(raw, encoding="ascii")
print(raw, end="")
