from __future__ import annotations

import pytest

from recovery_contract import (
    FakeProcessSupervisor,
    ProcessExitReceiptV1,
    RecoveryBlocked,
    RecoveryContractStore,
)


def _claimed_after_reopen(tmp_path):
    path = tmp_path / "candidate.sqlite3"
    supervisor = FakeProcessSupervisor()
    store = RecoveryContractStore(path, supervisor)
    owner_id, generation_id, handle = store.create_owner_for_test()
    store.create_command_for_test("cmd-1", owner_id)
    store.claim_for_test("cmd-1", owner_id, handle)
    store.assert_native_call_authorized("cmd-1", owner_id, handle)
    store.close()
    return path, supervisor, owner_id, generation_id, handle, RecoveryContractStore(
        path, supervisor
    )


def test_store_close_is_not_process_death_and_new_actor_cannot_self_authorize(tmp_path):
    _, supervisor, owner_id, generation_id, _old_handle, reopened = _claimed_after_reopen(
        tmp_path
    )
    before = reopened.state(owner_id)

    with pytest.raises(RecoveryBlocked, match="has not proved process-tree exit"):
        reopened.recover_stale_owner()
    with pytest.raises(RecoveryBlocked, match="one-shot"):
        reopened.acquire_owner_after_restart()
    native_calls = []
    try:
        reopened.assert_native_call_authorized("cmd-1", owner_id, object())
    except RecoveryBlocked:
        pass
    else:
        native_calls.append("ReqOrderInsert")

    forged = ProcessExitReceiptV1(
        supervisor_id=supervisor.supervisor_id,
        owner_id=owner_id,
        process_generation_id=generation_id,
        job_id="caller-claimed-empty-job",
        nonce="caller-invented-nonce",
        process_exit_observed=True,
        job_empty_observed=True,
        controls_released=True,
    )
    with pytest.raises(RecoveryBlocked, match="did not issue exact"):
        reopened.commit_forged_proof_for_test(forged)

    assert reopened.state(owner_id) == before
    assert before["commands"] == [("CLAIMED", 1, None)]
    assert before["owner"] == ("ACTIVE", None)
    assert before["family"] == ("ACTIVE", None)
    assert native_calls == []
    reopened.close()


@pytest.mark.parametrize(
    "facts",
    [
        {"process_exit_observed": False, "job_empty_observed": True, "controls_released": True, "job_sealed": True},
        {"process_exit_observed": True, "job_empty_observed": False, "controls_released": True, "job_sealed": True},
        {"process_exit_observed": True, "job_empty_observed": True, "controls_released": False, "job_sealed": True},
        {"process_exit_observed": True, "job_empty_observed": True, "controls_released": True, "job_sealed": False},
    ],
)
def test_partial_or_unsealed_process_exit_facts_do_not_recover_claim(tmp_path, facts):
    _, supervisor, owner_id, generation_id, _, reopened = _claimed_after_reopen(tmp_path)
    supervisor.observe_exit(owner_id, generation_id, **facts)
    with pytest.raises(RecoveryBlocked, match="has not proved process-tree exit"):
        reopened.recover_stale_owner()
    assert reopened.state(owner_id)["commands"] == [("CLAIMED", 1, None)]
    reopened.close()


def test_exact_dead_generation_commits_unknown_before_any_new_send_or_owner(tmp_path):
    _, supervisor, owner_id, generation_id, old_handle, reopened = _claimed_after_reopen(
        tmp_path
    )
    supervisor.observe_exit(
        owner_id,
        generation_id,
        process_exit_observed=True,
        job_empty_observed=True,
        controls_released=True,
        job_sealed=True,
    )

    assert reopened.recover_stale_owner() == 1
    state = reopened.state(owner_id)
    assert state["commands"] == [("UNKNOWN", 0, "owner_process_exit_inflight")]
    assert state["owner"] == ("POISONED", "owner_process_exit")
    assert state["family"] == ("POISONED", "owner_process_exit")
    assert state["recoveries"] == 1

    # A restart has no old same-Store handle and recovery never issues a new one.
    with pytest.raises(RecoveryBlocked, match="one-shot"):
        reopened.acquire_owner_after_restart()
    with pytest.raises(RecoveryBlocked, match="same-process owner handle"):
        reopened.claim_for_test("cmd-1", owner_id, old_handle)
    native_calls = []
    try:
        reopened.assert_native_call_authorized("cmd-1", owner_id, old_handle)
    except RecoveryBlocked:
        pass
    else:
        native_calls.append("ReqOrderInsert")
    assert native_calls == []
    assert state["commands"][0][0] == "UNKNOWN"
    assert reopened._db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    reopened.close()


def test_wrong_generation_receipt_and_recovery_replay_cannot_change_state(tmp_path):
    _, supervisor, owner_id, generation_id, _, reopened = _claimed_after_reopen(tmp_path)
    supervisor.bind_worker("other-owner", "other-generation", "other-job")
    supervisor.observe_exit(
        "other-owner",
        "other-generation",
        process_exit_observed=True,
        job_empty_observed=True,
        controls_released=True,
        job_sealed=True,
    )
    other_receipt = supervisor.issue_exit_receipt("other-owner", "other-generation")
    with pytest.raises(RecoveryBlocked, match="did not issue exact"):
        reopened.commit_forged_proof_for_test(other_receipt)
    assert reopened.state(owner_id)["commands"] == [("CLAIMED", 1, None)]

    supervisor.observe_exit(
        owner_id,
        generation_id,
        process_exit_observed=True,
        job_empty_observed=True,
        controls_released=True,
        job_sealed=True,
    )
    assert reopened.recover_stale_owner() == 1
    after_recovery = reopened.state(owner_id)
    with pytest.raises(RecoveryBlocked, match="already fenced"):
        reopened.recover_stale_owner()
    assert reopened.state(owner_id) == after_recovery
    assert after_recovery["recoveries"] == 1
    reopened.close()


def test_session_generation_mismatch_rejects_recovery_without_mutation(tmp_path):
    _, supervisor, owner_id, generation_id, _, reopened = _claimed_after_reopen(tmp_path)
    supervisor.observe_exit(
        owner_id,
        generation_id,
        process_exit_observed=True,
        job_empty_observed=True,
        controls_released=True,
        job_sealed=True,
    )
    reopened._db.execute(
        "UPDATE session_owner SET process_generation_id=? WHERE owner_id=?",
        ("mismatched-generation", owner_id),
    )
    before = reopened.state(owner_id)

    with pytest.raises(RecoveryBlocked, match="owner changed before crash recovery commit"):
        reopened.recover_stale_owner()

    assert reopened.state(owner_id) == before
    assert before["commands"] == [("CLAIMED", 1, None)]
    assert before["owner"] == ("ACTIVE", None)
    assert before["family"] == ("ACTIVE", None)
    assert reopened._db.execute(
        "SELECT process_generation_id FROM session_owner WHERE owner_id=?", (owner_id,)
    ).fetchone()[0] == "mismatched-generation"
    reopened.close()


def test_recovery_transaction_rollback_keeps_claim_fenced_then_retry_is_idempotent(
    tmp_path,
):
    _, supervisor, owner_id, generation_id, _, reopened = _claimed_after_reopen(tmp_path)
    supervisor.observe_exit(
        owner_id,
        generation_id,
        process_exit_observed=True,
        job_empty_observed=True,
        controls_released=True,
        job_sealed=True,
    )

    def abort_transaction():
        raise RuntimeError("synthetic sqlite commit boundary failure")

    with pytest.raises(RuntimeError, match="commit boundary"):
        reopened.recover_stale_owner(before_commit=abort_transaction)
    assert reopened.state(owner_id)["commands"] == [("CLAIMED", 1, None)]
    assert reopened.state(owner_id)["owner"] == ("ACTIVE", None)
    with pytest.raises(RecoveryBlocked, match="one-shot"):
        reopened.acquire_owner_after_restart()

    # The same confirmed dead generation can be observed again after rollback.
    assert reopened.recover_stale_owner() == 1
    assert reopened.state(owner_id)["commands"] == [
        ("UNKNOWN", 0, "owner_process_exit_inflight")
    ]
    reopened.close()
