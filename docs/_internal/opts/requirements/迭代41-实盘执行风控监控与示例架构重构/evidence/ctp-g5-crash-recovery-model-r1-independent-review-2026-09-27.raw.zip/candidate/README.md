# G5 process-crash recovery contract prototype

This directory is a fake-only design probe for the separate crash-before-Req
boundary. It does not modify the main tree, SDK, or installed wheels. It does
not import `_ctp`, start a provider, or send an order.

## Proposed recovery boundary

The Store must not infer process death from `close()`, lease expiry, an owner ID,
PID text, or a caller-supplied `dead=True`. It must not recreate an active
one-shot family/session owner on restart. Recovery is permitted only through a
code-owned startup factory with a fixed process-exit verifier supplied by a
trusted outer supervisor. The verifier must prove the exact persisted
`owner_intent_id` and `process_generation_id` have a signaled process handle,
an empty sealed Job, and released process/Job controls. Missing or ambiguous
facts leave the account fenced.

After proof, one `BEGIN IMMEDIATE` transaction re-reads the exact persisted
family owner, callback-session owner, process generation, and dispatch rows. It
changes every unreceipted `CLAIMED` command bound to that generation to
`UNKNOWN`, clears `native_call_inflight`, writes a fixed crash reason and a
one-use recovery record, and permanently poisons the old session/family owner.
The proof is fetched from the fixed supervisor adapter, not passed as a public
boolean or owner identifier. Recovery never issues a new owner or send handle.
If the transaction rolls back, the rows remain unchanged and a retry still
requires the same supervisor to prove the same terminated generation.

`UNKNOWN` is mandatory even if the process appears to have crashed before its
native request: the persisted claim precedes the Req boundary, so the Store
cannot distinguish “not called” from “called, then crashed before receipt.”
The recovery API must therefore poison the account and keep future sends
closed. It is not a clean handoff and does not resolve orders, restore the
callback stream, or authorize another session.

## Prototype result

`recovery_contract.py` models a fixed supervisor whose proof registry is
separate from SQLite. `test_recovery_contract.py` covers:

- Store close/reopen without process-exit proof leaves the old claim unchanged
  and cannot mint a new owner or native-call authorization.
- Caller-fabricated and cross-generation receipts are rejected.
- A mismatch between the persisted family-owner and session-owner process
  generations rejects recovery before any durable state change.
- Partial process/Job/control facts do not recover a claim.
- Exact supervisor evidence atomically changes `CLAIMED/inflight=1` to
  `UNKNOWN/inflight=0`, poisons both owners, and blocks any subsequent send.
- A transaction failure rolls back every state change; retry still requires
  supervisor evidence.
- A committed proof cannot be replayed to create a fresh owner.

The tests are a contract model, not an integration test of the R3r2 Store or
Windows Job backend. They passed with:

```powershell
python -B -m pytest -q --tb=short -p no:cacheprovider
```

Result: `9 passed` in the revised snapshot. The previous 8-pass snapshot is
preserved in `manifest-r0.json` and is superseded because independent review
found the session-generation comparison gap.

## Production blockers and boundaries

The current execution Store has `recover_claimed_ctp_dispatch_commands`, but it
requires a new CTP writer lease; after reopening, that lease cannot be obtained
because the persisted ACTIVE family owner is one-shot and only its exact
same-Store handle can use it. The helper also keys prior claims to writer
owner/token, not an OS process-exit proof. The crash repro therefore leaves the
command `CLAIMED/inflight=1`, both owner rows ACTIVE, and rejects a second owner.

The production path still needs a trusted lifecycle supervisor that owns the
worker's real process and Job handles across the crash boundary, binds its
process generation to the Store owner before SDK startup, and issues a
non-forgeable in-process capability only after process exit, Job-empty, and
control-release evidence. A caller-constructible dataclass or the current
fakeable watchdog result is not enough. The existing guardian tests exercise
fake process/Job facts and do not yet supervise this SDK/Store path.

Even after a verified crash recovery writes `UNKNOWN`, future trading stays
closed. A separately reviewed reconciliation and clean handoff contract would
be needed to start a later session. That is distinct from the same-generation
POISONED finalizer, which handles a caught failure while the original Store
owner is still alive; it cannot finalize a process crash that bypasses the
finalizer.
