"""Source-only isolation guard for independent R3r3/V21 snapshot QA."""
import builtins
import ctypes
import socket
import sys

_ORIGINAL_IMPORT = builtins.__import__
_ORIGINAL_CONNECT = socket.socket.connect
_ORIGINAL_CONNECT_EX = socket.socket.connect_ex
_ORIGINAL_CREATE_CONNECTION = socket.create_connection
_ORIGINAL_GETADDRINFO = socket.getaddrinfo
_ORIGINAL_SENDTO = socket.socket.sendto
_BLOCKED_IMPORTS = (
    "bt_api_ctp", "bt_api_py", "ctp", "pyctp", "PyCTP",
    "thosttraderapi", "thostmduserapi", "_ctp",
)
_LOOPBACK = {"127.0.0.1", "::1", "localhost"}
_ORIGINAL_LOADERS = {
    name: getattr(ctypes, name)
    for name in ("CDLL", "PyDLL", "WinDLL", "OleDLL")
    if hasattr(ctypes, name)
}


def _is_blocked(name):
    return any(name == prefix or name.startswith(prefix + ".") for prefix in _BLOCKED_IMPORTS)


class _NativeImportBlocker:
    def find_spec(self, fullname, path=None, target=None):
        if _is_blocked(fullname):
            raise ModuleNotFoundError(
                "provider/native import blocked in source-only QA: " + fullname,
                name=fullname,
            )
        return None


def _guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
    if _is_blocked(name):
        raise ImportError("provider/native import blocked in source-only QA: " + name)
    return _ORIGINAL_IMPORT(name, globals, locals, fromlist, level)


def _loopback(address):
    return isinstance(address, tuple) and bool(address) and str(address[0]).lower() in _LOOPBACK


def _guarded_connect(self, address, *args, **kwargs):
    if not _loopback(address):
        raise RuntimeError("non-loopback network access blocked in source-only QA")
    return _ORIGINAL_CONNECT(self, address, *args, **kwargs)


def _guarded_connect_ex(self, address, *args, **kwargs):
    if not _loopback(address):
        raise RuntimeError("non-loopback network access blocked in source-only QA")
    return _ORIGINAL_CONNECT_EX(self, address, *args, **kwargs)


def _guarded_create_connection(address, *args, **kwargs):
    if not _loopback(address):
        raise RuntimeError("non-loopback network access blocked in source-only QA")
    return _ORIGINAL_CREATE_CONNECTION(address, *args, **kwargs)


def _guarded_getaddrinfo(host, *args, **kwargs):
    if str(host).lower() not in _LOOPBACK:
        raise RuntimeError("external DNS lookup blocked in source-only QA")
    return _ORIGINAL_GETADDRINFO(host, *args, **kwargs)


def _guarded_sendto(self, data, address, *args, **kwargs):
    if not _loopback(address):
        raise RuntimeError("non-loopback network access blocked in source-only QA")
    return _ORIGINAL_SENDTO(self, data, address, *args, **kwargs)


def _vendor_name(name):
    lowered = str(name).lower()
    return any(token in lowered for token in ("thosttraderapi", "thostmduserapi", "bt_api_ctp", "bt_api_py", "pyctp"))


def _guarded_native_load(loader, name, *args, **kwargs):
    if _vendor_name(name):
        raise OSError("CTP/provider native library loading blocked in source-only QA")
    return loader(name, *args, **kwargs)

builtins.__import__ = _guarded_import
sys.meta_path.insert(0, _NativeImportBlocker())
socket.socket.connect = _guarded_connect
socket.socket.connect_ex = _guarded_connect_ex
socket.create_connection = _guarded_create_connection
socket.getaddrinfo = _guarded_getaddrinfo
socket.socket.sendto = _guarded_sendto
for _name, _loader in _ORIGINAL_LOADERS.items():
    setattr(ctypes, _name, lambda name, *a, __loader=_loader, **kw: _guarded_native_load(__loader, name, *a, **kw))
