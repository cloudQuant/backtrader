import ctypes
import importlib
import socket

assert importlib.import_module("asyncio")
assert importlib.import_module("colorama")
for name in ("bt_api_ctp.ctp.client", "thosttraderapi", "thostmduserapi"):
    try:
        importlib.import_module(name)
    except (ImportError, ModuleNotFoundError) as exc:
        assert "blocked in source-only QA" in str(exc), (name, str(exc))
    else:
        raise AssertionError(f"unexpected provider/native import success: {name}")
try:
    ctypes.CDLL("thosttraderapi.dll")
except OSError as exc:
    assert "blocked in source-only QA" in str(exc)
else:
    raise AssertionError("native library load was not blocked")
sock = socket.socket()
try:
    try:
        sock.connect(("example.com", 443))
    except RuntimeError as exc:
        assert "blocked in source-only QA" in str(exc)
    else:
        raise AssertionError("external socket connection was not blocked")
finally:
    sock.close()
try:
    socket.getaddrinfo("example.com", 443)
except RuntimeError as exc:
    assert "DNS lookup blocked" in str(exc)
else:
    raise AssertionError("external DNS lookup was not blocked")
print("CTP/provider import/load blocked; external connect/DNS blocked; OS support libraries permitted")
