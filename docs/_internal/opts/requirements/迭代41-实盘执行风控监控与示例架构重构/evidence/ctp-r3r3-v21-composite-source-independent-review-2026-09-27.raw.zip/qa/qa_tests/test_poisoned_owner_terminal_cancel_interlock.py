from __future__ import annotations

import hashlib
from decimal import Decimal

import pytest
from test_ctp_callback_session_router import (
    _Authority,
    _active_owner,
    _lease,
    _reserve,
    _scope,
    _stage_cancel_and_complete,
)

from bt_api_execution import (
    CancelIntent,
    CancelObservation,
    CtpDispatchReceipt,
    ExecutionState,
    InvalidStateTransition,
    OrderIntent,
    ProviderObservation,
    Side,
    SqliteExecutionStore,
    WriterLeaseUnavailable,
)


@pytest.mark.unit
def test_poisoned_owner_unknown_blocks_atomic_terminal_cancel_commit(tmp_path):
    """An ambiguous CTP cancel must not be papered over by a terminal cancel fact."""
    scope = _scope()
    store = SqliteExecutionStore(tmp_path / "cancel-poison-cross-feature.sqlite3")
    lease = _lease(store, scope)
    try:
        owner = _active_owner(store, scope, lease)
        session = store._active_ctp_callback_sessions[owner.owner_intent_id]
        reservation = _reserve(
            store, scope, lease, session.session_generation_id, "cross-feature-order"
        )
        provider_order_id = "sys-" + reservation.order_ref
        order = OrderIntent.limit(
            intent_id=reservation.managed_intent_id,
            scope=scope,
            signal_id="cross-feature-signal",
            instrument="rb2710",
            side=Side.BUY,
            quantity=Decimal("1"),
            price=Decimal("100"),
            metadata_version="meta.1",
        )
        store.admit_intent(order, writer_lease=lease)
        store.activate_intent(order.intent_id, scope, writer_lease=lease)
        _record, claimed = store.claim_for_dispatch(order.intent_id, scope, writer_lease=lease)
        assert claimed is True
        store.record_observation(
            ProviderObservation.accepted(order.intent_id, provider_order_id),
            scope=scope,
            writer_lease=lease,
        )

        command_id = "cross-feature-cancel-command"
        staged = _stage_cancel_and_complete(
            store, scope, lease, owner, reservation, command_id, 919, claim=False
        )
        assert staged.status == "READY"
        queue_receipt_id = hashlib.sha256(command_id.encode("ascii")).hexdigest()[:32]
        claim = store.claim_ctp_dispatch_command_for_session(
            scope,
            command_id,
            owner_handle=owner,
            writer_lease=lease,
            authority_verifier=_Authority(),
            required_local_queue_receipt_id=queue_receipt_id,
        )
        assert claim is not None and claim.command.status == "CLAIMED"
        command = claim.command
        assert command.operation == "CANCEL"
        unknown_receipt = CtpDispatchReceipt(
            receipt_type="ctp_dispatch_receipt.v2",
            command_id=command.command_id,
            account_key=command.account_key,
            scope_key=command.scope_key,
            trading_day=command.trading_day,
            operation=command.operation,
            request_payload_sha256=command.request_payload_sha256,
            reservation_managed_intent_id=command.reservation_managed_intent_id,
            order_ref=command.order_ref,
            cancel_target_order_ref=command.cancel_target_order_ref,
            cancel_target_exchange_id=command.cancel_target_exchange_id,
            cancel_target_order_sys_id=command.cancel_target_order_sys_id,
            cancel_target_front_id=command.cancel_target_front_id,
            cancel_target_session_id=command.cancel_target_session_id,
            approval_use_id=command.approval_use_id,
            approval_digest=command.approval_digest,
            session_binding_sha256=command.session_binding_sha256,
            outcome="UNKNOWN",
            native_receipt_payload={"request_id": 919, "dispatch_state": "ambiguous"},
            correlation_key=command.correlation_key,
            local_queue_receipt_id=command.local_queue_receipt_id,
        )

        cancel = CancelIntent(
            cancel_id="cross-feature-cancel",
            scope=scope,
            target_intent_id=order.intent_id,
            provider_order_id=provider_order_id,
            metadata_version="meta.1",
        )
        store.admit_cancel(cancel, writer_lease=lease)
        store.activate_cancel(cancel.cancel_id, scope, "permit.cross-feature", writer_lease=lease)
        _cancel_record, cancel_claimed = store.claim_cancel_for_dispatch(
            cancel.cancel_id, scope, writer_lease=lease
        )
        assert cancel_claimed is True

        poisoned = store.poison_ctp_callback_session_owner(owner, "owner_binding_mismatch")
        assert poisoned.durable_state == "POISONED"
        final = store.complete_poisoned_ctp_dispatch_unknown_for_session(
            scope, unknown_receipt, owner_handle=owner, writer_lease=lease
        )
        assert final.status == "UNKNOWN"
        assert store.read_ctp_dispatch_command(scope, command.command_id).status == "UNKNOWN"

        before_record = store.get(order.intent_id, scope=scope)
        before_cancel = store.get_cancel(cancel.cancel_id, scope=scope)
        before_outbox = store.read_cancel_outbox(scope=scope)
        assert before_record.state is ExecutionState.ACKED
        assert before_cancel.state is ExecutionState.DISPATCHING

        with pytest.raises((WriterLeaseUnavailable, InvalidStateTransition)):
            store.record_cancel_observation_with_commit(
                CancelObservation.cancelled(
                    cancel.cancel_id, order.intent_id, provider_order_id
                ),
                scope=scope,
                writer_lease=lease,
            )

        assert store.get(order.intent_id, scope=scope) == before_record
        assert store.get_cancel(cancel.cancel_id, scope=scope) == before_cancel
        assert store.read_cancel_outbox(scope=scope) == before_outbox
        assert store.read_ctp_dispatch_command(scope, command.command_id).status == "UNKNOWN"
    finally:
        store.close()
