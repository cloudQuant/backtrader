from dataclasses import replace
import sys
from pathlib import Path
SNAPSHOT = Path(r"D:\temp\iteration41_v17_execution_review_20260926")
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import ContractValidationError, ExecutionScope, SqliteExecutionStore
from test_ctp_dispatch_commands import _lease, _prepare_v17_cancel

path = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926\allocator_type_semantics.sqlite3")
if path.exists():
    path.unlink()
scope = ExecutionScope("CTP", "simulation", "acct-type-check", "strategy.type", "20260925")
store = SqliteExecutionStore(path)
lease = _lease(store, scope)
_, args = _prepare_v17_cancel(store, scope, lease, "same-number", session_generation_id="type-generation")
args["native_request_id"] = 1
command = store.stage_ctp_dispatch_command(**args)
key = command.correlation_key
assert type(key.native_request_id) is int and key.native_request_id == 1
assert type(key.native_action_ref) is int and key.native_action_ref == 1
rejected = {}
for field, value in (("native_action_ref", True), ("native_action_ref", "1"), ("native_action_ref", 2_147_483_648)):
    try:
        replace(key, **{field: value})
    except ContractValidationError:
        rejected[f"{field}={value!r}"] = True
    else:
        raise AssertionError(f"correlation accepted invalid ActionRef {value!r}")
print({"request_id_and_action_ref_can_numerically_coincide": True, "rejected": rejected})
store.close()
