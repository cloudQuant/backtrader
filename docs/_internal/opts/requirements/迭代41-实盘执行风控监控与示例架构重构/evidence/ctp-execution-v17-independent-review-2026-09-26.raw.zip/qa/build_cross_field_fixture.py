from __future__ import annotations
import hashlib, json, shutil, sqlite3
from pathlib import Path
root=Path(r'D:\temp\iteration41_v17_migration_fixtures_20260926')
source=root/'v16_terminal_ready_claimed.sqlite3'
baseline=root/'v16_cross_field_identity_valid_baseline.sqlite3'
corrupt=root/'v16_cross_field_account_scope_mismatch.sqlite3'
for p in (baseline,corrupt):
    for suffix in ('','-wal','-shm'):
        q=Path(str(p)+suffix)
        if q.exists(): q.unlink()
shutil.copyfile(source,baseline)
def query_fk(p):
    c=sqlite3.connect(p)
    try:
        return [tuple(r) for r in c.execute('PRAGMA foreign_key_check').fetchall()]
    finally: c.close()
pre_source_fk=query_fk(baseline)
assert pre_source_fk==[], pre_source_fk
c=sqlite3.connect(baseline)
try:
    c.execute('PRAGMA foreign_keys=OFF')
    triggers=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='ctp_dispatch_commands'").fetchall()]
    for name in triggers: c.execute('DROP TRIGGER "'+name.replace('"','""')+'"')
    target=c.execute("SELECT command_id,account_key,scope_key,correlation_version FROM ctp_dispatch_commands WHERE command_id='fixture-terminal-cancel'").fetchone()
    assert target and target[3]==1, target
    columns={r[1] for r in c.execute("PRAGMA table_info(ctp_dispatch_commands)").fetchall()}
    values={"correlation_version":0,"runtime_order_id":None,"managed_action_id":None,"session_generation_id":None,"dispatch_front_id":None,"dispatch_session_id":None,"native_request_id":None,"native_action_ref":None,"native_request_payload_json":None,"native_request_payload_sha256":None,"local_queue_receipt_id":None,"local_queue_receipt_queued":None}
    values={k:v for k,v in values.items() if k in columns}
    assignments=", ".join(f"{key}=?" for key in values)
    c.execute(f"UPDATE ctp_dispatch_commands SET {assignments} WHERE command_id=?",(*values.values(),target[0]))
    c.commit()
finally: c.close()
baseline_fk=query_fk(baseline)
assert baseline_fk==[], baseline_fk
# This is now a canonical, integrity-valid legacy V16 row; change exactly one key field.
shutil.copyfile(baseline,corrupt)
replacement='account:'+hashlib.sha256(b'synthetic-other-account').hexdigest()
c=sqlite3.connect(corrupt)
try:
    c.execute('PRAGMA foreign_keys=OFF')
    c.execute("UPDATE ctp_dispatch_commands SET account_key=? WHERE command_id='fixture-terminal-cancel'",(replacement,))
    c.commit()
finally: c.close()
corrupt_fk=query_fk(corrupt)
assert len(corrupt_fk)==3, corrupt_fk
with sqlite3.connect(baseline) as c:
    validrow=tuple(c.execute("SELECT account_key,scope_key,command_id,correlation_version FROM ctp_dispatch_commands WHERE command_id='fixture-terminal-cancel'").fetchone())
with sqlite3.connect(corrupt) as c:
    badrow=tuple(c.execute("SELECT account_key,scope_key,command_id,correlation_version FROM ctp_dispatch_commands WHERE command_id='fixture-terminal-cancel'").fetchone())
files=[]
for p in (baseline,corrupt):
    files.append({'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'wal_exists':Path(str(p)+'-wal').exists(),'shm_exists':Path(str(p)+'-shm').exists()})
manifest={'kind':'synthetic-v16-cross-field-account-scope-migration-fixture','source_fixture':source.name,'source_fixture_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'schema_version':16,'no_provider_native_network_or_private_config':True,'valid_baseline_foreign_key_check':baseline_fk,'corrupt_only_field_changed_after_baseline':'ctp_dispatch_commands.account_key','replacement_account_key':replacement,'baseline_row':validrow,'corrupt_row':badrow,'valid_baseline_foreign_key_violation_count':len(baseline_fk),'corrupt_foreign_key_violation_count':len(corrupt_fk),'corrupt_foreign_key_violations':corrupt_fk,'files':files}
mp=root/'cross_field_fixture_manifest.json'
mp.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'manifest':mp.name,'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),**manifest},sort_keys=True,indent=2))
