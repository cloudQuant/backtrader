import json, shutil, sqlite3, sys
from pathlib import Path

SNAPSHOT = Path(r"D:\temp\iteration41_v17_execution_review_20260926")
FIXTURES = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926")
RUNS = FIXTURES / "v17_migration_runs"
RUNS.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import (
    ContractValidationError, DurableStoreError, ExecutionScope,
    InvalidStateTransition, SqliteExecutionStore,
)
from test_ctp_dispatch_commands import (
    _FakeCtpDispatchAuthorityVerifier, _lease, _scope,
)

def raw_rows(path, command_ids):
    with sqlite3.connect(path) as con:
        con.row_factory = sqlite3.Row
        columns = {row[1] for row in con.execute("PRAGMA table_info(ctp_dispatch_commands)")}
        native_int = "native_action_ref_int" if "native_action_ref_int" in columns else "NULL AS native_action_ref_int"
        return {
            command_id: dict(con.execute(
                "SELECT account_key, command_id, operation, status, correlation_version, "
                "native_action_ref, request_payload_json, request_payload_sha256, "
                + native_int + " FROM ctp_dispatch_commands WHERE command_id = ?",
                (command_id,),
            ).fetchone())
            for command_id in command_ids
        }

def clone(name):
    source = FIXTURES / name
    target = RUNS / name.replace(".sqlite3", "_migrated.sqlite3")
    if target.exists():
        target.unlink()
    shutil.copyfile(source, target)
    return target

results = {}
path = clone("v16_terminal_ready_claimed.sqlite3")
ids = ["fixture-terminal-cancel", "fixture-ready-submit", "fixture-claimed-submit"]
before = raw_rows(path, ids)
store = SqliteExecutionStore(path)
scope = _scope()
try:
    version = store._connection.execute(
        "SELECT value FROM execution_meta WHERE key='schema_version'"
    ).fetchone()[0]
    after = raw_rows(path, ids)
    fence_rows = store._connection.execute(
        "SELECT account_key, command_id, scope_key, correlation_key_sha256, session_binding_sha256 "
        "FROM ctp_dispatch_callback_source_lifecycle_fences WHERE account_key=?",
        (scope.account_key,),
    ).fetchall()
    assert version == "17"
    assert len(fence_rows) == 1
    old_cancel = before["fixture-terminal-cancel"]
    new_cancel = after["fixture-terminal-cancel"]
    for key in ("native_action_ref", "request_payload_json", "request_payload_sha256", "correlation_version"):
        assert new_cancel[key] == old_cancel[key], (key, old_cancel[key], new_cancel[key])
    assert new_cancel["status"] == "COMPLETED" and new_cancel["native_action_ref_int"] is None
    for command_id in ("fixture-ready-submit", "fixture-claimed-submit"):
        assert after[command_id]["status"] == "UNKNOWN"
        assert after[command_id]["request_payload_json"] == before[command_id]["request_payload_json"]
        assert after[command_id]["request_payload_sha256"] == before[command_id]["request_payload_sha256"]
        assert after[command_id]["native_action_ref"] is None
        assert after[command_id]["native_action_ref_int"] is None
    lease = _lease(store, scope)
    verifier = _FakeCtpDispatchAuthorityVerifier()
    for command_id in ("fixture-ready-submit", "fixture-claimed-submit"):
        assert store.claim_ctp_dispatch_command(
            scope, command_id, writer_lease=lease, authority_verifier=verifier
        ) is None
    assert verifier.calls == []
    try:
        store.create_ctp_callback_session_owner(scope, writer_lease=lease)
    except InvalidStateTransition:
        pass
    else:
        raise AssertionError("legacy-cancel account fence did not block a new session owner")
    results["terminal_ready_claimed"] = {
        "version": version,
        "legacy_cancel_preserved": True,
        "pending_submits_unknown": True,
        "fence_count": len(fence_rows),
        "legacy_claims_return_none_without_verifier": True,
        "account_owner_blocked": True,
    }
finally:
    store.close()

path = clone("v16_cross_scope_day.sqlite3")
ids = ["fixture-cross-terminal", "fixture-cross-ready"]
before = raw_rows(path, ids)
store = SqliteExecutionStore(path)
try:
    after = raw_rows(path, ids)
    account = before["fixture-cross-terminal"]["account_key"]
    fences = store._connection.execute(
        "SELECT command_id, scope_key FROM ctp_dispatch_callback_source_lifecycle_fences "
        "WHERE account_key=? ORDER BY command_id",
        (account,),
    ).fetchall()
    assert len(fences) == 1
    assert after["fixture-cross-terminal"]["status"] == "COMPLETED"
    assert after["fixture-cross-ready"]["status"] == "UNKNOWN"
    for command_id in ids:
        assert after[command_id]["native_action_ref"] == before[command_id]["native_action_ref"]
        assert after[command_id]["request_payload_json"] == before[command_id]["request_payload_json"]
        assert after[command_id]["request_payload_sha256"] == before[command_id]["request_payload_sha256"]
    second_scope = ExecutionScope("CTP", "simulation", "acct-outbox", "strategy.other", "20260926")
    lease = _lease(store, second_scope)
    try:
        store.create_ctp_callback_session_owner(second_scope, writer_lease=lease)
    except InvalidStateTransition:
        pass
    else:
        raise AssertionError("legacy cancel fence did not cover another same-account scope/day")
    results["cross_scope_day"] = {
        "same_account": True,
        "account_wide_fence_rows": len(fences),
        "terminal_preserved": True,
        "ready_becomes_unknown": True,
        "fence_crosses_scope_day": True,
    }
finally:
    store.close()

path = clone("v16_unknown_cancel.sqlite3")
before = raw_rows(path, ["fixture-unknown-cancel"])["fixture-unknown-cancel"]
store = SqliteExecutionStore(path)
try:
    after = raw_rows(path, ["fixture-unknown-cancel"])["fixture-unknown-cancel"]
    assert after["status"] == "UNKNOWN"
    assert after["native_action_ref"] == before["native_action_ref"]
    assert after["request_payload_json"] == before["request_payload_json"]
    assert after["request_payload_sha256"] == before["request_payload_sha256"]
    assert after["native_action_ref_int"] is None
    assert store._connection.execute(
        "SELECT COUNT(*) FROM ctp_dispatch_callback_source_lifecycle_fences WHERE account_key=?",
        (before["account_key"],),
    ).fetchone()[0] == 1
    results["unknown_cancel"] = {"unknown_preserved": True, "text_ref_preserved": True, "fenced": True}
finally:
    store.close()

path = clone("v16_missing_account_key.sqlite3")
try:
    store = SqliteExecutionStore(path)
except DurableStoreError as error:
    message = str(error)
    assert "legacy CTP cancel account identity is unreadable" in message
    with sqlite3.connect(path) as con:
        version = con.execute(
            "SELECT value FROM execution_meta WHERE key='schema_version'"
        ).fetchone()[0]
        account = con.execute(
            "SELECT account_key FROM ctp_dispatch_commands WHERE command_id=?",
            ("fixture-unknown-account-cancel",),
        ).fetchone()[0]
        assert version == "16" and account == ""
    results["missing_account_key"] = {
        "migration_rejected": True,
        "message": message,
        "version_rollback": True,
        "malformed_history_preserved": True,
    }
else:
    store.close()
    raise AssertionError("V17 migration accepted blank historical account identity")

print(json.dumps(results, sort_keys=True, indent=2))


