import json, shutil, sqlite3, sys
from pathlib import Path
SNAPSHOT = Path(r"D:\temp\iteration41_v17_execution_review_20260926")
FIXTURES = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926")
source = FIXTURES / "v16_missing_terminal_submit_account_key.sqlite3"
path = FIXTURES / "v17_missing_terminal_submit_account_key_migrated.sqlite3"
if path.exists():
    path.unlink()
shutil.copyfile(source, path)
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import SqliteExecutionStore
from test_ctp_dispatch_commands import _lease, _prepare_v17_cancel, _scope

before = None
with sqlite3.connect(path) as con:
    before = tuple(con.execute(
        "SELECT account_key, status, request_payload_json, request_payload_sha256 "
        "FROM ctp_dispatch_commands WHERE command_id=?",
        ("fixture-terminal-submit-missing-account",),
    ).fetchone())
store = SqliteExecutionStore(path)
scope = _scope()
try:
    version = store._connection.execute(
        "SELECT value FROM execution_meta WHERE key='schema_version'"
    ).fetchone()[0]
    old_after = tuple(store._connection.execute(
        "SELECT account_key, status, request_payload_json, request_payload_sha256 "
        "FROM ctp_dispatch_commands WHERE command_id=?",
        ("fixture-terminal-submit-missing-account",),
    ).fetchone())
    fence_count = store._connection.execute(
        "SELECT COUNT(*) FROM ctp_dispatch_callback_source_lifecycle_fences"
    ).fetchone()[0]
    lease = _lease(store, scope)
    _reservation, args = _prepare_v17_cancel(
        store, scope, lease, "newacct",
        session_generation_id="new-session-generation",
    )
    command = store.stage_ctp_dispatch_command(**args)
    print(json.dumps({
        "schema_version": version,
        "old_malformed_submit_preserved": old_after == before,
        "source_fence_count_before_new_stage": fence_count,
        "new_cancel_staged": command.status == "READY",
        "new_native_action_ref": command.correlation_key.native_action_ref,
        "old_command_account_key": old_after[0],
        "candidate_behavior": "migration permits v2 staging despite malformed terminal submit account key",
    }, sort_keys=True, indent=2))
finally:
    store.close()

