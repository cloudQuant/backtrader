from __future__ import annotations
import hashlib, json, shutil, sqlite3, sys
from pathlib import Path
root = Path(r'D:\temp\iteration41_v17_migration_fixtures_20260926')
snapshot = Path(r'D:\temp\iteration41_v17_execution_review_20260926_r4_cancel_fk_regression')
sys.path.insert(0, str(snapshot / 'src'))
from bt_api_execution import DurableStoreError, SqliteExecutionStore
cases = [
    ('cross_field', 'v16_cross_field_account_scope_mismatch.sqlite3', 'historical CTP foreign key integrity is inconsistent'),
    ('missing_submit', 'v16_missing_terminal_submit_account_key.sqlite3', 'historical CTP dispatch account identity is unreadable'),
]
results = []
for label, source_name, expected in cases:
    source = root / source_name
    dest = root / f'v17_{label}_identity_r4.sqlite3'
    for suffix in ('', '-wal', '-shm'):
        p = Path(str(dest) + suffix)
        if p.exists():
            p.unlink()
    shutil.copyfile(source, dest)
    with sqlite3.connect(dest) as db:
        before_version = db.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
        before_rows = [tuple(r) for r in db.execute('SELECT account_key,scope_key,command_id,operation,status FROM ctp_dispatch_commands ORDER BY command_id').fetchall()]
        before_fk = [tuple(r) for r in db.execute('PRAGMA foreign_key_check').fetchall()]
    try:
        SqliteExecutionStore(dest)
        outcome = {'opened': True}
    except DurableStoreError as exc:
        outcome = {'opened': False, 'exception': type(exc).__name__ + ': ' + str(exc)}
    with sqlite3.connect(dest) as db:
        after_version = db.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
        after_rows = [tuple(r) for r in db.execute('SELECT account_key,scope_key,command_id,operation,status FROM ctp_dispatch_commands ORDER BY command_id').fetchall()]
        after_fk = [tuple(r) for r in db.execute('PRAGMA foreign_key_check').fetchall()]
    assert not outcome['opened'] and expected in outcome['exception'], (label, outcome)
    assert before_version == after_version == '16', (label, before_version, after_version)
    assert before_rows == after_rows, (label, before_rows, after_rows)
    assert before_fk == after_fk, (label, before_fk, after_fk)
    results.append({
        'case': label,
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'tested_db': dest.name,
        'tested_db_sha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
        'expected_error': expected,
        'outcome': outcome,
        'schema_version_before_after': [before_version, after_version],
        'command_rows_preserved': True,
        'foreign_key_violations_before_after': [len(before_fk), len(after_fk)],
        'result': 'PASS',
    })
result = {'snapshot_manifest_sha256': 'be9415becf2a6a3fe32e667aae5437322d3b311c82db75f931c5ff8fe15cc0c1', 'results': results}
out = root / 'r4_identity_migration_retest.json'
out.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, sort_keys=True, indent=2))
