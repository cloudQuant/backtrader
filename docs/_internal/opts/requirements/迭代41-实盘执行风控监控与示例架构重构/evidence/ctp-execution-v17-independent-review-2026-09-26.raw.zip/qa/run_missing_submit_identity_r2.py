from __future__ import annotations
import hashlib, json, shutil, sqlite3, sys
from pathlib import Path
root = Path(r'D:\temp\iteration41_v17_migration_fixtures_20260926')
snapshot = Path(r'D:\temp\iteration41_v17_execution_review_20260926_r2_cancel_and_identity')
source = root / 'v16_missing_terminal_submit_account_key.sqlite3'
dest = root / 'v17_missing_terminal_submit_account_key_r2.sqlite3'
if dest.exists(): dest.unlink()
shutil.copyfile(source, dest)
sys.path.insert(0, str(snapshot / 'src'))
from bt_api_execution import DurableStoreError, SqliteExecutionStore
with sqlite3.connect(dest) as db:
    before_version = db.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
    before_row = tuple(db.execute("SELECT account_key,status,request_payload_json,request_payload_sha256 FROM ctp_dispatch_commands WHERE command_id=?", ('fixture-terminal-submit-missing-account',)).fetchone())
    before_count = db.execute('SELECT COUNT(*) FROM ctp_dispatch_commands').fetchone()[0]
try:
    SqliteExecutionStore(dest)
    outcome = 'unexpected-open-success'
except DurableStoreError as exc:
    outcome = type(exc).__name__ + ': ' + str(exc)
with sqlite3.connect(dest) as db:
    after_version = db.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
    after_row = tuple(db.execute("SELECT account_key,status,request_payload_json,request_payload_sha256 FROM ctp_dispatch_commands WHERE command_id=?", ('fixture-terminal-submit-missing-account',)).fetchone())
    after_count = db.execute('SELECT COUNT(*) FROM ctp_dispatch_commands').fetchone()[0]
assert outcome.startswith('DurableStoreError: historical CTP dispatch account identity is unreadable'), outcome
assert before_version == after_version == '16', (before_version, after_version)
assert before_row == after_row and before_count == after_count, (before_row, after_row)
result = {'source_fixture_sha256':hashlib.sha256(source.read_bytes()).hexdigest(), 'tested_db':dest.name, 'tested_db_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(), 'outcome':outcome, 'schema_version_before_after':[before_version, after_version], 'row_preserved':before_row == after_row, 'dispatch_count_before_after':[before_count,after_count], 'result':'PASS'}
(root / 'r2_missing_submit_identity_retest.json').write_text(json.dumps(result, sort_keys=True, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, sort_keys=True, indent=2))
