from __future__ import annotations
import hashlib,json,sqlite3
from pathlib import Path
root=Path(r'D:\temp\iteration41_v17_migration_fixtures_20260926')
files=[]
for name in ('v16_cross_field_identity_valid_baseline.sqlite3','v16_cross_field_account_scope_mismatch.sqlite3'):
 p=root/name
 assert not Path(str(p)+'-wal').exists() and not Path(str(p)+'-shm').exists(), name
 c=sqlite3.connect(p)
 try:
  fk=[tuple(r) for r in c.execute('PRAGMA foreign_key_check').fetchall()]
  version=c.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()[0]
  row=tuple(c.execute("SELECT account_key,scope_key,command_id,correlation_version FROM ctp_dispatch_commands WHERE command_id='fixture-terminal-cancel'").fetchone())
 finally:c.close()
 if name.endswith('baseline.sqlite3'): assert not fk and version=='16'
 else: assert len(fk)==3 and version=='16'
 files.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'schema_version':version,'foreign_key_violation_count':len(fk),'command_row':row,'sidecars_absent':True})
manifest={'kind':'synthetic-v16-cross-field-account-scope-migration-fixture','source_fixture':'v16_terminal_ready_claimed.sqlite3','source_fixture_sha256':'fb69cd1682928bb770fa23c97aa2ecf2a9e79b761cac9103310b0e76609fdc1c','schema_version':16,'no_provider_native_network_or_private_config':True,'valid_baseline_foreign_key_violation_count':0,'corrupt_only_field_changed_after_baseline':'ctp_dispatch_commands.account_key','corrupt_foreign_key_violation_count':3,'files':files}
p=root/'cross_field_fixture_manifest.json'
p.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'manifest':p.name,'manifest_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**manifest},sort_keys=True,indent=2))
