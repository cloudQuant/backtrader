from __future__ import annotations
import multiprocessing as mp
import sys
from pathlib import Path

SNAPSHOT = Path(r"D:\temp\iteration41_v17_execution_review_20260926")
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import ExecutionScope, SqliteExecutionStore
from test_ctp_dispatch_commands import _lease, _prepare_v17_cancel

DB = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926\allocator_process_race.sqlite3")

def worker(path, account_ref, lease, worker_tag, barrier, queue):
    try:
        scope = ExecutionScope("CTP", "simulation", account_ref, "strategy.concurrent", "20260925")
        store = SqliteExecutionStore(path)
        try:
            _, arguments = _prepare_v17_cancel(
                store, scope, lease, worker_tag,
                session_generation_id="allocator-race-generation",
            )
            barrier.wait(timeout=12)
            command = store.stage_ctp_dispatch_command(**arguments)
            queue.put(("ok", account_ref, worker_tag, command.correlation_key.native_action_ref))
        finally:
            store.close()
    except BaseException as error:
        queue.put(("error", account_ref, worker_tag, type(error).__name__, str(error)))

def run_group(account_refs, group_name):
    ctx = mp.get_context("spawn")
    barrier = ctx.Barrier(len(account_refs))
    queue = ctx.Queue()
    procs = []
    for index, account_ref in enumerate(account_refs):
        lease = lease_by_account[account_ref]
        proc = ctx.Process(
            target=worker,
            args=(str(DB), account_ref, lease, f"{group_name}-{index}", barrier, queue),
        )
        proc.start()
        procs.append(proc)
    results = [queue.get(timeout=30) for _ in procs]
    for proc in procs:
        proc.join(timeout=20)
        if proc.is_alive():
            proc.terminate()
            proc.join(timeout=5)
            raise RuntimeError("allocator worker timed out")
        if proc.exitcode != 0:
            raise RuntimeError(f"allocator worker exited {proc.exitcode}")
    failures = [item for item in results if item[0] != "ok"]
    if failures:
        raise AssertionError(failures)
    return results

def main():
    if DB.exists():
        DB.unlink()
    store = SqliteExecutionStore(DB)
    scopes = {
        ref: ExecutionScope("CTP", "simulation", ref, "strategy.concurrent", "20260925")
        for ref in ("acct-concurrent-A", "acct-concurrent-B")
    }
    global lease_by_account
    lease_by_account = {
        ref: _lease(store, scope, owner="allocator-multiprocess-owner-" + ref)
        for ref, scope in scopes.items()
    }
    store.close()

    same_account = run_group(["acct-concurrent-A", "acct-concurrent-A"], "same")
    cross_account = run_group(["acct-concurrent-A", "acct-concurrent-B"], "cross")
    store = SqliteExecutionStore(DB)
    try:
        rows = store._connection.execute(
            "SELECT account_key, native_action_ref_int, command_id, native_request_id "
            "FROM ctp_dispatch_commands WHERE operation='CANCEL' AND correlation_version=2 "
            "ORDER BY account_key, native_action_ref_int"
        ).fetchall()
        by_account = {}
        for row in rows:
            by_account.setdefault(str(row["account_key"]), []).append(int(row["native_action_ref_int"]))
        assert sorted(by_account[scopes["acct-concurrent-A"].account_key]) == [1, 2, 3]
        assert by_account[scopes["acct-concurrent-B"].account_key] == [1]
        request_ids = [int(row["native_request_id"]) for row in rows]
        assert len(request_ids) == len(set(request_ids))
    finally:
        store.close()
    print({
        "same_account_two_processes": same_account,
        "cross_account_two_processes": cross_account,
        "refs_by_account": by_account,
        "result": "PASS",
    })

if __name__ == "__main__":
    main()
