from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

SNAPSHOT = Path(r"C:\Users\yunji\AppData\Local\Temp\bt_api_execution_g5_v16_callback_matrix_20260926_219pass")
OUT = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926")
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import ExecutionScope, SqliteExecutionStore
from test_ctp_dispatch_commands import (
    _authority_verifier, _dispatch_fake, _lease, _reserve_seeded,
    _scope, _stage_cancel, _stage_submit,
)

def finish(store):
    store._connection.close()

def create_mixed(path: Path):
    scope = _scope()
    store = SqliteExecutionStore(path)
    lease = _lease(store, scope)
    r_cancel = _reserve_seeded(store, scope, lease, "fixture-cancel-terminal")
    cancel = _stage_cancel(store, scope, lease, r_cancel, "fixture-terminal-cancel")
    _dispatch_fake(store, scope, lease, cancel, outcome="QUEUED")
    r_ready = _reserve_seeded(store, scope, lease, "fixture-submit-ready")
    _stage_submit(store, scope, lease, r_ready, "fixture-ready-submit", approval_use_id="fixture-ready-approval")
    r_claimed = _reserve_seeded(store, scope, lease, "fixture-submit-claimed")
    claimed_ready = _stage_submit(store, scope, lease, r_claimed, "fixture-claimed-submit", approval_use_id="fixture-claimed-approval")
    claimed = store.claim_ctp_dispatch_command(
        scope, claimed_ready.command_id, writer_lease=lease,
        authority_verifier=_authority_verifier(),
    )
    assert claimed is not None and claimed.status == "CLAIMED"
    rows = store._connection.execute(
        "SELECT command_id, operation, status, account_key, scope_key, trading_day, "
        "native_action_ref, request_payload_json, request_payload_sha256 "
        "FROM ctp_dispatch_commands ORDER BY command_id"
    ).fetchall()
    result = [dict(row) for row in rows]
    expected = {
        "fixture-terminal-cancel": "COMPLETED",
        "fixture-ready-submit": "READY",
        "fixture-claimed-submit": "CLAIMED",
    }
    assert all(next(row["status"] for row in result if row["command_id"] == k) == v for k, v in expected.items())
    finish(store)
    return result

def create_cross_scope(path: Path):
    scope = _scope()
    store = SqliteExecutionStore(path)
    lease = _lease(store, scope)
    r_cancel = _reserve_seeded(store, scope, lease, "fixture-cross-terminal-cancel")
    cancel = _stage_cancel(store, scope, lease, r_cancel, "fixture-cross-terminal")
    _dispatch_fake(store, scope, lease, cancel, outcome="QUEUED")
    other_scope = ExecutionScope("CTP", "simulation", "acct-outbox", "strategy.other", "20260926")
    other_lease = _lease(store, other_scope)
    r_other = _reserve_seeded(
        store, other_scope, other_lease, "fixture-cross-ready-cancel",
        session_generation_id="test-session-generation-2",
    )
    other_cancel = _stage_cancel(store, other_scope, other_lease, r_other, "fixture-cross-ready")
    assert other_cancel.status == "READY"
    rows = store._connection.execute(
        "SELECT command_id, operation, status, account_key, scope_key, trading_day, "
        "native_action_ref, request_payload_json, request_payload_sha256 "
        "FROM ctp_dispatch_commands ORDER BY command_id"
    ).fetchall()
    result = [dict(row) for row in rows]
    assert len({row["account_key"] for row in result}) == 1
    assert len({row["scope_key"] for row in result}) == 2
    assert len({row["trading_day"] for row in result}) == 2
    finish(store)
    return result

def create_unknown(path: Path):
    scope = _scope()
    store = SqliteExecutionStore(path)
    lease = _lease(store, scope)
    r = _reserve_seeded(store, scope, lease, "fixture-unknown-cancel-target")
    cancel = _stage_cancel(store, scope, lease, r, "fixture-unknown-cancel")
    unknown = _dispatch_fake(store, scope, lease, cancel, outcome="UNKNOWN")
    assert unknown.status == "UNKNOWN"
    row = store._connection.execute(
        "SELECT command_id, operation, status, account_key, scope_key, trading_day, "
        "native_action_ref, request_payload_json, request_payload_sha256 "
        "FROM ctp_dispatch_commands WHERE command_id = ?",
        ("fixture-unknown-cancel",),
    ).fetchone()
    finish(store)
    return dict(row)

def create_unknown_account(path: Path):
    scope = _scope()
    store = SqliteExecutionStore(path)
    lease = _lease(store, scope)
    r = _reserve_seeded(store, scope, lease, "fixture-unknown-account")
    cmd = _stage_cancel(store, scope, lease, r, "fixture-unknown-account-cancel")
    _dispatch_fake(store, scope, lease, cmd, outcome="QUEUED")
    conn = store._connection
    conn.execute("PRAGMA foreign_keys=OFF")
    triggers = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='ctp_dispatch_commands'"
    ).fetchall()
    for (name,) in triggers:
        conn.execute('DROP TRIGGER "' + str(name).replace('"', '""') + '"')
    conn.execute(
        "UPDATE ctp_dispatch_commands SET account_key = '', correlation_version = 0 "
        "WHERE command_id = ?",
        ("fixture-unknown-account-cancel",),
    )
    conn.commit()
    row = conn.execute(
        "SELECT account_key, correlation_version, operation, status, request_payload_json, "
        "request_payload_sha256 FROM ctp_dispatch_commands WHERE command_id = ?",
        ("fixture-unknown-account-cancel",),
    ).fetchone()
    finish(store)
    return dict(row)

def file_hash(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

OUT.mkdir(parents=True, exist_ok=True)
files = [
    OUT / "v16_terminal_ready_claimed.sqlite3",
    OUT / "v16_cross_scope_day.sqlite3",
    OUT / "v16_unknown_cancel.sqlite3",
    OUT / "v16_missing_account_key.sqlite3",
]
for item in files:
    if item.exists():
        item.unlink()
rows_mixed = create_mixed(files[0])
rows_cross = create_cross_scope(files[1])
row_unknown = create_unknown(files[2])
row_unknown_account = create_unknown_account(files[3])
manifest = {
    "fixture_kind": "synthetic-local-v16-migration-only",
    "source_snapshot": str(SNAPSHOT),
    "source_manifest_sha256": file_hash(SNAPSHOT / "snapshot_manifest.json"),
    "source_head": "6aa4d7c3dd05aeb635e85191e75afb9e660dd618",
    "database_schema_version": 16,
    "no_provider_native_network_or_private_config": True,
    "files": [{"path": p.name, "sha256": file_hash(p), "bytes": p.stat().st_size} for p in files],
    "terminal_ready_claimed_rows": rows_mixed,
    "cross_scope_day_rows": rows_cross,
    "unknown_row": row_unknown,
    "missing_account_key_row": row_unknown_account,
    "expected_review": {
        "legacy_cancel_accounts_fenced_even_if_terminal_or_unknown": True,
        "ready_and_claimed_legacy_submits_become_unknown_and_unclaimable": True,
        "cross_scope_day_same_account_fence": True,
        "blank_legacy_account_key": "migration must reject or fail closed globally; never fence only the blank pseudo-account",
    },
}
manifest_path = OUT / "fixture_manifest.json"
manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps({
    "manifest": str(manifest_path),
    "manifest_sha256": file_hash(manifest_path),
    "files": manifest["files"],
    "mixed_statuses": [(r["command_id"], r["status"]) for r in rows_mixed],
    "cross_statuses": [(r["command_id"], r["status"]) for r in rows_cross],
    "unknown": row_unknown["status"],
    "blank_account": row_unknown_account["account_key"],
}, sort_keys=True, indent=2))
