import hashlib, json, sys
from pathlib import Path
SNAPSHOT = Path(r"C:\Users\yunji\AppData\Local\Temp\bt_api_execution_g5_v16_callback_matrix_20260926_219pass")
OUT = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926")
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import SqliteExecutionStore
from test_ctp_dispatch_commands import _dispatch_fake, _lease, _reserve_seeded, _scope, _stage_submit

path = OUT / "v16_missing_terminal_submit_account_key.sqlite3"
if path.exists():
    path.unlink()
scope = _scope()
store = SqliteExecutionStore(path)
lease = _lease(store, scope)
reservation = _reserve_seeded(store, scope, lease, "fixture-terminal-submit-only")
command = _stage_submit(
    store, scope, lease, reservation,
    command_id="fixture-terminal-submit-missing-account",
    approval_use_id="fixture-terminal-submit-missing-account-approval",
)
completed = _dispatch_fake(store, scope, lease, command, outcome="QUEUED")
assert completed.status == "COMPLETED"
con = store._connection
con.execute("PRAGMA foreign_keys=OFF")
for (name,) in con.execute(
    "SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='ctp_dispatch_commands'"
).fetchall():
    con.execute('DROP TRIGGER "' + str(name).replace('"', '""') + '"')
con.execute(
    "UPDATE ctp_dispatch_commands SET account_key = '' WHERE command_id = ?",
    ("fixture-terminal-submit-missing-account",),
)
con.commit()
row = con.execute(
    "SELECT account_key, command_id, operation, status, correlation_version, "
    "request_payload_json, request_payload_sha256 FROM ctp_dispatch_commands "
    "WHERE command_id = ?",
    ("fixture-terminal-submit-missing-account",),
).fetchone()
store.close()
sha = hashlib.sha256(path.read_bytes()).hexdigest()
manifest = {
    "kind": "synthetic-v16-terminal-submit-with-blank-account-key",
    "source_snapshot_manifest_sha256": hashlib.sha256(
        (SNAPSHOT / "snapshot_manifest.json").read_bytes()
    ).hexdigest(),
    "database_schema_version": 16,
    "database_path": path.name,
    "database_sha256": sha,
    "row": dict(row),
    "no_provider_native_network_or_private_config": True,
}
m = OUT / "supplemental_submit_identity_manifest.json"
m.write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"manifest": str(m), "manifest_sha256": hashlib.sha256(m.read_bytes()).hexdigest(), **manifest}, sort_keys=True, indent=2))
