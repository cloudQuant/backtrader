import json, sys, hashlib
from pathlib import Path
SNAPSHOT = Path(r"D:\temp\iteration41_v17_execution_review_20260926")
sys.path.insert(0, str(SNAPSHOT / "src"))
sys.path.insert(0, str(SNAPSHOT / "tests"))
from bt_api_execution import DurableStoreError, ExecutionScope, SqliteExecutionStore
from test_ctp_dispatch_commands import _lease, _prepare_v17_cancel

path = Path(r"D:\temp\iteration41_v17_migration_fixtures_20260926\allocator_int32_boundary.sqlite3")
if path.exists():
    path.unlink()
scope = ExecutionScope("CTP", "simulation", "acct-int32-boundary", "strategy.boundary", "20260925")
store = SqliteExecutionStore(path)
lease = _lease(store, scope, owner="boundary-owner")
_, first_args = _prepare_v17_cancel(store, scope, lease, "last-valid", session_generation_id="boundary-generation")
store._connection.execute(
    "INSERT INTO ctp_native_action_ref_counters(account_key,last_action_ref,updated_at_ns) VALUES (?,2147483646,1)",
    (scope.account_key,),
)
first = store.stage_ctp_dispatch_command(**first_args)
assert type(first.correlation_key.native_action_ref) is int
assert first.correlation_key.native_action_ref == 2_147_483_647
store.close()

store = SqliteExecutionStore(path)
lease = _lease(store, scope, owner="boundary-owner")
_, second_args = _prepare_v17_cancel(store, scope, lease, "overflow", session_generation_id="boundary-generation")
try:
    store.stage_ctp_dispatch_command(**second_args)
except DurableStoreError as error:
    assert "int32 sequence is exhausted" in str(error)
else:
    raise AssertionError("allocator wrapped or allocated beyond INT32_MAX")
counter = store._connection.execute(
    "SELECT last_action_ref FROM ctp_native_action_ref_counters WHERE account_key=?",
    (scope.account_key,),
).fetchone()[0]
allocations = store._connection.execute(
    "SELECT native_action_ref FROM ctp_native_action_ref_allocations WHERE account_key=? ORDER BY native_action_ref",
    (scope.account_key,),
).fetchall()
command = store.read_ctp_dispatch_command(scope, second_args["command_id"])
assert counter == 2_147_483_647
assert [row[0] for row in allocations] == [2_147_483_647]
assert command is None
print(json.dumps({
    "accepted_max": first.correlation_key.native_action_ref,
    "subsequent_allocation": "rejected",
    "counter_after": counter,
    "allocation_rows": [row[0] for row in allocations],
    "second_command_created": command is not None,
    "database_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
}, sort_keys=True, indent=2))
store.close()
