# External CTP AccountActorPort candidate — freeze r2

Date: 2026-09-27

## Scope

This isolated, offline-only candidate defines a typed CTP submit/cancel port, a fail-closed unavailable default, route classification, and a fake Store boundary harness. It is not wired into Backtrader. No external actor implementation, identity, transport, credentials, CTP provider, SDK, native API, or network call exists in this candidate.

## Main-repository seam review

The source reviewed was D:\source_code\backtrader at capture time. backtrader/stores/btapistore.py SHA-256 was DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826; backtrader_runtime/ctp_f14_external_admission.py SHA-256 was 7BA54C6C658EF269F1049FAB1A6D2C14D85D0A7B777767479081CE3F53B7016B.

BtApiStore.__init__ currently calls _resolve_provider at about line 3500, assigns caller api/api_cls, merges kwargs, then applies environment gateway overrides and reads execution authorization config/secrets. The gate must be inserted against raw route inputs before _resolve_provider/_apply_env_gateway_overrides, config secret extraction, SDK imports, client construction, autostart, and connection. The raw api object may already have been constructed by its caller; a Store gate can reject it before use/connect but cannot undo that prior construction.

Public submit/cancel paths include legacy direct dispatch when no managed adapter is attached (submit_order around line 7714, cancel_order around 7991, and cancel_order_ref around 8040). CTP managed submit/cancel use a specialized adapter and enqueue commands to a local SDK route (_submit_ctp_managed_order around 7766 and _cancel_managed around 8070). All are local write paths and must be bypassed/guarded for actor-owned CTP routes. _ensure_api_ready around line 16395 may import bt_api_py, instantiate direct or gateway clients, and later connect.

CtpF14ExternalAdmissionAuthority around lines 249-265 is an admission claim/recheck Protocol. It is not a remote executor and does not replace this transport port.

## Verification

- python -m unittest discover -s tests -v: 15 passed.
- python -m py_compile account_actor_port.py store_boundary_harness.py tests\test_store_boundary_harness.py: passed.
- python -m ruff check --target-version py38 account_actor_port.py store_boundary_harness.py tests\test_store_boundary_harness.py: passed.

The fake cases verify missing actor rejection before the fake credential resolver, API/API-class factory, gateway factory, connect, and fake ReqOrderInsert/ReqOrderAction; they also reject raw API injection with an actor and CTP calls to legacy private fallback methods. A caller-created fake API is counted as preexisting construction; the test confirms no Store connect or native method call.

## Integration limits

The route classifier deliberately rejects ambiguous btapi injected clients; this can break existing custom non-CTP integrations and requires a code-owned non-CTP registry before integration. Explicit CTP selectors in route maps take precedence over generic gateway labels. CTP actor routing also removes the Store local CTP market-data/account-query client; an eventual actor must expose an appropriate read-only feed or the Store must remain unavailable. The typed receipt reports only actor queue disposition, never provider acknowledgement.

This is a local interface/harness only. It does not establish external account exclusivity, authenticated actor identity, deployment pinning, common account snapshots, callback source, reliable handoff, or real CTP availability. Default live and SimNow write routes remain closed.