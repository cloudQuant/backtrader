import unittest
from decimal import Decimal

from account_actor_port import (
    AccountActorGateError,
    ActorCommandReceiptV1,
    ActorCommandState,
    CtpAccountActorPort,
    CtpCancelIntentV1,
    CtpSubmitIntentV1,
    RouteKind,
    StoreRouteDescriptor,
    UnavailableCtpAccountActorPort,
    classify_store_route,
)
from store_boundary_harness import StoreBoundaryHarness


class Counters:
    def __init__(self):
        self.constructed = 0
        self.connected = 0
        self.native_calls = 0
        self.gateway_created = 0


class FakeNativeClient:
    def __init__(self, counters):
        counters.constructed += 1
        self.counters = counters

    def connect(self):
        self.counters.connected += 1

    def ReqOrderInsert(self, *_args):
        self.counters.native_calls += 1
        return 0

    def ReqOrderAction(self, *_args):
        self.counters.native_calls += 1
        return 0


class FakeActorPort(CtpAccountActorPort):
    def __init__(self):
        self.submits = []
        self.cancels = []

    def submit_order(self, intent):
        self.submits.append(intent)
        return ActorCommandReceiptV1(
            command_id=intent.intent_id,
            state=ActorCommandState.QUEUED,
            actor_epoch=3,
        )

    def cancel_order(self, intent):
        self.cancels.append(intent)
        return ActorCommandReceiptV1(
            command_id=intent.cancel_intent_id,
            state=ActorCommandState.QUEUED,
            actor_epoch=3,
        )


def submit_intent():
    return CtpSubmitIntentV1(
        intent_id="submit-1",
        instrument_id="IF2601",
        exchange_id="CFFEX",
        side="BUY",
        offset="OPEN",
        hedge_flag="SPECULATION",
        quantity=1,
        limit_price=Decimal("3000.5"),
    )


def cancel_intent():
    return CtpCancelIntentV1(
        cancel_intent_id="cancel-1",
        runtime_order_id="runtime-order-1",
        order_ref="123",
        front_id=7,
        session_id=11,
        exchange_id="CFFEX",
        order_sys_id="system-order-1",
    )


class ActorPortGateTests(unittest.TestCase):
    def test_ctp_direct_legacy_store_rejects_before_api_class_factory(self):
        counters = Counters()

        def factory():
            return FakeNativeClient(counters)

        route = StoreRouteDescriptor(
            provider="ctp",
            backend="direct",
            api_cls=FakeNativeClient,
        )
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(
                route,
                credential_resolver=lambda: self.fail("credentials must not be resolved"),
                api_factory=factory,
            )
        self.assertEqual(counters.constructed, 0)
        self.assertEqual(counters.connected, 0)
        self.assertEqual(counters.native_calls, 0)

    def test_ctp_gateway_rejects_before_legacy_gateway_import_or_factory(self):
        counters = Counters()

        def gateway_factory():
            counters.gateway_created += 1
            return FakeNativeClient(counters)

        route = StoreRouteDescriptor(
            provider="gateway",
            backend="gateway",
            config={"exchange_type": "CTP"},
        )
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(
                route,
                credential_resolver=lambda: self.fail("credentials must not be resolved"),
                gateway_factory=gateway_factory,
            )
        self.assertEqual(counters.gateway_created, 0)
        self.assertEqual(counters.constructed, 0)
        self.assertEqual(counters.native_calls, 0)

    def test_ctp_gateway_default_exchange_is_fail_closed(self):
        route = StoreRouteDescriptor(provider="ctp_gateway", backend="gateway")
        self.assertIs(classify_store_route(route), RouteKind.CTP)
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(
                route,
                credential_resolver=lambda: self.fail("credentials must not be resolved"),
            )
        self.assertIs(classify_store_route(StoreRouteDescriptor(provider="ctp")), RouteKind.CTP)

    def test_gateway_primary_exchange_cannot_mask_ctp_symbol_route(self):
        counters = Counters()
        route = StoreRouteDescriptor(
            provider="gateway",
            backend="gateway",
            config={
                "exchange_type": "OKX",
                "symbol_routes": {"IF2601": "CTP"},
            },
        )
        self.assertIs(classify_store_route(route), RouteKind.CTP)

        def gateway_factory():
            counters.gateway_created += 1
            return FakeNativeClient(counters)

        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(
                route,
                credential_resolver=lambda: self.fail("credentials must not be resolved"),
                gateway_factory=gateway_factory,
            )
        self.assertEqual(counters.gateway_created, 0)
        self.assertEqual(counters.constructed, 0)
        self.assertEqual(counters.native_calls, 0)

    def test_injected_api_is_rejected_before_store_connect_or_native_call(self):
        counters = Counters()
        prebuilt = FakeNativeClient(counters)
        route = StoreRouteDescriptor(provider="ctp", backend="direct", api=prebuilt)
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(
                route,
                credential_resolver=lambda: self.fail("credentials must not be resolved"),
            )
        self.assertEqual(counters.constructed, 1)  # caller built it before Store entry
        self.assertEqual(counters.connected, 0)
        self.assertEqual(counters.native_calls, 0)

    def test_actor_route_rejects_api_and_api_cls_injection_even_with_actor(self):
        counters = Counters()
        actor = FakeActorPort()
        prebuilt = FakeNativeClient(counters)
        route = StoreRouteDescriptor(provider="ctp", api=prebuilt)
        with self.assertRaisesRegex(AccountActorGateError, "local ctp client injection forbidden"):
            StoreBoundaryHarness(route, actor_port=actor)
        route = StoreRouteDescriptor(provider="ctp", api_cls=FakeNativeClient)
        with self.assertRaisesRegex(AccountActorGateError, "local ctp client injection forbidden"):
            StoreBoundaryHarness(route, actor_port=actor, api_factory=lambda: FakeNativeClient(counters))
        self.assertEqual(counters.constructed, 1)
        self.assertEqual(counters.native_calls, 0)
        self.assertEqual(actor.submits, [])

    def test_btapi_ctp_exchange_configuration_rejects_before_custom_class(self):
        counters = Counters()
        route = StoreRouteDescriptor(
            provider="btapi",
            api_kwargs={"exchange_kwargs": {"CTP": {"broker_id": "fake"}}},
            api_cls=FakeNativeClient,
        )
        self.assertIs(classify_store_route(route), RouteKind.CTP)
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(route, api_factory=lambda: FakeNativeClient(counters))
        self.assertEqual(counters.constructed, 0)
        self.assertEqual(counters.native_calls, 0)

    def test_ambiguous_btapi_custom_client_fails_closed_before_factory(self):
        counters = Counters()
        route = StoreRouteDescriptor(provider="btapi", api_cls=FakeNativeClient)
        self.assertIs(classify_store_route(route), RouteKind.AMBIGUOUS)
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            StoreBoundaryHarness(
                route,
                credential_resolver=lambda: self.fail("credentials must not be resolved"),
                api_factory=lambda: FakeNativeClient(counters),
            )
        self.assertEqual(counters.constructed, 0)
        self.assertEqual(counters.native_calls, 0)

    def test_actor_only_typed_submit_and_cancel_have_no_local_native_client(self):
        actor = FakeActorPort()
        route = StoreRouteDescriptor(provider="ctp", backend="direct")
        store = StoreBoundaryHarness(route, actor_port=actor)
        submit_result = store.submit_order(submit_intent())
        cancel_result = store.cancel_order(cancel_intent())
        self.assertEqual(submit_result.state, ActorCommandState.QUEUED)
        self.assertEqual(cancel_result.state, ActorCommandState.QUEUED)
        self.assertEqual(len(actor.submits), 1)
        self.assertEqual(len(actor.cancels), 1)
        self.assertIsNone(store.api)
        self.assertEqual(store.legacy_calls, 0)

    def test_actor_route_rejects_legacy_private_fallback(self):
        actor = FakeActorPort()
        store = StoreBoundaryHarness(
            StoreRouteDescriptor(provider="ctp", backend="direct"),
            actor_port=actor,
        )
        with self.assertRaisesRegex(AccountActorGateError, "ctp legacy dispatch forbidden"):
            store._submit_order_legacy(submit_intent())
        with self.assertRaisesRegex(AccountActorGateError, "ctp legacy dispatch forbidden"):
            store._cancel_order_legacy(cancel_intent())
        self.assertEqual(store.legacy_calls, 0)

    def test_actor_route_requires_exact_typed_intents_and_no_dict_fallback(self):
        actor = FakeActorPort()
        store = StoreBoundaryHarness(
            StoreRouteDescriptor(provider="ctp"),
            actor_port=actor,
        )
        with self.assertRaisesRegex(AccountActorGateError, "typed submit intent required"):
            store.submit_order({"instrument_id": "IF2601"})
        with self.assertRaisesRegex(AccountActorGateError, "typed cancel intent required"):
            store.cancel_order({"order_ref": "123"})
        self.assertEqual(actor.submits, [])
        self.assertEqual(actor.cancels, [])

    def test_bad_actor_receipt_never_falls_back_to_native(self):
        class BadActor(FakeActorPort):
            def submit_order(self, intent):
                self.submits.append(intent)
                return True

        actor = BadActor()
        store = StoreBoundaryHarness(StoreRouteDescriptor(provider="ctp"), actor_port=actor)
        with self.assertRaisesRegex(AccountActorGateError, "actor receipt type invalid"):
            store.submit_order(submit_intent())
        self.assertIsNone(store.api)
        self.assertEqual(store.legacy_calls, 0)


class TypedIntentValidationTests(unittest.TestCase):
    def test_bool_quantity_is_not_native_integer_quantity(self):
        with self.assertRaisesRegex(ValueError, "positive exact integer"):
            CtpSubmitIntentV1(
                intent_id="i",
                instrument_id="x",
                exchange_id="e",
                side="BUY",
                offset="OPEN",
                hedge_flag="SPECULATION",
                quantity=True,
                limit_price=Decimal(1),
            )

    def test_bool_front_id_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "positive exact integer"):
            CtpCancelIntentV1(
                cancel_intent_id="c",
                runtime_order_id="r",
                order_ref="o",
                front_id=True,
                session_id=1,
                exchange_id="e",
                order_sys_id="s",
            )

    def test_unavailable_default_does_not_claim_authority(self):
        unavailable = UnavailableCtpAccountActorPort()
        with self.assertRaisesRegex(AccountActorGateError, "external account actor unavailable"):
            unavailable.submit_order(submit_intent())


if __name__ == "__main__":
    unittest.main()
