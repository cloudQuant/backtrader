# External CTP Account Actor Port — offline candidate r0

This independent candidate models a fail-closed composition boundary only. It does not edit or import the main Backtrader package, does not implement a remote service, and must not be treated as a CTP write route.

Run the isolated fake harness with:

    python -m unittest discover -s tests -v

The required result is zero API-class/gateway construction, connect, or ReqOrderInsert/ReqOrderAction calls for missing/default actor routes. An explicit FakeActorPort is test-only and proves DTO wiring, not external authority.

See INTEGRATION_CONTRACT.md for the precise main Store call points, existing seam differences, and public-compatibility limitations.
