"""Tiny fake Store boundary. It models ordering only and never imports Backtrader."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any, Optional

from account_actor_port import (
    AccountActorGateError,
    ActorCommandReceiptV1,
    CtpAccountActorPort,
    CtpCancelIntentV1,
    CtpSubmitIntentV1,
    RouteKind,
    StoreRouteDescriptor,
    classify_store_route,
    reject_ctp_legacy_dispatch,
    require_account_actor_before_local_client,
    validate_actor_receipt,
)


class StoreBoundaryHarness:
    def __init__(
        self,
        route: StoreRouteDescriptor,
        *,
        actor_port: Optional[CtpAccountActorPort] = None,  # noqa: UP045 - Python 3.8
        credential_resolver: Optional[Callable[[], Any]] = None,  # noqa: UP045 - Python 3.8
        api_factory: Optional[Callable[[], Any]] = None,  # noqa: UP045 - Python 3.8
        gateway_factory: Optional[Callable[[], Any]] = None,  # noqa: UP045 - Python 3.8
    ) -> None:
        # This is the candidate integration order: gate before retaining or
        # invoking any local API/API class/gateway factory.
        self.route_kind = classify_store_route(route)
        self.actor_port = require_account_actor_before_local_client(route, actor_port)
        self.api = None
        self.legacy_calls = 0
        # This ordering models the production boundary: classification and the
        # unavailable-actor rejection precede credential resolution too.
        if self.route_kind is RouteKind.NON_CTP and credential_resolver is not None:
            credential_resolver()
        if self.route_kind is RouteKind.NON_CTP:
            if route.api is not None:
                self.api = route.api
            elif route.backend == "gateway":
                self.api = gateway_factory() if gateway_factory is not None else None
            elif route.api_cls is not None:
                self.api = api_factory() if api_factory is not None else route.api_cls()
        elif route.api is not None or route.api_cls is not None:
            # The gate above rejects these for an actor-owned CTP route.
            raise AccountActorGateError("local_ctp_client_injection_forbidden")

    def submit_order(self, intent: object) -> ActorCommandReceiptV1:
        if self.route_kind is not RouteKind.NON_CTP:
            if type(intent) is not CtpSubmitIntentV1:
                raise AccountActorGateError("typed_submit_intent_required")
            receipt = self.actor_port.submit_order(intent)
            return validate_actor_receipt(receipt, expected_command_id=intent.intent_id)
        return self._submit_order_legacy(intent)

    def cancel_order(self, intent: object) -> ActorCommandReceiptV1:
        if self.route_kind is not RouteKind.NON_CTP:
            if type(intent) is not CtpCancelIntentV1:
                raise AccountActorGateError("typed_cancel_intent_required")
            receipt = self.actor_port.cancel_order(intent)
            return validate_actor_receipt(receipt, expected_command_id=intent.cancel_intent_id)
        return self._cancel_order_legacy(intent)

    def _submit_order_legacy(self, value: object) -> str:
        del value
        reject_ctp_legacy_dispatch(self.route_kind)
        self.legacy_calls += 1
        return "legacy_non_ctp"

    def _cancel_order_legacy(self, value: object) -> str:
        del value
        reject_ctp_legacy_dispatch(self.route_kind)
        self.legacy_calls += 1
        return "legacy_non_ctp"
