"""Offline-only typed account actor port and preconstruction CTP route gate.

This module defines a capability boundary for a future external actor client.
It contains no transport, credential resolver, SDK import, native API, or actor
implementation. A typed fake port proves wiring only; it is not authority.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Any, Optional


class AccountActorGateError(RuntimeError):
    """Fail-closed error before any local CTP client is connected or created."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code.replace("_", " "))


class RouteKind(str, Enum):
    CTP = "ctp"
    NON_CTP = "non_ctp"
    AMBIGUOUS = "ambiguous"


class ActorCommandState(str, Enum):
    QUEUED = "queued"
    UNKNOWN = "unknown"
    REJECTED = "rejected"


@dataclass(frozen=True)
class CtpSubmitIntentV1:
    """Logical order intent. Native OrderRef/RequestID are never caller fields."""

    intent_id: str
    instrument_id: str
    exchange_id: str
    side: str
    offset: str
    hedge_flag: str
    quantity: int
    limit_price: Decimal

    def __post_init__(self) -> None:
        _required_text(self.intent_id, "intent_id")
        _required_text(self.instrument_id, "instrument_id")
        _required_text(self.exchange_id, "exchange_id")
        if self.side not in {"BUY", "SELL"}:
            raise ValueError("side must be BUY or SELL")
        if self.offset not in {"OPEN", "CLOSE", "CLOSE_TODAY", "CLOSE_YESTERDAY"}:
            raise ValueError("unsupported offset")
        if self.hedge_flag not in {"SPECULATION", "ARBITRAGE", "HEDGE", "MARKET_MAKER"}:
            raise ValueError("unsupported hedge_flag")
        if type(self.quantity) is not int or self.quantity <= 0:
            raise ValueError("quantity must be a positive exact integer")
        if type(self.limit_price) is not Decimal or not self.limit_price.is_finite():
            raise ValueError("limit_price must be a finite Decimal")
        if self.limit_price <= 0:
            raise ValueError("limit_price must be positive")


@dataclass(frozen=True)
class CtpCancelIntentV1:
    """Logical cancel intent. Native OrderActionRef/RequestID are never fields."""

    cancel_intent_id: str
    runtime_order_id: str
    order_ref: str
    front_id: int
    session_id: int
    exchange_id: str
    order_sys_id: str

    def __post_init__(self) -> None:
        for name in (
            "cancel_intent_id",
            "runtime_order_id",
            "order_ref",
            "exchange_id",
            "order_sys_id",
        ):
            _required_text(getattr(self, name), name)
        if type(self.front_id) is not int or self.front_id <= 0:
            raise ValueError("front_id must be a positive exact integer")
        if type(self.session_id) is not int or self.session_id <= 0:
            raise ValueError("session_id must be a positive exact integer")


@dataclass(frozen=True)
class ActorCommandReceiptV1:
    """Actor queue disposition; it is deliberately not a provider acknowledgement."""

    command_id: str
    state: ActorCommandState
    actor_epoch: int

    def __post_init__(self) -> None:
        _required_text(self.command_id, "command_id")
        if type(self.state) is not ActorCommandState:
            raise ValueError("state must be ActorCommandState")
        if type(self.actor_epoch) is not int or self.actor_epoch <= 0:
            raise ValueError("actor_epoch must be a positive exact integer")


class CtpAccountActorPort(ABC):
    """Typed remote-owner client seam; methods never accept local native callbacks."""

    @abstractmethod
    def submit_order(self, intent: CtpSubmitIntentV1) -> ActorCommandReceiptV1:
        """Submit one logical intent to the external account actor."""

    @abstractmethod
    def cancel_order(self, intent: CtpCancelIntentV1) -> ActorCommandReceiptV1:
        """Submit one logical cancel intent to the external account actor."""


class UnavailableCtpAccountActorPort(CtpAccountActorPort):
    """Default port. No external account actor is installed in this candidate."""

    def submit_order(self, intent: CtpSubmitIntentV1) -> ActorCommandReceiptV1:
        del intent
        raise AccountActorGateError("external_account_actor_unavailable")

    def cancel_order(self, intent: CtpCancelIntentV1) -> ActorCommandReceiptV1:
        del intent
        raise AccountActorGateError("external_account_actor_unavailable")


@dataclass(frozen=True)
class StoreRouteDescriptor:
    """Only non-secret routing facts used before Store SDK/client construction."""

    provider: str
    backend: Optional[str] = None  # noqa: UP045 - retain Python 3.8 compatibility
    config: Mapping[str, Any] = None  # type: ignore[assignment]
    api_kwargs: Mapping[str, Any] = None  # type: ignore[assignment]
    api: Any = None
    api_cls: Any = None

    def __post_init__(self) -> None:
        if self.config is None:
            object.__setattr__(self, "config", {})
        if self.api_kwargs is None:
            object.__setattr__(self, "api_kwargs", {})


def classify_store_route(route: StoreRouteDescriptor) -> RouteKind:
    """Classify before reading credentials or creating an SDK/gateway object.

    Unknown btapi routes and caller-injected btapi clients are AMBIGUOUS. In a
    strict production composition they must not be treated as non-CTP merely
    because the caller omitted an exchange label.
    """

    provider = _text(route.provider).lower()
    backend = _text(route.backend).lower()
    if provider in {"ctp", "ctp_gateway"}:
        return RouteKind.CTP

    config = route.config if isinstance(route.config, Mapping) else {}
    api_kwargs = route.api_kwargs if isinstance(route.api_kwargs, Mapping) else {}
    exchange = _first_text(
        api_kwargs.get("exchange_type"),
        api_kwargs.get("exchange"),
        config.get("exchange_type"),
        config.get("exchange"),
    ).upper()

    # Explicit CTP selectors in any route map take precedence over a generic
    # provider/backend label. This prevents a mixed gateway route from being
    # classified as non-CTP just because its primary exchange is another venue.
    venues: set[str] = set()
    for values in (api_kwargs, config):
        venues.update(
            _venue(value)
            for value in (values.get("exchange_type"), values.get("exchange"))
            if _venue(value)
        )
        venues.update(_collect_venues(values.get("exchange_kwargs")))
        venues.update(_collect_route_values(values.get("symbol_routes")))
    venues.update(_collect_venues(getattr(route.api, "exchange_kwargs", None)))
    if "CTP" in venues:
        return RouteKind.CTP

    if provider.endswith("_gateway") or provider == "gateway" or backend == "gateway":
        # The current BtApiStore gateway CTP path defaults exchange_type to CTP.
        if not exchange:
            exchange = "CTP"
        return RouteKind.CTP if exchange == "CTP" else RouteKind.NON_CTP

    if provider == "btapi":
        if route.api is not None or route.api_cls is not None:
            return RouteKind.AMBIGUOUS
        if venues:
            return RouteKind.NON_CTP
        return RouteKind.AMBIGUOUS

    return RouteKind.NON_CTP


def require_account_actor_before_local_client(
    route: StoreRouteDescriptor,
    actor_port: Optional[CtpAccountActorPort],  # noqa: UP045 - Python 3.8 compatibility
) -> CtpAccountActorPort:
    """Reject CTP/ambiguous routes before any local API, SDK or gateway creation."""

    kind = classify_store_route(route)
    if kind is RouteKind.NON_CTP:
        return actor_port if actor_port is not None else UnavailableCtpAccountActorPort()

    if actor_port is None or isinstance(actor_port, UnavailableCtpAccountActorPort):
        raise AccountActorGateError("external_account_actor_unavailable")
    if not isinstance(actor_port, CtpAccountActorPort):
        raise AccountActorGateError("typed_account_actor_port_required")
    if route.api is not None or route.api_cls is not None:
        raise AccountActorGateError("local_ctp_client_injection_forbidden")
    return actor_port


def validate_actor_receipt(
    receipt: object, *, expected_command_id: str
) -> ActorCommandReceiptV1:
    """Validate local receipt shape without elevating it to provider acknowledgement."""

    if type(receipt) is not ActorCommandReceiptV1:
        raise AccountActorGateError("actor_receipt_type_invalid")
    if receipt.command_id != expected_command_id:
        raise AccountActorGateError("actor_receipt_command_mismatch")
    return receipt


def reject_ctp_legacy_dispatch(route_kind: RouteKind) -> None:
    """Defense in depth for old private Store dispatchers."""

    if route_kind is not RouteKind.NON_CTP:
        raise AccountActorGateError("ctp_legacy_dispatch_forbidden")


def _collect_venues(value: Any) -> set[str]:
    result: set[str] = set()
    if not isinstance(value, Mapping):
        return result
    for key, nested in value.items():
        venue = _venue(key)
        if venue:
            result.add(venue)
        if isinstance(nested, Mapping):
            nested_venue = _first_text(nested.get("exchange_type"), nested.get("exchange"))
            if nested_venue:
                result.add(_venue(nested_venue))
    return result


def _collect_route_values(value: Any) -> set[str]:
    if not isinstance(value, Mapping):
        return set()
    return {venue for venue in (_venue(item) for item in value.values()) if venue}


def _venue(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return value.strip().partition("___")[0].upper()


def _first_text(*values: Any) -> str:
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _text(value: Any) -> str:
    return value.strip() if isinstance(value, str) else ""


def _required_text(value: Any, name: str) -> None:
    if type(value) is not str or not value.strip():
        raise ValueError(f"{name} is required")


__all__ = [
    "AccountActorGateError",
    "ActorCommandReceiptV1",
    "ActorCommandState",
    "CtpAccountActorPort",
    "CtpCancelIntentV1",
    "CtpSubmitIntentV1",
    "RouteKind",
    "StoreRouteDescriptor",
    "UnavailableCtpAccountActorPort",
    "classify_store_route",
    "reject_ctp_legacy_dispatch",
    "require_account_actor_before_local_client",
    "validate_actor_receipt",
]
