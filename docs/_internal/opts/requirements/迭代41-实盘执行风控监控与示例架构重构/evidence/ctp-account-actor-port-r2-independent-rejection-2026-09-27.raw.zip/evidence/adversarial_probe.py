import json
from decimal import Decimal
from account_actor_port import (
    AccountActorGateError, ActorCommandReceiptV1, ActorCommandState,
    CtpAccountActorPort, CtpSubmitIntentV1, StoreRouteDescriptor,
    classify_store_route, require_account_actor_before_local_client,
    validate_actor_receipt,
)
from store_boundary_harness import StoreBoundaryHarness

class FakeLocalApi:
    made = 0
    def __init__(self):
        type(self).made += 1

class FakeActor(CtpAccountActorPort):
    def __init__(self, actor_epoch=3, account_id="acct-wrong"):
        self.actor_epoch = actor_epoch
        self.account_id = account_id
        self.calls = []
    def submit_order(self, intent):
        self.calls.append(intent)
        return ActorCommandReceiptV1(intent.intent_id, ActorCommandState.QUEUED, self.actor_epoch)
    def cancel_order(self, intent):
        self.calls.append(intent)
        return ActorCommandReceiptV1(intent.cancel_intent_id, ActorCommandState.QUEUED, self.actor_epoch)

def intent():
    return CtpSubmitIntentV1("submit-1", "IF2601", "CFFEX", "BUY", "OPEN", "SPECULATION", 1, Decimal("3000"))

results = {}

# Unknown provider label plus injected API class is classified NON_CTP and permitted.
FakeLocalApi.made = 0
route = StoreRouteDescriptor(provider="custom_ctp_alias", backend="direct", api_cls=FakeLocalApi)
kind = classify_store_route(route)
actor = require_account_actor_before_local_client(route, None)
constructed = []
harness = StoreBoundaryHarness(route, api_factory=lambda: constructed.append(FakeLocalApi()) or constructed[-1])
fallback = harness._submit_order_legacy(intent())
results["unknown_provider_api_cls"] = {
    "route_kind": kind.value,
    "unavailable_port_returned": actor.__class__.__name__,
    "local_api_factory_calls": len(constructed),
    "legacy_fallback": fallback,
}

# Nested symbol_routes value is not traversed; primary OKX gateway label masks the nested CTP value.
nested_route = StoreRouteDescriptor(
    provider="gateway", backend="gateway",
    config={"exchange_type": "OKX", "symbol_routes": {"IF2601": {"exchange": "CTP"}}},
)
nested_kind = classify_store_route(nested_route)
gateway_calls = []
nested_harness = StoreBoundaryHarness(
    nested_route, gateway_factory=lambda: gateway_calls.append("constructed") or object()
)
results["nested_gateway_symbol_route"] = {
    "route_kind": nested_kind.value,
    "gateway_factory_calls": len(gateway_calls),
}

# Classification calls a caller-controlled property before the fail-closed gate returns.
class SideEffectApi:
    reads = 0
    @property
    def exchange_kwargs(self):
        type(self).reads += 1
        return {}
side_effect_route = StoreRouteDescriptor(provider="btapi", api=SideEffectApi())
try:
    require_account_actor_before_local_client(side_effect_route, None)
except AccountActorGateError as exc:
    gate_error = exc.code
results["api_property_before_gate"] = {
    "property_reads": SideEffectApi.reads,
    "eventual_gate_error": gate_error,
}

# Positive exact command-id check and rejection for mismatched request identity.
receipt = ActorCommandReceiptV1("submit-1", ActorCommandState.QUEUED, 1)
results["stale_actor_epoch"] = {
    "expected_current_epoch_in_probe": 3,
    "receipt_epoch": receipt.actor_epoch,
    "validate_accepted": validate_actor_receipt(receipt, expected_command_id="submit-1") is receipt,
}
try:
    validate_actor_receipt(ActorCommandReceiptV1("other", ActorCommandState.QUEUED, 3), expected_command_id="submit-1")
except AccountActorGateError as exc:
    wrong_request_error = exc.code
results["wrong_command_id"] = {"rejected": wrong_request_error}

# Account in route config is not bound to typed intent or receipt; actor identity is not inspected.
wrong_account_actor = FakeActor(actor_epoch=3, account_id="acct-other")
account_route = StoreRouteDescriptor(provider="ctp", config={"account_id": "acct-configured"})
account_harness = StoreBoundaryHarness(account_route, actor_port=wrong_account_actor)
accepted = account_harness.submit_order(intent())
results["mismatched_actor_account"] = {
    "route_account": account_route.config["account_id"],
    "fake_actor_account": wrong_account_actor.account_id,
    "receipt_state": accepted.state.value,
    "accepted_without_account_binding": accepted.command_id == "submit-1",
}

# This port has no callback inbox/sequence or replay state: repeated identical request is sent twice.
replay_actor = FakeActor(account_id="acct-configured")
replay_harness = StoreBoundaryHarness(
    StoreRouteDescriptor(provider="ctp", config={"account_id": "acct-configured"}),
    actor_port=replay_actor,
)
replay_first = replay_harness.submit_order(intent())
replay_second = replay_harness.submit_order(intent())
results["duplicate_intent_replay"] = {
    "both_receipts_accepted": replay_first.command_id == replay_second.command_id == "submit-1",
    "actor_submit_calls": len(replay_actor.calls),
}

# The no-actor CTP route remains fail-closed before credential resolver.
resolver_calls = []
try:
    StoreBoundaryHarness(
        StoreRouteDescriptor(provider="ctp"),
        credential_resolver=lambda: resolver_calls.append("called"),
    )
except AccountActorGateError as exc:
    no_actor_error = exc.code
results["absent_actor"] = {"error": no_actor_error, "credential_resolver_calls": len(resolver_calls)}

print(json.dumps(results, indent=2, sort_keys=True))
