# Independent QA: claimed-action expiry r4a

Date: 2026-09-27. This packet is source-only QA; it does not authorize provider, native CTP, wheel, deployment, or live operation.

## Result

The independently guarded run executed the four frozen r4a test files plus `qa-tests/test_r4_bounded_skew.py`: **100 passed, 0 skipped, exit 0**. The only warnings were missing CTP extension for this interpreter and the existing pytest-asyncio default loop-scope warning. `_ctp` was not left in `sys.modules`; all API calls were fake.

The custom real-Store boundary test uses a Store-issued V2 binding with its accepted TTL parameter set to 2 seconds, while the signed permit remains at its fixture TTL of 4 seconds. At final admission it pauses to about 200 ms before binding expiry, refreshes the typed revocation/fence snapshots, then supplies a trusted final sample 100 microseconds before or after the exact binding expiry.

* Before expiry: final trusted time was 100,000 ns before binding expiry; fake ReqOrderInsert=1, command COMPLETED, owner ACTIVE, one persisted authority use. Trusted-final to fake Req wall was 194,626,500 ns.
* After expiry: final trusted time was 100,000 ns after expiry; fake ReqOrderInsert=0, command UNKNOWN (`native_receipt_unknown`), owner POISONED (`native_call_lease_failure`), one persisted authority use. Trusted-final to near-call wall was 194,288,800 ns.

Both trusted-time/wall deltas and expiry/wall gaps were asserted <=250,000,000 ns. This verifies the r4a fix in a bounded-skew fake call path and confirms the approval is not consumed a second time.

## Exact source tuple and guards

* r4a source snapshot: `D:\temp\iteration41-action-authority-claimed-r4a-expiry-fix-20260926`; author evidence manifest SHA256 `6b9b516b5a777d6e81b3595dfe170772a11b5d7737121cb4945e34815ddbbb7a`. The r4a evidence manifest is copied here; it was not modified.
* All eight runtime/test source files were hashed against that manifest and independently compared against r4; all bytes matched. The r4 directory's earlier evidence runner/log was contaminated; this packet only treats its source-byte equality as valid, not its old run evidence.
* Imported runtime candidate modules came from the explicit r4a snapshot with exact `__file__` assertions.
* V18 execution Store came from `D:\temp\iteration41_v18_cancel_postcondition_r0\src` (`store.py` SHA256 `25980518e1b7aae5ce13e3531ab854771ab5d036df0209cddde08508124e8206`).
* SDK29 CTP source came from `D:\q\e\src` (`client.py` SHA256 `bf915128c41da83efdff517e3ea711c43d7555406bd831a0dfcd775b64840d1c`).
* Base source came from `D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src` (`__init__.py` SHA256 `c0c14cfa1e39a79fef8126a85e82cd7b41d5662e683ff11932fcc58add8116b4`).
* Parent76 source came from `D:\bt_api_py_codex_i9_integrated_20260926` (`bt_api_py\__init__.py` SHA256 `d7704ab15dd3a09beb033be65536c70f24748ad77e1ee7d446c633d7f864d999`).
* Explicit source-only distribution metadata shim: `C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926` (execution 0.2.0, CTP 2.0.4+iteration41.i9, base 0.15.4, parent 0.15.5). No wheel or installed-artifact claim.

The exact origins and the 100-test output are in `results/independent.stdout.log`; warnings are in `results/independent.stderr.log`. The JUnit file is `results/r4a-independent.junit.xml`.
