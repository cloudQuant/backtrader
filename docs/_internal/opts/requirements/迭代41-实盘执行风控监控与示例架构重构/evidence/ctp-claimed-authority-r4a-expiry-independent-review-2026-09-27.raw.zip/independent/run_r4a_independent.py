from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import sys

R4A = Path(r'D:\temp\iteration41-action-authority-claimed-r4a-expiry-fix-20260926')
R4 = Path(r'D:\temp\iteration41-action-authority-claimed-r4-expiry-fix-20260926')
EVIDENCE = Path(r'D:\temp\iteration41-action-authority-claimed-r4a-evidence-20260926')
EXPECTED_EVIDENCE_MANIFEST = '6b9b516b5a777d6e81b3595dfe170772a11b5d7737121cb4945e34815ddbbb7a'
QA = Path(__file__).resolve().parent
OUT = Path(os.environ['R4A_QA_OUTPUT'])
OUT.mkdir(parents=True, exist_ok=True)

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert digest(EVIDENCE / 'manifest.json') == EXPECTED_EVIDENCE_MANIFEST
manifest = json.loads((EVIDENCE / 'manifest.json').read_text(encoding='utf-8'))
expected_sources = {item['path']: item['sha256'] for item in manifest['snapshot_files'] if item['path'].endswith('.py') and '__pycache__' not in item['path'] and item['path'].startswith(('backtrader_runtime/', 'tests/'))}
assert len(expected_sources) == 8, len(expected_sources)
for rel, expected_hash in expected_sources.items():
    r4a_hash = digest(R4A / Path(rel))
    r4_hash = digest(R4 / Path(rel))
    assert r4a_hash == expected_hash, (rel, 'r4a', r4a_hash, expected_hash)
    assert r4_hash == expected_hash, (rel, 'r4', r4_hash, expected_hash)
    print('SOURCE', rel, expected_hash)

# Independently pin import origins from the source-only dependency tuple.
metadata_root = Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926')
execution_root = Path(r'D:\temp\iteration41_v18_cancel_postcondition_r0\src')
sdk_root = Path(r'D:\q\e\src')
base_root = Path(r'D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src')
parent_root = Path(r'D:\bt_api_py_codex_i9_integrated_20260926')
main_root = Path(r'D:\source_code\backtrader')
source_paths = [metadata_root, execution_root, sdk_root, base_root, parent_root, main_root]
sys.path[:] = [str(p) for p in source_paths] + [p for p in sys.path if p not in {str(item) for item in source_paths}]

import backtrader_runtime
runtime_names = (
    'ctp_managed_action_authority',
    'ctp_managed_action_scope_resolver',
    'ctp_i9_account_session_candidate',
    'ctp_managed_account_runtime_candidate',
)
for short in runtime_names:
    name = 'backtrader_runtime.' + short
    expected_path = (R4A / 'backtrader_runtime' / (short + '.py')).resolve()
    spec = importlib.util.spec_from_file_location(name, expected_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    setattr(backtrader_runtime, short, module)
    spec.loader.exec_module(module)
    assert Path(module.__file__).resolve() == expected_path
    print('ORIGIN', name, module.__file__, digest(expected_path))

dependency_paths = {
    'bt_api_execution.store': execution_root / 'bt_api_execution' / 'store.py',
    'bt_api_ctp.ctp.client': sdk_root / 'bt_api_ctp' / 'ctp' / 'client.py',
    'bt_api_base': base_root / 'bt_api_base' / '__init__.py',
    'bt_api_py': parent_root / 'bt_api_py' / '__init__.py',
}
for name, expected in dependency_paths.items():
    module = importlib.import_module(name)
    assert Path(module.__file__).resolve() == expected.resolve(), (name, module.__file__, expected)
    print('ORIGIN', name, module.__file__, digest(expected))
versions = {name: importlib.metadata.version(name) for name in ('bt_api_execution', 'bt_api_ctp', 'bt_api_base', 'bt_api_py')}
assert versions == {
    'bt_api_execution': '0.2.0',
    'bt_api_ctp': '2.0.4+iteration41.i9',
    'bt_api_base': '0.15.4',
    'bt_api_py': '0.15.5',
}
print('SOURCE_ONLY_METADATA', json.dumps(versions, sort_keys=True), str(metadata_root))
assert not any(name == 'bt_api_ctp.ctp._ctp' or name.endswith('._ctp') for name in sys.modules)

# Load the frozen integration test once as a helper namespace for the QA-only
# bounded-skew test. Pytest later loads the frozen four test files normally.
helper_path = R4A / 'tests' / 'integration' / 'test_iteration41_ctp_i9_account_session_candidate.py'
helper_spec = importlib.util.spec_from_file_location('r4_frozen_helpers', helper_path)
assert helper_spec is not None and helper_spec.loader is not None
helpers = importlib.util.module_from_spec(helper_spec)
sys.modules['r4_frozen_helpers'] = helpers
helper_spec.loader.exec_module(helpers)

import pytest

TEST_FILES = ([QA / 'qa-tests/test_r4_bounded_skew.py'] if os.environ.get('R4A_QA_ONLY') == '1' else [
    R4A / 'tests/unit/runtime/test_ctp_managed_action_authority.py',
    R4A / 'tests/unit/runtime/test_ctp_managed_action_scope_resolver.py',
    R4A / 'tests/integration/test_iteration41_ctp_managed_account_runtime_candidate.py',
    R4A / 'tests/integration/test_iteration41_ctp_i9_account_session_candidate.py',
    QA / 'qa-tests/test_r4_bounded_skew.py',
])
exit_code = pytest.main([
    '-q', '-s', '-p', 'no:cacheprovider', '--confcutdir=' + str(R4A),
    '--junitxml=' + str(OUT / 'r4a-independent.junit.xml'),
    *(str(path) for path in TEST_FILES),
])
assert not any(name == 'bt_api_ctp.ctp._ctp' or name.endswith('._ctp') for name in sys.modules)
raise SystemExit(exit_code)
