from __future__ import annotations

import importlib
import time
from dataclasses import replace

import pytest

from backtrader_runtime.ctp_managed_account_runtime_candidate import (
    CtpManagedAccountRuntimeCandidate,
    CtpManagedActionAuthorityVerifierSlot,
)

h = importlib.import_module("r4_frozen_helpers")


@pytest.mark.parametrize(
    "delta_ns,expect_allowed",
    [(-100_000, True), (100_000, False)],
    ids=["before-expiry", "after-expiry"],
)
def test_200ms_store_binding_expiry_boundary_within_250ms(
    tmp_path, monkeypatch, delta_ns, expect_allowed
):
    slot = CtpManagedActionAuthorityVerifierSlot()
    candidate, store, reserve, make_prepared, _scope_type = h._source_candidate_fixture(
        tmp_path, monkeypatch, environment="simnow", authority_verifier=slot
    )
    api = h._FakeTraderApiFactory.instances[-1]
    reservation = reserve("r4-independent-200ms-" + ("before" if expect_allowed else "after"))
    unsigned_prepared = make_prepared(reservation)
    authority = h._bind_real_action_authority_for_candidate(candidate, unsigned_prepared, slot)
    prepared = replace(unsigned_prepared, approval_digest=authority.permit.digest)
    candidate.stage_and_queue(prepared)

    claim_now = time.time_ns()
    authority.clock.value = claim_now
    authority.revocation_source.snapshot = replace(
        authority.revocation_source.snapshot,
        observed_at_ns=claim_now,
        valid_until_ns=claim_now + 250_000_000,
        source_digest_sha256=h.sha256(b"r4 independent fresh revocation").hexdigest(),
    )
    authority.fence_source.snapshot = replace(
        authority.fence_source.snapshot,
        observed_at_ns=claim_now,
        expires_at_ns=claim_now + 250_000_000,
        source_digest_sha256=h.sha256(b"r4 independent fresh fence").hexdigest(),
    )

    clock_samples = []
    original_now = authority.clock.now_ns

    def tracked_now():
        value = original_now()
        clock_samples.append(value)
        return value

    authority.clock.now_ns = tracked_now
    composition = object.__new__(CtpManagedAccountRuntimeCandidate)
    composition._session_candidate = candidate
    composition._execution_scope = candidate._scope
    composition._store = store
    composition._scope_resolver = authority.resolver
    composition._authority_adapter = authority.adapter
    composition._trusted_clock = authority.clock
    observed = {}

    def final_admission(owner_handle, binding, verified):
        expiry = binding.expires_at_ns
        observed["expiry_ns"] = expiry
        remaining_ns = expiry - time.time_ns() - 200_000_000
        if remaining_ns > 0:
            time.sleep(remaining_ns / 1_000_000_000)
        refreshed_at = time.time_ns()
        authority.clock.value = refreshed_at
        authority.revocation_source.snapshot = replace(
            authority.revocation_source.snapshot,
            observed_at_ns=refreshed_at,
            valid_until_ns=refreshed_at + 250_000_000,
            source_digest_sha256=h.sha256(b"r4 independent final revocation").hexdigest(),
        )
        authority.fence_source.snapshot = replace(
            authority.fence_source.snapshot,
            observed_at_ns=refreshed_at,
            expires_at_ns=refreshed_at + 250_000_000,
            source_digest_sha256=h.sha256(b"r4 independent final fence").hexdigest(),
        )
        pre_expiry = expiry - 100_000
        authority.clock.values = [
            pre_expiry,
            pre_expiry,
            pre_expiry,
            pre_expiry,
            expiry + delta_ns,
        ]
        clock_samples.clear()
        try:
            composition._verify_final_native_call(owner_handle, binding, verified)
        finally:
            observed["trusted_final_ns"] = clock_samples[-1]
            observed["near_call_wall_ns"] = time.time_ns()

    candidate._native_call_admission = final_admission
    original_claim = store.claim_ctp_dispatch_command_for_session

    def short_binding_claim(*args, **kwargs):
        # Keep the permit's real 4 s TTL longer than the actual Store binding.
        # The claim remains Store-issued; only the supported TTL parameter is shortened.
        kwargs["binding_ttl_ns"] = 2_000_000_000
        return original_claim(*args, **kwargs)

    monkeypatch.setattr(store, "claim_ctp_dispatch_command_for_session", short_binding_claim)
    request_walls = []
    original_req = api.ReqOrderInsert

    def timed_req(field, request_id):
        request_walls.append(time.time_ns())
        return original_req(field, request_id)

    monkeypatch.setattr(api, "ReqOrderInsert", timed_req)
    try:
        if expect_allowed:
            result = candidate.dispatch_next()
            assert getattr(result, "status", None) == "COMPLETED", result
        else:
            with pytest.raises(
                h.CtpI9AccountSessionCandidateError,
                match="native call outcome is unknown; account remains fenced",
            ):
                candidate.dispatch_next()

        expiry = observed["expiry_ns"]
        near_wall = observed["near_call_wall_ns"]
        trusted_final = observed["trusted_final_ns"]
        assert abs(trusted_final - near_wall) <= 250_000_000
        assert 0 < expiry - near_wall <= 250_000_000
        assert trusted_final == expiry + delta_ns

        req_calls = [
            call for call in api.calls
            if isinstance(call, tuple) and call[0] == "ReqOrderInsert"
        ]
        command = store.read_ctp_dispatch_command(candidate._scope, prepared.command_id)
        owner_row = store._connection.execute(
            "SELECT owner_state, poison_code FROM ctp_dispatch_callback_session_owners "
            "WHERE owner_intent_id = ?",
            (candidate.owner_handle.owner_intent_id,),
        ).fetchone()
        uses = store._connection.execute(
            "SELECT command_id, approval_digest FROM ctp_dispatch_authority_uses "
            "WHERE account_key = ? AND approval_use_id = ?",
            (candidate._scope.account_key, prepared.approval_use_id),
        ).fetchall()
        assert len(uses) == 1
        assert tuple(uses[0]) == (prepared.command_id, authority.permit.digest)
        if expect_allowed:
            assert req_calls and len(request_walls) == 1
            assert abs(trusted_final - request_walls[0]) <= 250_000_000
            assert command.status == "COMPLETED"
            assert tuple(owner_row) == ("ACTIVE", None)
        else:
            assert not req_calls and not request_walls
            assert command.status == "UNKNOWN"
            assert command.unknown_reason == "native_receipt_unknown"
            assert tuple(owner_row) == ("POISONED", "native_call_lease_failure")
        print(
            "expiry_ns=%d trusted_final_ns=%d near_call_wall_ns=%d delta_ns=%d "
            "req_count=%d command=%s owner=%s authority_uses=%d"
            % (
                expiry,
                trusted_final,
                near_wall,
                trusted_final - near_wall,
                len(req_calls),
                command.status,
                owner_row[0],
                len(uses),
            )
        )
    finally:
        candidate.stop()
        store.close()
