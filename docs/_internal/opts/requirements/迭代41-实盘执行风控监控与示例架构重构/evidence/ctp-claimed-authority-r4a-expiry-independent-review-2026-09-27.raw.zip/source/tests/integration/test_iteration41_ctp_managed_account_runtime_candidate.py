"""Fake-only checks for the unregistered shared simulation/live composition."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from backtrader_runtime.ctp_managed_account_runtime_candidate import (
    CtpManagedActionAuthorityVerifierSlot,
    CtpManagedAccountRuntimeCandidateError,
    _account_family_digest,
)
from backtrader_runtime.ctp_managed_action_authority import (
    CtpManagedActionAuthorityAdapter,
    CtpManagedActionAuthorityError,
)


def test_deferred_authority_slot_rejects_until_one_exact_adapter_is_bound():
    slot = CtpManagedActionAuthorityVerifierSlot()
    command = object()
    with pytest.raises(CtpManagedActionAuthorityError):
        slot.verify_action(command, now_ns=123)

    adapter = object.__new__(CtpManagedActionAuthorityAdapter)
    calls = []
    adapter.verify_action = lambda value, *, now_ns: calls.append((value, now_ns)) or "ok"

    slot.bind(adapter)
    assert slot.bound is True
    assert slot.verify_action(command, now_ns=124) == "ok"
    assert calls == [(command, 124)]

    with pytest.raises(CtpManagedAccountRuntimeCandidateError):
        slot.bind(adapter)


def test_deferred_authority_slot_rejects_duck_verifier_and_never_reopens_after_close():
    slot = CtpManagedActionAuthorityVerifierSlot()
    with pytest.raises(CtpManagedAccountRuntimeCandidateError):
        slot.bind(SimpleNamespace(verify_action=lambda *_args, **_kwargs: object()))

    adapter = object.__new__(CtpManagedActionAuthorityAdapter)
    adapter.verify_action = lambda *_args, **_kwargs: "should not run"
    slot.bind(adapter)
    slot.close()
    assert slot.closed is True
    assert slot.bound is False
    with pytest.raises(CtpManagedActionAuthorityError):
        slot.verify_action(object(), now_ns=125)
    with pytest.raises(CtpManagedAccountRuntimeCandidateError):
        slot.bind(adapter)


@pytest.mark.parametrize(
    "account_ref",
    [
        "broker-user",
        "ctp-account-ref.v1:" + "A" * 64,
        "ctp-account-ref.v1:" + "0" * 63,
        "ctp-account-ref.v1:" + "0" * 64 + ":extra",
    ],
)
def test_account_family_lock_key_requires_canonical_opaque_ctp_account_ref(account_ref):
    with pytest.raises(CtpManagedAccountRuntimeCandidateError):
        _account_family_digest(SimpleNamespace(account_ref=account_ref))


def test_account_family_lock_key_is_mode_independent_and_never_uses_account_key():
    account_ref = "ctp-account-ref.v1:" + "a" * 64
    simulation = SimpleNamespace(account_ref=account_ref, account_key="account:" + "1" * 64)
    live = SimpleNamespace(account_ref=account_ref, account_key="account:" + "2" * 64)
    assert _account_family_digest(simulation) == "a" * 64
    assert _account_family_digest(live) == "a" * 64


@pytest.mark.parametrize("suffix", ["", "-wal", "-shm"])
def test_legacy_journal_or_sqlite_sidecar_blocks_the_new_account_ledger(tmp_path, suffix):
    from backtrader_runtime.ctp_managed_account_runtime_candidate import (
        CtpManagedAccountRuntimeCandidate,
    )

    state_root = tmp_path / "ctp_simnow_execution"
    journal_dir = state_root / "journals"
    journal_dir.mkdir(parents=True)
    journal = journal_dir / ("a" * 64 + ".sqlite3")
    CtpManagedAccountRuntimeCandidate._require_legacy_journal_absent(state_root, "a" * 64)
    (Path(str(journal) + suffix)).write_bytes(b"offline synthetic legacy state")
    with pytest.raises(CtpManagedAccountRuntimeCandidateError):
        CtpManagedAccountRuntimeCandidate._require_legacy_journal_absent(state_root, "a" * 64)
