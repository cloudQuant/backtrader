# Iteration 41 risk cancel dispatch resolution slice

- Source base: `d4bc03047ebfc2b416259aba313fafca7a0dffcc` in `D:\bt_api_risk_ac41_48_candidate_20260926`.
- Frozen source snapshot: `D:\temp\iteration41_risk_cancel_resolution_20260927`.
- Risk API: `DurableRiskGate.resolve_cancel_dispatch_freeze(CancelDispatchResolutionProof)`, guarded by exact `VerifiedCancelDispatchResolution` from `cancel_dispatch_resolution_guard(proof, *, claim)`.
- Semantics: only typed terminal cancel-action facts (`CANCELLED` plus exact target-terminal postcondition, or `REJECTED` with target still ACKED/PARTIALLY_FILLED) can clear the cancel-specific latch. The cancel permit is settled, never marked `NO_FILL`; target-order exposure reservations are unchanged. Generic order `CANCELED_NO_FILL` is explicitly rejected for CANCEL permits.
- Tests: full package `222 passed, 1 existing pytest config warning`; focused durable risk plus cancellation proof `72 passed, 1 warning`; Ruff passes. Full tests used `-p no:asyncio` because this host's auto-loaded pytest-asyncio plugin errors while collecting the package root; no async tests are part of the risk package suite.
- Trust boundary: test authorities are fake-only. This slice does not supply a production issuer or connect execution/provider/native code. Parent proof construction/guard and main bridge wiring are separate pending integrations.
- File hashes and exact commands are in `risk-cancel-resolution-manifest.json`.