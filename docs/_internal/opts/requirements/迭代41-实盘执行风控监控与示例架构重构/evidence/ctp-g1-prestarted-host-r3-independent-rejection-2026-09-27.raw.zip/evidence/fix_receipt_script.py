from pathlib import Path
path = Path(r"D:\temp\g1-host-qa-20260927\evidence\make_receipt.py")
s = path.read_text(encoding="utf-8-sig")
old = '''for row in manifest["source_snapshots"]:
    snap, current = row["snapshot"], row["main_current"]
    check(snap["path"], snap["sha256"], snap["size"], "source_snapshot")
    check(current["path"], current["sha256"], current["size"], "main_current_record")
    snap_hash, _ = digest(snap["path"])
    current_hash, _ = digest(current["path"])
    actual_match = snap_hash.lower() == current_hash.lower()
    checks.append({
        "label": "snapshot_matches_main_current_flag",
        "path": row["repo_relative_path"],
        "expected": row["snapshot_matches_main_current"],
        "actual": actual_match,
        "ok": actual_match is row["snapshot_matches_main_current"],
    })
'''
new = '''live_main_drift = []
for row in manifest["source_snapshots"]:
    snap, current = row["snapshot"], row["main_current"]
    check(snap["path"], snap["sha256"], snap["size"], "source_snapshot")
    declared_match = snap["sha256"].lower() == current["sha256"].lower()
    checks.append({
        "label": "snapshot_matches_recorded_main_current_flag",
        "path": row["repo_relative_path"],
        "expected": row["snapshot_matches_main_current"],
        "actual": declared_match,
        "ok": declared_match is row["snapshot_matches_main_current"],
    })
    live_hash, live_size = digest(current["path"])
    live_main_drift.append({
        "path": row["repo_relative_path"],
        "recorded_main_current_sha256": current["sha256"],
        "recorded_main_current_size": current["size"],
        "actual_current_sha256": live_hash,
        "actual_current_size": live_size,
        "matches_manifest_record": live_hash.lower() == current["sha256"].lower() and live_size == current["size"],
    })
'''
assert old in s
s = s.replace(old, new)
old = '''    "all_content_checks_ok": all(item["ok"] for item in checks),
    "checks": checks,
'''
new = '''    "all_content_checks_ok": all(item["ok"] for item in checks),
    "checks": checks,
    "live_main_drift_count": sum(not item["matches_manifest_record"] for item in live_main_drift),
    "live_main_drift": live_main_drift,
'''
assert old in s
s = s.replace(old, new)
old = '''        "all_content_checks_ok": audit["all_content_checks_ok"],
    },
'''
new = '''        "all_content_checks_ok": audit["all_content_checks_ok"],
        "live_main_drift_count": audit["live_main_drift_count"],
        "live_main_drift": audit["live_main_drift"],
    },
'''
assert old in s
s = s.replace(old, new)
old = '''- Manifest content audit: `{audit["check_count"]}` checks; all passed
'''
new = '''- Manifest candidate/snapshot/evidence audit: `{audit["check_count"]}` immutable checks; all passed
- Mutable main-tree paths: `{audit["live_main_drift_count"]}` current hash drift(s) from the manifest snapshot
'''
assert old in s
s = s.replace(old, new)
old = '''4. **No native acceptance.** The candidate has no Windows Job/named-pipe backend; tests use a fake process-tree model only. This receipt is not real G1 acceptance.
'''
new = '''4. **No native acceptance.** The candidate has no Windows Job/named-pipe backend; tests use a fake process-tree model only. This receipt is not real G1 acceptance.
5. **Live main-tree drift.** The manifest records `scripts/ctp_i13_i15_windows_guardian_service.py` at SHA-256 `a493f272459316529ea4888df79883431784e10a06fe22995e9fa452bf019950`; during this QA it hashes to `03628b0613ecc9f49ff07f299c6f39162cd64bfd90c396c324473cd4f6104339` (180159 bytes). The frozen candidate snapshot itself still matches its manifest hash. This was recorded as drift; the main checkout was not edited by QA.
'''
assert old in s
s = s.replace(old, new)
path.write_text(s, encoding="utf-8")
