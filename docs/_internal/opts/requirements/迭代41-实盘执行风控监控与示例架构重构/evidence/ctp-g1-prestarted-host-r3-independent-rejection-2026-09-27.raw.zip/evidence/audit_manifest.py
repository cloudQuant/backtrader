import hashlib
import json
from pathlib import Path

manifest_path = Path(r"D:\temp\iteration41-g1-outer-host-deadline-candidate-20260927\candidate-manifest-r3.json")
manifest_bytes = manifest_path.read_bytes()
manifest_hash = hashlib.sha256(manifest_bytes).hexdigest()
manifest = json.loads(manifest_bytes)
checks = []

def check(path_text, expected_hash, expected_size, label):
    path = Path(path_text)
    raw = path.read_bytes()
    actual_hash = hashlib.sha256(raw).hexdigest()
    actual_size = len(raw)
    checks.append({
        "label": label,
        "path": str(path),
        "expected_sha256": expected_hash,
        "actual_sha256": actual_hash,
        "expected_size": expected_size,
        "actual_size": actual_size,
        "ok": actual_hash.lower() == expected_hash.lower() and actual_size == expected_size,
    })

for row in manifest["candidate_files"]:
    check(row["path"], row["sha256"], row["size"], "candidate_file")
for row in manifest["source_snapshots"]:
    snap = row["snapshot"]
    check(snap["path"], snap["sha256"], snap["size"], "source_snapshot")
    current = row["main_current"]
    check(current["path"], current["sha256"], current["size"], "main_current_record")
for key, row in [("prior_deadline_reproduction_receipt", manifest["prior_deadline_reproduction_receipt"])]:
    check(row["path"], row["sha256"], row["size"], key)
for item in manifest["verification"]["checks"]:
    log = item["log"]
    check(log["path"], log["sha256"], log["size"], "prior_log:" + item["name"])

qa_root = Path(r"D:\temp\g1-host-qa-20260927")
for rel in ["source/scripts/ctp_i13_i15_service_host_supervisor.py", "tests/test_service_host_supervisor.py"]:
    original = Path(manifest["candidate_root"]) / rel.replace("/", "\\")
    copied = qa_root / rel
    a, b = original.read_bytes(), copied.read_bytes()
    checks.append({
        "label": "qa_copy_matches_candidate",
        "path": str(copied),
        "expected_sha256": hashlib.sha256(a).hexdigest(),
        "actual_sha256": hashlib.sha256(b).hexdigest(),
        "expected_size": len(a),
        "actual_size": len(b),
        "ok": a == b,
    })

result = {
    "manifest_sha256": manifest_hash,
    "expected_manifest_sha256": "548cb59b4437c0784a75c186a714c180ce0305c9df8b3f5213321610d9f9b01a",
    "manifest_hash_ok": manifest_hash.lower() == "548cb59b4437c0784a75c186a714c180ce0305c9df8b3f5213321610d9f9b01a",
    "all_content_checks_ok": all(item["ok"] for item in checks),
    "checks": checks,
}
out = qa_root / "evidence" / "manifest-audit.json"
out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: result[k] for k in ("manifest_sha256", "manifest_hash_ok", "all_content_checks_ok")}, indent=2))
print(f"checks={len(checks)}")
for item in checks:
    if not item["ok"]:
        print(json.dumps(item))
