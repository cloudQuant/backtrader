# Independent G1 Service Host QA Receipt

- Verdict: **FAKE_MODEL_ONLY / NOT_ACCEPTED_AS_REAL_G1_OR_HARD_DEADLINE_PROOF**
- Candidate manifest SHA-256: `548cb59b4437c0784a75c186a714c180ce0305c9df8b3f5213321610d9f9b01a` (expected hash matched)
- Manifest candidate/snapshot/evidence audit: `31` immutable checks; all passed
- Mutable main-tree paths: `1` current hash drift(s) from the manifest snapshot
- Runtime: Windows, Python 3.11.5
- QA copy: `D:\temp\g1-host-qa-20260927`

## Test runs

- Baseline candidate tests: 6 passed. Log SHA-256 `642404456f3b209c232e9da78f30c010d7dcc57d0c7b83511e2c0c3028c3786d`.
- QA adversarial module: 17 passed, including five added adversarial cases. Log SHA-256 `190d2a9606b325bd83382f3ed79b693b0f770454e0f14f395ddf14c06db91c27`.
- Reproduction filter: 5 passed, 12 deselected. Cases: late readiness, release overrun, termination overrun, exit+empty with failed release, and concurrent double request. Log SHA-256 `9092ec21445de3c0024697fcd312c8a147be457bbd2d6353a4bcd30b4ba4738a`.

## Findings

1. **Late readiness acceptance.** `poll_host_ready()` can return true after the startup deadline; the code returns `ready` without a post-poll deadline check. Reproduced in the QA copy at `source/scripts/ctp_i13_i15_service_host_supervisor.py:283`.
2. **Unbounded synchronous backend calls.** Delayed fake `terminate_job()` and `release_controls()` both cause the helper to return after the request deadline. Adapter calls have no enforced timeout at the call boundary (`:503`, `:551`, `:577`).
3. **No integration call site.** Search found new helper references only inside its own module. Request admission ordering is a documented custodian obligation, not proven by an integrated listener.
4. **No native acceptance.** The candidate has no Windows Job/named-pipe backend; tests use a fake process-tree model only. This receipt is not real G1 acceptance.
5. **Live main-tree drift.** The manifest records `scripts/ctp_i13_i15_windows_guardian_service.py` at SHA-256 `a493f272459316529ea4888df79883431784e10a06fe22995e9fa452bf019950`; during this QA it hashes to `03628b0613ecc9f49ff07f299c6f39162cd64bfd90c396c324473cd4f6104339` (180159 bytes). The frozen candidate snapshot itself still matches its manifest hash. This was recorded as drift; the main checkout was not edited by QA.

Exit/empty/release behavior is fail-closed in the fake: exit plus empty plus failed release yields UNKNOWN and retains the host reference. The concurrent double-request test sends only one request. Prewarm blocking test checks helper-level admission only.

## Evidence

- JSON receipt: `D:\temp\g1-host-qa-20260927\evidence\qa-receipt.json` (SHA-256 `00001c61fff1311b34edb79d118f44e8aeb8cbbfae3d7bb9f17f6323a8992dad`, 12162 bytes)
- Manifest audit: `D:\temp\g1-host-qa-20260927\evidence\manifest-audit.json` (SHA-256 `91660f44407a333cb0e14b65a232c60852c4c69826354fe3b2ac4efd3e24adb2`, 15603 bytes)
- Test logs: `evidence/pytest-baseline.log`, `evidence/pytest-adversarial.log`, `evidence/pytest-negative-probes.log`
- QA-only tests: `tests/test_adversarial_qa.py` (SHA-256 `c8e9679f887ec3c28f3f2f33aeb772bc46e263edfea1607406b276be77912e56`)

