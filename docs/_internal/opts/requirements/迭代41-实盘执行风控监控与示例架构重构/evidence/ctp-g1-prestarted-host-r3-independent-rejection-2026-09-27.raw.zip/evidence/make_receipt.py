from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

candidate_root = Path(r"D:\temp\iteration41-g1-outer-host-deadline-candidate-20260927")
qa_root = Path(r"D:\temp\g1-host-qa-20260927")
manifest_path = candidate_root / "candidate-manifest-r3.json"
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)


def digest(path):
    raw = Path(path).read_bytes()
    return hashlib.sha256(raw).hexdigest(), len(raw)


checks = []
def check(path, expected_hash, expected_size, label):
    actual_hash, actual_size = digest(path)
    checks.append({
        "label": label,
        "path": str(path),
        "expected_sha256": expected_hash,
        "actual_sha256": actual_hash,
        "expected_size": expected_size,
        "actual_size": actual_size,
        "ok": actual_hash.lower() == expected_hash.lower() and actual_size == expected_size,
    })

for row in manifest["candidate_files"]:
    check(row["path"], row["sha256"], row["size"], "candidate_file")
live_main_drift = []
for row in manifest["source_snapshots"]:
    snap, current = row["snapshot"], row["main_current"]
    check(snap["path"], snap["sha256"], snap["size"], "source_snapshot")
    declared_match = snap["sha256"].lower() == current["sha256"].lower()
    checks.append({
        "label": "snapshot_matches_recorded_main_current_flag",
        "path": row["repo_relative_path"],
        "expected": row["snapshot_matches_main_current"],
        "actual": declared_match,
        "ok": declared_match is row["snapshot_matches_main_current"],
    })
    live_hash, live_size = digest(current["path"])
    live_main_drift.append({
        "path": row["repo_relative_path"],
        "recorded_main_current_sha256": current["sha256"],
        "recorded_main_current_size": current["size"],
        "actual_current_sha256": live_hash,
        "actual_current_size": live_size,
        "matches_manifest_record": live_hash.lower() == current["sha256"].lower() and live_size == current["size"],
    })
for row in manifest["prior_manifests"]:
    path = Path(row["path"])
    actual_hash, _ = digest(path)
    checks.append({
        "label": "prior_manifest_hash",
        "path": str(path),
        "expected_sha256": row["sha256"],
        "actual_sha256": actual_hash,
        "ok": actual_hash.lower() == row["sha256"].lower(),
    })
for key, row in [("prior_deadline_reproduction_receipt", manifest["prior_deadline_reproduction_receipt"])]:
    check(row["path"], row["sha256"], row["size"], key)
for item in manifest["verification"]["checks"]:
    log = item["log"]
    check(log["path"], log["sha256"], log["size"], "prior_log:" + item["name"])
for rel in ["source/scripts/ctp_i13_i15_service_host_supervisor.py", "tests/test_service_host_supervisor.py"]:
    original = candidate_root / Path(rel)
    copied = qa_root / Path(rel)
    original_hash, original_size = digest(original)
    copied_hash, copied_size = digest(copied)
    checks.append({
        "label": "qa_copy_matches_candidate",
        "path": str(copied),
        "expected_sha256": original_hash,
        "actual_sha256": copied_hash,
        "expected_size": original_size,
        "actual_size": copied_size,
        "ok": original_hash == copied_hash and original_size == copied_size,
    })

manifest_hash = hashlib.sha256(manifest_bytes).hexdigest()
expected_manifest_hash = "548cb59b4437c0784a75c186a714c180ce0305c9df8b3f5213321610d9f9b01a"
audit = {
    "manifest_path": str(manifest_path),
    "manifest_sha256": manifest_hash,
    "expected_manifest_sha256": expected_manifest_hash,
    "manifest_hash_ok": manifest_hash.lower() == expected_manifest_hash.lower(),
    "check_count": len(checks),
    "all_content_checks_ok": all(item["ok"] for item in checks),
    "checks": checks,
    "live_main_drift_count": sum(not item["matches_manifest_record"] for item in live_main_drift),
    "live_main_drift": live_main_drift,
}
audit_path = qa_root / "evidence" / "manifest-audit.json"
audit_path.write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
audit_hash, audit_size = digest(audit_path)

file_rows = []
for rel in [
    "evidence/python-version.log",
    "evidence/pytest-baseline.log",
    "evidence/pytest-baseline-exit.txt",
    "evidence/pytest-adversarial.log",
    "evidence/pytest-adversarial-exit.txt",
    "evidence/pytest-negative-probes.log",
    "evidence/pytest-negative-probes-exit.txt",
    "tests/test_adversarial_qa.py",
]:
    path = qa_root / Path(rel)
    sha, size = digest(path)
    file_rows.append({"path": str(path), "sha256": sha, "size": size})

receipt = {
    "schema": "g1-fake-prestarted-service-host-independent-qa.v1",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "candidate": {
        "root": str(candidate_root),
        "manifest": str(manifest_path),
        "manifest_sha256": manifest_hash,
        "expected_manifest_sha256": expected_manifest_hash,
        "manifest_hash_ok": audit["manifest_hash_ok"],
        "candidate_files": manifest["candidate_files"],
    },
    "qa_copy": str(qa_root),
    "manifest_audit": {
        "path": str(audit_path),
        "sha256": audit_hash,
        "size": audit_size,
        "checks": audit["check_count"],
        "all_content_checks_ok": audit["all_content_checks_ok"],
        "live_main_drift_count": audit["live_main_drift_count"],
        "live_main_drift": audit["live_main_drift"],
    },
    "runtime": {"platform": "Windows", "python": "Python 3.11.5"},
    "tests": [
        {
            "command": "python -m pytest -q tests/test_service_host_supervisor.py",
            "exit": 0,
            "result": "6 passed in 0.43s",
            "log": next(row for row in file_rows if row["path"].endswith("pytest-baseline.log")),
        },
        {
            "command": "python -m pytest -q tests/test_adversarial_qa.py",
            "exit": 0,
            "result": "17 passed in 0.58s; includes 5 added QA adversarial tests and repeated baseline cases",
            "log": next(row for row in file_rows if row["path"].endswith("pytest-adversarial.log")),
            "qa_test_source": next(row for row in file_rows if row["path"].endswith("test_adversarial_qa.py")),
        },
        {
            "command": "python -m pytest -q tests/test_adversarial_qa.py -k 'ready_poll or release_controls or terminate_call or release_failure or concurrent_double_request'",
            "exit": 0,
            "result": "5 passed, 12 deselected in 0.25s",
            "cases": [
                "test_ready_poll_can_return_ready_after_startup_deadline",
                "test_release_controls_can_overrun_request_deadline",
                "test_terminate_call_can_overrun_request_deadline",
                "test_release_failure_is_unknown_with_both_exit_and_empty_observed",
                "test_concurrent_double_request_claims_host_once",
            ],
            "log": next(row for row in file_rows if row["path"].endswith("pytest-negative-probes.log")),
        },
    ],
    "findings": [
        {
            "id": "G1-QA-1",
            "severity": "blocker for hard-deadline claim",
            "summary": "A late readiness poll can still return a ready host.",
            "evidence": "QA fake poll advances the monotonic clock past startup_deadline and returns True; prepare_service_host returns ready because it checks the deadline before the poll, but not again before issuing the handle.",
            "source": "source/scripts/ctp_i13_i15_service_host_supervisor.py:283",
        },
        {
            "id": "G1-QA-2",
            "severity": "blocker for hard-deadline claim",
            "summary": "Synchronous backend calls can return after request deadline.",
            "evidence": "QA fake release_controls and terminate_job each advance monotonic time beyond the deadline; supervise_prepared_request returns only after that overrun. These adapter methods have no enforced timeout at the call boundary.",
            "source": "source/scripts/ctp_i13_i15_service_host_supervisor.py:503,551,577",
        },
        {
            "id": "G1-QA-3",
            "severity": "integration blocker",
            "summary": "No service call site uses this supervisor.",
            "evidence": "A recursive search of candidate source found the new helper references only inside its own module; no listener/custodian startup or request dispatch integration is present.",
            "source": "source/scripts/ctp_i13_i15_service_host_supervisor.py",
        },
        {
            "id": "G1-QA-4",
            "severity": "acceptance limitation",
            "summary": "This candidate has no real Windows Job or named-pipe backend.",
            "evidence": "The candidate manifest explicitly limits its test scope to fake process/thread model and states that no Win32 Job or named-pipe API is invoked. Tests do not exercise native containment or a provider.",
            "source": str(manifest_path),
        },
    ],
    "adversarial_coverage": {
        "prewarm_admission": "Existing fake test confirms no PreparedServiceHost is returned and a request without one is rejected while Create/Job setup is blocked; it does not exercise an integrated listener.",
        "job_exit_empty_release": "Candidate success path observes launcher exit, Job empty, then release. Added QA test makes release fail and verifies UNKNOWN, containment false, and retained host reference.",
        "unknown_cleanup": "Candidate test for Job nonempty after termination verifies UNKNOWN and preserves the PreparedServiceHost reference.",
        "double_request": "Added concurrent race test verifies the single-use lock sends at most one request through the fake host.",
    },
    "verdict": "FAKE_MODEL_ONLY / NOT_ACCEPTED_AS_REAL_G1_OR_HARD_DEADLINE_PROOF",
    "scope": "No main checkout edits, credential reads, provider connections, service install/start, SDK imports for provider work, or native CTP activity were performed.",
    "evidence_files": file_rows,
}
receipt_path = qa_root / "evidence" / "qa-receipt.json"
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
receipt_hash, receipt_size = digest(receipt_path)

md = f'''# Independent G1 Service Host QA Receipt

- Verdict: **{receipt["verdict"]}**
- Candidate manifest SHA-256: `{manifest_hash}` (expected hash matched)
- Manifest candidate/snapshot/evidence audit: `{audit["check_count"]}` immutable checks; all passed
- Mutable main-tree paths: `{audit["live_main_drift_count"]}` current hash drift(s) from the manifest snapshot
- Runtime: Windows, Python 3.11.5
- QA copy: `{qa_root}`

## Test runs

- Baseline candidate tests: 6 passed. Log SHA-256 `{receipt["tests"][0]["log"]["sha256"]}`.
- QA adversarial module: 17 passed, including five added adversarial cases. Log SHA-256 `{receipt["tests"][1]["log"]["sha256"]}`.
- Reproduction filter: 5 passed, 12 deselected. Cases: late readiness, release overrun, termination overrun, exit+empty with failed release, and concurrent double request. Log SHA-256 `{receipt["tests"][2]["log"]["sha256"]}`.

## Findings

1. **Late readiness acceptance.** `poll_host_ready()` can return true after the startup deadline; the code returns `ready` without a post-poll deadline check. Reproduced in the QA copy at `source/scripts/ctp_i13_i15_service_host_supervisor.py:283`.
2. **Unbounded synchronous backend calls.** Delayed fake `terminate_job()` and `release_controls()` both cause the helper to return after the request deadline. Adapter calls have no enforced timeout at the call boundary (`:503`, `:551`, `:577`).
3. **No integration call site.** Search found new helper references only inside its own module. Request admission ordering is a documented custodian obligation, not proven by an integrated listener.
4. **No native acceptance.** The candidate has no Windows Job/named-pipe backend; tests use a fake process-tree model only. This receipt is not real G1 acceptance.
5. **Live main-tree drift.** The manifest records `scripts/ctp_i13_i15_windows_guardian_service.py` at SHA-256 `a493f272459316529ea4888df79883431784e10a06fe22995e9fa452bf019950`; during this QA it hashes to `03628b0613ecc9f49ff07f299c6f39162cd64bfd90c396c324473cd4f6104339` (180159 bytes). The frozen candidate snapshot itself still matches its manifest hash. This was recorded as drift; the main checkout was not edited by QA.

Exit/empty/release behavior is fail-closed in the fake: exit plus empty plus failed release yields UNKNOWN and retains the host reference. The concurrent double-request test sends only one request. Prewarm blocking test checks helper-level admission only.

## Evidence

- JSON receipt: `{receipt_path}` (SHA-256 `{receipt_hash}`, {receipt_size} bytes)
- Manifest audit: `{audit_path}` (SHA-256 `{audit_hash}`, {audit_size} bytes)
- Test logs: `evidence/pytest-baseline.log`, `evidence/pytest-adversarial.log`
- QA-only tests: `tests/test_adversarial_qa.py` (SHA-256 `{next(row["sha256"] for row in file_rows if row["path"].endswith("test_adversarial_qa.py"))}`)
'''
md_path = qa_root / "evidence" / "qa-receipt.md"
md_path.write_text(md, encoding="utf-8")
md_hash, md_size = digest(md_path)
print(json.dumps({
    "manifest_sha256": manifest_hash,
    "manifest_hash_ok": audit["manifest_hash_ok"],
    "audit_checks": audit["check_count"],
    "all_content_checks_ok": audit["all_content_checks_ok"],
    "receipt_path": str(receipt_path),
    "receipt_sha256": receipt_hash,
    "receipt_size": receipt_size,
    "markdown_path": str(md_path),
    "markdown_sha256": md_hash,
    "markdown_size": md_size,
}, indent=2))
