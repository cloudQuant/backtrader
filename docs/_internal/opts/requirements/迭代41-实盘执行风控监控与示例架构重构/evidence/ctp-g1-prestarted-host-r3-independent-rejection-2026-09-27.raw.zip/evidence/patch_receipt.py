from pathlib import Path
p = Path(r"D:\temp\g1-host-qa-20260927\evidence\make_receipt.py")
s = p.read_text(encoding="utf-8")
s = s.replace('''    "evidence/pytest-adversarial.log",
    "evidence/pytest-adversarial-exit.txt",
    "tests/test_adversarial_qa.py",
''','''    "evidence/pytest-adversarial.log",
    "evidence/pytest-adversarial-exit.txt",
    "evidence/pytest-negative-probes.log",
    "evidence/pytest-negative-probes-exit.txt",
    "tests/test_adversarial_qa.py",
''')
s = s.replace('''            "qa_test_source": next(row for row in file_rows if row["path"].endswith("test_adversarial_qa.py")),
        },
    ],
''','''            "qa_test_source": next(row for row in file_rows if row["path"].endswith("test_adversarial_qa.py")),
        },
        {
            "command": "python -m pytest -q tests/test_adversarial_qa.py -k 'ready_poll or release_controls or terminate_call or release_failure or concurrent_double_request'",
            "exit": 0,
            "result": "5 passed, 12 deselected in 0.25s",
            "cases": [
                "test_ready_poll_can_return_ready_after_startup_deadline",
                "test_release_controls_can_overrun_request_deadline",
                "test_terminate_call_can_overrun_request_deadline",
                "test_release_failure_is_unknown_with_both_exit_and_empty_observed",
                "test_concurrent_double_request_claims_host_once",
            ],
            "log": next(row for row in file_rows if row["path"].endswith("pytest-negative-probes.log")),
        },
    ],
''')
s = s.replace('''- QA adversarial module: 17 passed, including five added adversarial cases. Log SHA-256 `{receipt["tests"][1]["log"]["sha256"]}`.
''','''- QA adversarial module: 17 passed, including five added adversarial cases. Log SHA-256 `{receipt["tests"][1]["log"]["sha256"]}`.
- Reproduction filter: 5 passed, 12 deselected. Cases: late readiness, release overrun, termination overrun, exit+empty with failed release, and concurrent double request. Log SHA-256 `{receipt["tests"][2]["log"]["sha256"]}`.
''')
p.write_text(s, encoding="utf-8")
