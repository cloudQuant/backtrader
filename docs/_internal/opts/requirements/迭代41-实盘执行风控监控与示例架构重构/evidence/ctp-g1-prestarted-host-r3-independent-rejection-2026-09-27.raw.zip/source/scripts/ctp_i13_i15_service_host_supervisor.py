"""Prestarted outer Job gate for the one-request G1 service-host candidate.

This isolated, unregistered contract deliberately separates host startup from
request admission. A trusted long-lived custodian must call
``prepare_service_host`` before it accepts any request. The returned
``PreparedServiceHost`` proves that the fixed one-request service host already
exists, is assigned to the outer Job, has resumed, and reported ready. The
per-request path accepts only that prepared handle and never calls
CreateProcess, creates a Job, or runs service code in the caller.

The prepared child contains the full synchronous G1 operation: anchor and
dependency verification, inner launcher/Job creation, coordinator/worker
stages, and receipt creation. If one of those calls blocks, the custodian can
terminate the outer Job and verify the entire fake process tree is empty.

The startup/prewarm call itself is outside a request deadline. If its native
CreateProcess/Job setup blocks, no PreparedServiceHost is returned and the
listener must not accept a request. The persistent custodian/SCM lifecycle
must supervise or restart startup separately. In particular, this helper does
not claim it can interrupt a native process-creation call on its own stack.

All results are process-containment facts only. Child exit, stdout, or a
successful drain never means that the readonly operation was observed. The
coordinator/writer/worker role parsers remain separate and must authenticate
any application receipt after outer Job-empty proof.
"""

# Preserve Python 3.8 syntax; broad backend exceptions map to fail-closed
# UNKNOWN results because native process/Job adapters may raise OS-specific errors.
# ruff: noqa: UP045, BLE001
from __future__ import annotations

import math
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Optional

from scripts.ctp_i13_i15_outer_watchdog import (
    FixedOuterCommand,
    OuterProcessEvidence,
    OuterWatchdogBackend,
    OuterWatchdogResult,
    _valid_retention_token,
)

DEFAULT_CLEANUP_RESERVE_SECONDS = 2.0
MAX_REQUEST_BYTES = 64 * 1024
MAX_POLL_INTERVAL_SECONDS = 0.25
_PREPARED_HOST_TOKEN = object()


class ServiceHostPreparationError(ValueError):
    """The fixed one-request host is not safe to admit work."""


@dataclass(frozen=True)
class PreparedServiceHost:
    """One single-use process/Job session created before request admission."""

    _session: object = field(repr=False, compare=False)
    _backend: object = field(repr=False, compare=False)
    _ready: bool = field(repr=False, compare=False)
    _token: object = field(repr=False, compare=False)
    _lock: object = field(default_factory=threading.Lock, repr=False, compare=False)
    _consumed: bool = field(default=False, repr=False, compare=False)

    def __post_init__(self):
        if self._token is not _PREPARED_HOST_TOKEN or self._ready is not True:
            raise ServiceHostPreparationError("prepared_service_host_proof_invalid")

    def _claim(self):
        with self._lock:
            if self._consumed:
                raise ServiceHostPreparationError("prepared_service_host_already_consumed")
            object.__setattr__(self, "_consumed", True)
            return self._session, self._backend


@dataclass(frozen=True)
class HostPreparationResult:
    state: str
    reason: str
    host: Optional[PreparedServiceHost]
    job_assignment_proven: bool
    startup_blocked_outside_request_deadline: bool = False


@dataclass(frozen=True)
class PreparedRequestResult:
    state: str
    reason: str
    containment_proven: bool
    watchdog: OuterWatchdogResult
    request_sent: Optional[bool] = None
    application_result: str = "unobserved"
    retained_host: Optional[PreparedServiceHost] = field(
        default=None, repr=False, compare=False
    )


def _to_finite_float(value: object, reason: str) -> float:
    if type(value) not in (int, float):
        raise ValueError(reason)
    try:
        result = float(value)
    except (OverflowError, ValueError, TypeError):
        raise ValueError(reason) from None
    if not math.isfinite(result):
        raise ValueError(reason)
    return result


def _poll_interval(value: object) -> float:
    result = _to_finite_float(value, "service_host_poll_interval_invalid")
    if not 0.0 < result <= MAX_POLL_INTERVAL_SECONDS:
        raise ServiceHostPreparationError("service_host_poll_interval_invalid")
    return result


def _session_poll_ready(session: object) -> Optional[bool]:
    poll_ready = getattr(session, "poll_host_ready", None)
    if not callable(poll_ready):
        return None
    try:
        value = poll_ready()
    except Exception:
        return None
    return value if type(value) is bool else None


def _session_job_assignment_proven(session: object) -> bool:
    try:
        return (
            getattr(session, "process_created", None) is True
            and getattr(session, "job_assignment_observed", None) is True
        )
    except Exception:
        return False


def _terminate_prepared_session(session: object, backend: object):
    """Best-effort startup rollback; returns (drained, retained)."""

    try:
        terminated = session.terminate_job()
    except Exception:
        terminated = None
    try:
        exit_code = session.poll_launcher_exit_code()
    except Exception:
        exit_code = None
    try:
        empty = session.poll_job_empty()
    except Exception:
        empty = None
    if (
        _session_job_assignment_proven(session)
        and terminated is True
        and type(exit_code) is int
        and empty is True
    ):
        try:
            released = session.release_controls()
        except Exception:
            released = False
        if released is True:
            return True, False
    try:
        retained = backend.retain_controls(session)
    except Exception:
        retained = None
    return False, retained is not None


def prepare_service_host(
    command: FixedOuterCommand,
    *,
    backend: OuterWatchdogBackend,
    startup_deadline_monotonic: float,
    monotonic: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
    poll_interval_seconds: float = 0.05,
) -> HostPreparationResult:
    """Prestart one fixed host before accepting any request.

    This function belongs in the persistent service custodian's startup path,
    before opening/accepting the request endpoint. ``poll_host_ready`` must be
    a nonblocking read from the fixed readiness channel. A timeout or failure
    yields no usable host handle. The CreateProcess/Job setup call itself is
    synchronous; if it blocks, the caller is stuck in prewarm and must not
    accept work. That is a startup availability failure, not an accepted
    request that can be claimed to have met its deadline.
    """

    if type(command) is not FixedOuterCommand:
        raise ServiceHostPreparationError("fixed_service_host_command_required")
    deadline = _to_finite_float(
        startup_deadline_monotonic, "service_host_startup_deadline_invalid"
    )
    if not callable(monotonic) or not callable(sleep):
        raise TypeError("service_host_clock_invalid")
    interval = _poll_interval(poll_interval_seconds)
    create = getattr(backend, "create_suspended_in_job", None)
    retain = getattr(backend, "retain_controls", None)
    if not callable(create) or not callable(retain):
        raise ServiceHostPreparationError("service_host_backend_invalid")
    try:
        now = _to_finite_float(monotonic(), "service_host_clock_invalid")
    except Exception:
        return HostPreparationResult("unknown", "startup_clock_unavailable", None, False)
    if now >= deadline:
        return HostPreparationResult("not_ready", "startup_deadline_expired", None, False)

    try:
        session = create(command, deadline_monotonic=deadline)
    except Exception:
        # No request handle is ever emitted for uncertain native creation.
        return HostPreparationResult("unknown", "host_creation_unconfirmed", None, False)
    try:
        if _to_finite_float(monotonic(), "service_host_clock_invalid") >= deadline:
            drained, retained = _terminate_prepared_session(session, backend)
            return HostPreparationResult(
                "not_ready" if drained else "unknown",
                "host_creation_returned_after_startup_deadline",
                None,
                _session_job_assignment_proven(session),
                startup_blocked_outside_request_deadline=not drained and retained,
            )
    except Exception:
        drained, retained = _terminate_prepared_session(session, backend)
        return HostPreparationResult(
            "unknown",
            "startup_clock_unavailable_after_creation",
            None,
            _session_job_assignment_proven(session),
            startup_blocked_outside_request_deadline=not drained and retained,
        )
    try:
        created = getattr(session, "process_created", None)
        assigned = getattr(session, "job_assignment_observed", None)
    except Exception:
        created = assigned = None
    if created is not True or assigned is not True:
        drained, retained = _terminate_prepared_session(session, backend)
        return HostPreparationResult(
            "unknown",
            "host_creation_or_job_assignment_unconfirmed",
            None,
            _session_job_assignment_proven(session),
            startup_blocked_outside_request_deadline=not drained and retained,
        )
    try:
        resumed = session.resume_launcher()
    except Exception:
        resumed = None
    if resumed is not True:
        drained, retained = _terminate_prepared_session(session, backend)
        return HostPreparationResult(
            "not_ready" if drained else "unknown",
            "host_resume_unconfirmed",
            None,
            _session_job_assignment_proven(session),
            startup_blocked_outside_request_deadline=not drained and retained,
        )

    while True:
        try:
            now = _to_finite_float(monotonic(), "service_host_clock_invalid")
        except Exception:
            now = deadline
        if now >= deadline:
            drained, retained = _terminate_prepared_session(session, backend)
            return HostPreparationResult(
                "not_ready" if drained else "unknown",
                "host_readiness_deadline_exceeded",
                None,
                _session_job_assignment_proven(session),
                startup_blocked_outside_request_deadline=not drained and retained,
            )
        ready = _session_poll_ready(session)
        if ready is True:
            return HostPreparationResult(
                "ready",
                "fixed_host_ready_before_request_admission",
                PreparedServiceHost(
                    _session=session,
                    _backend=backend,
                    _ready=True,
                    _token=_PREPARED_HOST_TOKEN,
                ),
                True,
            )
        if ready is None:
            drained, retained = _terminate_prepared_session(session, backend)
            return HostPreparationResult(
                "unknown" if not drained else "not_ready",
                "host_readiness_unobserved",
                None,
                _session_job_assignment_proven(session),
                startup_blocked_outside_request_deadline=not drained and retained,
            )
        remaining = deadline - now
        try:
            sleep(min(interval, remaining))
        except Exception:
            drained, retained = _terminate_prepared_session(session, backend)
            return HostPreparationResult(
                "unknown" if not drained else "not_ready",
                "host_readiness_wait_failed",
                None,
                _session_job_assignment_proven(session),
                startup_blocked_outside_request_deadline=not drained and retained,
            )


def _evidence_result(
    *,
    session: object,
    backend: object,
    state: str,
    reason: str,
    created: bool,
    assigned: bool,
    resumed: bool,
    request_sent: Optional[bool],
    termination_requested: bool,
    termination_succeeded: Optional[bool],
    exit_code: Optional[int],
    exit_observed: Optional[bool],
    job_empty: Optional[bool],
    released: Optional[bool],
    deadline: float,
    host: PreparedServiceHost,
    monotonic: Callable[[], float],
) -> PreparedRequestResult:
    retained = False
    retention_token = None
    drained = (
        created is True
        and assigned is True
        and exit_observed is True
        and job_empty is True
        and released is True
    )
    if not drained and termination_requested:
        try:
            now = _to_finite_float(monotonic(), "service_host_clock_invalid")
        except Exception:
            now = deadline
        # Custody transfer is allowed only while the original hard deadline
        # still has budget; never make a cleanup call after the deadline.
        if now < deadline:
            try:
                token = backend.retain_controls(session)
            except Exception:
                token = None
            if _valid_retention_token(token):
                retained = True
                retention_token = token
    evidence = OuterProcessEvidence(
        process_created=created,
        job_assignment_observed=assigned,
        launcher_resumed=resumed,
        launcher_exit_observed=exit_observed,
        launcher_exit_code=exit_code,
        launcher_termination_requested=False,
        launcher_termination_call_succeeded=None,
        job_termination_requested=termination_requested,
        job_termination_call_succeeded=termination_succeeded,
        job_empty_observed=job_empty,
        containment="verified" if drained else "unknown",
        controls_retained=retained if not drained else False,
        retention_token=retention_token,
    )
    watchdog = OuterWatchdogResult(
        state=state,
        reason=reason,
        evidence=evidence,  # same immutable shape as the ordinary outer watchdog
    )
    return PreparedRequestResult(
        state=state,
        reason=reason,
        containment_proven=drained,
        watchdog=watchdog,
        request_sent=request_sent,
        retained_host=None if drained else host,
    )


def supervise_prepared_request(
    host: PreparedServiceHost,
    request_raw: bytes,
    *,
    deadline_monotonic: float,
    cleanup_reserve_seconds: float = DEFAULT_CLEANUP_RESERVE_SECONDS,
    monotonic: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
    poll_interval_seconds: float = 0.05,
) -> PreparedRequestResult:
    """Send one request to an already-ready host and supervise its outer Job.

    The operation performs no backend process or Job creation. ``send_request``
    must be a nonblocking fixed-channel send (for Windows, overlapped I/O). The
    host handle is single-use and consumed before transmission, so retries use
    a newly prepared host outside the accepted request.
    """

    if type(host) is not PreparedServiceHost or host._token is not _PREPARED_HOST_TOKEN:
        raise ServiceHostPreparationError("prepared_service_host_required")
    if type(request_raw) is not bytes or not 0 < len(request_raw) <= MAX_REQUEST_BYTES:
        raise ServiceHostPreparationError("service_host_request_bytes_invalid")
    deadline = _to_finite_float(deadline_monotonic, "service_host_deadline_invalid")
    cleanup_reserve = _to_finite_float(
        cleanup_reserve_seconds, "service_host_cleanup_reserve_invalid"
    )
    if cleanup_reserve <= 0.0:
        raise ServiceHostPreparationError("service_host_cleanup_reserve_invalid")
    if not callable(monotonic) or not callable(sleep):
        raise TypeError("service_host_clock_invalid")
    interval = _poll_interval(poll_interval_seconds)
    session, backend = host._claim()
    try:
        created = getattr(session, "process_created", None) is True
        assigned = getattr(session, "job_assignment_observed", None) is True
    except Exception:
        created = assigned = False
    if not created or not assigned:
        return _evidence_result(
            session=session, backend=backend, state="unknown",
            reason="prepared_host_identity_lost", created=created,
            assigned=assigned, resumed=True, request_sent=None,
            termination_requested=False, termination_succeeded=None,
            exit_code=None, exit_observed=None, job_empty=None, released=None,
            deadline=deadline,
            host=host, monotonic=monotonic,
        )

    try:
        now = _to_finite_float(monotonic(), "service_host_clock_invalid")
    except Exception:
        now = deadline
    stop_deadline = deadline - cleanup_reserve
    if now >= stop_deadline or now >= deadline:
        return _terminate_for_request_deadline(
            session, backend, deadline=deadline, monotonic=monotonic, sleep=sleep,
            host=host,
            poll_interval_seconds=float(poll_interval_seconds), reason="request_deadline_too_close",
            request_sent=False,
        )

    send = getattr(session, "send_request_nonblocking", None)
    if not callable(send):
        return _terminate_for_request_deadline(
            session, backend, deadline=deadline, monotonic=monotonic, sleep=sleep,
            host=host,
            poll_interval_seconds=float(poll_interval_seconds), reason="request_channel_unavailable",
            request_sent=False,
        )
    try:
        sent = send(request_raw, deadline_monotonic=deadline)
    except Exception:
        sent = None
    if sent is not True:
        return _terminate_for_request_deadline(
            session, backend, deadline=deadline, monotonic=monotonic, sleep=sleep,
            host=host,
            poll_interval_seconds=float(poll_interval_seconds), reason="request_send_unconfirmed",
            request_sent=False if sent is False else None,
        )

    while True:
        try:
            now = _to_finite_float(monotonic(), "service_host_clock_invalid")
        except Exception:
            now = deadline
        if now >= stop_deadline:
            return _terminate_for_request_deadline(
                session, backend, deadline=deadline, monotonic=monotonic, sleep=sleep,
                host=host,
                poll_interval_seconds=interval, reason="request_deadline_exceeded",
                request_sent=True,
            )
        try:
            exit_code = session.poll_launcher_exit_code()
        except Exception:
            exit_code = None
        if exit_code is not None:
            if type(exit_code) is not int:
                return _terminate_for_request_deadline(
                    session, backend, deadline=deadline, monotonic=monotonic,
                    host=host,
                    sleep=sleep, poll_interval_seconds=interval,
                    reason="host_exit_code_invalid", request_sent=True,
                )
            try:
                empty = session.poll_job_empty()
            except Exception:
                empty = None
            if empty is True:
                try:
                    released = session.release_controls()
                except Exception:
                    released = False
                now = _to_finite_float(monotonic(), "service_host_clock_invalid")
                if released is True:
                    state = "completed" if now < deadline else "deadline_exceeded"
                    reason = "host_exited_job_empty" if now < deadline else "request_deadline_exceeded"
                    return _evidence_result(
                        session=session, backend=backend, state=state, reason=reason,
                        created=True, assigned=True, resumed=True, request_sent=True,
                        termination_requested=False, termination_succeeded=None,
                        exit_code=exit_code, exit_observed=True, job_empty=True,
                        released=True, deadline=deadline,
                        host=host, monotonic=monotonic,
                    )
            return _terminate_for_request_deadline(
                session, backend, deadline=deadline, monotonic=monotonic,
                host=host,
                sleep=sleep, poll_interval_seconds=interval,
                reason="host_job_cleanup_unconfirmed", request_sent=True,
            )
        remaining = stop_deadline - now
        if remaining <= 0.0:
            continue
        try:
            sleep(min(interval, remaining))
        except Exception:
            return _terminate_for_request_deadline(
                session, backend, deadline=deadline, monotonic=monotonic,
                host=host,
                sleep=sleep, poll_interval_seconds=interval,
                reason="host_watchdog_wait_failed", request_sent=True,
            )


def _terminate_for_request_deadline(
    session: object,
    backend: object,
    *,
    host: PreparedServiceHost,
    deadline: float,
    monotonic: Callable[[], float],
    sleep: Callable[[float], None],
    poll_interval_seconds: float,
    reason: str,
    request_sent: Optional[bool],
) -> PreparedRequestResult:
    try:
        terminate_result = session.terminate_job()
    except Exception:
        terminate_result = None
    exit_code = None
    exit_observed = None
    job_empty = None
    released = None
    while True:
        try:
            now = _to_finite_float(monotonic(), "service_host_clock_invalid")
        except Exception:
            now = deadline
        try:
            observed = session.poll_launcher_exit_code()
            if type(observed) is int:
                exit_code, exit_observed = observed, True
        except Exception:
            exit_code, exit_observed = None, None
        try:
            empty = session.poll_job_empty()
            if type(empty) is bool:
                job_empty = empty
        except Exception:
            job_empty = None
        if exit_observed is True and job_empty is True and terminate_result is True:
            try:
                released = session.release_controls()
            except Exception:
                released = False
            if released is True:
                return _evidence_result(
                    session=session, backend=backend, state="deadline_exceeded",
                    reason=reason, created=True, assigned=True, resumed=True,
                    request_sent=request_sent, termination_requested=True,
                    termination_succeeded=True, exit_code=exit_code,
                    exit_observed=True, job_empty=True, released=True,
                    deadline=deadline,
                    host=host, monotonic=monotonic,
                )
            break
        if now >= deadline:
            break
        remaining = deadline - now
        try:
            sleep(min(poll_interval_seconds, remaining))
        except Exception:
            break
    return _evidence_result(
        session=session, backend=backend, state="unknown",
        reason="outer_job_cleanup_unconfirmed", created=True, assigned=True,
        resumed=True, request_sent=request_sent, termination_requested=True,
        termination_succeeded=terminate_result if type(terminate_result) is bool else None,
        exit_code=exit_code, exit_observed=exit_observed,
        job_empty=job_empty, released=released, deadline=deadline,
        host=host, monotonic=monotonic,
    )


__all__ = [
    "HostPreparationResult",
    "PreparedRequestResult",
    "PreparedServiceHost",
    "ServiceHostPreparationError",
    "prepare_service_host",
    "supervise_prepared_request",
]
