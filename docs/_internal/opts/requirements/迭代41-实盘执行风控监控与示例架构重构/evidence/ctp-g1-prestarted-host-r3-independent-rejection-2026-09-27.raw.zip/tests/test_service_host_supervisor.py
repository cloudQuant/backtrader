import sys
import threading
import time
import unittest
from pathlib import Path

CANDIDATE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CANDIDATE / "source"))

from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand
from scripts.ctp_i13_i15_service_host_supervisor import (
    ServiceHostPreparationError,
    prepare_service_host,
    supervise_prepared_request,
)


class FakeClock:
    def __init__(self, value=100.0):
        self.value = value
        self.lock = threading.Lock()

    def now(self):
        with self.lock:
            return self.value

    def sleep(self, seconds):
        with self.lock:
            self.value += seconds


class FakePrestartedServiceHost:
    """Fake OS process+Job already created before request admission."""

    def __init__(
        self,
        stage,
        *,
        finish_on_request=False,
        drain_on_kill=True,
        job_assignment_observed=True,
    ):
        self.stage = stage
        self.process_created = True
        self.job_assignment_observed = job_assignment_observed
        self.members = {"request-host", "service-child", "grandchild"}
        self.drain_on_kill = drain_on_kill
        self.finish_on_request = finish_on_request
        self.ready = True
        self.resumed = False
        self.request_frames = []
        self.entered_stage = threading.Event()
        self.killed = threading.Event()
        self.exited = threading.Event()
        self.exit_code = None
        self.controls_released = False
        self.operation_thread = None

    def resume_launcher(self):
        self.resumed = True
        return True

    def poll_host_ready(self):
        return self.ready

    def send_request_nonblocking(self, raw, *, deadline_monotonic):
        self.request_frames.append(bytes(raw))
        if self.finish_on_request:
            self.exit_code = 0
            self.members.clear()
            self.exited.set()
            return True

        def blocked_service_call():
            self.entered_stage.set()
            # Represents an uninterruptible synchronous call in the child:
            # verify_anchor, inner CreateProcess/Job creation, or create_receipt.
            self.killed.wait()
            self.exited.set()

        self.operation_thread = threading.Thread(target=blocked_service_call, daemon=True)
        self.operation_thread.start()
        return self.entered_stage.wait(timeout=1.0)

    def poll_launcher_exit_code(self):
        return self.exit_code if self.exited.is_set() else None

    def poll_job_empty(self):
        return not self.members

    def terminate_job(self):
        self.killed.set()
        if self.drain_on_kill:
            self.members.clear()
            self.exit_code = -9
            self.exited.set()
        return True

    def terminate_launcher_process(self):
        return self.terminate_job()

    def release_controls(self):
        self.controls_released = not self.members and self.exited.is_set()
        return self.controls_released


class FakeHostBackend:
    def __init__(
        self,
        stage="create_receipt",
        *,
        finish_on_request=False,
        drain_on_kill=True,
        job_assignment_observed=True,
    ):
        self.stage = stage
        self.finish_on_request = finish_on_request
        self.drain_on_kill = drain_on_kill
        self.job_assignment_observed = job_assignment_observed
        self.create_count = 0
        self.resume_count = 0
        self.session = None
        self.retention_calls = 0

    def create_suspended_in_job(self, command, *, deadline_monotonic):
        self.create_count += 1
        self.session = FakePrestartedServiceHost(
            self.stage,
            finish_on_request=self.finish_on_request,
            drain_on_kill=self.drain_on_kill,
            job_assignment_observed=self.job_assignment_observed,
        )
        return self.session

    def retain_controls(self, session):
        self.retention_calls += 1
        return "fake-custody-1"


class ServiceHostDeadlineTests(unittest.TestCase):
    def setUp(self):
        self.command = FixedOuterCommand(
            [sys.executable, "-I", "-S", "-c", "# fixed fake one-request host"],
            str(CANDIDATE),
            {},
        )

    def prepare(self, backend, clock):
        result = prepare_service_host(
            self.command,
            backend=backend,
            startup_deadline_monotonic=clock.now() + 10.0,
            monotonic=clock.now,
            sleep=clock.sleep,
            poll_interval_seconds=0.05,
        )
        self.assertEqual(result.state, "ready")
        self.assertTrue(result.job_assignment_proven)
        self.assertIsNotNone(result.host)
        return result.host

    def test_blocked_setup_inner_job_creation_and_late_receipt_hit_outer_job_deadline(self):
        for stage in ("verify_anchor", "inner_create_process_or_job", "create_receipt"):
            with self.subTest(stage=stage):
                clock = FakeClock()
                backend = FakeHostBackend(stage)
                host = self.prepare(backend, clock)
                create_count_at_accept = backend.create_count
                result = supervise_prepared_request(
                    host,
                    b"already-authenticated-fixed-request",
                    deadline_monotonic=clock.now() + 1.0,
                    cleanup_reserve_seconds=0.2,
                    monotonic=clock.now,
                    sleep=clock.sleep,
                    poll_interval_seconds=0.05,
                )
                session = backend.session
                self.assertEqual(backend.create_count, create_count_at_accept)
                self.assertEqual(backend.create_count, 1)
                self.assertEqual(session.request_frames, [b"already-authenticated-fixed-request"])
                self.assertTrue(session.entered_stage.is_set())
                self.assertEqual(result.state, "deadline_exceeded")
                self.assertEqual(result.application_result, "unobserved")
                self.assertTrue(result.containment_proven)
                self.assertEqual(result.watchdog.state, "deadline_exceeded")
                self.assertEqual(result.watchdog.evidence.containment, "verified")
                self.assertTrue(session.killed.is_set())
                self.assertTrue(session.exited.is_set())
                self.assertEqual(session.members, set())
                self.assertTrue(session.controls_released)
                session.operation_thread.join(timeout=0.5)
                self.assertFalse(session.operation_thread.is_alive())

    def test_no_request_is_admitted_until_prestart_create_and_job_assignment_return(self):
        entered_create = threading.Event()
        release_create = threading.Event()
        backend = FakeHostBackend()
        real_clock = time.monotonic
        result_box = {}

        class BlockingPrewarmBackend(FakeHostBackend):
            def create_suspended_in_job(self, command, *, deadline_monotonic):
                self.create_count += 1
                entered_create.set()
                release_create.wait()
                self.session = FakePrestartedServiceHost("receipt")
                return self.session

        backend = BlockingPrewarmBackend()
        thread = threading.Thread(
            target=lambda: result_box.setdefault(
                "result",
                prepare_service_host(
                    self.command,
                    backend=backend,
                    startup_deadline_monotonic=real_clock() + 0.1,
                    monotonic=real_clock,
                    poll_interval_seconds=0.01,
                ),
            ),
            daemon=True,
        )
        thread.start()
        self.assertTrue(entered_create.wait(timeout=1.0))
        time.sleep(0.15)
        with self.assertRaisesRegex(ServiceHostPreparationError, "prepared_service_host_required"):
            supervise_prepared_request(
                None,
                b"request",
                deadline_monotonic=real_clock() + 1.0,
                cleanup_reserve_seconds=0.1,
                monotonic=real_clock,
            )
        self.assertNotIn("result", result_box)
        release_create.set()
        thread.join(timeout=1.0)
        self.assertFalse(thread.is_alive())
        self.assertEqual(result_box["result"].state, "not_ready")
        self.assertIsNone(result_box["result"].host)
        self.assertEqual(backend.session.request_frames, [])
        self.assertFalse(backend.session.resumed)

    def test_missing_job_assignment_never_produces_a_prepared_host(self):
        clock = FakeClock()
        backend = FakeHostBackend(job_assignment_observed=False)
        result = prepare_service_host(
            self.command,
            backend=backend,
            startup_deadline_monotonic=clock.now() + 5.0,
            monotonic=clock.now,
            sleep=clock.sleep,
        )
        self.assertEqual(result.state, "unknown")
        self.assertFalse(result.job_assignment_proven)
        self.assertIsNone(result.host)
        self.assertFalse(backend.session.resumed)
        self.assertEqual(backend.session.request_frames, [])

    def test_request_path_is_single_use_and_does_not_create_another_process_or_job(self):
        clock = FakeClock()
        backend = FakeHostBackend(finish_on_request=True)
        host = self.prepare(backend, clock)
        result = supervise_prepared_request(
            host,
            b"fixed-request",
            deadline_monotonic=clock.now() + 5.0,
            cleanup_reserve_seconds=0.5,
            monotonic=clock.now,
            sleep=clock.sleep,
        )
        self.assertEqual(result.state, "completed")
        self.assertTrue(result.containment_proven)
        self.assertEqual(result.application_result, "unobserved")
        self.assertEqual(backend.create_count, 1)
        with self.assertRaisesRegex(ServiceHostPreparationError, "already_consumed"):
            supervise_prepared_request(
                host,
                b"replay",
                deadline_monotonic=clock.now() + 5.0,
                cleanup_reserve_seconds=0.5,
                monotonic=clock.now,
                sleep=clock.sleep,
            )
        self.assertEqual(backend.create_count, 1)

    def test_unproven_job_empty_keeps_host_reference_and_never_claims_drained(self):
        clock = FakeClock()
        backend = FakeHostBackend(drain_on_kill=False)
        host = self.prepare(backend, clock)
        result = supervise_prepared_request(
            host,
            b"fixed-request",
            deadline_monotonic=clock.now() + 0.6,
            cleanup_reserve_seconds=0.2,
            monotonic=clock.now,
            sleep=clock.sleep,
            poll_interval_seconds=0.05,
        )
        self.assertEqual(result.state, "unknown")
        self.assertFalse(result.containment_proven)
        self.assertIsNotNone(result.retained_host)
        self.assertIs(result.watchdog.evidence.job_empty_observed, False)
        self.assertEqual(result.application_result, "unobserved")

    def test_request_bytes_and_numeric_deadline_fail_closed(self):
        clock = FakeClock()
        backend = FakeHostBackend()
        host = self.prepare(backend, clock)
        with self.assertRaisesRegex(ValueError, "request_bytes_invalid"):
            supervise_prepared_request(
                host,
                b"",
                deadline_monotonic=clock.now() + 5,
                cleanup_reserve_seconds=0.5,
                monotonic=clock.now,
                sleep=clock.sleep,
            )
        self.assertEqual(backend.session.request_frames, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
