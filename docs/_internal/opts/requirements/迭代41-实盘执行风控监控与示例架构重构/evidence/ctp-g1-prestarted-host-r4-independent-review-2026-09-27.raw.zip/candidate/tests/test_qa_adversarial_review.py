import sys
import threading
import unittest
from pathlib import Path

# Isolated source-root insertion must precede candidate imports in this test.
# ruff: noqa: I001
CANDIDATE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CANDIDATE / "source"))

from scripts.ctp_i13_i15_outer_watchdog import FixedOuterCommand
from scripts.ctp_i13_i15_service_host_supervisor import (
    ServiceHostPreparationError,
    prepare_service_host,
    supervise_prepared_request,
)
from test_service_host_supervisor import (
    FakeClock,
    FakeHostBackend,
    FakePrestartedServiceHost,
)

class AdversarialQATests(unittest.TestCase):
    def setUp(self):
        self.command = FixedOuterCommand(
            [sys.executable, "-I", "-S", "-c", "# fixed fake one-request host"],
            str(CANDIDATE),
            {},
        )

    def prepare(self, backend, clock):
        result = prepare_service_host(
            self.command,
            backend=backend,
            startup_deadline_monotonic=clock.now() + 10.0,
            monotonic=clock.now,
            sleep=clock.sleep,
            poll_interval_seconds=0.05,
        )
        self.assertEqual(result.state, "ready")
        self.assertTrue(result.job_assignment_proven)
        self.assertIsNotNone(result.host)
        return result.host

    def test_ready_poll_return_after_startup_deadline_is_rejected(self):
        clock = FakeClock()

        class LateReadySession(FakePrestartedServiceHost):
            def poll_host_ready(self):
                clock.value += 2.0
                return True

        class Backend(FakeHostBackend):
            def create_suspended_in_job(self, command, *, deadline_monotonic):
                self.create_count += 1
                self.session = LateReadySession("late_ready")
                return self.session

        backend = Backend()
        result = prepare_service_host(
            self.command,
            backend=backend,
            startup_deadline_monotonic=clock.now() + 0.5,
            monotonic=clock.now,
            sleep=clock.sleep,
        )
        self.assertEqual(result.state, "not_ready")
        self.assertIsNone(result.host)
        self.assertEqual(
            result.reason,
            "host_readiness_returned_after_startup_deadline",
        )
        self.assertTrue(result.startup_operation_returned_after_deadline)
        self.assertGreater(clock.now(), 100.5)

    def test_release_controls_overrun_is_unknown(self):
        clock = FakeClock()

        class SlowReleaseSession(FakePrestartedServiceHost):
            def release_controls(self):
                clock.value += 6.0
                self.controls_released = True
                return True

        class Backend(FakeHostBackend):
            def create_suspended_in_job(self, command, *, deadline_monotonic):
                self.create_count += 1
                self.session = SlowReleaseSession("quick", finish_on_request=True)
                return self.session

        backend = Backend()
        host = self.prepare(backend, clock)
        deadline = clock.now() + 5.0
        result = supervise_prepared_request(
            host, b"request", deadline_monotonic=deadline,
            cleanup_reserve_seconds=0.2, monotonic=clock.now, sleep=clock.sleep,
        )
        self.assertEqual(result.state, "unknown")
        self.assertEqual(result.reason, "control_release_returned_after_deadline")
        self.assertTrue(result.operation_returned_after_deadline)
        self.assertTrue(result.containment_proven)
        self.assertGreater(clock.now(), deadline)

    def test_release_failure_is_unknown_with_both_exit_and_empty_observed(self):
        clock = FakeClock()

        class ReleaseFailureSession(FakePrestartedServiceHost):
            def release_controls(self):
                self.controls_released = False
                return False

        class Backend(FakeHostBackend):
            def create_suspended_in_job(self, command, *, deadline_monotonic):
                self.create_count += 1
                self.session = ReleaseFailureSession("quick", finish_on_request=True)
                return self.session

        backend = Backend()
        host = self.prepare(backend, clock)
        result = supervise_prepared_request(
            host, b"request", deadline_monotonic=clock.now() + 5.0,
            cleanup_reserve_seconds=0.5, monotonic=clock.now, sleep=clock.sleep,
        )
        self.assertEqual(result.state, "unknown")
        self.assertFalse(result.containment_proven)
        self.assertTrue(result.watchdog.evidence.launcher_exit_observed)
        self.assertTrue(result.watchdog.evidence.job_empty_observed)
        self.assertFalse(result.watchdog.evidence.controls_retained is False)
        self.assertIsNotNone(result.retained_host)

    def test_terminate_call_overrun_is_unknown(self):
        clock = FakeClock()

        class SlowTerminateSession(FakePrestartedServiceHost):
            def terminate_job(self):
                clock.value += 6.0
                self.killed.set()
                self.members.clear()
                self.exit_code = -9
                self.exited.set()
                return True

        class Backend(FakeHostBackend):
            def create_suspended_in_job(self, command, *, deadline_monotonic):
                self.create_count += 1
                self.session = SlowTerminateSession("blocked")
                return self.session

        backend = Backend()
        host = self.prepare(backend, clock)
        deadline = clock.now() + 1.0
        result = supervise_prepared_request(
            host, b"request", deadline_monotonic=deadline,
            cleanup_reserve_seconds=0.2, monotonic=clock.now, sleep=clock.sleep,
        )
        self.assertEqual(result.state, "unknown")
        self.assertEqual(result.reason, "job_termination_returned_after_deadline")
        self.assertTrue(result.operation_returned_after_deadline)
        self.assertFalse(result.containment_proven)
        self.assertIsNotNone(result.retained_host)
        self.assertGreater(clock.now(), deadline)

    def test_concurrent_double_request_claims_host_once(self):
        clock = FakeClock()
        backend = FakeHostBackend(finish_on_request=True)
        host = self.prepare(backend, clock)
        gate = threading.Barrier(3)
        outcomes = []
        lock = threading.Lock()

        def invoke(payload):
            gate.wait()
            try:
                value = supervise_prepared_request(
                    host, payload, deadline_monotonic=clock.now() + 5.0,
                    cleanup_reserve_seconds=0.5, monotonic=clock.now, sleep=clock.sleep,
                )
                outcome = ("result", value.state)
            except ServiceHostPreparationError as exc:
                outcome = ("error", str(exc))
            with lock:
                outcomes.append(outcome)

        first = threading.Thread(target=invoke, args=(b"request-1",))
        second = threading.Thread(target=invoke, args=(b"request-2",))
        first.start()
        second.start()
        gate.wait()
        first.join(timeout=1.0)
        second.join(timeout=1.0)
        self.assertFalse(first.is_alive())
        self.assertFalse(second.is_alive())
        self.assertEqual(sum(item[0] == "result" for item in outcomes), 1)
        self.assertEqual(sum(item[0] == "error" for item in outcomes), 1)
        self.assertEqual(len(backend.session.request_frames), 1)
        self.assertEqual(backend.create_count, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
