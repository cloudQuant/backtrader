# Independent QA: AccountActorPort r3-r1

Date: 2026-09-27
Frozen input: `D:\temp\iteration41-ctp-account-actor-port-freeze-20260927-r3-r1`
Frozen manifest SHA-256: `417ebef0fc2a85b4e37ee22122024b0118211c161795abb79dac438840b960a1`

## Verification result

- Verified all 9 manifest-listed source/test/evidence files against bytes and SHA-256, copied them to `snapshot/`, then reverified all 9 copy hashes with zero mismatches.
- Ran `python -B -m unittest discover -s tests -v` from the isolated snapshot using the source-QA Python 3.11 venv and `PYTHONDONTWRITEBYTECODE=1`; **24 passed**, exit 0.
- Replayed the r2 classifier counterexamples and environment/compatibility cases against only the isolated fake candidate. The exact script and JSON output are under `logs/`.

## Route matrix

- Unknown `custom_ctp_alias` with `api_cls`: classified `AMBIGUOUS`, rejected as `store_route_ambiguous`, API factory not called.
- Nested symbol route `symbol_routes={IF2601:{exchange:CTP}}`: classified CTP; absent actor rejects before gateway factory.
- Deep venue-options route `exchange_kwargs={OKX:{routing:{exchange_type:CTP}}}`: classified CTP; absent actor rejects before API factory. This closes the deeper nested route reported against the first r3 freeze.
- Injected btapi API with a side-effecting `exchange_kwargs` property: classified `AMBIGUOUS`; rejected before property access (`property_reads=0`).
- Explicit CTP selector plus OKX environment provider remains CTP; explicit CTP-gateway plus OKX environment also remains CTP. OKX plus CTP environment is conservatively classified CTP; unknown provider plus OKX environment remains ambiguous.
- Classifier accepts these explicit non-CTP selectors: OKX/Binance direct, generic gateway with IB_WEB/MT5, exact IB_WEB/MT5 gateway aliases, and btapi with explicit OKX exchange_kwargs. This is selector-classification evidence only; the candidate intentionally rejects opaque caller API injection and is not a main Store compatibility run.

## Actor trust gaps that remain

The fake actor reports account `acct-other` while the route has `account_id=acct-configured`; its receipt at epoch 1 is accepted. Repeating the same `intent_id` submits to the actor twice and both receipts pass. The public typed receipt consists only of `(command_id, state, actor_epoch)`; validation checks exact receipt class and command id, not an expected epoch, account/scope, authenticated actor identity, sequence, or replay ledger. Wrong command id is rejected. Missing actor rejects before credential resolver (0 calls).

These are reproduced local fake-harness results, but they are not a production actor security protocol. R3 does not establish a trusted account identity, session epoch, one-shot command ledger, external fencing, or G6-P authority.

## Main-repository source review (static only)

Current source hashes match the frozen candidate's `MAIN_SOURCE_INVENTORY.md`:

- `backtrader/stores/btapistore.py`: `DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826`
- `backtrader/stores/__init__.py`: `076BB64AE832E189B28B313E0028E24005D507DD6B46D0336FE3295AF579B246`
- `tests/unit/stores/test_btapistore.py`: `E7E7B985130F010DEED84B920FD0F91712BFE54AC24B5EF8BF1C8FC687BCA6B1`
- `tests/unit/stores/test_btapistore_normalized.py`: `84C570A2EA1DDC03A3AE3560E30177CD695B5720BC05225256BC7F6D1016D397`

A read-only search found no `account_actor_port`, `CtpAccountActorPort`, or `require_account_actor_before_local_client` under main `backtrader/stores` or `backtrader_runtime`. `BtApiStore.__init__` at line 3455 resolves/stores provider and caller API; line 3538 reads the API's `exchange_kwargs` property. `submit_order` at 7714 falls to `_submit_order_legacy` when no managed adapter is attached; `cancel_order_ref` at 8062 similarly falls to `_cancel_order_ref_legacy`. Legacy guards reject CTP only when a managed execution adapter exists. This remains a static reachable-path observation; no main Store was instantiated and no CTP submit/cancel was called.

The first r3 freeze `A4D336E159AA2C64342F0311710E1B20C55B4B7768F8B23DC03A5525B42F8F9F` and its earlier QA directory `D:\temp\iteration41-ctp-account-actor-port-r3-qa-independent-20260927` are preserved as superseded diagnostic evidence. That run had 24 passing tests but did not cover deep `exchange_kwargs[OKX].routing.exchange_type=CTP`; r3-r1 is the only snapshot reviewed here as the current candidate.

## Boundary and decision

**R3-r1 passes this isolated route-classifier/harness QA, but is not accepted as G6-P account authority or a production integration.** No main production source was modified. No main Store order was sent. No SDK/native/provider/network/credential/protected-config operation was performed. The candidate remains unregistered and not wired to the main Store.

