# External CTP Account Actor Port — offline candidate r3

This independent candidate models a fail-closed composition boundary and a small code-owned provider registry. It does not edit or import the main Backtrader package, does not implement a remote service, and must not be treated as a CTP write route. Unknown providers, ambiguous gateway selectors, and all raw `api`/`api_cls` injection are rejected without introspection.

Run the isolated fake harness with:

    python -m unittest discover -s tests -v

The required result is zero API-class/gateway construction, connect, or ReqOrderInsert/ReqOrderAction calls for missing/default actor routes. The tests also cover CTP environment-downgrade attempts, nested route maps, unknown providers, and injected API objects with trap properties. An explicit FakeActorPort is test-only and proves DTO wiring, not external authority. Its receipt has no verified account binding, expected epoch, or replay defense.

See INTEGRATION_CONTRACT.md for the precise main Store call points, existing seam differences, and public-compatibility limitations.
