from decimal import Decimal
import json

from account_actor_port import (
    AccountActorGateError, ActorCommandReceiptV1, ActorCommandState,
    CtpAccountActorPort, CtpSubmitIntentV1, RouteKind, StoreRouteDescriptor,
    classify_store_route, require_account_actor_before_local_client,
)
from store_boundary_harness import StoreBoundaryHarness

class FakeApiClass:
    pass

class ApiPropertySpy:
    def __init__(self): self.reads = 0
    @property
    def exchange_kwargs(self):
        self.reads += 1
        raise AssertionError('caller property should not be inspected')

class FakeActor(CtpAccountActorPort):
    def __init__(self, account_id='acct-other', epoch=1, command_id_mode='echo'):
        self.account_id = account_id
        self.epoch = epoch
        self.command_id_mode = command_id_mode
        self.calls = []
    def submit_order(self, intent):
        self.calls.append(intent)
        cid = intent.intent_id if self.command_id_mode == 'echo' else 'wrong-command'
        return ActorCommandReceiptV1(cid, ActorCommandState.QUEUED, self.epoch)
    def cancel_order(self, intent):
        self.calls.append(intent)
        return ActorCommandReceiptV1(intent.cancel_intent_id, ActorCommandState.QUEUED, self.epoch)

intent = CtpSubmitIntentV1('same-intent', 'IF2601', 'CFFEX', 'BUY', 'OPEN', 'SPECULATION', 1, Decimal('3000'))
result = {}

unknown = StoreRouteDescriptor(provider='custom_ctp_alias', backend='direct', api_cls=FakeApiClass)
factory_calls = []
try:
    StoreBoundaryHarness(unknown, api_factory=lambda: factory_calls.append('called'))
    unknown_error = None
except AccountActorGateError as exc:
    unknown_error = exc.code
result['unknown_provider_api_cls'] = {
    'route_kind': classify_store_route(unknown).value,
    'gate_error': unknown_error,
    'api_factory_calls': factory_calls,
}

nested_symbol = StoreRouteDescriptor(
    provider='gateway', backend='gateway',
    config={'exchange_type': 'OKX', 'symbol_routes': {'IF2601': {'exchange': 'CTP'}}},
)
symbol_factory_calls = []
try:
    StoreBoundaryHarness(nested_symbol, gateway_factory=lambda: symbol_factory_calls.append('called'))
    symbol_error = None
except AccountActorGateError as exc:
    symbol_error = exc.code
result['nested_symbol_routes_ctp'] = {
    'route_kind': classify_store_route(nested_symbol).value,
    'gate_error': symbol_error,
    'gateway_factory_calls': symbol_factory_calls,
}

nested_exchange = StoreRouteDescriptor(
    provider='btapi', backend='direct',
    config={'exchange_kwargs': {'OKX': {'routing': {'exchange_type': 'CTP'}}}},
)
exchange_factory_calls = []
try:
    StoreBoundaryHarness(nested_exchange, api_factory=lambda: exchange_factory_calls.append('called'))
    exchange_error = None
except AccountActorGateError as exc:
    exchange_error = exc.code
result['nested_exchange_kwargs_routing_ctp'] = {
    'route_kind': classify_store_route(nested_exchange).value,
    'gate_error': exchange_error,
    'api_factory_calls': exchange_factory_calls,
}

spy = ApiPropertySpy()
injected = StoreRouteDescriptor(provider='btapi', api=spy)
try:
    require_account_actor_before_local_client(injected, None)
    property_error = None
except AccountActorGateError as exc:
    property_error = exc.code
result['injected_api_property_order'] = {
    'route_kind': classify_store_route(injected).value,
    'gate_error': property_error,
    'property_reads': spy.reads,
}

result['environment_precedence'] = {
    'explicit_ctp_with_okx_environment': classify_store_route(StoreRouteDescriptor(
        provider='ctp', backend='direct', environment_provider='okx', environment_exchange_type='OKX'
    )).value,
    'explicit_ctp_gateway_with_okx_environment': classify_store_route(StoreRouteDescriptor(
        provider='ctp_gateway', backend='gateway', environment_provider='okx', environment_exchange_type='OKX'
    )).value,
    'environment_ctp_on_okx': classify_store_route(StoreRouteDescriptor(
        provider='okx', backend='direct', environment_provider='ctp'
    )).value,
    'unknown_provider_with_okx_environment': classify_store_route(StoreRouteDescriptor(
        provider='custom_alias', backend='direct', environment_provider='okx', environment_exchange_type='OKX'
    )).value,
}

supported = {
    'okx_direct': StoreRouteDescriptor(provider='okx', backend='direct'),
    'binance_direct': StoreRouteDescriptor(provider='binance', backend='direct'),
    'gateway_ib_web': StoreRouteDescriptor(provider='gateway', backend='gateway', config={'exchange_type': 'IB_WEB'}),
    'gateway_mt5': StoreRouteDescriptor(provider='gateway', backend='gateway', config={'exchange_type': 'MT5'}),
    'ib_web_gateway_alias': StoreRouteDescriptor(provider='ib_web_gateway', backend='gateway', config={'exchange_type': 'IB_WEB'}),
    'mt5_gateway_alias': StoreRouteDescriptor(provider='mt5_gateway', backend='gateway', config={'exchange_type': 'MT5'}),
    'btapi_explicit_okx_exchange_kwargs': StoreRouteDescriptor(provider='btapi', api_kwargs={'exchange_kwargs': {'OKX': {'endpoint': 'fake'}}}),
}
result['supported_non_ctp_route_selectors'] = {key: classify_store_route(value).value for key, value in supported.items()}

actor = FakeActor(account_id='acct-other', epoch=1)
account_route = StoreRouteDescriptor(provider='ctp', backend='direct', config={'account_id': 'acct-configured'})
harness = StoreBoundaryHarness(account_route, actor_port=actor)
receipt1 = harness.submit_order(intent)
receipt2 = harness.submit_order(intent)
result['receipt_scope_epoch_replay'] = {
    'configured_account': account_route.config['account_id'],
    'actor_reported_account': actor.account_id,
    'receipt_epoch_accepted': receipt1.actor_epoch,
    'same_intent_second_receipt_accepted': receipt2.command_id == intent.intent_id,
    'actor_submit_calls': len(actor.calls),
    'receipt_fields': list(ActorCommandReceiptV1.__dataclass_fields__),
    'intent_fields': list(CtpSubmitIntentV1.__dataclass_fields__),
}

bad_actor = FakeActor(command_id_mode='wrong')
try:
    StoreBoundaryHarness(account_route, actor_port=bad_actor).submit_order(intent)
    wrong_id_error = None
except AccountActorGateError as exc:
    wrong_id_error = exc.code
result['wrong_command_id'] = {'rejected_as': wrong_id_error}

resolver_calls = []
try:
    StoreBoundaryHarness(account_route, actor_port=None, credential_resolver=lambda: resolver_calls.append(1))
    absent_actor_error = None
except AccountActorGateError as exc:
    absent_actor_error = exc.code
result['absent_actor'] = {'error': absent_actor_error, 'credential_resolver_calls': len(resolver_calls)}

print(json.dumps(result, indent=2, sort_keys=True))
