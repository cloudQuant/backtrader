from __future__ import annotations

import json
import threading
import time
from pathlib import Path

from scripts.ctp_i13_i15_service_host_supervisor import (
    PreparedServiceHost,
    _PREPARED_HOST_TOKEN,
    supervise_prepared_request,
)


class BlockingFakeSession:
    process_created = True
    job_assignment_observed = True

    def __init__(self) -> None:
        self.entered = threading.Event()
        self.release = threading.Event()

    def send_request_nonblocking(self, _raw: bytes, *, deadline_monotonic: float) -> bool:
        del deadline_monotonic
        self.entered.set()
        self.release.wait()
        return True


session = BlockingFakeSession()
host = PreparedServiceHost(
    _session=session,
    _backend=object(),
    _ready=True,
    _token=_PREPARED_HOST_TOKEN,
)
start = time.monotonic()
deadline = start + 0.12
result_box: list[object] = []


def call_supervisor() -> None:
    result_box.append(
        supervise_prepared_request(
            host,
            b"fake-request",
            deadline_monotonic=deadline,
            cleanup_reserve_seconds=0.02,
            poll_interval_seconds=0.01,
        )
    )


caller = threading.Thread(target=call_supervisor, name="fake-request-caller")
caller.start()
if not session.entered.wait(1.0):
    raise AssertionError("fake send method was not entered")
while time.monotonic() < deadline + 0.05:
    time.sleep(0.001)
caller_blocked_past_deadline = caller.is_alive()
observed_at = time.monotonic()
session.release.set()
caller.join(1.0)
if caller.is_alive():
    raise AssertionError("caller did not return after fake API was released")
result = result_box[0]
record = {
    "probe": "blocking_method_named_send_request_nonblocking",
    "model": "inert Python fake; no Win32 process, Job, service, provider, or credentials",
    "deadline_seconds": round(deadline - start, 6),
    "caller_still_blocked_after_deadline": caller_blocked_past_deadline,
    "observed_after_deadline_seconds": round(observed_at - deadline, 6),
    "response_state_after_release": result.state,
    "operation_returned_after_deadline": result.operation_returned_after_deadline,
    "retained_host_present": result.retained_host is host,
    "interpretation": "post-call check downgrades to UNKNOWN only after the synchronous call returns; it cannot bound caller return",
}
if not caller_blocked_past_deadline:
    raise AssertionError("expected caller to remain blocked beyond deadline")
if result.state != "unknown" or not result.operation_returned_after_deadline:
    raise AssertionError("late synchronous API return must be UNKNOWN")
print(json.dumps(record, sort_keys=True, indent=2))
