from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
qa=Path(__file__).resolve().parent
archive=qa/'ac41-63-controlled-writer-slice-20260927.zip'
manifest=json.loads((qa/'archive-manifest.json').read_text(encoding='utf-8'))
expected={item['path']:item for item in manifest['members']}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in sorted(expected): z.write(qa/Path(name),name)
    z.write(qa/'archive-manifest.json','archive-manifest.json')
    z.write(qa/'SHA256SUMS.txt','SHA256SUMS.txt')
with zipfile.ZipFile(archive,'r') as z:
    bad=z.testzip()
    if bad is not None: raise SystemExit('ZIP_TEST_FAIL '+bad)
    names=set(z.namelist())
    exact=set(expected)|{'archive-manifest.json','SHA256SUMS.txt'}
    if names!=exact: raise SystemExit('MEMBER_SET_MISMATCH extras='+repr(sorted(names-exact))+' missing='+repr(sorted(exact-names)))
    failures=[]
    for name,item in expected.items():
        raw=z.read(name)
        if len(raw)!=item['size_bytes'] or hashlib.sha256(raw).hexdigest().upper()!=item['sha256']:
            failures.append(name)
    if failures: raise SystemExit('MEMBER_HASH_FAIL '+repr(failures))
    sums=z.read('SHA256SUMS.txt').decode('ascii').splitlines()
    sum_failures=[]
    for line in sums:
        h,name=line.split('  ',1)
        if name not in names or hashlib.sha256(z.read(name)).hexdigest().upper()!=h:
            sum_failures.append(name)
    if sum_failures: raise SystemExit('CHECKSUM_FAIL '+repr(sum_failures))
summary={'zip_testzip':bad,'archive_members':len(names),'manifest_payload_members':len(expected),'sha256sum_entries':len(sums),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),'archive_size_bytes':archive.stat().st_size,'result':'PASS'}
(qa/'archive-verification.log').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n',encoding='utf-8')
(qa/'archive-verification.sha256').write_text(hashlib.sha256((qa/'archive-verification.log').read_bytes()).hexdigest().upper()+'  archive-verification.log\n',encoding='ascii')
print(json.dumps(summary,indent=2,sort_keys=True))
