from __future__ import annotations
import hashlib,json,platform
from pathlib import Path
qa=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files={}
for p in sorted(x for x in qa.rglob('*') if x.is_file() and x.name not in {'receipt.json','archive-manifest.json','SHA256SUMS.txt','ac41-63-controlled-writer-slice-20260927.zip','archive-verification.log','archive-verification.sha256'}):
 files[str(p.relative_to(qa)).replace('\\','/')]=sha(p)
source_check=json.loads((qa/'source-identity-check.json').read_text(encoding='utf-8'))
input_check=json.loads((qa/'input-check.json').read_text(encoding='utf-8'))
main=json.loads((qa/'main-probe.log').read_text(encoding='utf-8'))
r2a=json.loads((qa/'r2a-probe.log').read_text(encoding='utf-8'))
receipt={
 'schema':'ac41-63-controlled-writer-slice-independent-qa-v1',
 'date':'2026-09-27',
 'classification':'LIMITED_STATIC_AND_LOCAL_FAKE_PATH_REVIEW_NOT_CLOSURE',
 'scope':{'reviewed_disposition_candidates':10,'total_disposition_candidates':389,'unreviewed_disposition_candidates':379,'all_dispositions_remain':'REVIEW_REQUIRED / NOT_AVAILABLE'},
 'main_source_manifest_sha256':source_check['source_manifest_sha256'],
 'inventory_counts':input_check['inventory_counts'],
 'disposition_count':input_check['disposition_entries'],
 'main_source_sha256':{k:v['actual_sha256'] for k,v in source_check.items() if isinstance(v,dict) and 'actual_sha256' in v},
 'r2a_candidate':{'manifest_sha256':source_check['r2a']['candidate_manifest_sha256'],'patch_sha256':source_check['r2a']['patch_sha256'],'btapistore_sha256':source_check['r2a']['store_sha256'],'payloads_verified':679,'manifest_result':'PASS'},
 'probe_results':{'main_exit_code':int((qa/'main-probe.exit-code.txt').read_text()),'main_probe_outcomes':{p['name']:p['outcome'] for p in main['probes']},'r2a_exit_code':int((qa/'r2a-probe.exit-code.txt').read_text()),'r2a_probe_outcomes':{p['name']:p['outcome'] for p in r2a['probes']},'r2a_manifest_exit_code':int((qa/'r2a-manifest-verify.exit-code.txt').read_text()),'r2a_manifest_log':(qa/'r2a-manifest-verify.log').read_text(encoding='utf-8').strip().splitlines()},
 'safety_scope':{'no_real_config_or_environment_values_read':True,'no_credentials_or_account_data_used':True,'no_sdk_native_provider_or_network_import_or_call':True,'writer_delegates_only_inert_fake_traps':True,'no_real_order_or_cancel':True,'default_CTP_route_remains_closed':True},
 'python':platform.python_version(),
 'artifacts_sha256':files,
 'limitations':['AST-compiled method probes establish only method-body control-flow to fake boundaries, not full Store lifecycle or external reachability.','The 10-item review leaves 379 inventory dispositions untouched.','Native CTP fallback, full runner source execution, all adapter compositions, r2b, provider acceptance and production behavior are not verified.']
}
(qa/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'receipt_sha256':sha(qa/'receipt.json'),'receipt_path':str(qa/'receipt.json'),'artifact_count':len(files),'main_exit':receipt['probe_results']['main_exit_code'],'r2a_exit':receipt['probe_results']['r2a_exit_code'],'r2a_verified':receipt['r2a_candidate']['payloads_verified']},indent=2))
