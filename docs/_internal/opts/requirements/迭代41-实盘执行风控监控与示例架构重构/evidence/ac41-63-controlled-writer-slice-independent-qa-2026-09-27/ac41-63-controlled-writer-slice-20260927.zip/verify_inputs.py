from __future__ import annotations
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
cand=json.loads((root/'input'/'live-execution-inventory-candidates.json').read_text(encoding='utf-8'))
disp=json.loads((root/'input'/'live-execution-writer-dispositions.json').read_text(encoding='utf-8'))
ids=["i41-writer-6b64c967597ca9a30e13","i41-writer-ed12303a6c97d433f979","i41-writer-e25ef08c3d066b243298","i41-writer-8f9ca48eab400d71e549","i41-writer-8739a8fd4212eca086b0","i41-writer-f8f51de9f2f4a3fdf72c","i41-writer-b71354cccd4aa34361ee","i41-writer-fbe05d71d70ed65a9838","i41-writer-174e9667065d97aae5dd","i41-writer-7d767677b3f095e8da32"]
entries={e['candidate_id']:e for e in disp['entries']}
selected=[]
for cid in ids:
 e=entries[cid]
 selected.append({"candidate_id":cid,"path":e['candidate']['path'],"line":e['candidate']['line'],"function":e['candidate']['function_name'],"call":e['candidate'].get('call'),"kind":e['candidate']['kind'],"disposition":e['disposition'],"availability":e['availability'],"trace_evidence_disposition":e['trace_evidence_disposition']})
status_counts={}
for e in disp['entries']:
 key=(e['disposition'],e['availability']); status_counts[str(key)]=status_counts.get(str(key),0)+1
checks={"inventory_counts":cand["counts"],"disposition_entries":len(disp['entries']),"status_counts":status_counts,"selected_count":len(selected),"selected_ids_all_present":all(cid in entries for cid in ids),"selected_items":selected,"input_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in (root/'input').iterdir() if p.is_file()},"overall_status":disp['closure_status']}
assert cand['counts']['files_scanned']==349 and cand['counts']['writer_candidates']==327 and cand['counts']['dynamic_execution_candidates']==62
assert len(disp['entries'])==389 and len(selected)==10 and all(cid in entries for cid in ids)
assert all(e['disposition']=='REVIEW_REQUIRED' and e['availability']=='NOT_AVAILABLE' for e in disp['entries'])
(root/'input-check.json').write_text(json.dumps(checks,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False,indent=2,sort_keys=True))
