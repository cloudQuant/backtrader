from __future__ import annotations
import hashlib,json,subprocess,sys
from pathlib import Path
qa=Path(__file__).resolve().parent
main=Path(r'D:\temp\iteration41-writer-inventory-independent-qa-20260927\repo')
r2a=Path(r'D:\temp\iteration41-ctp-account-actor-main-store-wiring-candidate-20260927-r2a')
manifest=json.loads((qa/'input'/'frozen-source-manifest.json').read_text(encoding='utf-8'))
listed={e['path']:e['sha256'].upper() for e in manifest['files']}
source_paths={
'backtrader_runtime/inventory.py':'0EBC77EFD22E21B299E794E09C8CB879899B5DC4EFD3302E86D2D9C626B0F6CB',
'backtrader_runtime/cli.py':'BCA2632E261FE2B663008E8B0758C2C932DF917F9376E9B90230848B41EF5EF4',
'backtrader_runtime/runner.py':'F80C4DE5C8E981F73B2C05930BB5F772F631099CE3A8291AF94E7BAC0DCB6AFD',
'backtrader_runtime/registry.py':'F359E0D0576662BC8D5F966EF2345FE723C8802CD504AD383323E59959FE5A01',
'backtrader_runtime/policy.py':'631B326ED570E076CB9199FF73755D1AD8EC268197D0964008725B0C58983074',
'backtrader/stores/btapistore.py':'DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826',
'backtrader/stores/managed_execution.py':'1C31F89412E8E1177EB2E27389C62B50E074361EF808098846C06704F18440C5',
'scripts/collect_iteration41_writer_inventory.py':'54AF45DE1C4D14AAF1C3849C9B820F505EDB7A4C34C344B8E4157F490C9E0ED5',
'scripts/iteration41_writer_inventory_scope.json':'C473B4390D70477978C0EB9673E267244D78A57D0ACB2E8DF6D5F7D3BFA60DD7',
}
checks={}
for rel,expected in source_paths.items():
 actual=hashlib.sha256((main/rel).read_bytes()).hexdigest().upper()
 listed_value=listed.get(rel)
 checks[rel]={"expected_sha256":expected,"actual_sha256":actual,"manifest_sha256":listed_value,"pass":actual==expected and listed_value==expected}
if not all(x['pass'] for x in checks.values()): raise SystemExit("main frozen source mismatch")
r2a_sha=hashlib.sha256((r2a/'backtrader/stores/btapistore.py').read_bytes()).hexdigest().upper()
manifest_bytes=(r2a/'evidence/candidate-manifest.json').read_bytes()
r2a_manifest_sha=hashlib.sha256(manifest_bytes).hexdigest().upper()
r2a_patch_sha=hashlib.sha256((r2a/'r2a-apply.patch').read_bytes()).hexdigest().upper()
checks['r2a']={"store_sha256":r2a_sha,"candidate_manifest_sha256":r2a_manifest_sha,"patch_sha256":r2a_patch_sha,
                "expected_store_sha256":"18A02F00EC3B2031932284C9E855395C1C70C3E448DBAFCD054E4F079048C4D0",
                "expected_manifest_sha256":"5AD9CCE0851FBEBD9AC07D520919B7A02F793AB99A133CF96E91F58CEDE405FB",
                "expected_patch_sha256":"7708DF2F0923B74E5F95315390580EB417E9CA05CFA4C6FE41422BC410908E99"}
checks['r2a']['pass']=checks['r2a']['store_sha256']==checks['r2a']['expected_store_sha256'] and checks['r2a']['candidate_manifest_sha256']==checks['r2a']['expected_manifest_sha256'] and checks['r2a']['patch_sha256']==checks['r2a']['expected_patch_sha256']
if not checks['r2a']['pass']: raise SystemExit("r2a source identity mismatch")
checks['source_manifest_sha256']=hashlib.sha256((qa/'input'/'frozen-source-manifest.json').read_bytes()).hexdigest().upper()
checks['r2a_manifest_verification_log']= (qa/'r2a-manifest-verify.log').read_text(encoding='utf-8').strip().splitlines()
checks['r2a_manifest_verified_payloads']=679
(qa/'source-identity-check.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False,indent=2,sort_keys=True))
