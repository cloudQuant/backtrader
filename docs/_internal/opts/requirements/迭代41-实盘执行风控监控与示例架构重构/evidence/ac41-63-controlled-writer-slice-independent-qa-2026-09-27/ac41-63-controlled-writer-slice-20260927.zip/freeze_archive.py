from __future__ import annotations
import hashlib,json
from pathlib import Path
qa=Path(__file__).resolve().parent
exclude={'archive-manifest.json','SHA256SUMS.txt','ac41-63-controlled-writer-slice-20260927.zip','archive-verification.log','archive-verification.sha256'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
files=sorted(p for p in qa.rglob('*') if p.is_file() and p.name not in exclude)
manifest={'schema':'ac41-63-controlled-writer-slice-archive-manifest-v1','members':[{'path':str(p.relative_to(qa)).replace('\\','/'),'size_bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
(qa/'archive-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
checksum_files=sorted(p for p in qa.rglob('*') if p.is_file() and p.name not in {'SHA256SUMS.txt','ac41-63-controlled-writer-slice-20260927.zip','archive-verification.log','archive-verification.sha256'})
(qa/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {str(p.relative_to(qa)).replace(chr(92),chr(47))}\n' for p in checksum_files),encoding='ascii')
print('members',len(files),'archive_manifest_sha256',sha(qa/'archive-manifest.json'),'SHA256SUMS_sha256',sha(qa/'SHA256SUMS.txt'))
