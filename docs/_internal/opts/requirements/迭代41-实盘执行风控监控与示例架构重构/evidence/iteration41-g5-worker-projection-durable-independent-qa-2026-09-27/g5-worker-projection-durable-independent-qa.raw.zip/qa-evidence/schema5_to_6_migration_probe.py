import json, os, subprocess, sys
from pathlib import Path
qa=Path(r'D:\temp\iteration41-g5-worker-projection-independent-qa-20260927')
db=qa/'evidence'/'runtime'/'schema5-to-6.sqlite3'
baseline=qa/'frozen_sdk'/'src'; tests=qa/'frozen_sdk'/'tests'
candidate=qa/'candidate'/'implementation'/'sdk'/'src'
create=r'''
import json,sys
sys.path.insert(0,sys.argv[1])
import test_ctp_dispatch_commands as helpers
from bt_api_execution import SqliteExecutionStore
path=sys.argv[2]; scope=helpers._scope(); store=SqliteExecutionStore(path)
try:
 lease=helpers._lease(store,scope,'qa-v5-owner')
 reservation=helpers._reserve_seeded(store,scope,lease,'qa-migration-intent')
 command=helpers._stage_submit(store,scope,lease,reservation,command_id='qa-v5-command',approval_use_id='qa-v5-approval')
 version=store._connection.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()['value']
 result={'schema_version':version,'command_status':command.status,'order_ref':reservation.order_ref,'command_table_count':store._connection.execute("SELECT COUNT(*) FROM ctp_dispatch_commands").fetchone()[0],'projection_table_exists':store._connection.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='ctp_order_target_projections'").fetchone()[0]}
 print(json.dumps(result,sort_keys=True))
 assert version=='5' and command.status=='READY' and result['projection_table_exists']==0
finally: store.close()
'''
check=r'''
import json,sys
from bt_api_execution import ExecutionScope,SqliteExecutionStore
path=sys.argv[1]; scope=ExecutionScope('CTP','simulation','acct-outbox','strategy.outbox','20260925'); store=SqliteExecutionStore(path)
try:
 version=store._connection.execute("SELECT value FROM execution_meta WHERE key='schema_version'").fetchone()['value']
 command=store.read_ctp_dispatch_command(scope,'qa-v5-command')
 reservation=store.read_ctp_order_identity(scope,'qa-migration-intent')
 tables={row['name'] for row in store._connection.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
 result={'schema_version':version,'command_status':None if command is None else command.status,'order_ref':None if reservation is None else reservation.order_ref,'projection_table_exists':'ctp_order_target_projections' in tables,'consumptions_table_exists':'ctp_order_target_projection_consumptions' in tables}
 print(json.dumps(result,sort_keys=True))
 assert version=='6' and command is not None and command.status=='READY' and reservation is not None and result['projection_table_exists'] and result['consumptions_table_exists']
finally: store.close()
'''
def run(label,code,pythonpath,args):
 env=os.environ.copy(); env['PYTHONPATH']=str(pythonpath); env['PYTHONDONTWRITEBYTECODE']='1'
 result=subprocess.run([sys.executable,'-c',code,*args],cwd=str(qa),env=env,capture_output=True,text=True)
 print(f'[{label}] exit={result.returncode}'); print(result.stdout,end=''); print(result.stderr,end='')
 if result.returncode: raise SystemExit(result.returncode)
run('create-v5',create,baseline,[str(tests),str(db)])
run('open-as-v6',check,candidate,[str(db)])