from __future__ import annotations
import hashlib,json,shutil,zipfile
from pathlib import Path
qa=Path(r'D:\temp\iteration41-g5-worker-projection-independent-qa-20260927')
ev=qa/'evidence'; packet=ev/'frozen-packet'
v21=Path(r'D:\temp\iteration41_v21_ctp_account_handoff_freeze_r3_20260927')
raw=ev/'g5-worker-projection-durable-independent-qa.raw.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(src:Path, rel:str):
 dst=packet/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); return dst
# Put the updated report into the packet.
put(ev/'independent-qa-report.md','qa-evidence/independent-qa-report.md')
# Bind the exact V21 interface inputs used by the signature probe.
v21_files=[
 (v21/'manifest.json','v21-input/manifest.json'),
 (v21/'SOURCE-MANIFEST.json','v21-input/SOURCE-MANIFEST.json'),
 (v21/'pyproject.toml','v21-input/pyproject.toml'),
 (v21/'src/bt_api_execution/store.py','v21-input/src/bt_api_execution/store.py'),
 (v21/'src/bt_api_execution/ctp_single_worker_candidate.py','v21-input/src/bt_api_execution/ctp_single_worker_candidate.py'),
]
for src,rel in v21_files: put(src,rel)
provenance={
 'frozen_root':str(v21),
 'manifest_sha256':sha((v21/'manifest.json').read_bytes()),
 'source_manifest_sha256':sha((v21/'SOURCE-MANIFEST.json').read_bytes()),
 'pyproject_sha256':sha((v21/'pyproject.toml').read_bytes()),
 'store_sha256':sha((v21/'src/bt_api_execution/store.py').read_bytes()),
 'worker_sha256':sha((v21/'src/bt_api_execution/ctp_single_worker_candidate.py').read_bytes()),
 'probe_sha256':sha((ev/'v21_worker_interface_probe.py').read_bytes()),
 'probe_log_sha256':sha((ev/'v21_worker_interface_probe.log').read_bytes()),
}
(packet/'v21-input-provenance.json').write_text(json.dumps(provenance,indent=2,sort_keys=True)+'\n',encoding='utf-8')
# Include the packet refresh procedure as raw evidence.
put(ev/'refresh_packet.py','qa-evidence/refresh_packet.py')
# Rebuild the packet-level hash inventory (it intentionally excludes its own digest).
records=[]
for src in sorted(packet.rglob('*')):
 if src.is_file() and src.name!='PACKET-MANIFEST.json':
  records.append({'path':src.relative_to(packet).as_posix(),'bytes':src.stat().st_size,'sha256':sha(src.read_bytes())})
(packet/'PACKET-MANIFEST.json').write_text(json.dumps({'format':'iteration41-g5-independent-qa-packet.v1','self_hash_excluded':True,'files':records},indent=2,sort_keys=True)+'\n',encoding='utf-8')
# Rebuild raw archive deterministically by sorted path order.
tmp=raw.with_suffix('.tmp.zip')
with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for src in sorted(packet.rglob('*')):
  if src.is_file(): z.write(src,src.relative_to(packet).as_posix())
tmp.replace(raw)
with zipfile.ZipFile(raw) as z:
 test=z.testzip(); members=[]
 for name in sorted(z.namelist()):
  b=z.read(name); members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
# Verify every archived member against current packet bytes.
member_mismatch=[]
with zipfile.ZipFile(raw) as z:
 for m in members:
  b=z.read(m['path']); p=packet/m['path']
  if len(b)!=p.stat().st_size or sha(b)!=sha(p.read_bytes()): member_mismatch.append(m['path'])
index={
 'format':'iteration41-g5-independent-qa-archive-index.v1',
 'raw_zip':raw.name,'raw_zip_bytes':raw.stat().st_size,'raw_zip_sha256':sha(raw.read_bytes()),
 'testzip':test,'member_count':len(members),'member_hashes':members,
 'packet_source_file_count':len(records),'packet_source_copy_mismatches':member_mismatch,
 'candidate_author_zip_sha256':sha(Path(r'D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate.zip').read_bytes()),
 'candidate_input_manifest_sha256':sha(Path(r'D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate\frozen-input-manifest.json').read_bytes()),
 'candidate_output_manifest_sha256':sha(Path(r'D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate\evidence\final-output-manifest.json').read_bytes()),
 'candidate_delta_patch_sha256':sha(Path(r'D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate\implementation\sdk_patch\G5_TYPED_TARGET_PROJECTION_DURABLE_CONSUMER.patch').read_bytes()),
 'v21_input_provenance':provenance,
}
index_path=ev/'ARCHIVE-INDEX.json'; index_path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n',encoding='utf-8')
receipt_path=ev/'independent-qa-receipt.json'; receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
receipt.update({
 'raw_zip':raw.name,'raw_zip_sha256':index['raw_zip_sha256'],'raw_zip_testzip':test,
 'archive_index_sha256':sha(index_path.read_bytes()),
 'report_sha256':sha((ev/'independent-qa-report.md').read_bytes()),
 'v21_source_manifest_sha256':provenance['source_manifest_sha256'],
 'v21_store_sha256':provenance['store_sha256'],'v21_worker_sha256':provenance['worker_sha256'],
 'packet_source_copy_mismatches':member_mismatch,
})
receipt_path.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'report_sha256':sha((ev/'independent-qa-report.md').read_bytes()),'zip':str(raw),'zip_bytes':raw.stat().st_size,'zip_sha256':sha(raw.read_bytes()),'zip_testzip':test,'members':len(members),'index_sha256':sha(index_path.read_bytes()),'receipt_sha256':sha(receipt_path.read_bytes()),'v21_source_manifest_sha256':provenance['source_manifest_sha256'],'v21_store_sha256':provenance['store_sha256'],'v21_worker_sha256':provenance['worker_sha256'],'mismatches':member_mismatch},indent=2))
if test is not None or member_mismatch: raise SystemExit(1)