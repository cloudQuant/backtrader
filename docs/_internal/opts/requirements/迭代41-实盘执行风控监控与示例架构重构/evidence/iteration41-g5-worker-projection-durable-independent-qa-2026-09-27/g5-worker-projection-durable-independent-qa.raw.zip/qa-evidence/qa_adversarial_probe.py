from __future__ import annotations
import hashlib, importlib.util, json, sys
from dataclasses import replace
from pathlib import Path

qa=Path(r'D:\temp\iteration41-g5-worker-projection-independent-qa-20260927')
impl=qa/'candidate'/'implementation'
sys.path[:0]=[str(impl/'sdk'/'src'),str(impl),str(impl/'tests')]
spec=importlib.util.spec_from_file_location('g5_focus_helpers',impl/'tests'/'test_g5_single_worker_action_handoff.py')
helpers=importlib.util.module_from_spec(spec); sys.modules[spec.name]=helpers; spec.loader.exec_module(helpers)
from bt_api_execution.ctp_identity_authority import CtpActionRefSeedProof
from bt_api_execution.ctp_single_worker_candidate import CtpManagedSingleWorkerCandidate, CtpNativeDispatchResult, stable_managed_command_id
from bt_api_execution.errors import IntentConflictError
evidence=qa/'evidence'
rows=[]

def fresh_store(name):
    return helpers._open(evidence/'runtime'/name)

# Same fresh target projection must not be consumed by a second command.
store,authority,scope,lease=fresh_store('one-use.sqlite3')
try:
    order=helpers._seed_order(authority,scope,lease)
    first_action=helpers._reserve_action(authority,scope,lease,order)
    first=helpers._prepared(order)
    worker=CtpManagedSingleWorkerCandidate(store,scope,lease,authority)
    target=helpers._target_projection(store,order,first)
    worker.stage_prepared_dispatch(first,cancel_target_projection=target,action_identity=first_action)
    second_id='cancel-worker-two'
    second_action=authority.reserve_cancel_action_identity(scope,second_id,order.managed_intent_id,order.runtime_order_id,order.order_ref,legacy_seed=CtpActionRefSeedProof('20260927',41,hashlib.sha256(b'synthetic action seed').hexdigest()),writer_lease=lease)
    second=replace(first,command_id=stable_managed_command_id('cancel','worker-intent',order.runtime_order_id,second_id),managed_cancel_intent_id=second_id,approval_use_id='approval-worker-two',approval_digest=hashlib.sha256(b'approval-worker-two').hexdigest(),local_queue_receipt_id='a123456789abcdef0123456789abcdef')
    try:
        worker.stage_prepared_dispatch(second,cancel_target_projection=target,action_identity=second_action)
        raise AssertionError('projection unexpectedly reused')
    except IntentConflictError as exc:
        err=str(exc)
        exc_type=type(exc).__name__
    second_command=store.read_ctp_dispatch_command(scope,second.command_id)
    consumption_count=store._connection.execute('SELECT COUNT(*) FROM ctp_order_target_projection_consumptions').fetchone()[0]
    assert second_command is None and consumption_count==1
    rows.append({'case':'projection-one-use-second-command','result':'REJECTED','exception':exc_type,'message':err,'second_command_absent':True,'consumption_count':consumption_count,'first_action_ref':first_action.native_action_ref,'second_action_ref':second_action.native_action_ref})
finally: store.close()

# A synchronous wrapper that returns a coroutine is invoked after claim, then fenced UNKNOWN.
store,authority,scope,lease=fresh_store('sync-wrapper-awaitable.sqlite3')
try:
    order=helpers._seed_order(authority,scope,lease); action=helpers._reserve_action(authority,scope,lease,order); prepared=helpers._prepared(order)
    worker=CtpManagedSingleWorkerCandidate(store,scope,lease,authority); binding=worker.stage_prepared_dispatch(prepared,cancel_target_projection=helpers._target_projection(store,order,prepared),action_identity=action)
    command=store.read_ctp_dispatch_command(scope,prepared.command_id); binding=worker.record_managed_queue_receipt(prepared.command_id,binding,helpers._queue(binding,command))
    entered=[]; coroutine_body=[]
    async def async_result(_command):
        coroutine_body.append('executed'); return CtpNativeDispatchResult('QUEUED',{'queued':True})
    def sync_wrapper(_command):
        entered.append('sender-entered'); return async_result(_command)
    result=worker.dispatch_managed_command(prepared.command_id,binding,sync_wrapper)
    durable=store.read_ctp_dispatch_command(scope,prepared.command_id)
    assert entered==['sender-entered'] and coroutine_body==[] and result.worker_state=='UNKNOWN' and result.sender_called is True and durable.status=='UNKNOWN'
    rows.append({'case':'sync-wrapper-returning-awaitable','result':result.worker_state,'sender_entered':entered,'coroutine_body':coroutine_body,'sender_called':result.sender_called,'durable_status':durable.status,'interpretation':'not rejected before claim/callback; awaitable body closed without execution'})
finally: store.close()

# Expiry is checked before entering sender; a sender that delays past expiry has no inner SDK-entry recheck.
store,authority,scope,lease=fresh_store('expiry-inside-sender.sqlite3')
try:
    clock={'now':1_000_000_000}; store._monotonic_now_ns=lambda:clock['now']
    order=helpers._seed_order(authority,scope,lease); action=helpers._reserve_action(authority,scope,lease,order); prepared=helpers._prepared(order)
    worker=CtpManagedSingleWorkerCandidate(store,scope,lease,authority); target=helpers._target_projection(store,order,prepared); expires=target.projection.expires_at_ns
    binding=worker.stage_prepared_dispatch(prepared,cancel_target_projection=target,action_identity=action)
    command=store.read_ctp_dispatch_command(scope,prepared.command_id); binding=worker.record_managed_queue_receipt(prepared.command_id,binding,helpers._queue(binding,command))
    attempts=[]
    def delayed_sync_sender(_command):
        clock['now']=expires; attempts.append({'attempt_now_ns':clock['now'],'expired':clock['now']>=expires})
        return CtpNativeDispatchResult('QUEUED',{'queued':True})
    result=worker.dispatch_managed_command(prepared.command_id,binding,delayed_sync_sender)
    assert attempts==[{'attempt_now_ns':expires,'expired':True}] and result.worker_state=='COMPLETED' and result.sender_called
    rows.append({'case':'expiry-after-worker-check-inside-sync-sender','result':result.worker_state,'sender_attempts':attempts,'interpretation':'worker pre-entry TTL check passed; no recheck inside injected sender at modeled SDK call'})
finally: store.close()

blocked=[m for m in ('bt_api_ctp','bt_api_py','ctp') if m in sys.modules]
if blocked: raise SystemExit('native/provider modules loaded: '+repr(blocked))
print(json.dumps({'result':'PASS_LOCAL_NEGATIVE_PROBES','native_provider_modules_loaded':blocked,'cases':rows},sort_keys=True))