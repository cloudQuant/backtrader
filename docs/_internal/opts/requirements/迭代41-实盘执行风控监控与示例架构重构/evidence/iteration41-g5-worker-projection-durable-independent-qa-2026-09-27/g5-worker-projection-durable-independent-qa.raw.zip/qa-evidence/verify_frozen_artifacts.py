from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

candidate=Path(r'D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate')
archive=Path(r'D:\temp\iteration41-g5-worker-projection-durable-20260927-candidate.zip')
qa_root=Path(r'D:\temp\iteration41-g5-worker-projection-independent-qa-20260927')
sha=lambda b: hashlib.sha256(b).hexdigest()
input_manifest_path=candidate/'frozen-input-manifest.json'
output_manifest_path=candidate/'evidence/final-output-manifest.json'
input_manifest=json.loads(input_manifest_path.read_text(encoding='utf-8'))
output_manifest=json.loads(output_manifest_path.read_text(encoding='utf-8'))
inputs=input_manifest if isinstance(input_manifest,list) else input_manifest.get('inputs',input_manifest.get('files',[]))
outputs=output_manifest['outputs']
matched=[]; missing=[]; mismatched=[]; cache=[]
for e in inputs:
    rel=e['path'].replace('\\','/')
    p=candidate/rel
    if '__pycache__' in rel or rel.endswith('.pyc'):
        cache.append(rel); continue
    if not p.is_file(): missing.append(rel); continue
    actual=sha(p.read_bytes())
    if actual != e['sha256'].lower() or p.stat().st_size != e.get('bytes',p.stat().st_size):
        mismatched.append({'path':rel,'expected':e['sha256'],'actual':actual,'bytes':p.stat().st_size})
    else: matched.append(rel)
out_match=[]; out_missing=[]; out_mismatch=[]
for e in outputs:
    rel=e['path'].replace('\\','/')
    p=candidate/rel
    if not p.is_file(): out_missing.append(rel); continue
    actual=sha(p.read_bytes())
    if actual != e['sha256'].lower() or p.stat().st_size != e['bytes']:
        out_mismatch.append({'path':rel,'expected':e['sha256'],'actual':actual,'actual_bytes':p.stat().st_size})
    else: out_match.append(rel)
qa_candidate_matches=[]; qa_candidate_mismatch=[]
for e in outputs:
    rel=e['path'].replace('\\','/')
    p=qa_root/'candidate'/rel
    if p.is_file():
        if sha(p.read_bytes()) == e['sha256'].lower() and p.stat().st_size == e['bytes']:
            qa_candidate_matches.append(rel)
        else: qa_candidate_mismatch.append(rel)
qa_base_matches=[]; qa_base_mismatch=[]
for e in inputs:
    rel=e['path'].replace('\\','/')
    if not rel.startswith('inputs/sdk/'): continue
    sub=rel[len('inputs/sdk/'):]
    p=qa_root/'frozen_sdk'/sub
    if '__pycache__' in rel or rel.endswith('.pyc'): continue
    if not p.is_file() or sha(p.read_bytes()) != e['sha256'].lower() or p.stat().st_size != e.get('bytes',p.stat().st_size):
        qa_base_mismatch.append(rel)
    else: qa_base_matches.append(rel)
with zipfile.ZipFile(archive) as z:
    bad=z.testzip(); names=set(z.namelist()); zip_output_missing=[]; zip_output_mismatch=[]
    for e in outputs:
        rel=e['path'].replace('\\','/')
        if rel not in names: zip_output_missing.append(rel); continue
        actual=sha(z.read(rel))
        if actual != e['sha256'].lower(): zip_output_mismatch.append({'path':rel,'expected':e['sha256'],'actual':actual})
    zip_members=len(names)
result={
 'candidate_root':str(candidate),
 'frozen_input_manifest_sha256':sha(input_manifest_path.read_bytes()),
 'output_manifest_sha256':sha(output_manifest_path.read_bytes()),
 'candidate_archive_sha256':sha(archive.read_bytes()),
 'candidate_archive_bytes':archive.stat().st_size,
 'input_manifest_entries':len(inputs),'input_noncache_matches':len(matched),'input_cache_entries_excluded':len(cache),'input_missing':missing,'input_mismatch':mismatched,
 'output_entries':len(outputs),'output_match':len(out_match),'output_missing':out_missing,'output_mismatch':out_mismatch,
 'qa_candidate_copy_matches':len(qa_candidate_matches),'qa_candidate_copy_mismatches':qa_candidate_mismatch,
 'qa_frozen_sdk_copy_matches':len(qa_base_matches),'qa_frozen_sdk_copy_mismatches':qa_base_mismatch,
 'archive_members':zip_members,'archive_testzip':bad,'archive_output_missing':zip_output_missing,'archive_output_mismatch':zip_output_mismatch,
 'patch_sha256':sha((candidate/'implementation/sdk_patch/G5_TYPED_TARGET_PROJECTION_DURABLE_CONSUMER.patch').read_bytes()),
}
print(json.dumps(result,indent=2))
raise SystemExit(0 if not missing and not mismatched and not out_missing and not out_mismatch and not qa_candidate_mismatch and not qa_base_mismatch and not bad and not zip_output_missing and not zip_output_mismatch else 1)