from __future__ import annotations

import json
import sqlite3
import sys
from dataclasses import replace
from pathlib import Path

snapshot = Path(r"D:\temp\iteration41-cancel-control-r3-freeze-20260927")
evidence = Path(r"D:\temp\iteration41-cancel-control-r3-evidence-20260927")
sys.path.insert(0, str(snapshot / "tests"))
import test_cancellation_dispatch_resolution_control as t
from bt_api_py.runtime_plugins.cancellation_control import (
    ManagedCancellationReconciliationControlPort,
)
from bt_api_py.runtime_plugins.catalog import RuntimePluginError
from bt_api_py.runtime_plugins.fake_dispatch_authority import (
    FakeDispatchJournalError,
    ManagedFakeProviderJournalAuthority,
)
from bt_api_py.runtime_plugins.reconcile_control import AuthorizationDecision


def active_state(fixture):
    active = fixture.active()
    return {
        "unknown_freeze_active": fixture.unknown_cause in active,
        "release_progress_freeze_active": fixture.progress_cause in active,
    }


def outbox_event(path: Path, event_id: str):
    with sqlite3.connect(path) as connection:
        row = connection.execute(
            "SELECT event_type FROM monitor_outbox_events WHERE event_id = ?", (event_id,)
        ).fetchone()
    return None if row is None else row[0]


results = {}

root = evidence / "four-negative-state-final-rerun"
root.mkdir()
fixture = t._Fixture(root / "expiry-callback")
try:
    def approve_after_expiry(request):
        fixture.now = request.command.expires_at + 0.01
        return AuthorizationDecision(True, request.command.issuer_id, "0" * 64, "approved")

    fixture.control._authorize = approve_after_expiry
    try:
        t._release(fixture)
    except RuntimePluginError as error:
        code = error.code
    else:
        code = "UNEXPECTED_SUCCESS"
    audit = fixture.control.audit.get_command(fixture.command.command_id)
    results["authorization_callback_expiry"] = {
        "error_code": code,
        "audit_status": None if audit is None else audit.status.value,
        "release_applied_at": None if audit is None else audit.release_applied_at,
        "release_monitor_event": outbox_event(
            fixture.runtime.state_directory / "monitor.sqlite3",
            "cancel-freeze-release:" + fixture.command.command_id,
        ),
        **active_state(fixture),
    }
finally:
    fixture.close()

fixture = t._Fixture(root / "append-delete")
try:
    original_append = fixture.runtime.outbox.append
    event_id = "cancel-freeze-release:" + fixture.command.command_id

    def append_then_delete(event):
        receipt = original_append(event)
        if event.event_id == event_id:
            with sqlite3.connect(fixture.runtime.state_directory / "monitor.sqlite3") as connection:
                connection.execute("DELETE FROM monitor_outbox_events WHERE event_id = ?", (event_id,))
        return receipt

    fixture.runtime.outbox.append = append_then_delete
    try:
        t._release(fixture)
    except RuntimePluginError as error:
        code = error.code
    else:
        code = "UNEXPECTED_SUCCESS"
    audit = fixture.control.audit.get_command(fixture.command.command_id)
    results["append_commit_then_delete"] = {
        "error_code": code,
        "audit_status": None if audit is None else audit.status.value,
        "release_applied_at": None if audit is None else audit.release_applied_at,
        "release_monitor_event": outbox_event(
            fixture.runtime.state_directory / "monitor.sqlite3", event_id
        ),
        **active_state(fixture),
    }
finally:
    fixture.close()

fixture = t._Fixture(root / "final-latch-expiry")
try:
    original_mark_released = fixture.control.audit.mark_command_released

    def mark_then_expire(command_id):
        result = original_mark_released(command_id)
        fixture.now = fixture.command.expires_at + 0.01
        return result

    fixture.control.audit.mark_command_released = mark_then_expire
    try:
        t._release(fixture)
    except RuntimePluginError as error:
        code = error.code
    else:
        code = "UNEXPECTED_SUCCESS"
    audit = fixture.control.audit.get_command(fixture.command.command_id)
    results["expiry_after_release_audit_commit"] = {
        "error_code": code,
        "audit_status": None if audit is None else audit.status.value,
        "released_at": None if audit is None else audit.released_at,
        "release_applied_at": None if audit is None else audit.release_applied_at,
        "release_monitor_event": outbox_event(
            fixture.runtime.state_directory / "monitor.sqlite3",
            "cancel-freeze-release:" + fixture.command.command_id,
        ),
        **active_state(fixture),
    }
finally:
    fixture.close()

fixture = t._Fixture(root / "ctp-provider")
control = None
authority = fixture.runtime.fake_dispatch_authority
original_scope = authority._execution_scope
try:
    scope = replace(fixture.runtime.scope, provider="ctp")
    authority._execution_scope = scope
    runtime = replace(fixture.runtime, scope=scope)
    calls = []
    control = ManagedCancellationReconciliationControlPort(
        runtime,
        fixture.cancel_facade,
        state_directory=root / "ctp-provider-control",
        authorize=lambda request: calls.append(request),
    )
    command = replace(fixture.command, scope=scope.key)
    try:
        control.release_cancel_freeze(command)
    except RuntimePluginError as error:
        code = error.code
    else:
        code = "UNEXPECTED_SUCCESS"
    audit = control.audit.get_command(command.command_id)
    results["ctp_labeled_execution_scope"] = {
        "error_code": code,
        "authorizer_calls": len(calls),
        "control_audit_command_exists": audit is not None,
        "execution_provider": scope.provider,
        **active_state(fixture),
    }
finally:
    if control is not None:
        control.close()
    authority._execution_scope = original_scope
    fixture.close()

fixture = t._Fixture(root / "wrong-account")
try:
    bad_scope = replace(fixture.runtime.scope, account_ref="unregistered-account")
    bad_risk_scope = replace(fixture.runtime.risk_scope, account_id="unregistered-account")
    database_path = root / "wrong-account-authority.sqlite3"
    try:
        ManagedFakeProviderJournalAuthority(
            database_path=database_path,
            execution_scope=bad_scope,
            risk_scope=bad_risk_scope,
            execution_store=fixture.runtime.execution_store,
            facade=None,
            risk_types=t.risk,
            contract=fixture.runtime.contract,
            policy_id=fixture.runtime.risk_gate.policy.policy_id,
        )
    except FakeDispatchJournalError as error:
        code = type(error).__name__
    else:
        code = "UNEXPECTED_SUCCESS"
    results["wrong_account_scope"] = {
        "rejection": code,
        "authority_database_created": database_path.exists(),
        "execution_scope_account_ref": bad_scope.account_ref,
        "risk_scope_account_id": bad_risk_scope.account_id,
        **active_state(fixture),
    }
finally:
    fixture.close()

results["module_origins"] = {
    "execution": str(Path(t.execution.__file__).resolve()),
    "risk": str(Path(t.risk.__file__).resolve()),
    "monitor": str(Path(t.monitor.__file__).resolve()),
    "fake_authority": str(
        Path(sys.modules["bt_api_py.runtime_plugins.fake_dispatch_authority"].__file__).resolve()
    ),
}
print(json.dumps(results, indent=2, sort_keys=True))
