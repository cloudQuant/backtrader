import ast
from pathlib import Path
for value in (
    "bt_api_py/runtime_plugins/fake_dispatch_authority.py",
    "bt_api_py/runtime_plugins/managed.py",
    "bt_api_py/runtime_plugins/cancellation_control.py",
    "tests/test_cancellation_dispatch_resolution_control.py",
):
    ast.parse(Path(value).read_text(encoding="utf-8"))
print("4 files parsed")
