import difflib
from pathlib import Path
old = Path(r"D:\temp\iteration41-cancel-control-composition-freeze-r2-20260927")
new = Path(r"D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927")
paths = (
    "bt_api_py/runtime_plugins/cancellation_control.py",
    "bt_api_py/runtime_plugins/fake_dispatch_authority.py",
    "bt_api_py/runtime_plugins/managed.py",
    "tests/test_cancellation_dispatch_resolution_control.py",
)
chunks = []
for relative in paths:
    before = (old / relative).read_text(encoding="utf-8").splitlines(keepends=True)
    after = (new / relative).read_text(encoding="utf-8").splitlines(keepends=True)
    chunks.extend(difflib.unified_diff(before, after, fromfile="r2/" + relative, tofile="r3/" + relative))
out = Path(r"D:\temp\iteration41-cancel-control-r3-evidence-20260927\r3-changes.diff")
out.write_text("".join(chunks), encoding="utf-8")
print(out)
