# Cancellation-control r3 receipt (fake-only)

## Frozen snapshot

- Snapshot: `D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927`
- `payload-manifest.json` SHA-256: `65af6f048a1148182b35a18b8998f738a306d83b5d33352bd469c809c3a8d28f`
- Manifest verification: 154 payload files matched their recorded size and SHA-256; no unlisted payload files were present when checked.
- Main changed-file hashes:
  - `bt_api_py/runtime_plugins/cancellation_control.py`: `9af8665d98d414c475479da1eb9d2ebbc7b502853ad877f628e5118acb528d9b`
  - `bt_api_py/runtime_plugins/fake_dispatch_authority.py`: `ff31893935aed8ac7944c5f720eb46553298cf593553dbbe64ad74583b89dc06`
  - `bt_api_py/runtime_plugins/managed.py`: `45708013afd32c0d97d87ba9ca92aaa773a14e272e12e11fdb0f85223b947aba`
  - `tests/test_cancellation_dispatch_resolution_control.py`: `e80bfc25ee9cdaafcee95d4b97e1bb598c420b04dc92ee331941af757c38d2a2`
- Unified source/test diff from frozen r2: `r3-changes.diff`.

## Changes and checks

R3 keeps the r2 directory and its evidence unchanged. It adds a second expiry check after the injected authorizer returns, an exact monitor-event readback on the first release path before the audit can remain `RELEASED`, and an expiry check at the last release boundary. If expiry is detected after the release audit was tentatively committed but before the final latch is cleared, r3 reasserts both risk causes and changes the command audit to `EXPIRED` with `released_at` cleared.

The fake journal authority now requires the exact registered tuple of strategy, execution provider, account, and risk policy, together with the offline simulation/replay/managed-execution contract. It verifies this at authority construction and again at release. A mismatched CTP-labeled execution scope or unregistered account/strategy is rejected before the authorizer or audit release operation.

Focused command, run against the frozen snapshot with Python 3.11.5:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
python -m pytest --noconftest -p no:cacheprovider tests/test_cancellation_dispatch_resolution_control.py -q
```

Result: **15 passed** (`focused-tests-r1.log`). Targeted Ruff checks passed for the new fake-binding predicate (`SIM103`) and `managed.py` import ordering (`I`); see `ruff_policy_r1.log` and `ruff_imports_r1.log`. Four source/test files parsed with `ast.parse` (`syntax-check.log`).

## Negative probe outcomes

Raw result JSON and SQLite state are in `four-negative-probes-final.log` and `four-negative-state-final-rerun`.

- Authorizer advances the injected clock beyond expiry before returning approval: `CANCELLATION_CONTROL_COMMAND_EXPIRED`; audit status `expired`; no release-applied timestamp or release event; unknown-cancel freeze stays active.
- Monitor append commits and the event is deleted before append returns: `CANCELLATION_CONTROL_MONITOR_OUTBOX_UNCONFIRMED`; audit returns to `pending`; prepared release event is absent; both unknown and release-progress freezes are active, including after reopening the control port in the pytest case.
- Execution scope relabeled `provider='ctp'` while matching the fake authority’s stored scope object: `CANCELLATION_DISPATCH_RESOLUTION_AUTHORITY_REQUIRED`; authorizer calls `0`; no control audit command; unknown freeze active.
- Unregistered account scope at fake-authority construction: `FakeDispatchJournalError`; authority database was not created; unknown freeze active.
- Clock crosses expiry after the release audit commit but before final latch removal: `CANCELLATION_CONTROL_COMMAND_EXPIRED`; final status `expired`, `released_at=null`; monitor prepared event remains as an audit fact; both risk freezes are active.

The loaded execution, risk, monitor and fake-authority import origins are printed in the probe log and are asserted by the focused test module. No CTP SDK/native module, native provider, credentials, network, or real account were used.

## Remaining limits

The monitor and risk state live in separate SQLite databases, so there is no cross-database atomic commit. The exact event readback rejects deletion before the readback, but it does not prevent another process with write access from deleting or changing the monitor row immediately after the readback and before the final risk-latch operation. R3 does not establish a protected file-ownership boundary for that interval.

The injected `authorize` callback remains a trusted local seam; this slice does not authenticate a real operator, verify a cryptographic one-time authorization token, or establish native cancellation terminality. These results are fake-only and do not enable real CTP, SimNow, production, or a default route.

The prior r2 audit report and candidate are preserved separately at `D:\temp\iteration41_cancel_control_r2_audit_20260927` and `D:\temp\iteration41-cancel-control-composition-freeze-r2-20260927`. The updated r2 audit manifest SHA-256 is `dae12f0bdcf3b06e65f187313bf23ec8f1b10f2badd52f79e580329fd16b1b10`; its pre-provider-boundary manifest is retained as `manifest-r2-pre-provider-boundary.json`.
