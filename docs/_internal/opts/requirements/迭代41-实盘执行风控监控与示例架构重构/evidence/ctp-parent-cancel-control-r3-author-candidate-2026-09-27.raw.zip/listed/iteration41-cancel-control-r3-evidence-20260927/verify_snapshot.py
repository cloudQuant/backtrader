import hashlib, json
from pathlib import Path
root = Path(r"D:\temp\iteration41-cancel-control-r3-freeze-20260927")
raw = (root / "payload-manifest.json").read_bytes()
entries = json.loads(raw.decode("utf-8-sig"))
expected = {entry["path"].replace("\\", "/"): entry for entry in entries}
actual = {
    str(path.relative_to(root)).replace("\\", "/")
    for path in root.rglob("*") if path.is_file() and path.name != "payload-manifest.json"
}
assert actual == set(expected), (sorted(actual - set(expected)), sorted(set(expected) - actual))
for relative, entry in expected.items():
    data = (root / relative).read_bytes()
    assert len(data) == entry["size"]
    assert hashlib.sha256(data).hexdigest() == entry["sha256"]
print("manifest_sha256=" + hashlib.sha256(raw).hexdigest())
print("verified_payload_files=" + str(len(expected)))
for relative in (
    "bt_api_py/runtime_plugins/cancellation_control.py",
    "bt_api_py/runtime_plugins/fake_dispatch_authority.py",
    "bt_api_py/runtime_plugins/managed.py",
    "tests/test_cancellation_dispatch_resolution_control.py",
):
    print(relative + "=" + expected[relative]["sha256"])
