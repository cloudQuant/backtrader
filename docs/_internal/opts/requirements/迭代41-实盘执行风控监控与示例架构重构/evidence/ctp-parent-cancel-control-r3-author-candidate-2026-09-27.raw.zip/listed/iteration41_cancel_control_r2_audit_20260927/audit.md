# Cancellation-control r2 first-release audit (fake only)

## Snapshot and method

- Frozen candidate: `D:\temp\iteration41-cancel-control-composition-freeze-r2-20260927`.
- The candidate directory has no `.git` metadata and no root manifest. This receipt pins the relevant source/test bytes by SHA-256 in `manifest.json`.
- Entry under review: `ManagedCancellationReconciliationControlPort.release_cancel_freeze`, first non-`RELEASED` branch. It runs only against the candidate's synthetic replay fixture and pinned local Python packages. The test module asserts the loaded execution, risk, monitor, and fake-authority origins. No CTP SDK/native module, provider, credentials, or network was used.
- Reproducer: `reproduce_first_release_gaps.py`; command: `$env:PYTHONDONTWRITEBYTECODE='1'; python D:\temp\iteration41_cancel_control_r2_audit_20260927\reproduce_first_release_gaps.py`.
- Snapshot inspection: `inspect_snapshots.py`; command: `$env:PYTHONDONTWRITEBYTECODE='1'; python D:\temp\iteration41_cancel_control_r2_audit_20260927\inspect_snapshots.py`.
- The reproducer exits successfully only when it observes both defects below. Output and SQLite backup snapshots are preserved beside this report.

## Findings

### 1. Authorization callback can outlive the command expiry

`release_cancel_freeze` checks `command.expires_at` at line 1156, before `_authorize_command` calls the injected callback (line 1189). `_authorize_command` validates only the result type and `decision.subject_id == command.issuer_id`; it does not recheck expiry or verify a cryptographic/one-time authorization receipt. `AuthorizationDecision` validates `receipt_digest` syntax, not its source or binding.

The fake reproducer advances the injected clock to `expires_at + 1` inside `authorize`, then returns `AuthorizationDecision(True, command.issuer_id, '0' * 64, 'approved')`. The first release still returns `released=True`; its audit row stores that all-zero digest. The authorization request is therefore only a trusted callback boundary, not an independently verified authorization proof in this snapshot.

**Needed rejection tests:** callback crosses expiry before returning; callback crosses expiry after its decision but before final latch removal; both must leave the risk freeze active, keep the command non-`RELEASED`, and refuse provider/account mutation. Add a positive test for a deployment-owned validator that binds exact command ID, evidence digest, issuer, action, expiry, and one-time nonce. Until such a validator is supplied and independently tested, a permissive callback is suitable only for fake tests.

### 2. First release trusts append return and has a two-database tamper window

The non-replay branch appends `cancellation_freeze_release_prepared` (around lines 1257–1275), marks the control audit row `RELEASED` (line 1283), then clears the final risk progress latch. It does not call `_verify_release_prepared_monitor_fact` there. That readback exists only in `_resume_released_command` (line 1558), so ordinary startup does not verify an already released row.

The reproducer wraps the real `DurableOutbox.append`: it first lets the SQLite transaction commit the exact event, then deletes that row before returning to the release code. The release returns success; the control DB says `released`; the monitor DB has no prepared event; all risk freeze rows are inactive. Constructing a new control port does not reassert because startup recovery scans only pending/authorized prepared releases. The snapshots show the event present immediately after append and absent before the risk latch is cleared.

This is a concrete local concurrent-writer/tamper window across independent SQLite databases, not a normal `DurableOutbox.append` failure. Exact readback before final release is necessary to reject the reproduced case, but readback alone cannot prevent a writer from deleting the event immediately after the check. The code currently has no pinned DB identity or OS-level exclusive-write protection for the monitor file, and the risk/control/monitor journals cannot commit atomically together.

**Needed rejection tests:** append returns after the prepared event is deleted, changed, or inserted under a mismatched fingerprint; release must refuse and reassert both latches, and startup must remain blocked. Add a second writer that mutates the monitor DB between readback and final latch removal. If that threat is in scope, the implementation needs a protected single canonical journal or a reviewed OS/file-ownership boundary plus explicit residual tamper assumptions; another readback does not close that race.

### 3. Fake proof is not normal CTP evidence, but r2 did not bind the execution provider

The normal `compose_managed_execution` CTP branch uses a CTP risk scope and does not install `ManagedFakeProviderJournalAuthority`; that standard path rejects. However, r2 `_require_cancel_resolution_authority` checked only the risk provider (`fake`), offline environments, and object equality. It did not require the execution provider to be one of the exact registered offline fake providers.

`probe_ctp_labeled_execution_scope.py` reproduces this gap with synthetic in-process wiring: it changes the execution scope provider to `ctp` and changes the authority's stored execution-scope reference to match, while retaining the fake/offline risk scope. `_require_cancel_resolution_authority()` accepts the fake authority. The probe constructs no CTP client, native module, or provider; it demonstrates that the local fake proof gate did not itself reject the mismatched scope.

Additionally, `CancellationReconciliationEvidence` accepts any syntactically valid SHA-256 string as `source_receipt_digest`; `_validated_observation` checks typed identities/state but does not authenticate that digest against a native callback or independent source. The fixture uses repeated-character digests and caller-created typed observations. That proves only fake journal behavior. Keep this code unregistered for real CTP and require exact code-owned execution-provider/account/policy binding at both fake-authority construction and release time. Real CTP still needs a distinct verified native evidence and production authorization contract.

### 4. r3 closes the local provider-label and first-release checks

The separate r3 candidate now validates the exact registered offline tuple `(strategy, execution provider, account, risk policy)` in `ManagedFakeProviderJournalAuthority` construction and again in `_require_cancel_resolution_authority`. Its negative tests reject a CTP-labeled execution scope before authorizer/audit activity and reject unregistered account/strategy scopes before creating the fake journal. The r3 first-release branch also performs an exact monitor outbox readback before recording RELEASED and checks the injected expiry clock after the authorizer and immediately before final release confirmation/latch removal. See the separate r3 frozen receipt; this does not change or retroactively alter the r2 finding.

## Repro result

The observed run returned `released=True` after the injected clock had passed expiry, stored receipt digest `000...000`, and had no `cancel-freeze-release:*` row in monitor SQLite. `risk_after_release.sqlite3` records the dispatch, unknown, and release-progress freezes as inactive. A new control-port constructor left them inactive. `snapshot_inspection.log` records the exact audit/monitor/risk rows.

## Limits

This audit demonstrates fake-only control-flow and local SQLite behavior. It does not establish real-provider cancel terminality, real authorization, CTP source provenance, safe production file permissions, or a real trading route. The fake gate is a meaningful fail-closed discriminator; it is not a production-ready release authority.
