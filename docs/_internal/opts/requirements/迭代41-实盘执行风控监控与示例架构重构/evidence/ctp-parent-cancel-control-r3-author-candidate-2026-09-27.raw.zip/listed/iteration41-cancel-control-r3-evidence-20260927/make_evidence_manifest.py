import hashlib, json
from pathlib import Path
root = Path(r"D:\temp\iteration41-cancel-control-r3-evidence-20260927")
external = [
    Path(r"D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927\payload-manifest.json"),
    Path(r"D:\temp\iteration41_cancel_control_r2_audit_20260927\audit.md"),
    Path(r"D:\temp\iteration41_cancel_control_r2_audit_20260927\manifest.json"),
    Path(r"D:\temp\iteration41_cancel_control_r2_audit_20260927\manifest-r2-pre-provider-boundary.json"),
]
paths = sorted(p for p in root.rglob("*") if p.is_file() and p.name != "evidence-manifest.json")
paths += external
entries = []
for path in paths:
    data = path.read_bytes()
    entries.append({"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
manifest = {"schema": "iteration41-cancel-control-r3-evidence-v1", "entries": entries}
out = root / "evidence-manifest.json"
out.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print("entries=" + str(len(entries)))
print("manifest=" + str(out))
print("sha256=" + hashlib.sha256(out.read_bytes()).hexdigest())
