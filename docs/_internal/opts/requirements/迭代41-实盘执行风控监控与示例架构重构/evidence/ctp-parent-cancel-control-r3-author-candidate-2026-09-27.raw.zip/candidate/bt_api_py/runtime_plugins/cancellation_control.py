"""Fail-closed control for reconciling an unknown managed cancellation.

The Backtrader bridge creates an account freeze whenever a provider cancellation
attempt has an unknown outcome.  A normal cancellation reconciliation records
typed evidence but intentionally cannot clear that latch.  This composition
module provides the only local release path: immutable evidence, a durable
audit entry, a durable monitor-outbox fact, and an identity-bound authorization
decision must all be present before one exact cancellation freeze can clear.

It owns no provider client and does not acquire provider evidence.  Callers
must supply a typed ``CancelObservation`` obtained by independently controlled
reconciliation code.  Any failure after a local release reasserts the same
freeze; an ``UNKNOWN`` cancellation never releases automatically.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
import time
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .catalog import RuntimePluginError
from .reconcile_control import AuthorizationDecision, ControlCommandStatus

_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_REASON_CODE = re.compile(r"^[a-z][a-z0-9_]{0,127}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


class CancellationControlAuditError(RuntimeError):
    """Base error for the local cancellation-control audit ledger."""


class CancellationControlAuditConflictError(CancellationControlAuditError):
    """An immutable cancellation evidence or command identity was reused."""


def _identifier(value: object, field_name: str) -> str:
    if not isinstance(value, str) or value != value.strip() or not _IDENTIFIER.fullmatch(value):
        raise ValueError("invalid " + field_name)
    return value


def _reason_code(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not _REASON_CODE.fullmatch(value):
        raise ValueError("invalid " + field_name)
    return value


def _digest(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not _SHA256.fullmatch(value):
        raise ValueError("invalid " + field_name)
    return value


def _timestamp(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("invalid " + field_name)
    return float(value)


def _canonical_json(value: object) -> str:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False
    )


def _sha256(value: object) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


_CANCEL_DISPATCH_PROOF_SCHEMA = "bt-api-risk-cancel-dispatch-resolution-v1"
_CANCEL_DISPATCH_PROOF_FIELDS = (
    "permit_id",
    "intent_id",
    "intent_hash",
    "cause_id",
    "claim_digest",
    "evidence_class",
    "dispatch_attempt_count",
    "execution_scope_key",
    "cancel_id",
    "target_intent_id",
    "provider_order_id",
    "cancel_intent_fingerprint",
    "terminal_state",
    "cancel_event_id",
    "cancel_event_sequence",
    "cancel_event_sha256",
    "cancel_source",
    "source_evidence_sha256",
    "target_postcondition",
    "target_state",
    "target_filled_quantity",
    "target_updated_at_ns",
    "target_record_sha256",
    "target_event_id",
    "target_event_sequence",
    "target_event_type",
    "target_event_sha256",
    "writer_owner_id",
    "writer_fencing_token",
    "writer_fence_sha256",
)
_CANCEL_DISPATCH_PROOF_ENUMS = {
    "evidence_class": "DispatchEvidenceClass",
    "terminal_state": "CancelDispatchTerminalState",
    "cancel_source": "CancelDispatchSource",
    "target_postcondition": "CancelTargetPostcondition",
}


def _cancel_dispatch_proof_payload(proof: Any) -> dict[str, object]:
    """Return the exact scalar document used by the risk proof fingerprint."""

    scope = getattr(proof, "scope", None)
    scope_key = getattr(scope, "key", None)
    if type(scope_key) is not str or not scope_key:
        raise ValueError("invalid cancel dispatch proof scope")
    payload: dict[str, object] = {
        "schema": _CANCEL_DISPATCH_PROOF_SCHEMA,
        "scope_key": scope_key,
    }
    for name in _CANCEL_DISPATCH_PROOF_FIELDS:
        value = getattr(proof, name, None)
        payload[name] = getattr(value, "value", value)
    return payload


def _restore_cancel_dispatch_proof(
    payload_json: str, payload_sha256: str, authority: Any
) -> Any:
    """Reconstruct only the exact risk-owned proof type from its durable payload."""

    try:
        payload = json.loads(payload_json)
    except (TypeError, ValueError) as error:
        raise ValueError("stored cancellation proof is unreadable") from error
    expected_keys = {"schema", "scope_key", *_CANCEL_DISPATCH_PROOF_FIELDS}
    risk_types = getattr(authority, "_risk_types", None)
    proof_type = getattr(risk_types, "CancelDispatchResolutionProof", None)
    risk_scope = getattr(authority, "_risk_scope", None)
    if (
        type(payload) is not dict
        or set(payload) != expected_keys
        or payload.get("schema") != _CANCEL_DISPATCH_PROOF_SCHEMA
        or type(payload.get("scope_key")) is not str
        or type(payload_sha256) is not str
        or _canonical_json(payload) != payload_json
        or _sha256(payload) != payload_sha256
        or not isinstance(proof_type, type)
        or getattr(risk_scope, "key", None) != payload.get("scope_key")
    ):
        raise ValueError("stored cancellation proof identity or digest is invalid")
    values = {name: payload[name] for name in _CANCEL_DISPATCH_PROOF_FIELDS}
    for field_name, enum_name in _CANCEL_DISPATCH_PROOF_ENUMS.items():
        enum_type = getattr(risk_types, enum_name, None)
        if not isinstance(enum_type, type):
            raise ValueError("risk cancellation proof enum is unavailable")
        values[field_name] = enum_type(values[field_name])
    proof = proof_type(scope=risk_scope, **values)
    if (
        type(proof) is not proof_type
        or proof.fingerprint != payload_sha256
        or _cancel_dispatch_proof_payload(proof) != payload
    ):
        raise ValueError("stored cancellation proof does not reconstruct exactly")
    return proof


def _observation_projection(observation: object) -> dict[str, object]:
    """Return the only redacted cancellation evidence persisted by this module."""

    try:
        state = observation.state.value  # type: ignore[attr-defined]
        cancel_id = observation.cancel_id  # type: ignore[attr-defined]
        target_intent_id = observation.target_intent_id  # type: ignore[attr-defined]
        provider_order_id = observation.provider_order_id  # type: ignore[attr-defined]
        reason_code = observation.reason_code  # type: ignore[attr-defined]
    except AttributeError as error:
        raise ValueError("invalid typed cancellation observation") from error
    return {
        "cancel_id": _identifier(cancel_id, "observation cancel_id"),
        "target_intent_id": _identifier(target_intent_id, "observation target_intent_id"),
        "provider_order_id": _identifier(provider_order_id, "observation provider_order_id"),
        "state": _identifier(state, "observation state"),
        "reason_code": (
            None if reason_code is None else _reason_code(reason_code, "observation reason_code")
        ),
    }


def _record_projection(record: object) -> dict[str, object]:
    """Return a stable, non-secret cancellation record projection for audit checks."""

    try:
        state = record.state.value  # type: ignore[attr-defined]
        cancel_id = record.cancel_id  # type: ignore[attr-defined]
        target_intent_id = record.target_intent_id  # type: ignore[attr-defined]
        provider_order_id = record.provider_order_id  # type: ignore[attr-defined]
        review_required = record.review_required  # type: ignore[attr-defined]
    except AttributeError as error:
        raise ValueError("invalid cancellation record") from error
    if type(review_required) is not bool:
        raise ValueError("invalid cancellation record review_required")
    return {
        "cancel_id": _identifier(cancel_id, "record cancel_id"),
        "target_intent_id": _identifier(target_intent_id, "record target_intent_id"),
        "provider_order_id": _identifier(provider_order_id, "record provider_order_id"),
        "state": _identifier(state, "record state"),
        "review_required": review_required,
    }


@dataclass(frozen=True)
class CancellationReconciliationEvidence:
    """Externally obtained typed evidence for one unknown cancellation attempt."""

    evidence_id: str
    cancel_id: str
    target_intent_id: str
    provider_order_id: str
    observation: Any
    source_receipt_digest: str
    observed_at: float

    def __post_init__(self) -> None:
        for name in ("evidence_id", "cancel_id", "target_intent_id", "provider_order_id"):
            object.__setattr__(self, name, _identifier(getattr(self, name), name))
        object.__setattr__(
            self,
            "source_receipt_digest",
            _digest(self.source_receipt_digest, "source_receipt_digest"),
        )
        object.__setattr__(self, "observed_at", _timestamp(self.observed_at, "observed_at"))

    @property
    def fingerprint(self) -> str:
        """Return immutable identity binding typed evidence to its receipt digest."""

        return _sha256(
            {
                "cancel_id": self.cancel_id,
                "evidence_id": self.evidence_id,
                "observation": _observation_projection(self.observation),
                "observed_at": self.observed_at,
                "provider_order_id": self.provider_order_id,
                "source_receipt_digest": self.source_receipt_digest,
                "target_intent_id": self.target_intent_id,
            }
        )


@dataclass(frozen=True)
class ReleaseCancellationFreezeCommand:
    """One reviewed request to clear exactly one unknown-cancel freeze."""

    command_id: str
    scope: str
    cancel_id: str
    evidence_id: str
    evidence_fingerprint: str
    issuer_id: str
    reason_code: str
    issued_at: float
    expires_at: float

    def __post_init__(self) -> None:
        for name in ("command_id", "scope", "cancel_id", "evidence_id", "issuer_id"):
            object.__setattr__(self, name, _identifier(getattr(self, name), name))
        object.__setattr__(
            self,
            "evidence_fingerprint",
            _digest(self.evidence_fingerprint, "evidence_fingerprint"),
        )
        object.__setattr__(self, "reason_code", _reason_code(self.reason_code, "reason_code"))
        object.__setattr__(self, "issued_at", _timestamp(self.issued_at, "issued_at"))
        object.__setattr__(self, "expires_at", _timestamp(self.expires_at, "expires_at"))
        if self.expires_at <= self.issued_at:
            raise ValueError("expires_at must be after issued_at")

    @property
    def fingerprint(self) -> str:
        return _sha256(
            {
                "cancel_id": self.cancel_id,
                "command_id": self.command_id,
                "evidence_fingerprint": self.evidence_fingerprint,
                "evidence_id": self.evidence_id,
                "expires_at": self.expires_at,
                "issued_at": self.issued_at,
                "issuer_id": self.issuer_id,
                "reason_code": self.reason_code,
                "scope": self.scope,
            }
        )


@dataclass(frozen=True)
class CancellationReleaseAuthorizationRequest:
    """Redacted context passed to a deployment-owned authorization callback."""

    command: ReleaseCancellationFreezeCommand
    evidence: CancellationReconciliationEvidence
    reconciled_record: Mapping[str, object]


@dataclass(frozen=True)
class CancellationReconciliationAudit:
    """Durable local evidence and monitor-outbox status for one cancellation."""

    evidence_id: str
    fingerprint: str
    scope: str
    cancel_id: str
    target_intent_id: str
    provider_order_id: str
    observation: Mapping[str, object]
    record: Mapping[str, object]
    source_receipt_digest: str
    observed_at: float
    monitor_event_id: str
    monitor_published: bool


@dataclass(frozen=True)
class CancellationControlCommandAudit:
    """Durable state for a requested cancellation-freeze release."""

    command: ReleaseCancellationFreezeCommand
    status: ControlCommandStatus
    authorization_subject_id: str | None
    authorization_receipt_digest: str | None
    authorization_reason_code: str | None
    release_applied_at: float | None
    released_at: float | None
    outcome_code: str | None


@dataclass(frozen=True)
class ControlledCancellationReconciliationResult:
    """Result of reconciling a cancellation and recording its monitor fact."""

    record: Any
    audit: CancellationReconciliationAudit


@dataclass(frozen=True)
class CancellationFreezeReleaseResult:
    """Result of a reviewed cancellation-freeze release."""

    command_id: str
    cancel_id: str
    released: bool
    idempotent: bool


class DurableCancellationControlAudit:
    """SQLite audit ledger for cancellation evidence and release commands."""

    def __init__(
        self,
        database_path: Path | str,
        *,
        clock: Callable[[], float] | None = None,
        timeout_seconds: float = 5.0,
    ) -> None:
        self._database_path = Path(database_path)
        self._clock = clock or time.time
        self._timeout_seconds = timeout_seconds
        self._database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize_schema()

    def close(self) -> None:
        """Keep a symmetric lifecycle hook; each SQLite operation owns its connection."""

    def get_reconciliation(self, evidence_id: str) -> CancellationReconciliationAudit | None:
        evidence_id = _identifier(evidence_id, "evidence_id")
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM cancellation_control_evidence WHERE evidence_id = ?", (evidence_id,)
            ).fetchone()
        return None if row is None else self._reconciliation_from_row(row)

    def record_reconciliation(
        self,
        evidence: CancellationReconciliationEvidence,
        *,
        scope: str,
        observation: Mapping[str, object],
        record: Mapping[str, object],
        monitor_event_id: str,
    ) -> CancellationReconciliationAudit:
        """Persist immutable evidence before it can release a risk latch."""

        scope = _identifier(scope, "scope")
        monitor_event_id = _identifier(monitor_event_id, "monitor_event_id")
        fingerprint = evidence.fingerprint
        observation_json = _canonical_json(observation)
        record_json = _canonical_json(record)
        now = self._clock()
        with self._transaction() as connection:
            existing = connection.execute(
                "SELECT * FROM cancellation_control_evidence WHERE evidence_id = ?",
                (evidence.evidence_id,),
            ).fetchone()
            if existing is not None:
                if (
                    str(existing["fingerprint"]) != fingerprint
                    or str(existing["scope"]) != scope
                    or str(existing["cancel_id"]) != evidence.cancel_id
                    or str(existing["target_intent_id"]) != evidence.target_intent_id
                    or str(existing["provider_order_id"]) != evidence.provider_order_id
                    or str(existing["monitor_event_id"]) != monitor_event_id
                ):
                    raise CancellationControlAuditConflictError(
                        "evidence_id was reused with different content"
                    )
                return self._reconciliation_from_row(existing)
            connection.execute(
                """
                INSERT INTO cancellation_control_evidence (
                    evidence_id, fingerprint, scope, cancel_id, target_intent_id, provider_order_id,
                    observation_json, record_json, source_receipt_digest, observed_at,
                    monitor_event_id, monitor_published, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
                """,
                (
                    evidence.evidence_id,
                    fingerprint,
                    scope,
                    evidence.cancel_id,
                    evidence.target_intent_id,
                    evidence.provider_order_id,
                    observation_json,
                    record_json,
                    evidence.source_receipt_digest,
                    evidence.observed_at,
                    monitor_event_id,
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT * FROM cancellation_control_evidence WHERE evidence_id = ?",
                (evidence.evidence_id,),
            ).fetchone()
            assert row is not None
            return self._reconciliation_from_row(row)

    def mark_reconciliation_monitor_published(
        self, evidence_id: str, monitor_event_id: str
    ) -> CancellationReconciliationAudit:
        """Record that the exact cancellation fact reached the durable outbox."""

        evidence_id = _identifier(evidence_id, "evidence_id")
        monitor_event_id = _identifier(monitor_event_id, "monitor_event_id")
        with self._transaction() as connection:
            row = connection.execute(
                "SELECT * FROM cancellation_control_evidence WHERE evidence_id = ?", (evidence_id,)
            ).fetchone()
            if row is None:
                raise CancellationControlAuditError("cancellation evidence does not exist")
            if str(row["monitor_event_id"]) != monitor_event_id:
                raise CancellationControlAuditConflictError(
                    "monitor event differs from cancellation evidence"
                )
            connection.execute(
                """
                UPDATE cancellation_control_evidence
                SET monitor_published = 1, updated_at = ? WHERE evidence_id = ?
                """,
                (self._clock(), evidence_id),
            )
            updated = connection.execute(
                "SELECT * FROM cancellation_control_evidence WHERE evidence_id = ?", (evidence_id,)
            ).fetchone()
            assert updated is not None
            return self._reconciliation_from_row(updated)

    def get_command(self, command_id: str) -> CancellationControlCommandAudit | None:
        command_id = _identifier(command_id, "command_id")
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM cancellation_control_commands WHERE command_id = ?", (command_id,)
            ).fetchone()
        return None if row is None else self._command_from_row(row)

    def record_command(
        self, command: ReleaseCancellationFreezeCommand
    ) -> CancellationControlCommandAudit:
        """Persist an immutable release command before authorization or risk mutation."""

        now = self._clock()
        with self._transaction() as connection:
            existing = connection.execute(
                "SELECT * FROM cancellation_control_commands WHERE command_id = ?",
                (command.command_id,),
            ).fetchone()
            if existing is not None:
                if str(existing["fingerprint"]) != command.fingerprint:
                    raise CancellationControlAuditConflictError(
                        "command_id was reused with different content"
                    )
                return self._command_from_row(existing)
            connection.execute(
                """
                INSERT INTO cancellation_control_commands (
                    command_id, fingerprint, scope, cancel_id, evidence_id, evidence_fingerprint,
                    issuer_id, reason_code, issued_at, expires_at, status, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    command.command_id,
                    command.fingerprint,
                    command.scope,
                    command.cancel_id,
                    command.evidence_id,
                    command.evidence_fingerprint,
                    command.issuer_id,
                    command.reason_code,
                    command.issued_at,
                    command.expires_at,
                    ControlCommandStatus.PENDING.value,
                    now,
                ),
            )
            self._append_attempt(
                connection, command.command_id, "command_recorded", "command_recorded", now
            )
            return self._command_from_row(self._command_row(connection, command.command_id))

    def record_authorization(
        self, command_id: str, decision: AuthorizationDecision
    ) -> CancellationControlCommandAudit:
        """Durably audit an identity-bound authorization before a latch release."""

        command_id = _identifier(command_id, "command_id")
        now = self._clock()
        with self._transaction() as connection:
            row = self._command_row(connection, command_id)
            status = ControlCommandStatus(str(row["status"]))
            if status in {ControlCommandStatus.RELEASED, ControlCommandStatus.EXPIRED}:
                raise CancellationControlAuditError("command is no longer authorizable")
            next_status = (
                ControlCommandStatus.AUTHORIZED
                if decision.approved
                else ControlCommandStatus.DENIED
            )
            connection.execute(
                """
                UPDATE cancellation_control_commands
                SET status = ?, authorization_subject_id = ?, authorization_receipt_digest = ?,
                    authorization_reason_code = ?, authorization_at = ?, outcome_code = ?,
                    updated_at = ?
                WHERE command_id = ?
                """,
                (
                    next_status.value,
                    decision.subject_id,
                    decision.receipt_digest,
                    decision.reason_code,
                    now,
                    decision.reason_code,
                    now,
                    command_id,
                ),
            )
            self._append_attempt(
                connection,
                command_id,
                "authorization_approved" if decision.approved else "authorization_denied",
                decision.reason_code,
                now,
            )
            return self._command_from_row(self._command_row(connection, command_id))

    def mark_command_expired(self, command_id: str) -> CancellationControlCommandAudit:
        """Durably refuse an expired command without touching the risk latch."""

        return self._set_command_status(
            command_id,
            ControlCommandStatus.EXPIRED,
            "command_expired",
            allowed={ControlCommandStatus.PENDING, ControlCommandStatus.AUTHORIZED},
        )

    def mark_released_command_expired_before_final_latch(
        self, command_id: str
    ) -> CancellationControlCommandAudit:
        """Undo only the audit-final marker while the last risk latch is active.

        The release path performs a second trusted-clock check after the
        RELEASED audit commit but immediately before clearing its final risk
        latch.  If expiry crossed in that interval, the durable command must
        not remain RELEASED while the latch is reasserted.
        """

        command_id = _identifier(command_id, "command_id")
        now = self._clock()
        with self._transaction() as connection:
            row = self._command_row(connection, command_id)
            status = ControlCommandStatus(str(row["status"]))
            released_at_final_boundary = (
                status is ControlCommandStatus.RELEASED and row["released_at"] is not None
            )
            reasserted_expiry_boundary = (
                status is ControlCommandStatus.PENDING
                and row["outcome_code"] == "command_expired_before_final_latch"
            )
            if (
                row["release_applied_at"] is None
                or not (released_at_final_boundary or reasserted_expiry_boundary)
            ):
                raise CancellationControlAuditError(
                    "command is not at the final released-before-latch boundary"
                )
            connection.execute(
                """
                UPDATE cancellation_control_commands
                SET status = ?, released_at = NULL, outcome_code = ?, updated_at = ?
                WHERE command_id = ?
                """,
                (
                    ControlCommandStatus.EXPIRED.value,
                    "command_expired_before_final_latch",
                    now,
                    command_id,
                ),
            )
            self._append_attempt(
                connection,
                command_id,
                "command_expired",
                "command_expired_before_final_latch",
                now,
            )
            return self._command_from_row(self._command_row(connection, command_id))

    def record_release_applied(self, command_id: str) -> CancellationControlCommandAudit:
        """Persist a release preparation before mutating the risk latch.

        The stable ``release_applied_at`` timestamp records only a durable
        preparation.  It is not a successful release and survives a later
        reassertion so a retry uses the same monitor event identity.  A new
        control port treats every prepared, non-final row as a restart recovery
        obligation and restores the cancellation freeze before retrying.
        """

        command_id = _identifier(command_id, "command_id")
        now = self._clock()
        with self._transaction() as connection:
            row = self._command_row(connection, command_id)
            if ControlCommandStatus(str(row["status"])) is not ControlCommandStatus.AUTHORIZED:
                raise CancellationControlAuditError("command is not authorized")
            if row["release_applied_at"] is None:
                connection.execute(
                    """
                    UPDATE cancellation_control_commands
                    SET release_applied_at = ?, outcome_code = ?, updated_at = ?
                    WHERE command_id = ?
                    """,
                    (now, "freeze_release_prepared", now, command_id),
                )
                self._append_attempt(
                    connection,
                    command_id,
                    "freeze_release_prepared",
                    "freeze_release_prepared",
                    now,
                )
            return self._command_from_row(self._command_row(connection, command_id))

    def record_cancel_dispatch_proof(
        self, command_id: str, proof: Any, authority: Any
    ) -> tuple[str, str]:
        """Persist the exact proof before risk consumes it, enabling safe replay."""

        command_id = _identifier(command_id, "command_id")
        proof_type = getattr(getattr(authority, "_risk_types", None), "CancelDispatchResolutionProof", None)
        if not isinstance(proof_type, type) or type(proof) is not proof_type:
            raise CancellationControlAuditError("typed cancel dispatch proof is required")
        try:
            payload = _cancel_dispatch_proof_payload(proof)
            payload_json = _canonical_json(payload)
            payload_sha256 = _sha256(payload)
            if proof.fingerprint != payload_sha256:
                raise ValueError("risk proof digest differs from its canonical payload")
        except Exception as error:
            raise CancellationControlAuditError("cancel dispatch proof is not canonical") from error
        now = self._clock()
        with self._transaction() as connection:
            row = self._command_row(connection, command_id)
            status = ControlCommandStatus(str(row["status"]))
            if (
                status is not ControlCommandStatus.AUTHORIZED
                or row["release_applied_at"] is None
            ):
                raise CancellationControlAuditError("cancel proof requires a prepared release")
            stored_json = row["cancel_resolution_proof_json"]
            stored_sha256 = row["cancel_resolution_proof_sha256"]
            if stored_json is not None or stored_sha256 is not None:
                if stored_json != payload_json or stored_sha256 != payload_sha256:
                    raise CancellationControlAuditConflictError(
                        "control command already has another cancel dispatch proof"
                    )
                return payload_json, payload_sha256
            connection.execute(
                """
                UPDATE cancellation_control_commands
                SET cancel_resolution_proof_json = ?, cancel_resolution_proof_sha256 = ?,
                    updated_at = ?
                WHERE command_id = ?
                """,
                (payload_json, payload_sha256, now, command_id),
            )
            self._append_attempt(
                connection,
                command_id,
                "cancel_dispatch_proof_persisted",
                "cancel_dispatch_proof_persisted",
                now,
            )
            return payload_json, payload_sha256

    def get_cancel_dispatch_proof(self, command_id: str) -> tuple[str, str] | None:
        """Read an immutable, digest-checked cancellation proof payload."""

        command_id = _identifier(command_id, "command_id")
        with self._connection() as connection:
            row = self._command_row(connection, command_id)
        payload_json = row["cancel_resolution_proof_json"]
        payload_sha256 = row["cancel_resolution_proof_sha256"]
        if payload_json is None and payload_sha256 is None:
            return None
        if (
            type(payload_json) is not str
            or type(payload_sha256) is not str
            or not _SHA256.fullmatch(payload_sha256)
        ):
            raise CancellationControlAuditError("stored cancellation proof is incomplete")
        try:
            payload = json.loads(payload_json)
        except (TypeError, ValueError) as error:
            raise CancellationControlAuditError("stored cancellation proof is unreadable") from error
        if _canonical_json(payload) != payload_json or _sha256(payload) != payload_sha256:
            raise CancellationControlAuditError("stored cancellation proof digest is invalid")
        return payload_json, payload_sha256

    def mark_command_reasserted(
        self, command_id: str, outcome_code: str
    ) -> CancellationControlCommandAudit:
        """Return a failed or interrupted release to pending after reassertion."""

        command_id = _identifier(command_id, "command_id")
        outcome_code = _reason_code(outcome_code, "outcome_code")
        now = self._clock()
        with self._transaction() as connection:
            self._command_row(connection, command_id)
            connection.execute(
                """
                UPDATE cancellation_control_commands
                SET status = ?, released_at = NULL, outcome_code = ?, updated_at = ?
                WHERE command_id = ?
                """,
                (ControlCommandStatus.PENDING.value, outcome_code, now, command_id),
            )
            self._append_attempt(connection, command_id, "freeze_reasserted", outcome_code, now)
            return self._command_from_row(self._command_row(connection, command_id))

    def unconfirmed_release_commands(self, scope: str) -> list[CancellationControlCommandAudit]:
        """Return non-final prepared releases that must re-freeze on restart."""

        scope = _identifier(scope, "scope")
        with self._connection() as connection:
            rows = connection.execute(
                """
                SELECT * FROM cancellation_control_commands
                WHERE scope = ? AND status IN (?, ?) AND release_applied_at IS NOT NULL
                ORDER BY command_id ASC
                """,
                (scope, ControlCommandStatus.PENDING.value, ControlCommandStatus.AUTHORIZED.value),
            ).fetchall()
        return [self._command_from_row(row) for row in rows]

    def mark_command_released(self, command_id: str) -> CancellationControlCommandAudit:
        """Commit a final release only after its monitor fact is durable."""

        command_id = _identifier(command_id, "command_id")
        now = self._clock()
        with self._transaction() as connection:
            row = self._command_row(connection, command_id)
            status = ControlCommandStatus(str(row["status"]))
            if status is ControlCommandStatus.RELEASED:
                return self._command_from_row(row)
            if status is not ControlCommandStatus.AUTHORIZED or row["release_applied_at"] is None:
                raise CancellationControlAuditError("command release confirmation is not ready")
            connection.execute(
                """
                UPDATE cancellation_control_commands
                SET status = ?, released_at = ?, outcome_code = ?, updated_at = ?
                WHERE command_id = ?
                """,
                (ControlCommandStatus.RELEASED.value, now, "freeze_released", now, command_id),
            )
            self._append_attempt(connection, command_id, "freeze_released", "freeze_released", now)
            return self._command_from_row(self._command_row(connection, command_id))

    def record_pending_failure(self, command_id: str, outcome_code: str) -> None:
        """Record a failed attempt while retaining a retryable command and freeze."""

        command_id = _identifier(command_id, "command_id")
        outcome_code = _reason_code(outcome_code, "outcome_code")
        now = self._clock()
        with self._transaction() as connection:
            self._command_row(connection, command_id)
            connection.execute(
                """
                UPDATE cancellation_control_commands SET outcome_code = ?, updated_at = ?
                WHERE command_id = ?
                """,
                (outcome_code, now, command_id),
            )
            self._append_attempt(connection, command_id, "release_not_applied", outcome_code, now)

    def _set_command_status(
        self,
        command_id: str,
        status: ControlCommandStatus,
        outcome_code: str,
        *,
        allowed: set[ControlCommandStatus],
    ) -> CancellationControlCommandAudit:
        command_id = _identifier(command_id, "command_id")
        outcome_code = _reason_code(outcome_code, "outcome_code")
        now = self._clock()
        with self._transaction() as connection:
            row = self._command_row(connection, command_id)
            current = ControlCommandStatus(str(row["status"]))
            if current is status:
                return self._command_from_row(row)
            if current not in allowed:
                raise CancellationControlAuditError("command has an incompatible lifecycle state")
            connection.execute(
                """
                UPDATE cancellation_control_commands SET status = ?, outcome_code = ?, updated_at = ?
                WHERE command_id = ?
                """,
                (status.value, outcome_code, now, command_id),
            )
            self._append_attempt(connection, command_id, status.value, outcome_code, now)
            return self._command_from_row(self._command_row(connection, command_id))

    @staticmethod
    def _command_row(connection: sqlite3.Connection, command_id: str) -> sqlite3.Row:
        row = connection.execute(
            "SELECT * FROM cancellation_control_commands WHERE command_id = ?", (command_id,)
        ).fetchone()
        if row is None:
            raise CancellationControlAuditError("control command does not exist")
        return row

    @staticmethod
    def _append_attempt(
        connection: sqlite3.Connection,
        command_id: str,
        event_type: str,
        outcome_code: str,
        occurred_at: float,
    ) -> None:
        connection.execute(
            """
            INSERT INTO cancellation_control_attempts
                (command_id, event_type, outcome_code, occurred_at)
            VALUES (?, ?, ?, ?)
            """,
            (command_id, event_type, outcome_code, occurred_at),
        )

    @staticmethod
    def _reconciliation_from_row(row: sqlite3.Row) -> CancellationReconciliationAudit:
        return CancellationReconciliationAudit(
            evidence_id=str(row["evidence_id"]),
            fingerprint=str(row["fingerprint"]),
            scope=str(row["scope"]),
            cancel_id=str(row["cancel_id"]),
            target_intent_id=str(row["target_intent_id"]),
            provider_order_id=str(row["provider_order_id"]),
            observation=MappingProxyType(json.loads(str(row["observation_json"]))),
            record=MappingProxyType(json.loads(str(row["record_json"]))),
            source_receipt_digest=str(row["source_receipt_digest"]),
            observed_at=float(row["observed_at"]),
            monitor_event_id=str(row["monitor_event_id"]),
            monitor_published=bool(row["monitor_published"]),
        )

    @staticmethod
    def _command_from_row(row: sqlite3.Row) -> CancellationControlCommandAudit:
        command = ReleaseCancellationFreezeCommand(
            command_id=str(row["command_id"]),
            scope=str(row["scope"]),
            cancel_id=str(row["cancel_id"]),
            evidence_id=str(row["evidence_id"]),
            evidence_fingerprint=str(row["evidence_fingerprint"]),
            issuer_id=str(row["issuer_id"]),
            reason_code=str(row["reason_code"]),
            issued_at=float(row["issued_at"]),
            expires_at=float(row["expires_at"]),
        )
        return CancellationControlCommandAudit(
            command=command,
            status=ControlCommandStatus(str(row["status"])),
            authorization_subject_id=(
                None
                if row["authorization_subject_id"] is None
                else str(row["authorization_subject_id"])
            ),
            authorization_receipt_digest=(
                None
                if row["authorization_receipt_digest"] is None
                else str(row["authorization_receipt_digest"])
            ),
            authorization_reason_code=(
                None
                if row["authorization_reason_code"] is None
                else str(row["authorization_reason_code"])
            ),
            release_applied_at=(
                None if row["release_applied_at"] is None else float(row["release_applied_at"])
            ),
            released_at=None if row["released_at"] is None else float(row["released_at"]),
            outcome_code=None if row["outcome_code"] is None else str(row["outcome_code"]),
        )

    def _initialize_schema(self) -> None:
        with self._connection() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS cancellation_control_evidence (
                    evidence_id TEXT PRIMARY KEY,
                    fingerprint TEXT NOT NULL,
                    scope TEXT NOT NULL,
                    cancel_id TEXT NOT NULL,
                    target_intent_id TEXT NOT NULL,
                    provider_order_id TEXT NOT NULL,
                    observation_json TEXT NOT NULL,
                    record_json TEXT NOT NULL,
                    source_receipt_digest TEXT NOT NULL,
                    observed_at REAL NOT NULL,
                    monitor_event_id TEXT NOT NULL,
                    monitor_published INTEGER NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_cancellation_control_evidence_fingerprint
                    ON cancellation_control_evidence(fingerprint);
                CREATE TABLE IF NOT EXISTS cancellation_control_commands (
                    command_id TEXT PRIMARY KEY,
                    fingerprint TEXT NOT NULL,
                    scope TEXT NOT NULL,
                    cancel_id TEXT NOT NULL,
                    evidence_id TEXT NOT NULL,
                    evidence_fingerprint TEXT NOT NULL,
                    issuer_id TEXT NOT NULL,
                    reason_code TEXT NOT NULL,
                    issued_at REAL NOT NULL,
                    expires_at REAL NOT NULL,
                    status TEXT NOT NULL,
                    authorization_subject_id TEXT,
                    authorization_receipt_digest TEXT,
                    authorization_reason_code TEXT,
                    authorization_at REAL,
                    release_applied_at REAL,
                    released_at REAL,
                    cancel_resolution_proof_json TEXT,
                    cancel_resolution_proof_sha256 TEXT,
                    outcome_code TEXT,
                    updated_at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS cancellation_control_attempts (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    command_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    outcome_code TEXT NOT NULL,
                    occurred_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_cancellation_control_attempts_command
                    ON cancellation_control_attempts(command_id, sequence);
                """
            )
            columns = {
                str(row["name"])
                for row in connection.execute(
                    "PRAGMA table_info(cancellation_control_commands)"
                ).fetchall()
            }
            if "cancel_resolution_proof_json" not in columns:
                connection.execute(
                    "ALTER TABLE cancellation_control_commands "
                    "ADD COLUMN cancel_resolution_proof_json TEXT"
                )
            if "cancel_resolution_proof_sha256" not in columns:
                connection.execute(
                    "ALTER TABLE cancellation_control_commands "
                    "ADD COLUMN cancel_resolution_proof_sha256 TEXT"
                )

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(
            str(self._database_path), timeout=self._timeout_seconds, isolation_level=None
        )
        connection.row_factory = sqlite3.Row
        try:
            connection.execute("PRAGMA synchronous = FULL")
            yield connection
        finally:
            connection.close()

    @contextmanager
    def _transaction(self) -> Iterator[sqlite3.Connection]:
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield connection
            except BaseException:
                connection.execute("ROLLBACK")
                raise
            else:
                connection.execute("COMMIT")


class ManagedCancellationReconciliationControlPort:
    """Reconcile a cancellation then release only its audited unknown-outcome latch."""

    def __init__(
        self,
        runtime: Any,
        cancellation_facade: Any,
        *,
        state_directory: Path | str,
        authorize: Callable[[CancellationReleaseAuthorizationRequest], AuthorizationDecision],
        clock: Callable[[], float] | None = None,
    ) -> None:
        if not callable(authorize):
            raise ValueError("authorize callback is required")
        self._runtime = runtime
        self._cancellation_facade = cancellation_facade
        self._authorize = authorize
        self._clock = clock or time.time
        self._require_runtime_surface()
        state_directory = Path(state_directory).resolve(strict=False)
        self._audit = DurableCancellationControlAudit(
            state_directory / "cancellation_operator_control.sqlite3", clock=self._clock
        )
        self._recover_unconfirmed_releases()

    @property
    def audit(self) -> DurableCancellationControlAudit:
        """Expose read-only audit methods to a deployment-owned monitor adapter."""

        return self._audit

    def close(self) -> None:
        """Close local audit resources; the composed runtime remains caller-owned."""

        self._audit.close()

    def reconcile(
        self, evidence: CancellationReconciliationEvidence
    ) -> ControlledCancellationReconciliationResult:
        """Apply typed cancellation evidence and publish an immutable monitor fact.

        This method cannot release the unknown-cancel freeze.  It accepts only
        terminal ``CANCELLED`` or ``REJECTED`` observations; ``ACKED`` means a
        cancellation is still in progress and must keep the account frozen.
        """

        observation = self._validated_observation(evidence)
        try:
            fingerprint = evidence.fingerprint
        except ValueError as error:
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_EVIDENCE_INVALID",
                "typed cancellation evidence could not be canonicalized",
            ) from error
        monitor_event_id = "cancel-reconcile:" + fingerprint
        existing = self._audit.get_reconciliation(evidence.evidence_id)
        record = self._cancellation_facade.get(evidence.cancel_id)
        if record is None:
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_UNKNOWN",
                "cancellation intent is absent from this runtime",
            )
        if existing is None:
            if record.state.value == "UNKNOWN":
                try:
                    record = self._cancellation_facade.reconcile(observation)
                except Exception as error:
                    raise RuntimePluginError(
                        "CANCELLATION_RECONCILIATION_PERSISTENCE_FAILED",
                        "typed cancellation evidence could not be applied",
                    ) from error
            elif not self._record_matches_observation(record, observation):
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_REQUIRES_UNKNOWN",
                    "control reconciliation requires an unknown cancel or its exact crash recovery",
                )
            if not self._is_reviewed_terminal(record):
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_INCOMPLETE",
                    "only terminal cancellation evidence can be reviewed for freeze release",
                )
            if not self._record_matches_observation(record, observation):
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_RESULT_MISMATCH",
                    "reconciled cancellation record does not match typed provider evidence",
                )
            try:
                existing = self._audit.record_reconciliation(
                    evidence,
                    scope=self._runtime.scope.key,
                    observation=_observation_projection(observation),
                    record=_record_projection(record),
                    monitor_event_id=monitor_event_id,
                )
            except CancellationControlAuditConflictError as error:
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_AUDIT_CONFLICT",
                    "cancellation evidence identity conflicts with durable audit",
                ) from error
            except Exception as error:
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_AUDIT_UNCONFIRMED",
                    "cancellation evidence could not be durably audited",
                ) from error
        else:
            if (
                existing.fingerprint != fingerprint
                or existing.scope != self._runtime.scope.key
                or existing.cancel_id != evidence.cancel_id
            ):
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_AUDIT_CONFLICT",
                    "cancellation evidence differs from the durable audit",
                )
            if not self._record_matches_projection(record, existing.record):
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_EVIDENCE_STALE",
                    "current cancellation record differs from reviewed evidence",
                )
        audit = self._publish_reconciliation_fact(evidence, record, existing)
        return ControlledCancellationReconciliationResult(record=record, audit=audit)

    def release_cancel_freeze(
        self, command: ReleaseCancellationFreezeCommand
    ) -> CancellationFreezeReleaseResult:
        """Resolve the typed cancel latch, then release the reviewed unknown latch.

        A second risk freeze remains active through proof resolution, the
        release-prepared monitor event, and the durable audit confirmation.
        Clearing that final in-progress cause is the last required I/O, so a
        monitor/audit failure or process crash cannot expose a write window.
        """

        if command.scope != self._runtime.scope.key:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_SCOPE_MISMATCH",
                "control command scope does not match the managed runtime",
            )
        authority = self._require_cancel_resolution_authority()
        try:
            command_audit = self._audit.record_command(command)
        except CancellationControlAuditConflictError as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_COMMAND_CONFLICT",
                "control command identity conflicts with durable audit",
            ) from error
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "control command could not be durably recorded",
            ) from error
        if command_audit.status is ControlCommandStatus.RELEASED:
            self._resume_released_command(command, authority, command_audit)
            return CancellationFreezeReleaseResult(
                command.command_id, command.cancel_id, True, True
            )
        if command_audit.status is ControlCommandStatus.DENIED:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUTHORIZATION_DENIED",
                "this cancellation control command was durably denied",
            )
        if command_audit.status is ControlCommandStatus.EXPIRED:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_COMMAND_EXPIRED", "this control command is expired"
            )
        if command.expires_at <= self._clock():
            try:
                self._audit.mark_command_expired(command.command_id)
            except Exception as error:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                    "expired command refusal could not be audited",
                ) from error
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_COMMAND_EXPIRED", "this control command is expired"
            )

        evidence = self._require_published_evidence(command)
        record = self._cancellation_facade.get(command.cancel_id)
        if record is None or not self._record_matches_projection(record, evidence.record):
            self._record_pending_failure(command.command_id, "cancellation_evidence_stale")
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_EVIDENCE_STALE",
                "current cancellation record differs from reviewed evidence",
            )
        request = CancellationReleaseAuthorizationRequest(
            command=command,
            evidence=CancellationReconciliationEvidence(
                evidence_id=evidence.evidence_id,
                cancel_id=evidence.cancel_id,
                target_intent_id=evidence.target_intent_id,
                provider_order_id=evidence.provider_order_id,
                observation=self._observation_from_audit(evidence),
                source_receipt_digest=evidence.source_receipt_digest,
                observed_at=evidence.observed_at,
            ),
            reconciled_record=evidence.record,
        )
        decision = self._authorize_command(command, request)
        # The authorizer is injected and may take arbitrarily long.  The
        # command's validity at entry is not enough: expiration must still be
        # current when the decision comes back, before any release mutation.
        if command.expires_at <= self._clock():
            try:
                self._audit.mark_command_expired(command.command_id)
            except Exception as error:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                    "expired authorization refusal could not be durably recorded",
                ) from error
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_COMMAND_EXPIRED",
                "this control command expired while authorization was pending",
            )
        if not decision.approved:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUTHORIZATION_DENIED",
                "cancellation control command was rejected by the authorizer",
            )
        self._publish_authorization_fact(command, decision, evidence)
        self._assert_freeze_active(command.cancel_id)
        progress_cause = self._release_in_progress_cause(command.cancel_id)
        try:
            self._runtime.risk_gate.freeze(
                self._runtime.risk_scope,
                progress_cause,
                progress_cause,
            )
            self._assert_cause_active(progress_cause)
            self._assert_freeze_active(command.cancel_id)
            applied = self._audit.record_release_applied(command.command_id)
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "release_preparation_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "cancellation release preparation could not be safely recorded",
            ) from error
        try:
            proof = self._get_or_issue_cancel_dispatch_proof(command, authority)
            self._verify_cancel_dispatch_proof(command, proof, authority)
            self._verify_cancel_dispatch_authority_current(proof, authority)
            resolver = getattr(self._runtime.risk_gate, "resolve_cancel_dispatch_freeze", None)
            if not callable(resolver):
                raise RuntimePluginError(
                    "CANCELLATION_DISPATCH_RESOLUTION_UNAVAILABLE",
                    "risk gate lacks typed cancel dispatch latch resolution",
                )
            resolver(proof)
            self._assert_cause_inactive(proof.cause_id)
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "dispatch_resolution_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_FAILED",
                "cancellation dispatch latch could not be resolved by exact typed proof",
            ) from error
        try:
            # This generic resolver can clear only the separate unknown-result
            # cause. Risk refuses to use it for dispatch-inflight causes.
            self._runtime.risk_gate.resolve_freeze(
                self._runtime.risk_scope, self._freeze_cause(command.cancel_id)
            )
            self._assert_freeze_inactive(command.cancel_id)
        except RuntimePluginError as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "unknown_freeze_resolution_unconfirmed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_RESOLUTION_UNCONFIRMED",
                "unknown cancellation freeze release could not be verified",
            ) from error
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "unknown_freeze_resolution_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_RESOLUTION_FAILED",
                "unknown cancellation freeze could not be resolved",
            ) from error
        try:
            self._append_monitor_event(
                event_id="cancel-freeze-release:" + command.command_id,
                event_type="cancellation_freeze_release_prepared",
                data={
                    "cancel_id": command.cancel_id,
                    "command_id": command.command_id,
                    "dispatch_resolution_digest": proof.fingerprint,
                    "evidence_digest": command.evidence_fingerprint,
                    "issuer_id": command.issuer_id,
                    "release_applied_at": applied.release_applied_at,
                    "state": evidence.record["state"],
                    "stage": "final_in_progress_freeze_remains_active",
                },
                occurred_at=applied.release_applied_at,
            )
            self._verify_release_prepared_monitor_fact(
                command,
                evidence,
                proof,
                applied.release_applied_at,
            )
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "release_outbox_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_MONITOR_OUTBOX_UNCONFIRMED",
                "cancellation release monitor fact was not durable; dispatch remains frozen",
            ) from error
        if command.expires_at <= self._clock():
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "command_expired_during_release"
            )
            try:
                self._audit.mark_command_expired(command.command_id)
            except Exception as error:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                    "expired release refusal could not be durably recorded",
                ) from error
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_COMMAND_EXPIRED",
                "this control command expired before final release confirmation",
            )
        try:
            self._audit.mark_command_released(command.command_id)
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "release_audit_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "cancellation release confirmation could not be durably audited",
            ) from error
        if command.expires_at <= self._clock():
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "command_expired_before_final_latch"
            )
            try:
                self._audit.mark_released_command_expired_before_final_latch(
                    command.command_id
                )
            except Exception as error:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                    "expired final release refusal could not be durably recorded",
                ) from error
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_COMMAND_EXPIRED",
                "this control command expired before final latch removal",
            )
        try:
            # The final latch is removed only after proof, unknown-latch
            # removal, monitor publication, and audit confirmation.  Keep
            # this as the last required I/O; a crash before it leaves the
            # in-progress freeze active.
            self._runtime.risk_gate.resolve_freeze(self._runtime.risk_scope, progress_cause)
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "final_freeze_resolution_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_RESOLUTION_FAILED",
                "final cancellation release freeze could not be resolved",
            ) from error
        return CancellationFreezeReleaseResult(command.command_id, command.cancel_id, True, False)

    def _require_runtime_surface(self) -> None:
        required = (
            "outbox",
            "risk_gate",
            "risk_scope",
            "scope",
            "execution",
            "outbox_event_type",
        )
        if any(not hasattr(self._runtime, name) for name in required):
            raise ValueError("runtime does not expose the managed cancellation control surface")
        if not isinstance(getattr(self._runtime.scope, "key", None), str):
            raise ValueError("runtime has an invalid execution scope")
        if not callable(getattr(self._cancellation_facade, "get", None)) or not callable(
            getattr(self._cancellation_facade, "reconcile", None)
        ):
            raise ValueError("cancellation facade lacks reconciliation surface")

    def _require_cancel_resolution_authority(self) -> Any:
        """Require the exact composed offline fake journal authority and risk gate."""

        from .fake_dispatch_authority import (
            ManagedFakeProviderJournalAuthority,
            is_registered_offline_fake_binding,
        )

        authority = getattr(self._runtime, "fake_dispatch_authority", None)
        risk_gate = self._runtime.risk_gate
        risk_scope = self._runtime.risk_scope
        execution_scope = self._runtime.scope
        contract = getattr(self._runtime, "contract", None)
        risk_policy = getattr(risk_gate, "policy", None)
        policy_id = getattr(risk_policy, "policy_id", None)
        risk_types = getattr(authority, "_risk_types", None)
        risk_gate_type = getattr(risk_types, "DurableRiskGate", None)
        proof_type = getattr(risk_types, "CancelDispatchResolutionProof", None)
        if (
            type(authority) is not ManagedFakeProviderJournalAuthority
            or not is_registered_offline_fake_binding(
                contract, execution_scope, policy_id, risk_scope
            )
            or getattr(authority, "_contract", None) != contract
            or getattr(authority, "_policy_id", None) != policy_id
            or getattr(risk_scope, "provider", None) != "fake"
            or getattr(risk_scope, "environment", None) != "offline"
            or getattr(execution_scope, "environment", None) != "offline"
            or getattr(authority, "_risk_scope", None) != risk_scope
            or getattr(authority, "_execution_scope", None) != execution_scope
            or not isinstance(risk_gate_type, type)
            or type(risk_gate) is not risk_gate_type
            or getattr(risk_gate, "_execution_journal_authority", None) is not authority
            or not isinstance(proof_type, type)
            or not callable(getattr(authority, "create_cancel_dispatch_resolution_proof", None))
            or not callable(getattr(authority, "cancel_dispatch_resolution_guard", None))
            or not callable(getattr(risk_gate, "resolve_cancel_dispatch_freeze", None))
            or not callable(getattr(risk_gate, "resolve_freeze", None))
            or not callable(getattr(risk_gate, "active_freeze_reasons", None))
        ):
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_AUTHORITY_REQUIRED",
                "freeze release requires the exact composed offline fake cancellation authority",
            )
        return authority

    def _get_or_issue_cancel_dispatch_proof(
        self, command: ReleaseCancellationFreezeCommand, authority: Any
    ) -> Any:
        stored = self._audit.get_cancel_dispatch_proof(command.command_id)
        if stored is None:
            proof = authority.create_cancel_dispatch_resolution_proof(
                command.cancel_id, self._runtime.risk_gate
            )
            self._verify_cancel_dispatch_proof(command, proof, authority)
            payload_json, payload_sha256 = self._audit.record_cancel_dispatch_proof(
                command.command_id, proof, authority
            )
        else:
            payload_json, payload_sha256 = stored
        return _restore_cancel_dispatch_proof(payload_json, payload_sha256, authority)

    def _verify_cancel_dispatch_proof(
        self, command: ReleaseCancellationFreezeCommand, proof: Any, authority: Any
    ) -> None:
        risk_types = authority._risk_types
        proof_type = risk_types.CancelDispatchResolutionProof
        simulation_class = risk_types.DispatchEvidenceClass.SIMULATION_JOURNAL
        expected_intent_id = (
            "cancel-admission:" + self._runtime.scope.key + ":" + command.cancel_id
        )
        if (
            type(proof) is not proof_type
            or proof.scope != self._runtime.risk_scope
            or proof.execution_scope_key != self._runtime.scope.key
            or proof.cancel_id != command.cancel_id
            or proof.intent_id != expected_intent_id
            or proof.cause_id != "dispatch-inflight:" + expected_intent_id
            or proof.evidence_class is not simulation_class
            or proof.terminal_state
            not in {
                risk_types.CancelDispatchTerminalState.CANCELLED,
                risk_types.CancelDispatchTerminalState.REJECTED,
            }
            or not _SHA256.fullmatch(proof.fingerprint)
            or proof.fingerprint != _sha256(_cancel_dispatch_proof_payload(proof))
        ):
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_PROOF_MISMATCH",
                "typed cancel proof does not match this exact offline cancellation",
            )

    def _verify_cancel_dispatch_authority_current(self, proof: Any, authority: Any) -> None:
        """Re-read the stored claim, current lease, and terminal journal facts."""

        risk_types = authority._risk_types
        try:
            binding = self._runtime.risk_gate.dispatch_claim_binding(proof.permit_id)
        except risk_types.PermitInvalidError as error:
            if getattr(error, "code", None) != "DISPATCH_FREEZE_MISSING":
                raise
            # A committed risk resolution deliberately removes the active
            # claim latch, so the normal claim reader cannot return it on
            # replay. Re-read current typed execution facts and lease here;
            # the risk resolver below independently checks the exact durable
            # proof/claim row before accepting an idempotent replay.
            self._verify_current_cancel_commit(proof)
            return
        if type(binding) is not risk_types.DispatchClaimBinding:
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_CLAIM_INVALID",
                "risk gate did not return its exact stored cancellation claim",
            )
        with authority.cancel_dispatch_resolution_guard(proof, claim=binding) as verified:
            verified_type = risk_types.VerifiedCancelDispatchResolution
            if (
                type(verified) is not verified_type
                or verified.scope != proof.scope
                or verified.permit_id != proof.permit_id
                or verified.intent_id != proof.intent_id
                or verified.claim_digest != proof.claim_digest
                or verified.proof_sha256 != proof.fingerprint
                or verified.writer_fence_sha256 != proof.writer_fence_sha256
            ):
                raise RuntimePluginError(
                    "CANCELLATION_DISPATCH_RESOLUTION_AUTHORITY_MISMATCH",
                    "journal authority did not confirm the persisted proof and current target",
                )

    def _verify_current_cancel_commit(self, proof: Any) -> None:
        """Check current execution source facts after an exact risk-proof commit."""

        try:
            lease = self._runtime.facade.acquire_writer_lease()
            self._runtime.execution_store.assert_writer_lease(self._runtime.scope, lease)
            commit = self._runtime.execution_store.read_terminal_cancel_commit(
                self._runtime.scope, proof.cancel_id, writer_lease=lease
            )
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_CURRENT_FACTS_UNAVAILABLE",
                "current writer lease or terminal cancellation facts could not be read",
            ) from error
        execution = self._runtime.execution
        commit_type = getattr(execution, "CancelObservationCommitV1", None)
        if not isinstance(commit_type, type) or type(commit) is not commit_type:
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_CURRENT_FACTS_INVALID",
                "execution store did not return the exact typed terminal cancellation commit",
            )
        cancel = commit.cancel_record
        intent = commit.cancel_intent
        target = commit.target_record
        cancel_event = commit.cancel_event
        target_event = commit.target_event
        if (
            intent.scope != self._runtime.scope
            or intent.cancel_id != proof.cancel_id
            or intent.target_intent_id != proof.target_intent_id
            or intent.provider_order_id != proof.provider_order_id
            or intent.fingerprint != proof.cancel_intent_fingerprint
            or cancel.state.value != proof.terminal_state.value
            or cancel.dispatch_attempts != proof.dispatch_attempt_count
            or cancel.review_required
            or cancel_event.event_id != proof.cancel_event_id
            or cancel_event.sequence != proof.cancel_event_sequence
            or commit.cancel_event_sha256 != proof.cancel_event_sha256
            or commit.source_evidence_sha256 != proof.source_evidence_sha256
            or target.intent_id != proof.target_intent_id
            or target.state.value != proof.target_state
            or format(target.filled_quantity, "f") != proof.target_filled_quantity
            or target.updated_at_ns != proof.target_updated_at_ns
            or commit.target_record_sha256 != proof.target_record_sha256
            or target_event.event_id != proof.target_event_id
            or target_event.sequence != proof.target_event_sequence
            or target_event.event_type != proof.target_event_type
            or commit.target_event_sha256 != proof.target_event_sha256
            or commit.writer_lease.owner_id != proof.writer_owner_id
            or commit.writer_lease.fencing_token != proof.writer_fencing_token
            or lease.owner_id != proof.writer_owner_id
            or lease.fencing_token != proof.writer_fencing_token
        ):
            raise RuntimePluginError(
                "CANCELLATION_DISPATCH_RESOLUTION_CURRENT_FACTS_MISMATCH",
                "current terminal cancellation facts differ from the committed typed proof",
            )

    def _resume_released_command(
        self,
        command: ReleaseCancellationFreezeCommand,
        authority: Any,
        command_audit: CancellationControlCommandAudit,
    ) -> None:
        """Finish the last freeze removal after a crash at the commit cutpoint.

        A RELEASED control row alone is insufficient.  Re-read the exact
        release-prepared event from the pinned monitor outbox before removing
        the final risk latch; the audit row and monitor row are separate local
        commits and cannot substitute for one another.
        """

        unknown_cause = self._freeze_cause(command.cancel_id)
        progress_cause = self._release_in_progress_cause(command.cancel_id)
        try:
            if (
                command_audit.status is not ControlCommandStatus.RELEASED
                or command_audit.release_applied_at is None
            ):
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_RELEASE_STATE_INCONSISTENT",
                    "released control command lacks its durable applied timestamp",
                )
            evidence = self._require_published_evidence(command)
            current_record = self._cancellation_facade.get(command.cancel_id)
            if current_record is None or not self._record_matches_projection(
                current_record, evidence.record
            ):
                raise RuntimePluginError(
                    "CANCELLATION_RECONCILIATION_EVIDENCE_STALE",
                    "current cancellation record differs from released evidence",
                )
            stored = self._audit.get_cancel_dispatch_proof(command.command_id)
            if stored is None:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_RELEASE_STATE_INCONSISTENT",
                    "released control command has no durable cancel dispatch proof",
                )
            proof = _restore_cancel_dispatch_proof(stored[0], stored[1], authority)
            self._verify_cancel_dispatch_proof(command, proof, authority)
            active = set(
                self._runtime.risk_gate.active_freeze_reasons(self._runtime.risk_scope)
            )
            if unknown_cause in active:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_RELEASE_STATE_INCONSISTENT",
                    "released control command has an active unknown-outcome freeze",
                )
            if proof.cause_id in active:
                raise RuntimePluginError(
                    "CANCELLATION_CONTROL_RELEASE_STATE_INCONSISTENT",
                    "released control command retains the dispatch-inflight freeze",
                )
            self._verify_cancel_dispatch_authority_current(proof, authority)
            self._verify_release_prepared_monitor_fact(
                command,
                evidence,
                proof,
                command_audit.release_applied_at,
            )
            self._runtime.risk_gate.resolve_cancel_dispatch_freeze(proof)
            # The successful audit/outbox records precede the final latch in
            # the original call. If that call crashed before its last commit,
            # this retry performs only that last commit and nothing afterward.
            if progress_cause in active:
                self._runtime.risk_gate.resolve_freeze(
                    self._runtime.risk_scope, progress_cause
                )
        except Exception as error:
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "released_command_recovery_failed"
            )
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_RELEASE_RECOVERY_FAILED",
                "prepared cancellation release could not be safely resumed",
            ) from error

    def _verify_release_prepared_monitor_fact(
        self,
        command: ReleaseCancellationFreezeCommand,
        evidence: CancellationReconciliationAudit,
        proof: Any,
        release_applied_at: float,
    ) -> None:
        """Read back the exact prepared event from the composed SQLite outbox."""

        state_directory = self._runtime.state_directory
        if not isinstance(state_directory, Path):
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_MONITOR_FACT_UNAVAILABLE",
                "managed runtime lacks a durable monitor state directory",
            )
        database_path = state_directory / "monitor.sqlite3"
        try:
            database_uri = database_path.resolve(strict=True).as_uri() + "?mode=ro"
            event_id = "cancel-freeze-release:" + command.command_id
            event_data = {
                "cancel_id": command.cancel_id,
                "command_id": command.command_id,
                "dispatch_resolution_digest": proof.fingerprint,
                "evidence_digest": command.evidence_fingerprint,
                "issuer_id": command.issuer_id,
                "release_applied_at": release_applied_at,
                "state": evidence.record["state"],
                "stage": "final_in_progress_freeze_remains_active",
            }
            event_type = self._runtime.outbox_event_type
            expected_event = event_type(
                event_id=event_id,
                scope=self._runtime.scope.key,
                event_type="cancellation_freeze_release_prepared",
                data=event_data,
                occurred_at=release_applied_at,
            )
            if type(expected_event) is not event_type:
                raise ValueError("monitor event factory returned an unexpected type")
            with sqlite3.connect(database_uri, uri=True, timeout=1.0) as connection:
                row = connection.execute(
                    """
                    SELECT fingerprint, scope, event_type, data_json, occurred_at
                    FROM monitor_outbox_events WHERE event_id = ?
                    """,
                    (event_id,),
                ).fetchone()
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_MONITOR_FACT_UNAVAILABLE",
                "prepared cancellation monitor fact could not be read back",
            ) from error
        if row is None or (
            row[0] != expected_event.fingerprint
            or row[1] != expected_event.scope
            or row[2] != expected_event.event_type
            or row[3] != expected_event.data_json
            or row[4] != expected_event.occurred_at
        ):
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_MONITOR_FACT_MISMATCH",
                "prepared cancellation monitor fact is missing or differs from the audit",
            )

    def _assert_cause_active(self, cause_id: str) -> None:
        try:
            active_reasons = self._runtime.risk_gate.active_freeze_reasons(
                self._runtime.risk_scope
            )
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_STATE_UNAVAILABLE",
                "cancellation release freeze state could not be verified",
            ) from error
        if cause_id not in active_reasons:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_NOT_ACTIVE",
                "required cancellation release freeze is not active",
            )

    def _assert_cause_inactive(self, cause_id: str) -> None:
        try:
            active_reasons = self._runtime.risk_gate.active_freeze_reasons(
                self._runtime.risk_scope
            )
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_STATE_UNAVAILABLE",
                "cancellation dispatch freeze state could not be verified",
            ) from error
        if cause_id in active_reasons:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_RELEASE_STATE_INCONSISTENT",
                "typed dispatch proof left its exact risk freeze active",
            )

    def _recover_unconfirmed_releases(self) -> None:
        """Reassert prepared-but-unconfirmed cancellation freezes after restart."""

        try:
            commands = self._audit.unconfirmed_release_commands(self._runtime.scope.key)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "unconfirmed cancellation release records could not be loaded",
            ) from error
        for audit in commands:
            command = audit.command
            self._reassert_after_failed_release(
                command.command_id, command.cancel_id, "restart_release_unconfirmed"
            )

    def _validated_observation(self, evidence: CancellationReconciliationEvidence) -> Any:
        if not isinstance(evidence, CancellationReconciliationEvidence):
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_EVIDENCE_INVALID",
                "CancellationReconciliationEvidence is required",
            )
        observation_type = getattr(self._runtime.execution, "CancelObservation", None)
        if not isinstance(observation_type, type) or not isinstance(
            evidence.observation, observation_type
        ):
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_EVIDENCE_INVALID",
                "evidence must contain the runtime execution CancelObservation type",
            )
        observation = evidence.observation
        if (
            observation.cancel_id != evidence.cancel_id
            or observation.target_intent_id != evidence.target_intent_id
            or observation.provider_order_id != evidence.provider_order_id
        ):
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_IDENTITY_MISMATCH",
                "cancellation observation belongs to another durable target",
            )
        if observation.state.value not in {"CANCELLED", "REJECTED"}:
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_INCOMPLETE",
                "only terminal cancellation evidence can support reviewed release",
            )
        if observation.state.value == "REJECTED" and observation.reason_code is None:
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_EVIDENCE_INCOMPLETE",
                "rejected cancellation reconciliation requires a provider reason code",
            )
        return observation

    def _publish_reconciliation_fact(
        self,
        evidence: CancellationReconciliationEvidence,
        record: Any,
        audit: CancellationReconciliationAudit,
    ) -> CancellationReconciliationAudit:
        if audit.monitor_published:
            return audit
        try:
            projection = _record_projection(record)
            self._append_monitor_event(
                event_id=audit.monitor_event_id,
                event_type="cancellation_reconciled",
                data={
                    "cancel_id": evidence.cancel_id,
                    "evidence_digest": audit.fingerprint,
                    "provider_order_id": projection["provider_order_id"],
                    "state": projection["state"],
                    "target_intent_id": evidence.target_intent_id,
                },
                occurred_at=evidence.observed_at,
            )
            return self._audit.mark_reconciliation_monitor_published(
                evidence.evidence_id, audit.monitor_event_id
            )
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_MONITOR_OUTBOX_UNCONFIRMED",
                "cancellation reconciliation monitor fact was not durably published",
            ) from error

    def _require_published_evidence(
        self, command: ReleaseCancellationFreezeCommand
    ) -> CancellationReconciliationAudit:
        evidence = self._audit.get_reconciliation(command.evidence_id)
        if (
            evidence is None
            or evidence.scope != self._runtime.scope.key
            or evidence.cancel_id != command.cancel_id
            or evidence.fingerprint != command.evidence_fingerprint
        ):
            self._record_pending_failure(command.command_id, "cancellation_evidence_missing")
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_EVIDENCE_REQUIRED",
                "cancellation freeze release requires matching durable evidence",
            )
        if not evidence.monitor_published:
            self._record_pending_failure(command.command_id, "cancellation_outbox_unconfirmed")
            raise RuntimePluginError(
                "CANCELLATION_RECONCILIATION_MONITOR_OUTBOX_UNCONFIRMED",
                "cancellation release requires durable reconciliation monitor delivery",
            )
        return evidence

    def _authorize_command(
        self,
        command: ReleaseCancellationFreezeCommand,
        request: CancellationReleaseAuthorizationRequest,
    ) -> AuthorizationDecision:
        try:
            decision = self._authorize(request)
        except Exception as error:
            self._record_pending_failure(command.command_id, "authorization_unavailable")
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUTHORIZATION_UNAVAILABLE",
                "cancellation control authorization could not be verified",
            ) from error
        if not isinstance(decision, AuthorizationDecision):
            self._record_pending_failure(command.command_id, "authorization_invalid")
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUTHORIZATION_INVALID",
                "authorizer must return AuthorizationDecision",
            )
        if decision.subject_id != command.issuer_id:
            self._record_pending_failure(command.command_id, "authorization_identity_mismatch")
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUTHORIZATION_IDENTITY_MISMATCH",
                "authorization identity does not match command issuer",
            )
        try:
            self._audit.record_authorization(command.command_id, decision)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "authorization decision could not be durably audited",
            ) from error
        return decision

    def _publish_authorization_fact(
        self,
        command: ReleaseCancellationFreezeCommand,
        decision: AuthorizationDecision,
        evidence: CancellationReconciliationAudit,
    ) -> None:
        try:
            self._append_monitor_event(
                event_id="cancel-freeze-release-authorized:" + command.command_id,
                event_type="cancellation_freeze_release_authorized",
                data={
                    "authorization_receipt_digest": decision.receipt_digest,
                    "cancel_id": command.cancel_id,
                    "command_id": command.command_id,
                    "evidence_digest": evidence.fingerprint,
                    "issuer_id": command.issuer_id,
                    "state": evidence.record["state"],
                },
                occurred_at=command.issued_at,
            )
        except Exception as error:
            self._record_pending_failure(command.command_id, "authorization_outbox_failed")
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_MONITOR_OUTBOX_UNCONFIRMED",
                "authorization monitor fact was not durable; dispatch remains frozen",
            ) from error

    def _append_monitor_event(
        self,
        *,
        event_id: str,
        event_type: str,
        data: Mapping[str, object],
        occurred_at: float | None,
    ) -> None:
        if occurred_at is None:
            raise ValueError("monitor occurred_at is required")
        self._runtime.outbox.append(
            self._runtime.outbox_event_type(
                event_id=event_id,
                scope=self._runtime.scope.key,
                event_type=event_type,
                data=dict(data),
                occurred_at=occurred_at,
            )
        )

    def _assert_freeze_active(self, cancel_id: str) -> None:
        cause_id = self._freeze_cause(cancel_id)
        try:
            active_reasons = self._runtime.risk_gate.active_freeze_reasons(self._runtime.risk_scope)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_STATE_UNAVAILABLE",
                "cancellation freeze state could not be verified",
            ) from error
        if cause_id not in active_reasons:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_NOT_ACTIVE",
                "unknown cancellation freeze is not active for this cancellation",
            )

    def _assert_freeze_inactive(self, cancel_id: str) -> None:
        cause_id = self._freeze_cause(cancel_id)
        try:
            active_reasons = self._runtime.risk_gate.active_freeze_reasons(self._runtime.risk_scope)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_STATE_UNAVAILABLE",
                "cancellation freeze state could not be verified",
            ) from error
        if cause_id in active_reasons:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_RELEASE_STATE_INCONSISTENT",
                "audit says released while the cancellation freeze is active",
            )

    def _reassert_after_failed_release(
        self, command_id: str, cancel_id: str, outcome_code: str
    ) -> None:
        cause_ids = (
            self._freeze_cause(cancel_id),
            self._release_in_progress_cause(cancel_id),
        )
        try:
            for cause_id in cause_ids:
                self._runtime.risk_gate.freeze(self._runtime.risk_scope, cause_id, cause_id)
                self._assert_cause_active(cause_id)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_FREEZE_REASSERT_FAILED",
                "release outcome is uncertain and cancellation freeze could not be restored",
            ) from error
        try:
            self._audit.mark_command_reasserted(command_id, outcome_code)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "reasserted cancellation freeze could not be durably audited",
            ) from error

    def _record_pending_failure(self, command_id: str, outcome_code: str) -> None:
        try:
            self._audit.record_pending_failure(command_id, outcome_code)
        except Exception as error:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_AUDIT_UNCONFIRMED",
                "control refusal could not be durably audited",
            ) from error

    @staticmethod
    def _is_reviewed_terminal(record: Any) -> bool:
        try:
            projection = _record_projection(record)
        except ValueError:
            return False
        return (
            projection["state"] in {"CANCELLED", "REJECTED"} and not projection["review_required"]
        )

    @staticmethod
    def _record_matches_observation(record: Any, observation: Any) -> bool:
        try:
            return _record_projection(record) == {
                "cancel_id": _observation_projection(observation)["cancel_id"],
                "target_intent_id": _observation_projection(observation)["target_intent_id"],
                "provider_order_id": _observation_projection(observation)["provider_order_id"],
                "state": _observation_projection(observation)["state"],
                "review_required": False,
            }
        except ValueError:
            return False

    @staticmethod
    def _record_matches_projection(record: Any, expected: Mapping[str, object]) -> bool:
        try:
            return _record_projection(record) == dict(expected)
        except ValueError:
            return False

    def _observation_from_audit(self, evidence: CancellationReconciliationAudit) -> Any:
        """Rebuild the package-owned typed observation for the authorizer only."""

        observation = evidence.observation
        return self._runtime.execution.CancelObservation(
            cancel_id=observation["cancel_id"],
            target_intent_id=observation["target_intent_id"],
            provider_order_id=observation["provider_order_id"],
            state=observation["state"],
            reason_code=observation["reason_code"],
        )

    def _freeze_cause(self, cancel_id: str) -> str:
        scope_key = getattr(self._runtime.scope, "key", None)
        if not isinstance(scope_key, str) or not scope_key:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_SCOPE_MISMATCH",
                "runtime cancellation freeze lacks an execution scope",
            )
        return "cancel-outcome-unknown:" + scope_key + ":" + _identifier(cancel_id, "cancel_id")

    def _release_in_progress_cause(self, cancel_id: str) -> str:
        scope_key = getattr(self._runtime.scope, "key", None)
        if not isinstance(scope_key, str) or not scope_key:
            raise RuntimePluginError(
                "CANCELLATION_CONTROL_SCOPE_MISMATCH",
                "runtime cancellation release lacks an execution scope",
            )
        return "cancel-release-in-progress:" + scope_key + ":" + _identifier(
            cancel_id, "cancel_id"
        )


__all__ = [
    "CancellationControlAuditConflictError",
    "CancellationControlAuditError",
    "CancellationControlCommandAudit",
    "CancellationFreezeReleaseResult",
    "CancellationReconciliationAudit",
    "CancellationReconciliationEvidence",
    "CancellationReleaseAuthorizationRequest",
    "ControlledCancellationReconciliationResult",
    "DurableCancellationControlAudit",
    "ManagedCancellationReconciliationControlPort",
    "ReleaseCancellationFreezeCommand",
]
