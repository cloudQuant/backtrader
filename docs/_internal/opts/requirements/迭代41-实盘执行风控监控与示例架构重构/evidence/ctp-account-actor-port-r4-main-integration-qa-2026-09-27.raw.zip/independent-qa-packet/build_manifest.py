from __future__ import annotations
import hashlib, json
from pathlib import Path
root = Path(r'D:\temp\iteration41-ctp-account-actor-r4-independent-review-20260927')
files = []
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name not in {'qa-manifest.json', 'qa-manifest.sha256'}:
        data = path.read_bytes()
        files.append({
            'path': str(path.relative_to(root)).replace('\\', '/'),
            'size_bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
        })
manifest = {
    'qa': 'ctp-account-actor-port-r4-independent-review',
    'frozen_source_root': r'D:\temp\iteration41-ctp-account-actor-port-freeze-20260927-r4',
    'frozen_manifest_sha256': '8f793cc85754f6fa447925bd0ad40570dd7f10480773f45500b56fd0933591a8',
    'isolated_candidate_copy': r'D:\temp\iteration41-ctp-account-actor-port-r4-qa-independent-20260927',
    'main_source': r'D:\source_code\backtrader\backtrader\stores\btapistore.py',
    'main_source_sha256': 'DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826',
    'tests': {'command': 'python -B -m unittest discover -s tests -v', 'passed': 34, 'failed': 0, 'exit_code': 0},
    'scope': 'isolated offline fake-only candidate QA and static main Store review; no provider/SDK/native/network/credentials/account access',
    'files': files,
}
manifest_path = root / 'qa-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n', encoding='utf-8')
manifest_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
(root / 'qa-manifest.sha256').write_text(manifest_hash + '  qa-manifest.json\n', encoding='ascii')
print(manifest_hash)
