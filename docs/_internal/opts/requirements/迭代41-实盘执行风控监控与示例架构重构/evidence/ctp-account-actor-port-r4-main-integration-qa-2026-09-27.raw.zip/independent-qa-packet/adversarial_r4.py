from decimal import Decimal
from account_actor_port import (
    AccountActorGateError, ActorCommandReceiptV2, ActorCommandState,
    CtpAccountActorPort, CtpSubmitIntentV2, FakeLocalActorReplayLedger,
    StoreRouteDescriptor,
)
from store_boundary_harness import StoreBoundaryHarness

class Actor(CtpAccountActorPort):
    def __init__(self, mutate=None): self.calls = 0; self.mutate = mutate
    def submit_order(self, intent):
        self.calls += 1
        receipt = ActorCommandReceiptV2(intent.operation, intent.command_id, ActorCommandState.QUEUED, intent.context, intent.command_digest)
        return self.mutate(receipt) if self.mutate else receipt
    def cancel_order(self, intent): raise AssertionError('not used')

def ctx(**kw):
    v = dict(account_ref='account-A', runtime_id='runtime-A', mode='simulation', config_digest='a'*64, session_id='sid-A', front_id=7, native_session_id=11, session_generation=4, actor_epoch=3)
    v.update(kw)
    from account_actor_port import ActorCommandContextV1
    return ActorCommandContextV1(**v)

def intent(context, ident='intent-A'):
    return CtpSubmitIntentV2(ident, 'IF2601', 'CFFEX', 'BUY', 'OPEN', 'SPECULATION', 1, Decimal('3000'), context)

results = {}
# Missing authority is stopped before credentials/factories.
counts = {'credentials':0, 'api':0, 'gateway':0}
def bump(key):
    def f(): counts[key] += 1; return object()
    return f
try:
    StoreBoundaryHarness(StoreRouteDescriptor('ctp', 'direct'), actor_port=None, credential_resolver=bump('credentials'), api_factory=bump('api'), gateway_factory=bump('gateway'))
except AccountActorGateError as e:
    results['absent_actor'] = {'code':e.code, 'counts':dict(counts)}
assert results['absent_actor']['code'] == 'external_account_actor_unavailable' and counts == {'credentials':0,'api':0,'gateway':0}
# A caller can invent a stale epoch and matching account context: there is no external source.
stale = ctx(actor_epoch=999)
a = Actor(); h = StoreBoundaryHarness(StoreRouteDescriptor('ctp','direct'), actor_port=a, actor_context=stale, receipt_ledger=FakeLocalActorReplayLedger())
r = h.submit_order(intent(stale))
results['caller_invented_stale_epoch'] = {'accepted':True,'receipt_state':r.state.value,'actor_calls':a.calls,'epoch':stale.actor_epoch}
assert a.calls == 1
# The same is true for an arbitrary wrong account if the caller supplies both sides.
wrong = ctx(account_ref='account-not-from-sealed-config')
a2 = Actor(); h2 = StoreBoundaryHarness(StoreRouteDescriptor('ctp','direct'), actor_port=a2, actor_context=wrong, receipt_ledger=FakeLocalActorReplayLedger())
h2.submit_order(intent(wrong, 'intent-wrong-account'))
results['caller_invented_wrong_account'] = {'accepted':True,'actor_calls':a2.calls,'account_ref':wrong.account_ref}
assert a2.calls == 1
# Mismatch against the locally pinned expected context rejects before the actor.
a3 = Actor(); expected=ctx(); h3=StoreBoundaryHarness(StoreRouteDescriptor('ctp','direct'), actor_port=a3, actor_context=expected, receipt_ledger=FakeLocalActorReplayLedger())
try: h3.submit_order(intent(ctx(actor_epoch=expected.actor_epoch+1), 'intent-stale-mismatch'))
except AccountActorGateError as e: results['mismatched_stale_epoch']={'code':e.code,'actor_calls':a3.calls}
assert results['mismatched_stale_epoch']=={'code':'actor_intent_context_mismatch','actor_calls':0}
# A locally repeated command is stopped before a second actor call.
a4=Actor(); ledger=FakeLocalActorReplayLedger(); h4=StoreBoundaryHarness(StoreRouteDescriptor('ctp','direct'),actor_port=a4,actor_context=expected,receipt_ledger=ledger); i=intent(expected,'same-id')
h4.submit_order(i)
try: h4.submit_order(i)
except AccountActorGateError as e: results['receipt_replay']={'code':e.code,'actor_calls':a4.calls}
assert results['receipt_replay']=={'code':'actor_intent_replay','actor_calls':1}
# Untrusted shallowly immutable route descriptor changes after classification; fake harness keeps NON_CTP.
route=StoreRouteDescriptor('okx','direct',config={'exchange_type':'OKX'})
h5=StoreBoundaryHarness(route)
route.config['exchange_type']='CTP'
legacy=h5.submit_order({'raw':'payload'})
results['mutable_route_after_gate']={'initial_route_kind':h5.route_kind.value,'mutated_exchange_type':route.config['exchange_type'],'result':legacy,'legacy_calls':h5.legacy_calls}
assert results['mutable_route_after_gate']=={'initial_route_kind':'non_ctp','mutated_exchange_type':'CTP','result':'legacy_non_ctp','legacy_calls':1}
print(results)
