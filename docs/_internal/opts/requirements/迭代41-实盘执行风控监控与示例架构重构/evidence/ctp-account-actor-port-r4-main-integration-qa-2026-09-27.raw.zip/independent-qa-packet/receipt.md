# Independent QA — CTP AccountActorPort r4

Date: 2026-09-27 (Asia/Singapore)

## Freeze and source provenance

- Frozen source: `D:\temp\iteration41-ctp-account-actor-port-freeze-20260927-r4`
- Frozen `manifest.json` SHA-256: `8f793cc85754f6fa447925bd0ad40570dd7f10480773f45500b56fd0933591a8`
- QA isolated copy: `D:\temp\iteration41-ctp-account-actor-port-r4-qa-independent-20260927`
- All 9 manifest-listed payload files were copied and checked for exact size and SHA-256; see `payload-verification.json`.
- Imports during independent run resolved to the isolated copy: `module-origins.txt`.

## Test result

Command from the isolated copy, with bytecode disabled:

`PYTHONDONTWRITEBYTECODE=1; python -B -m unittest discover -s tests -v`

Result: 34 passed, 0 failed, process exit 0. Raw output is in `frozen-focus.stdout.txt` and `frozen-focus.stderr.txt` (PowerShell redirected streams separately); exit marker is `frozen-focus.exit.txt`.

Supplemental fake-only probe: `adversarial_r4.py` completed; output is in `adversarial-results.txt`. It made no SDK, native, provider, credential, network, or account calls.

Observed cases:

- CTP route with no actor rejects as `external_account_actor_unavailable` before credential/API/gateway counters move.
- An intent whose actor epoch/account differs from the locally configured expected context rejects before actor invocation; the duplicate command id is claimed once and a second call is rejected before a second actor invocation.
- A self-consistent caller-selected stale epoch (`actor_epoch=999`) and arbitrary account reference are accepted by the fake harness when the caller supplies those same values as its expected `actor_context`. This is the documented authority limit, not proof of a current actor epoch or sealed account.
- The frozen `StoreRouteDescriptor` is only shallowly frozen: its `config` dict remains mutable. After constructing a harness as `NON_CTP` for OKX, changing that dict to CTP leaves the cached `route_kind=NON_CTP` and permits the harness legacy path. This is a candidate-local route-snapshot defect; the candidate is not wired into main Store.

The r4 focused contract has no callback inbox/callback-replay API. The replay test concerns duplicate command IDs in the in-memory fake ledger only. It cannot evidence callback deduplication or durable cross-process replay protection.

## Main Store static call surface (no code changed, no runtime call made)

Inspected `D:\source_code\backtrader\backtrader\stores\btapistore.py`, SHA-256 `DBA2989252DB76FE010FBEE7CAACDCDBA34A9B951E3702724156482B67FAE826`. Search under `backtrader/` and `backtrader_runtime/` found no `AccountActorPort`, `CtpAccountActorPort`, `actor_port`, or `require_account_actor_before_local_client` integration symbol.

- Construction resolves provider before any actor gate (`_resolve_provider`, lines 3768–72; called from `__init__` at 3500). `BT_STORE_PROVIDER` can rewrite requested `ctp` to a gateway selector. Backend resolution accepts `forwarding` at 3435–44. Constructor reads caller `api.exchange_kwargs` at 3538 and can autostart at 3765–66.
- Public submit without the managed adapter goes straight to `_submit_order_legacy` at 7714–27. Public `cancel_order` and `cancel_order_ref` without the adapter go to `_cancel_order_ref_legacy` at 7991–8008 and 8062–68.
- Those legacy methods reject only when a managed adapter exists and `_is_ctp_session_provider()` is true (submit 7906–14; cancel 8219–27). They are otherwise reachable and perform local dispatch.
- `enqueue_order` and `enqueue_cancel` likewise reject the managed CTP case only when the managed adapter is installed (7151–58, 7309–18). Generic SDK commands reach `_invoke_sdk_command` at 6635–49, which invokes `async_make_order` / `async_cancel_order`.
- `_is_ctp_session_provider()` returns false for all `backend='forwarding'` (8363–65). Therefore a CTP+forwarding configuration is not protected by the Store's CTP-specific managed-adapter checks. `_ensure_api_ready` selects `_create_forwarding_client` for that backend (16395–16421, 16541 onward); the forwarding client receives configured exchange values and supports command forwarding. This is a static path finding, not an executed provider request.
- Direct CTP wrapper sends use the typed execution method only when both method and capability exist; otherwise they call raw `ReqOrderInsert` / `ReqOrderAction` (1933–49). The old gateway wrapper forwards `submit_order` and `cancel_order` to `GatewayClient` (3318–27, 3343–53).
- No runtime test in this audit constructed `BtApiStore`, imported the SDK, called a provider, read private configuration, or accessed a live account. The cited paths establish callable source routes only; they do not establish deployment reachability or an actual order send.

## Required main integration negatives

1. Before provider/environment rewriting, private credential extraction, injected API attribute reads, SDK/gateway imports, factory invocation, start/connect, or autostart, classify the raw requested route. With no external actor, all CTP, ambiguous, unknown, and unsupported routes must fail with all credential/client/native counters at zero.
2. Include direct `ctp`, `ctp_gateway`, generic `gateway` default-to-CTP, `btapi` CTP in `exchange_kwargs`, recursively nested selector routes, `provider=ctp` plus `backend=forwarding` and CTP exchange, and environment attempts to downgrade CTP to a non-CTP gateway.
3. Exercise public `submit_order`, `cancel_order`, `cancel_order_ref`, legacy private dispatch methods, generic `enqueue_order`/`enqueue_cancel`/`_enqueue_order_command`, SDK worker methods, direct CTP wrapper, and old gateway wrapper. With actor absent/unavailable, every path must reject before local queueing or any API/native counter.
4. With an actor present, only exact typed submit/cancel intents may reach it. Reject stale/mismatched sealed account/session/epoch before the actor; bind receipts to the durable request identity; replay and unknown receipt states must not become provider acknowledgement or trigger local retry. Assert no fallback, SDK worker, API constructor, or raw `Req*` call.
5. Add route immutability/snapshot tests: mutable caller config must not change the post-gate provider/backend/venue decision. The r4 shallow-frozen descriptor probe is a concrete requirement for that test.

## Acceptance boundary

The isolated classifier and local DTO plumbing passed its 34 tests. Its local actor epoch/account binding is caller-supplied and the in-memory ledger is process-local. The main Store has no actor gate and retains legacy dispatch surfaces. Therefore this QA accepts only the narrow offline candidate test result; it does not accept main integration, durable actor receipts, CTP dispatch, G6-P, or live operation. No default route changes were made.
