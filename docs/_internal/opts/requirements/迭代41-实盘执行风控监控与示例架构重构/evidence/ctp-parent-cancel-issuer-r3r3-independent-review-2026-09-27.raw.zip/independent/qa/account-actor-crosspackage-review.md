# Independent cancel resolution cross-package QA

## Frozen inputs

- Parent issuer r2: `D:\temp\iteration41_parent76_cancel_resolution_issuer_r3r3_review_20260927_freeze_r2`
- Parent snapshot manifest SHA-256: `50B0D8B99AFDACDAF2055246010E5766BBE630BC66D71C2AEEACA117BAF3CE7A`
- Execution R3r3 manifest SHA-256: `7655307FB90C959DABF5DC14786D02C60EDD3FCF3D1FC3CEFC32F2512E34EEEC`
- Risk resolver manifest SHA-256: `B5B066E901E656E3CE42599E0701B731DF16BE742121A43604B58D69E35DED5D`
- Independently recomputed all 15 parent snapshot payload hashes; all matched.

## Run

From `D:\temp\iteration41_cancel_issuer_crosspackage_qa_r2_20260927`, Python 3.11.5 (`C:\anaconda3\python.exe`), `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, `PYTHONPATH` unset:

```powershell
python -m pytest -q --color=no --basetemp qa\final-basetemp --junitxml qa\final-junit.xml tests\test_cancel_dispatch_resolution_proof.py tests\test_cancel_dispatch_resolution_proof_store.py tests\test_account_actor_crosspackage_cancel.py --tb=short
```

Result: **28 passed**. The existing issuer suite contributes 23 tests; the independent cross-package file contributes 5. Existing tests assert execution/risk package origins against the frozen dependency roots.

- Log SHA-256: `8787C2BDC2C0BF1D0F3B395D53EE01B2D9EBF98562FB3DD19CE05F6CFE7B546B`
- JUnit SHA-256: `D033F3C9011BDF51B9B86BE75230690EB7015D931FFCA0C0CC2B1E6A1782B32A`
- Independent test SHA-256: `B7782E21E054210E4C3FB3CB45715D04B625B427B6F40AB44B6864672372F03E`
- Synthetic SQLite hash inventory (43 files): `qa\final-synthetic-db-manifest.json`, SHA-256 `71543860E42B7DF4496779A778F5BCD6C402847AA3201E522A8F596462408566`.
- Machine-readable receipt: `qa\account-actor-crosspackage-review.json`, SHA-256 `C409209C902711101A73B19417AA8C0ABAEF4D772414112B28EED23F49FF051C`.

## Independent cases

- `CANCELLED` and `REJECTED` proofs each resolve only their matching cancel latch. The second cancel latch stays active after resolving the first.
- A separate active order exposure permit remains active with its notional unchanged after resolving its target's cancel latch.
- `UNKNOWN` cannot issue a terminal proof; arbitrary proof objects do not resolve the risk latch.
- A proof under an old writer lease fails after release and a higher fencing generation is acquired.
- A proof fails after the target projection changes through the public reconcile API.
- A foreign risk account cannot issue a proof; changing the proof's scope to another account fails risk resolution.

## Limits

All tests use synthetic SQLite journals and fake providers. No native SDK/provider, network, credentials, or private configuration was used. This verifies the frozen fake issuer + Risk resolver contract only. The parent control-release call is not wired into the production composition, and normalized journal digests are not authenticated provider evidence.
