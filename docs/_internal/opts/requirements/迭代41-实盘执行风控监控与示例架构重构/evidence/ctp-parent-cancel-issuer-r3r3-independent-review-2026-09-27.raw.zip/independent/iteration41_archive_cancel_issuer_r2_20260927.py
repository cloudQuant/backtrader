from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


SNAPSHOT = Path(r"D:\temp\iteration41_parent76_cancel_resolution_issuer_r3r3_review_20260927_freeze_r2")
QA = Path(r"D:\temp\iteration41_cancel_issuer_crosspackage_qa_r2_20260927")
EVIDENCE = Path(r"D:\source_code\backtrader\docs\_internal\opts\requirements\迭代41-实盘执行风控监控与示例架构重构\evidence")
STEM = "ctp-parent-cancel-issuer-r3r3-independent-review-2026-09-27"
SNAPSHOT_SHA = "50b0d8b99afdacdaf2055246010e5766bbe630bc66d71c2aeeaca117baf3ce7a"
QA_JSON_SHA = "c409209c902711101a73b19417aa8c0abaef4d772414112b28eed23f49ff051c"
QA_MD_SHA = "898be54c86dc3582266040ee2c2cb6e739e8fc87f0f869bf610ae43e261f3b89"
QA_TEST_SHA = "b7782e21e054210e4c3fb3cb45715d04b625b427b6f40ab44b6864672372f03e"
QA_LOG_SHA = "8787c2bdc2c0bf1d0f3b395d53ee01b2d9ebf98562fb3dd19ce05f6cfe7b546b"
QA_JUNIT_SHA = "d033f3c9011bdf51b9b86be75230690eb7015d931ffca0c0cc2b1e6a1782b32a"
QA_DB_MANIFEST_SHA = "71543860e42b7df4496779a778f5bcd6c402847aa3201e522a8f596462408566"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def checked(path: Path, expected: str, size: int | None = None) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"invalid file: {path}")
    raw = path.read_bytes()
    if sha(raw) != expected.lower() or (size is not None and len(raw) != size):
        raise RuntimeError(f"hash/size mismatch: {path}")
    return raw


def main() -> None:
    snapshot_raw = checked(SNAPSHOT / "snapshot-manifest.json", SNAPSHOT_SHA)
    snapshot = json.loads(snapshot_raw)
    assert len(snapshot["files"]) == 15
    assert snapshot["acceptance_boundary"]["fake_only"] is True
    qa_raw = checked(QA / "qa/account-actor-crosspackage-review.json", QA_JSON_SHA)
    qa = json.loads(qa_raw)
    assert qa["snapshot_manifest_sha256"].lower() == SNAPSHOT_SHA
    assert qa["manifest_payload_files_verified"] == 15
    assert qa["verification"]["result"].startswith("28 passed")
    db_manifest_raw = checked(QA / "qa/final-synthetic-db-manifest.json", QA_DB_MANIFEST_SHA)
    db_manifest = json.loads(db_manifest_raw)
    assert len(db_manifest) == qa["verification"]["synthetic_sqlite_files"] == 43
    for row in snapshot["files"]:
        checked(SNAPSHOT / row["path"], row["sha256"])
    for row in db_manifest:
        checked(QA / row["path"], row["sha256"], row["bytes"])
    for suffix in (".raw.zip", ".json", ".md"):
        assert not (EVIDENCE / f"{STEM}{suffix}").exists()
    archive = EVIDENCE / f"{STEM}.raw.zip"
    entries: list[dict[str, object]] = []

    def add(zf: zipfile.ZipFile, path: Path, name: str, expected: str, size: int | None = None) -> None:
        raw = checked(path, expected, size)
        zf.writestr(name, raw)
        entries.append({"path": name, "sha256": sha(raw), "bytes": len(raw)})

    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zf:
        add(zf, SNAPSHOT / "snapshot-manifest.json", "issuer/snapshot-manifest.json", SNAPSHOT_SHA)
        for row in snapshot["files"]:
            name = row["path"].replace("\\", "/")
            add(zf, SNAPSHOT / row["path"], "issuer/" + name, row["sha256"])
        for name, expected in (
            ("qa/account-actor-crosspackage-review.json", QA_JSON_SHA),
            ("qa/account-actor-crosspackage-review.md", QA_MD_SHA),
            ("tests/test_account_actor_crosspackage_cancel.py", QA_TEST_SHA),
            ("qa/final-pytest.log", QA_LOG_SHA),
            ("qa/final-junit.xml", QA_JUNIT_SHA),
            ("qa/final-synthetic-db-manifest.json", QA_DB_MANIFEST_SHA),
        ):
            add(zf, QA / name, "independent/" + name.replace("\\", "/"), expected)
        for row in db_manifest:
            name = row["path"].replace("\\", "/")
            add(zf, QA / row["path"], "independent/" + name, row["sha256"], row["bytes"])
        script = Path(__file__)
        add(zf, script, "independent/" + script.name, sha(script.read_bytes()))
    with zipfile.ZipFile(archive) as zf:
        assert zf.testzip() is None
        assert len(zf.namelist()) == len(entries) == 66
    archive_sha = sha(archive.read_bytes())
    review = {
        "schema": "iteration41.parent_cancel_issuer_r3r3.root_review.v1",
        "status": "LOCAL_FAKE_ISSUER_PASS_MAIN_CONTROL_WIRING_PENDING",
        "issuer_manifest_sha256": SNAPSHOT_SHA,
        "independent_qa_receipt_sha256": QA_JSON_SHA,
        "root_reverified": {"issuer_payloads": 15, "synthetic_sqlite_files": 43, "zip_testzip": None},
        "tests": "23 author freeze / 28 combined independent (5 new cross-package)",
        "limits": [
            "SIMULATION_JOURNAL fake/offline issuer only; normalized source digest is not authenticated provider evidence.",
            "Parent control-release/main Backtrader composition and production/direct authority are not wired.",
            "No native SDK, provider, protected config, account or trading request was used.",
        ],
        "archive": {"file": archive.name, "sha256": archive_sha, "entries": len(entries)},
        "files": entries,
    }
    (EVIDENCE / f"{STEM}.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (EVIDENCE / f"{STEM}.md").write_text(
        "# Parent R3r3 fake 撤单终态证明发行器独立复核\n\n"
        "发行器 r2 manifest `" + SNAPSHOT_SHA + "` 的 15 项来源/测试经 root 逐条复核；"
        "独立隔离 QA 在冻结 Execution R3r3 与 risk 源上通过 `28 passed`（作者 23 项 + 5 项跨包负测）。"
        "新用例覆盖 CANCELLED/REJECTED 只解除精确取消闸、订单敞口仍在，及 UNKNOWN、伪证明、旧 writer lease、"
        "目标投影变化、外来账户/范围拒绝。43 个合成 SQLite 原件及其摘要也入档。\n\n"
        "此发行器只在 fake/offline `SIMULATION_JOURNAL` 下从 Execution 的受租约保护原子读回生成证明。"
        "规范化 journal 来源摘要不认证 provider；parent 控制端释放顺序与主仓接线尚未完成，"
        "真实 SimNow/production 仍 `NO_WRITE / LIVE_NO_GO`。旧 r1 快照由 r2 取代；作者口述 r2 摘要漏末尾 `A`，"
        "本页采用对磁盘实算的完整 64 位值。\n\n"
        f"[机器记录]({STEM}.json)与[原始归档]({STEM}.raw.zip)包含源码和独立 QA；"
        f"归档 SHA-256 `{archive_sha}`，共 {len(entries)} 项。\n",
        encoding="utf-8",
    )
    print(json.dumps({"archive": str(archive), "sha256": archive_sha, "entries": len(entries)}))


if __name__ == "__main__":
    main()
