"""Independent risk + parent issuer adversarial checks on frozen source roots."""

from __future__ import annotations

import importlib.util
import sqlite3
import sys
from dataclasses import replace
from decimal import Decimal
from pathlib import Path

import pytest

_ROOT = Path(__file__).parents[1]
_STORE_TEST_SPEC = importlib.util.spec_from_file_location(
    "account_actor_r3r3_store_fixtures",
    _ROOT / "tests" / "test_cancel_dispatch_resolution_proof_store.py",
)
assert _STORE_TEST_SPEC is not None and _STORE_TEST_SPEC.loader is not None
_STORE_TESTS = importlib.util.module_from_spec(_STORE_TEST_SPEC)
sys.modules[_STORE_TEST_SPEC.name] = _STORE_TESTS
_STORE_TEST_SPEC.loader.exec_module(_STORE_TESTS)

execution = _STORE_TESTS.execution
risk = _STORE_TESTS.risk
_OrderGate = _STORE_TESTS._OrderGate
_RealRiskCancelAdmission = _STORE_TESTS._RealRiskCancelAdmission
_real_risk_types = _STORE_TESTS._real_risk_types

_PARENT_SPEC = importlib.util.spec_from_file_location(
    "account_actor_parent_issuer_under_test", _ROOT / "src" / "fake_dispatch_authority.py"
)
assert _PARENT_SPEC is not None and _PARENT_SPEC.loader is not None
_PARENT = importlib.util.module_from_spec(_PARENT_SPEC)
sys.modules[_PARENT_SPEC.name] = _PARENT
_PARENT_SPEC.loader.exec_module(_PARENT)


def _make_stack(tmp_path: Path, account_ref: str = "acct-cross"):
    scope = execution.ExecutionScope(
        "FAKE", "offline", account_ref, "strategy.cross", "20260927"
    )
    store = execution.SqliteExecutionStore(tmp_path / "execution.sqlite3")
    facade = execution.ManagedExecutionFacade(
        store, scope, writer_id="cross-writer", admission_gate=_OrderGate()
    )
    risk_scope = risk.AccountScope("fake", account_ref, "offline")
    authority = _PARENT.ManagedFakeProviderJournalAuthority(
        database_path=tmp_path / "fake.sqlite3",
        execution_scope=scope,
        risk_scope=risk_scope,
        execution_store=store,
        facade=facade,
        risk_types=_real_risk_types(),
    )
    gate = risk.DurableRiskGate(
        tmp_path / "risk.sqlite3",
        risk.RiskPolicy(
            policy_id="cross-package-cancel-policy",
            max_increase_notional=Decimal("100"),
            max_increase_count=5,
        ),
        execution_journal_authority=authority,
    )
    admission = _RealRiskCancelAdmission(gate, risk_scope, scope)
    return scope, store, facade, risk_scope, authority, gate, admission


def _submit_partial_order(facade, scope, execution, suffix: str):
    order = execution.OrderIntent.limit(
        intent_id="order-" + suffix,
        scope=scope,
        signal_id="signal-" + suffix,
        instrument="BTC-USDT",
        side=execution.Side.BUY,
        quantity=Decimal("2"),
        price=Decimal("5"),
        metadata_version="meta-v1",
    )
    accepted = facade.submit(
        order,
        lambda intent: execution.ProviderObservation.accepted(
            intent.intent_id, "provider-order-" + suffix
        ),
    )
    assert accepted.state is execution.ExecutionState.ACKED
    partial = facade.reconcile(
        execution.ProviderObservation(
            intent_id=order.intent_id,
            state=execution.ExecutionState.PARTIALLY_FILLED,
            provider_order_id="provider-order-" + suffix,
            filled_quantity=Decimal("0.5"),
            average_price=Decimal("5"),
            cumulative_commission=Decimal("-0.01"),
        )
    )
    return order, partial


def _cancel(order, scope, execution, cancel_id: str, state: str):
    intent = execution.CancelIntent(
        cancel_id=cancel_id,
        scope=scope,
        target_intent_id=order.intent_id,
        provider_order_id=order.intent_id.replace("order-", "provider-order-"),
        metadata_version="meta-v1",
    )
    if state == "CANCELLED":
        dispatch = lambda item: execution.CancelObservation.cancelled(
            item.cancel_id, item.target_intent_id, item.provider_order_id
        )
    elif state == "REJECTED":
        dispatch = lambda item: execution.CancelObservation.rejected(
            item.cancel_id,
            item.target_intent_id,
            item.provider_order_id,
            "provider_rejected",
        )
    else:
        raise ValueError("unsupported test state")
    return intent, dispatch


def _risk_rows(database_path: Path, query: str):
    connection = sqlite3.connect(database_path)
    try:
        connection.row_factory = sqlite3.Row
        return connection.execute(query).fetchall()
    finally:
        connection.close()


def test_risk_resolution_clears_only_its_cancel_latch_and_preserves_order_exposure(
    tmp_path: Path,
) -> None:
    scope, store, facade, risk_scope, authority, gate, admission = _make_stack(tmp_path)
    try:
        order1, _ = _submit_partial_order(facade, scope, execution, "one")
        order2, _ = _submit_partial_order(facade, scope, execution, "two")
        exposure_intent = risk.RiskIntent(
            intent_id="exposure:" + order1.intent_id,
            scope=risk_scope,
            action=risk.IntentAction.INCREASE,
            notional=Decimal("10"),
            payload_fingerprint=order1.fingerprint,
        )
        exposure_permit = gate.reserve(exposure_intent)
        cancel_facade = execution.ManagedCancellationFacade(
            store,
            scope,
            acquire_writer_lease=facade.acquire_writer_lease,
            admission_gate=admission,
        )
        cancel1, dispatch1 = _cancel(order1, scope, execution, "cancel-one", "CANCELLED")
        cancel2, dispatch2 = _cancel(order2, scope, execution, "cancel-two", "REJECTED")
        record1 = cancel_facade.cancel(cancel1, dispatch1)
        record2 = cancel_facade.cancel(cancel2, dispatch2)
        assert record1.state is execution.ExecutionState.CANCELLED
        assert record2.state is execution.ExecutionState.REJECTED

        permit1 = record1.permit_reference
        permit2 = record2.permit_reference
        assert permit1 and permit2 and permit1 != permit2
        binding2 = gate.dispatch_claim_binding(permit2)
        assert binding2.cause_id in gate.active_freeze_reasons(risk_scope)

        proof1 = authority.create_cancel_dispatch_resolution_proof(cancel1.cancel_id, admission)
        gate.resolve_cancel_dispatch_freeze(proof1)

        # Only the first action latch is consumed; the second cancellation and
        # the independent order exposure reservation remain durable.
        assert gate.active_freeze_reasons(risk_scope) == [binding2.cause_id]
        assert gate.snapshot(risk_scope)["increase_count"] == 1
        assert gate.snapshot(risk_scope)["increase_notional"] == Decimal("10")
        rows = _risk_rows(
            tmp_path / "risk.sqlite3",
            "SELECT permit_id, action, status, notional FROM risk_reservations",
        )
        by_permit = {row["permit_id"]: row for row in rows}
        assert by_permit[permit1]["status"] == "settled"
        assert by_permit[permit2]["status"] == "settled"
        assert by_permit[exposure_permit.permit_id]["status"] == "active"
        assert by_permit[exposure_permit.permit_id]["notional"] == "10"

        proof2 = authority.create_cancel_dispatch_resolution_proof(cancel2.cancel_id, admission)
        gate.resolve_cancel_dispatch_freeze(proof2)
        assert gate.active_freeze_reasons(risk_scope) == []
        assert gate.snapshot(risk_scope)["increase_count"] == 1
    finally:
        store.close()


def test_unknown_cancel_cannot_issue_or_consume_terminal_proof(tmp_path: Path) -> None:
    scope, store, facade, risk_scope, authority, gate, admission = _make_stack(tmp_path)
    try:
        order, _ = _submit_partial_order(facade, scope, execution, "unknown")
        cancel = execution.CancelIntent(
            cancel_id="cancel-unknown",
            scope=scope,
            target_intent_id=order.intent_id,
            provider_order_id="provider-order-unknown",
            metadata_version="meta-v1",
        )
        cancel_facade = execution.ManagedCancellationFacade(
            store,
            scope,
            acquire_writer_lease=facade.acquire_writer_lease,
            admission_gate=admission,
        )

        def ambiguous_dispatch(_intent):
            raise RuntimeError("fake lost terminal outcome")

        record = cancel_facade.cancel(cancel, ambiguous_dispatch)
        assert record.state is execution.ExecutionState.UNKNOWN
        assert record.permit_reference
        binding = gate.dispatch_claim_binding(record.permit_reference)
        with pytest.raises(Exception):
            authority.create_cancel_dispatch_resolution_proof(cancel.cancel_id, admission)
        with pytest.raises(risk.PermitInvalidError):
            gate.resolve_cancel_dispatch_freeze(object())
        assert gate.active_freeze_reasons(risk_scope) == [binding.cause_id]
        assert _risk_rows(
            tmp_path / "risk.sqlite3", "SELECT * FROM risk_cancel_dispatch_resolutions"
        ) == []
    finally:
        store.close()


def test_stale_writer_generation_cannot_resolve_frozen_cancel_proof(tmp_path: Path) -> None:
    scope, store, facade, risk_scope, authority, gate, admission = _make_stack(tmp_path)
    try:
        order, _ = _submit_partial_order(facade, scope, execution, "stale")
        cancel, dispatch = _cancel(order, scope, execution, "cancel-stale", "REJECTED")
        cancel_facade = execution.ManagedCancellationFacade(
            store,
            scope,
            acquire_writer_lease=facade.acquire_writer_lease,
            admission_gate=admission,
        )
        record = cancel_facade.cancel(cancel, dispatch)
        binding = gate.dispatch_claim_binding(record.permit_reference)
        proof = authority.create_cancel_dispatch_resolution_proof(cancel.cancel_id, admission)

        old_lease = facade.acquire_writer_lease()
        assert store.release_lease(
            scope, old_lease.owner_id, fencing_token=old_lease.fencing_token
        )
        replacement = execution.ManagedExecutionFacade(
            store, scope, writer_id="replacement-writer", admission_gate=_OrderGate()
        )
        new_lease = replacement.acquire_writer_lease()
        assert new_lease.fencing_token > old_lease.fencing_token

        with pytest.raises(risk.PermitInvalidError):
            gate.resolve_cancel_dispatch_freeze(proof)
        assert gate.active_freeze_reasons(risk_scope) == [binding.cause_id]
        assert _risk_rows(
            tmp_path / "risk.sqlite3", "SELECT * FROM risk_cancel_dispatch_resolutions"
        ) == []
    finally:
        store.close()


def test_old_proof_cannot_resolve_after_public_target_projection_changes(
    tmp_path: Path,
) -> None:
    scope, store, facade, risk_scope, authority, gate, admission = _make_stack(tmp_path)
    try:
        order, partial = _submit_partial_order(facade, scope, execution, "changed")
        cancel, dispatch = _cancel(order, scope, execution, "cancel-changed", "REJECTED")
        cancel_facade = execution.ManagedCancellationFacade(
            store,
            scope,
            acquire_writer_lease=facade.acquire_writer_lease,
            admission_gate=admission,
        )
        record = cancel_facade.cancel(cancel, dispatch)
        binding = gate.dispatch_claim_binding(record.permit_reference)
        proof = authority.create_cancel_dispatch_resolution_proof(cancel.cancel_id, admission)

        changed = facade.reconcile(
            execution.ProviderObservation(
                intent_id=order.intent_id,
                state=execution.ExecutionState.PARTIALLY_FILLED,
                provider_order_id="provider-order-changed",
                filled_quantity=Decimal("0.75"),
                average_price=Decimal("5"),
                cumulative_commission=Decimal("-0.02"),
            )
        )
        assert changed.filled_quantity == Decimal("0.75")
        with pytest.raises(risk.PermitInvalidError):
            gate.resolve_cancel_dispatch_freeze(proof)
        assert gate.active_freeze_reasons(risk_scope) == [binding.cause_id]
        assert _risk_rows(
            tmp_path / "risk.sqlite3", "SELECT * FROM risk_cancel_dispatch_resolutions"
        ) == []
        current = store.get(order.intent_id, scope=scope)
        assert current is not None and current.filled_quantity == Decimal("0.75")
        assert partial.filled_quantity == Decimal("0.5")
    finally:
        store.close()


def test_wrong_account_and_scope_proofs_fail_before_resolving_cancel(tmp_path: Path) -> None:
    scope, store, facade, risk_scope, authority, gate, admission = _make_stack(tmp_path)
    try:
        order, _ = _submit_partial_order(facade, scope, execution, "scope")
        cancel, dispatch = _cancel(order, scope, execution, "cancel-scope", "CANCELLED")
        cancel_facade = execution.ManagedCancellationFacade(
            store,
            scope,
            acquire_writer_lease=facade.acquire_writer_lease,
            admission_gate=admission,
        )
        record = cancel_facade.cancel(cancel, dispatch)
        binding = gate.dispatch_claim_binding(record.permit_reference)
        proof = authority.create_cancel_dispatch_resolution_proof(cancel.cancel_id, admission)

        other_scope = risk.AccountScope("fake", "another-account", "offline")
        with pytest.raises(risk.PermitInvalidError):
            authority.create_cancel_dispatch_resolution_proof(
                cancel.cancel_id,
                _RealRiskCancelAdmission(
                    risk.DurableRiskGate(
                        tmp_path / "foreign-risk.sqlite3",
                        risk.RiskPolicy("foreign", Decimal("100"), 2),
                    ),
                    other_scope,
                    scope,
                ),
            )

        forged = replace(proof, scope=other_scope)
        with pytest.raises(risk.PermitInvalidError):
            gate.resolve_cancel_dispatch_freeze(forged)
        assert gate.active_freeze_reasons(risk_scope) == [binding.cause_id]
        assert _risk_rows(
            tmp_path / "risk.sqlite3", "SELECT * FROM risk_cancel_dispatch_resolutions"
        ) == []
    finally:
        store.close()
