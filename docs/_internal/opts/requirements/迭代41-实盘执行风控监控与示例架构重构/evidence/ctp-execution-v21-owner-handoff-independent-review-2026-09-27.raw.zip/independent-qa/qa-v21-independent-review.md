# Independent V21 account-owner handoff QA

**Result:** No reproducible defect found in the reviewed V21 handoff and poisoned-`UNKNOWN` finalizer paths. Scope is local fake/offline only.

## Frozen inputs and provenance

- Frozen source: `D:\temp\iteration41_v21_ctp_account_handoff_freeze_r3_20260927`
- `SOURCE-MANIFEST.json` SHA-256: `b3a614d62b2a4cf1b0dbdfefee463015157dee38bf4c9c5119c64ef2d71d6d24`
- V20 R2 base manifest SHA-256: `15c37a6cc5503127c63d6987b9de0fd71a48181fc33dff5a4e52f57a8fc5d129`
- Independently checked all 32 source payload entries against both the freeze and QA copy; all match. No `.pyc` files were present in either tree. QA imports resolved from the QA copy.
- The frozen source was not modified. One QA-only test was added at `tests/test_v21_handoff_adversarial_independent.py` (SHA-256 `7cabf2cb3e0c76239fcdf7e6436debec045e24409a4db38c4ca770bf2be2b4d`).

## Results

- Focused handoff/family-owner/adversarial tests: **10 passed**. Exact invocation and hashes are in `qa-v21-independent-review.json`; raw log and JUnit are retained beside it.
- Full execution package: **271 passed, 2 skipped**. Raw log and JUnit are retained beside the receipt.
- Ruff check and format check passed for the QA-only test.
- Synthetic database and sidecar hashes are recorded in `qa-v21-synthetic-db-hashes-receipt.json` (277 files). Source payload comparison is in `qa-v21-source-hash-verification.json`.

The adversarial checks cover lost handoff responses and exact idempotent receipt replay, altered proof rejection, stale-generation write denial, and atomic rollback/idempotent completion of poisoned `CLAIMED` work to `UNKNOWN`. The wrong-generation, wrong-lease/fence, foreign-family lease/session, target mismatch, and session-digest mismatch cases all fail closed.

## Limits

All execution used synthetic SQLite and local fake interfaces. No provider, credentials, native SDK, or network was used. This does not establish actual native `Join`/`Release` completion, callback drain, OS verifier isolation, or safe handoff after a process crash while native code is active. Treat this as offline V21 candidate evidence only, not real G5 acceptance.
