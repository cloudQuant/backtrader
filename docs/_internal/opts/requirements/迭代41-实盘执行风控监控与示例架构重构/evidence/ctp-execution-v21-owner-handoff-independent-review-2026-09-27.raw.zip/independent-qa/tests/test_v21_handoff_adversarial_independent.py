from __future__ import annotations

import hashlib
from dataclasses import replace

import pytest
import test_ctp_account_owner_handoff as handoff
import test_ctp_callback_session_router as router

from bt_api_execution import (
    ContractValidationError,
    CtpDispatchReceipt,
    DurableStoreError,
    ExecutionScope,
    InvalidStateTransition,
    SqliteExecutionStore,
    WriterLeaseUnavailable,
)


def test_lost_handoff_response_replays_receipt_and_old_generation_cannot_write(
    tmp_path,
) -> None:
    verifier = handoff._OfflineVerifier()
    store, scope, family, lease, callback_owner, binding = handoff._setup(
        tmp_path, verifier=verifier
    )
    target = handoff._scope("live", day="20260926")
    proof = handoff._proof(store, scope, target, family, callback_owner, binding)
    try:
        # Intentionally discard the return value to model commit-before-return
        # response loss. Recovery is only through the persisted receipt.
        handoff._handoff(store, scope, family, lease, callback_owner, proof, target)
        receipt = store.read_ctp_account_owner_handoff_receipt(proof.proof_id, target)
        assert receipt.from_generation == 1
        assert receipt.to_generation == 2
        assert verifier.calls == 1
        assert (
            handoff._handoff(store, scope, family, lease, callback_owner, proof, target) == receipt
        )
        assert verifier.calls == 1
        altered_proof = replace(proof, target_trading_day="20260927")
        with pytest.raises(ContractValidationError, match="already consumed"):
            handoff._handoff(store, scope, family, lease, callback_owner, altered_proof, target)
        assert verifier.calls == 1

        # The old generation cannot create a new owner, lease, reservation,
        # session or command after it has published the one successor.
        with pytest.raises(InvalidStateTransition):
            store.acquire_ctp_account_family_owner(scope)
        with pytest.raises((InvalidStateTransition, WriterLeaseUnavailable)):
            store.acquire_or_renew_lease(
                scope,
                lease.owner_id,
                ttl_ns=60_000_000_000,
                ctp_account_family_owner=family,
            )
        with pytest.raises((InvalidStateTransition, ContractValidationError)):
            store.reserve_ctp_order_identity(
                scope,
                "old-generation-intent",
                router._runtime_id("old-generation-order"),
            )
        with pytest.raises((InvalidStateTransition, WriterLeaseUnavailable)):
            store.create_ctp_callback_session_owner(scope, writer_lease=lease)
        with pytest.raises(InvalidStateTransition):
            store.read_ctp_dispatch_command(scope, "old-generation-command")

        generations = store._connection.execute(
            "SELECT generation, owner_state FROM ctp_account_family_owner_generations "
            "ORDER BY generation"
        ).fetchall()
        assert [tuple(row) for row in generations] == [(1, "CLOSED"), (2, "AVAILABLE")]
        assert (
            store._connection.execute("SELECT COUNT(*) FROM ctp_dispatch_commands").fetchone()[0]
            == 0
        )
        assert (
            store._connection.execute(
                "SELECT COUNT(*) FROM ctp_order_identity_reservations"
            ).fetchone()[0]
            == 0
        )
        assert (
            store._connection.execute(
                "SELECT COUNT(*) FROM ctp_dispatch_callback_session_owners"
            ).fetchone()[0]
            == 1
        )
    finally:
        store.close()

    # A fresh process-like Store can recover the exact receipt, but it cannot
    # replay the old owner proof or claim a successor without using that receipt.
    reopened = SqliteExecutionStore.open_ctp_account_store(tmp_path / "account.sqlite3", target)
    try:
        assert reopened.read_ctp_account_owner_handoff_receipt(proof.proof_id, target) == receipt
        assert (
            handoff._handoff(reopened, scope, family, lease, callback_owner, proof, target)
            == receipt
        )
        assert (
            reopened._connection.execute(
                "SELECT COUNT(*) FROM ctp_account_owner_handoff_receipts"
            ).fetchone()[0]
            == 1
        )
        successor = reopened.acquire_ctp_account_family_owner(target)
        assert successor.generation == 2
        next_lease = reopened.acquire_or_renew_lease(
            target,
            "independent-successor",
            ttl_ns=60_000_000_000,
            ctp_account_family_owner=successor,
        )
        successor_owner = reopened.create_ctp_callback_session_owner(
            target, writer_lease=next_lease
        )
        generation_owner_id = reopened._connection.execute(
            "SELECT callback_owner_intent_id FROM ctp_account_family_owner_generations "
            "WHERE generation = ?",
            (successor.generation,),
        ).fetchone()[0]
        assert successor_owner.owner_intent_id == generation_owner_id
        with pytest.raises(InvalidStateTransition):
            reopened.reserve_ctp_order_identity(
                scope,
                "stale-old-generation-intent",
                router._runtime_id("stale-old-generation-order"),
            )
        assert (
            reopened._connection.execute("SELECT COUNT(*) FROM ctp_dispatch_commands").fetchone()[0]
            == 0
        )
    finally:
        reopened.close()


def _claimed_submit_with_unknown_receipt(tmp_path):
    scope = router._scope()
    store = SqliteExecutionStore(tmp_path / "poisoned.sqlite3")
    lease = router._lease(store, scope)
    owner = router._active_owner(store, scope, lease)
    session = store._active_ctp_callback_sessions[owner.owner_intent_id]
    reservation = router._reserve(
        store, scope, lease, session.session_generation_id, "v21-poisoned-submit"
    )
    request = {
        "InstrumentID": "rb2710",
        "ExchangeID": "SHFE",
        "OrderRef": reservation.order_ref,
        "Direction": "0",
        "CombOffsetFlag": "0",
        "CombHedgeFlag": "1",
        "LimitPrice": 100.0,
        "VolumeTotalOriginal": 1,
        "OrderPriceType": "2",
        "TimeCondition": "3",
    }
    _, claim = router._queue_and_complete(
        store,
        scope,
        lease,
        owner,
        reservation,
        "v21-poisoned-command",
        request,
        941,
        complete=False,
    )
    command = claim.command
    receipt = CtpDispatchReceipt(
        receipt_type="ctp_dispatch_receipt.v2",
        command_id=command.command_id,
        account_key=command.account_key,
        scope_key=command.scope_key,
        trading_day=command.trading_day,
        operation=command.operation,
        request_payload_sha256=command.request_payload_sha256,
        reservation_managed_intent_id=command.reservation_managed_intent_id,
        order_ref=command.order_ref,
        cancel_target_order_ref=command.cancel_target_order_ref,
        cancel_target_exchange_id=command.cancel_target_exchange_id,
        cancel_target_order_sys_id=command.cancel_target_order_sys_id,
        cancel_target_front_id=command.cancel_target_front_id,
        cancel_target_session_id=command.cancel_target_session_id,
        approval_use_id=command.approval_use_id,
        approval_digest=command.approval_digest,
        session_binding_sha256=command.session_binding_sha256,
        outcome="UNKNOWN",
        native_receipt_payload={"request_id": 941, "dispatch_state": "ambiguous"},
        correlation_key=command.correlation_key,
        local_queue_receipt_id=command.local_queue_receipt_id,
    )
    return store, scope, lease, owner, command, receipt


def test_poisoned_claim_unknown_finalization_is_exact_atomic_and_never_reopens(
    tmp_path,
) -> None:
    store, scope, lease, owner, command, receipt = _claimed_submit_with_unknown_receipt(tmp_path)
    try:
        foreign_ref = (
            "ctp-account-ref.v1:" + hashlib.sha256(b"v21-independent-foreign-account").hexdigest()
        )
        foreign_scope = ExecutionScope(
            "ctp", "simulation", foreign_ref, "strategy.foreign", "20260925"
        )
        foreign_family = store.acquire_ctp_account_family_owner(foreign_scope)
        foreign_lease = store.acquire_or_renew_lease(
            foreign_scope,
            "foreign-account-writer",
            ttl_ns=60_000_000_000,
            ctp_account_family_owner=foreign_family,
        )
        foreign_callback_owner = router._active_owner(store, foreign_scope, foreign_lease)
        initial_reservation_count = store._connection.execute(
            "SELECT COUNT(*) FROM ctp_order_identity_reservations WHERE account_key = ?",
            (scope.account_key,),
        ).fetchone()[0]
        initial_command_count = store._connection.execute(
            "SELECT COUNT(*) FROM ctp_dispatch_commands WHERE account_key = ?",
            (scope.account_key,),
        ).fetchone()[0]

        poisoned = store.poison_ctp_callback_session_owner(owner, "owner_binding_mismatch")
        assert poisoned.durable_state == "POISONED"

        store._connection.execute(
            """CREATE TRIGGER abort_v21_unknown_finalizer
               BEFORE UPDATE OF status ON ctp_dispatch_commands
               WHEN OLD.command_id = 'v21-poisoned-command'
                 AND OLD.status = 'CLAIMED' AND NEW.status = 'UNKNOWN'
               BEGIN SELECT RAISE(ABORT, 'independent injected abort'); END"""
        )
        with pytest.raises(DurableStoreError, match="transaction failed"):
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, receipt, owner_handle=owner, writer_lease=lease
            )

        row = store._connection.execute(
            "SELECT status, native_call_inflight, native_request_id, completion_echo_sha256 "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (command.command_id,),
        ).fetchone()
        assert tuple(row) == ("CLAIMED", 1, 941, None)
        assert (
            store._connection.execute(
                "SELECT generation, owner_state FROM ctp_account_family_owner_generations"
            ).fetchall()[0]["owner_state"]
            == "POISONED"
        )

        # A different family generation, writer owner/token, callback session,
        # command target, or session binding cannot finalize this claim.
        bad_leases = (
            replace(lease, family_generation=lease.family_generation + 1),
            replace(lease, fencing_token=lease.fencing_token + 1),
            replace(lease, owner_id="other-poisoned-writer"),
            foreign_lease,
        )
        for bad_lease in bad_leases:
            with pytest.raises((ContractValidationError, WriterLeaseUnavailable)):
                store.complete_poisoned_ctp_dispatch_unknown_for_session(
                    scope, receipt, owner_handle=owner, writer_lease=bad_lease
                )

        with pytest.raises(ContractValidationError):
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, receipt, owner_handle=foreign_callback_owner, writer_lease=lease
            )

        bad_target_correlation = replace(receipt.correlation_key, order_ref="999999999999")
        bad_target_receipt = replace(
            receipt,
            order_ref="999999999999",
            correlation_key=bad_target_correlation,
        )
        with pytest.raises(ContractValidationError, match="receipt differs"):
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, bad_target_receipt, owner_handle=owner, writer_lease=lease
            )
        bad_session_sha = "0" * 64
        bad_session_correlation = replace(
            receipt.correlation_key, session_binding_sha256=bad_session_sha
        )
        bad_session_receipt = replace(
            receipt,
            session_binding_sha256=bad_session_sha,
            correlation_key=bad_session_correlation,
        )
        with pytest.raises(ContractValidationError):
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, bad_session_receipt, owner_handle=owner, writer_lease=lease
            )
        assert tuple(
            store._connection.execute(
                "SELECT status, native_call_inflight FROM ctp_dispatch_commands "
                "WHERE command_id = ?",
                (command.command_id,),
            ).fetchone()
        ) == ("CLAIMED", 1)

        store._connection.execute("DROP TRIGGER abort_v21_unknown_finalizer")
        finalized = store.complete_poisoned_ctp_dispatch_unknown_for_session(
            scope, receipt, owner_handle=owner, writer_lease=lease
        )
        assert finalized.status == "UNKNOWN"
        assert finalized.correlation_key.native_request_id == 941
        finalized_row = store._connection.execute(
            "SELECT status, native_call_inflight, native_request_id, completion_echo_sha256 "
            "FROM ctp_dispatch_commands WHERE command_id = ?",
            (command.command_id,),
        ).fetchone()
        assert finalized_row["status"] == "UNKNOWN"
        assert finalized_row["native_call_inflight"] == 0
        assert finalized_row["native_request_id"] == 941
        assert finalized_row["completion_echo_sha256"]
        assert (
            store.complete_poisoned_ctp_dispatch_unknown_for_session(
                scope, receipt, owner_handle=owner, writer_lease=lease
            )
            == finalized
        )

        with pytest.raises(InvalidStateTransition):
            store.acquire_ctp_account_family_owner(scope)
        with pytest.raises((InvalidStateTransition, WriterLeaseUnavailable)):
            store.acquire_or_renew_lease(
                scope,
                lease.owner_id,
                ttl_ns=60_000_000_000,
                ctp_account_family_owner=store._test_ctp_account_family_owner,
            )
        with pytest.raises((InvalidStateTransition, ContractValidationError)):
            store.reserve_ctp_order_identity(
                scope,
                "after-poison-intent",
                router._runtime_id("after-poison-order"),
            )
        assert (
            store._connection.execute(
                "SELECT COUNT(*) FROM ctp_account_family_owner_generations WHERE family_key = ?",
                (lease.family_key,),
            ).fetchone()[0]
            == 1
        )
        assert (
            store._connection.execute(
                "SELECT COUNT(*) FROM ctp_dispatch_callback_session_owners WHERE account_key = ?",
                (scope.account_key,),
            ).fetchone()[0]
            == 1
        )
        assert (
            store._connection.execute(
                "SELECT COUNT(*) FROM ctp_dispatch_commands WHERE account_key = ?",
                (scope.account_key,),
            ).fetchone()[0]
            == initial_command_count
            == 1
        )
        assert (
            store._connection.execute(
                "SELECT COUNT(*) FROM ctp_order_identity_reservations WHERE account_key = ?",
                (scope.account_key,),
            ).fetchone()[0]
            == initial_reservation_count
        )
        assert (
            store._connection.execute(
                "SELECT native_request_id FROM ctp_dispatch_commands WHERE command_id = ?",
                (command.command_id,),
            ).fetchone()[0]
            == 941
        )
    finally:
        store.close()

    reopened = SqliteExecutionStore(tmp_path / "poisoned.sqlite3")
    try:
        with pytest.raises(InvalidStateTransition):
            reopened.acquire_ctp_account_family_owner(scope)
        command_after_restart = reopened.read_ctp_dispatch_command(scope, command.command_id)
        assert command_after_restart is not None
        assert command_after_restart.status == "UNKNOWN"
        assert command_after_restart.correlation_key.native_request_id == 941
        assert (
            reopened._connection.execute(
                "SELECT COUNT(*) FROM ctp_account_family_owner_generations WHERE family_key = ?",
                (lease.family_key,),
            ).fetchone()[0]
            == 1
        )
        assert (
            reopened._connection.execute(
                "SELECT COUNT(*) FROM ctp_dispatch_commands WHERE account_key = ?",
                (scope.account_key,),
            ).fetchone()[0]
            == 1
        )
        assert (
            reopened._connection.execute(
                "SELECT COUNT(*) FROM ctp_order_identity_reservations WHERE account_key = ?",
                (scope.account_key,),
            ).fetchone()[0]
            == initial_reservation_count
        )
    finally:
        reopened.close()
