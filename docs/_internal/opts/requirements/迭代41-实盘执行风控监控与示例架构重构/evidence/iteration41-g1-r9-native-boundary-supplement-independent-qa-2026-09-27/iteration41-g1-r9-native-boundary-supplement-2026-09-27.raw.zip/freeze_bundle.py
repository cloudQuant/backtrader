from pathlib import Path
import hashlib, json, zipfile

root=Path(r'D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927')
archive=root/'iteration41-g1-r9-native-boundary-supplement-2026-09-27.raw.zip'
manifest_path=root/'bundle-manifest.json'
receipt_path=root/'bundle-receipt.json'
sums_path=root/'SHA256SUMS.txt'
sha=lambda data:hashlib.sha256(data).hexdigest()
paths=[root/'r9_native_boundary_supplement.cpp',root/'build-supplement.bat',root/'reproduce.ps1',root/'README.md',root/'r9-prior-qa-provenance-erratum.md',root/'build.log',root/'build-exit.txt',root/'frozen-input'/'r9_author_archive_receipt.json',root/'frozen-input'/'raw-zip-extraction-verification.json']
paths += sorted((root/'frozen-input'/'canonical-candidate').glob('*'))
paths += sorted((root/'run').glob('*'))
# Include this builder so the bundle can be independently regenerated.
paths += [root/'freeze_bundle.py']
paths=[p for p in paths if p.is_file()]
rel=lambda p:p.relative_to(root).as_posix()
if len({rel(p) for p in paths})!=len(paths): raise SystemExit('duplicate bundle paths')
payload=[]
for p in sorted(paths,key=rel):
    b=p.read_bytes();payload.append({'path':rel(p),'bytes':len(b),'sha256':sha(b)})
manifest={'schema':'iteration41_g1_r9_native_boundary_supplement_bundle.v1','payload_count':len(payload),'payloads':payload}
manifest_bytes=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
manifest_path.write_bytes(manifest_bytes)
receipt={
 'schema':'iteration41_g1_r9_native_boundary_supplement_receipt.v1',
 'classification':'INERT_LOCAL_WIN32_BOUNDARY_EVIDENCE_ONLY_G1_CLOSED',
 'bundle_manifest':'bundle-manifest.json','bundle_manifest_sha256':sha(manifest_bytes),
 'r9_author_zip_sha256':'2055fb8329a06d80abe8fc52ae2d2fec25674686300defe96192faf3a4e44f3a',
 'r9_author_index_sha256':'1957b0bdc47c26903de96eed6a8c08bb4d25613d56d495de2c3add2198852665',
 'r9_candidate_manifest_sha256':'98a8110a5c99e960d052c18d57c9aaedf3bd43fa61dc3271a8b7235a0280da81',
 'supplement_source_sha256':sha((root/'r9_native_boundary_supplement.cpp').read_bytes()),
 'final_executable_sha256':sha((root/'run'/'r9_native_boundary_supplement.exe').read_bytes()),
 'exploratory_failed_executable_sha256':sha((root/'run'/'r9_native_boundary_supplement-run01.exe').read_bytes()),
 'replays':[
  {'log':'run/native-boundary-run-01.log','exit_code':2,'disposition':'preserved assertion mismatch: actual post-death DuplicateHandle error 5, old assertion required 6'},
  {'log':'run/native-boundary-run-final.log','exit_code':0,'disposition':'all local helper probes passed'},
  {'log':'run/native-boundary-replay-02.log','exit_code':0,'disposition':'independent repeat passed; source unchanged; no helper process remained'}
 ],
 'limits':['No kernel CreateProcessW hang injected','No P14 correct-rights API failure/hang or CloseHandle failure injected','No SCM/startup-D/whole-command hard-deadline evidence','No provider, SDK, credentials, network, or production route']
}
receipt_bytes=(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
receipt_path.write_bytes(receipt_bytes)
sums=[]
for p in sorted(paths,key=rel): sums.append(f"{sha(p.read_bytes())}  {rel(p)}")
sums += [f"{sha(manifest_bytes)}  bundle-manifest.json",f"{sha(receipt_bytes)}  bundle-receipt.json"]
sums_path.write_text('\n'.join(sums)+'\n',encoding='ascii')
# Fixed timestamps make the archive deterministic for the same bundle inputs.
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in [(rel(p),p.read_bytes()) for p in sorted(paths,key=rel)]:
        zi=zipfile.ZipInfo(name,(2026,9,27,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        z.writestr(zi,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    for name,data in [('bundle-manifest.json',manifest_bytes),('bundle-receipt.json',receipt_bytes),('SHA256SUMS.txt',sums_path.read_bytes())]:
        zi=zipfile.ZipInfo(name,(2026,9,27,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o100644<<16
        z.writestr(zi,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive) as z:
    bad=z.testzip()
    if bad: raise SystemExit(f'zip test failed: {bad}')
    names=set(z.namelist());expected={x['path'] for x in payload}|{'bundle-manifest.json','bundle-receipt.json','SHA256SUMS.txt'}
    if names!=expected: raise SystemExit(f'zip member mismatch: extra={names-expected} missing={expected-names}')
    m=json.loads(z.read('bundle-manifest.json').decode('utf-8'))
    for item in m['payloads']:
        data=z.read(item['path'])
        if len(data)!=item['bytes'] or sha(data)!=item['sha256']: raise SystemExit(f'member integrity mismatch: {item["path"]}')
    if sha(z.read('bundle-receipt.json'))!=sha(receipt_bytes): raise SystemExit('receipt mismatch')
    if sha(z.read('SHA256SUMS.txt'))!=sha(sums_path.read_bytes()): raise SystemExit('sums mismatch')
check={
 'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
 'zip_testzip':'passed','member_count':len(names),'payload_count':len(payload),
 'manifest_sha256':sha(manifest_bytes),'receipt_sha256':sha(receipt_bytes),'sha256sums_sha256':sha(sums_path.read_bytes()),
 'all_payload_hashes_checked_from_archive':True,'archive_member_set_exact':True
}
(root/'archive-check.json').write_text(json.dumps(check,indent=2)+'\n',encoding='utf-8')
print(json.dumps(check,indent=2))
