@echo off
setlocal
set "TEMP=D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927\run\tmp"
set "TMP=D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927\run\tmp"
pushd "D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927\run"
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" > vs-bootstrap.log 2>&1
set "VCVARS_EXIT=%ERRORLEVEL%"
cl /nologo /std:c++17 /EHsc /O2 /W4 /Fe:D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927\run\r9_native_boundary_supplement.exe D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927\r9_native_boundary_supplement.cpp
set "CL_EXIT=%ERRORLEVEL%"
echo VCVARS_EXIT=%VCVARS_EXIT%
echo CL_EXIT=%CL_EXIT%
popd
exit /b %CL_EXIT%
