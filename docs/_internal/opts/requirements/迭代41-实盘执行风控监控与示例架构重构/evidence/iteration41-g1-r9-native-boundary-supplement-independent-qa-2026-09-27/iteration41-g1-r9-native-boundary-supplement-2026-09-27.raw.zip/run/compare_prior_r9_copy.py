from pathlib import Path
import hashlib, json, struct, zipfile

project = next(Path(r'D:\source_code\backtrader\docs\_internal\opts\requirements').glob('迭代41*'))
author = project / 'evidence' / 'iteration41-g1-r9-windows-inert-custodian-author-2026-09-27'
archive_path = author / 'r9_candidate_raw.zip'
index_path = author / 'r9_candidate_entries.json'
old = Path(r'D:\temp\iteration41-g1-r9-independent-qa-20260927\frozen-copy')
out_path = Path(r'D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927\run\prior-copy-comparison.json')
sha = lambda data: hashlib.sha256(data).hexdigest()
records=[]
with zipfile.ZipFile(archive_path) as z:
    test = z.testzip()
    index_raw=z.read('r9_candidate_entries.json')
    index=json.loads(index_raw.decode('utf-8'))
    indexed={entry['path']:entry for entry in index['entries']}
    members=set(z.namelist())
    if len(indexed)!=19 or len(members)!=20 or test is not None:
        raise SystemExit(f'canonical archive gate failed: index={len(indexed)} members={len(members)} test={test}')
    if members!={(x) for x in indexed}|{'r9_candidate_entries.json'}:
        raise SystemExit('zip member set differs from indexed payload plus embedded index')
    for name, entry in sorted(indexed.items()):
        raw=z.read(name); digest=sha(raw); f=old/name
        exists=f.exists(); prior=f.read_bytes() if exists else b''
        records.append({'path':name,'canonical_bytes':len(raw),'canonical_sha256':digest,
                        'index_matches':len(raw)==entry['bytes'] and digest==entry['sha256'],
                        'prior_copy_exists':exists,'prior_copy_bytes':len(prior) if exists else None,
                        'prior_copy_sha256':sha(prior) if exists else None,'byte_identical':exists and raw==prior})

# PE output comparison: report exact raw differences and normalize only those
# differing bytes, without pretending the full files are byte-identical.
with zipfile.ZipFile(archive_path) as z: canonical_exe=z.read('r9_custodian.exe')
rebuilt_exe=(old/'r9_custodian.exe').read_bytes()
if len(canonical_exe)!=len(rebuilt_exe): raise SystemExit('exe sizes differ')
exe_diff=[i for i,(a,b) in enumerate(zip(canonical_exe,rebuilt_exe)) if a!=b]
pe=struct.unpack_from('<I',canonical_exe,0x3c)[0]
pe2=struct.unpack_from('<I',rebuilt_exe,0x3c)[0]
if pe!=pe2: raise SystemExit('PE offsets differ')
tsa=struct.unpack_from('<I',canonical_exe,pe+8)[0]
tsb=struct.unpack_from('<I',rebuilt_exe,pe+8)[0]
norm_a=bytearray(canonical_exe); norm_b=bytearray(rebuilt_exe)
for off in exe_diff: norm_a[off]=0; norm_b[off]=0

def pe_sections(data, peoff):
    n=struct.unpack_from('<H',data,peoff+6)[0]
    opt=struct.unpack_from('<H',data,peoff+20)[0]
    table=peoff+24+opt
    result=[]
    for i in range(n):
        h=table+i*40; name=data[h:h+8].split(b'\0')[0].decode('ascii','replace')
        size,ptr=struct.unpack_from('<II',data,h+16)
        result.append({'name':name,'raw_bytes':size,'raw_offset':ptr,
                       'sha256':sha(data[ptr:ptr+size]) if ptr and size else None})
    return result
sections_a=pe_sections(canonical_exe,pe); sections_b=pe_sections(rebuilt_exe,pe2)
if [(s['name'],s['raw_bytes'],s['raw_offset']) for s in sections_a] != [(s['name'],s['raw_bytes'],s['raw_offset']) for s in sections_b]:
    raise SystemExit('PE section table differs')
section_comparison=[{'name':a['name'],'raw_bytes':a['raw_bytes'],'sha256_equal':a['sha256']==b['sha256'],
                    'author_sha256':a['sha256'],'rebuilt_sha256':b['sha256']} for a,b in zip(sections_a,sections_b)]

# COFF object: ignore sections with PointerToRawData=0 (uninitialized .bss).
with zipfile.ZipFile(archive_path) as z: canonical_obj=z.read('r9_custodian.obj')
rebuilt_obj=(old/'r9_custodian.obj').read_bytes()
coff_time_a=struct.unpack_from('<I',canonical_obj,4)[0]; coff_time_b=struct.unpack_from('<I',rebuilt_obj,4)[0]
n=struct.unpack_from('<H',canonical_obj,2)[0]
obj_sections=[]
for i in range(n):
    h=20+i*40; name=canonical_obj[h:h+8].split(b'\0')[0].decode('ascii','replace')
    size_a,ptr_a=struct.unpack_from('<II',canonical_obj,h+16)
    size_b,ptr_b=struct.unpack_from('<II',rebuilt_obj,h+16)
    if not ptr_a and not ptr_b:
        continue
    ba=canonical_obj[ptr_a:ptr_a+size_a]; bb=rebuilt_obj[ptr_b:ptr_b+size_b]
    obj_sections.append({'name':name,'bytes':size_a,'raw_data_equal':ba==bb})

build_author=(author/'frozen_candidate'/'r9_build.bat').read_text(encoding='utf-8',errors='replace').splitlines()
build_prior=(old/'r9_build.bat').read_text(encoding='utf-8',errors='replace').splitlines()
report={
 'canonical_archive_sha256':sha(archive_path.read_bytes()),'canonical_index_sha256':sha(index_raw),
 'canonical_zip_testzip':'passed','canonical_members':20,'canonical_indexed_payloads':len(indexed),
 'canonical_payloads_all_match_index':all(r['index_matches'] for r in records),
 'prior_copy_payloads_byte_identical_count':sum(r['byte_identical'] for r in records),
 'prior_copy_payloads_byte_different_count':sum(not r['byte_identical'] for r in records),
 'prior_copy_file_records':records,
 'build_recipe':{'author_lines':build_author,'prior_lines':build_prior,'byte_identical':(author/'frozen_candidate'/'r9_build.bat').read_bytes()==(old/'r9_build.bat').read_bytes(),
   'semantic_command_same':(len(build_author)==len(build_prior) and (build_author[:1]+build_author[3:])==(build_prior[:1]+build_prior[3:])),
   'difference':'TEMP/TMP root only; vcvars call and cl flags/input/output command lines match'},
 'exe':{'canonical_sha256':sha(canonical_exe),'rebuilt_sha256':sha(rebuilt_exe),'bytes':len(canonical_exe),
   'pe_timestamp_author_hex':hex(tsa),'pe_timestamp_rebuilt_hex':hex(tsb),'raw_differing_byte_offsets':exe_diff,
   'normalized_by_zeroing_only_differing_offsets_equal':bytes(norm_a)==bytes(norm_b),'sections':section_comparison,
   'text_section_hash_equal':next(a['sha256_equal'] for a in section_comparison if a['name']=='.text')},
 'obj':{'canonical_sha256':sha(canonical_obj),'rebuilt_sha256':sha(rebuilt_obj),'bytes':len(canonical_obj),
   'coff_timestamp_author_hex':hex(coff_time_a),'coff_timestamp_rebuilt_hex':hex(coff_time_b),
   'raw_initialized_section_count':len(obj_sections),'all_text_sections_equal':all(s['raw_data_equal'] for s in obj_sections if s['name'].startswith('.text')),
   'different_initialized_sections':sorted({s['name'] for s in obj_sections if not s['raw_data_equal']}),
   'different_initialized_section_instances':sum(not s['raw_data_equal'] for s in obj_sections)}
}
out_path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='prior_copy_file_records'},indent=2,ensure_ascii=False))
