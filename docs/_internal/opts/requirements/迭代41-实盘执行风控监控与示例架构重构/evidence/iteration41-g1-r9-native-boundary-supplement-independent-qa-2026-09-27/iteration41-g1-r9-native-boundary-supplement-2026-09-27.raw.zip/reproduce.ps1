param(
    [Parameter(Mandatory = $false)]
    [string]$RunTag = 'replay-02'
)
$ErrorActionPreference = 'Stop'
$root = 'D:\temp\iteration41-g1-r9-native-boundary-supplement-20260927'
$source = Join-Path $root 'r9_native_boundary_supplement.cpp'
$batch = Join-Path $root 'build-supplement.bat'
$run = Join-Path $root 'run'
$exe = Join-Path $run 'r9_native_boundary_supplement.exe'
$before = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$buildLog = Join-Path $run ("build-$RunTag.log")
$buildExitPath = Join-Path $run ("build-$RunTag.exit")
& $env:ComSpec /d /c ('"' + $batch + '"') *> $buildLog
$buildExit = $LASTEXITCODE
Set-Content -LiteralPath $buildExitPath -Value $buildExit -NoNewline
$afterBuild = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
if ($buildExit -ne 0) { throw "Build failed; see $buildLog" }
$out = Join-Path $run ("native-boundary-$RunTag.log")
$exitPath = Join-Path $run ("native-boundary-$RunTag.exit")
& $exe *> $out
$runExit = $LASTEXITCODE
Set-Content -LiteralPath $exitPath -Value $runExit -NoNewline
$afterRun = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$processes = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -eq $exe } | Select-Object Name,ProcessId,CommandLine)
$processPath = Join-Path $run ("process-check-$RunTag.json")
[ordered]@{
    run_tag = $RunTag
    source_sha256_before = $before
    source_sha256_after_build = $afterBuild
    source_sha256_after_run = $afterRun
    source_unchanged = ($before -eq $afterBuild -and $before -eq $afterRun)
    build_exit = $buildExit
    run_exit = $runExit
    final_exe_sha256 = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash
    remaining_helper_process_count = $processes.Count
    remaining_helper_processes = $processes
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $processPath -Encoding UTF8
Get-Content -LiteralPath $out
Write-Output "BUILD_EXIT=$buildExit RUN_EXIT=$runExit"
Write-Output "PROCESS_CHECK=$processPath"
if ($runExit -ne 0 -or $before -ne $afterRun -or $processes.Count -ne 0) { exit 1 }
