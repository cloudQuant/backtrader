#define _WIN32_WINNT 0x0A00
#define NOMINMAX
#include <windows.h>
#include <stdint.h>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct alignas(8) Shared {
    volatile LONG ready;
    volatile LONG stage;
    volatile LONG apiSuccess;
    volatile LONG apiError;
    volatile LONG childPid;
    volatile LONG64 requestStart;
    volatile LONG64 deadline;
    volatile LONG64 createStart;
    volatile LONG64 createReturn;
    volatile LONG brokerReady;
    volatile LONG brokerOpenError;
    volatile LONG writerSubmitted;
    volatile LONG writerPending;
    volatile LONG writerDone;
    volatile LONG writerError;
    volatile LONG64 writerSubmitTick;
    volatile LONG cancelIssued;
    volatile LONG cancelError;
    volatile LONG callerReady;
    volatile LONG callerQueryOk;
    volatile LONG callerQueryActive;
    volatile LONG64 callerRemoteOuterHandle;
};

static HANDLE H(uint64_t x) { return (HANDLE)(uintptr_t)x; }
static uint64_t HV(HANDLE h) { return (uint64_t)(uintptr_t)h; }
static HANDLE ParseH(const wchar_t* s) { return H(_wcstoui64(s, nullptr, 10)); }
static LONG G32(volatile LONG* p) { return InterlockedCompareExchange(p, 0, 0); }
static void S32(volatile LONG* p, LONG v) { InterlockedExchange(p, v); }
static LONG64 G64(volatile LONG64* p) { return InterlockedCompareExchange64(p, 0, 0); }
static void S64(volatile LONG64* p, LONG64 v) { InterlockedExchange64(p, v); }
static std::wstring ExePath() {
    std::vector<wchar_t> b(32768);
    DWORD n = GetModuleFileNameW(nullptr, b.data(), (DWORD)b.size());
    return n ? std::wstring(b.data(), n) : L"";
}
static std::wstring Q(const std::wstring& s) { return L"\"" + s + L"\""; }
static std::wstring HS(HANDLE h) { return std::to_wstring((unsigned long long)HV(h)); }
static void Close(HANDLE& h) { if (h && h != INVALID_HANDLE_VALUE) { CloseHandle(h); h = nullptr; } }
static HANDLE NewEvent(bool inherit = true, bool signaled = false) {
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, inherit ? TRUE : FALSE};
    return CreateEventW(&sa, TRUE, signaled ? TRUE : FALSE, nullptr);
}
static HANDLE NewMapping(Shared*& view) {
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    HANDLE h = CreateFileMappingW(INVALID_HANDLE_VALUE, &sa, PAGE_READWRITE, 0, sizeof(Shared), nullptr);
    if (!h) return nullptr;
    view = (Shared*)MapViewOfFile(h, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(Shared));
    if (!view) { Close(h); return nullptr; }
    ZeroMemory(view, sizeof(Shared));
    return h;
}
static HANDLE NewJob(bool inherit = false) {
    HANDLE h = CreateJobObjectW(nullptr, nullptr);
    if (!h) return nullptr;
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION x{};
    x.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (!SetInformationJobObject(h, JobObjectExtendedLimitInformation, &x, sizeof(x))) {
        Close(h); return nullptr;
    }
    if (inherit && !SetHandleInformation(h, HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT)) {
        Close(h); return nullptr;
    }
    return h;
}
static bool JobActive(HANDLE job, DWORD& active, DWORD& error) {
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION x{};
    if (!QueryInformationJobObject(job, JobObjectBasicAccountingInformation, &x, sizeof(x), nullptr)) {
        error = GetLastError(); return false;
    }
    active = x.ActiveProcesses; error = 0; return true;
}
static bool WaitJobEmpty(HANDLE job, DWORD timeoutMs, DWORD& last, DWORD& error) {
    ULONGLONG end = GetTickCount64() + timeoutMs;
    do {
        if (!JobActive(job, last, error)) return false;
        if (last == 0) return true;
        Sleep(2);
    } while (GetTickCount64() < end);
    error = WAIT_TIMEOUT; return false;
}
static bool Resume(PROCESS_INFORMATION& pi) { return ResumeThread(pi.hThread) != (DWORD)-1; }

static bool SpawnSuspended(const std::wstring& command,
                           const std::vector<HANDLE>& inherited,
                           const std::vector<HANDLE>& jobs,
                           PROCESS_INFORMATION& pi, DWORD& error) {
    STARTUPINFOEXW sx{};
    sx.StartupInfo.cb = sizeof(sx);
    DWORD attrCount = (DWORD)(!inherited.empty()) + (DWORD)(!jobs.empty());
    SIZE_T bytes = 0;
    InitializeProcThreadAttributeList(nullptr, attrCount, 0, &bytes);
    std::vector<unsigned char> storage(bytes);
    sx.lpAttributeList = (LPPROC_THREAD_ATTRIBUTE_LIST)storage.data();
    if (!InitializeProcThreadAttributeList(sx.lpAttributeList, attrCount, 0, &bytes)) {
        error = GetLastError(); return false;
    }
    bool ok = true;
    if (!inherited.empty()) {
        ok = UpdateProcThreadAttribute(sx.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST,
            (void*)inherited.data(), inherited.size() * sizeof(HANDLE), nullptr, nullptr) != FALSE;
    }
    if (ok && !jobs.empty()) {
        ok = UpdateProcThreadAttribute(sx.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_JOB_LIST,
            (void*)jobs.data(), jobs.size() * sizeof(HANDLE), nullptr, nullptr) != FALSE;
    }
    std::vector<wchar_t> mutableCommand(command.begin(), command.end());
    mutableCommand.push_back(L'\0');
    if (ok) {
        ok = CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, !inherited.empty(),
            CREATE_SUSPENDED | EXTENDED_STARTUPINFO_PRESENT, nullptr, nullptr, &sx.StartupInfo, &pi) != FALSE;
    }
    error = ok ? 0 : GetLastError();
    DeleteProcThreadAttributeList(sx.lpAttributeList);
    return ok;
}

static bool SpawnLeafSuspended(PROCESS_INFORMATION& pi, DWORD& error) {
    STARTUPINFOW si{}; si.cb = sizeof(si);
    std::wstring command = Q(ExePath()) + L" --leaf";
    std::vector<wchar_t> mutableCommand(command.begin(), command.end()); mutableCommand.push_back(L'\0');
    BOOL ok = CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, FALSE, CREATE_SUSPENDED,
        nullptr, nullptr, &si, &pi);
    error = ok ? 0 : GetLastError();
    return ok != FALSE;
}

static int NativeWorker(int argc, wchar_t** argv) {
    if (argc < 9) return 41;
    std::wstring mode = argv[2];
    HANDLE map = ParseH(argv[3]), go = ParseH(argv[4]), ready = ParseH(argv[5]);
    HANDLE entered = ParseH(argv[6]), returned = ParseH(argv[7]), job = ParseH(argv[8]);
    Shared* s = (Shared*)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(Shared));
    if (!s) return 42;
    S32(&s->ready, 1); SetEvent(ready);
    if (WaitForSingleObject(go, 5000) != WAIT_OBJECT_0) { UnmapViewOfFile(s); return 43; }
    S32(&s->stage, 1); SetEvent(entered);
    if (mode == L"before") {
        Sleep(10000);
        UnmapViewOfFile(s); return 0;
    }
    S64(&s->createStart, (LONG64)GetTickCount64());
    STARTUPINFOW si{}; si.cb = sizeof(si); PROCESS_INFORMATION child{};
    std::wstring command = Q(ExePath()) + L" --leaf";
    std::vector<wchar_t> mutableCommand(command.begin(), command.end()); mutableCommand.push_back(L'\0');
    BOOL created = CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, FALSE, CREATE_SUSPENDED,
        nullptr, nullptr, &si, &child);
    DWORD createError = created ? 0 : GetLastError();
    S64(&s->createReturn, (LONG64)GetTickCount64());
    S32(&s->apiSuccess, created ? 1 : 0); S32(&s->apiError, (LONG)createError);
    if (created) {
        S32(&s->childPid, (LONG)child.dwProcessId);
        DWORD active = 0, qerr = 0; JobActive(job, active, qerr);
        BOOL inJob = FALSE; IsProcessInJob(child.hProcess, job, &inJob);
        S32(&s->stage, inJob && active >= 2 ? 2 : 3);
        Close(child.hThread); Close(child.hProcess);
    } else {
        S32(&s->stage, 3);
    }
    SetEvent(returned);
    Sleep(10000);
    UnmapViewOfFile(s);
    return 0;
}

static int LeafMain() {
    Sleep(10000);
    return 0;
}

static std::vector<HANDLE> BasicHandles(std::initializer_list<HANDLE> values) {
    return std::vector<HANDLE>(values.begin(), values.end());
}

static bool RunNativeBoundary(const wchar_t* mode) {
    HANDLE job = NewJob(true); Shared* s = nullptr; HANDLE map = NewMapping(s);
    HANDLE go = NewEvent(), ready = NewEvent(), entered = NewEvent(), returned = NewEvent();
    if (!job || !map || !go || !ready || !entered || !returned) return false;
    PROCESS_INFORMATION worker{}; DWORD spawnError = 0;
    std::wstring cmd = Q(ExePath()) + L" --native-worker " + mode + L" " + HS(map) + L" " + HS(go) +
        L" " + HS(ready) + L" " + HS(entered) + L" " + HS(returned) + L" " + HS(job);
    auto inh = BasicHandles({map, go, ready, entered, returned, job});
    auto jobs = BasicHandles({job});
    bool spawned = SpawnSuspended(cmd, inh, jobs, worker, spawnError) && Resume(worker);
    DWORD readyWait = spawned ? WaitForSingleObject(ready, 3000) : WAIT_FAILED;
    if (!spawned || readyWait != WAIT_OBJECT_0) {
        if (job) TerminateJobObject(job, 0xE9F20001);
        DWORD active=0, err=0; if(job) WaitJobEmpty(job,3000,active,err);
        Close(worker.hThread); Close(worker.hProcess); UnmapViewOfFile(s); Close(map);
        Close(go); Close(ready); Close(entered); Close(returned); Close(job);
        std::cout << "{\"kind\":\"native-" << (mode[0]==L'b'?"before":"after") << "\",\"setup_ok\":false,\"spawn_error\":" << spawnError << "}\n";
        return false;
    }
    LONG64 start = (LONG64)GetTickCount64(), deadline = start + 1200;
    S64(&s->requestStart, start); S64(&s->deadline, deadline); SetEvent(go);
    DWORD enteredWait = WaitForSingleObject(entered, 3000);
    DWORD returnWait = WAIT_TIMEOUT;
    if (mode[0] != L'b' && enteredWait == WAIT_OBJECT_0) {
        ULONGLONG remaining = GetTickCount64() < (ULONGLONG)deadline ? (ULONGLONG)deadline - GetTickCount64() : 0;
        returnWait = WaitForSingleObject(returned, (DWORD)remaining);
    }
    while (GetTickCount64() < (ULONGLONG)deadline) Sleep(1);
    DWORD before = 999, beforeErr = 0; bool beforeOk = JobActive(job, before, beforeErr);
    DWORD pid = (DWORD)G32(&s->childPid);
    HANDLE child = pid ? OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid) : nullptr;
    BOOL term = TerminateJobObject(job, 0xE9F20002);
    DWORD termErr = term ? 0 : GetLastError();
    DWORD after = 999, afterErr = 0; bool empty = WaitJobEmpty(job, 2500, after, afterErr);
    DWORD workerWait = WaitForSingleObject(worker.hProcess, 2500);
    DWORD childWait = child ? WaitForSingleObject(child, 2500) : WAIT_OBJECT_0;
    LONG64 callStart = G64(&s->createStart), callReturn = G64(&s->createReturn);
    LONG apiSuccess = G32(&s->apiSuccess);
    LONG apiError = G32(&s->apiError);
    bool callByD = callReturn > 0 && callReturn <= deadline;
    std::cout << "{\"kind\":\"native-" << (mode[0]==L'b'?"before":"after")
        << "\",\"setup_ok\":true,\"worker_pid\":" << worker.dwProcessId
        << ",\"request_start_tick_ms\":" << start << ",\"deadline_tick_ms\":" << deadline
        << ",\"entered_wait\":" << enteredWait << ",\"returned_wait\":" << returnWait
        << ",\"create_start_tick_ms\":" << callStart << ",\"create_return_tick_ms\":" << callReturn
        << ",\"create_duration_ms\":" << (callReturn >= callStart ? callReturn-callStart : 0)
        << ",\"create_return_by_D\":" << (callByD?"true":"false")
        << ",\"create_success\":" << (apiSuccess?"true":"false")
        << ",\"create_error\":" << apiError << ",\"child_pid\":" << pid
        << ",\"job_active_before_kill\":" << before << ",\"job_query_ok_before\":" << (beforeOk?"true":"false")
        << ",\"terminate_returned\":" << (term?"true":"false") << ",\"terminate_error\":" << termErr
        << ",\"job_active_after\":" << after << ",\"job_empty\":" << (empty?"true":"false")
        << ",\"worker_wait_object_0\":" << (workerWait==WAIT_OBJECT_0?"true":"false")
        << ",\"child_wait_object_0\":" << (childWait==WAIT_OBJECT_0?"true":"false")
        << ",\"child_handle_opened\":" << (child?"true":"false") << ",\"job_query_error_after\":" << afterErr << "}\n";
    Close(child); Close(worker.hThread); Close(worker.hProcess);
    UnmapViewOfFile(s); Close(map); Close(go); Close(ready); Close(entered); Close(returned); Close(job);
    return term && empty && workerWait==WAIT_OBJECT_0 && childWait==WAIT_OBJECT_0 &&
        (mode[0]==L'b' ? (pid==0 && before==1) : (pid!=0 && before>=2 && apiSuccess));
}

static bool RunP14Rights() {
    HANDLE job=NewJob(false); PROCESS_INFORMATION leaf{}; DWORD createError=0;
    bool created=job && SpawnLeafSuspended(leaf,createError);
    bool assigned=created && AssignProcessToJobObject(job,leaf.hProcess);
    bool resumed=assigned && Resume(leaf);
    Sleep(30);
    DWORD activeBefore=999, qerr=0; bool queryOwnerBefore=job && JobActive(job,activeBefore,qerr);
    HANDLE queryOnly=nullptr, termOnly=nullptr;
    BOOL dupQ=job && DuplicateHandle(GetCurrentProcess(),job,GetCurrentProcess(),&queryOnly,JOB_OBJECT_QUERY,FALSE,0);
    BOOL dupT=job && DuplicateHandle(GetCurrentProcess(),job,GetCurrentProcess(),&termOnly,JOB_OBJECT_TERMINATE,FALSE,0);
    SetLastError(0); BOOL termLimited=dupQ ? TerminateJobObject(queryOnly,0xE9F20003) : FALSE;
    DWORD termLimitedError=termLimited?0:GetLastError();
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION qi{}; SetLastError(0);
    BOOL queryLimited=dupT ? QueryInformationJobObject(termOnly,JobObjectBasicAccountingInformation,&qi,sizeof(qi),nullptr) : FALSE;
    DWORD queryLimitedError=queryLimited?0:GetLastError();
    DWORD activeAfterDenied=999, ownerErr=0; bool queryAfterDenied=job && JobActive(job,activeAfterDenied,ownerErr);
    BOOL ownerTerm=job ? TerminateJobObject(job,0xE9F20004) : FALSE;
    DWORD ownerTermErr=ownerTerm?0:GetLastError();
    DWORD wait=leaf.hProcess?WaitForSingleObject(leaf.hProcess,2500):WAIT_FAILED;
    DWORD activeAfter=999, afterErr=0; bool empty=job && WaitJobEmpty(job,2500,activeAfter,afterErr);
    std::cout << "{\"kind\":\"p14-rights-negative\",\"setup_created\":" << (created?"true":"false")
        << ",\"assign_ok\":" << (assigned?"true":"false") << ",\"resume_ok\":" << (resumed?"true":"false")
        << ",\"job_active_before\":" << activeBefore << ",\"owner_query_before_ok\":" << (queryOwnerBefore?"true":"false")
        << ",\"terminate_query_only_returned\":" << (termLimited?"true":"false") << ",\"terminate_query_only_error\":" << termLimitedError
        << ",\"query_terminate_only_returned\":" << (queryLimited?"true":"false") << ",\"query_terminate_only_error\":" << queryLimitedError
        << ",\"job_active_after_denied_calls\":" << activeAfterDenied << ",\"owner_query_after_denied_ok\":" << (queryAfterDenied?"true":"false")
        << ",\"owner_terminate_returned\":" << (ownerTerm?"true":"false") << ",\"owner_terminate_error\":" << ownerTermErr
        << ",\"job_active_after_owner_terminate\":" << activeAfter << ",\"job_empty\":" << (empty?"true":"false")
        << ",\"leaf_wait_object_0\":" << (wait==WAIT_OBJECT_0?"true":"false") << "}\n";
    Close(queryOnly); Close(termOnly); Close(leaf.hThread); Close(leaf.hProcess); Close(job);
    return created && assigned && resumed && queryOwnerBefore && activeBefore==1 &&
        !termLimited && termLimitedError==ERROR_ACCESS_DENIED &&
        !queryLimited && queryLimitedError==ERROR_ACCESS_DENIED &&
        queryAfterDenied && activeAfterDenied==1 && ownerTerm && empty && activeAfter==0 && wait==WAIT_OBJECT_0;
}

static int IoBrokerMain(int argc,wchar_t** argv) {
    if(argc<9)return 51;
    HANDLE map=ParseH(argv[2]),ready=ParseH(argv[3]),begin=ParseH(argv[4]),submitted=ParseH(argv[5]);
    HANDLE cancel=ParseH(argv[6]),done=ParseH(argv[7]); std::wstring pipeName=argv[8];
    Shared* s=(Shared*)MapViewOfFile(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared));
    if(!s)return 52;
    HANDLE pipe=CreateFileW(pipeName.c_str(),GENERIC_WRITE,0,nullptr,OPEN_EXISTING,FILE_FLAG_OVERLAPPED,nullptr);
    DWORD openErr=pipe==INVALID_HANDLE_VALUE?GetLastError():0;
    S32(&s->brokerOpenError,(LONG)openErr); S32(&s->brokerReady,1); SetEvent(ready);
    if(pipe==INVALID_HANDLE_VALUE){UnmapViewOfFile(s);return 53;}
    if(WaitForSingleObject(begin,5000)!=WAIT_OBJECT_0){Close(pipe);UnmapViewOfFile(s);return 54;}
    std::vector<char> buffer(2*1024*1024,'R');
    HANDLE ovEvent=NewEvent(false,false); OVERLAPPED ov{}; ov.hEvent=ovEvent;
    DWORD written=0; BOOL ok=WriteFile(pipe,buffer.data(),(DWORD)buffer.size(),&written,&ov);
    DWORD writeErr=ok?0:GetLastError(); S32(&s->writerError,(LONG)writeErr);
    if(!ok && writeErr==ERROR_IO_PENDING) S32(&s->writerPending,1);
    S64(&s->writerSubmitTick,(LONG64)GetTickCount64());
    S32(&s->writerSubmitted,1); SetEvent(submitted);
    if(!ok && writeErr==ERROR_IO_PENDING) {
        HANDLE waits[2]={cancel,ovEvent};
        DWORD which=WaitForMultipleObjects(2,waits,FALSE,8000);
        if(which==WAIT_OBJECT_0) {
            BOOL canceled=CancelIoEx(pipe,&ov); DWORD cancelErr=canceled?0:GetLastError();
            S32(&s->cancelIssued,canceled?1:0); S32(&s->cancelError,(LONG)cancelErr);
            WaitForSingleObject(ovEvent,2500);
        }
        DWORD finalBytes=0; BOOL finalOk=GetOverlappedResult(pipe,&ov,&finalBytes,FALSE);
        DWORD finalErr=finalOk?0:GetLastError(); S32(&s->writerError,(LONG)finalErr);
    }
    S32(&s->writerPending,0); S32(&s->writerDone,1); SetEvent(done);
    Close(ovEvent); Close(pipe); UnmapViewOfFile(s); return 0;
}
static int IoCallerMain(int argc,wchar_t** argv) {
    if(argc<5)return 61;
    HANDLE map=ParseH(argv[2]),ready=ParseH(argv[3]),outerQuery=ParseH(argv[4]);
    Shared* s=(Shared*)MapViewOfFile(map,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared));
    if(!s)return 62;
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION info{}; BOOL q=QueryInformationJobObject(outerQuery,JobObjectBasicAccountingInformation,&info,sizeof(info),nullptr);
    S32(&s->callerQueryOk,q?1:0); S32(&s->callerQueryActive,q?(LONG)info.ActiveProcesses:-1);
    S64(&s->callerRemoteOuterHandle,(LONG64)HV(outerQuery)); S32(&s->callerReady,1); SetEvent(ready);
    Sleep(10000);
    UnmapViewOfFile(s); return 0;
}
static bool ConnectPipeOverlapped(HANDLE server,DWORD& error) {
    HANDLE e=NewEvent(false,false); OVERLAPPED ov{}; ov.hEvent=e;
    BOOL ok=ConnectNamedPipe(server,&ov); DWORD last=ok?0:GetLastError();
    if(!ok && last==ERROR_PIPE_CONNECTED){Close(e);error=0;return true;}
    if(!ok && last!=ERROR_IO_PENDING){Close(e);error=last;return false;}
    DWORD wait=WaitForSingleObject(e,3000);
    if(wait!=WAIT_OBJECT_0){CancelIoEx(server,&ov);WaitForSingleObject(e,1000);Close(e);error=WAIT_TIMEOUT;return false;}
    DWORD bytes=0; BOOL got=GetOverlappedResult(server,&ov,&bytes,FALSE); error=got?0:GetLastError(); Close(e); return got!=FALSE;
}
static bool RunCallerDeathOwnership() {
    HANDLE outer=NewJob(false), callerJob=NewJob(false);
    Shared* s=nullptr; HANDLE map=NewMapping(s);
    HANDLE bReady=NewEvent(), begin=NewEvent(), submitted=NewEvent(), cancel=NewEvent(), done=NewEvent(), cReady=NewEvent();
    std::wstring pipeName=L"\\\\.\\pipe\\r9-native-supplement-"+std::to_wstring(GetCurrentProcessId())+L"-"+std::to_wstring(GetTickCount64());
    SECURITY_ATTRIBUTES sa{sizeof(sa),nullptr,FALSE};
    HANDLE server=CreateNamedPipeW(pipeName.c_str(),PIPE_ACCESS_INBOUND|FILE_FLAG_OVERLAPPED,
        PIPE_TYPE_BYTE|PIPE_WAIT,1,4096,4096,0,&sa);
    if(!outer||!callerJob||!map||!server||!bReady||!begin||!submitted||!cancel||!done||!cReady)return false;
    PROCESS_INFORMATION broker{}; DWORD brokerErr=0;
    std::wstring brokerCmd=Q(ExePath())+L" --io-broker "+HS(map)+L" "+HS(bReady)+L" "+HS(begin)+L" "+HS(submitted)+L" "+HS(cancel)+L" "+HS(done)+L" "+Q(pipeName);
    auto brokerHandles=BasicHandles({map,bReady,begin,submitted,cancel,done});
    bool brokerSpawned=SpawnSuspended(brokerCmd,brokerHandles,BasicHandles({outer}),broker,brokerErr)&&Resume(broker);
    DWORD connectErr=0; bool connected=brokerSpawned&&ConnectPipeOverlapped(server,connectErr);
    DWORD br=connected?WaitForSingleObject(bReady,2000):WAIT_FAILED;
    HANDLE outerQuery=nullptr;
    BOOL qDup=DuplicateHandle(GetCurrentProcess(),outer,GetCurrentProcess(),&outerQuery,JOB_OBJECT_QUERY,TRUE,0);
    if(!qDup||br!=WAIT_OBJECT_0||G32(&s->brokerOpenError)!=0) {
        if(outer)TerminateJobObject(outer,0xE9F20005);
        DWORD a=0,e=0;if(outer)WaitJobEmpty(outer,3000,a,e);
        Close(outerQuery);Close(broker.hThread);Close(broker.hProcess);Close(server);
        UnmapViewOfFile(s);Close(map);Close(bReady);Close(begin);Close(submitted);Close(cancel);Close(done);Close(cReady);Close(callerJob);Close(outer);
        std::cout<<"{\"kind\":\"caller-death-pending-io\",\"setup_ok\":false,\"broker_spawn_error\":"<<brokerErr<<",\"pipe_connect_error\":"<<connectErr<<"}\n";
        return false;
    }
    uint64_t remoteValue=HV(outerQuery);
    PROCESS_INFORMATION caller{}; DWORD callerErr=0;
    std::wstring callerCmd=Q(ExePath())+L" --io-caller "+HS(map)+L" "+HS(cReady)+L" "+HS(outerQuery);
    auto callerHandles=BasicHandles({map,cReady,outerQuery});
    bool callerSpawned=SpawnSuspended(callerCmd,callerHandles,BasicHandles({outer}),caller,callerErr);
    BOOL innerAssigned=callerSpawned?AssignProcessToJobObject(callerJob,caller.hProcess):FALSE;
    DWORD assignErr=innerAssigned?0:GetLastError();
    bool callerResumed=innerAssigned&&Resume(caller);
    Close(outerQuery); outerQuery=nullptr;
    DWORD callerReadyWait=callerResumed?WaitForSingleObject(cReady,3000):WAIT_FAILED;
    if(!callerResumed||callerReadyWait!=WAIT_OBJECT_0) {
        if(outer)TerminateJobObject(outer,0xE9F20006);
        DWORD a=0,e=0;if(outer)WaitJobEmpty(outer,3000,a,e);
        Close(caller.hThread);Close(caller.hProcess);Close(broker.hThread);Close(broker.hProcess);Close(server);
        UnmapViewOfFile(s);Close(map);Close(bReady);Close(begin);Close(submitted);Close(cancel);Close(done);Close(cReady);Close(callerJob);Close(outer);
        std::cout<<"{\"kind\":\"caller-death-pending-io\",\"setup_ok\":false,\"caller_spawn_error\":"<<callerErr<<",\"inner_assign_error\":"<<assignErr<<"}\n";
        return false;
    }
    ULONGLONG requestStart=GetTickCount64(), deadline=requestStart+1200;
    S64(&s->requestStart,(LONG64)requestStart); S64(&s->deadline,(LONG64)deadline);
    SetEvent(begin);
    DWORD subWait=WaitForSingleObject(submitted,4000);
    while(GetTickCount64()<deadline)Sleep(1);
    DWORD outerBefore=999,outerErr=0,callerBefore=999,callerErrQ=0;
    bool outerQBefore=JobActive(outer,outerBefore,outerErr), callerQBefore=JobActive(callerJob,callerBefore,callerErrQ);
    LONG pendingBefore=G32(&s->writerPending);
    HANDLE aliveRemoteCopy=nullptr; SetLastError(0);
    BOOL aliveRemoteDup=DuplicateHandle(caller.hProcess,H(remoteValue),GetCurrentProcess(),&aliveRemoteCopy,JOB_OBJECT_QUERY,FALSE,0);
    DWORD aliveRemoteDupErr=aliveRemoteDup?0:GetLastError();
    DWORD aliveRemoteActive=999,aliveRemoteErr=0;
    bool aliveRemoteQuery=aliveRemoteDup&&JobActive(aliveRemoteCopy,aliveRemoteActive,aliveRemoteErr);
    Close(aliveRemoteCopy);
    ULONGLONG callerKillTick=GetTickCount64();
    BOOL callerTerm=TerminateJobObject(callerJob,0xE9F20007); DWORD callerTermErr=callerTerm?0:GetLastError();
    DWORD callerWait=WaitForSingleObject(caller.hProcess,2500);
    DWORD callerAfter=999,callerAfterErr=0;bool callerEmpty=WaitJobEmpty(callerJob,2000,callerAfter,callerAfterErr);
    HANDLE remoteCopy=nullptr; SetLastError(0);
    BOOL remoteDup=DuplicateHandle(caller.hProcess,H(remoteValue),GetCurrentProcess(),&remoteCopy,JOB_OBJECT_QUERY,FALSE,0);
    DWORD remoteDupErr=remoteDup?0:GetLastError();if(remoteDup)Close(remoteCopy);
    DWORD outerAfterDeath=999,outerAfterDeathErr=0;bool outerQAfterDeath=JobActive(outer,outerAfterDeath,outerAfterDeathErr);
    LONG pendingAfterDeath=G32(&s->writerPending);
    SetEvent(cancel);
    DWORD doneWait=WaitForSingleObject(done,4000);
    DWORD brokerWait=WaitForSingleObject(broker.hProcess,4000);
    DWORD outerFinal=999,outerFinalErr=0;bool outerEmpty=WaitJobEmpty(outer,2500,outerFinal,outerFinalErr);
    LONG writerError=G32(&s->writerError),cancelIssued=G32(&s->cancelIssued),cancelError=G32(&s->cancelError);
    if(!outerEmpty)TerminateJobObject(outer,0xE9F20008);
    std::cout<<"{\"kind\":\"caller-death-pending-io\",\"setup_ok\":true,\"request_start_tick_ms\":"<<requestStart
        <<",\"deadline_tick_ms\":"<<deadline<<",\"broker_pid\":"<<broker.dwProcessId<<",\"caller_pid\":"<<caller.dwProcessId
        <<",\"caller_query_handle_value\":"<<remoteValue<<",\"caller_query_before_death\":"<<(G32(&s->callerQueryOk)?"true":"false")
        <<",\"caller_job_query_active_before_death\":"<<G32(&s->callerQueryActive)
        <<",\"writer_submit_wait\":"<<subWait<<",\"writer_submit_tick_ms\":"<<G64(&s->writerSubmitTick)
        <<",\"writer_pending_before_caller_kill\":"<<(pendingBefore?"true":"false")
        <<",\"outer_active_before_caller_kill\":"<<outerBefore<<",\"caller_job_active_before_kill\":"<<callerBefore
        <<",\"outer_job_query_ok_before_caller_kill\":"<<(outerQBefore?"true":"false")
        <<",\"caller_job_query_ok_before_kill\":"<<(callerQBefore?"true":"false")
        <<",\"duplicate_remote_outer_handle_before_death_succeeded\":"<<(aliveRemoteDup?"true":"false")
        <<",\"duplicate_remote_outer_handle_before_death_error\":"<<aliveRemoteDupErr
        <<",\"duplicate_handle_query_before_death_ok\":"<<(aliveRemoteQuery?"true":"false")
        <<",\"duplicate_handle_active_before_death\":"<<aliveRemoteActive
        <<",\"caller_kill_tick_ms\":"<<callerKillTick<<",\"caller_kill_at_or_after_D\":"<<(callerKillTick>=deadline?"true":"false")
        <<",\"caller_terminate_returned\":"<<(callerTerm?"true":"false")<<",\"caller_terminate_error\":"<<callerTermErr
        <<",\"caller_process_signaled\":"<<(callerWait==WAIT_OBJECT_0?"true":"false")
        <<",\"caller_job_empty_after_death\":"<<(callerEmpty?"true":"false")<<",\"caller_job_active_after_death\":"<<callerAfter
        <<",\"duplicate_remote_outer_handle_after_death_succeeded\":"<<(remoteDup?"true":"false")
        <<",\"duplicate_remote_outer_handle_after_death_error\":"<<remoteDupErr
        <<",\"remote_handle_unavailable_after_death\":"<<(!remoteDup?"true":"false")
        <<",\"keeper_outer_query_after_caller_death_ok\":"<<(outerQAfterDeath?"true":"false")
        <<",\"keeper_outer_active_after_caller_death\":"<<outerAfterDeath
        <<",\"writer_pending_after_caller_death\":"<<(pendingAfterDeath?"true":"false")
        <<",\"cancel_done_wait\":"<<doneWait<<",\"broker_process_signaled\":"<<(brokerWait==WAIT_OBJECT_0?"true":"false")
        <<",\"cancel_issued\":"<<(cancelIssued?"true":"false")<<",\"cancel_error\":"<<cancelError
        <<",\"final_writer_error\":"<<writerError<<",\"outer_job_empty_after_broker_exit\":"<<(outerEmpty?"true":"false")
        <<",\"outer_active_final\":"<<outerFinal<<",\"outer_query_error_final\":"<<outerFinalErr<<"}\n";
    Close(caller.hThread);Close(caller.hProcess);Close(broker.hThread);Close(broker.hProcess);Close(server);
    UnmapViewOfFile(s);Close(map);Close(bReady);Close(begin);Close(submitted);Close(cancel);Close(done);Close(cReady);Close(callerJob);Close(outer);
    return subWait==WAIT_OBJECT_0&&pendingBefore&&outerQBefore&&callerQBefore&&outerBefore==2&&callerBefore==1&&
        aliveRemoteDup&&aliveRemoteQuery&&aliveRemoteActive==2&&callerTerm&&callerWait==WAIT_OBJECT_0&&callerEmpty&&callerAfter==0&&
        !remoteDup&&outerQAfterDeath&&outerAfterDeath==1&&pendingAfterDeath&&doneWait==WAIT_OBJECT_0&&
        brokerWait==WAIT_OBJECT_0&&cancelIssued&&writerError==ERROR_OPERATION_ABORTED&&outerEmpty&&outerFinal==0;
}

int wmain(int argc,wchar_t**argv) {
    if(argc>1&&std::wstring(argv[1])==L"--leaf")return LeafMain();
    if(argc>1&&std::wstring(argv[1])==L"--native-worker")return NativeWorker(argc,argv);
    if(argc>1&&std::wstring(argv[1])==L"--io-broker")return IoBrokerMain(argc,argv);
    if(argc>1&&std::wstring(argv[1])==L"--io-caller")return IoCallerMain(argc,argv);
    bool nativeBefore=RunNativeBoundary(L"before");
    bool nativeAfter=RunNativeBoundary(L"after");
    bool p14=RunP14Rights();
    bool io=RunCallerDeathOwnership();
    std::cout<<"{\"kind\":\"summary\",\"native_before_control_ok\":"<<(nativeBefore?"true":"false")
        <<",\"native_after_createprocess_ok\":"<<(nativeAfter?"true":"false")
        <<",\"p14_access_denied_and_job_empty_ok\":"<<(p14?"true":"false")
        <<",\"caller_death_and_job_handle_ownership_ok\":"<<(io?"true":"false")
        <<",\"kernel_createprocess_hang_injected\":false,\"p14_kernel_stall_injected\":false}\n";
    return nativeBefore&&nativeAfter&&p14&&io?0:10;
}
