"""Sourcefake checks for the Root-only preparation call gate.

These tests compile only the pinned public V3/V4 modules. They do not create a
source scope, run V4/R29 proof, or read/fabricate profiler cache bytes.
"""

from __future__ import annotations

import hashlib
import importlib.machinery
from pathlib import Path
import sys
import types

import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]
CALL_PATH = REPO_ROOT / "scripts/iteration41_optional16_r33_root_preparation_call_r1.py"
V3_PATH = REPO_ROOT / "scripts/iteration41_root_held_source_scope_v3.py"
V4_PATH = REPO_ROOT / "scripts/iteration41_root_held_source_scope_v4.py"
V3_SHA256 = "f3270495d3ddb046f8617d689510d4ae6ee700d639e0db769c518a15099a7677"
V4_SHA256 = "138c86e21de773822eceac07034e113e0adb5ea5d9056fcc16cee10a75c0e830"


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _read_public(path: Path) -> bytes:
    raw = path.read_bytes()
    assert type(raw) is bytes and raw
    return raw


def _load_module(name: str, path: Path, raw: bytes, digest: str) -> types.ModuleType:
    module = types.ModuleType(name)
    module.__file__ = str(path)
    module.__package__ = ""
    module.__loader__ = None
    module.__cached__ = None
    module.__spec__ = importlib.machinery.ModuleSpec(name, loader=None, origin=str(path))
    module.__verified_source_sha256__ = digest
    exec(compile(raw, str(path), "exec", dont_inherit=True), module.__dict__, module.__dict__)
    return module


def _source_modules(call):
    v3_raw = _read_public(V3_PATH)
    v4_raw = _read_public(V4_PATH)
    assert _sha(v3_raw) == V3_SHA256
    assert _sha(v4_raw) == V4_SHA256
    v3 = _load_module(call.V3_MODULE_NAME, V3_PATH, v3_raw, V3_SHA256)
    v4 = call._v4_reference(v3, v4_raw)
    return v3_raw, v4_raw, v3, v4


def _load_call():
    raw = _read_public(CALL_PATH)
    module = _load_module(
        "iteration41_optional16_r33_root_preparation_call_test",
        CALL_PATH,
        raw,
        _sha(raw),
    )
    return module


def test_v4_module_and_nested_v3_bind_to_held_source_without_sys_modules_authority():
    call = _load_call()
    v3_raw, v4_raw, v3, v4 = _source_modules(call)

    before = sys.modules.get(call.V3_MODULE_NAME)
    try:
        reference_v3, reference_v4 = call.bind_v4_module_to_held_source(
            v4, {"v3": v3_raw, "v4": v4_raw}
        )
    finally:
        assert sys.modules.get(call.V3_MODULE_NAME) is before

    assert v4._V3_MODULE is v3
    assert v4.RootHeldScopeV4.__bases__ == (v3.RootHeldScopeV3,)
    assert reference_v3 is not v3
    assert reference_v4 is not v4
    assert reference_v3.__name__ == call.V3_MODULE_NAME
    assert reference_v4.__name__ == call.V4_MODULE_NAME
    assert call.V3_MODULE_NAME not in sys.modules or sys.modules[call.V3_MODULE_NAME] is before


def test_v3_retained_scope_must_be_the_exact_caller_object():
    call = _load_call()
    v3_raw, v4_raw, v3, v4 = _source_modules(call)
    held_scope_token = object()
    v3._RETAINED_SCOPES.append(held_scope_token)
    try:
        reference_v3, _reference_v4 = call.bind_v4_module_to_held_source(
            v4, {"v3": v3_raw, "v4": v4_raw}, scope=held_scope_token
        )
        assert reference_v3._RETAINED_SCOPES == [held_scope_token]
        assert reference_v3._RETAINED_SCOPES[0] is held_scope_token
        with pytest.raises(
            call.RootPreparationCallError,
            match="v3_retained_scope_identity_mismatch",
        ):
            call.bind_v4_module_to_held_source(v4, {"v3": v3_raw, "v4": v4_raw}, scope=object())
    finally:
        v3._RETAINED_SCOPES.clear()


def test_v4_method_code_mutation_is_rejected():
    call = _load_call()
    v3_raw, v4_raw, _v3, v4 = _source_modules(call)
    original = v4.RootHeldScopeV4.verify_profiler_module_cache

    def substituted(*_args, **_kwargs):
        return {"source_code_graph_equal": True}

    v4.RootHeldScopeV4.verify_profiler_module_cache = substituted
    try:
        with pytest.raises(call.RootPreparationCallError, match="module_function_source_or_global_mismatch"):
            call.bind_v4_module_to_held_source(v4, {"v3": v3_raw, "v4": v4_raw})
    finally:
        v4.RootHeldScopeV4.verify_profiler_module_cache = original


def test_v4_pinned_profiler_global_mutation_is_rejected():
    call = _load_call()
    v3_raw, v4_raw, _v3, v4 = _source_modules(call)
    original = dict(v4.PROFILER_CACHE_PINS)
    first_key = next(iter(v4.PROFILER_CACHE_PINS))
    v4.PROFILER_CACHE_PINS[first_key] = "0" * 64
    try:
        with pytest.raises(call.RootPreparationCallError, match="module_global_value_mismatch"):
            call.bind_v4_module_to_held_source(v4, {"v3": v3_raw, "v4": v4_raw})
    finally:
        v4.PROFILER_CACHE_PINS.clear()
        v4.PROFILER_CACHE_PINS.update(original)


def test_v4_held_source_pin_mismatch_is_rejected_before_module_use():
    call = _load_call()
    v3_raw, v4_raw, _v3, v4 = _source_modules(call)
    changed = bytearray(v4_raw)
    changed[-1] ^= 1
    with pytest.raises(call.RootPreparationCallError, match="v4_held_source_invalid"):
        call.bind_v4_module_to_held_source(v4, {"v3": v3_raw, "v4": bytes(changed)})


def test_fixed_runtime_descriptors_are_explicit_and_cache_bytes_stay_unread():
    call = _load_call()
    v3_raw, v4_raw, _v3, v4 = _source_modules(call)
    call.bind_v4_module_to_held_source(v4, {"v3": v3_raw, "v4": v4_raw})

    assert v4.PROFILER_SOURCE_PINS == {
        "cProfile": (
            "C:/anaconda3/Lib/cProfile.py",
            "0a97cf92d0e3efd2e08c2f9b0f0fb8e52a2b26978550804d8e59435201f3fa84",
        ),
        "profile": (
            "C:/anaconda3/Lib/profile.py",
            "4d87bdc8b85bf0a9bdee3e9d975a8a1a0c7360cb264fb68c4c48a102e718e3a3",
        ),
        "pstats": (
            "C:/anaconda3/Lib/pstats.py",
            "d62d1e6a626ebd92187419bfe075a76997cce26fe99dd4520786d4a82b6ff10c",
        ),
    }
    assert v4.PROFILER_CACHE_PINS == {
        "C:/anaconda3/Lib/__pycache__/cProfile.cpython-311.pyc":
            "9d9a26a0e0aefd28a28dcd09bf97fd66072f8d537d18431f609485e16fb206b3",
        "C:/anaconda3/Lib/__pycache__/profile.cpython-311.pyc":
            "97408337b11e2c3b44bfb68c6e1f5e84de2536d4185049fec7038ecefc22a346",
        "C:/anaconda3/Lib/__pycache__/pstats.cpython-311.pyc":
            "8e66b028e50b31e7fbc7de63fcfe77025304aeb63b84e085ce13db784dca77ad",
    }
    assert call._path_key(v4.R2_MODULE_REL) == call._path_key(
        r"D:\temp\iteration41-optional16-r32-root-held-invoke-r3.py"
    )
    assert v4.R2_MODULE_SHA256 == "c93a20753db03df0710b86262b3e4a95d9a49ac5c86fe6aad055acfc945f162e"
    assert call._path_key(v4.PROFILER_PROOF_REL) == call._path_key(
        r"D:\temp\iteration41-r29-profiler-bytecode-source-proof-r1.py"
    )
    assert v4.PROFILER_PROOF_SHA256 == "7c7de3f15710f5f1b3fc8047bb35b50454d2ed6e5382bfb4096827dca405a913"


def test_exact_r1_helper_is_loaded_from_its_fixed_source_pin():
    call = _load_call()
    helper_path = REPO_ROOT / "scripts/iteration41_optional16_r33_root_preparation_r1.py"
    raw = _read_public(helper_path)
    assert _sha(raw) == call.PREPARATION_SHA256
    helper = call._load_pinned_preparation_helper(raw)
    assert helper.__name__ == "_iteration41_optional16_r33_root_preparation_r1_pinned"
    assert helper.__dict__["__verified_source_sha256__"] == call.PREPARATION_SHA256
    assert type(helper.prepare_root_source_verification) is types.FunctionType
    assert helper.__name__ not in sys.modules


def test_default_call_does_not_touch_scope_or_source_arguments():
    call = _load_call()

    class NoTouch:
        def __getattribute__(self, _name):
            raise AssertionError("closed_call_touched_argument")

    result = call.prepare_root_source_verification(
        NoTouch(), NoTouch(), NoTouch(), NoTouch(), NoTouch()
    )
    assert result == {
        "schema": call.SCHEMA,
        "status": "BLOCKED",
        "reason_code": "preparation_request_required",
        "evidence_level": "NONE",
    }


def test_root_call_contains_no_worker_install_or_child_start_call():
    ast = __import__("ast")
    call_raw = _read_public(CALL_PATH)
    tree = ast.parse(call_raw.decode("utf-8", "strict"))
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)]
    names = set()
    for node in calls:
        if isinstance(node.func, ast.Name):
            names.add(node.func.id)
        elif isinstance(node.func, ast.Attribute):
            names.add(node.func.attr)
    assert "prepare_root_source_verification" in names
    assert not ({"install_full_hold_adaptation", "_r2_main", "CreateProcessW", "Popen", "start"} & names)

    function = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "prepare_root_source_verification"
    )
    ordered_calls = []
    for node in ast.walk(function):
        if not isinstance(node, ast.Call):
            continue
        if isinstance(node.func, ast.Name):
            ordered_calls.append((node.lineno, node.func.id))
        elif isinstance(node.func, ast.Attribute):
            ordered_calls.append((node.lineno, node.func.attr))
    ordered_calls.sort()
    lines = {name: line for line, name in ordered_calls}
    assert lines["bind_v4_module_to_held_source"] < lines["_scope_matches_sources"]
    assert lines["_scope_matches_sources"] < lines["_load_pinned_preparation_helper"]
    assert lines["_load_pinned_preparation_helper"] < lines["prepare_root_source_verification"]

    scope_checker = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_scope_matches_sources"
    )
    assert sum(
        1 for node in ast.walk(scope_checker)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "read_held"
    ) == 1

