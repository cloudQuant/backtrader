# V23 r3 independent source QA receipt

**Result: source-only QA passed; install/release remains blocked.**

- Frozen root: `D:\temp\iteration41_v23_g1_owner_binding_freeze_20260927-r3`
- Verified copy: `D:\temp\iteration41-v23-g1-owner-independent-qa-20260927\snapshot`
- Manifest SHA-256: `f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330`
- Verified payload: 44/44 files, 1,748,219 bytes. V22 delta: 12 entries (10 modified, 2 added, zero removed), each verified against the source manifest.
- Store schema: 23; declared distribution version: `0.2.0`.

## Test results

Focused command from the verified copy:

```powershell
$env:PYTHONPATH = 'D:\temp\iteration41-v23-g1-owner-independent-qa-20260927\snapshot\src;D:\temp\iteration41-v23-g1-owner-independent-qa-20260927\snapshot\tests;D:\temp\iteration41-v23-g1-owner-independent-qa-20260927'
& 'C:\Users\yunji\AppData\Local\Temp\bt-pytest-asyncio-compat-20260926\Scripts\python.exe' -B -m pytest tests/test_ctp_dispatch_commands.py::test_single_worker_freezes_queued_command_without_native_owner_adapter tests/test_ctp_dispatch_commands.py::test_generic_zero_inflight_claim_cannot_flow_to_candidate_sender tests/test_ctp_native_owner_process_binding_v23.py tests/test_ctp_process_exit_recovery_v22.py::test_v20_account_identity_store_migrates_to_v23_native_owner_binding_schema tests/test_ctp_process_exit_recovery_v22.py::test_v21_claim_without_process_binding_migrates_to_unknown_and_poisoned_fence -q -p no:cacheprovider -p v23_isolation_guard --basetemp 'D:\temp\iteration41-v23-g1-owner-independent-qa-20260927\pytest-tmp-focus-loopback' --junitxml 'D:\temp\iteration41-v23-g1-owner-independent-qa-20260927\focus-loopback.xml'
```

Result: **20 passed** (2.29s). The full `tests` package run used the same environment/guard and passed **322, skipped 2** (26.51s). Both before/after payload-hash maps were identical. The skips are optional TraderClient tests because `bt_api_ctp.ctp.client` is not installed; one pytest-asyncio configuration deprecation warning was emitted.

Guard report: zero external network/DNS attempts, zero native SDK modules loaded, zero provider calls. The full run used 13 literal-loopback/AF_UNIX local IPC operations for Windows asyncio. Module origins matched this copy and the exact frozen V20/V21 source roots.

## Static review

- `ctp_single_worker_candidate.py:490-516`: `dispatch_managed_command` returns a durable projection for an already claimed row; a queued READY row is failed closed to UNKNOWN and raises. It never calls the injected sender. `store.py:11863-11883` documents generic claim as local admission only. The generic-claim test (`test_ctp_dispatch_commands.py:2951-2996`) obtains `CLAIMED` with `native_call_inflight=0`, passes it through the candidate consumer, and verifies sender count 0. The separate session claim (`store.py:12306+`) requires active callback-owner/process binding.
- `test_ctp_dispatch_commands.py:1041-1153` proves READY submit/cancel becomes UNKNOWN/inflight=0 with account family poisoned, no sender call, and durable state after reopen. The injected poison-write failure at `:1158-1219` rolls back both transitions (READY/ACTIVE); retry commits the fail-closed state.
- The exact V20 store fixture upgrades to schema 23. The exact V21 claimed-row fixture becomes UNKNOWN with `g1_process_binding_missing`, remains inflight/fenced, and generic recovery cannot clear it. Both migration tests passed.
- Binding tests use `FakeNativeOwnerProcessAttestor`: synthetic DTO/database invariants only, not OS process/Job isolation or G1/G5 evidence.

## Blockers and artifacts

The declared Execution distribution version `0.2.0` collides with an existing identity. Unique version and pin migration are required before install/release acceptance. The package is SOURCE-ONLY and its V22 base is explicitly not G5 acceptance. Ruff format is reported nonclean for 11 files; this QA made no source edits.

Machine-readable receipt: `V23-INDEPENDENT-QA-RECEIPT.json`. JUnit/stdout/guard logs are beside it. Initial harness-failure logs are retained too; the temporary guard had blocked Windows asyncio's literal `127.0.0.1` self-pipe and was corrected to permit local loopback/AF_UNIX only. Candidate source was unchanged throughout.
