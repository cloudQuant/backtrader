from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

QA = Path(r'D:\temp\iteration41-v23-g1-owner-independent-qa-20260927')
EVIDENCE = Path(r'D:\source_code\backtrader\docs\_internal\opts\requirements\迭代41-实盘执行风控监控与示例架构重构\evidence')
ARCHIVE_NAME = 'ctp-execution-v23-g1-owner-binding-independent-qa-2026-09-27.raw.zip'
INDEX_NAME = ARCHIVE_NAME + '.index.json'

FILES = {
    'receipt/V23-INDEPENDENT-QA-RECEIPT.md': QA/'V23-INDEPENDENT-QA-RECEIPT.md',
    'receipt/V23-INDEPENDENT-QA-RECEIPT.json': QA/'V23-INDEPENDENT-QA-RECEIPT.json',
    'provenance/source-validation.json': QA/'source-validation.json',
    'provenance/environment.json': QA/'source-qa-environment.json',
    'provenance/static-call-graph.json': QA/'static-call-graph.json',
    'provenance/V23-SOURCE-MANIFEST.json': QA/'snapshot'/'V23-SOURCE-MANIFEST.json',
    'provenance/COMPOSITE-SOURCE-MANIFEST.json': QA/'snapshot'/'COMPOSITE-SOURCE-MANIFEST.json',
    'provenance/manifest.json': QA/'snapshot'/'manifest.json',
    'provenance/merge-audit.json': QA/'snapshot'/'merge-audit.json',
    'provenance/pyproject.toml': QA/'snapshot'/'pyproject.toml',
    'provenance/SOURCE-ONLY.txt': QA/'snapshot'/'SOURCE-ONLY.txt',
    'provenance/input-manifests/SOURCE-MANIFEST.json': QA/'snapshot'/'input-manifests'/'SOURCE-MANIFEST.json',
    'provenance/input-manifests/V22-CANDIDATE-MANIFEST.json': QA/'snapshot'/'input-manifests'/'V22-CANDIDATE-MANIFEST.json',
    'provenance/input-manifests/source-manifest-r3r3.json': QA/'snapshot'/'input-manifests'/'source-manifest-r3r3.json',
    'provenance/input-manifests/parent-r3r2-manifest.json': QA/'snapshot'/'input-manifests'/'parent-r3r2-manifest.json',
    'tests/focused.xml': QA/'focus-loopback.xml',
    'tests/focused.stdout.txt': QA/'focus-loopback.stdout.txt',
    'tests/focused.run.json': QA/'focus-loopback-run.json',
    'tests/focused.guard.json': QA/'focus-loopback-guard.json',
    'tests/full-package.xml': QA/'full-package-loopback.xml',
    'tests/full-package.stdout.txt': QA/'full-package-loopback.stdout.txt',
    'tests/full-package.run.json': QA/'full-package-loopback-run.json',
    'tests/full-package.guard.json': QA/'full-package-loopback-guard.json',
    'tests/summary-loopback.json': QA/'test-summary-loopback.json',
    'tests/initial-guard-blocked-loopback/focused.xml': QA/'focus.xml',
    'tests/initial-guard-blocked-loopback/focused.stdout.txt': QA/'focus.stdout.txt',
    'tests/initial-guard-blocked-loopback/focused.run.json': QA/'focus-run.json',
    'tests/initial-guard-blocked-loopback/focused.guard.json': QA/'focus-guard.json',
    'tests/initial-guard-blocked-loopback/full-package.xml': QA/'full-package.xml',
    'tests/initial-guard-blocked-loopback/full-package.stdout.txt': QA/'full-package.stdout.txt',
    'tests/initial-guard-blocked-loopback/full-package.run.json': QA/'full-package-run.json',
    'tests/initial-guard-blocked-loopback/full-package.guard.json': QA/'full-package-guard.json',
    'tests/initial-guard-blocked-loopback/summary.json': QA/'test-summary.json',
    'tools/prepare_and_verify.py': QA/'prepare_and_verify.py',
    'tools/run_v23_tests_loopback.py': QA/'run_v23_tests_loopback.py',
    'tools/v23_isolation_guard.py': QA/'v23_isolation_guard.py',
    'tools/package_v23_qa_bundle.py': Path(__file__),
}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

missing = [str(path) for path in FILES.values() if not path.is_file()]
if missing:
    raise SystemExit('missing evidence inputs: ' + ', '.join(missing))
archive = EVIDENCE/ARCHIVE_NAME
entries=[]
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for member, source in FILES.items():
        data=source.read_bytes()
        zf.writestr(member, data)
        entries.append({'path':member,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(archive, 'r') as zf:
    bad=zf.testzip()
    if bad is not None:
        raise SystemExit(f'ZIP CRC failure at {bad}')
    for entry in entries:
        data=zf.read(entry['path'])
        if len(data)!=entry['bytes'] or sha(data)!=entry['sha256']:
            raise SystemExit(f'ZIP round-trip hash mismatch: {entry["path"]}')
index={
 'schema':'iteration41-v23-independent-qa-raw-bundle-index.v1',
 'archive':ARCHIVE_NAME,
 'archive_sha256':sha(archive.read_bytes()),
 'archive_bytes':archive.stat().st_size,
 'testzip':'PASS',
 'round_trip_hash_check':'PASS',
 'entry_count':len(entries),
 'source_manifest_sha256':'f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330',
 'entries':entries,
}
index_path=EVIDENCE/INDEX_NAME
index_path.write_text(json.dumps(index,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'archive':str(archive),'archive_sha256':index['archive_sha256'],'archive_bytes':index['archive_bytes'],'entry_count':len(entries),'testzip':index['testzip'],'index':str(index_path),'index_sha256':sha(index_path.read_bytes())},indent=2))

