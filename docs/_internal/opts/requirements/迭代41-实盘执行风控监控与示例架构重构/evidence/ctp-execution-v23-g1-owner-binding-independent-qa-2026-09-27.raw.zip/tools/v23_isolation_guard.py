from __future__ import annotations
import builtins, ipaddress, json, os, socket, sys
from pathlib import Path

_expected_src = Path(os.environ["V23_EXPECTED_SRC"]).resolve()
_report_path = Path(os.environ["V23_GUARD_REPORT"])
_external_attempts = []
_loopback_transport = []
_forbidden_import_attempts = []

def _host_from_address(address):
    if isinstance(address, tuple) and address:
        return address[0]
    return address

def _is_loopback_address(address):
    host = _host_from_address(address)
    if type(host) is not str:
        return False
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host.split("%", 1)[0]).is_loopback
    except ValueError:
        return False

def _deny_external(kind, args):
    _external_attempts.append({"kind": kind, "args": [repr(x)[:200] for x in args]})
    raise OSError("external network/DNS disabled by V23 source QA guard")

def _allow_connect(kind, original, self, address, *args, **kwargs):
    # AF_UNIX paths are local IPC; TCP/UDP is permitted only to literal loopback.
    if self.family == getattr(socket, "AF_UNIX", object()):
        _loopback_transport.append({"kind": kind, "address": repr(address)[:200], "family": "AF_UNIX"})
        return original(self, address, *args, **kwargs)
    if _is_loopback_address(address):
        _loopback_transport.append({"kind": kind, "address": repr(address)[:200], "family": self.family})
        return original(self, address, *args, **kwargs)
    return _deny_external(kind, (address, *args))

_original_connect = socket.socket.connect
_original_connect_ex = socket.socket.connect_ex
_original_sendto = socket.socket.sendto
_original_create_connection = socket.create_connection
_original_getaddrinfo = socket.getaddrinfo
socket.socket.connect = lambda self, address, *args, **kwargs: _allow_connect("connect", _original_connect, self, address, *args, **kwargs)
socket.socket.connect_ex = lambda self, address, *args, **kwargs: _allow_connect("connect_ex", _original_connect_ex, self, address, *args, **kwargs)

def _guard_sendto(self, data, *args, **kwargs):
    address = args[-1] if args else kwargs.get("address")
    if self.family == getattr(socket, "AF_UNIX", object()) or _is_loopback_address(address):
        _loopback_transport.append({"kind": "sendto", "address": repr(address)[:200], "family": self.family})
        return _original_sendto(self, data, *args, **kwargs)
    return _deny_external("sendto", (address,))
socket.socket.sendto = _guard_sendto

def _guard_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    if type(host) is str and host.lower() == "localhost":
        # Avoid resolver/DNS use while supporting standard local asyncio IPC.
        results = []
        if family in (0, socket.AF_INET):
            results.append((socket.AF_INET, type or socket.SOCK_STREAM, proto or socket.IPPROTO_TCP,
                            "", ("127.0.0.1", port)))
        if family in (0, socket.AF_INET6):
            results.append((socket.AF_INET6, type or socket.SOCK_STREAM, proto or socket.IPPROTO_TCP,
                            "", ("::1", port, 0, 0)))
        _loopback_transport.append({"kind": "getaddrinfo-localhost", "address": repr((host, port))[:200]})
        return results
    if type(host) is str:
        try:
            ipaddress.ip_address(host.split("%", 1)[0])
        except ValueError:
            return _deny_external("getaddrinfo", (host, port))
    return _original_getaddrinfo(host, port, family, type, proto, flags)
socket.getaddrinfo = _guard_getaddrinfo

_original_import = builtins.__import__
def _tracking_import(name, globals=None, locals=None, fromlist=(), level=0):
    top = name.split(".", 1)[0] if type(name) is str else ""
    if top in {"bt_api_ctp", "_ctp", "ctp_wrap"}:
        _forbidden_import_attempts.append(name)
    return _original_import(name, globals, locals, fromlist, level)
builtins.__import__ = _tracking_import

def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False

def pytest_sessionstart(session):
    import bt_api_execution
    origin = Path(bt_api_execution.__file__).resolve()
    if not _within(origin, _expected_src):
        raise RuntimeError(f"bt_api_execution origin outside isolated copy: {origin}")
    session.config._v23_import_origins = {"bt_api_execution": str(origin)}

def pytest_sessionfinish(session, exitstatus):
    origins = getattr(session.config, "_v23_import_origins", {})
    for module_name, root_env in (
        ("_bt_api_execution_frozen_v20.store", "V23_V20_SOURCE"),
        ("_bt_api_execution_frozen_v21.store", "V23_V21_SOURCE"),
    ):
        module = sys.modules.get(module_name)
        if module is not None:
            path = Path(module.__file__).resolve()
            expected_root = Path(os.environ[root_env]).resolve()
            if not _within(path, expected_root):
                origins[module_name] = f"WRONG:{path}"
            else:
                origins[module_name] = str(path)
    blocked_loaded = sorted(
        name for name in sys.modules
        if name in {"_ctp", "ctp_wrap", "bt_api_ctp"}
        or name.startswith("bt_api_ctp.")
    )
    report = {
        "source_origin": origins,
        "sdk_import_attempts": list(_forbidden_import_attempts),
        "sdk_native_modules_loaded": blocked_loaded,
        "external_network_or_dns_attempts": list(_external_attempts),
        "local_loopback_ipc": list(_loopback_transport),
        "pytest_exitstatus": exitstatus,
    }
    _report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if blocked_loaded or _external_attempts or any(v.startswith("WRONG:") for v in origins.values()):
        raise RuntimeError(f"V23 isolation guard failed; report={_report_path}")
