from __future__ import annotations
import hashlib, json, os, subprocess, sys, time
from pathlib import Path

OUT = Path(r"D:\temp\iteration41-v23-g1-owner-independent-qa-20260927")
ROOT = OUT / "snapshot"
MANIFEST = ROOT / "V23-SOURCE-MANIFEST.json"
SRC = ROOT / "src"
TESTS = ROOT / "tests"
V20 = Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\src")
V21 = Path(r"D:\temp\iteration41_v20_r3r3_v21_handoff_freeze_r1_20260927\src")

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def inventory():
    m = json.loads(MANIFEST.read_text(encoding="utf-8"))
    out = {"V23-SOURCE-MANIFEST.json": sha(MANIFEST)}
    for entry in m["payload_files"]:
        p = ROOT / Path(*entry["path"].split("/"))
        out[entry["path"]] = sha(p)
    return out

def run(label, nodes):
    before = inventory()
    basetemp = OUT / f"pytest-tmp-{label}"
    junit = OUT / f"{label}.xml"
    guard = OUT / f"{label}-guard.json"
    log = OUT / f"{label}.stdout.txt"
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join((str(SRC), str(TESTS), str(OUT)))
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONNOUSERSITE"] = "1"
    env["PYTEST_ADDOPTS"] = ""
    env.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)
    env.pop("PYTEST_PLUGINS", None)
    env["V23_EXPECTED_SRC"] = str(SRC)
    env["V23_GUARD_REPORT"] = str(guard)
    env["V23_V20_SOURCE"] = str(V20)
    env["V23_V21_SOURCE"] = str(V21)
    command = [sys.executable, "-B", "-m", "pytest", *nodes,
               "-q", "-p", "no:cacheprovider", "-p", "v23_isolation_guard",
               "--basetemp", str(basetemp), "--junitxml", str(junit)]
    start = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                            errors="replace")
    log.write_text(result.stdout, encoding="utf-8")
    after = inventory()
    guard_data = json.loads(guard.read_text(encoding="utf-8")) if guard.exists() else None
    unchanged = before == after
    entry = {
        "label": label,
        "command": command,
        "cwd": str(ROOT),
        "python": sys.version,
        "pytest_plugin_autoload": "enabled (PYTEST_DISABLE_PLUGIN_AUTOLOAD unset)",
        "cache_provider": "disabled",
        "bytecode_writes": "disabled (-B and PYTHONDONTWRITEBYTECODE=1)",
        "returncode": result.returncode,
        "seconds": round(time.time() - start, 3),
        "junit": str(junit),
        "stdout": str(log),
        "guard_report": guard_data,
        "source_hashes_unchanged": unchanged,
        "before_source_hashes": before,
        "after_source_hashes": after,
    }
    (OUT / f"{label}-run.json").write_text(
        json.dumps(entry, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"{label}: exit={result.returncode} source_unchanged={unchanged} seconds={entry['seconds']}")
    print(result.stdout)
    if result.returncode != 0 or not unchanged or guard_data is None:
        return entry, False
    if guard_data.get("forbidden_sdk_native_modules_loaded") or guard_data.get("external_network_attempts"):
        return entry, False
    if any(value.startswith("WRONG:") for value in guard_data.get("source_origin", {}).values()):
        return entry, False
    return entry, True

focus_nodes = [
    "tests/test_ctp_dispatch_commands.py::test_single_worker_freezes_queued_command_without_native_owner_adapter",
    "tests/test_ctp_dispatch_commands.py::test_generic_zero_inflight_claim_cannot_flow_to_candidate_sender",
    "tests/test_ctp_native_owner_process_binding_v23.py",
    "tests/test_ctp_process_exit_recovery_v22.py::test_v20_account_identity_store_migrates_to_v23_native_owner_binding_schema",
    "tests/test_ctp_process_exit_recovery_v22.py::test_v21_claim_without_process_binding_migrates_to_unknown_and_poisoned_fence",
]
full_nodes = ["tests"]
focus, focus_ok = run("focus-loopback", focus_nodes)
full, full_ok = run("full-package-loopback", full_nodes)
summary = {"focus": focus, "full_package": full,
           "overall_source_qa": bool(focus_ok and full_ok)}
(OUT / "test-summary-loopback.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
sys.exit(0 if summary["overall_source_qa"] else 1)
