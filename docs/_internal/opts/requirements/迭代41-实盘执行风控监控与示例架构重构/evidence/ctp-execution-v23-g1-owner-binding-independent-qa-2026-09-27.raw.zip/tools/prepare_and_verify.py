from __future__ import annotations
import hashlib, json, os, shutil, stat
from pathlib import Path, PurePosixPath

SOURCE = Path(r"D:\temp\iteration41_v23_g1_owner_binding_freeze_20260927-r3")
V22 = Path(r"D:\temp\iteration41_v22_g5_crash_recovery_r3r3_candidate_20260927")
OUT = Path(r"D:\temp\iteration41-v23-g1-owner-independent-qa-20260927")
DEST = OUT / "snapshot"
EXPECTED_MANIFEST_SHA = "f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330"
REPARSE = 0x400

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def assert_no_reparse(path: Path, stop: Path) -> None:
    current = path
    stop = stop.resolve(strict=True)
    while True:
        st = os.stat(current, follow_symlinks=False)
        if stat.S_ISLNK(st.st_mode) or (getattr(st, "st_file_attributes", 0) & REPARSE):
            raise RuntimeError(f"reparse/symlink source rejected: {current}")
        if current.resolve(strict=True) == stop:
            break
        if current.parent == current:
            raise RuntimeError(f"source path escaped root: {path}")
        current = current.parent

manifest_path = SOURCE / "V23-SOURCE-MANIFEST.json"
assert_no_reparse(SOURCE, SOURCE.parent.resolve(strict=True))
if sha(manifest_path) != EXPECTED_MANIFEST_SHA:
    raise RuntimeError("V23 manifest hash differs from requested freeze")
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
if manifest.get("payload_file_count") != 44 or len(manifest.get("payload_files", [])) != 44:
    raise RuntimeError("payload count is not exactly 44")
if len(manifest.get("changed_source_and_test_files", [])) != 12:
    raise RuntimeError("delta is not exactly 12 paths")
if manifest.get("removed_source_and_test_paths") != []:
    raise RuntimeError("unexpected removed paths")
if DEST.exists():
    raise RuntimeError(f"destination already exists; refusing overwrite: {DEST}")

validated = []
seen = set()
size_sum = 0
for entry in manifest["payload_files"]:
    rel = PurePosixPath(entry["path"])
    if rel.is_absolute() or ".." in rel.parts or not rel.parts:
        raise RuntimeError(f"unsafe payload path: {rel}")
    rel_win = Path(*rel.parts)
    if rel.as_posix() in seen:
        raise RuntimeError(f"duplicate payload path: {rel}")
    seen.add(rel.as_posix())
    src = SOURCE / rel_win
    assert_no_reparse(src, SOURCE.resolve(strict=True))
    if not src.is_file():
        raise RuntimeError(f"payload missing/not regular file: {rel}")
    actual_size, actual_sha = src.stat().st_size, sha(src)
    if actual_size != entry["bytes"] or actual_sha != entry["sha256"]:
        raise RuntimeError(f"payload mismatch: {rel}")
    size_sum += actual_size
    validated.append({"path": rel.as_posix(), "bytes": actual_size, "sha256": actual_sha})

if size_sum != manifest.get("payload_bytes_total"):
    raise RuntimeError(f"payload byte sum mismatch: {size_sum}")

# Verify all 12 declared V22→V23 change entries against the available V22 source tree.
changed = []
for entry in manifest["changed_source_and_test_files"]:
    rel = PurePosixPath(entry["path"])
    if rel.is_absolute() or ".." in rel.parts:
        raise RuntimeError(f"unsafe delta path: {rel}")
    source_file = SOURCE / Path(*rel.parts)
    v22_file = V22 / Path(*rel.parts)
    change = entry["change"]
    if change == "added":
        if v22_file.exists() or entry.get("base_v22_sha256") is not None:
            raise RuntimeError(f"added path already exists in V22: {rel}")
    elif change == "modified":
        if not v22_file.is_file():
            raise RuntimeError(f"modified path missing from V22 base: {rel}")
        base_sha = sha(v22_file)
        if base_sha != entry.get("base_v22_sha256"):
            raise RuntimeError(f"V22 base hash mismatch for delta: {rel}")
        if sha(source_file) == base_sha:
            raise RuntimeError(f"declared modified path has identical bytes: {rel}")
    else:
        raise RuntimeError(f"unknown delta classification {change!r}: {rel}")
    changed.append({"path": rel.as_posix(), "change": change,
                    "base_v22_sha256": entry.get("base_v22_sha256"),
                    "v23_sha256": sha(source_file)})

DEST.mkdir(parents=True)
shutil.copyfile(manifest_path, DEST / manifest_path.name)
for entry in validated:
    rel = Path(*PurePosixPath(entry["path"]).parts)
    target = DEST / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(SOURCE / rel, target)
    os.chmod(target, stat.S_IREAD)

# Verify copied bytes against the same signed payload list and keep test results outside DEST.
for entry in validated:
    target = DEST / Path(*PurePosixPath(entry["path"]).parts)
    if target.stat().st_size != entry["bytes"] or sha(target) != entry["sha256"]:
        raise RuntimeError(f"copy verification failed: {entry['path']}")
if sha(DEST / manifest_path.name) != EXPECTED_MANIFEST_SHA:
    raise RuntimeError("copied manifest differs")

report = {
    "manifest_sha256": EXPECTED_MANIFEST_SHA,
    "payload_files_verified": len(validated),
    "payload_bytes_verified": size_sum,
    "delta_entries_verified": len(changed),
    "delta_base": "V22 candidate source tree, each modified path checked against base_v22_sha256; additions confirmed absent",
    "snapshot_copy": str(DEST),
    "read_only_payload_files": len(validated),
    "payload": validated,
    "delta": changed,
}
(OUT / "source-validation.json").write_text(
    json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
print(f"V23_MANIFEST_SHA256={EXPECTED_MANIFEST_SHA}")
print(f"PAYLOAD_VERIFIED={len(validated)}/44 bytes={size_sum}")
print(f"DELTA_VERIFIED={len(changed)}/12 added={sum(x['change']=='added' for x in changed)} modified={sum(x['change']=='modified' for x in changed)}")
print(f"READ_ONLY_COPY={DEST}")
