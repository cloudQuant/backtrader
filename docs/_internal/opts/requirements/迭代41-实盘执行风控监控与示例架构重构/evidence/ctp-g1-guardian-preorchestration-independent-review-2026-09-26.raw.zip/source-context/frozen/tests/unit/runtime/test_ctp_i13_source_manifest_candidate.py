"""Offline tests for the non-authorizing I13 source-manifest candidate."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import stat
import sys
import types
import uuid
import ast
import base64
import zlib
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]


def _load_script_module(module_name: str, path: Path) -> types.ModuleType:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise AssertionError("test script module could not be loaded")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module


candidate_builder = _load_script_module(
    "_i13_source_manifest_candidate_test_builder",
    REPO_ROOT / "scripts" / "ctp_i13_source_manifest_candidate.py",
)
parent_launcher = _load_script_module(
    "_i13_source_manifest_candidate_test_launcher",
    REPO_ROOT / "scripts" / "ctp_i13_i15_parent_launcher.py",
)


def _load_runtime_identity() -> tuple[types.ModuleType, str]:
    """Load the identity source under a fake package, bypassing runtime init."""

    package_name = "_i13_source_identity_test_" + uuid.uuid4().hex
    package = types.ModuleType(package_name)
    package.__path__ = [str(REPO_ROOT / "backtrader_runtime")]
    sys.modules[package_name] = package
    module_name = package_name + ".ctp_i13_source_identity"
    module = _load_script_module(
        module_name, REPO_ROOT / "backtrader_runtime" / "ctp_i13_source_identity.py"
    )
    return module, package_name


def _remove_runtime_identity(package_name: str) -> None:
    for module_name in tuple(sys.modules):
        if module_name == package_name or module_name.startswith(package_name + "."):
            sys.modules.pop(module_name, None)


def _fake_runtime_tree(root: Path) -> Path:
    package = root / "backtrader_runtime"
    files = {
        "__init__.py": b"# fake runtime package\n",
        "inventory.py": b"RUNTIME_REGISTRY = ()\n",
        "ctp_i13_md_oneshot_supervisor.py": b"DIAGNOSTIC_ONLY = True\n",
        "ctp_i13_source_identity.py": b"IDENTITY_SOURCE = True\n",
        "ctp_i13_worker_dependency_seal.py": b"DEPENDENCY_SEAL_SOURCE = True\n",
        "nested/fake_module.py": b"VALUE = 'offline'\n",
        "ctp_i13_source_identity_pin.py": b"I13_SOURCE_MANIFEST_SHA256 = '0' * 64\n",
        "ctp_i15_source_identity_pin.py": b"I15_REVIEWED_SOURCE_MANIFEST_SHA256 = None\n",
    }
    for relative, content in files.items():
        path = package / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    worker_path = root.joinpath(*candidate_builder.FIXED_READONLY_WORKER_PATH.parts)
    worker_path.parent.mkdir(parents=True, exist_ok=True)
    worker_path.write_bytes(b"WORKER_SOURCE = 'fixed-readonly-worker'\n")
    bootstrap_path = root.joinpath(*candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.parts)
    bootstrap_path.write_bytes(b"BOOTSTRAP_SOURCE = 'fixed-readonly-bootstrap'\n")
    support_sources = {
        "scripts/ctp_i13_i15_sealed_import.py": b"SEALED_IMPORT_SOURCE = True\n",
        "scripts/ctp_i13_i15_guardian_deployment_anchor.py": b"ANCHOR_SOURCE = True\n",
        "scripts/ctp_i13_i15_parent_launcher.py": b"PARENT_SOURCE = True\n",
        "scripts/ctp_i13_i15_runtime_closure.py": b"RUNTIME_CLOSURE_SOURCE = True\n",
        "scripts/ctp_i13_i15_worker_output_channel.py": b"OUTPUT_CHANNEL_SOURCE = True\n",
    }
    for relative, content in support_sources.items():
        target = root.joinpath(*relative.split("/"))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    return root


def test_bootstrap_artifact_is_deterministic_and_binds_exact_embedded_support(
    tmp_path: Path,
) -> None:
    root = _fake_runtime_tree(tmp_path)

    artifact = candidate_builder.build_readonly_preflight_bootstrap(root)
    repeated = candidate_builder.build_readonly_preflight_bootstrap(root)

    assert artifact == repeated
    assert len(artifact) <= candidate_builder._MAX_BOOTSTRAP_BYTES
    assert artifact.startswith(
        (root / "scripts" / "ctp_i13_i15_sealed_import.py").read_bytes().rstrip() + b"\n\n"
    )
    compile(artifact, "<test-bootstrap>", "exec")
    module = ast.parse(artifact.decode("ascii"))
    assignment = next(
        node
        for node in module.body
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Name)
            and target.id == "_READONLY_BOOTSTRAP_SUPPORT_B85"
            for target in node.targets
        )
    )
    encoded = ast.literal_eval(assignment.value)
    support_start = artifact.index(b"_READONLY_BOOTSTRAP_SUPPORT_SHA256 = ")
    support_line = artifact[support_start : artifact.index(b"\n", support_start)]
    support_sha256 = support_line.split(b'"')[1].decode("ascii")
    raw = zlib.decompress(base64.b85decode(encoded.encode("ascii")))
    assert hashlib.sha256(raw).hexdigest() == support_sha256
    value = json.loads(raw.decode("utf-8"))
    assert value["schema"] == 1
    assert [row["path"] for row in value["files"]] == [
        path.as_posix() for path in candidate_builder.BOOTSTRAP_EMBEDDED_SUPPORT_PATHS
    ]
    for row in value["files"]:
        source = base64.b64decode(row["source_b64"], validate=True)
        assert hashlib.sha256(source).hexdigest() == row["sha256"]
        assert source == root.joinpath(*row["path"].split("/")).read_bytes()
    assert b"ctp_i13_i15_readonly_preflight_bootstrap_binding.v3" in artifact
    assert b"runtime_manifest_sha256" in artifact
    assert b"worker_output" in artifact and b"request_id" in artifact


def test_bootstrap_writer_targets_only_the_fixed_source_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _fake_runtime_tree(tmp_path)

    output, content = candidate_builder.write_readonly_preflight_bootstrap_candidate(root)

    assert output == root / candidate_builder.BOOTSTRAP_OUTPUT
    assert output.read_bytes() == content
    outside = root.parent / (root.name + "_bootstrap_escape.py")
    monkeypatch.setattr(candidate_builder, "BOOTSTRAP_OUTPUT", outside)
    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="bootstrap_output_path_invalid",
    ):
        candidate_builder.write_readonly_preflight_bootstrap_candidate(root)
    assert not outside.exists()


def test_candidate_is_canonical_complete_and_accepted_by_both_parsers(
    tmp_path: Path,
) -> None:
    root = _fake_runtime_tree(tmp_path)
    raw = candidate_builder.build_i13_source_manifest(root)
    digest = hashlib.sha256(raw).hexdigest()
    value = json.loads(raw.decode("utf-8"))

    assert set(value) == {"schema", "source_files"}
    assert value["schema"] == 1
    assert list(value["source_files"]) == sorted(value["source_files"])
    assert raw == json.dumps(
        value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    assert not raw.endswith(b"\n")
    assert set(value["source_files"]) == set(candidate_builder.discover_i13_source_files(root))
    assert candidate_builder.PIN_PATHS.isdisjoint(value["source_files"])

    parsed_by_launcher = parent_launcher._parse_candidate_manifest("i13_md", raw, digest)
    identity, package_name = _load_runtime_identity()
    try:
        parsed_by_runtime = identity.parse_i13_source_manifest(raw)
        identity._verify_i13_source_files(root, parsed_by_runtime)
        full_inventory = identity._runtime_python_inventory(root) | {
            candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix()
        } | {
            candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.as_posix()
        }
        leased_directories = identity._source_lease_directories(
            root,
            [
                root.joinpath(*candidate_builder.FIXED_READONLY_WORKER_PATH.parts),
                root.joinpath(*candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.parts),
            ],
        )
    finally:
        _remove_runtime_identity(package_name)

    assert dict(parsed_by_launcher) == value["source_files"]
    assert dict(parsed_by_runtime) == value["source_files"]
    assert full_inventory == set(value["source_files"]) | candidate_builder.PIN_PATHS
    worker_relative = candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix()
    worker_path = root.joinpath(*candidate_builder.FIXED_READONLY_WORKER_PATH.parts)
    bootstrap_relative = candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.as_posix()
    bootstrap_path = root.joinpath(*candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.parts)
    assert (
        value["source_files"][worker_relative]
        == hashlib.sha256(worker_path.read_bytes()).hexdigest()
    )
    assert value["source_files"][bootstrap_relative] == hashlib.sha256(
        bootstrap_path.read_bytes()
    ).hexdigest()
    assert root / "scripts" in leased_directories
    assert root in leased_directories


def test_candidate_covers_new_sources_but_excludes_pin_contents(tmp_path: Path) -> None:
    root = _fake_runtime_tree(tmp_path)
    first = candidate_builder.build_i13_source_manifest(root)
    package = root / "backtrader_runtime"
    (package / "new_diagnostic_helper.py").write_bytes(b"HELPER = True\n")
    second = candidate_builder.build_i13_source_manifest(root)
    (package / "ctp_i13_source_identity_pin.py").write_bytes(
        b"I13_SOURCE_MANIFEST_SHA256 = 'changed-but-still-unpinned'\n"
    )
    third = candidate_builder.build_i13_source_manifest(root)

    assert first != second
    assert second == third
    assert "backtrader_runtime/new_diagnostic_helper.py" in json.loads(second)["source_files"]
    assert (
        candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix()
        in json.loads(second)["source_files"]
    )


def test_candidate_writer_uses_only_a_labelled_non_runtime_path(tmp_path: Path) -> None:
    root = _fake_runtime_tree(tmp_path)
    output = root / "artifacts" / candidate_builder.CANDIDATE_OUTPUT.name

    written_path, raw = candidate_builder.write_current_dirty_tree_candidate(root)

    assert written_path == output
    assert output.read_bytes() == raw
    assert output != root / candidate_builder.MANIFEST_RELATIVE_PATH


def test_candidate_writer_rejects_mutated_relative_output_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _fake_runtime_tree(tmp_path)
    monkeypatch.setattr(candidate_builder, "CANDIDATE_OUTPUT", Path("../escaped.json"))

    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="candidate_output_path_invalid",
    ):
        candidate_builder.write_current_dirty_tree_candidate(root)

    assert not (root.parent / "escaped.json").exists()
    assert not (root / "artifacts").exists()


def test_candidate_writer_rejects_mutated_absolute_output_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _fake_runtime_tree(tmp_path)
    outside = root.parent / (root.name + "_escaped.json")
    monkeypatch.setattr(candidate_builder, "CANDIDATE_OUTPUT", outside)

    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="candidate_output_path_invalid",
    ):
        candidate_builder.write_current_dirty_tree_candidate(root)

    assert not outside.exists()
    assert not (root / "artifacts").exists()


def test_candidate_writer_rejects_reparse_artifacts_directory(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = _fake_runtime_tree(tmp_path)
    artifacts = root / "artifacts"
    artifacts.mkdir()
    original_lstat = os.lstat

    def report_reparse(path: object, *args: object, **kwargs: object) -> object:
        if Path(path) == artifacts:
            return types.SimpleNamespace(
                st_mode=stat.S_IFDIR | 0o755,
                st_file_attributes=0x400,
            )
        return original_lstat(path, *args, **kwargs)

    monkeypatch.setattr(candidate_builder.os, "lstat", report_reparse)

    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="candidate_output_directory_invalid",
    ):
        candidate_builder.write_current_dirty_tree_candidate(root)

    assert not (artifacts / candidate_builder.CANDIDATE_OUTPUT.name).exists()


def test_discovered_file_set_matches_runtime_identity_inventory() -> None:
    identity, package_name = _load_runtime_identity()
    try:
        full_inventory = identity._runtime_python_inventory(REPO_ROOT)
    finally:
        _remove_runtime_identity(package_name)

    assert set(candidate_builder.discover_i13_source_files(REPO_ROOT)) == (
        full_inventory - candidate_builder.PIN_PATHS
        | {
            candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix(),
            candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.as_posix(),
        }
    )


def test_legacy_runtime_only_manifest_remains_valid_but_does_not_pin_worker(
    tmp_path: Path,
) -> None:
    root = _fake_runtime_tree(tmp_path)
    raw = candidate_builder.build_i13_source_manifest(root)
    value = json.loads(raw.decode("utf-8"))
    value["source_files"].pop(candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix())
    value["source_files"].pop(candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.as_posix())
    legacy_raw = json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode(
        "utf-8"
    )
    identity, package_name = _load_runtime_identity()
    try:
        parsed = identity.parse_i13_source_manifest(legacy_raw)
        identity._require_i13_source_inventory(root, set(parsed) | candidate_builder.PIN_PATHS)
        leased_directories = identity._source_lease_directories(
            root,
            [root.joinpath(*path.split("/")) for path in parsed],
        )
    finally:
        _remove_runtime_identity(package_name)
    assert candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix() not in parsed
    assert candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.as_posix() not in parsed
    assert root / "scripts" not in leased_directories


def test_identity_checks_fixed_worker_digest_and_rejects_changed_bytes(
    tmp_path: Path,
) -> None:
    root = _fake_runtime_tree(tmp_path)
    raw = candidate_builder.build_i13_source_manifest(root)
    identity, package_name = _load_runtime_identity()
    try:
        parsed = identity.parse_i13_source_manifest(raw)
        worker = root.joinpath(*candidate_builder.FIXED_READONLY_WORKER_PATH.parts)
        worker.write_bytes(b"changed-worker-bytes\n")
        with pytest.raises(identity.I13SourceIdentityError, match="source_digest_mismatch"):
            identity._verify_i13_source_files(root, parsed)
    finally:
        _remove_runtime_identity(package_name)


def test_manifest_parsers_reject_any_other_scripts_source_path(tmp_path: Path) -> None:
    root = _fake_runtime_tree(tmp_path)
    value = json.loads(candidate_builder.build_i13_source_manifest(root))
    value["source_files"]["scripts/unreviewed.py"] = hashlib.sha256(b"x").hexdigest()
    raw = json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode()
    with pytest.raises(parent_launcher.ParentLaunchError, match="manifest_path_invalid"):
        parent_launcher._parse_candidate_manifest("i13_md", raw, hashlib.sha256(raw).hexdigest())
    identity, package_name = _load_runtime_identity()
    try:
        with pytest.raises(identity.I13SourceIdentityError, match="source_manifest_path_invalid"):
            identity.parse_i13_source_manifest(raw)
    finally:
        _remove_runtime_identity(package_name)


def test_candidate_rejects_missing_fixed_worker_source(tmp_path: Path) -> None:
    root = _fake_runtime_tree(tmp_path)
    worker = root.joinpath(*candidate_builder.FIXED_READONLY_WORKER_PATH.parts)
    worker.unlink()
    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="source_inventory_incomplete",
    ):
        candidate_builder.build_i13_source_manifest(root)


def test_candidate_rejects_missing_fixed_bootstrap_source(tmp_path: Path) -> None:
    root = _fake_runtime_tree(tmp_path)
    bootstrap = root.joinpath(*candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.parts)
    bootstrap.unlink()
    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="source_inventory_incomplete",
    ):
        candidate_builder.build_i13_source_manifest(root)


def test_candidate_rejects_missing_dependency_helper_for_bootstrap(tmp_path: Path) -> None:
    root = _fake_runtime_tree(tmp_path)
    helper = root.joinpath(*candidate_builder.FIXED_WORKER_DEPENDENCY_HELPER_PATH.parts)
    helper.unlink()
    with pytest.raises(
        candidate_builder.SourceManifestCandidateError,
        match="source_inventory_incomplete",
    ):
        candidate_builder.build_i13_source_manifest(root)


def test_worker_only_manifest_is_compatible_but_bootstrap_requires_worker(
    tmp_path: Path,
) -> None:
    root = _fake_runtime_tree(tmp_path)
    value = json.loads(candidate_builder.build_i13_source_manifest(root))
    worker_path = candidate_builder.FIXED_READONLY_WORKER_PATH.as_posix()
    bootstrap_path = candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.as_posix()
    value["source_files"].pop(bootstrap_path)
    worker_only = json.dumps(
        value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    worker_only_digest = hashlib.sha256(worker_only).hexdigest()
    assert worker_path in parent_launcher._parse_candidate_manifest(
        "i13_md", worker_only, worker_only_digest
    )
    identity, package_name = _load_runtime_identity()
    try:
        parsed_worker_only = identity.parse_i13_source_manifest(worker_only)
        identity._require_i13_source_inventory(
            root, set(parsed_worker_only) | candidate_builder.PIN_PATHS
        )
    finally:
        _remove_runtime_identity(package_name)

    helper_missing_value = json.loads(candidate_builder.build_i13_source_manifest(root))
    helper_missing_value["source_files"].pop(
        candidate_builder.FIXED_WORKER_DEPENDENCY_HELPER_PATH.as_posix()
    )
    helper_missing_raw = json.dumps(
        helper_missing_value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    helper_missing_digest = hashlib.sha256(helper_missing_raw).hexdigest()
    with pytest.raises(
        parent_launcher.ParentLaunchError,
        match="readonly_dependency_helper_source_unpinned",
    ):
        parent_launcher._parse_candidate_manifest(
            "i13_md", helper_missing_raw, helper_missing_digest
        )
    identity, package_name = _load_runtime_identity()
    try:
        parsed_helper_missing = identity.parse_i13_source_manifest(helper_missing_raw)
        with pytest.raises(
            identity.I13SourceIdentityError,
            match="source_manifest_dependency_helper_unpinned",
        ):
            identity._require_i13_source_inventory(
                root, set(parsed_helper_missing) | candidate_builder.PIN_PATHS
            )
    finally:
        _remove_runtime_identity(package_name)

    value["source_files"].pop(worker_path)
    value["source_files"][bootstrap_path] = hashlib.sha256(
        root.joinpath(*candidate_builder.FIXED_READONLY_BOOTSTRAP_PATH.parts).read_bytes()
    ).hexdigest()
    bootstrap_without_worker = json.dumps(
        value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    bootstrap_digest = hashlib.sha256(bootstrap_without_worker).hexdigest()
    with pytest.raises(parent_launcher.ParentLaunchError, match="readonly_worker_source_unpinned"):
        parent_launcher._parse_candidate_manifest(
            "i13_md", bootstrap_without_worker, bootstrap_digest
        )
    identity, package_name = _load_runtime_identity()
    try:
        parsed = identity.parse_i13_source_manifest(bootstrap_without_worker)
        with pytest.raises(identity.I13SourceIdentityError, match="source_manifest_worker_unpinned"):
            identity._require_i13_source_inventory(
                root, set(parsed) | candidate_builder.PIN_PATHS
            )
    finally:
        _remove_runtime_identity(package_name)


def test_parent_launcher_rejects_extra_manifest_fields_and_out_of_scope_paths(
    tmp_path: Path,
) -> None:
    root = _fake_runtime_tree(tmp_path)
    value = json.loads(candidate_builder.build_i13_source_manifest(root))
    value["not_in_schema"] = True
    extra_field = json.dumps(
        value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    with pytest.raises(parent_launcher.ParentLaunchError, match="manifest_invalid"):
        parent_launcher._parse_candidate_manifest(
            "i13_md", extra_field, hashlib.sha256(extra_field).hexdigest()
        )

    value.pop("not_in_schema")
    value["source_files"]["backtrader_runtime/../outside.py"] = hashlib.sha256(
        b"fake-source"
    ).hexdigest()
    invalid_path = json.dumps(
        value, ensure_ascii=True, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    with pytest.raises(parent_launcher.ParentLaunchError, match="manifest_path_invalid"):
        parent_launcher._parse_candidate_manifest(
            "i13_md", invalid_path, hashlib.sha256(invalid_path).hexdigest()
        )
