# R5 feasibility decision: process creation before returned handles

## Contract under examination

The r4 protocol issues no `PreparedServiceHost` until `create_suspended_in_job` has returned a session and the process is assigned to a Job. The caller invokes that backend method synchronously. The requested r5 contract adds an independently running custodian and requires a caller-return deadline even if setup/cleanup blocks, with either exact exit + Job-empty + control-release evidence or `UNKNOWN` while controls remain retained.

## Native boundary

`CreateProcessW` is a synchronous call with no timeout or cancellation parameter. On success, its output `PROCESS_INFORMATION` carries the process and primary-thread handles. If that call has not returned, a caller outside the blocked stack has no process/thread handles to wait on or close. A pre-created Job can be held before process creation, and Windows 10+ offers `PROC_THREAD_ATTRIBUTE_JOB_LIST` to associate Job handles at creation, but neither provides a process/thread handle or a completion result before `CreateProcessW` returns. Creating the Job itself is another synchronous handle-producing call.

Official references:

- [CreateProcessW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw): `PROCESS_INFORMATION` is an output populated on successful return.
- [UpdateProcThreadAttribute](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute): `PROC_THREAD_ATTRIBUTE_JOB_LIST` assigns existing Job handles during child creation on Windows 10+.
- [Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects): Job creation, explicit process assignment, termination, accounting, and handle lifetime.

## Negative probe

`tests/test_r5_create_without_handles.py` fault-injects a synchronous `create_suspended_in_job` call that has not returned a session/handle. An independent deadline observer can notice that time passed, but the caller remains blocked beyond the startup deadline; no session, process/thread handle, Job handle, or retention token is available through the r4 interface. Once released, preparation reports `not_ready` and issues no prepared host. This probe is deterministic and fake-only; it does not deliberately stall a real Win32 call.

## Decision

Do not claim a hard whole-command deadline or implement a r5 backend on top of the current r4 boundary. A persistent OS-started custodian could bound requests only after it is already running and has acquired its Job/process/thread handles; that leaves custodian bootstrap and prewarm/CreateProcess before readiness outside the hard whole-command proof. Making that assumption silently would narrow the requested contract. Keep G1 closed until a separately established, independently supervised bootstrap proves a caller deadline and control custody across this setup boundary.

The fake probe uses no child process, provider, SDK, network, credentials, protected config, service install, or repository file.
