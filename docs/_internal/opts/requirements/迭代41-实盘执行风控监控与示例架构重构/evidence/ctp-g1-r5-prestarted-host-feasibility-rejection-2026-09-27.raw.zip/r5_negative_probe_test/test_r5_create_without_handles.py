import json
import sys
import threading
import time
import unittest
from pathlib import Path

CANDIDATE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CANDIDATE / 'source'))

from test_service_host_supervisor import FakePrestartedServiceHost
import test_service_host_supervisor as baseline
from scripts.ctp_i13_i15_service_host_supervisor import prepare_service_host


class CreateWithoutHandlesTests(unittest.TestCase):
    """Fault-inject a synchronous CreateProcess boundary before handle return."""

    def test_startup_caller_misses_deadline_before_backend_returns_any_session(self):
        create_entered = threading.Event()
        unblock_create = threading.Event()

        class Backend:
            def __init__(self):
                self.session = None
                self.job_handle = None
                self.process_handle = None
                self.thread_handle = None
                self.retention_calls = 0

            def create_suspended_in_job(self, command, *, deadline_monotonic):
                create_entered.set()
                # Represents a synchronous CreateProcess/Job setup call that
                # has not returned PROCESS_INFORMATION or a session handle.
                unblock_create.wait()
                self.session = FakePrestartedServiceHost('late_creation')
                return self.session

            def retain_controls(self, session):
                self.retention_calls += 1
                return 'fake-retention-token'

        base = baseline.ServiceHostDeadlineTests()
        base.setUp()
        backend = Backend()
        deadline = time.monotonic() + 0.20
        outcomes = {}

        def invoke_prepare():
            try:
                outcomes['result'] = prepare_service_host(
                    base.command,
                    backend=backend,
                    startup_deadline_monotonic=deadline,
                    monotonic=time.monotonic,
                    poll_interval_seconds=0.01,
                )
            except BaseException as exc:
                outcomes['error'] = repr(exc)

        caller = threading.Thread(target=invoke_prepare, daemon=True)
        started = time.monotonic()
        caller.start()
        try:
            self.assertTrue(create_entered.wait(timeout=1.0))
            while time.monotonic() <= deadline + 0.10:
                time.sleep(0.005)
            observed = time.monotonic()
            caller.join(timeout=0.02)
            handles_before_return = {
                'job_handle': backend.job_handle,
                'process_handle': backend.process_handle,
                'thread_handle': backend.thread_handle,
                'session': backend.session,
            }
            self.assertGreater(observed, deadline)
            self.assertTrue(caller.is_alive())
            self.assertNotIn('result', outcomes)
            self.assertEqual(handles_before_return, {
                'job_handle': None,
                'process_handle': None,
                'thread_handle': None,
                'session': None,
            })
            self.assertEqual(backend.retention_calls, 0)
            print(json.dumps({
                'observation': 'blocked_process_setup_before_handle_publication',
                'request_or_startup_deadline_elapsed': True,
                'seconds_past_deadline': round(observed - deadline, 3),
                'caller_still_blocked': caller.is_alive(),
                'session_returned': 'result' in outcomes,
                'handles_available_to_custodian': handles_before_return,
                'retention_calls': backend.retention_calls,
            }, sort_keys=True))
        finally:
            unblock_create.set()
            caller.join(timeout=1.0)

        self.assertFalse(caller.is_alive())
        result = outcomes['result']
        self.assertEqual(result.state, 'not_ready')
        self.assertEqual(result.reason, 'host_creation_returned_after_startup_deadline')
        self.assertIsNone(result.host)
        self.assertTrue(result.startup_operation_returned_after_deadline)
        self.assertIsNotNone(backend.session)
        self.assertEqual(backend.session.members, set())
        print(json.dumps({
            'after_test_unblocked': True,
            'final_state': result.state,
            'final_reason': result.reason,
            'prepared_host_returned': result.host is not None,
            'elapsed_seconds': round(time.monotonic() - started, 3),
        }, sort_keys=True))


if __name__ == '__main__':
    unittest.main(verbosity=2)
