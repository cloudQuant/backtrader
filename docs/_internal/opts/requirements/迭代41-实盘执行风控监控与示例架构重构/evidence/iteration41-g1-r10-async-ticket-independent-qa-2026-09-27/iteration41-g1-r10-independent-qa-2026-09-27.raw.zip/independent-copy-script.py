from pathlib import Path
import hashlib,json,shutil
src=Path(r'D:\temp\iteration41-g1-r10-async-ticket-inert-20260927')
qa=Path(r'D:\temp\iteration41-g1-r10-independent-qa-20260927')
frozen=qa/'frozen-copy'; replay=qa/'replay'
if qa.exists(): raise SystemExit(f'QA root already exists; refusing to overwrite: {qa}')
frozen.mkdir(parents=True); replay.mkdir(parents=True)
manifest_path=src/'r10_manifest.json'; manifest_raw=manifest_path.read_bytes(); m=json.loads(manifest_raw.decode('utf-8'))
expected='da1252e1e25c20530a9cce358c35a1a90f0729dc7f60da85fe2600dd8790f6c3'
sha=lambda b:hashlib.sha256(b).hexdigest()
if sha(manifest_raw)!=expected: raise SystemExit('manifest SHA mismatch')
payload=m['payload_sha256']
if len(payload)!=23: raise SystemExit(f'expected 23 payloads, got {len(payload)}')
records=[]
for rel,want in sorted(payload.items()):
 p=src/rel
 if not p.is_file(): raise SystemExit(f'missing payload {rel}')
 data=p.read_bytes(); got=sha(data)
 if got!=want: raise SystemExit(f'author payload hash mismatch: {rel} {got} != {want}')
 for dest in [frozen,replay]:
  target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 records.append({'path':rel,'bytes':len(data),'sha256':got,'matches_manifest':True})
# preserve the four freeze metadata files in both copies
for name in ['r10_manifest.json','r10_manifest.sha256','r10_receipt.json','r10_receipt.sha256']:
 data=(src/name).read_bytes()
 for dest in [frozen,replay]:(dest/name).write_bytes(data)
if sha(manifest_path.read_bytes())!=expected: raise SystemExit('author manifest changed during verification/copy')
receipt={'schema':'r10_independent_copy_receipt.v1','author_root':str(src),'author_manifest_sha256':expected,
 'payload_count':len(records),'all_payloads_match':all(x['matches_manifest'] for x in records),
 'frozen_copy':str(frozen),'replay_copy':str(replay),'payloads':records}
(qa/'source-copy-verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='payloads'},indent=2))
