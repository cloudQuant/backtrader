import json
import run_r10_trials as r10
row=r10.run_trial("late-intake")
print(json.dumps(row,indent=2))
scenario=(row.get("scenario") or {})
result={
  "schema":"r10_late_intake_negative.v1",
  "mode":"late-intake",
  "ready":row.get("ready"),
  "runner_timeout":row.get("runner_timeout"),
  "exit_code":row.get("exit_code"),
  "request_start_tick_ms":scenario.get("request_start_tick_ms"),
  "deadline_tick_ms":scenario.get("deadline_tick_ms"),
  "caller_submit_return_tick_ms":scenario.get("caller_submit_return_tick_ms"),
  "caller_submit_result":scenario.get("caller_submit_result"),
  "caller_submit_return_before_D":scenario.get("caller_submit_return_before_D"),
  "ticket_unknown_tick_ms":scenario.get("ticket_unknown_tick_ms"),
  "reaper_unknown_lateness_ms":scenario.get("reaper_unknown_lateness_ms"),
  "ticket_state_final":scenario.get("ticket_state_final"),
  "slot_state_final":scenario.get("slot_state_final"),
  "caller_job_empty":scenario.get("caller_job_empty"),
  "broker_exact_exit_and_job_empty":scenario.get("broker_exact_exit_and_job_empty"),
  "worker_job_empty":scenario.get("worker_job_empty"),
  "raw":row,
  "disposition":"BUG_REPRODUCED: after delayed wait to D+50ms, SubmitTicket returns ACCEPTED (0), then broker marks UNKNOWN; production G1 remains closed."
}
open("late-intake-result.json","w",encoding="utf-8").write(json.dumps(result,indent=2)+"\n")
assert row.get("ready") and not row.get("runner_timeout") and row.get("exit_code")==0
assert scenario.get("caller_submit_result")==0
assert scenario.get("caller_submit_return_tick_ms",0)>scenario.get("deadline_tick_ms",0)
assert scenario.get("ticket_state_final")==3 and scenario.get("slot_state_final")==2
assert scenario.get("broker_exact_exit_and_job_empty") and scenario.get("caller_job_empty") and scenario.get("worker_job_empty")
