from pathlib import Path
import difflib, json, shutil, hashlib
qa=Path(r'D:\temp\iteration41-g1-r10-independent-qa-20260927')
probe=qa/'late-intake-probe'; src=qa/'frozen-copy'/'r10_custodian.cpp'
raw=src.read_text(encoding='utf-8')
old='''    Put64(&s->submitStartQpc, Qpc());\n    LONG64 ticket = 0;'''
new='''    if (Get32(&s->requestKind) == 5) {\n        // QA-only negative: make the sole SubmitTicket call after the pre-set D.\n        ULONGLONG deadline = (ULONGLONG)Get64(&s->deadlineTick);\n        while (GetTickCount64() <= deadline + 50) Sleep(1);\n    }\n    Put64(&s->submitStartQpc, Qpc());\n    LONG64 ticket = 0;'''
assert raw.count(old)==1
modified=raw.replace(old,new,1)
old2='''    LONG kind = mode == L"caller-death" ? 2 : mode == L"popen-before" ? 3 : mode == L"popen-after" ? 4 : 1;'''
new2='''    LONG kind = mode == L"caller-death" ? 2 : mode == L"popen-before" ? 3 : mode == L"popen-after" ? 4 : mode == L"late-intake" ? 5 : 1;'''
assert modified.count(old2)==1
modified=modified.replace(old2,new2,1)
out=probe/'r10_late_intake_probe.cpp'; out.write_text(modified,encoding='utf-8',newline='\n')
diff=''.join(difflib.unified_diff(raw.splitlines(True), modified.splitlines(True), fromfile='author-frozen/r10_custodian.cpp', tofile='qa-only/r10_late_intake_probe.cpp'))
(probe/'source-delta.patch').write_text(diff,encoding='utf-8',newline='\n')
for name in ['r10_sacrificial_popen.py','run_r10_trials.py']:
 shutil.copy2(qa/'frozen-copy'/name,probe/name)
(probe/'build-late-intake.bat').write_text('''@echo off\nset "TEMP=D:\\temp\\iteration41-g1-r10-independent-qa-20260927\\late-intake-probe\\.tmp"\nset "TMP=D:\\temp\\iteration41-g1-r10-independent-qa-20260927\\late-intake-probe\\.tmp"\ncall "C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\VC\\Auxiliary\\Build\\vcvars64.bat" >NUL\ncl /nologo /std:c++17 /EHsc /O2 /W4 /Fe:r10_late_intake_probe.exe r10_late_intake_probe.cpp\nexit /b %ERRORLEVEL%\n''',encoding='ascii',newline='')
runner='''import json\nimport run_r10_trials as r10\nrow=r10.run_trial("late-intake")\nprint(json.dumps(row,indent=2))\nscenario=(row.get("scenario") or {})\nresult={\n  "schema":"r10_late_intake_negative.v1",\n  "mode":"late-intake",\n  "ready":row.get("ready"),\n  "runner_timeout":row.get("runner_timeout"),\n  "exit_code":row.get("exit_code"),\n  "request_start_tick_ms":scenario.get("request_start_tick_ms"),\n  "deadline_tick_ms":scenario.get("deadline_tick_ms"),\n  "caller_submit_return_tick_ms":scenario.get("caller_submit_return_tick_ms"),\n  "caller_submit_result":scenario.get("caller_submit_result"),\n  "caller_submit_return_before_D":scenario.get("caller_submit_return_before_D"),\n  "ticket_unknown_tick_ms":scenario.get("ticket_unknown_tick_ms"),\n  "reaper_unknown_lateness_ms":scenario.get("reaper_unknown_lateness_ms"),\n  "ticket_state_final":scenario.get("ticket_state_final"),\n  "slot_state_final":scenario.get("slot_state_final"),\n  "caller_job_empty":scenario.get("caller_job_empty"),\n  "broker_exact_exit_and_job_empty":scenario.get("broker_exact_exit_and_job_empty"),\n  "worker_job_empty":scenario.get("worker_job_empty"),\n  "raw":row,\n  "disposition":"BUG_REPRODUCED: after delayed wait to D+50ms, SubmitTicket returns ACCEPTED (0), then broker marks UNKNOWN; production G1 remains closed."\n}\nopen("late-intake-result.json","w",encoding="utf-8").write(json.dumps(result,indent=2)+"\\n")\nassert row.get("ready") and not row.get("runner_timeout") and row.get("exit_code")==0\nassert scenario.get("caller_submit_result")==0\nassert scenario.get("caller_submit_return_tick_ms",0)>scenario.get("deadline_tick_ms",0)\nassert scenario.get("ticket_state_final")==3 and scenario.get("slot_state_final")==2\nassert scenario.get("broker_exact_exit_and_job_empty") and scenario.get("caller_job_empty") and scenario.get("worker_job_empty")\n'''
(probe/'run_late_intake_probe.py').write_text(runner,encoding='utf-8',newline='\n')
for p in [out,probe/'source-delta.patch',probe/'build-late-intake.bat',probe/'run_late_intake_probe.py']:
 print(p.name,hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size)
