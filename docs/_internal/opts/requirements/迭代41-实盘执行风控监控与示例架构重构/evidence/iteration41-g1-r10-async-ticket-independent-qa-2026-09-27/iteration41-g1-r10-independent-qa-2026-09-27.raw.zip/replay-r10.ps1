$ErrorActionPreference = 'Stop'
$qa = 'D:\temp\iteration41-g1-r10-independent-qa-20260927'
$replay = Join-Path $qa 'replay'
$manifest = Get-Content -Raw -LiteralPath (Join-Path $replay 'r10_manifest.json') | ConvertFrom-Json
$paths = @($manifest.payload_sha256.PSObject.Properties.Name)
$before = @{}
foreach ($rel in $paths) { $p = Join-Path $replay $rel; $before[$rel] = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
$sourceBefore = $before['r10_custodian.cpp']
$runnerBefore = $before['run_r10_trials.py']
$baselineBefore = @{}
Get-ChildItem -File -Recurse (Join-Path $replay 'r9_frozen_baseline') | ForEach-Object {
  $rel = $_.FullName.Substring($replay.Length + 1).Replace('\','/')
  $baselineBefore[$rel] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
}
$console = Join-Path $qa 'independent-replay-console.log'
Push-Location $replay
try { & python .\run_r10_trials.py *> $console; $code = $LASTEXITCODE }
finally { Pop-Location }
$after = @{}
foreach ($rel in $paths) { $p = Join-Path $replay $rel; if (Test-Path -LiteralPath $p) { $after[$rel] = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() } else { $after[$rel] = $null } }
$sourceAfter = $after['r10_custodian.cpp']
$runnerAfter = $after['run_r10_trials.py']
$baselineAfter = @{}
Get-ChildItem -File -Recurse (Join-Path $replay 'r9_frozen_baseline') | ForEach-Object {
  $rel = $_.FullName.Substring($replay.Length + 1).Replace('\','/')
  $baselineAfter[$rel] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
}
$result = [ordered]@{
  schema = 'r10_independent_replay_result.v1'
  replay_root = $replay
  author_manifest_sha256 = 'da1252e1e25c20530a9cce358c35a1a90f0729dc7f60da85fe2600dd8790f6c3'
  runner_exit_code = $code
  source_before_sha256 = $sourceBefore
  source_after_sha256 = $sourceAfter
  runner_before_sha256 = $runnerBefore
  runner_after_sha256 = $runnerAfter
  source_and_runner_unchanged = ($sourceBefore -eq $sourceAfter -and $runnerBefore -eq $runnerAfter)
  frozen_r9_baseline_unchanged = ((ConvertTo-Json -InputObject $baselineBefore -Compress -Depth 20) -ceq (ConvertTo-Json -InputObject $baselineAfter -Compress -Depth 20))
  baseline_before = $baselineBefore
  baseline_after = $baselineAfter
  before_payload_sha256 = $before
  after_payload_sha256 = $after
  console_log = $console
}
$result | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $qa 'independent-replay-result.json') -Encoding UTF8
Get-Content $console
Write-Output "RUNNER_EXIT=$code"
Write-Output "SOURCE_UNCHANGED=$($sourceBefore -eq $sourceAfter) RUNNER_UNCHANGED=$($runnerBefore -eq $runnerAfter)"
Write-Output "R9_BASELINE_UNCHANGED=$((ConvertTo-Json -InputObject $baselineBefore -Compress -Depth 20) -ceq (ConvertTo-Json -InputObject $baselineAfter -Compress -Depth 20))"
if ($code -ne 0 -or $sourceBefore -ne $sourceAfter -or $runnerBefore -ne $runnerAfter) { exit 1 }
