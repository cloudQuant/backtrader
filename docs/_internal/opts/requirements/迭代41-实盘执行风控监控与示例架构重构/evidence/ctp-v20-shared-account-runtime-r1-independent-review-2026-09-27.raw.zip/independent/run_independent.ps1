param(
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
$snapshot = 'D:\temp\iteration41-ctp-account-runtime-v20-r2-freeze-r1-20260927'
$snapshotFull = [System.IO.Path]::GetFullPath($snapshot).TrimEnd('\')
$outputFull = [System.IO.Path]::GetFullPath($OutputDirectory).TrimEnd('\')
if ($outputFull.Equals($snapshotFull, [System.StringComparison]::OrdinalIgnoreCase) -or $outputFull.StartsWith($snapshotFull + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'OutputDirectory must be outside the frozen snapshot'
}
New-Item -ItemType Directory -Force -Path $outputFull | Out-Null
$env:V20_QA_OUTPUT = $outputFull
$env:PYTHONPATH = 'D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\src;D:\q\e\src;D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src;D:\source_code\backtrader;C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926'
$env:BT_API_TEST_METADATA_ROOT = 'C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926'
$env:PYTHONDONTWRITEBYTECODE = '1'
$python = 'D:\temp\iteration41-main-source-qa-20260926\venv\Scripts\python.exe'
$runner = 'D:\temp\iteration41-v20-r1-independent-qa-20260927\independent_run.py'
$stdout = Join-Path $outputFull 'independent.stdout.log'
$stderr = Join-Path $outputFull 'independent.stderr.log'
$proc = Start-Process -FilePath $python -ArgumentList @($runner) -WorkingDirectory $snapshot -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru -Wait
$result = [ordered]@{ exit_code = $proc.ExitCode; python = $python; runner = $runner; working_directory = $snapshot; output_directory = $outputFull }
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outputFull 'process-result.json') -Encoding UTF8
exit $proc.ExitCode
