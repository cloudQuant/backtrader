from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import runpy
import sys

def main():
    SNAPSHOT = Path(r"D:\temp\iteration41-ctp-account-runtime-v20-r2-freeze-r1-20260927").resolve()
    EVIDENCE = Path(r"D:\temp\iteration41-ctp-account-runtime-v20-r2-evidence-final-20260927").resolve()
    EXECUTION = Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\src").resolve()
    SDK = Path(r"D:\q\e\src").resolve()
    BASE = Path(r"D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src").resolve()
    MAIN = Path(r"D:\source_code\backtrader").resolve()
    METADATA = Path(r"C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926").resolve()
    OUTPUT = Path(os.environ["V20_QA_OUTPUT"]).resolve()
    MANIFEST_SHA = "c4a01df5f796d718deb8bd6672ea281421223eea2bf14ec014415ac7ae52fa9c"


    def sha(path: Path) -> str:
        return hashlib.sha256(path.read_bytes()).hexdigest()


    def assert_origin(name: str, path: Path) -> object:
        module = importlib.import_module(name)
        actual = Path(module.__file__).resolve()
        expected = path.resolve()
        if actual != expected:
            raise RuntimeError(f"origin mismatch {name}: {actual} != {expected}")
        print("IMPORT_ORIGIN", name, actual, sha(actual))
        return module


    manifest_path = EVIDENCE / "manifest.json"
    if sha(manifest_path) != MANIFEST_SHA:
        raise RuntimeError("V20 evidence manifest hash mismatch")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    expected: dict[str, dict] = {}
    for entry in manifest["snapshot_python_files"]:
        expected[entry["path"]] = entry
    for entry in manifest["runner_files"]:
        expected[entry["path"]] = entry
    failures = []
    for rel, entry in expected.items():
        path = SNAPSHOT / Path(rel)
        if not path.is_file():
            failures.append(f"missing:{rel}")
            continue
        if path.stat().st_size != entry["bytes"] or sha(path) != entry["sha256"]:
            failures.append(f"mismatch:{rel}")
    actual = {
        path.relative_to(SNAPSHOT).as_posix()
        for path in SNAPSHOT.rglob("*")
        if path.is_file()
    }
    if failures or actual != set(expected):
        raise RuntimeError(f"snapshot manifest mismatch: failures={failures}, extra={sorted(actual-set(expected))}, missing={sorted(set(expected)-actual)}")
    for entry in manifest["evidence_outputs"]:
        path = EVIDENCE / entry["path"]
        if not path.is_file() or path.stat().st_size != entry["bytes"] or sha(path) != entry["sha256"]:
            raise RuntimeError("author evidence output mismatch: " + entry["path"])
    print("MANIFEST_OK", MANIFEST_SHA, "files", len(expected))
    print("EXECUTION_MANIFEST", sha(EXECUTION.parent / "manifest.json"))

    # Match the frozen runner's source-only dependency order while requiring the
    # candidate package to come from this frozen bundle.
    sys.path.insert(0, str(SNAPSHOT))
    for path in (EXECUTION, SDK, BASE, MAIN, METADATA):
        sys.path.append(str(path))

    runtime = assert_origin("backtrader_runtime", SNAPSHOT / "backtrader_runtime" / "__init__.py")
    for short in (
        "ctp_simulation_execution",
        "ctp_managed_action_scope_resolver",
        "ctp_managed_action_authority",
        "ctp_i9_account_session_candidate",
        "ctp_managed_account_runtime_candidate",
    ):
        assert_origin(
            "backtrader_runtime." + short,
            SNAPSHOT / "backtrader_runtime" / (short + ".py"),
        )
    assert_origin("bt_api_execution.store", EXECUTION / "bt_api_execution" / "store.py")
    assert_origin("bt_api_ctp.ctp.client", SDK / "bt_api_ctp" / "ctp" / "client.py")
    assert_origin("bt_api_base", BASE / "bt_api_base" / "__init__.py")
    versions = {
        name: importlib.metadata.version(name)
        for name in ("bt_api_execution", "bt_api_ctp", "bt_api_base", "bt_api_py")
    }
    print("SOURCE_ONLY_METADATA", json.dumps(versions, sort_keys=True), METADATA)
    if versions != {
        "bt_api_execution": "0.2.0",
        "bt_api_ctp": "2.0.4+iteration41.i9",
        "bt_api_base": "0.15.4",
        "bt_api_py": "0.15.5",
    }:
        raise RuntimeError("source-only metadata tuple mismatch")

    import pytest
    original_pytest_main = pytest.main
    junit = OUTPUT / "independent.junit.xml"

    def pytest_main_with_junit(args, plugins=None):
        return original_pytest_main([*args, "--junitxml=" + str(junit)], plugins=plugins)

    pytest.main = pytest_main_with_junit
    test_files = (
        SNAPSHOT / "tests/integration/test_iteration41_ctp_managed_account_runtime_candidate.py",
        SNAPSHOT / "tests/unit/runtime/test_ctp_simulation_execution.py",
    )
    try:
        result = original_pytest_main([
            "-q", "-p", "no:cacheprovider", "--confcutdir=" + str(SNAPSHOT),
            *(str(path) for path in test_files), "--junitxml=" + str(junit),
        ])
    finally:
        pytest.main = original_pytest_main
    if int(result) != 0:
        raise SystemExit(int(result))

    if any(name == "bt_api_ctp.ctp._ctp" or name.endswith("._ctp") for name in sys.modules):
        raise RuntimeError("native CTP extension unexpectedly loaded")
    print("NATIVE_EXTENSION_LOADED", False)

    prefix_roots = {
        "backtrader_runtime": SNAPSHOT / "backtrader_runtime",
        "bt_api_execution": EXECUTION / "bt_api_execution",
        "bt_api_ctp": SDK / "bt_api_ctp",
        "bt_api_base": BASE / "bt_api_base",
        "backtrader": MAIN / "backtrader",
    }
    for name, module in sorted(sys.modules.items()):
        if module is None or not getattr(module, "__file__", None):
            continue
        for prefix, root in prefix_roots.items():
            if name == prefix or name.startswith(prefix + "."):
                path = Path(module.__file__).resolve()
                if not path.is_relative_to(root.resolve()):
                    raise RuntimeError(f"loaded origin outside pinned tree: {name}: {path}")
                print("LOADED_ORIGIN", name, path)
                break
    print("POST_TEST_CTP_ORIGIN_GUARD_OK")

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
