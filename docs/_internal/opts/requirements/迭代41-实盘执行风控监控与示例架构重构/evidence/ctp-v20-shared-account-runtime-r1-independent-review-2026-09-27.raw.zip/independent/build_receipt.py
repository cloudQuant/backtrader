from __future__ import annotations
import hashlib, json, os
from pathlib import Path
import xml.etree.ElementTree as ET

qa = Path(r"D:\temp\iteration41-v20-r1-independent-qa-20260927")
snapshot = Path(r"D:\temp\iteration41-ctp-account-runtime-v20-r2-freeze-r1-20260927")
evidence = Path(r"D:\temp\iteration41-ctp-account-runtime-v20-r2-evidence-final-20260927")
results = qa / "rerun"
diagnostics = qa / "results" / "spawn_runner_diagnostic"
manifest_path = evidence / "manifest.json"
expected_manifest_sha = "c4a01df5f796d718deb8bd6672ea281421223eea2bf14ec014415ac7ae52fa9c"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest_sha = sha(manifest_path)
assert manifest_sha == expected_manifest_sha, manifest_sha
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
expected = {x["path"]: x for x in manifest["snapshot_python_files"] + manifest["runner_files"]}
actual_files = {p.relative_to(snapshot).as_posix() for p in snapshot.rglob("*") if p.is_file()}
assert actual_files == set(expected), (sorted(actual_files - set(expected)), sorted(set(expected) - actual_files))
for rel, ent in expected.items():
    p = snapshot / Path(rel)
    assert p.stat().st_size == ent["bytes"] and sha(p) == ent["sha256"], rel
for ent in manifest["evidence_outputs"]:
    p = evidence / ent["path"]
    assert p.is_file() and p.stat().st_size == ent["bytes"] and sha(p) == ent["sha256"], ent["path"]

stdout_path = results / "independent.stdout.log"
stderr_path = results / "independent.stderr.log"
xml_path = results / "independent.junit.xml"
process_path = results / "process-result.json"
stdout = stdout_path.read_text(encoding="utf-8", errors="replace")
stderr = stderr_path.read_text(encoding="utf-8", errors="replace")
proc = json.loads(process_path.read_text(encoding="utf-8-sig"))
assert proc["exit_code"] == 0
assert "84 passed, 2 xfailed" in stdout
assert "POST_TEST_CTP_ORIGIN_GUARD_OK" in stdout and "NATIVE_EXTENSION_LOADED False" in stdout
assert "MANIFEST_OK " + expected_manifest_sha in stdout
assert "SOURCE_ONLY_METADATA" in stdout
root = ET.parse(xml_path).getroot()
suites = [root] if root.tag == "testsuite" else list(root.findall("testsuite"))
cases = [c for suite in suites for c in suite.findall("testcase")]
failures = sum(int(s.get("failures", "0")) for s in suites)
errors = sum(int(s.get("errors", "0")) for s in suites)
skipped = [c for c in cases if c.find("skipped") is not None]
assert len(cases) == 86 and failures == 0 and errors == 0 and len(skipped) == 2
xfail_cases = [{"node": f'{c.get("classname")}::{c.get("name")}', "reason": c.find("skipped").get("message")} for c in skipped]
assert {x["node"] for x in xfail_cases} == {
    "tests.unit.runtime.test_ctp_simulation_execution::test_profile_config_change_after_final_check_blocks_native_dispatch[submit]",
    "tests.unit.runtime.test_ctp_simulation_execution::test_profile_config_change_after_final_check_blocks_native_dispatch[cancel]",
}

origin_hashes = {
  "backtrader_runtime": "3f071f55a089f8bf54e0338139b7401988a5421607345ffad808ec4ecebcebfb",
  "backtrader_runtime.ctp_simulation_execution": "7618c31d119ba906d49090585623adf91952a67d78c0b81ee38a629651ffb9ec",
  "backtrader_runtime.ctp_managed_action_scope_resolver": "73a02e3e7a41128e95069ccc49dcc35501719a2714b6b4d1e369aeacfa8fd461",
  "backtrader_runtime.ctp_managed_action_authority": "7caed2a83447173ff93755c5561713c2e2f8f410d21ae78e4a07cccd3f681c66",
  "backtrader_runtime.ctp_i9_account_session_candidate": "e80e23200acfb2f3148d914ef5d6076ddd077f39240644df53f4780147d4f2b6",
  "backtrader_runtime.ctp_managed_account_runtime_candidate": "765655cfbe1b4e92959d35b02d0c5d5c203e205816cbafc50891238952d258da",
  "bt_api_execution.store": "75b01d7badbf67043c65082bee8dc27efbe4a309a739ff9f5cadd50f21ccde72",
  "bt_api_ctp.ctp.client": "bf915128c41da83efdff517e3ea711c43d7555406bd831a0dfcd775b64840d1c",
  "bt_api_base": "c0c14cfa1e39a79fef8126a85e82cd7b41d5662e683ff11932fcc58add8116b4",
}
critical_tests = [
 "test_account_family_lock_key_is_mode_independent_and_never_uses_account_key",
 "test_public_factory_uses_one_legacy_account_path_for_both_modes",
 "test_public_factory_fake_login_and_cross_mode_restart_share_one_v20_store",
 "test_public_factory_rejects_existing_legacy_journal_without_rewriting_it",
 "test_nonempty_legacy_journal_without_scope_fails_closed",
 "test_legacy_journal_rejects_v20_execution_store_before_any_write",
]
assert all(any(name in c.get("name", "") for c in cases) for name in critical_tests)

# Candidate source has no inventory/default registry hook: the only references
# under production runtime source are its module definition/docs/export.
rg = __import__("subprocess").run([
  "rg", "-n", "CtpManagedAccountRuntimeCandidate|ctp_managed_account_runtime_candidate",
  str(snapshot / "backtrader_runtime" / "inventory.py"),
  str(snapshot / "backtrader_runtime" / "registry.py"),
  str(snapshot / "backtrader_runtime" / "runner.py"),
], capture_output=True, text=True)
assert rg.returncode == 1, (rg.returncode, rg.stdout, rg.stderr)

receipt = {
  "kind": "independent_read_only_v20_account_runtime_source_qa",
  "result": "PASS_WITH_ACCEPTANCE_LIMITS",
  "manifest_sha256": manifest_sha,
  "snapshot_file_count": len(expected),
  "snapshot_post_run_hash_validation": "all manifested files byte/hash match; no extra/missing files",
  "execution_manifest_sha256": sha(Path(r"D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\manifest.json")),
  "test_result": {"tests": len(cases), "passed": len(cases) - len(skipped) - failures - errors, "xfail": len(skipped), "failed": failures, "errors": errors, "duration_seconds": round(sum(float(s.get("time", "0")) for s in suites), 2)},
  "xfail": xfail_cases,
  "critical_tests_confirmed_in_junit": critical_tests,
  "source_origins_and_sha256": origin_hashes,
  "source_only_metadata": {"bt_api_execution": "0.2.0", "bt_api_ctp": "2.0.4+iteration41.i9", "bt_api_base": "0.15.4", "bt_api_py": "0.15.5"},
  "metadata_root": r"C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926",
  "verified_behaviors": [
    "same account_ref simulation/live resolves to one legacy journal path; same V20 account Store and durable family owner rejects the cross-mode live restart without changing bytes",
    "legacy journal without scope fails closed with bytes unchanged, journal_mode remains delete, and metadata table is not created",
    "existing V20 execution database is rejected by legacy journal before any bytes, SQLite journal mode, or schema objects change",
    "candidate class is absent from default inventory/registry/runner; no default runtime route was added",
    "fake lifecycle calls only authenticate/login; no order/action request; native _ctp module was not loaded",
  ],
  "warnings": [
    "expected missing Windows CTP extension RuntimeWarning; SDK import remained source-only and native extension was absent",
    "existing pytest-asyncio unset fixture loop-scope deprecation warning",
  ],
  "run_command": r"D:\temp\iteration41-v20-r1-independent-qa-20260927\run_independent.ps1 -OutputDirectory <external-output-dir>",
  "artifacts": {p.name: sha(p) for p in [stdout_path, stderr_path, xml_path, process_path, qa / "independent_run.py", qa / "run_independent.ps1", qa / "build_receipt.py"]},
  "initial_runner_diagnostic": {
    "path": str(diagnostics),
    "classification": "QA harness issue only: first audit script executed pytest at import under Windows multiprocessing spawn; after adding a main guard the exact frozen tests passed 84/2. Snapshot/source untouched.",
    "stdout_sha256": sha(diagnostics / "independent.stdout.log"),
    "stderr_sha256": sha(diagnostics / "independent.stderr.log"),
  },
  "acceptance_limits": [
    "source-only metadata shim; this is not installed-wheel consumer acceptance",
    "synthetic temporary test configuration and fake client only; no private config, provider, real native request, or real order/trade was used",
    "two expected xfails retain the open config-change-after-final-check/native-dispatch gap; no trusted config-action broker",
    "this source bundle remains an unregistered candidate; this QA does not authorize live, simulation writes, default runner routing, or deployment",
  ],
  "stderr_sha256": sha(stderr_path),
}
receipt_path = qa / "qa-receipt.json"
receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
# Hash all stable QA artifacts, excluding the hash manifest itself.
artifacts = [receipt_path, stdout_path, stderr_path, xml_path, process_path, qa / "independent_run.py", qa / "run_independent.ps1", qa / "build_receipt.py"]
for p in sorted(diagnostics.iterdir()):
    if p.is_file(): artifacts.append(p)
manifest_out = {str(p.relative_to(qa)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in artifacts}
manifest_file = qa / "artifact-manifest.json"
manifest_file.write_text(json.dumps(manifest_out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print("QA_RECEIPT", receipt_path, sha(receipt_path))
print("ARTIFACT_MANIFEST", manifest_file, sha(manifest_file))
print("TESTS", len(cases), "passed", 84, "xfail", 2, "post_test_origin_guard=True", "snapshot_hashes_verified=True")
