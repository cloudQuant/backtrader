param(
    [Parameter(Mandatory = $true)]
    [string]$OutputDirectory
)
$ErrorActionPreference = 'Stop'
$python = 'D:\temp\iteration41-main-source-qa-20260926\venv\Scripts\python.exe'
$env:PYTHONPATH = 'D:\temp\iteration41_v20_ctp_account_store_freeze_r2_20260927a\src;D:\q\e\src;D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src;D:\source_code\backtrader;C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926'
$env:BT_API_TEST_METADATA_ROOT = 'C:\Users\yunji\AppData\Local\Temp\iteration41-f14-builder-fixed-metadata-20260926'
$env:PYTHONDONTWRITEBYTECODE = '1'
$snapshotRoot = [System.IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') + '\'
$outputRoot = [System.IO.Path]::GetFullPath($OutputDirectory)
if (-not (Test-Path -LiteralPath $outputRoot -PathType Container)) {
    New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
}
$outputRoot = (Resolve-Path -LiteralPath $outputRoot).Path.TrimEnd('\') + '\'
if ($outputRoot.StartsWith($snapshotRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'OutputDirectory must be outside the immutable source snapshot.'
}
$process = Start-Process -FilePath $python -ArgumentList @('.\verify_origins_and_run.py') -WorkingDirectory $PSScriptRoot -RedirectStandardOutput (Join-Path $outputRoot 'pytest.stdout.log') -RedirectStandardError (Join-Path $outputRoot 'pytest.stderr.log') -PassThru -Wait -NoNewWindow
@{ python=$python; snapshot=$snapshotRoot.TrimEnd('\'); output_directory=$outputRoot.TrimEnd('\'); exit_code=$process.ExitCode } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outputRoot 'process-result.json') -Encoding utf8
exit $process.ExitCode
