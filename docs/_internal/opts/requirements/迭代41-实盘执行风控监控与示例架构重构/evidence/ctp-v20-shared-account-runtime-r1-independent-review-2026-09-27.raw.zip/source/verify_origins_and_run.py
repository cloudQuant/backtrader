"""Run the frozen CTP account-runtime focus after exact-origin checks."""
from __future__ import annotations

import importlib
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def main() -> int:
    import pytest
    import backtrader_runtime

    package_path = pathlib.Path(backtrader_runtime.__file__).resolve()
    expected_package_path = (ROOT / "backtrader_runtime" / "__init__.py").resolve()
    if package_path != expected_package_path:
        raise RuntimeError("backtrader_runtime package origin mismatch: " + str(package_path))
    modules = (
        "ctp_simulation_execution",
        "ctp_managed_action_scope_resolver",
        "ctp_managed_action_authority",
        "ctp_i9_account_session_candidate",
        "ctp_managed_account_runtime_candidate",
    )
    for short_name in modules:
        module_name = "backtrader_runtime." + short_name
        expected = ROOT / "backtrader_runtime" / (short_name + ".py")
        module = importlib.import_module(module_name)
        actual = pathlib.Path(module.__file__).resolve()
        if actual != expected.resolve():
            raise RuntimeError("module origin mismatch: " + short_name + " -> " + str(actual))
        print("SOURCE_ORIGIN", short_name, actual)

    test_files = (
        ROOT / "tests/integration/test_iteration41_ctp_managed_account_runtime_candidate.py",
        ROOT / "tests/unit/runtime/test_ctp_simulation_execution.py",
    )
    return int(pytest.main(["-q", "-p", "no:cacheprovider", "--confcutdir=" + str(ROOT), *(str(path) for path in test_files)]))


if __name__ == "__main__":
    raise SystemExit(main())

