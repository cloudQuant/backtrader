# Iteration 41 G6-P/F14 external account actor audit

Status: READ_ONLY_ARCHITECTURE_AUDIT / G6-P F14_STRICT_BLOCKED / G8-P NOT_RUN / NO_WRITE / LIVE_NO_GO.

This receipt captures exact working-tree bytes for the source files listed in source-manifest.json. It is an architecture review, not a source acceptance, test result, provider run, or authorization. No pytest, import of CTP SDK/native module, account/config/credential access, network, or native/provider call was performed. The gateway and transport candidates are dirty, locally developed source and are not treated as pinned or released artifacts.

## Governing contract

The main repository's ADR-41-16 retains the strict F14 gate. A future credential-owning gateway is a design alternative only. It must be the sole usable CTP credential holder and sole network path, serialize all account actions, control old processes and direct clients, and provide a defensible complete/coherent account view. A gateway can address writer routing only if deployed exclusion is independently proven; it does not create a common account snapshot.

Current evidence remains G6-P F14_STRICT_BLOCKED and G8-P NOT_RUN. The F14 protocol has no pinned service implementation wired to the shared runner, Store, or final native call. Its signed-receipt candidate is observation-only. A local token or local assert-before-Req is subject to bypass and revocation races.

## Current call paths and bypasses

1. Backtrader Store/Broker. BtApiBroker.submit/cancel call BtApiStore.submit_order/cancel_order. In btapistore.py, submit_order falls back to _submit_order_legacy when no managed adapter is attached (around lines 7714-7727); cancel_order falls back to _cancel_order_ref_legacy (around lines 7991-8013). _ensure_api_ready accepts injected api/api_cls/config and selects direct SDK or gateway backend (around lines 16395-16453). The legacy route can instantiate a direct client or the old CTP gateway wrapper. These local APIs are reachable independently of the default runtime registration status.

2. Legacy same-process gateway. BtApiStore's gateway backend imports bt_api_py.gateway.client.GatewayClient (around lines 3074-3102 and 16442-16452). GatewayClient.connect defaults gateway_start_local_runtime to true and starts GatewayRuntime in the same process (client.py 68-85). GatewayRuntime's adapter registry selects CtpGatewayAdapter for CTP (runtime.py 32-39); that adapter starts CTP market/trade streams and its order/cancel methods call feed.make_order/feed.cancel_order (ctp_adapter.py 50-91, 151-220). This is a ZeroMQ-shaped API but not an external credential-owning actor.

3. Direct SDK. The current local CTP SDK client exposes submit_order_insert and submit_order_action; each ultimately invokes _native_api.ReqOrderInsert or ReqOrderAction (client.py around lines 4260/4376 and 4591/4698). Any process that can construct/import this client and obtain credentials/session can call it without the new gateway candidate. The API itself does not enforce that all account writes route through an external actor.

4. New bt_api_gateway candidate. GatewayCommandRouter is provider-neutral. Its constructor receives an arbitrary executor and optional admission and writer-authority objects. Non-READ requests fail closed if admission or writer authority is absent, then the router journals locally, claims local writer state, and calls the injected executor (router.py 185-212, 277-358, 360-418). Its local writer authority explicitly coordinates only processes using the same SQLite file (writer_authority.py 1-5). There is no built-in external CTP actor, broker adapter, trusted deployment pin, or authority source. The handler/executor can be wired to a fake or a process-local client; the generic router does not establish that it is the only route.

5. ZMQ transport candidate. Remote TCP requires Curve credentials and a static RemotePrincipalGrant ACL; ZAP-authenticated User-Id selects a grant before invoking the injected handler (server.py 112-187, 225-260, 275-313). This establishes peer authentication and static scope/kind authorization only. WireMessage.sequence and sent_at are client supplied; they are not a service-issued CTP epoch or account snapshot watermark (wire.py 40-90). Local IPC/inproc/loopback uses an injected authenticator. Response status handled/accepted means the handler returned, not that a provider accepted the order. Transport has no durable cross-host epoch, revocation/handoff, or account-state source.

6. Gateway event journal. Events are already-redacted caller-supplied mappings, and snapshots are caller-supplied payloads. capture_snapshot checks that expected_cursor equals the journal's latest event cursor, not that a CTP provider produced all account facts from that cursor or a common provider revision (event_journal.py 1-7, 39-62, 232-310). It is a read-model journal, not account truth.

7. MCP route. Current MCP tools start/cancel local strategy jobs; they are not place/cancel order tools (server.py around lines 454-501). The candidate validator rejects BtApiStore/provider-store references and the worker rechecks candidate source/protected CTP paths before process launch (validation.py 853-910; worker.py 165-198). This narrows the supported candidate-run path but is static candidate validation, not an OS egress boundary, credential custody mechanism, or account writer fence. A local process or separately invoked SDK/Store path can still bypass it where credentials/network access exist.

## Minimal target call chain

``` mermaid
flowchart LR
  Client["Backtrader / strategy / MCP job"] -->|"typed intent only; no CTP credentials"| API["Authenticated actor API"]
  API --> Gate["External account epoch + one-use action admission"]
  Gate --> Snap["Authoritative complete snapshot at one provider revision"]
  Snap --> Journal["Actor-owned durable command/inbox journal"]
  Journal --> Actor["One serialized per-account native owner"]
  Actor -->|"final epoch/risk check and call in same actor boundary"| CTP["CTP MD/TD session and native Req"]
  CTP --> Callback["Same-owner callback inbox and reconciliation"]
  Callback --> Projection["Redacted read-only events/snapshot to clients"]
  Direct["Direct Store / SDK / old local gateway"] -. "credentials and network denied" .-> CTP
```
## Minimum external actor call chain

1. An external per-account actor runs under a distinct service identity. Only it can retrieve usable CTP credentials, create the MD/TD sessions, own the TraderSpi/callback consumer, and reach CTP write endpoints. Backtrader strategy/MCP/client processes receive no credentials, CTP SDK import path, or native client handle—only a typed authenticated client port.
2. Deployment enforces sole access: credential vault ACL, host/service account restrictions, and network/firewall/application policy deny direct writes from other users, hosts, terminals, old processes, and SDK clients. A local database lease or signed local DTO is not this boundary.
3. The actor obtains a monotonic account epoch/fencing generation from a cross-host authority, authenticates that authority with a deployment-pinned trust root, and persists a one-use action claim and idempotency key in its server-owned durable journal. Lease expiry or process restart cannot by itself authorize takeover. Revoke/handoff is serialized by the same account actor and invalidates older generations at the actual final provider call boundary.
4. Before dispatch, the actor uses an authoritative complete account snapshot tied to the same account, TradingDay, actor epoch, provider version/watermark, and validity window. Required coverage is funds, all account open orders (including foreign/manual/other strategy orders), trades, and positions, with pagination/completeness and deterministic reconciliation. Independent CTP query bIsLast flags do not prove a common snapshot. If CTP exposes no common version, the provider/external service must supply a trusted equivalent; otherwise strict F14 stays blocked.
5. One actor command loop does the final policy/risk/admission check, exact command claim, epoch check, native call, and callback ingestion under a single serialized account owner. The client never does local assert_active then direct Req. A native immediate return or transport reply is not provider acknowledgement. Unknown outcomes remain fenced; never automatically retry.
6. The same actor records all callback/order/trade facts and publishes redacted read-only strategy projections. Shutdown/restart waits for typed native stop and callback drain/reconciliation evidence. A process-local close, queue-empty observation, SQLite trigger, or timeout does not prove that older native work has ceased.

## External facts still required

- Service identity, deployment-pinned authentication/TLS/key rotation, durable monotonic cross-host epoch, and atomic revoke/handoff semantics.
- Operational proof that only the actor can access the credentials and CTP write network path; direct SDK, old local gateway, other OS users/hosts and break-glass paths are excluded or revoke the actor first.
- One service-side source for full account snapshot and all collections tied to one provider version/watermark, including pagination and completeness. CTP request terminal callbacks alone do not provide this.
- Service-side durable idempotency and account event/callback inbox, stop/drain, crash recovery, late callback handling, and no-resend for unknown.
- Cross-host adversarial evidence: competing writer rejected; stale epoch after takeover rejected at final dispatch; revoke racing a paused dispatch; actor crash after claim/before native call; crash after native call/before receipt; direct client denied; event gaps/unknown order/trade freeze; consistent snapshot under provider activity.
- Independently reviewed production-specific policy, risk, monitor, approval and recovery, separate from SimNow; G8-P is not run/accepted.

## Offline work that can be done first

- Define a transport-neutral AccountActorPort for typed submit/cancel/read-snapshot requests. Keep it unavailable by default; reject CTP or CTP-gateway Store construction unless the explicit actor client port is present, and do not pass a native CTP client into strategy/client processes.
- Add Store/Broker negative tests showing missing/expired/revoked actor capability rejects before client construction and before every direct/gateway fallback. Include injected api/api_cls, SDK mode and backend=gateway; assert zero ReqOrderInsert/ReqOrderAction calls.
- Add direct SDK boundary tests and architecture checks that the strategy-side runtime never receives a native client/credential object. These tests document local wiring; they cannot prove hostile in-process isolation.
- Add transport tests for wrong peer key, revoked principal mapping, wrong account/strategy/kind, stale service epoch, client-chosen sequence/sent_at, replay, time skew, oversized/redacted payload, response backpressure, and request/response confusion. Require executor to be a code-owned actor service implementation at composition root, not an arbitrary client callback.
- Add fake service tests for two clients/hosts racing one account, one-use action claim, crash/UNKNOWN/no resend, final dispatch vs revocation, event gaps, snapshot version mismatch/incomplete page/foreign open order, and restart/drain. Keep these explicitly fake-only.
- Keep MCP candidate validation tests as defense in depth; add tests that aliases/dynamic imports/worker environment cannot supply the CTP SDK or protected config. For real exclusion, use OS/network controls and separate-service tests rather than claiming an AST test is sufficient.

## Source state and method

Current main repo HEAD: ad2c142b9a8b42cede85886528c681abdfcb8096. Relevant Store/Broker, runtime/F14 and docs files include dirty or untracked worktree bytes. Gateway submodule HEAD: 44fd2fe26b51f1d8b573c84415a6cff660f33dea, but its README is modified and source/tests/pyproject are untracked; the transport ZMQ directory is untracked under parent bt_api_py HEAD d3674e19a11b9f35f19ae756899bcf18854c8c46. CTP SDK submodule HEAD is ce1edd60785eb4c66fefa16a994a66946a1e068f with modified client.py. The old SDK gateway files are from local repo HEAD 7a5335017bffff35d433bdb8d475a66e50aa50f6. MCP repo HEAD is ad6312a11c2fe7ff9a4c3fcfcfab5037a951b58c with relevant source modifications and an untracked boundary test. Exact file sizes and byte hashes are in source-manifest.json. No tests were run in this audit.

