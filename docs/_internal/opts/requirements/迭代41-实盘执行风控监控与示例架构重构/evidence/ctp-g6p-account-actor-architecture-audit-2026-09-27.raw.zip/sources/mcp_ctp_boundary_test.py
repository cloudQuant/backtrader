from __future__ import annotations

import os
import socket
import stat
from pathlib import Path
from types import SimpleNamespace

import pytest
from conftest import canonical_spec

from backtrader_mcp import protected_paths, validation, worker
from backtrader_mcp.errors import Conflict, InvalidRequest
from backtrader_mcp.process_control import candidate_network_isolation_status
from backtrader_mcp.protected_paths import (
    assert_runtime_path_safe,
    capture_target_path_identity,
    revalidate_target_path_identity,
)
from backtrader_mcp.state import StateStore
from backtrader_mcp.validation import validate_sources


@pytest.mark.parametrize(
    "source",
    [
        "import backtrader as bt\nprovider = bt.stores\n",
        "import backtrader as bt\nbt.stores.BtApiStore(provider='ctp_gateway')\n",
        "import backtrader as bt\nstores = bt.stores\nstore = stores.BtApiStore\n",
        "from backtrader.stores import BtApiStore\nBtApiStore()\n",
        "import backtrader as bt\ngetattr(bt, 'stores').BtApiStore()\n",
        'import backtrader as bt\nexec("bt.stores.BtApiStore()")\n',
    ],
)
def test_validator_rejects_provider_store_capabilities(source):
    report = validate_sources({"strategy.py": source})

    assert report["status"] == "failed"
    assert any(
        item["code"] in {"live_trading", "blocked_import", "blocked_call"}
        for item in report["diagnostics"]
    )


def _fail_if_network_is_attempted(*_args, **_kwargs):
    pytest.fail("validation/preparation unexpectedly attempted network access")


def test_provider_draft_fails_validation_before_any_job_or_network(registered_dataset, monkeypatch):
    service, dataset = registered_dataset
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)

    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    snapshot = service.get_strategy_draft(draft["draft_id"])
    source = snapshot["files"]["strategy.py"] + (
        "\nimport backtrader as bt\nstore = bt.stores.BtApiStore(provider='ctp_gateway')\n"
    )
    updated = service.update_strategy_draft(
        draft["draft_id"],
        "strategy.py",
        source,
        snapshot["revision"],
        snapshot["manifest"]["strategy.py"],
    )
    validation = service.validate_strategy_draft(draft["draft_id"], updated["revision"])

    assert validation["report"]["status"] == "failed"
    assert any(item["code"] == "live_trading" for item in validation["report"]["diagnostics"])
    jobs_before = service.state.list("job")
    with pytest.raises(Conflict):
        service.prepare_strategy_run(
            draft["draft_id"],
            validation["validation_token"],
            dataset["dataset_id"],
            "default",
            30,
            "runonce",
            "ctp-provider-draft-run-rejected",
        )
    assert service.state.list("job") == jobs_before
    assert service.state.list("run_plan") == []


@pytest.mark.parametrize(
    "path",
    [
        r"C:\source_code\backtrader\examples\013_3_sa_midfreq_simnow\runtime-ctp-private\config.yaml",
        "c:/SOURCE_CODE/backtrader/examples/013_3_sa_midfreq_simnow/RUNTIME-CTP-PRIVATE/config.yaml",
        r"\\server\share\backtrader\examples\013_3_sa_midfreq_simnow\runtime-ctp-private\config.yaml",
    ],
    ids=["drive-backslashes", "drive-forward-slashes-casefold", "unc"],
)
def test_validator_rejects_literal_protected_ctp_config_via_csv_feed(path):
    source = (
        "import backtrader as bt\n"
        f"feed = bt.feeds.GenericCSVData(dataname={path!r})\n"
        "feed.start()\n"
        "first_line = feed.f.readline()\n"
    )

    report = validate_sources({"strategy.py": source})

    assert report["status"] == "failed"
    assert any(item["code"] == "protected_ctp_path" for item in report["diagnostics"])


def test_validator_allows_ordinary_windows_csv_path():
    path = r"D:\market\prices.csv"
    report = validate_sources(
        {
            "strategy.py": (
                "import backtrader as bt\n"
                f"feed = bt.feeds.GenericCSVData(dataname={path!r})\n"
            )
        }
    )

    assert report["status"] == "passed"


def test_validator_rejects_path_resolved_through_reparse_alias(monkeypatch):
    protected = Path(
        r"C:\synthetic\examples\013_3_sa_midfreq_simnow\runtime-ctp-private\config.yaml"
    )
    monkeypatch.setattr(validation.Path, "resolve", lambda self, strict=False: protected)
    report = validate_sources(
        {"strategy.py": "import backtrader as bt\nfeed = bt.feeds.GenericCSVData(dataname='R:/market/alias.csv')\n"}
    )

    assert report["status"] == "failed"
    assert any(item["code"] == "protected_ctp_path" for item in report["diagnostics"])


def test_worker_blocks_protected_ctp_candidate_before_network_or_popen(tmp_path, monkeypatch):
    runtime = tmp_path / "candidate-runtime"
    package = runtime / "backtrader"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "version.py").write_text("version = '0.0'\n", encoding="utf-8")
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    state.put(
        "job",
        "job-ctp-path",
        {"job_id": "job-ctp-path", "state": "RUNNING", "runtime_root": str(runtime)},
    )
    draft_root = tmp_path / "draft"
    draft_root.mkdir()
    (draft_root / "strategy.py").write_text(
        "import backtrader as bt\n"
        + "feed = bt.feeds.GenericCSVData(dataname=r'"
        + r"C:\source_code\backtrader\examples\013_3_sa_midfreq_simnow\runtime-ctp-private\config.yaml"
        + "')\nfeed.start()\nfeed.f.readline()\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(
        worker.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("candidate process started before the CTP path gate"),
    )
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)

    result = worker._execute_mode(
        state,
        "job-ctp-path",
        {"runtime_root": str(runtime), "timeout_seconds": 30},
        tmp_path / "jobs" / "job-ctp-path",
        "runonce",
        draft_root,
        draft_root / "run.py",
        {},
        [],
        "",
        {},
        0.0,
        "",
        None,
        "",
        ["strategy.py"],
    )

    assert result == 2
    assert state.get("job", "job-ctp-path")["state"] == "FAILED"
    assert not (tmp_path / "jobs" / "job-ctp-path").exists()


def test_worker_rechecks_source_at_candidate_popen_boundary(tmp_path, monkeypatch):
    runtime = tmp_path / "candidate-runtime"
    package = runtime / "backtrader"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "version.py").write_text("version = '0.0'\n", encoding="utf-8")
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    state.put(
        "job",
        "job-ctp-race",
        {"job_id": "job-ctp-race", "state": "RUNNING", "runtime_root": str(runtime)},
    )
    draft_root = tmp_path / "draft"
    draft_root.mkdir()
    strategy_path = draft_root / "strategy.py"
    market_path = r"D:\market\prices.csv"
    strategy_path.write_text(
        "import backtrader as bt\n"
        f"feed = bt.feeds.GenericCSVData(dataname={market_path!r})\n",
        encoding="utf-8",
    )
    protected_source = (
        "import backtrader as bt\n"
        "feed = bt.feeds.GenericCSVData(dataname=r'"
        + r"C:\source_code\backtrader\examples\013_3_sa_midfreq_simnow\runtime-ctp-private\config.yaml"
        + "')\n"
    )
    real_gate = worker._protected_ctp_candidate_error
    gate_calls = 0

    def replace_after_first_check(root, editable_files):
        nonlocal gate_calls
        gate_calls += 1
        if gate_calls == 2:
            strategy_path.write_text(protected_source, encoding="utf-8")
        return real_gate(root, editable_files)

    monkeypatch.setattr(worker, "_protected_ctp_candidate_error", replace_after_first_check)
    monkeypatch.setattr(
        worker.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("candidate process started after a source race"),
    )
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)
    job_root = tmp_path / "jobs" / "job-ctp-race"
    job_root.mkdir(parents=True)

    result = worker._execute_mode(
        state,
        "job-ctp-race",
        {"runtime_root": str(runtime), "timeout_seconds": 30},
        job_root,
        "runonce",
        draft_root,
        draft_root / "run.py",
        {},
        [],
        "",
        {},
        0.0,
        "",
        None,
        "",
        ["strategy.py"],
    )

    assert result == 2
    assert gate_calls == 2
    assert state.get("job", "job-ctp-race")["state"] == "FAILED"


def test_prepare_and_target_listing_reject_private_preimages_without_reads_or_mutation(
    registered_dataset, monkeypatch, tmp_path
):
    service, dataset = registered_dataset
    target = service.settings.target_roots["strategies"]
    target.mkdir(parents=True, exist_ok=True)
    managed = target / "managed"
    managed.mkdir()
    marker = "private-preimage-must-never-leave-disk"
    config = managed / "config.yaml"
    secrets = managed / "secrets.yaml"
    config.write_text(f"account: {marker}\n", encoding="utf-8")
    secrets.write_text(f"password: {marker}\n", encoding="utf-8")
    original = {path: path.read_bytes() for path in (config, secrets)}

    def fail_if_tree_is_hashed(_path):
        pytest.fail("private target preimage was hashed before rejection")

    monkeypatch.setattr("backtrader_mcp.changes._tree_manifest", fail_if_tree_is_hashed)
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)

    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    changes_before = service.state.list("change")

    with pytest.raises(InvalidRequest) as prepare_error:
        service.prepare_strategy_changes(
            draft["draft_id"],
            validation["validation_token"],
            "strategies",
            "managed",
            {},
            "private-preimage-rejected",
        )
    with pytest.raises(InvalidRequest) as listing_error:
        service.list_target_tree("strategies", "managed")

    assert marker not in str(prepare_error.value)
    assert marker not in str(listing_error.value)
    assert all(path.read_bytes() == content for path, content in original.items())
    assert service.state.list("change") == changes_before
    assert not list(target.glob(".backtrader-mcp-*.stage"))
    assert not list(target.glob(".backtrader-mcp-*.backup"))


def test_change_target_rejects_hardlink_alias_to_private_config_before_hashing(
    registered_dataset, monkeypatch, tmp_path
):
    service, _dataset = registered_dataset
    target_root = service.settings.target_roots["strategies"]
    target = target_root / "managed-hardlink"
    target.mkdir(parents=True)

    # This is synthetic test data only. A regular filename must not make a
    # hard-linked private config eligible for ChangeService tree hashing.
    private_config = tmp_path / "runtime-ctp-private" / "config.yaml"
    private_config.parent.mkdir()
    private_config.write_text("synthetic secret marker\n", encoding="utf-8")
    os.link(private_config, target / "strategy.py")

    def reject_hash(_path):
        pytest.fail("hard-linked private config was hashed before rejection")

    monkeypatch.setattr("backtrader_mcp.changes.file_hash", reject_hash)

    with pytest.raises(InvalidRequest, match="hard-linked"):
        service.list_target_tree("strategies", "managed-hardlink")


def test_target_identity_recheck_rejects_private_config_added_after_initial_scan(
    tmp_path, monkeypatch
):
    target = tmp_path / "strategies" / "managed"
    target.mkdir(parents=True)
    (target / "strategy.py").write_text("synthetic strategy\n", encoding="utf-8")
    state_root = tmp_path / "state"
    runtime_root = tmp_path / "runtime"
    identity = capture_target_path_identity(
        target,
        state_root=state_root,
        runtime_roots=(runtime_root,),
    )

    marker = "synthetic private config marker"
    (target / "config.yaml").write_text(f"account: {marker}\n", encoding="utf-8")

    def reject_hash(_path):
        pytest.fail("target was hashed before the identity recheck rejected its config")

    monkeypatch.setattr("backtrader_mcp.changes.file_hash", reject_hash)
    with pytest.raises(InvalidRequest, match="private configuration") as error:
        revalidate_target_path_identity(
            identity,
            state_root=state_root,
            runtime_roots=(runtime_root,),
        )
    assert marker not in str(error.value)


def test_target_identity_recheck_rejects_directory_replacement(tmp_path):
    target = tmp_path / "strategies" / "managed"
    target.mkdir(parents=True)
    (target / "strategy.py").write_text("synthetic strategy\n", encoding="utf-8")
    state_root = tmp_path / "state"
    runtime_root = tmp_path / "runtime"
    identity = capture_target_path_identity(
        target,
        state_root=state_root,
        runtime_roots=(runtime_root,),
    )

    moved = target.with_name("managed-original")
    target.rename(moved)
    target.mkdir()
    (target / "strategy.py").write_text("synthetic strategy\n", encoding="utf-8")

    with pytest.raises(InvalidRequest, match="identity changed"):
        revalidate_target_path_identity(
            identity,
            state_root=state_root,
            runtime_roots=(runtime_root,),
        )


@pytest.mark.parametrize("race", ["replacement", "reparse", "hardlink"])
def test_change_prepare_revalidates_target_before_hashing_raced_tree(
    registered_dataset, monkeypatch, tmp_path, race
):
    import backtrader_mcp.changes as changes_module

    service, dataset = registered_dataset
    target_root = service.settings.target_roots["strategies"]
    target = target_root / f"managed-{race}"
    target.mkdir(parents=True)
    (target / "strategy.py").write_text("synthetic strategy\n", encoding="utf-8")
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    original_revalidate = changes_module.revalidate_target_path_identity
    original_is_reparse = protected_paths._is_reparse_point
    raced = False
    simulate_reparse = {"enabled": False}
    target_metadata = target.lstat()

    def is_reparse(metadata):
        if (
            simulate_reparse["enabled"]
            and metadata.st_dev == target_metadata.st_dev
            and metadata.st_ino == target_metadata.st_ino
        ):
            return True
        return original_is_reparse(metadata)

    def race_before_revalidation(identity, *, state_root, runtime_roots):
        nonlocal raced
        if not raced:
            raced = True
            if race == "replacement":
                moved = target.with_name(target.name + "-old")
                target.rename(moved)
                target.mkdir()
                (target / "config.yaml").write_text(
                    "synthetic private marker\n", encoding="utf-8"
                )
            elif race == "hardlink":
                synthetic_config = tmp_path / "synthetic-private" / "config.yaml"
                synthetic_config.parent.mkdir()
                synthetic_config.write_text("synthetic secret\n", encoding="utf-8")
                (target / "strategy.py").unlink()
                os.link(synthetic_config, target / "strategy.py")
            else:
                simulate_reparse["enabled"] = True
        return original_revalidate(
            identity,
            state_root=state_root,
            runtime_roots=runtime_roots,
        )

    monkeypatch.setattr(changes_module, "revalidate_target_path_identity", race_before_revalidation)
    monkeypatch.setattr(protected_paths, "_is_reparse_point", is_reparse)
    monkeypatch.setattr(
        changes_module,
        "file_hash",
        lambda _path: pytest.fail("raced target was hashed before identity revalidation"),
    )

    with pytest.raises(InvalidRequest):
        service.prepare_strategy_changes(
            draft["draft_id"],
            validation["validation_token"],
            "strategies",
            target.name,
            {},
            f"race-{race}",
        )

    assert raced
    assert service.state.list("change") == []


def test_apply_revalidates_target_before_consuming_approval_or_staging(
    registered_dataset, monkeypatch
):
    import backtrader_mcp.changes as changes_module

    service, dataset = registered_dataset
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    prepared = service.prepare_strategy_changes(
        draft["draft_id"],
        validation["validation_token"],
        "strategies",
        "managed-apply-race",
        {},
        "prepare-apply-race",
    )
    approval = service.changes.approve_change(prepared["change_set_id"], prepared["change_token"])
    target = service.settings.target_roots["strategies"] / "managed-apply-race"
    original_revalidate = changes_module.revalidate_target_path_identity
    revalidations = 0

    def insert_private_config(identity, *, state_root, runtime_roots):
        nonlocal revalidations
        revalidations += 1
        if revalidations == 2:
            target.mkdir()
            (target / "config.yaml").write_text(
                "synthetic private marker\n", encoding="utf-8"
            )
        return original_revalidate(
            identity,
            state_root=state_root,
            runtime_roots=runtime_roots,
        )

    monkeypatch.setattr(changes_module, "revalidate_target_path_identity", insert_private_config)
    with pytest.raises(InvalidRequest, match="private configuration"):
        service.apply_strategy_changes(
            prepared["change_set_id"],
            prepared["change_token"],
            approval["approval_id"],
            "apply-private-config-race",
        )

    approval_row = next(
        row
        for row in service.state.list_approvals()
        if row["approval_id"] == approval["approval_id"]
    )
    assert revalidations == 2
    assert approval_row["used_at"] is None
    assert not list(target.parent.glob(".backtrader-mcp-*.stage"))
    assert not list(target.parent.glob(".backtrader-mcp-*.backup"))


def test_worker_runtime_revalidation_blocks_private_config_race_before_payload_load(
    tmp_path, monkeypatch
):
    runtime = tmp_path / "candidate-runtime"
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    state.put(
        "job",
        "job-race",
        {
            "job_id": "job-race",
            "state": "QUEUED",
            "runtime_root": str(runtime),
            "draft_id": "draft-never-load",
            "dataset_id": "dataset-never-load",
        },
    )
    original_revalidate = worker.revalidate_runtime_path_identity
    injected = False

    def inject_private_config(identity, *, state_root, target_roots):
        nonlocal injected
        if not injected:
            injected = True
            private_config = (
                runtime
                / "examples"
                / "case"
                / "runtime-ctp-private"
                / "config.yaml"
            )
            private_config.parent.mkdir(parents=True)
            private_config.write_text("synthetic private marker\n", encoding="utf-8")
        return original_revalidate(
            identity,
            state_root=state_root,
            target_roots=target_roots,
        )

    original_get = StateStore.get

    def reject_payload_load(store, kind, identifier):
        if kind in {"draft", "dataset"}:
            pytest.fail("worker loaded job payload before runtime identity revalidation")
        return original_get(store, kind, identifier)

    monkeypatch.setattr(worker, "revalidate_runtime_path_identity", inject_private_config)
    monkeypatch.setattr(StateStore, "get", reject_payload_load)

    assert worker.run_worker(state_root, "job-race") == 2
    assert injected
    assert original_get(state, "job", "job-race")["state"] == "FAILED"


def test_prepare_run_revalidates_runtime_after_capture_before_provenance(
    registered_dataset, monkeypatch, tmp_path
):
    import backtrader_mcp.jobs as jobs_module

    service, dataset = registered_dataset
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    runtime = tmp_path / "candidate-runtime"
    package = runtime / "backtrader"
    package.mkdir(parents=True)
    (package / "version.py").write_text("version = 'synthetic'\n", encoding="utf-8")
    service.settings.runtimes["default"] = runtime
    monkeypatch.setattr(jobs_module, "require_cloudquant_runtime", lambda path: path)
    monkeypatch.setattr(jobs_module, "runtime_git_commit", lambda _path: None)
    original_revalidate = jobs_module.revalidate_runtime_path_identity
    injected = False

    def inject_private_config(identity, *, state_root, target_roots):
        nonlocal injected
        if not injected:
            injected = True
            private_config = (
                runtime
                / "examples"
                / "case"
                / "runtime-ctp-private"
                / "config.yaml"
            )
            private_config.parent.mkdir(parents=True)
            private_config.write_text("synthetic private marker\n", encoding="utf-8")
        return original_revalidate(
            identity,
            state_root=state_root,
            target_roots=target_roots,
        )

    monkeypatch.setattr(jobs_module, "revalidate_runtime_path_identity", inject_private_config)
    with pytest.raises(InvalidRequest, match="private configuration"):
        service.prepare_strategy_run(
            draft["draft_id"],
            validation["validation_token"],
            dataset["dataset_id"],
            "default",
            30,
            "runonce",
            "runtime-config-race-rejected",
        )

    assert injected
    assert service.state.list("run_plan") == []
    assert service.state.list("job") == []


def test_change_target_cannot_overlap_registered_runtime_without_creating_paths(registered_dataset):
    service, dataset = registered_dataset
    runtime = service.settings.runtimes["default"]
    missing = runtime / "must-not-be-created-by-change-service"
    service.settings.target_roots["runtime-target"] = runtime

    with pytest.raises(InvalidRequest, match="protected runtime"):
        service.list_target_tree("runtime-target", missing.name)
    assert not missing.exists()

    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    with pytest.raises(InvalidRequest, match="protected runtime"):
        service.prepare_strategy_changes(
            draft["draft_id"],
            validation["validation_token"],
            "runtime-target",
            missing.name,
            {},
            "runtime-overlap-rejected",
        )
    assert not missing.exists()
    assert service.state.list("change") == []


def test_apply_rechecks_target_before_consuming_approval_or_replacing_config(registered_dataset):
    service, dataset = registered_dataset
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    prepared = service.prepare_strategy_changes(
        draft["draft_id"],
        validation["validation_token"],
        "strategies",
        "managed",
        {},
        "prepare-before-private-config-appears",
    )
    approval = service.changes.approve_change(prepared["change_set_id"], prepared["change_token"])
    target = service.settings.target_roots["strategies"] / "managed"
    target.mkdir()
    config = target / "config.yaml"
    original = "account: private-value-must-remain\n"
    config.write_text(original, encoding="utf-8")

    with pytest.raises(InvalidRequest, match="private configuration"):
        service.apply_strategy_changes(
            prepared["change_set_id"],
            prepared["change_token"],
            approval["approval_id"],
            "apply-after-private-config-appears",
        )

    approval_row = next(
        row
        for row in service.state.list_approvals()
        if row["approval_id"] == approval["approval_id"]
    )
    assert approval_row["used_at"] is None
    assert config.read_text(encoding="utf-8") == original
    assert not list(target.glob(".backtrader-mcp-*.stage"))
    assert not list(target.glob(".backtrader-mcp-*.backup"))


def test_run_plan_rejects_runtime_overlapping_a_configured_private_target(
    registered_dataset, monkeypatch, tmp_path
):
    service, dataset = registered_dataset
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    # Use an empty isolated path so this assertion reaches the overlap guard.
    # The shared Backtrader checkout may itself contain private CTP runtime
    # files, which must be rejected by the earlier private-content guard.
    runtime_root = tmp_path / "registered-runtime"
    service.settings.runtimes["default"] = runtime_root
    service.settings.target_roots["private-runtime-target"] = runtime_root
    # This case isolates path protection; the real provenance gate is covered
    # by the Backtrader runtime-policy tests.
    monkeypatch.setattr("backtrader_mcp.jobs.require_cloudquant_runtime", lambda path: path)

    with pytest.raises(InvalidRequest, match="overlaps private strategy or state paths"):
        service.prepare_strategy_run(
            draft["draft_id"],
            validation["validation_token"],
            dataset["dataset_id"],
            "default",
            30,
            "runonce",
            "private-runtime-run-rejected",
        )
    assert service.state.list("run_plan") == []
    assert service.state.list("job") == []


def test_prepare_run_rejects_private_runtime_before_provenance_or_plan_write(
    registered_dataset, monkeypatch, tmp_path
):
    service, dataset = registered_dataset
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    runtime = tmp_path / "candidate-runtime"
    private_config = (
        runtime / "examples" / "013_3_sa_midfreq_simnow" / "runtime-ctp-private" / "config.yaml"
    )
    private_config.parent.mkdir(parents=True)
    private_config.write_bytes(b"")
    service.settings.runtimes["default"] = runtime
    monkeypatch.setattr(
        "backtrader_mcp.jobs.require_cloudquant_runtime",
        lambda _path: pytest.fail("provenance inspection ran before the private-path guard"),
    )

    with pytest.raises(InvalidRequest, match="private configuration"):
        service.prepare_strategy_run(
            draft["draft_id"],
            validation["validation_token"],
            dataset["dataset_id"],
            "default",
            30,
            "runonce",
            "private-runtime-prepare-rejected",
        )

    assert service.state.list("run_plan") == []
    assert service.state.list("job") == []


def test_start_run_rechecks_private_runtime_before_approval_or_child_start(
    registered_dataset, monkeypatch, tmp_path
):
    service, dataset = registered_dataset
    runtime = tmp_path / "candidate-runtime"
    package = runtime / "backtrader"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "version.py").write_text("version = '0.0'\n", encoding="utf-8")
    service.settings.runtimes["default"] = runtime
    monkeypatch.setattr("backtrader_mcp.jobs.require_cloudquant_runtime", lambda path: path)
    monkeypatch.setattr("backtrader_mcp.jobs.runtime_git_commit", lambda _path: None)
    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    plan = service.prepare_strategy_run(
        draft["draft_id"],
        validation["validation_token"],
        dataset["dataset_id"],
        "default",
        30,
        "runonce",
        "private-runtime-start-prepare",
    )
    approval = service.jobs.approve_run_plan(plan["run_plan_id"], plan["run_token"])
    private_config = (
        runtime / "examples" / "013_3_sa_midfreq_simnow" / "runtime-ctp-private" / "config.yaml"
    )
    private_config.parent.mkdir(parents=True)
    private_config.write_bytes(b"")
    monkeypatch.setattr(
        "backtrader_mcp.jobs.subprocess.Popen",
        lambda *_args, **_kwargs: pytest.fail("worker subprocess started before the guard"),
    )

    with pytest.raises(InvalidRequest, match="private configuration"):
        service.start_strategy_run(
            plan["run_plan_id"],
            plan["run_token"],
            approval["approval_id"],
            "private-runtime-start-rejected",
        )

    approval_row = next(
        row
        for row in service.state.list_approvals()
        if row["approval_id"] == approval["approval_id"]
    )
    assert approval_row["used_at"] is None
    assert service.state.list("job") == []


def test_worker_rechecks_private_runtime_immediately_before_candidate_start(tmp_path, monkeypatch):
    runtime = tmp_path / "candidate-runtime"
    private_config = (
        runtime / "examples" / "013_3_sa_midfreq_simnow" / "runtime-ctp-private" / "config.yaml"
    )
    private_config.parent.mkdir(parents=True)
    private_config.write_bytes(b"")
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    job_root = tmp_path / "jobs" / "job-1"
    monkeypatch.setattr(
        worker.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("candidate subprocess started before the guard"),
    )

    with pytest.raises(InvalidRequest, match="private configuration"):
        worker._execute_mode(
            state,
            "job-1",
            {"runtime_root": str(runtime)},
            job_root,
            "runonce",
            tmp_path / "draft",
            tmp_path / "draft" / "run.py",
            {},
            [],
            "",
            {},
            0.0,
            "",
            None,
            "",
            [],
        )

    assert not job_root.exists()


def test_worker_refuses_private_runtime_before_loading_draft_or_dataset(tmp_path, monkeypatch):
    runtime = tmp_path / "candidate-runtime"
    private_config = runtime / "examples" / "case" / "runtime-ctp-private" / "config.yaml"
    private_config.parent.mkdir(parents=True)
    private_config.write_bytes(b"")
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    state.put(
        "job",
        "job-1",
        {"job_id": "job-1", "state": "QUEUED", "runtime_root": str(runtime)},
    )
    original_get = StateStore.get

    def reject_payload_load(store, kind, identifier):
        if kind in {"draft", "dataset"}:
            raise AssertionError("worker loaded job payload before runtime guard")
        return original_get(store, kind, identifier)

    monkeypatch.setattr(StateStore, "get", reject_payload_load)

    assert worker.run_worker(state_root, "job-1") == 2
    assert original_get(state, "job", "job-1")["state"] == "FAILED"


def test_worker_fails_closed_before_payload_load_when_os_isolation_is_missing(
    tmp_path, monkeypatch
):
    runtime = tmp_path / "candidate-runtime"
    runtime.mkdir()
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    state.put(
        "job",
        "job-isolation-unavailable",
        {
            "job_id": "job-isolation-unavailable",
            "state": "QUEUED",
            "runtime_root": str(runtime),
            "draft_id": "must-not-load",
            "dataset_id": "must-not-load",
        },
    )
    original_get = StateStore.get

    def reject_payload_load(store, kind, identifier):
        if kind in {"draft", "dataset"}:
            raise AssertionError("worker loaded candidate payload without OS isolation")
        return original_get(store, kind, identifier)

    monkeypatch.setattr(StateStore, "get", reject_payload_load)
    monkeypatch.setattr(
        worker.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("candidate/worker process launched without isolation"),
    )
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)

    isolation = candidate_network_isolation_status()
    assert not isolation.verified
    assert not isolation.network_denied
    assert not isolation.descendant_containment
    assert worker.run_worker(state_root, "job-isolation-unavailable") == 2

    row = original_get(state, "job", "job-isolation-unavailable")
    assert row["state"] == "FAILED"
    assert "network" in row["error"].lower()
    assert not (state_root / "jobs" / "job-isolation-unavailable").exists()


def test_start_run_rejects_without_isolation_before_approval_or_worker_start(
    registered_dataset, monkeypatch, tmp_path
):
    service, dataset = registered_dataset
    runtime = tmp_path / "candidate-runtime"
    package = runtime / "backtrader"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "version.py").write_text("version = '0.0'\n", encoding="utf-8")
    service.settings.runtimes["default"] = runtime
    monkeypatch.setattr("backtrader_mcp.jobs.require_cloudquant_runtime", lambda path: path)
    monkeypatch.setattr("backtrader_mcp.jobs.runtime_git_commit", lambda _path: None)
    monkeypatch.setattr(
        "backtrader_mcp.jobs.subprocess.Popen",
        lambda *_args, **_kwargs: pytest.fail("worker started without candidate isolation"),
    )
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)

    draft = service.create_strategy_draft(
        canonical_spec(dataset["dataset_id"], "single_data_indicator")
    )
    validation_result = service.validate_strategy_draft(draft["draft_id"], draft["revision"])
    plan = service.prepare_strategy_run(
        draft["draft_id"],
        validation_result["validation_token"],
        dataset["dataset_id"],
        "default",
        30,
        "runonce",
        "candidate-isolation-plan",
    )
    approval = service.jobs.approve_run_plan(plan["run_plan_id"], plan["run_token"])

    with pytest.raises(InvalidRequest, match="network.*isolation"):
        service.start_strategy_run(
            plan["run_plan_id"],
            plan["run_token"],
            approval["approval_id"],
            "candidate-isolation-start-rejected",
        )

    approval_row = next(
        row
        for row in service.state.list_approvals()
        if row["approval_id"] == approval["approval_id"]
    )
    assert approval_row["used_at"] is None
    assert service.state.list("job") == []


def test_execute_mode_rejects_without_isolation_before_candidate_popen(tmp_path, monkeypatch):
    runtime = tmp_path / "candidate-runtime"
    runtime.mkdir()
    state_root = tmp_path / "state"
    state_root.mkdir()
    state = StateStore(state_root)
    state.put(
        "job",
        "job-isolation-popen",
        {"job_id": "job-isolation-popen", "state": "RUNNING", "runtime_root": str(runtime)},
    )
    draft_root = tmp_path / "draft"
    draft_root.mkdir()
    (draft_root / "strategy.py").write_text("value = 1\n", encoding="utf-8")
    job_root = tmp_path / "jobs" / "job-isolation-popen"
    job_root.mkdir(parents=True)
    monkeypatch.setattr(
        worker.subprocess,
        "Popen",
        lambda *_args, **_kwargs: pytest.fail("candidate process started without isolation"),
    )
    monkeypatch.setattr(socket, "create_connection", _fail_if_network_is_attempted)
    monkeypatch.setattr(socket.socket, "connect", _fail_if_network_is_attempted)

    result = worker._execute_mode(
        state,
        "job-isolation-popen",
        {"runtime_root": str(runtime), "timeout_seconds": 30},
        job_root,
        "runonce",
        draft_root,
        draft_root / "run.py",
        {},
        [],
        "",
        {},
        0.0,
        "",
        None,
        "",
        ["strategy.py"],
    )

    assert result == 2
    assert state.get("job", "job-isolation-popen")["state"] == "FAILED"


@pytest.mark.parametrize("private_name", ["config.yaml", "secrets.yaml", ".env"])
def test_candidate_execution_guard_rejects_private_runtime_and_private_payload(
    tmp_path, monkeypatch, private_name
):
    private_runtime = tmp_path / "runtime-ctp-private"
    private_runtime.mkdir()
    with pytest.raises(InvalidRequest, match="private runtime"):
        assert_runtime_path_safe(
            private_runtime,
            state_root=tmp_path / "state",
            target_roots=(),
        )

    runtime = tmp_path / "trusted-runtime"
    private_config = runtime / "examples" / "case" / "runtime-ctp-private" / private_name
    private_config.parent.mkdir(parents=True)
    private_config.write_bytes(b"")
    original_read_bytes = Path.read_bytes
    original_read_text = Path.read_text

    def reject_private_read(path, *args, **kwargs):
        if path == private_config:
            raise AssertionError("private CTP config contents were read")
        return original_read_bytes(path, *args, **kwargs)

    def reject_private_text_read(path, *args, **kwargs):
        if path == private_config:
            raise AssertionError("private CTP config contents were read")
        return original_read_text(path, *args, **kwargs)

    monkeypatch.setattr(Path, "read_bytes", reject_private_read)
    monkeypatch.setattr(Path, "read_text", reject_private_text_read)
    with pytest.raises(InvalidRequest, match="private configuration"):
        assert_runtime_path_safe(
            runtime,
            state_root=tmp_path / "state",
            target_roots=(),
        )


def test_source_catalog_rejects_private_config_before_source_reads(service_env, monkeypatch):
    service, _source, target = service_env
    strategy = target / "candidate.py"
    strategy.write_text("class ExampleStrategy(Strategy):\n    pass\n", encoding="utf-8")
    private_config = (
        target / "examples" / "013_3_sa_midfreq_simnow" / "runtime-ctp-private" / "config.yaml"
    )
    private_config.parent.mkdir(parents=True)
    private_config.write_bytes(b"")
    original_read_text = Path.read_text

    def reject_strategy_read(path, *args, **kwargs):
        if path == strategy:
            raise AssertionError("source strategy was read before the private-path guard")
        return original_read_text(path, *args, **kwargs)

    monkeypatch.setattr(Path, "read_text", reject_strategy_read)

    with pytest.raises(InvalidRequest, match="private configuration"):
        service.refresh_strategy_catalog("strategies")

    assert service.state.list("catalog_entry") == []
    assert service.state.list("catalog_source") == []


def test_clean_tracked_private_runtime_placeholder_is_allowed(tmp_path):
    runtime = tmp_path / "trusted-runtime"
    protected = runtime / "examples" / "013_3_sa_midfreq_simnow" / "runtime-ctp-private"
    protected.mkdir(parents=True)
    (protected / "README.md").write_text("tracked placeholder\n", encoding="utf-8")
    (protected / ".gitignore").write_text("config.yaml\n", encoding="utf-8")

    assert_runtime_path_safe(
        runtime,
        state_root=tmp_path / "state",
        target_roots=(),
    )


def test_windows_reparse_alias_to_private_runtime_is_rejected(tmp_path, monkeypatch):
    runtime = tmp_path / "trusted-runtime"
    examples = runtime / "examples"
    examples.mkdir(parents=True)
    alias = examples / "external-data"
    alias.mkdir()
    outside_private = tmp_path / "outside" / "runtime-ctp-private"
    outside_private.mkdir(parents=True)
    (outside_private / "config.yaml").write_bytes(b"")

    original_reparse = protected_paths._is_reparse_point
    original_resolve = Path.resolve
    alias_metadata = alias.lstat()

    def simulated_reparse(metadata):
        if (
            metadata.st_ctime_ns == alias_metadata.st_ctime_ns
            and metadata.st_mode == alias_metadata.st_mode
        ):
            return True
        return original_reparse(metadata)

    def simulated_resolve(path, strict=False):
        if path == alias:
            return outside_private.resolve(strict=strict)
        return original_resolve(path, strict=strict)

    monkeypatch.setattr(protected_paths, "_is_reparse_point", simulated_reparse)
    monkeypatch.setattr(Path, "resolve", simulated_resolve)

    with pytest.raises(InvalidRequest, match="reparse|alias|protected runtime"):
        assert_runtime_path_safe(
            runtime,
            state_root=tmp_path / "state",
            target_roots=(),
        )


def test_windows_reparse_attribute_is_recognized():
    metadata = SimpleNamespace(st_mode=stat.S_IFDIR, st_file_attributes=0x400)

    assert protected_paths._is_reparse_point(metadata)
