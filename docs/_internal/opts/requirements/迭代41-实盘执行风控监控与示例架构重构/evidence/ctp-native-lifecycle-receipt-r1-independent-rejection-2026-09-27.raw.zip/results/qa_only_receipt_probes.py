from __future__ import annotations

import threading
from types import SimpleNamespace

import pytest

from bt_api_ctp.ctp import client as client_module
from bt_api_ctp.ctp.client import TraderClient


class Api:
    def __init__(self):
        self.init_entered = threading.Event()
        self.allow_init = threading.Event()
        self.join_entered = threading.Event()
        self.allow_join = threading.Event()
        self.calls = []

    def RegisterSpi(self, spi):
        self.calls.append(("register_spi", spi))

    def SubscribePrivateTopic(self, mode):
        self.calls.append(("private", mode))

    def SubscribePublicTopic(self, mode):
        self.calls.append(("public", mode))

    def RegisterFront(self, front):
        self.calls.append(("front", front))

    def Init(self):
        self.calls.append(("init", None))
        self.init_entered.set()
        assert self.allow_init.wait(3.0)

    def Join(self):
        self.calls.append(("join", None))
        self.join_entered.set()
        assert self.allow_join.wait(3.0)
        return 0

    def Release(self):
        self.calls.append(("release", None))


@pytest.fixture(autouse=True)
def isolate_lifecycle_registry():
    names = (
        "_RETIRED_CTP_NATIVE_SESSIONS",
        "_RELEASING_CTP_NATIVE_SESSION_API_IDS",
        "_CLAIMED_CTP_NATIVE_JOIN_API_IDS",
        "_RETURNED_CTP_NATIVE_JOIN_API_IDS",
        "_POISONED_CTP_NATIVE_SESSION_API_IDS",
        "_RELEASED_CTP_NATIVE_SESSION_API_IDS",
    )
    with client_module._RETIRED_CTP_NATIVE_SESSIONS_LOCK:
        saved = {name: list(getattr(client_module, name)) for name in names}
        saved_apis = list(client_module._RELEASED_CTP_NATIVE_SESSION_APIS)
        saved_states = dict(client_module._CTP_NATIVE_LIFECYCLE_STATES)
        for name in names:
            getattr(client_module, name).clear()
        client_module._RELEASED_CTP_NATIVE_SESSION_APIS.clear()
        client_module._CTP_NATIVE_LIFECYCLE_STATES.clear()
    try:
        yield
    finally:
        with client_module._RETIRED_CTP_NATIVE_SESSIONS_LOCK:
            for name, value in saved.items():
                collection = getattr(client_module, name)
                collection.clear()
                if isinstance(collection, set):
                    collection.update(value)
                else:
                    collection.extend(value)
            client_module._RELEASED_CTP_NATIVE_SESSION_APIS.clear()
            client_module._RELEASED_CTP_NATIVE_SESSION_APIS.update(saved_apis)
            client_module._CTP_NATIVE_LIFECYCLE_STATES.clear()
            client_module._CTP_NATIVE_LIFECYCLE_STATES.update(saved_states)


def test_public_receipt_shows_init_entered_and_exact_trader_provenance(monkeypatch):
    api = Api()
    monkeypatch.setattr(client_module, "CThostFtdcTraderApi", SimpleNamespace(CreateFtdcTraderApi=lambda _flow: api))
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = TraderClient("tcp://test", "9999", "account", "secret")
    errors = []

    def start():
        try:
            client.start(block=False)
        except BaseException as exc:
            errors.append(exc)

    starter = threading.Thread(target=start)
    starter.start()
    assert api.init_entered.wait(1.0)
    receipt = client.native_lifecycle_receipt
    assert receipt is not None
    assert receipt.init_state == "entered"
    assert receipt.clean is False
    assert receipt.api_object_id == id(api)
    assert receipt.spi_object_id == id(client._spi)
    assert receipt.session_generation == client._lifecycle_generation
    assert receipt.connection_generation == client._connection_generation
    assert client._spi._native_api_generation == client._native_api_generation
    assert client._spi._native_client_epoch == client._native_client_epoch
    assert client._spi._native_api_source_id == client._native_api_source_id
    observed_provenance = {
        "native_api_generation": (
            receipt.native_api_generation,
            client._native_api_generation,
            client._spi._native_api_generation,
        ),
        "native_client_epoch": (
            receipt.native_client_epoch,
            client._native_client_epoch,
            client._spi._native_client_epoch,
        ),
        "native_api_source_id": (
            receipt.native_api_source_id,
            client._native_api_source_id,
            client._spi._native_api_source_id,
        ),
        "native_spi_source_id": (
            receipt.native_spi_source_id,
            client._spi._native_spi_source_id,
        ),
    }
    provenance_differences = {
        name: values
        for name, values in observed_provenance.items()
        if any(value != values[0] for value in values[1:])
    }

    api.allow_init.set()
    starter.join(1.0)
    assert not starter.is_alive()
    assert errors == []
    assert api.join_entered.wait(1.0)
    api.allow_join.set()
    stopped = client.stop_and_wait(timeout=1.0)
    if not stopped.complete:
        stopped = client.stop_and_wait(timeout=1.0)
    assert stopped.lifecycle.join_state == "returned"
    assert stopped.lifecycle.release_attempt_count == 1
    assert stopped.lifecycle.release_state == "returned"
    assert stopped.lifecycle.clean is True
    assert [name for name, _ in api.calls].count("release") == 1
    assert provenance_differences == {}


def test_lifecycle_lookup_accepts_only_exact_api_object(monkeypatch):
    api = object()
    impostor = object()
    spi = SimpleNamespace(_native_spi_source_id="spi-source-1")
    client = SimpleNamespace(
        _native_api_generation=9,
        _native_client_epoch="epoch-9",
        _native_api_source_id="api-source-9",
    )
    state = client_module._bind_ctp_native_lifecycle_state(
        client,
        client_kind="trader",
        session_generation=12,
        api=api,
        spi=spi,
    )
    assert client_module._ctp_native_lifecycle_state_for_api(api) is state
    assert client_module._ctp_native_lifecycle_state_for_api(impostor) is None
    receipt = state.snapshot(connection_generation=4, thread_alive=False)
    assert receipt.api_object_id == id(api)
    assert receipt.spi_object_id == id(spi)
    assert receipt.session_generation == 12
    assert receipt.connection_generation == 4
    assert receipt.native_api_generation == 9
    assert receipt.native_client_epoch == "epoch-9"
    assert receipt.native_api_source_id == "api-source-9"
    assert receipt.native_spi_source_id == "spi-source-1"
    assert receipt.clean is False
