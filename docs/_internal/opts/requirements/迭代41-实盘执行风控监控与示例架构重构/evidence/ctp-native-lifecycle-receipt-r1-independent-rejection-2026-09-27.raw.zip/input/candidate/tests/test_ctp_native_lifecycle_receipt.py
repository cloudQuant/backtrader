"""Fake-only evidence for the per-session CTP native lifecycle receipt."""

from __future__ import annotations

import threading
from types import SimpleNamespace
from typing import Any

import pytest

from bt_api_ctp.ctp import client as client_module
from bt_api_ctp.ctp.client import MdClient, TraderClient

_TEST_APIS: list[_LifecycleApi] = []


class _LifecycleApi:
    def __init__(
        self,
        *,
        block_join: bool = False,
        detach_error: bool = False,
        release_error: bool = False,
        init_error: bool = False,
        join_error: bool = False,
        detach_result: Any = None,
        front_error: bool = False,
    ) -> None:
        self.calls: list[tuple[str, Any]] = []
        self.join_entered = threading.Event()
        self.allow_join = threading.Event()
        if not block_join:
            self.allow_join.set()
        self.detach_entered = threading.Event()
        self.allow_detach = threading.Event()
        self.allow_detach.set()
        self.release_entered = threading.Event()
        self.allow_release = threading.Event()
        self.allow_release.set()
        self.detach_error = detach_error
        self.release_error = release_error
        self.init_error = init_error
        self.join_error = join_error
        self.detach_result = detach_result
        self.front_error = front_error

    def RegisterSpi(self, spi: object | None) -> None:
        self.calls.append(("register_spi", spi))
        if spi is None:
            self.detach_entered.set()
            assert self.allow_detach.wait(2.0)
            if self.detach_error:
                raise RuntimeError("detach_failed")
            return self.detach_result

    def SubscribePrivateTopic(self, mode: int) -> None:
        self.calls.append(("private_topic", mode))

    def SubscribePublicTopic(self, mode: int) -> None:
        self.calls.append(("public_topic", mode))

    def RegisterFront(self, front: str) -> None:
        self.calls.append(("front", front))
        if self.front_error:
            raise RuntimeError("front_failed_before_init")

    def Init(self) -> None:
        self.calls.append(("init", None))
        if self.init_error:
            raise RuntimeError("init_failed")

    def Join(self) -> int:
        self.calls.append(("join", None))
        self.join_entered.set()
        assert self.allow_join.wait(2.0)
        if self.join_error:
            raise RuntimeError("join_failed")
        return 17

    def Release(self) -> None:
        self.calls.append(("release", None))
        self.release_entered.set()
        assert self.allow_release.wait(2.0)
        if self.release_error:
            raise RuntimeError("release_failed")


def _new_client(client_type):
    return client_type("tcp://test", "9999", "account", "secret")


def _patch_api_factory(monkeypatch, client_type, api):
    _TEST_APIS.append(api)
    if client_type is MdClient:
        monkeypatch.setattr(
            client_module,
            "CThostFtdcMdApi",
            SimpleNamespace(CreateFtdcMdApi=lambda _flow: api),
        )
    else:
        monkeypatch.setattr(
            client_module,
            "CThostFtdcTraderApi",
            SimpleNamespace(CreateFtdcTraderApi=lambda _flow: api),
        )


@pytest.fixture(autouse=True)
def _clear_release_registry():
    names = (
        "_RETIRED_CTP_NATIVE_SESSIONS",
        "_RELEASING_CTP_NATIVE_SESSION_API_IDS",
        "_CLAIMED_CTP_NATIVE_JOIN_API_IDS",
        "_RETURNED_CTP_NATIVE_JOIN_API_IDS",
        "_POISONED_CTP_NATIVE_SESSION_API_IDS",
        "_RELEASED_CTP_NATIVE_SESSION_API_IDS",
    )
    with client_module._RETIRED_CTP_NATIVE_SESSIONS_LOCK:
        saved = {name: list(getattr(client_module, name)) for name in names}
        saved_released_apis = list(client_module._RELEASED_CTP_NATIVE_SESSION_APIS)
        saved_lifecycle_states = dict(client_module._CTP_NATIVE_LIFECYCLE_STATES)
        for name in names:
            getattr(client_module, name).clear()
        client_module._RELEASED_CTP_NATIVE_SESSION_APIS.clear()
        client_module._CTP_NATIVE_LIFECYCLE_STATES.clear()
    _TEST_APIS.clear()
    try:
        yield
    finally:
        for api in _TEST_APIS:
            api.allow_join.set()
            api.allow_detach.set()
            api.allow_release.set()
        with client_module._RETIRED_CTP_NATIVE_SESSIONS_LOCK:
            for name, value in saved.items():
                getattr(client_module, name).clear()
                getattr(client_module, name).update(value) if isinstance(
                    getattr(client_module, name), set
                ) else getattr(client_module, name).extend(value)
            client_module._RELEASED_CTP_NATIVE_SESSION_APIS.clear()
            client_module._RELEASED_CTP_NATIVE_SESSION_APIS.update(saved_released_apis)
            client_module._CTP_NATIVE_LIFECYCLE_STATES.clear()
            client_module._CTP_NATIVE_LIFECYCLE_STATES.update(saved_lifecycle_states)
        _TEST_APIS.clear()


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_stop_receipt_tracks_one_exact_api_spi_join_release_generation(monkeypatch, client_type):
    api = _LifecycleApi(block_join=True)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)

    client.start(block=False)
    assert api.join_entered.wait(1.0)
    spi_object_id = id(client._spi)
    pending = client.stop_and_wait(timeout=0.01)

    lifecycle = pending.lifecycle
    assert lifecycle.client_kind == ("md" if client_type is MdClient else "trader")
    assert lifecycle.api_identity_token
    assert lifecycle.spi_identity_token
    assert lifecycle.api_object_id == id(api)
    assert lifecycle.spi_object_id == spi_object_id
    assert lifecycle.session_generation > 0
    assert lifecycle.register_spi_state == "returned"
    assert lifecycle.register_spi_return_type == "NoneType"
    assert lifecycle.init_state == "returned"
    assert lifecycle.init_return_type == "NoneType"
    assert lifecycle.detach_state == "returned"
    assert lifecycle.detach_return_type == "NoneType"
    assert lifecycle.join_state == "pending"
    assert lifecycle.release_attempt_count == 0
    assert lifecycle.release_state == "not_attempted"
    assert pending.timed_out is True
    assert pending.complete is False
    assert [name for name, _ in api.calls].count("release") == 0

    api.allow_join.set()
    completed = client.stop_and_wait(timeout=1.0)
    assert completed.lifecycle.join_state == "returned"
    assert completed.lifecycle.join_return_type == "int"
    assert completed.lifecycle.join_return_code == 17
    assert completed.lifecycle.release_attempt_count == 1
    assert completed.lifecycle.release_state == "returned"
    assert completed.complete is True
    assert [name for name, _ in api.calls].count("release") == 1


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_detach_exception_poison_prevents_release_and_is_not_retried(monkeypatch, client_type):
    api = _LifecycleApi(detach_error=True)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)

    client.start(block=False)
    assert api.join_entered.wait(1.0)
    api.allow_join.set()
    assert client.wait_native_join(1.0).observation.state == "returned"

    receipt = client.stop_and_wait(timeout=0.1)
    assert receipt.lifecycle.detach_state == "failed"
    assert receipt.lifecycle.detach_error_type == "RuntimeError"
    assert receipt.lifecycle.release_attempt_count == 0
    assert receipt.lifecycle.release_state == "not_attempted"
    assert receipt.complete is False
    assert [name for name, _ in api.calls].count("release") == 0

    repeated = client.stop_and_wait(timeout=0.1)
    assert repeated.lifecycle.detach_state == "failed"
    assert repeated.lifecycle.release_attempt_count == 0
    assert [name for name, _ in api.calls].count("register_spi") == 2


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_unexpected_detach_return_is_not_clean_and_never_releases(monkeypatch, client_type):
    api = _LifecycleApi(detach_result=0)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)

    client.start(block=False)
    assert api.join_entered.wait(1.0)
    api.allow_join.set()
    assert client.wait_native_join(1.0).observation.state == "returned"
    receipt = client.stop_and_wait(timeout=0.1)

    assert receipt.lifecycle.detach_state == "failed"
    assert receipt.lifecycle.detach_error_type == "unexpected_return_type"
    assert receipt.lifecycle.detach_return_type == "int"
    assert receipt.lifecycle.release_attempt_count == 0
    assert receipt.complete is False
    assert [name for name, _ in api.calls].count("release") == 0


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_join_exception_is_retained_as_failed_lifecycle_evidence(monkeypatch, client_type):
    api = _LifecycleApi(join_error=True)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)
    client._start_join_observer = lambda _api: False
    client.start(block=False)
    errors: list[BaseException] = []

    def observe_join():
        try:
            client._join_native_api(api)
        except BaseException as exc:
            errors.append(exc)

    observer = threading.Thread(target=observe_join)
    observer.start()
    assert api.join_entered.wait(1.0)
    api.allow_join.set()
    observer.join(1.0)
    assert not observer.is_alive()
    assert len(errors) == 1

    receipt = client.stop_and_wait(timeout=0.1)
    assert receipt.lifecycle.join_state == "failed"
    assert receipt.lifecycle.join_error_type == "RuntimeError"
    assert receipt.lifecycle.release_attempt_count == 0
    assert receipt.complete is False
    assert [name for name, _ in api.calls].count("release") == 0


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_init_exception_stays_nonclean_after_join_and_release(monkeypatch, client_type):
    api = _LifecycleApi(init_error=True)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)

    with pytest.raises(RuntimeError, match="init_failed"):
        client.start(block=False)
    assert api.join_entered.wait(1.0)
    assert client.wait_native_join(1.0).observation.state == "returned"

    lifecycle = client.native_lifecycle_receipt
    assert lifecycle.init_state == "failed"
    assert lifecycle.init_error_type == "RuntimeError"
    assert lifecycle.detach_state == "returned"
    assert lifecycle.join_state == "returned"
    assert lifecycle.release_attempt_count == 1
    assert lifecycle.release_state == "returned"
    assert lifecycle.clean is False


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_pre_init_failure_receipt_records_join_not_required_and_release(monkeypatch, client_type):
    api = _LifecycleApi(front_error=True)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)

    with pytest.raises(RuntimeError, match="front_failed_before_init"):
        client.start(block=False)
    receipt = client.stop_and_wait(timeout=0.1)

    assert receipt.lifecycle.register_spi_state == "returned"
    assert receipt.lifecycle.init_state == "not_entered"
    assert receipt.lifecycle.join_state == "not_required"
    assert receipt.lifecycle.detach_state == "returned"
    assert receipt.lifecycle.release_attempt_count == 1
    assert receipt.lifecycle.release_state == "returned"
    assert receipt.complete is True


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_release_exception_is_recorded_once_and_repeated_close_cannot_retry(
    monkeypatch, client_type
):
    api = _LifecycleApi(release_error=True)
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)

    client.start(block=False)
    assert api.join_entered.wait(1.0)
    api.allow_join.set()
    assert client.wait_native_join(1.0).observation.state == "returned"

    receipt = client.stop_and_wait(timeout=0.1)
    assert receipt.lifecycle.detach_state == "returned"
    assert receipt.lifecycle.release_attempt_count == 1
    assert receipt.lifecycle.release_state == "failed"
    assert receipt.lifecycle.release_error_type == "RuntimeError"
    assert receipt.complete is False

    repeated = client.stop_and_wait(timeout=0.1)
    assert repeated.lifecycle.release_attempt_count == 1
    assert repeated.lifecycle.release_state == "failed"
    assert [name for name, _ in api.calls].count("release") == 1


@pytest.mark.parametrize("client_type", [MdClient, TraderClient], ids=["md", "trader"])
def test_inflight_detach_and_release_snapshots_are_incomplete(monkeypatch, client_type):
    api = _LifecycleApi()
    api.allow_detach.clear()
    api.allow_release.clear()
    _patch_api_factory(monkeypatch, client_type, api)
    monkeypatch.setattr(client_module, "_check_native_module", lambda: None)
    client = _new_client(client_type)
    client.start(block=False)
    assert api.join_entered.wait(1.0)
    api.allow_join.set()
    assert client.wait_native_join(1.0).observation.state == "returned"

    stop_thread = threading.Thread(target=client.stop_and_wait, kwargs={"timeout": 0.1})
    stop_thread.start()
    assert api.detach_entered.wait(1.0)
    mid_detach = client.native_lifecycle_receipt
    assert mid_detach.detach_state == "entered"
    assert mid_detach.release_state == "not_attempted"
    assert mid_detach.clean is False

    api.allow_detach.set()
    assert api.release_entered.wait(1.0)
    mid_release = client.native_lifecycle_receipt
    assert mid_release.detach_state == "returned"
    assert mid_release.release_attempt_count == 1
    assert mid_release.release_state == "entered"
    assert mid_release.clean is False

    api.allow_release.set()
    stop_thread.join(1.0)
    assert not stop_thread.is_alive()
    assert client.native_lifecycle_receipt.clean is True
