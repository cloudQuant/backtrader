from __future__ import annotations
import hashlib, importlib, importlib.metadata, importlib.util, json, os, re, shutil, sys, tempfile
from pathlib import Path
import pytest

SNAPSHOT = Path(r"D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r2").resolve()
R1 = Path(r"D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r1").resolve()
BASE = Path(r"D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src").resolve()
METADATA = Path(r"D:\temp\iteration41-v20-r3-main-cancel-qa-20260927\source-only-metadata-r3").resolve()
QA = Path(r"D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927").resolve()
COPY = QA / "source-copy"
OUTPUT = Path(os.environ["R3_QA_OUTPUT"]).resolve()
EXPECTED_MANIFEST_SHA = "0a0850c107856262470d584132c4d869db1eb4dba6f37a33323fdf569981f41d"
EXPECTED_PARENT_MANIFEST_SHA = "15c37a6cc5503127c63d6987b9de0fd71a48181fc33dff5a4e52f57a8fc5d129"
EXPECTED_OVERLAYS = {"src/bt_api_execution/cancellation.py", "src/bt_api_execution/__init__.py", "tests/test_cancellation.py"}

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def manifest_files(root: Path, manifest: dict) -> dict[str, dict]:
    return {entry["path"]: entry for entry in manifest["files"]}

def verify_manifest_tree(root: Path, manifest: dict, *, exact_files: bool = True) -> None:
    expected = manifest_files(root, manifest)
    for rel, entry in expected.items():
        p = root / Path(rel)
        if not p.is_file() or p.stat().st_size != entry["bytes"] or sha(p) != entry["sha256"]:
            raise RuntimeError("manifest hash mismatch: " + rel)
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    if exact_files and actual != set(expected):
        raise RuntimeError(f"manifest file set mismatch: extra={sorted(actual-set(expected))}, missing={sorted(set(expected)-actual)}")


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    if OUTPUT == SNAPSHOT or SNAPSHOT in OUTPUT.parents:
        raise RuntimeError("output directory must be outside freeze")
    mpath = SNAPSHOT / "manifest.json"
    if sha(mpath) != EXPECTED_MANIFEST_SHA:
        raise RuntimeError("r2 manifest sha mismatch")
    manifest = json.loads(mpath.read_text(encoding="utf-8"))
    if manifest.get("parent_manifest_sha256") != EXPECTED_PARENT_MANIFEST_SHA:
        raise RuntimeError("parent V20r2 manifest mismatch")
    r1manifest = json.loads((R1 / "manifest.json").read_text(encoding="utf-8"))
    r2map = manifest_files(SNAPSHOT, manifest)
    r1map = manifest_files(R1, r1manifest)
    if set(r1map) != set(r2map):
        raise RuntimeError("r1/r2 path set differs")
    changed = {rel for rel in r1map if r1map[rel]["sha256"] != r2map[rel]["sha256"]}
    if changed != EXPECTED_OVERLAYS:
        raise RuntimeError(f"unexpected r1/r2 overlays: {sorted(changed)}")
    verify_manifest_tree(SNAPSHOT, manifest, exact_files=False)
    if not COPY.is_dir():
        raise RuntimeError("independent source copy was not prepared")
    copy_manifest = {"files": manifest["files"]}
    verify_manifest_tree(COPY, copy_manifest)
    print("SOURCE_COPY_OK", len(r2map), "manifest", EXPECTED_MANIFEST_SHA, "parent", EXPECTED_PARENT_MANIFEST_SHA)
    print("R1_OVERLAYS", json.dumps(sorted(changed)))
    print("UNMANIFESTED_FREEZE_FILES", json.dumps(sorted({p.relative_to(SNAPSHOT).as_posix() for p in SNAPSHOT.rglob("*") if p.is_file()} - set(r2map))))

    # Pin actual imports to the independent source copy, not the freeze or an install.
    for p in (COPY / "src", BASE, METADATA):
        sys.path.insert(0, str(p))
    imported = {}
    for name, expected in (
        ("bt_api_execution", COPY / "src/bt_api_execution/__init__.py"),
        ("bt_api_execution.contracts", COPY / "src/bt_api_execution/contracts.py"),
        ("bt_api_execution.cancellation", COPY / "src/bt_api_execution/cancellation.py"),
        ("bt_api_execution.store", COPY / "src/bt_api_execution/store.py"),
    ):
        mod = importlib.import_module(name)
        actual = Path(mod.__file__).resolve()
        if actual != expected.resolve():
            raise RuntimeError(f"origin mismatch {name}: {actual} != {expected}")
        imported[name] = {"path": str(actual), "sha256": sha(actual)}
        print("IMPORT_ORIGIN", name, actual, sha(actual))
    meta_path = importlib.metadata.distribution("bt_api_execution")._path
    if Path(meta_path).resolve().parent != METADATA.resolve():
        raise RuntimeError(f"metadata provenance mismatch: {meta_path}")
    version = importlib.metadata.version("bt_api_execution")
    if version != "0.2.0":
        raise RuntimeError("unexpected source-only execution metadata version")
    print("SOURCE_ONLY_METADATA", version, meta_path)

    tests = sorted((COPY / "tests").glob("test_*.py"))
    if len(tests) != 14:
        raise RuntimeError(f"unexpected test file count: {len(tests)}")
    junit = OUTPUT / "execution-r3-r2.junit.xml"
    basetemp = OUTPUT / "pytest-basetemp"
    result = pytest.main([
        "-q", "-p", "no:cacheprovider", "--basetemp=" + str(basetemp),
        "--junitxml=" + str(junit), *(str(p) for p in tests)
    ])
    if int(result) != 0:
        raise SystemExit(int(result))

    # Supplemental local-only probe: provider-returned integer zero is malformed
    # evidence, must latch UNKNOWN and must neither release nor retry the permit.
    test_path = COPY / "tests/test_cancellation.py"
    spec = importlib.util.spec_from_file_location("r3_qa_test_cancellation", test_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load cancellation test helpers")
    helpers = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = helpers
    spec.loader.exec_module(helpers)
    probe_dir = OUTPUT / "provider-zero-probe"
    probe_dir.mkdir(parents=True, exist_ok=True)
    gate = helpers._DurableCancelGate(probe_dir / "risk.sqlite3")
    store, facade, gate = helpers._ready_facades(probe_dir, cancel_gate=gate)
    calls: list[str] = []
    try:
        def returns_zero(intent):
            calls.append(intent.cancel_id)
            return 0
        first = facade.cancel(helpers._cancel_intent(), returns_zero)
        second = facade.cancel(helpers._cancel_intent(), returns_zero)
        assert first.state is helpers.ExecutionState.UNKNOWN
        assert second.state is helpers.ExecutionState.UNKNOWN
        assert len(calls) == 1 and calls == ["cancel.1"]
        assert gate.claimed == ["cancel.1"]
        assert gate.released == []
        assert gate.settled == []
        assert gate.has_durable_claim("cancel-permit-cancel.1")
        print("PROVIDER_ZERO_PROBE", json.dumps({"first": first.state.value, "second": second.state.value, "provider_calls": calls, "claimed": gate.claimed, "released": gate.released, "settled": gate.settled, "durable_claim": True}))
    finally:
        gate.close()
        store.close()

    post_modules = {}
    for name in ("bt_api_execution", "bt_api_execution.contracts", "bt_api_execution.cancellation", "bt_api_execution.store"):
        module = sys.modules[name]
        path = Path(module.__file__).resolve()
        if COPY / "src/bt_api_execution" not in path.parents and path != (COPY / "src/bt_api_execution/__init__.py").resolve():
            raise RuntimeError(f"post-test import escaped source copy: {name}: {path}")
        post_modules[name] = str(path)
    verify_manifest_tree(COPY, copy_manifest)
    verify_manifest_tree(SNAPSHOT, manifest, exact_files=False)
    print("POST_TEST_SOURCE_COPY_GUARD_OK", json.dumps(post_modules, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
