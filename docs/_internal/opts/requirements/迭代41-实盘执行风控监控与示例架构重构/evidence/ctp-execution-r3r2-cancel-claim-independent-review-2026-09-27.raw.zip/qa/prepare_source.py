from __future__ import annotations
import hashlib, json, shutil
from pathlib import Path
snapshot=Path(r'D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r2')
r1=Path(r'D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r1')
qa=Path(r'D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927')
copy=qa/'source-copy'
expected='0a0850c107856262470d584132c4d869db1eb4dba6f37a33323fdf569981f41d'
overlays={'src/bt_api_execution/cancellation.py','src/bt_api_execution/__init__.py','tests/test_cancellation.py'}
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
mp=snapshot/'manifest.json'
assert sha(mp)==expected
m=json.loads(mp.read_text(encoding='utf-8'))
m1=json.loads((r1/'manifest.json').read_text(encoding='utf-8'))
if m['parent_manifest_sha256']!='15c37a6cc5503127c63d6987b9de0fd71a48181fc33dff5a4e52f57a8fc5d129': raise RuntimeError('parent manifest mismatch')
e2={e['path']:e for e in m['files']}; e1={e['path']:e for e in m1['files']}
if set(e1)!=set(e2): raise RuntimeError('r1/r2 file sets differ')
changed={p for p in e1 if e1[p]['sha256']!=e2[p]['sha256']}
if changed!=overlays: raise RuntimeError(f'overlay mismatch {sorted(changed)}')
for rel,e in e2.items():
 p=snapshot/rel
 if not p.is_file() or p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']: raise RuntimeError('freeze source mismatch '+rel)
if copy.exists(): shutil.rmtree(copy)
for rel in e2:
 src=snapshot/rel; dst=copy/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
actual={p.relative_to(copy).as_posix() for p in copy.rglob('*') if p.is_file()}
if actual!=set(e2): raise RuntimeError('source copy file set mismatch')
for rel,e in e2.items():
 p=copy/rel
 if p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']: raise RuntimeError('source copy mismatch '+rel)
unmanifested={p.relative_to(snapshot).as_posix() for p in snapshot.rglob('*') if p.is_file()}-set(e2)
result={'freeze_manifest_sha256':sha(mp),'source_copy_file_count':len(actual),'parent_manifest_sha256':m['parent_manifest_sha256'],'changed_from_r1':sorted(changed),'unmanifested_freeze_files':sorted(unmanifested),'source_copy_root':str(copy)}
(qa/'source-copy-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
