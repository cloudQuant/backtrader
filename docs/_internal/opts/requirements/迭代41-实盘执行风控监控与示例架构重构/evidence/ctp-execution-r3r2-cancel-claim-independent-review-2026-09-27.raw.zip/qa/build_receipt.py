from __future__ import annotations
import hashlib, json, xml.etree.ElementTree as ET
from pathlib import Path

qa = Path(r"D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927")
snapshot = Path(r"D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r2")
manifest = json.loads((snapshot / "manifest.json").read_text(encoding="utf-8"))
expected_manifest_sha = "0a0850c107856262470d584132c4d869db1eb4dba6f37a33323fdf569981f41d"
parent_sha = "15c37a6cc5503127c63d6987b9de0fd71a48181fc33dff5a4e52f57a8fc5d129"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if sha(qa / "freeze-manifest-copy.json") != expected_manifest_sha:
    raise RuntimeError("copied freeze manifest changed")
if manifest.get("parent_manifest_sha256") != parent_sha:
    raise RuntimeError("parent manifest mismatch")

# Verify every manifested file and construct exact independent-copy provenance.
source_files = []
for item in manifest["files"]:
    p = qa / "source-copy" / Path(item["path"])
    if not p.is_file() or p.stat().st_size != item["bytes"] or sha(p) != item["sha256"]:
        raise RuntimeError("source-copy mismatch: " + item["path"])
    source_files.append({"path": item["path"], "bytes": item["bytes"], "sha256": item["sha256"]})
if len(source_files) != 29:
    raise RuntimeError("unexpected source copy count")

changed = sorted(
    item["path"] for item in manifest["files"]
    if item.get("changed_from_parent") or item.get("overlay")
)
# Cross-check r1/r2 from their manifests rather than trusting labels.
r1 = Path(r"D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r1")
r1manifest = json.loads((r1 / "manifest.json").read_text(encoding="utf-8"))
r1files = {x["path"]: x["sha256"] for x in r1manifest["files"]}
r2files = {x["path"]: x["sha256"] for x in manifest["files"]}
overlays = sorted(path for path in r2files if r2files[path] != r1files.get(path))
expected_overlays = ["src/bt_api_execution/__init__.py", "src/bt_api_execution/cancellation.py", "tests/test_cancellation.py"]
if overlays != expected_overlays:
    raise RuntimeError(f"r1/r2 diff mismatch: {overlays}")

junit = qa / "results/execution-r3-r2.junit.xml"
root = ET.parse(junit).getroot()
suite = root.find("testsuite") if root.tag == "testsuites" else root
if suite is None:
    raise RuntimeError("missing JUnit suite")
case_nodes = list(suite.findall("testcase"))
skips = []
for case in case_nodes:
    skipped = case.find("skipped")
    if skipped is not None:
        skips.append({"nodeid": f"{case.get('classname')}::{case.get('name')}", "reason": skipped.get("message")})
full_run = {
    "command": "run_independent.ps1 -OutputDirectory D:\\temp\\iteration41-v20-r3-execution-r2-independent-qa-20260927\\results",
    "tests": len(case_nodes),
    "passed": len(case_nodes) - len(skips),
    "skipped": len(skips),
    "failed": 0,
    "junit": "results/execution-r3-r2.junit.xml",
    "stdout": "results/stdout.log",
    "stderr": "results/stderr.log",
    "skips": skips,
}
if full_run["tests"] != 280 or full_run["passed"] != 278 or full_run["skipped"] != 2:
    raise RuntimeError(f"unexpected package result: {full_run}")

# Known exact runtime origins from the two successful SDK bridge probes and package run.
origins = {
    "bt_api_execution": {"path": str(qa / "source-copy/src/bt_api_execution/__init__.py"), "sha256": "9c6444b5175c57485ce312e7df50704f454f6d8decfd39ebd7ca653ee3b861e3"},
    "bt_api_execution.contracts": {"path": str(qa / "source-copy/src/bt_api_execution/contracts.py"), "sha256": "4cee90ae9c8b414877e7a7b917af85d518d45e6074418dc5b0f4bc713fad8219"},
    "bt_api_execution.cancellation": {"path": str(qa / "source-copy/src/bt_api_execution/cancellation.py"), "sha256": "1f7bc6863b5ca887e8306788e1b340eca7fe70bfffcb0544cc486b5badac08cf"},
    "bt_api_execution.store": {"path": str(qa / "source-copy/src/bt_api_execution/store.py"), "sha256": "75b01d7badbf67043c65082bee8dc27efbe4a309a739ff9f5cadd50f21ccde72"},
    "bt_api_ctp.ctp.client": {"path": r"D:\q\e\src\bt_api_ctp\ctp\client.py", "sha256": "bf915128c41da83efdff517e3ea711c43d7555406bd831a0dfcd775b64840d1c"},
    "bt_api_base": {"path": r"D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src\bt_api_base\__init__.py", "sha256": "c0c14cfa1e39a79fef8126a85e82cd7b41d5662e683ff11932fcc58add8116b4"},
}
for key, item in origins.items():
    if sha(Path(item["path"])) != item["sha256"]:
        raise RuntimeError("origin file changed: " + key)

receipt = {
    "schema": "iteration41.execution_r3_r2.independent_qa.v1",
    "result": "PACKAGE_SOURCE_QA_PASS_WITH_OPTIONAL_SDK_FIXTURE_DIAGNOSTIC",
    "freeze": {
        "path": str(snapshot),
        "manifest_sha256": expected_manifest_sha,
        "parent_v20_r2_manifest_sha256": parent_sha,
        "manifested_files": len(source_files),
        "source_copy": str(qa / "source-copy"),
        "source_copy_files": source_files,
        "r1_to_r2_changed_files": overlays,
        "unmanifested_files_in_freeze": json.loads((qa / "source-copy-audit.json").read_text(encoding="utf-8"))["unmanifested_freeze_files"],
    },
    "source_only_metadata": {
        "execution_version": "0.2.0",
        "metadata_root": r"D:\temp\iteration41-v20-r3-main-cancel-qa-20260927\source-only-metadata-r3",
        "is_installed_wheel_validation": False,
    },
    "full_package_run": full_run,
    "cancellation_claim_contract": {
        "required_exact_type": "CancelDispatchClaimReceiptV1",
        "bound_fields": ["permit_reference", "scope_key", "cancel_id", "intent_fingerprint"],
        "invalid_receipt_cases": ["integer zero", "empty string", "string", "plain object", "wrong permit", "wrong scope", "wrong cancel id", "wrong fingerprint"],
        "exception_case": "claim raises after local attempt",
        "verified_outcome": "UNKNOWN; durable claim/fence remains; replay does not call provider or claim again; no release or settlement",
    },
    "integer_zero_split": {
        "claim_return_zero": {
            "target_order_setup_provider_calls": 1,
            "cancel_dispatch_provider_calls": 0,
            "claim_calls": 1,
            "state_and_replay": "UNKNOWN",
            "release_calls": 0,
            "settle_calls": 0,
            "evidence": "zero-return-split-results/combined.log",
        },
        "cancel_provider_returns_zero": {
            "target_order_setup_provider_calls": 1,
            "cancel_dispatch_provider_calls": 1,
            "claim_calls": 1,
            "state_and_replay": "UNKNOWN",
            "release_calls": 0,
            "settle_calls": 0,
            "evidence": "zero-return-split-results/combined.log",
            "interpretation": "post-dispatch ambiguity; not evidence that provider was not called",
        },
    },
    "sdk_bridge": {
        "original_fixture": {
            "result": "2 failed before bridge creation",
            "reason": "fake OnRspUserLogin lacks BrokerID and UserID, so current SDK declines to seal login identity; execution helper reports TraderClient not logged in",
            "logs": ["sdk-bridge-results/stdout.log", "sdk-bridge-results/stderr.log", "sdk-bridge-results/process-result.json", "sdk-bridge-results/sdk-bridge.junit.xml"],
        },
        "qa_only_corrected_fixture": {
            "added_fields": {"BrokerID": "9999", "UserID": "fake-user"},
            "result": "2 passed",
            "native_extension_loaded": False,
            "frozen_source_changed": False,
            "fixture_path": str(qa / "sdk-bridge-positive-fixture/tests/test_ctp_callback_source_bridge.py"),
            "runner": "sdk_bridge_positive.py",
            "evidence": "sdk-bridge-positive-results-final",
        },
    },
    "origins": origins,
    "limits": [
        "fake-only; no provider, account, secrets, trade, or CTP native extension",
        "does not validate a remote risk-authority implementation",
        "does not validate installed wheels or production/default-route authorization",
        "unmanifested cache/patch/bytecode artifacts exist in the freeze directory; none were modified and they were excluded from the source copy",
    ],
}
(qa / "qa-receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")

# Hash selected evidence plus all manifest-listed source files; omit ephemeral pytest basetemp DBs.
selected = set()
for p in [
    qa / "freeze-manifest-copy.json", qa / "source-copy-audit.json", qa / "review_notes.md",
    qa / "prepare_source.py", qa / "independent_run.py", qa / "run_independent.ps1", qa / "sdk_bridge_probe.py",
    qa / "sdk_bridge_positive.py", qa / "zero_return_split_probe.py", qa / "build_receipt.py",
    qa / "qa-receipt.json", qa / "results/stdout.log", qa / "results/stderr.log", qa / "results/process-result.json", qa / "results/execution-r3-r2.junit.xml",
    qa / "sdk-bridge-positive-fixture/tests/test_ctp_callback_source_bridge.py",
    qa / "sdk-bridge-positive-results-final/combined.log", qa / "sdk-bridge-positive-results-final/process-result.json", qa / "sdk-bridge-positive-results-final/sdk-bridge-positive.junit.xml",
    qa / "zero-return-split-results/combined.log", qa / "zero-return-split-results/process-result.json",
]:
    if p.is_file(): selected.add(p)
for sub in ("sdk-bridge-results", "results/probe-import-diagnostic", "results/test-count-precheck-diagnostic", "results/unmanifested-cache-precheck-diagnostic"):
    d = qa / sub
    if d.exists(): selected.update(p for p in d.rglob("*") if p.is_file())
for item in manifest["files"]:
    selected.add(qa / "source-copy" / Path(item["path"]))
entries = []
for p in sorted(selected, key=lambda x: x.relative_to(qa).as_posix()):
    entries.append({"path": p.relative_to(qa).as_posix(), "bytes": p.stat().st_size, "sha256": sha(p)})
artifact_manifest = {
    "schema": "iteration41.execution_r3_r2.independent_qa.artifacts.v1",
    "qa_receipt": "qa-receipt.json",
    "artifact_count": len(entries),
    "artifacts": entries,
}
(qa / "artifact-manifest.json").write_text(json.dumps(artifact_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"qa_receipt_sha256": sha(qa / "qa-receipt.json"), "artifact_manifest_sha256": sha(qa / "artifact-manifest.json"), "artifact_count": len(entries), "full_run": full_run, "overlays": overlays}, sort_keys=True))
