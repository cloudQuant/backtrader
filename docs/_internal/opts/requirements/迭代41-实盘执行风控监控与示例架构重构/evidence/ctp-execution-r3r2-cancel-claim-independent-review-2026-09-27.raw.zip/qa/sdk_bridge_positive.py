from __future__ import annotations
import hashlib, importlib, importlib.metadata, os, sys
from pathlib import Path
import pytest

qa = Path(r"D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927")
copy = qa / "source-copy"
sdk = Path(r"D:\q\e\src").resolve()
base = Path(r"D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src").resolve()
metadata = Path(r"D:\temp\iteration41-v20-r3-main-cancel-qa-20260927\source-only-metadata-r3").resolve()
fixture = qa / "sdk-bridge-positive-fixture"
out = Path(os.environ["R3_BRIDGE_POSITIVE_OUTPUT"]).resolve()
out.mkdir(parents=True, exist_ok=True)
for p in (copy / "src", sdk, base, metadata):
    sys.path.insert(0, str(p))

expected = {
    "bt_api_execution": copy / "src/bt_api_execution/__init__.py",
    "bt_api_execution.cancellation": copy / "src/bt_api_execution/cancellation.py",
    "bt_api_ctp.ctp.client": sdk / "bt_api_ctp/ctp/client.py",
    "bt_api_base": base / "bt_api_base/__init__.py",
}
for name, path in expected.items():
    mod = importlib.import_module(name)
    actual = Path(mod.__file__).resolve()
    if actual != path.resolve():
        raise RuntimeError(f"origin mismatch {name}: {actual} != {path}")
    print("IMPORT_ORIGIN", name, actual, hashlib.sha256(actual.read_bytes()).hexdigest())
if importlib.metadata.version("bt_api_execution") != "0.2.0":
    raise RuntimeError("execution source-only metadata version mismatch")
if importlib.metadata.version("bt_api_ctp") != "2.0.4+iteration41.i9":
    raise RuntimeError("SDK source-only metadata version mismatch")
if importlib.metadata.version("bt_api_base") != "0.15.4":
    raise RuntimeError("base source-only metadata version mismatch")

test = fixture / "tests/test_ctp_callback_source_bridge.py"
original = copy / "tests/test_ctp_callback_source_bridge.py"
source = test.read_text(encoding="utf-8-sig")
needle = 'SimpleNamespace(FrontID=7, SessionID=19, TradingDay="20260925", MaxOrderRef="90")'
replacement = 'SimpleNamespace(BrokerID="9999", UserID="fake-user", FrontID=7, SessionID=19, TradingDay="20260925", MaxOrderRef="90")'
if source.count(replacement) != 1:
    raise RuntimeError("temporary fixture must contain exactly one scoped login-field addition")
orig_source = original.read_text(encoding="utf-8")
if orig_source.count(needle) != 1 or source.replace(replacement, needle, 1).rstrip() != orig_source.rstrip():
    raise RuntimeError("temporary test fixture is not a one-change copy of manifested test")
print("FIXTURE_ONLY_DIFF", {"added_fields": ["BrokerID", "UserID"], "values": ["9999", "fake-user"], "sdk_login_callback": "_TraderSpi.OnRspUserLogin", "frozen_source_modified": False})

nodes = [
    str(test) + "::test_close_wakes_real_trader_client_poll_and_discards_its_result",
    str(test) + "::test_close_discards_real_sdk_event_dequeued_before_close_wins",
]
result = pytest.main(["-q", "-p", "no:cacheprovider", "-c", str(copy / "pyproject.toml"), "--basetemp=" + str(out / "pytest-basetemp"), "--junitxml=" + str(out / "sdk-bridge-positive.junit.xml"), *nodes])
if int(result) != 0:
    raise SystemExit(int(result))
if any(name.endswith("._ctp") for name in sys.modules):
    raise RuntimeError("native CTP extension loaded")
print("NATIVE_EXTENSION_LOADED", False)




