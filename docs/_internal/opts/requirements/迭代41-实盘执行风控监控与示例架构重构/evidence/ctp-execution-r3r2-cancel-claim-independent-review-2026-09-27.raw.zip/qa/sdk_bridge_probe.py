from __future__ import annotations
import hashlib, importlib, importlib.metadata, json, os, sys
from pathlib import Path
import pytest
copy=Path(r"D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927\source-copy").resolve()
sdk=Path(r"D:\q\e\src").resolve()
base=Path(r"D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src").resolve()
metadata=Path(r"D:\temp\iteration41-v20-r3-main-cancel-qa-20260927\source-only-metadata-r3").resolve()
out=Path(os.environ["R3_SDK_PROBE_OUTPUT"]).resolve()
for p in (copy/"src",sdk,base,metadata): sys.path.insert(0,str(p))
modules=(
 ("bt_api_execution",copy/"src/bt_api_execution/__init__.py"),
 ("bt_api_execution.cancellation",copy/"src/bt_api_execution/cancellation.py"),
 ("bt_api_ctp.ctp.client",sdk/"bt_api_ctp/ctp/client.py"),
 ("bt_api_base",base/"bt_api_base/__init__.py"),
)
for name,expected in modules:
 m=importlib.import_module(name)
 actual=Path(m.__file__).resolve()
 if actual!=expected.resolve(): raise RuntimeError(f"origin mismatch {name}: {actual} != {expected}")
 print("IMPORT_ORIGIN",name,actual,hashlib.sha256(actual.read_bytes()).hexdigest())
if importlib.metadata.version("bt_api_execution")!="0.2.0": raise RuntimeError("metadata mismatch")
if importlib.metadata.version("bt_api_ctp")!="2.0.4+iteration41.i9": raise RuntimeError("SDK metadata mismatch")
if importlib.metadata.version("bt_api_base")!="0.15.4": raise RuntimeError("base metadata mismatch")
test=copy/"tests/test_ctp_callback_source_bridge.py"
nodes=[
 str(test)+"::test_close_wakes_real_trader_client_poll_and_discards_its_result",
 str(test)+"::test_close_discards_real_sdk_event_dequeued_before_close_wins",
]
junit=out/"sdk-bridge.junit.xml"
res=pytest.main(["-q","-p","no:cacheprovider","--basetemp="+str(out/"pytest-basetemp"),"--junitxml="+str(junit),*nodes])
if int(res)!=0: raise SystemExit(int(res))
if any(n=="bt_api_ctp.ctp._ctp" or n.endswith("._ctp") for n in sys.modules): raise RuntimeError("native CTP extension loaded")
print("NATIVE_EXTENSION_LOADED",False)
