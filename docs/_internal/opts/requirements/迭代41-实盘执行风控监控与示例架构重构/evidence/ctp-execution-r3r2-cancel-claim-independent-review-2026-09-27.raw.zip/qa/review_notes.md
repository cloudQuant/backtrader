# Execution R3 r2 independent QA

## Source and scope

- Frozen execution snapshot: `D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r2`
- Freeze manifest SHA-256: `0a0850c107856262470d584132c4d869db1eb4dba6f37a33323fdf569981f41d`
- Parent V20 r2 manifest SHA-256: `15c37a6cc5503127c63d6987b9de0fd71a48181fc33dff5a4e52f57a8fc5d129`
- Independent tests imported a separate copy of the 29 manifest-listed source/test files. The source-only `bt_api_execution` metadata shim reports version `0.2.0`; this is not installed-wheel acceptance.
- Compared r1 and r2 manifest entries: only `src/bt_api_execution/cancellation.py`, `src/bt_api_execution/__init__.py`, and `tests/test_cancellation.py` differ.
- The freeze directory also contains unmanifested `.ruff_cache`, `INCREMENTAL.patch`, and `__pycache__` files. They were left untouched; only manifest-listed files were copied and tested.

## Main package run

PowerShell command: `run_independent.ps1 -OutputDirectory D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927\results`

Result: 278 passed, 2 skipped, 0 failed. The two skipped optional SDK bridge tests were skipped because `bt_api_ctp` was intentionally absent from the package-only PYTHONPATH. JUnit: `results\execution-r3-r2.junit.xml`; stdout/stderr and process metadata are beside it.

The tested cancellation claim contract requires exact `CancelDispatchClaimReceiptV1` type and exact permit reference, scope key, cancel ID, and intent fingerprint. Eight malformed results (`0`, empty string, string, plain object, and each of four identity mismatches) plus claim exceptions latch UNKNOWN; replay does not re-claim; provider is not called; permit is neither released nor settled.

## Explicit integer-zero split

The separate `zero_return_split_probe.py` instrumented two distinct calls:

1. **Claim result is integer zero:** target order setup provider calls = 1, cancel dispatch provider calls = 0, claim calls = 1, first and replay are UNKNOWN, and no release/settle occurs. This is the no-cancel-dispatch case.
2. **Cancel provider itself returns integer zero:** target order setup provider calls = 1, cancel dispatch provider calls = 1, claim calls = 1, first and replay are UNKNOWN, and no release/settle/retry occurs. This is post-dispatch ambiguity, not evidence that the provider was not called.

Raw output and process metadata are in `zero-return-split-results`.

## SDK bridge fixture compatibility

The original two skipped tests were rerun with exact SDK source `D:\q\e\src` and actual execution source-copy origins. They fail before bridge creation because the fake `OnRspUserLogin` omits `BrokerID` and `UserID`; SDK29 correctly refuses to seal login identity when these do not match the client's bound identity.

A separate QA-only fixture copy adds only `BrokerID="9999"` and `UserID="fake-user"` to the existing synthetic terminal login callback. Both bridge lifecycle tests then pass (2 passed). Runtime imports are guarded to the execution source-copy, SDK29 source, and pinned base source. Native `_ctp` was not loaded. Test code and frozen source remain unchanged.

This is a test-fixture compatibility observation, not a change to R3 source. No production provider or real CTP account was accessed. It does not establish an installed-wheel SDK/execution integration.

## Limits

The candidate tests cover the local execution adapter/SQLite contract. They do not prove a remote risk authority, real CTP provider behavior, installed-wheel composition, or production authorization. The SDK tests use the SDK source tree and fake native API; the CTP extension is unavailable on this interpreter.
