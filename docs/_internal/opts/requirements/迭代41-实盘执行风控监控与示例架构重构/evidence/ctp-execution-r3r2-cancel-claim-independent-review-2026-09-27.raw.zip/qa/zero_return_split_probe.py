from __future__ import annotations
import hashlib, importlib, importlib.metadata, importlib.util, json, os, sys
from pathlib import Path
qa = Path(r"D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927")
copy = qa / "source-copy"
base = Path(r"D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src").resolve()
metadata = Path(r"D:\temp\iteration41-v20-r3-main-cancel-qa-20260927\source-only-metadata-r3").resolve()
out = Path(os.environ["R3_ZERO_SPLIT_OUTPUT"]).resolve()
out.mkdir(parents=True, exist_ok=True)
for p in (copy / "src", base, metadata): sys.path.insert(0, str(p))
for name, expected in (
    ("bt_api_execution", copy / "src/bt_api_execution/__init__.py"),
    ("bt_api_execution.cancellation", copy / "src/bt_api_execution/cancellation.py"),
):
    module = importlib.import_module(name)
    actual = Path(module.__file__).resolve()
    if actual != expected.resolve(): raise RuntimeError(f"origin mismatch: {name}: {actual}")
    print("IMPORT_ORIGIN", name, actual, hashlib.sha256(actual.read_bytes()).hexdigest())
if importlib.metadata.version("bt_api_execution") != "0.2.0": raise RuntimeError("metadata mismatch")
test_path = copy / "tests/test_cancellation.py"
spec = importlib.util.spec_from_file_location("r3_zero_split_test_helpers", test_path)
if spec is None or spec.loader is None: raise RuntimeError("cannot load helper")
helpers = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = helpers
spec.loader.exec_module(helpers)

original_submit = helpers.ManagedExecutionFacade.submit

def tracked_submit(self, intent, provider):
    def tracked_provider(value):
        order_setup_calls.append(value.intent_id)
        return provider(value)
    return original_submit(self, intent, tracked_provider)

helpers.ManagedExecutionFacade.submit = tracked_submit
try:
    # Case A: the admission/claim receipt is exact integer zero. Target order
    # setup occurs once, but cancellation dispatch must never be called.
    case_a = out / "claim-return-zero"
    case_a.mkdir(parents=True, exist_ok=True)
    order_setup_calls: list[str] = []
    gate_a = helpers._DurableCancelGate(case_a / "risk.sqlite3")
    store_a, facade_a, gate_a = helpers._ready_facades(case_a, cancel_gate=gate_a)
    cancel_calls_a: list[str] = []
    claim_calls_a: list[str] = []
    def claim_zero(permit_id, intent):
        claim_calls_a.append(intent.cancel_id)
        gate_a.claimed.append(intent.cancel_id)
        with gate_a._connection:
            gate_a._connection.execute("INSERT INTO risk_dispatch_claims (permit_id) VALUES (?)", (permit_id,))
        return 0
    gate_a.claim_before_dispatch = claim_zero
    def cancel_provider_a(intent):
        cancel_calls_a.append(intent.cancel_id)
        return 0
    try:
        first_a = facade_a.cancel(helpers._cancel_intent(), cancel_provider_a)
        second_a = facade_a.cancel(helpers._cancel_intent(), cancel_provider_a)
        assert first_a.state is helpers.ExecutionState.UNKNOWN
        assert second_a.state is helpers.ExecutionState.UNKNOWN
        assert order_setup_calls == ["order.1"]
        assert claim_calls_a == ["cancel.1"]
        assert cancel_calls_a == []
        assert gate_a.released == [] and gate_a.settled == []
        assert gate_a.has_durable_claim("cancel-permit-cancel.1")
        print("CLAIM_RETURN_ZERO", json.dumps({
            "first": first_a.state.value, "replay": second_a.state.value,
            "target_order_setup_provider_calls": len(order_setup_calls),
            "cancel_dispatch_provider_calls": len(cancel_calls_a),
            "claim_calls": len(claim_calls_a), "released": len(gate_a.released),
            "settled": len(gate_a.settled), "durable_claim": True,
        }, sort_keys=True))
    finally:
        gate_a.close(); store_a.close()

    # Case B: the cancellation provider itself returns integer zero. This is
    # post-dispatch ambiguity; the provider is called exactly once, then no retry/release.
    case_b = out / "cancel-provider-return-zero"
    case_b.mkdir(parents=True, exist_ok=True)
    order_setup_calls.clear()
    gate_b = helpers._DurableCancelGate(case_b / "risk.sqlite3")
    store_b, facade_b, gate_b = helpers._ready_facades(case_b, cancel_gate=gate_b)
    cancel_calls_b: list[str] = []
    def cancel_provider_b(intent):
        cancel_calls_b.append(intent.cancel_id)
        return 0
    try:
        first_b = facade_b.cancel(helpers._cancel_intent(), cancel_provider_b)
        second_b = facade_b.cancel(helpers._cancel_intent(), cancel_provider_b)
        assert first_b.state is helpers.ExecutionState.UNKNOWN
        assert second_b.state is helpers.ExecutionState.UNKNOWN
        assert order_setup_calls == ["order.1"]
        assert cancel_calls_b == ["cancel.1"]
        assert gate_b.claimed == ["cancel.1"]
        assert gate_b.released == [] and gate_b.settled == []
        assert gate_b.has_durable_claim("cancel-permit-cancel.1")
        print("CANCEL_PROVIDER_RETURN_ZERO", json.dumps({
            "first": first_b.state.value, "replay": second_b.state.value,
            "target_order_setup_provider_calls": len(order_setup_calls),
            "cancel_dispatch_provider_calls": len(cancel_calls_b),
            "claim_calls": len(gate_b.claimed), "released": len(gate_b.released),
            "settled": len(gate_b.settled), "durable_claim": True,
        }, sort_keys=True))
    finally:
        gate_b.close(); store_b.close()
finally:
    helpers.ManagedExecutionFacade.submit = original_submit
