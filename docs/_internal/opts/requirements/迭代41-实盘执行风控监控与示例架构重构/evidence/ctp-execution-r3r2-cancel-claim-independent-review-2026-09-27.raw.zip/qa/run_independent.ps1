param([Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
$snapshot = 'D:\temp\iteration41_v20_r3_cancel_claim_freeze_20260927_r2'
$snapshotFull = [System.IO.Path]::GetFullPath($snapshot).TrimEnd('\')
$outputFull = [System.IO.Path]::GetFullPath($OutputDirectory).TrimEnd('\')
if ($outputFull.Equals($snapshotFull, [System.StringComparison]::OrdinalIgnoreCase) -or $outputFull.StartsWith($snapshotFull + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'OutputDirectory must be outside freeze' }
New-Item -ItemType Directory -Force -Path $outputFull | Out-Null
$qa = 'D:\temp\iteration41-v20-r3-execution-r2-independent-qa-20260927'
$env:R3_QA_OUTPUT = $outputFull
$env:PYTHONPATH = "$qa\source-copy\src;D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src;D:\temp\iteration41-v20-r3-main-cancel-qa-20260927\source-only-metadata-r3"
$env:PYTHONDONTWRITEBYTECODE = '1'
$python = 'D:\temp\iteration41-main-source-qa-20260926\venv\Scripts\python.exe'
$runner = Join-Path $qa 'independent_run.py'
$proc = Start-Process -FilePath $python -ArgumentList @($runner) -WorkingDirectory "$qa\source-copy" -RedirectStandardOutput (Join-Path $outputFull 'stdout.log') -RedirectStandardError (Join-Path $outputFull 'stderr.log') -PassThru -Wait
[ordered]@{exit_code=$proc.ExitCode; python=$python; runner=$runner; working_directory="$qa\source-copy"; output_directory=$outputFull} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outputFull 'process-result.json') -Encoding UTF8
exit $proc.ExitCode
