# Freeze hash policy

`manifest.json` lists every payload file under `patch/`, `source/`, `tests/`, `JUnit/`, and `evidence/`, with byte count and SHA-256. `manifest.sha256` hashes `manifest.json`. `SHA256SUMS.txt` repeats every payload hash plus both manifest files; it omits itself to avoid a self-referential checksum. Paths are relative to the freeze root. Cache directories and bytecode are excluded.
