# Candidate Store integration contract

This is a D:\temp-only design slice. It is not wired into Backtrader and creates no external actor.

The existing main BtApiStore has a public managed-adapter seam. For non-CTP routes its generic ManagedExecutionAdapter receives a legacy_dispatch callback; CTP uses a specialized managed adapter that enqueues to the local SDK command route. Both remain local execution paths. The CTP F14 authority is a Protocol that claims and rechecks an action; it does not execute through a remote account actor. None of these is a substitute for this separate transport-neutral write port.

For a reviewed integration, add an optional code-owned CtpAccountActorPort to BtApiStore composition and use UnavailableCtpAccountActorPort when absent. Call the route classifier/gate from the raw requested provider/backend and explicit route config before `_resolve_provider` reads `BT_STORE_PROVIDER`, before `_apply_env_gateway_overrides`, before config credential extraction, SDK import, client construction, autostart, or connection. Environment overrides must not downgrade an explicitly requested CTP route. Known CTP routes require the actor and reject if it is unavailable; ambiguous and unsupported routes reject regardless of actor presence. Raw `api` and `api_cls` injection is rejected before any object attribute inspection. Submit/cancel must build exact typed logical intents and invoke only actor_port.submit_order/cancel_order. Do not pass `_submit_order_legacy` / `_cancel_order_ref_legacy` into the actor seam as native capabilities. Put defense-in-depth guards inside the private legacy dispatchers as well.

The candidate gate treats a CTP actor route as actor-owned and never instantiates a local CTP client. A real Store also uses CTP for market data and account queries; therefore a future actor client must supply the required read-only events/snapshot feed or the Store must remain unavailable. Do not silently construct local TraderClient for data after routing writes externally.

## r3 code-owned route registry

The classifier accepts only selectors represented by this small, explicit
registry. It does not infer safety from an arbitrary provider name or a
`_gateway` suffix:

| Selector | Candidate treatment |
|---|---|
| `ctp`, `ctp_gateway` | CTP, regardless of environment overrides |
| `okx`, `binance` | Non-CTP direct route when backend is omitted or `direct` |
| `btapi` | Non-CTP only with explicit complete route facts, all in `OKX`, `BINANCE`, `MT5`, `IB_WEB` |
| `gateway` | Non-CTP only with explicit `IB_WEB` or `MT5` route facts; no selector defaults to CTP |
| `ib_web_gateway`, `mt5_gateway` | Non-CTP only when explicit route facts exactly match the alias; no selector defaults to CTP |
| `futu`, `oanda`, `vc` | Explicitly unsupported |
| Any other selector, backend, or route value | Ambiguous and rejected before local construction |

Any CTP selector discovered in top-level exchange fields, `exchange_kwargs`,
or recursively nested `symbol_routes` takes precedence. Raw `api` and `api_cls`
injections are always ambiguous for this gate. The classifier never reads
attributes from either object. Environment provider changes do not grant a
non-CTP route; a requested CTP provider remains CTP even if environment fields
name `IB_WEB`, `MT5`, or another gateway.

This deliberately narrows compatibility. The public main Store documents
`provider="okx", api=...`; this candidate would reject that injected-client
form. It preserves code-owned direct `okx`/`binance` selectors and the observed
explicit gateway forms above. The main `BtApiStore` also accepts custom
providers and injected SDK classes; those require a separately reviewed
registry entry rather than implicit NON_CTP classification. These are
candidate rules, not a claim that all historical BtApiStore paths have been
integrated.

## r6 immutable route snapshot and authority limit

`StoreRouteSnapshot` stores a frozen route kind, canonical bytes, and SHA-256
digest. It accepts only the exact route descriptor and built-in nested values,
and reads the descriptor's instance dictionary instead of invoking caller
properties or mapping methods. API/API-class objects are represented only as
presence bits; the route gate rejects their injection before snapshot use.
Construction rechecks the digest and canonical bytes immediately before and
after each injected resolver/factory callback. A resolver that changes a
shared nested route is rejected before the gateway factory runs; a gateway
factory that changes it is rejected before its result is published. Submit
and cancel also recapture and compare before dispatch. A changed nested field
or route selector rejects before later harness dispatch; replacing a mapping
with equal canonical content is allowed because the route meaning is
unchanged. These synchronous checks do not provide atomicity against arbitrary
concurrent mutation of caller-owned mutable route data.

`ActorCommandContextV1` carries account reference, runtime id, mode, config
digest, session id, session generation, and expected actor epoch. The V2
submit/cancel digest canonically binds this context, operation, command id, and
logical intent fields. `ActorCommandReceiptV2` must return the exact context,
command id, and digest. The fake harness compares every field. These fields
and the digest are local comparisons; they do not prove the actor's current
epoch or authenticate a receipt.

`FakeLocalActorReplayLedger` is process-local and cannot prove uniqueness after
process restart or across hosts. The default CTP submit/cancel path therefore
rejects every command before calling a provided actor port unless a separately
trusted durable remote Actor exists; this candidate has no trust handshake or
implementation for one. The separate
`store_boundary_harness_testonly.LocalFakeStoreBoundaryHarness` module opts
into fake actor calls for unit tests. The ordinary harness exposes no
`test_only_local_fake_dispatch` flag. Importing that separate class is a
caller-controlled test entry point and cannot serve as external authority or
a production security gate. The test-only module uses an in-memory ledger to check
same-process duplicate calls and is not imported by Backtrader, a Store, or a
runtime registry. It makes no cross-process, durability, account-fence, or
external-authority claim. Fresh processes submitting the same command both
fail closed by default.

No real AccountActorPort implementation, credentials, service identity,
deployment trust pin, external account fence, provider snapshot, callback
feed, handoff, or native API exists here. A reviewed integration still needs
an independently authenticated remote Actor that owns durable idempotency and
provider dispatch, plus authoritative epoch/account/session validation,
cross-host fencing, and a read/callback snapshot contract. This candidate does
not enable a default CTP route.
