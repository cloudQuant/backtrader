import json
from decimal import Decimal

from account_actor_port import AccountActorGateError, FakeLocalActorReplayLedger, StoreRouteDescriptor
from store_boundary_harness import StoreBoundaryHarness
from store_boundary_harness_testonly import LocalFakeStoreBoundaryHarness
from test_store_boundary_harness import FakeActorPort, actor_context, submit_intent

rows=[]
def capture(name, fn):
    try:
        value=fn()
        rows.append({"case":name,"outcome":"ok","value":value})
    except AccountActorGateError as exc:
        rows.append({"case":name,"outcome":"gate_rejected","code":exc.code})
    except Exception as exc:
        rows.append({"case":name,"outcome":"exception","type":type(exc).__name__})

# Original r5 constructor TOCTOU: resolver flips a safe gateway to CTP and
# attaches an opaque API object; no factory/API callback should run.
r=StoreRouteDescriptor(provider="gateway",backend="gateway",config={"exchange_type":"IB_WEB"})
c={"resolver":0,"gateway":0,"api":0}
def resolver_ctp():
    c["resolver"]+=1
    r.config["exchange_type"]="CTP"
    object.__setattr__(r,"api",object())
def gf(): c.__setitem__("gateway",c["gateway"]+1); return object()
def af(): c.__setitem__("api",c["api"]+1); return object()
capture("r5_resolver_flip_to_ctp",lambda: StoreBoundaryHarness(r,credential_resolver=resolver_ctp,gateway_factory=gf,api_factory=af))
rows[-1]["calls"]=dict(c)

# More than one final-state route change in resolver; same NON_CTP class still
# has to be rejected because canonical route bytes differ.
r=StoreRouteDescriptor(provider="gateway",backend="gateway",config={"exchange_type":"IB_WEB"})
c={"resolver":0,"gateway":0}
def resolver_multi():
    c["resolver"]+=1
    r.config["exchange_type"]="CTP"
    r.config["exchange_type"]="MT5"
    r.config["symbol_routes"]={"IF2601":"CTP"}
capture("resolver_multiple_mutations_final_nested_ctp",lambda: StoreBoundaryHarness(r,credential_resolver=resolver_multi,gateway_factory=lambda: c.__setitem__("gateway",c["gateway"]+1)))
rows[-1]["calls"]=dict(c)

# Same-kind final route mutation.
r=StoreRouteDescriptor(provider="gateway",backend="gateway",config={"exchange_type":"IB_WEB"})
c={"resolver":0,"gateway":0}
def resolver_same_kind():
    c["resolver"]+=1
    r.config["exchange_type"]="MT5"
capture("resolver_same_kind_mutation",lambda: StoreBoundaryHarness(r,credential_resolver=resolver_same_kind,gateway_factory=lambda: c.__setitem__("gateway",c["gateway"]+1)))
rows[-1]["calls"]=dict(c)

# A callback that mutates and restores to the same canonical bytes is
# indistinguishable to post-callback snapshot validation; factory sees a
# verified final snapshot and is invoked.
r=StoreRouteDescriptor(provider="gateway",backend="gateway",config={"exchange_type":"IB_WEB"})
c={"resolver":0,"gateway":0}
def resolver_restore():
    c["resolver"]+=1
    r.config["exchange_type"]="CTP"
    r.config["exchange_type"]="IB_WEB"
def gateway_ok(): c["gateway"]+=1; return "fake-gateway"
obj=StoreBoundaryHarness(r,credential_resolver=resolver_restore,gateway_factory=gateway_ok)
rows.append({"case":"resolver_transient_mutate_then_restore","outcome":"constructed","calls":dict(c),"api_published":obj.api=="fake-gateway"})

# The factory itself changes route after being verified. It necessarily runs;
# the post-check rejects construction, does not publish result, and never
# reaches the separately injected API factory.
r=StoreRouteDescriptor(provider="gateway",backend="gateway",config={"exchange_type":"IB_WEB"})
c={"resolver":0,"gateway":0,"api":0}
def resolver_ok(): c["resolver"]+=1
def gateway_mutate():
    c["gateway"]+=1
    r.config["symbol_routes"]={"IF2601":"CTP"}
    return "must-not-publish"
def api_forbidden(): c["api"]+=1; return object()
capture("gateway_factory_mutates_to_ctp",lambda: StoreBoundaryHarness(r,credential_resolver=resolver_ok,gateway_factory=gateway_mutate,api_factory=api_forbidden))
rows[-1]["calls"]=dict(c)

# Ordinary CTP path cannot use supplied local fake Actor or legacy dispatch.
actor=FakeActorPort(); ctx=actor_context()
store=StoreBoundaryHarness(StoreRouteDescriptor(provider="ctp",backend="direct"),actor_port=actor,actor_context=ctx)
capture("ordinary_harness_fake_actor_submit",lambda: store.submit_order(submit_intent(context=ctx,intent_id="ordinary")))
rows[-1]["actor_submits"]=len(actor.submits); rows[-1]["legacy_calls"]=store.legacy_calls

# The explicit test-only adapter can dispatch a local fake; this proves its
# name/path is a caller-controlled test seam, not production authority.
actor=FakeActorPort(); ctx=actor_context()
test_store=LocalFakeStoreBoundaryHarness(StoreRouteDescriptor(provider="ctp",backend="direct"),actor_port=actor,actor_context=ctx,receipt_ledger=FakeLocalActorReplayLedger())
result=test_store.submit_order(submit_intent(context=ctx,intent_id="testonly"))
rows.append({"case":"explicit_testonly_fake_dispatch","outcome":"local_fake_only","actor_submits":len(actor.submits),"receipt_state":result.state.value,"legacy_calls":test_store.legacy_calls})
print(json.dumps(rows,sort_keys=True,indent=2))
