"""Fake-suite tripwire: forbid native CTP SDK imports and network APIs."""
import builtins
import socket

_original_import = builtins.__import__


def _guarded_import(name, *args, **kwargs):
    root = name.split(".", 1)[0]
    if root in {"bt_api_py", "_ctp"}:
        raise AssertionError("forbidden CTP SDK/native import: " + name)
    return _original_import(name, *args, **kwargs)


def _blocked_network(*_args, **_kwargs):
    raise AssertionError("network access is forbidden in the LOCAL_FAKE suite")


builtins.__import__ = _guarded_import
for _name in ("create_connection", "getaddrinfo", "gethostbyname", "gethostbyname_ex", "gethostbyaddr"):
    setattr(socket, _name, _blocked_network)
