"""Unit-test-only fake CTP dispatch seam.

Never import this module from Backtrader, a Store, runtime registry, or an
operator entry point. The in-memory ledger and fake port prove local plumbing
only; they have no remote identity, cross-process uniqueness, or account
authority.
"""
from __future__ import annotations

from typing import Any, Optional

from account_actor_port import (
    AccountActorGateError,
    CtpCancelIntentV2,
    CtpSubmitIntentV2,
    FakeLocalActorReplayLedger,
    RouteKind,
    StoreRouteDescriptor,
    classify_store_route,
)
from store_boundary_harness import StoreBoundaryHarness


class LocalFakeStoreBoundaryHarness(StoreBoundaryHarness):
    """Explicit local fake path for isolated unit tests only."""

    def __init__(
        self,
        route: StoreRouteDescriptor,
        *,
        receipt_ledger: Optional[FakeLocalActorReplayLedger] = None,  # noqa: UP045 - Python 3.8
        **kwargs,
    ) -> None:
        if type(receipt_ledger) is not FakeLocalActorReplayLedger:
            raise AccountActorGateError("fake_replay_ledger_required")
        if classify_store_route(route) is not RouteKind.CTP:
            raise AccountActorGateError("local_fake_harness_requires_ctp_route")
        super().__init__(route, **kwargs)
        if self.route_kind is not RouteKind.CTP:
            raise AccountActorGateError("local_fake_harness_requires_ctp_route")
        self.__receipt_ledger = receipt_ledger

    def _dispatch_actor_command(self, operation: str, intent: object) -> Any:
        if type(intent) not in {CtpSubmitIntentV2, CtpCancelIntentV2}:
            raise AccountActorGateError("typed_actor_intent_required")
        self.__receipt_ledger.claim_once(intent)
        if operation == "SUBMIT":
            return self.actor_port.submit_order(intent)
        if operation == "CANCEL":
            return self.actor_port.cancel_order(intent)
        raise AccountActorGateError("actor_operation_unsupported")
