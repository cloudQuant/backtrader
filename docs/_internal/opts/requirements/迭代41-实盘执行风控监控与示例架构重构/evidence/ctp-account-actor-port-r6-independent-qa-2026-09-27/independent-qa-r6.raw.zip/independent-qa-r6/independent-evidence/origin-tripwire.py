import importlib, json, pathlib, socket, sys
import sitecustomize
mods=[importlib.import_module(n) for n in ('account_actor_port','store_boundary_harness','store_boundary_harness_testonly')]
origins={m.__name__:str(pathlib.Path(m.__file__).resolve()) for m in mods}
expected_root=pathlib.Path(sys.path[0]).resolve().parent / 'source'
assert all(pathlib.Path(p).resolve().parent == expected_root for p in origins.values()), origins
assert str(pathlib.Path(sitecustomize.__file__).resolve()).endswith('evidence\\guard\\sitecustomize.py')
blocked=[]
for label, fn in [('sdk_import',lambda: importlib.import_module('bt_api_py')),('network_dns',lambda: socket.getaddrinfo('localhost',80))]:
    try: fn()
    except AssertionError: blocked.append(label)
    else: raise AssertionError(label+' was not blocked')
assert blocked == ['sdk_import','network_dns'], blocked
assert not any(n.split('.',1)[0] in {'bt_api_py','_ctp'} for n in sys.modules)
print(json.dumps({'module_origins':origins,'sitecustomize':sitecustomize.__file__,'tripwire_blocks':blocked,'forbidden_modules_loaded':False},sort_keys=True,indent=2))
