"""Tiny fake Store boundary. It models ordering only and never imports Backtrader."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any, Optional

from account_actor_port import (
    AccountActorGateError,
    ActorCommandContextV1,
    ActorCommandExpectationV2,
    CtpAccountActorPort,
    CtpCancelIntentV2,
    CtpSubmitIntentV2,
    RouteKind,
    StoreRouteDescriptor,
    StoreRouteSnapshot,
    capture_store_route_snapshot,
    classify_store_route,
    reject_ctp_legacy_dispatch,
    require_account_actor_before_local_client,
    validate_actor_receipt,
)


class StoreBoundaryHarness:
    def __init__(
        self,
        route: StoreRouteDescriptor,
        *,
        actor_port: Optional[CtpAccountActorPort] = None,  # noqa: UP045 - Python 3.8
        actor_context: Optional[ActorCommandContextV1] = None,  # noqa: UP045 - Python 3.8
        credential_resolver: Optional[Callable[[], Any]] = None,  # noqa: UP045 - Python 3.8
        api_factory: Optional[Callable[[], Any]] = None,  # noqa: UP045 - Python 3.8
        gateway_factory: Optional[Callable[[], Any]] = None,  # noqa: UP045 - Python 3.8
    ) -> None:
        # Gate the route before retaining or invoking any local API/API
        # class/gateway factory, credential resolver, environment lookup, or SDK.
        self.route_kind = classify_store_route(route)
        self.actor_port = require_account_actor_before_local_client(route, actor_port)
        self._route_descriptor = route
        self._route_snapshot: StoreRouteSnapshot = capture_store_route_snapshot(route)
        if self._route_snapshot.route_kind is not self.route_kind:
            raise AccountActorGateError("store_route_changed_during_construction")
        # Retain only immutable selector facts from the accepted snapshot.
        # Never use the mutable descriptor dictionary after an injected
        # callback has had an opportunity to mutate it.
        route_fields = object.__getattribute__(route, "__dict__")
        route_backend = route_fields["backend"]
        route_api_present = route_fields["api"] is not None
        route_api_cls_present = route_fields["api_cls"] is not None
        if self.route_kind is RouteKind.CTP:
            if type(actor_context) is not ActorCommandContextV1:
                raise AccountActorGateError("actor_command_context_required")
            self.actor_context = actor_context
        else:
            self.actor_context = actor_context
        self.api = None
        self.legacy_calls = 0
        # This ordering models the production boundary: classification and the
        # unavailable-actor rejection precede credential resolution too.
        if self.route_kind is RouteKind.NON_CTP and credential_resolver is not None:
            self._require_current_route_snapshot()
            credential_resolver()
            # A resolver is caller code and may mutate a shared nested route.
            # Stop before any gateway/client factory or subsequent route use.
            self._require_current_route_snapshot()
        if self.route_kind is RouteKind.NON_CTP:
            if route_api_present or route_api_cls_present:
                raise AccountActorGateError("store_route_changed_during_construction")
            if route_backend == "gateway" and gateway_factory is not None:
                self._require_current_route_snapshot()
                api = gateway_factory()
                # Factories are executable callbacks too. Do not publish or
                # use their result if the route changed during construction.
                self._require_current_route_snapshot()
                self.api = api
        elif route_api_present or route_api_cls_present:
            # The gate above rejects these for an actor-owned CTP route.
            raise AccountActorGateError("local_ctp_client_injection_forbidden")

    def submit_order(self, intent: object) -> Any:
        self._require_current_route_snapshot()
        if self.route_kind is RouteKind.CTP:
            if type(intent) is not CtpSubmitIntentV2:
                raise AccountActorGateError("typed_submit_intent_required")
            self._require_current_actor_context(intent)
            expected = ActorCommandExpectationV2.from_intent(intent)
            receipt = self._dispatch_actor_command("SUBMIT", intent)
            return validate_actor_receipt(receipt, expected=expected)
        return self._submit_order_legacy(intent)

    def cancel_order(self, intent: object) -> Any:
        self._require_current_route_snapshot()
        if self.route_kind is RouteKind.CTP:
            if type(intent) is not CtpCancelIntentV2:
                raise AccountActorGateError("typed_cancel_intent_required")
            self._require_current_actor_context(intent)
            expected = ActorCommandExpectationV2.from_intent(intent)
            receipt = self._dispatch_actor_command("CANCEL", intent)
            return validate_actor_receipt(receipt, expected=expected)
        return self._cancel_order_legacy(intent)

    def _require_current_route_snapshot(self) -> None:
        try:
            current = capture_store_route_snapshot(self._route_descriptor)
        except AccountActorGateError:
            raise AccountActorGateError("store_route_changed_after_construction") from None
        if (
            current.digest != self._route_snapshot.digest
            or current.canonical_bytes != self._route_snapshot.canonical_bytes
            or current.route_kind is not self._route_snapshot.route_kind
        ):
            raise AccountActorGateError("store_route_changed_after_construction")

    def _dispatch_actor_command(self, operation: str, intent: object) -> Any:
        del operation, intent
        raise AccountActorGateError("trusted_durable_remote_actor_unavailable")

    def _require_current_actor_context(self, intent: Any) -> None:
        if type(intent.context) is not ActorCommandContextV1:
            raise AccountActorGateError("actor_intent_context_invalid")
        try:
            intent.context.__post_init__()
            intent.__post_init__()
        except (AttributeError, TypeError, ValueError):
            raise AccountActorGateError("actor_intent_invalid") from None
        if intent.context != self.actor_context:
            raise AccountActorGateError("actor_intent_context_mismatch")

    def _submit_order_legacy(self, value: object) -> str:
        del value
        self._require_current_route_snapshot()
        reject_ctp_legacy_dispatch(self.route_kind)
        self.legacy_calls += 1
        return "legacy_non_ctp"

    def _cancel_order_legacy(self, value: object) -> str:
        del value
        self._require_current_route_snapshot()
        reject_ctp_legacy_dispatch(self.route_kind)
        self.legacy_calls += 1
        return "legacy_non_ctp"
