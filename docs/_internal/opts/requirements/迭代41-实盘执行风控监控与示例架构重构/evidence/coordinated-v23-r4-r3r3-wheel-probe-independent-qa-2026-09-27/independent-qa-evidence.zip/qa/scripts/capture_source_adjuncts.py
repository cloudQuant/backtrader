import collections,hashlib,json,pathlib,shutil,datetime
qa=pathlib.Path(r'D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927')
ex=qa/'extracted'
source_map=json.loads((ex/'candidate-v3'/'source-roots.json').read_text(encoding='utf-8-sig'))
module_names={'base':'bt_api_base','ctp':'bt_api_ctp','risk':'bt_api_risk','monitor':'bt_api_monitor','gateway':'bt_api_gateway','transport_zmq':'bt_api_transport_zmq','agent':'backtrader_agent','skills':'backtrader_skills','mcp':'backtrader_mcp'}
allowed={'.py','.pyi','.json','.toml','.txt','.md'}
blocked_names={'config.yaml','config.yml','credentials.json','secrets.json'}
blocked_ext={'.pem','.key','.p12','.pfx','.sqlite','.db','.pyd','.dll','.so','.dylib','.whl'}
base_out=qa/'source-adjuncts'; base_out.mkdir()
rows=[]; roots={}
for key,module in module_names.items():
 src=pathlib.Path(source_map[key]).resolve(strict=True)
 dest=base_out/key/'src'; dest.mkdir(parents=True)
 listed=[]; skipped=collections.Counter()
 for p in sorted(src.rglob('*')):
  if p.is_dir():
   if p.name in {'__pycache__','.pytest_cache','.git'}: skipped['cache_or_git_dirs']+=1
   continue
  if p.is_symlink() or bool(getattr(p.stat(),'st_file_attributes',0)&0x400): skipped['reparse_or_symlink_files']+=1; continue
  rel=p.relative_to(src); suffix=p.suffix.lower()
  if p.name.lower() in blocked_names or suffix in blocked_ext or p.name.lower().startswith('.env') or any(x in p.name.lower() for x in ('secret','credential','private_key','token')):
   skipped['sensitive_or_native_filtered']+=1; continue
  if suffix not in allowed and p.name not in {'py.typed','LICENSE','NOTICE'}:
   skipped[f'extension:{suffix or "<none>"}']+=1; continue
  target=dest/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,target)
  data=target.read_bytes(); listed.append({'path':rel.as_posix(),'size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 package_dir=dest/module
 module_file=dest/f'{module}.py'
 assert (package_dir/'__init__.py').is_file() or module_file.is_file(),(key,str(src),'top-level module absent after safe copy')
 roots[key]=str(dest.resolve())
 rows.append({'key':key,'module':module,'source_path':str(src),'copied_root':str(dest.resolve()),'copied_file_count':len(listed),'copied_bytes':sum(x['size_bytes'] for x in listed),'files':listed,'filtered_counts':dict(skipped)})
# For the two packages under test, map their own frozen candidate source to installed wheel site-packages after environment creation.
for key in ('parent','execution'):
 roots[key]='__SITE_PACKAGES__'
result={'schema':'independent-coordinated-probe-source-adjuncts-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_tree_claim':'External mapped helper roots copied as inert source files; not part of author 843-file candidate source manifest. Each copied file is hash-bound here. Sensitive/native/cache file filters are listed in script.','roots':rows}
(qa/'source-adjunct-manifest.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(qa/'source-roots-template.json').write_text(json.dumps(roots,indent=2),encoding='utf-8')
print(json.dumps({'source_adjuncts':[{k:r[k] for k in ('key','copied_file_count','copied_bytes','filtered_counts')} for r in rows],'status':'safe source roots copied; parent/execution will bind after venv creation'},indent=2))
