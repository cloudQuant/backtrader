"""Read-only consumer for the Iteration 41 deployment-evidence wire contract.

This module intentionally has no dependency on Backtrader, bt-api, an AI
producer, a provider SDK, or a network client.  It parses local JSON, validates
the canonical ``bt-api-deployment-evidence/v1`` shape, and compares explicit
caller-provided bindings.  A successful result is evidence validation only; it
does not grant credentials, execution authority, or any control capability.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import stat
import time
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, cast

from .errors import ContractError, SkillsError

DEPLOYMENT_EVIDENCE_SCHEMA_VERSION = "bt-api-deployment-evidence/v1"

_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_REVIEW_STATUSES = frozenset({"human_reviewed", "mechanically_mapped", "review_required"})
_PROMOTION_REVIEW_STATUSES = frozenset({"human_reviewed", "mechanically_mapped"})
_SENSITIVE_KEY_PARTS = (
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "passphrase",
    "password",
    "private_key",
    "secret",
    "token",
)
_MAX_EVIDENCE_BYTES = 1024 * 1024
_CHUNK_SIZE = 1024 * 1024


class DeploymentEvidenceError(ContractError):
    """The supplied local evidence does not satisfy the published wire contract."""

    code = "DEPLOYMENT_EVIDENCE_INVALID"


class DeploymentEvidenceExpired(DeploymentEvidenceError):
    """The evidence was validly shaped but is no longer current."""

    code = "DEPLOYMENT_EVIDENCE_EXPIRED"


class DeploymentEvidenceMismatch(DeploymentEvidenceError):
    """An explicit local scope or hash binding does not match the evidence."""

    code = "DEPLOYMENT_EVIDENCE_MISMATCH"


class DeploymentPromotionRejected(DeploymentEvidenceError):
    """The semantic review state cannot pass a promotion review gate."""

    code = "DEPLOYMENT_PROMOTION_REJECTED"


def _identifier(value: object, field_name: str) -> str:
    if not isinstance(value, str) or value != value.strip() or not _IDENTIFIER.fullmatch(value):
        raise DeploymentEvidenceError(f"invalid {field_name}", details={"field": field_name})
    return value


def _sha256(value: object, field_name: str) -> str:
    if not isinstance(value, str) or not _SHA256.fullmatch(value):
        raise DeploymentEvidenceError(f"invalid {field_name}", details={"field": field_name})
    return value


def _timestamp(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise DeploymentEvidenceError(f"invalid {field_name}", details={"field": field_name})
    return float(value)


def _field_path(parent: str, child: str) -> str:
    return f"{parent}.{child}" if parent else child


def _validate_json(value: object, path: str = "") -> None:
    """Reject non-canonical values and secret-shaped metadata before serializing."""

    if value is None or isinstance(value, (str, bool)):
        return
    if isinstance(value, int) and not isinstance(value, bool):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise DeploymentEvidenceError(
                f"non-finite JSON value at {path or 'payload'}",
                details={"field": path or "payload"},
            )
        return
    if isinstance(value, Mapping):
        for key, nested in value.items():
            if not isinstance(key, str):
                raise DeploymentEvidenceError(
                    "JSON object keys must be strings", details={"field": path or "payload"}
                )
            normalized = key.lower().replace("-", "_")
            nested_path = _field_path(path, key)
            if any(part in normalized for part in _SENSITIVE_KEY_PARTS):
                raise DeploymentEvidenceError(
                    f"secret-shaped field is forbidden at {nested_path}",
                    details={"field": nested_path},
                )
            _validate_json(nested, nested_path)
        return
    if isinstance(value, (list, tuple)):
        for index, nested in enumerate(value):
            _validate_json(nested, _field_path(path, str(index)))
        return
    raise DeploymentEvidenceError(
        f"unsupported JSON type at {path or 'payload'}",
        details={"field": path or "payload"},
    )


def _to_mutable_json(value: object) -> object:
    if isinstance(value, Mapping):
        return {str(key): _to_mutable_json(nested) for key, nested in value.items()}
    if isinstance(value, tuple):
        return [_to_mutable_json(nested) for nested in value]
    return value


def _freeze_json(value: object) -> object:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze_json(nested) for key, nested in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_json(nested) for nested in value)
    return value


def canonical_json(value: object) -> str:
    """Return the compatible canonical JSON form used for evidence digests."""

    _validate_json(value)
    return json.dumps(
        _to_mutable_json(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def evidence_sha256(value: object) -> str:
    """Return the SHA-256 digest for a canonical wire payload."""

    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _require_exact_fields(
    raw: Mapping[object, object], expected: frozenset[str], label: str
) -> None:
    keys = tuple(raw.keys())
    if any(not isinstance(key, str) for key in keys) or set(keys) != expected:
        raise DeploymentEvidenceError(f"invalid {label} wire fields", details={"field": label})


@dataclass(frozen=True)
class StrategyDeploymentEvidence:
    """Immutable local representation of a redacted deployment-evidence record."""

    evidence_id: str
    producer_product: str
    producer_version: str
    producer_commit: str
    producer_wheel_sha256: str
    tenant_id: str
    strategy_id: str
    artifact_sha256: str
    config_effective_digest: str
    review_status: str
    created_at: float
    expires_at: float
    metadata: Mapping[str, object]
    schema_version: str = DEPLOYMENT_EVIDENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != DEPLOYMENT_EVIDENCE_SCHEMA_VERSION:
            raise DeploymentEvidenceError(
                "unsupported evidence schema_version", details={"field": "schema_version"}
            )
        for field_name in (
            "evidence_id",
            "producer_product",
            "producer_version",
            "producer_commit",
            "tenant_id",
            "strategy_id",
        ):
            object.__setattr__(self, field_name, _identifier(getattr(self, field_name), field_name))
        for field_name in ("producer_wheel_sha256", "artifact_sha256", "config_effective_digest"):
            object.__setattr__(self, field_name, _sha256(getattr(self, field_name), field_name))
        if self.review_status not in _REVIEW_STATUSES:
            raise DeploymentEvidenceError(
                "invalid review_status", details={"field": "review_status"}
            )
        created_at = _timestamp(self.created_at, "created_at")
        expires_at = _timestamp(self.expires_at, "expires_at")
        if expires_at <= created_at:
            raise DeploymentEvidenceError(
                "evidence expires_at must be after created_at", details={"field": "expires_at"}
            )
        object.__setattr__(self, "created_at", created_at)
        object.__setattr__(self, "expires_at", expires_at)
        if not isinstance(self.metadata, Mapping):
            raise DeploymentEvidenceError(
                "metadata must be an object", details={"field": "metadata"}
            )
        _validate_json(self.metadata, "metadata")
        object.__setattr__(
            self,
            "metadata",
            _freeze_json(json.loads(canonical_json(self.metadata))),
        )

    @property
    def digest(self) -> str:
        """The independently reproducible digest of the normalized wire record."""

        return evidence_sha256(self.to_dict())

    def to_dict(self) -> dict[str, object]:
        """Return the exact portable wire shape, without any local path or authority."""

        return {
            "artifact_sha256": self.artifact_sha256,
            "config_effective_digest": self.config_effective_digest,
            "created_at": self.created_at,
            "evidence_id": self.evidence_id,
            "expires_at": self.expires_at,
            "metadata": _to_mutable_json(self.metadata),
            "producer": {
                "commit": self.producer_commit,
                "product": self.producer_product,
                "version": self.producer_version,
                "wheel_sha256": self.producer_wheel_sha256,
            },
            "review_status": self.review_status,
            "schema_version": self.schema_version,
            "strategy_id": self.strategy_id,
            "tenant_id": self.tenant_id,
        }

    @classmethod
    def from_dict(cls, raw: Mapping[object, object]) -> "StrategyDeploymentEvidence":
        """Load only the exact v1 wire fields; silent extensions are forbidden."""

        if not isinstance(raw, Mapping):
            raise DeploymentEvidenceError(
                "evidence must be an object", details={"field": "payload"}
            )
        expected = frozenset(
            {
                "artifact_sha256",
                "config_effective_digest",
                "created_at",
                "evidence_id",
                "expires_at",
                "metadata",
                "producer",
                "review_status",
                "schema_version",
                "strategy_id",
                "tenant_id",
            }
        )
        _require_exact_fields(raw, expected, "evidence")
        producer = raw["producer"]
        if not isinstance(producer, Mapping):
            raise DeploymentEvidenceError(
                "producer must be an object", details={"field": "producer"}
            )
        _require_exact_fields(
            producer,
            frozenset({"commit", "product", "version", "wheel_sha256"}),
            "producer",
        )
        return cls(
            evidence_id=cast(str, raw["evidence_id"]),
            producer_product=producer["product"],
            producer_version=producer["version"],
            producer_commit=producer["commit"],
            producer_wheel_sha256=producer["wheel_sha256"],
            tenant_id=cast(str, raw["tenant_id"]),
            strategy_id=cast(str, raw["strategy_id"]),
            artifact_sha256=cast(str, raw["artifact_sha256"]),
            config_effective_digest=cast(str, raw["config_effective_digest"]),
            review_status=cast(str, raw["review_status"]),
            created_at=cast(float, raw["created_at"]),
            expires_at=cast(float, raw["expires_at"]),
            metadata=cast(Mapping[str, object], raw["metadata"]),
            schema_version=cast(str, raw["schema_version"]),
        )


def _reject_duplicate_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise DeploymentEvidenceError(f"duplicate JSON field: {key}", details={"field": key})
        result[key] = value
    return result


def _reject_non_finite(value: str) -> object:
    raise DeploymentEvidenceError(f"non-finite JSON value is forbidden: {value}")


def _read_regular_file(path: Path, *, maximum_bytes: int, label: str) -> bytes:
    try:
        file_status = path.lstat()
    except OSError as error:
        raise DeploymentEvidenceError(
            f"unable to read {label}", details={"field": label}
        ) from error
    if stat.S_ISLNK(file_status.st_mode) or not stat.S_ISREG(file_status.st_mode):
        raise DeploymentEvidenceError(
            f"{label} must be a regular non-symlink file", details={"field": label}
        )
    if file_status.st_size > maximum_bytes:
        raise DeploymentEvidenceError(
            f"{label} exceeds the {maximum_bytes}-byte limit", details={"field": label}
        )
    try:
        payload = path.read_bytes()
    except OSError as error:
        raise DeploymentEvidenceError(
            f"unable to read {label}", details={"field": label}
        ) from error
    if len(payload) > maximum_bytes:
        raise DeploymentEvidenceError(
            f"{label} exceeds the {maximum_bytes}-byte limit", details={"field": label}
        )
    return payload


def load_deployment_evidence(path: str | Path) -> StrategyDeploymentEvidence:
    """Read one local JSON evidence record without resolving links or writing state."""

    payload = _read_regular_file(Path(path), maximum_bytes=_MAX_EVIDENCE_BYTES, label="evidence")
    try:
        decoded = payload.decode("utf-8")
    except UnicodeDecodeError as error:
        raise DeploymentEvidenceError(
            "evidence must be UTF-8 JSON", details={"field": "evidence"}
        ) from error
    try:
        raw = json.loads(
            decoded,
            object_pairs_hook=_reject_duplicate_object,
            parse_constant=_reject_non_finite,
        )
    except DeploymentEvidenceError:
        raise
    except json.JSONDecodeError as error:
        raise DeploymentEvidenceError(
            f"invalid evidence JSON: {error.msg}", details={"field": "evidence"}
        ) from error
    return StrategyDeploymentEvidence.from_dict(raw)


def _coerce_evidence(
    value: StrategyDeploymentEvidence | Mapping[object, object] | str | Path,
) -> StrategyDeploymentEvidence:
    if isinstance(value, StrategyDeploymentEvidence):
        return value
    if isinstance(value, (str, Path)):
        return load_deployment_evidence(value)
    if isinstance(value, Mapping):
        return StrategyDeploymentEvidence.from_dict(value)
    raise DeploymentEvidenceError("evidence must be a wire object or local path")


def _expected_identifier(
    *,
    expected: str | None,
    alias: str | None,
    field_name: str,
) -> str:
    if expected is not None and alias is not None and expected != alias:
        raise DeploymentEvidenceError(
            f"conflicting expected {field_name} values", details={"field": field_name}
        )
    selected = expected if expected is not None else alias
    if selected is None:
        raise DeploymentEvidenceError(
            f"expected {field_name} is required", details={"field": field_name}
        )
    return _identifier(selected, f"expected_{field_name}")


def _file_sha256(path: Path) -> str:
    try:
        file_status = path.lstat()
    except OSError as error:
        raise DeploymentEvidenceError(
            "unable to read artifact", details={"field": "artifact"}
        ) from error
    if stat.S_ISLNK(file_status.st_mode) or not stat.S_ISREG(file_status.st_mode):
        raise DeploymentEvidenceError(
            "artifact must be a regular non-symlink file", details={"field": "artifact"}
        )
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(_CHUNK_SIZE), b""):
                digest.update(chunk)
    except OSError as error:
        raise DeploymentEvidenceError(
            "unable to read artifact", details={"field": "artifact"}
        ) from error
    return digest.hexdigest()


def _validation_result(
    evidence: StrategyDeploymentEvidence, checked_at: float
) -> dict[str, object]:
    return {
        "authorization_granted": False,
        "checked_at": checked_at,
        "evidence_digest": evidence.digest,
        "evidence_id": evidence.evidence_id,
        "expires_at": evidence.expires_at,
        "producer": {
            "commit": evidence.producer_commit,
            "product": evidence.producer_product,
            "version": evidence.producer_version,
            "wheel_sha256": evidence.producer_wheel_sha256,
        },
        "promotion_review_eligible": evidence.review_status in _PROMOTION_REVIEW_STATUSES,
        "read_only": True,
        "review_status": evidence.review_status,
        "schema_version": evidence.schema_version,
        "status": "valid",
        "strategy_id": evidence.strategy_id,
        "tenant_id": evidence.tenant_id,
    }


def validate_deployment_evidence(
    evidence: StrategyDeploymentEvidence | Mapping[object, object] | str | Path,
    *,
    expected_tenant_id: str | None = None,
    expected_strategy_id: str | None = None,
    tenant_id: str | None = None,
    strategy_id: str | None = None,
    expected_evidence_digest: str | None = None,
    expected_artifact_sha256: str | None = None,
    expected_config_effective_digest: str | None = None,
    artifact_path: str | Path | None = None,
    now: float | None = None,
    require_promotion: bool = False,
) -> dict[str, object]:
    """Validate local evidence against explicit scope and optional byte/config bindings.

    ``expected_tenant_id`` and ``expected_strategy_id`` are deliberately
    required (their short aliases exist for simple callers).  The function only
    reports a semantic review-gate result; even a passing review gate grants no
    deployment, provider, risk, or control authority.
    """

    parsed = _coerce_evidence(evidence)
    expected_tenant = _expected_identifier(
        expected=expected_tenant_id,
        alias=tenant_id,
        field_name="tenant_id",
    )
    expected_strategy = _expected_identifier(
        expected=expected_strategy_id,
        alias=strategy_id,
        field_name="strategy_id",
    )
    checked_at = _timestamp(time.time() if now is None else now, "now")
    if checked_at < parsed.created_at:
        raise DeploymentEvidenceError("evidence is not yet valid", details={"field": "created_at"})
    if checked_at >= parsed.expires_at:
        raise DeploymentEvidenceExpired("evidence has expired", details={"field": "expires_at"})
    if parsed.tenant_id != expected_tenant:
        raise DeploymentEvidenceMismatch(
            "evidence tenant_id does not match the expected tenant",
            details={"field": "tenant_id"},
        )
    if parsed.strategy_id != expected_strategy:
        raise DeploymentEvidenceMismatch(
            "evidence strategy_id does not match the expected strategy",
            details={"field": "strategy_id"},
        )
    if expected_evidence_digest is not None and parsed.digest != _sha256(
        expected_evidence_digest, "expected_evidence_digest"
    ):
        raise DeploymentEvidenceMismatch(
            "evidence digest does not match the trusted evidence anchor",
            details={"field": "evidence_digest"},
        )
    if expected_artifact_sha256 is not None and parsed.artifact_sha256 != _sha256(
        expected_artifact_sha256, "expected_artifact_sha256"
    ):
        raise DeploymentEvidenceMismatch(
            "evidence artifact_sha256 does not match the expected artifact",
            details={"field": "artifact_sha256"},
        )
    if expected_config_effective_digest is not None and parsed.config_effective_digest != _sha256(
        expected_config_effective_digest, "expected_config_effective_digest"
    ):
        raise DeploymentEvidenceMismatch(
            "evidence config_effective_digest does not match the expected config",
            details={"field": "config_effective_digest"},
        )
    if artifact_path is not None and _file_sha256(Path(artifact_path)) != parsed.artifact_sha256:
        raise DeploymentEvidenceMismatch(
            "artifact bytes do not match evidence artifact_sha256",
            details={"field": "artifact_sha256"},
        )
    if require_promotion and parsed.review_status not in _PROMOTION_REVIEW_STATUSES:
        raise DeploymentPromotionRejected(
            "review_required evidence cannot pass the promotion review gate",
            details={"field": "review_status", "review_status": parsed.review_status},
        )
    return _validation_result(parsed, checked_at)


def _emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2, sort_keys=True))


def _add_validation_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--evidence", type=Path, required=True, help="local evidence JSON file")
    parser.add_argument("--tenant-id", required=True, help="expected opaque tenant identifier")
    parser.add_argument("--strategy-id", required=True, help="expected opaque strategy identifier")
    parser.add_argument(
        "--artifact-path",
        type=Path,
        help="optional local artifact whose bytes must match artifact_sha256",
    )
    parser.add_argument(
        "--expected-artifact-sha256",
        help="optional trusted artifact digest to compare against the evidence",
    )
    parser.add_argument(
        "--expected-evidence-digest",
        "--expected-evidence-sha256",
        dest="expected_evidence_digest",
        help="optional trusted canonical evidence digest to detect evidence-file tampering",
    )
    parser.add_argument(
        "--config-effective-digest",
        help="optional trusted effective-config digest to compare against the evidence",
    )
    parser.add_argument(
        "--now", type=float, help="Unix timestamp used for deterministic expiry checks"
    )


def build_parser() -> argparse.ArgumentParser:
    """Build the isolated, read-only deployment-evidence CLI parser."""

    parser = argparse.ArgumentParser(
        prog="backtrader-skills-evidence",
        description="Validate local Iteration 41 deployment evidence without granting authority.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    validate = commands.add_parser("validate", help="validate a local evidence record")
    _add_validation_arguments(validate)
    validate.add_argument(
        "--for-promotion",
        action="store_true",
        help="reject review_required evidence at the semantic promotion review gate",
    )
    promotion = commands.add_parser(
        "promotion-check",
        help="run the same validation while requiring a non-review_required semantic status",
    )
    _add_validation_arguments(promotion)
    return parser


def main(argv: list[str] | None = None) -> int:
    """Run a zero-write local validation command and emit one JSON result."""

    args = build_parser().parse_args(argv)
    try:
        result = validate_deployment_evidence(
            args.evidence,
            expected_tenant_id=args.tenant_id,
            expected_strategy_id=args.strategy_id,
            expected_evidence_digest=args.expected_evidence_digest,
            expected_artifact_sha256=args.expected_artifact_sha256,
            expected_config_effective_digest=args.config_effective_digest,
            artifact_path=args.artifact_path,
            now=args.now,
            require_promotion=args.command == "promotion-check" or args.for_promotion,
        )
    except SkillsError as error:
        _emit(
            {
                "status": "error",
                "code": error.code,
                "message": str(error),
                "details": error.details,
            }
        )
        return 2
    except (OSError, ValueError, json.JSONDecodeError) as error:
        _emit({"status": "error", "code": "INPUT_OR_IO_ERROR", "message": str(error)})
        return 2
    _emit(result)
    return 0


__all__ = [
    "DEPLOYMENT_EVIDENCE_SCHEMA_VERSION",
    "DeploymentEvidenceError",
    "DeploymentEvidenceExpired",
    "DeploymentEvidenceMismatch",
    "DeploymentPromotionRejected",
    "StrategyDeploymentEvidence",
    "build_parser",
    "canonical_json",
    "evidence_sha256",
    "load_deployment_evidence",
    "main",
    "validate_deployment_evidence",
]


if __name__ == "__main__":
    raise SystemExit(main())
