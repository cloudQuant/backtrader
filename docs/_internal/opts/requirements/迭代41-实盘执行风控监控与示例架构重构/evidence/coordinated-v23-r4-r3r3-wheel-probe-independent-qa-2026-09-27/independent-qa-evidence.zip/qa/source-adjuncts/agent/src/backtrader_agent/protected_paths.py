"""Fail-closed checks for private Backtrader runtime paths.

These checks inspect names and filesystem metadata only. They never open or
hash runtime configuration files.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import List

from .errors import AgentError

PRIVATE_RUNTIME_NAMES = {
    "runtime-ctp-private",
    "runtime-production",
    "runtime-private",
    "private-runtime",
}
PRIVATE_CONFIG_NAMES = {
    "config.yaml",
    "config.yml",
    "secrets.yaml",
    "secrets.yml",
    "secrets.json",
}


def _is_reparse_point(metadata: os.stat_result) -> bool:
    attributes = getattr(metadata, "st_file_attributes", 0)
    reparse_attribute = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return stat.S_ISLNK(metadata.st_mode) or bool(attributes & reparse_attribute)


def _protected_path_error() -> AgentError:
    return AgentError(
        "BTAG-ENGINE-TARGET-PROTECTED",
        "registered Backtrader checkout contains a protected private runtime path",
    )


def _path_has_private_runtime_component(path: Path) -> bool:
    return any(part.casefold() in PRIVATE_RUNTIME_NAMES for part in path.parts)


def _dangerous_alias(
    path: Path,
    *,
    examples_root: Path,
    in_private_runtime: bool,
) -> bool:
    """Classify reparse points without following them during tree traversal."""

    if in_private_runtime or path.name.casefold() in PRIVATE_RUNTIME_NAMES:
        return True
    try:
        target = path.resolve(strict=False)
    except (OSError, RuntimeError):
        return True
    if _path_has_private_runtime_component(target):
        return True
    if (
        target.name.casefold() in PRIVATE_CONFIG_NAMES
        and _path_has_private_runtime_component(target.parent)
    ):
        return True
    try:
        target.relative_to(examples_root)
    except ValueError:
        # An external alias could hide a private runtime outside the scanned
        # checkout tree. Internal aliases are covered by the real tree walk.
        return True
    return not target.exists()


def assert_backtrader_checkout_safe(root: Path) -> Path:
    """Reject private CTP runtime trees without reading their file contents.

    The private Iteration 41 configuration lives under ``examples`` in a
    ``runtime-ctp-private`` directory. A tracked, empty runtime directory is
    safe; reject actual private configuration names within it. Reparse points
    are checked by target metadata so an alias cannot hide the protected path.
    """

    try:
        resolved = Path(root).expanduser().resolve(strict=True)
        if not resolved.is_dir():
            raise OSError("checkout root is not a directory")
    except (OSError, RuntimeError) as exc:
        raise AgentError(
            "BTAG-ENGINE-TARGET",
            "registered Backtrader checkout could not be inspected",
        ) from exc

    if _path_has_private_runtime_component(resolved):
        raise _protected_path_error()

    examples = resolved / "examples"
    try:
        examples_metadata = examples.lstat()
    except FileNotFoundError:
        return resolved
    except OSError as exc:
        raise AgentError(
            "BTAG-ENGINE-TARGET",
            "registered Backtrader checkout could not be inspected",
        ) from exc

    if _is_reparse_point(examples_metadata):
        # ``examples`` redirects the whole scanned tree, so its alias target
        # cannot be treated like an ordinary internal link.
        raise _protected_path_error()
    if not stat.S_ISDIR(examples_metadata.st_mode):
        return resolved

    try:
        examples_root = examples.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise AgentError(
            "BTAG-ENGINE-TARGET",
            "registered Backtrader checkout could not be inspected",
        ) from exc
    pending: List[tuple] = [(examples_root, False)]
    while pending:
        directory, in_private_runtime = pending.pop()
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    try:
                        metadata = entry.stat(follow_symlinks=False)
                    except OSError as exc:
                        raise AgentError(
                            "BTAG-ENGINE-TARGET",
                            "registered Backtrader checkout could not be inspected",
                        ) from exc
                    entry_path = Path(entry.path)
                    entry_name = entry.name.casefold()
                    is_private_runtime = entry_name in PRIVATE_RUNTIME_NAMES
                    if _is_reparse_point(metadata):
                        if _dangerous_alias(
                            entry_path,
                            examples_root=examples_root,
                            in_private_runtime=in_private_runtime or is_private_runtime,
                        ):
                            raise _protected_path_error()
                        continue
                    if in_private_runtime and entry_name in PRIVATE_CONFIG_NAMES:
                        raise _protected_path_error()
                    if stat.S_ISDIR(metadata.st_mode):
                        pending.append(
                            (entry_path, in_private_runtime or is_private_runtime)
                        )
        except AgentError:
            raise
        except OSError as exc:
            raise AgentError(
                "BTAG-ENGINE-TARGET",
                "registered Backtrader checkout could not be inspected",
            ) from exc

    return resolved
