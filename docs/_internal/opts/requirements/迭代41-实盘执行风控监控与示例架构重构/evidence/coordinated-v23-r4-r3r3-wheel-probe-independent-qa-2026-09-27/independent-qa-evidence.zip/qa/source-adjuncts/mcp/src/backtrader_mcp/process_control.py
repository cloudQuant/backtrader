"""Platform-aware process group, environment, and termination helpers."""

from __future__ import annotations

import os
import signal
import subprocess
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any


def _platform_name() -> str:
    return os.name


def is_posix() -> bool:
    return _platform_name() == "posix"


@dataclass(frozen=True)
class CandidateNetworkIsolationStatus:
    """Code-owned evidence required before untrusted candidate code may run."""

    backend: str | None
    network_denied: bool
    descendant_containment: bool
    verified: bool
    reason: str


class CandidateNetworkIsolationUnavailable(RuntimeError):
    """Raised when the host has no accepted OS boundary for candidates."""


def candidate_network_isolation_status() -> CandidateNetworkIsolationStatus:
    """Report accepted OS-level candidate isolation, never static AST findings.

    Process groups, resource limits, and minimal environments do not restrict
    network access. No Windows AppContainer/WFP or POSIX network-namespace
    backend is currently wired to the candidate launcher, so this remains
    unavailable until a code-owned backend can attest to both network denial
    and descendant containment.
    """

    if os.name == "nt":
        reason = (
            "candidate execution blocked: no verified Windows OS network isolation "
            "and process-containment backend is configured"
        )
    else:
        reason = (
            "candidate execution blocked: no verified POSIX OS network isolation "
            "and process-containment backend is configured"
        )
    return CandidateNetworkIsolationStatus(
        backend=None,
        network_denied=False,
        descendant_containment=False,
        verified=False,
        reason=reason,
    )


def require_candidate_network_isolation() -> CandidateNetworkIsolationStatus:
    """Fail closed unless trusted OS enforcement covers the candidate tree."""

    status = candidate_network_isolation_status()
    if not (
        status.backend
        and status.network_denied
        and status.descendant_containment
        and status.verified
    ):
        raise CandidateNetworkIsolationUnavailable(status.reason)
    return status


def popen_group_options(*, preexec_fn: Callable[[], None] | None = None) -> dict[str, Any]:
    """Return only Popen group options supported by the active platform."""

    if is_posix():
        options: dict[str, Any] = {"start_new_session": True}
        if preexec_fn is not None:
            options["preexec_fn"] = preexec_fn
        return options
    creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    return {"creationflags": creationflags} if creationflags else {}


def platform_environment(environment: Mapping[str, str]) -> dict[str, str]:
    """Preserve the minimum Windows launch variable without broad inheritance."""

    result = dict(environment)
    if not is_posix():
        system_root = os.environ.get("SystemRoot") or os.environ.get("SYSTEMROOT")
        if system_root:
            result.setdefault("SystemRoot", system_root)
    return result


def terminate_popen(process: subprocess.Popen[Any]) -> None:
    """Terminate a known child, escalating after a short bounded wait."""

    if process.poll() is not None:
        return
    if is_posix():
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=2)
        except (OSError, ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(process.pid, getattr(signal, "SIGKILL", 9))
            except (OSError, ProcessLookupError):
                pass
        return
    try:
        process.terminate()
        process.wait(timeout=2)
    except (OSError, subprocess.TimeoutExpired):
        try:
            process.kill()
        except OSError:
            pass


def terminate_pid(pid: int) -> None:
    """Request termination for an already-recorded supervisor or child PID."""

    try:
        if is_posix():
            os.killpg(pid, signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        pass
