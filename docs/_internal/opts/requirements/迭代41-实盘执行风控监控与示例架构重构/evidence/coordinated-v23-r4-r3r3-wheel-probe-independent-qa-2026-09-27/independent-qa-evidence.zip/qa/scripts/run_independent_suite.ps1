param([Parameter(Mandatory=$true)][ValidateSet('main-bridge','main-cancel-control','main-artifact-set','parent-issuer-control')][string]$Suite)
$ErrorActionPreference='Stop'
$qa='D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927'
$ex=Join-Path $qa 'extracted'
$venv=Join-Path $qa 'venv'
$py=Join-Path $venv 'Scripts\python.exe'
$site=Join-Path $venv 'Lib\site-packages'
$overlay=Join-Path $ex 'candidate-v3\main-overlay'
$parentTests=Join-Path $ex 'parent-installed-tests-v3b'
$guard=Join-Path $ex 'origin-guard-r4'
$metadata=Join-Path $ex 'candidate-v3\source-only-metadata'
$runRoot=Join-Path $qa 'independent-runs'
$sourceMap=Join-Path $qa 'source-roots-independent.json'
$env:BT_API_TEST_SOURCE_ROOTS=Get-Content -LiteralPath $sourceMap -Raw
$env:BT_API_TEST_GUARD_ROOT=$guard
$env:BT_API_TEST_METADATA_ROOT=$metadata
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'
$roots=Get-Content -LiteralPath $sourceMap -Raw | ConvertFrom-Json
$env:PYTHONPATH=(@($guard,$overlay,$site,$roots.base,$roots.ctp,$roots.risk,$roots.monitor,$roots.gateway,$roots.transport_zmq,$roots.agent,$roots.skills,$roots.mcp,$metadata) -join ';')
$runner=Join-Path $ex 'run_installed_wheel_pytest_v3.py'
$files=@()
$cwd=$null
switch ($Suite) {
 'main-bridge' { $files=@('tests/unit/runtime/test_managed_execution_bridge.py','tests/unit/runtime/test_iteration41_l2_fixture_package.py','tests/integration/test_iteration41_managed_cancellation_composition.py','tests/integration/test_iteration41_managed_execution_composition.py','tests/integration/test_iteration41_managed_replay_l2.py'); $cwd=$overlay }
 'main-cancel-control' { $files=@('tests/test_cancellation_dispatch_resolution_control.py'); $cwd=$overlay }
 'main-artifact-set' { $files=@('tests/unit/runtime/test_ctp_i9_candidate_artifact_set.py'); $cwd=$overlay }
 'parent-issuer-control' { $files=@('tests/test_cancel_dispatch_resolution_proof.py','tests/test_cancel_dispatch_resolution_proof_store.py','tests/test_cancellation_dispatch_resolution_control.py'); $cwd=$parentTests }
}
$name="$Suite-independent-wheel-qa"
$fixture=Join-Path $runRoot "$name-fixtures"
$guardLog=Join-Path $runRoot "$name-guard"
$junit=Join-Path $runRoot "$name.xml"
$log=Join-Path $runRoot "$name.log"
New-Item -ItemType Directory -Path $runRoot,$fixture,$guardLog -Force | Out-Null
$env:BT_API_TEST_FIXTURE_ROOT=$fixture
$env:BT_API_TEST_GUARD_LOG_ROOT=$guardLog
$args=@($runner,'--import-mode=importlib','-q','--basetemp',$fixture,"--junitxml=$junit") + $files
Push-Location $cwd
try { & $py @args 2>&1 | Tee-Object -FilePath $log; $code=$LASTEXITCODE } finally { Pop-Location }
Set-Content -LiteralPath (Join-Path $runRoot "$name.exit.txt") -Value $code -NoNewline -Encoding ascii
Write-Output "SUITE=$Suite EXIT=$code"
if ($code -ne 0) { exit $code }
