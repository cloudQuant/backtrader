"""Read-only Backtrader engine-root inspection and hash binding."""

import os
import platform
import re
import stat
import sys
from pathlib import Path
from typing import Any, Dict, Iterator, Tuple

from .backtrader_runtime import inspect_backtrader_engine_root
from .caching import memoized
from .canonical import hash_object, sha256_bytes
from .errors import AgentError
from .protected_paths import assert_backtrader_checkout_safe
from .roots import RootRegistry

VERSION_RE = re.compile(r'^__version__\s*=\s*["\']([^"\']+)["\']', re.MULTILINE)


def _read_member(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        raise AgentError(
            "BTAG-ENGINE-MEMBER", "engine package member could not be read"
        ) from exc


def _regular_member(path: Path, *, required: bool = False) -> bytes:
    try:
        metadata = path.lstat()
    except OSError as exc:
        if required:
            raise AgentError(
                "BTAG-ENGINE-LAYOUT",
                "engine root must contain backtrader/__init__.py and backtrader/version.py",
            ) from exc
        raise AgentError(
            "BTAG-ENGINE-MEMBER", "engine package member could not be inspected"
        ) from exc
    if stat.S_ISLNK(metadata.st_mode):
        raise AgentError(
            "BTAG-ENGINE-SYMLINK", "engine package cannot contain symbolic links"
        )
    if not stat.S_ISREG(metadata.st_mode):
        raise AgentError(
            "BTAG-ENGINE-TYPE", "engine package members must be regular files"
        )
    return _read_member(path)


def _walk_members(package: Path) -> Iterator[Tuple[str, Path, os.stat_result]]:
    """Yield (relative posix name, path, lstat metadata) for hashable members.

    The same BTAG-ENGINE-* diagnostics as the original walk are raised before
    any hashing: symlinked or non-regular members, unreadable metadata, and
    members escaping the package root are all rejected during the walk.
    """

    try:
        package_metadata = package.lstat()
    except OSError as exc:
        raise AgentError(
            "BTAG-ENGINE-LAYOUT",
            "engine root must contain backtrader/__init__.py and backtrader/version.py",
        ) from exc
    if stat.S_ISLNK(package_metadata.st_mode):
        raise AgentError(
            "BTAG-ENGINE-SYMLINK", "engine package cannot be a symbolic link"
        )
    if not stat.S_ISDIR(package_metadata.st_mode):
        raise AgentError(
            "BTAG-ENGINE-LAYOUT", "engine root must contain a backtrader package"
        )

    package_root = package.resolve(strict=True)
    for current, directories, names in os.walk(
        str(package), topdown=True, followlinks=False
    ):
        current_path = Path(current)
        kept_directories = []
        for name in sorted(directories):
            child = current_path / name
            try:
                metadata = child.lstat()
            except OSError as exc:
                raise AgentError(
                    "BTAG-ENGINE-MEMBER", "engine package member could not be inspected"
                ) from exc
            if stat.S_ISLNK(metadata.st_mode):
                raise AgentError(
                    "BTAG-ENGINE-SYMLINK",
                    "engine package cannot contain symbolic links",
                )
            if not stat.S_ISDIR(metadata.st_mode):
                raise AgentError(
                    "BTAG-ENGINE-TYPE", "engine package member must be a directory"
                )
            if name != "__pycache__":
                kept_directories.append(name)
        directories[:] = kept_directories
        for name in sorted(names):
            child = current_path / name
            try:
                metadata = child.lstat()
            except OSError as exc:
                raise AgentError(
                    "BTAG-ENGINE-MEMBER", "engine package member could not be inspected"
                ) from exc
            if stat.S_ISLNK(metadata.st_mode):
                raise AgentError(
                    "BTAG-ENGINE-SYMLINK",
                    "engine package cannot contain symbolic links",
                )
            if not stat.S_ISREG(metadata.st_mode):
                raise AgentError(
                    "BTAG-ENGINE-TYPE", "engine package members must be regular files"
                )
            if name.endswith(".pyc"):
                continue
            try:
                child.resolve(strict=True).relative_to(package_root)
            except (OSError, ValueError) as exc:
                raise AgentError(
                    "BTAG-ENGINE-PATH",
                    "engine package member escapes the registered package",
                ) from exc
            yield child.relative_to(package).as_posix(), child, metadata


def _tree_signature(package: Path) -> Tuple[Tuple[str, int, int, int], ...]:
    """Cheap content identity: per-member path, size, mtime, and ctime.

    The signature walks the tree without reading any file contents. It changes
    whenever a member changes, so memoized hashes are never stale within a
    process even when the engine tree is mutated mid-invocation. ``ctime_ns``
    is included because an in-place tamper can preserve size and restore mtime
    via ``os.utime``, while ctime cannot be restored by an unprivileged writer.
    """

    return tuple(
        (relative, metadata.st_size, metadata.st_mtime_ns, metadata.st_ctime_ns)
        for relative, _, metadata in _walk_members(package)
    )


@memoized
def _hash_package_members(
    package: Path, signature: Tuple[Tuple[str, int, int, int], ...]
) -> Dict[str, str]:
    """SHA-256 every package member; ``signature`` is the process-local cache key."""

    return {
        relative: sha256_bytes(_read_member(child))
        for relative, child, _ in _walk_members(package)
    }


def _package_tree(package: Path) -> Dict[str, str]:
    return _hash_package_members(package, _tree_signature(package))


def inspect_engine(roots: RootRegistry, root_id: str) -> Dict[str, Any]:
    record = roots.get_record(root_id)
    if record.get("kind") != "engine" or record.get("writable"):
        raise AgentError(
            "BTAG-ENGINE-ROOT",
            "engine root must be registered read-only with kind 'engine'",
        )
    try:
        root = Path(record["path"]).resolve(strict=True)
    except OSError as exc:
        raise AgentError(
            "BTAG-ENGINE-ROOT", "registered engine root is unavailable"
        ) from exc
    assert_backtrader_checkout_safe(root)
    package = root / "backtrader"
    initializer = package / "__init__.py"
    version_file = package / "version.py"
    package_files = _package_tree(package)
    initializer_bytes = _regular_member(initializer, required=True)
    version_bytes = _regular_member(version_file, required=True)
    try:
        version_source = version_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AgentError(
            "BTAG-ENGINE-VERSION", "engine version file must be UTF-8 text"
        ) from exc
    match = VERSION_RE.search(version_source)
    descriptor: Dict[str, Any] = {
        "schema_version": "engine-runtime-v2",
        "root_id": root_id,
        "package": "backtrader",
        "version": match.group(1) if match else "unknown",
        "initializer_sha256": sha256_bytes(initializer_bytes),
        "version_file_sha256": sha256_bytes(version_bytes),
        "package_tree_sha256": hash_object(package_files),
        "package_file_count": len(package_files),
        "source": inspect_backtrader_engine_root(root),
    }
    descriptor["engine_hash"] = hash_object(descriptor)
    return descriptor


def inspect_execution_environment() -> Dict[str, Any]:
    if sys.platform == "win32":
        # platform.platform() may invoke ``cmd.exe /c ver`` on Windows. Avoid
        # shell startup here: host AutoRun hooks can mutate the environment or
        # start unrelated processes while a child environment is being built.
        windows_version = sys.getwindowsversion()
        platform_name = (
            f"Windows-{windows_version.major}.{windows_version.minor}."
            f"{windows_version.build}"
        )
    else:
        platform_name = platform.platform()

    descriptor: Dict[str, Any] = {
        "schema_version": "execution-environment-v1",
        "python_executable": str(Path(sys.executable).resolve()),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform_name,
    }
    descriptor["environment_hash"] = hash_object(descriptor)
    return descriptor
