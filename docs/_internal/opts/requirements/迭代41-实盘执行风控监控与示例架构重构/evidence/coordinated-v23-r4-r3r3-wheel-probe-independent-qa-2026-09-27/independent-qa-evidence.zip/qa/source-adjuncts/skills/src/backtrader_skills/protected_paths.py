"""Fail-closed checks for the offline strategy runner's target checkout."""

from __future__ import annotations

import os
import stat
from pathlib import Path

from .errors import PathPolicyError

_PROTECTED_RUNTIME_NAMES = frozenset(
    {"runtime-ctp-private", "runtime-production", "runtime-private", "private-runtime"}
)
_PROTECTED_CONFIG_NAMES = frozenset(
    {"config.yaml", "secrets.yaml", "config.yml", "secrets.yml", "secrets.json"}
)
_EXAMPLES = Path("examples")


def _has_protected_runtime_component(path: Path) -> bool:
    return any(part.casefold() in _PROTECTED_RUNTIME_NAMES for part in path.parts)


def _is_reparse_point(path: Path) -> bool:
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return False
    except OSError as error:
        raise PathPolicyError("fixed runner cannot verify protected runtime paths") from error
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    attributes = getattr(metadata, "st_file_attributes", 0)
    return stat.S_ISLNK(metadata.st_mode) or bool(attributes & reparse_flag)


def _reject() -> None:
    # Keep paths and contents out of user-visible errors and runner artifacts.
    raise PathPolicyError(
        "fixed offline runner is disabled for checkouts containing protected CTP runtime paths"
    )


def assert_fixed_runner_target_safe(target: Path) -> Path:
    """Reject Iteration 41 CTP runtime/config paths without opening their files.

    The runner's boundary is deliberately offline: it can execute approved
    Backtrader strategies in runonce/runnext mode only. A checkout carrying a
    protected CTP runtime cannot be used as a runner target.
    """

    expanded = target.expanduser()
    if _has_protected_runtime_component(expanded):
        _reject()
    try:
        resolved = expanded.resolve(strict=False)
    except (OSError, RuntimeError) as error:
        raise PathPolicyError("fixed runner cannot verify protected runtime paths") from error
    if _has_protected_runtime_component(resolved):
        _reject()

    lexical_examples = resolved / _EXAMPLES
    if _is_reparse_point(lexical_examples):
        _reject()
    try:
        examples = lexical_examples.resolve(strict=False)
    except (OSError, RuntimeError) as error:
        raise PathPolicyError("fixed runner cannot verify protected runtime paths") from error
    if _has_protected_runtime_component(examples):
        _reject()
    try:
        metadata = examples.stat()
    except FileNotFoundError:
        return resolved
    except OSError as error:
        raise PathPolicyError("fixed runner cannot verify protected runtime paths") from error
    if not stat.S_ISDIR(metadata.st_mode):
        raise PathPolicyError("fixed runner cannot verify protected runtime paths")

    def on_walk_error(_: OSError) -> None:
        raise PathPolicyError("fixed runner cannot verify protected runtime paths")

    try:
        for directory, child_dirs, child_files in os.walk(
            examples, topdown=True, followlinks=False, onerror=on_walk_error
        ):
            current = Path(directory)
            in_protected_runtime = _has_protected_runtime_component(current.relative_to(examples))
            descend: list[str] = []
            for name in child_dirs:
                child = current / name
                if _is_reparse_point(child):
                    # Do not traverse aliases: even a link to a protected
                    # runtime's parent can hide its contents from this walk.
                    _reject()
                descend.append(name)
            child_dirs[:] = descend
            for name in child_files:
                child = current / name
                if _is_reparse_point(child):
                    _reject()
                if in_protected_runtime and name.casefold() in _PROTECTED_CONFIG_NAMES:
                    try:
                        metadata = child.stat(follow_symlinks=False)
                    except OSError as error:
                        raise PathPolicyError(
                            "fixed runner cannot verify protected runtime paths"
                        ) from error
                    if stat.S_ISREG(metadata.st_mode):
                        _reject()
    except PathPolicyError:
        raise
    except OSError as error:
        raise PathPolicyError("fixed runner cannot verify protected runtime paths") from error

    return resolved
