import base64,csv,hashlib,io,json,pathlib,zipfile,datetime
qa=pathlib.Path(r'D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927').resolve(); ex=qa/'extracted'; wheels=qa/'wheelhouse'; site=qa/'venv'/'Lib'/'site-packages'
roles={'execution':('bt_api_execution','bt_api_execution-0.2.4.dev0+v23r3r3.f94b924e1e20-py3-none-any.whl','b2a74d5ec4bce72db66ed5698709a8f986de02b54d72fb5e08a181c2983b6217',17),'parent':('bt_api_py','bt_api_py-0.15.7.dev0+r4r3r3.67e54513-py3-none-any.whl','5e6e846d26b5038c0916fa15d3ce3f7a1c1334fd0aa160cd263d2d0397c07b0f',143)}
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def record_hash(path, algo): return base64.urlsafe_b64encode(hashlib.new(algo,path.read_bytes()).digest()).decode('ascii').rstrip('=')
wheel_build={}
for role,(_,name,expected,count) in roles.items():
 a=ex/'wheel-build-logs-v4'/'build-a-wheels'/role/name; b=ex/'wheel-build-logs-v4'/'build-b-wheels'/role/name
 ab=a.read_bytes(); bb=b.read_bytes(); assert ab==bb and sha_bytes(ab)==expected
 copied=(wheels/name).read_bytes(); assert copied==ab
 wheel_build[role]={'build_a_sha256':sha_bytes(ab),'build_b_sha256':sha_bytes(bb),'copied_wheel_sha256':sha_bytes(copied),'size_bytes':len(ab),'byte_identical':True}
assert 'include-system-site-packages = false' in (qa/'venv'/'pyvenv.cfg').read_text(encoding='utf-8')
for file in ('pip-install.exit.txt','pip-uninstall-base-v2.exit.txt','pip-check-v2.exit.txt'): assert (qa/file).read_text().strip()=='0',file
assert 'No broken requirements found.' in (qa/'pip-check-v2.log').read_text(encoding='utf-8')
record_results={}; direct_urls={}
for role,(dist_name,wheel_name,expected_wheel,expected_count) in roles.items():
 normalized=dist_name.replace('-','_').lower(); dist_infos=list(site.glob(normalized+'-*.dist-info')); assert len(dist_infos)==1,(dist_name,dist_infos)
 di=dist_infos[0]; rec=di/'RECORD'; assert rec.is_file()
 rows={}
 with rec.open('r',encoding='utf-8',newline='') as f:
  for rel,hsize in ((r[0],r[1:]) for r in csv.reader(f)): rows[rel]=hsize
 # Validate every installed RECORD row, including pip-created metadata/bytecode rows.
 for rel,(hash_spec,size) in rows.items():
  p=(site/pathlib.PurePosixPath(rel)).resolve(strict=True); p.relative_to(site.resolve())
  if hash_spec:
   algo,encoded=hash_spec.split('=',1); assert record_hash(p,algo)==encoded,(dist_name,'installed RECORD hash',rel)
  if size: assert p.stat().st_size==int(size),(dist_name,'installed RECORD size',rel)
 wheel_path=wheels/wheel_name
 with zipfile.ZipFile(wheel_path,'r') as w:
  members=[n for n in w.namelist() if not n.endswith('.dist-info/RECORD')]
  assert len(members)==expected_count,(dist_name,len(members),expected_count)
  for member in members:
   p=site.joinpath(*pathlib.PurePosixPath(member).parts); raw=p.read_bytes(); expected=w.read(member)
   assert raw==expected,(dist_name,'installed payload differs from wheel',member)
   digest='sha256='+base64.urlsafe_b64encode(hashlib.sha256(expected).digest()).decode('ascii').rstrip('=')
   assert rows[member]==[digest,str(len(expected))],(dist_name,'RECORD wheel member',member,rows.get(member))
 di_url=di/'direct_url.json'; direct=json.loads(di_url.read_text(encoding='utf-8'))
 assert direct['archive_info']['hashes']['sha256']==expected_wheel and direct['archive_info']['hash']=='sha256='+expected_wheel
 assert '/wheelhouse/'+wheel_name.replace('+','%2B') in direct['url']
 record_results[dist_name]={'record_path':str(rec),'installed_record_rows_all_valid':len(rows),'wheel_payload_members_checked':len(members),'all_installed_wheel_payloads_byte_identical':True,'pip_generated_extra_record_rows':len(rows)-len(members),'direct_url_sha256':expected_wheel,'direct_url':direct['url']}
assert not (site/'bt_api_base').exists()
roots={'parent':str(site),'base':str(qa/'source-adjuncts'/'base'/'src'),'ctp':str(qa/'source-adjuncts'/'ctp'/'src'),'execution':str(site),'risk':str(qa/'source-adjuncts'/'risk'/'src'),'monitor':str(qa/'source-adjuncts'/'monitor'/'src'),'gateway':str(qa/'source-adjuncts'/'gateway'/'src'),'transport_zmq':str(qa/'source-adjuncts'/'transport_zmq'/'src'),'agent':str(qa/'source-adjuncts'/'agent'/'src'),'skills':str(qa/'source-adjuncts'/'skills'/'src'),'mcp':str(qa/'source-adjuncts'/'mcp'/'src')}
modules={'parent':'bt_api_py','base':'bt_api_base','ctp':'bt_api_ctp','execution':'bt_api_execution','risk':'bt_api_risk','monitor':'bt_api_monitor','gateway':'bt_api_gateway','transport_zmq':'bt_api_transport_zmq','agent':'backtrader_agent','skills':'backtrader_skills','mcp':'backtrader_mcp'}
for key,module in modules.items(): assert (pathlib.Path(roots[key])/module/'__init__.py').is_file(),(key,module,roots[key])
(qa/'source-roots-independent.json').write_text(json.dumps(roots,indent=2),encoding='utf-8')
result={'schema':'independent-coordinated-wheel-qa-install-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python_executable':str(qa/'venv'/'Scripts'/'python.exe'),'venv_no_system_site_packages':True,'pip_install_exit':0,'base_wheel_uninstall_exit':0,'pip_check_exit':0,'pip_check_output':'No broken requirements found.','wheel_builds':wheel_build,'installed_record_pep610':record_results,'source_roots':roots,'base_runtime_distribution_uninstalled':True,'tests':'not run yet'}
(qa/'installation-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'wheel_builds':wheel_build,'installed_record_pep610':record_results,'pip_check':'No broken requirements found.','base_runtime_distribution_uninstalled':True,'source_root_count':len(roots)},indent=2))
