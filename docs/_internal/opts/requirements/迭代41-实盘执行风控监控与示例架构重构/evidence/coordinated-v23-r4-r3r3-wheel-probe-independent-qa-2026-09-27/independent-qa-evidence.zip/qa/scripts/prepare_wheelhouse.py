import hashlib,json,pathlib,shutil,datetime
qa=pathlib.Path(r'D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927')
ex=qa/'extracted'; wheelhouse=pathlib.Path(r'D:\temp\iteration41-capability-risk-version-fix-20260926\offline-wheelhouse')
logs=[ex/'installed-wheel-v3-clean-install.log',ex/'installed-wheel-v3-clean-extra-deps.log']
external=set()
for p in logs:
 for line in p.read_text(encoding='utf-8',errors='replace').splitlines():
  if not line.startswith('Processing '): continue
  filename=pathlib.PureWindowsPath(line.split()[1]).name
  if filename.lower().endswith('.whl') and 'iteration41-capability-risk-version-fix-20260926' in line.lower(): external.add(filename)
assert external,('no offline wheels parsed',[p.name for p in logs])
out=qa/'wheelhouse'; assert out.parent.resolve()==qa.resolve()
if out.exists(): shutil.rmtree(out)
out.mkdir()
rows=[]
for name in sorted(external,key=str.lower):
 src=wheelhouse/name
 assert src.is_file(),f'missing offline dependency wheel: {src}'
 dest=out/name; shutil.copyfile(src,dest)
 rows.append({'file':name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'copied_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'size_bytes':dest.stat().st_size,'source':'offline-wheelhouse path named by archived install log'})
archive=ex/'wheel-build-logs-v4'
wheel_names={'execution':'bt_api_execution-0.2.4.dev0+v23r3r3.f94b924e1e20-py3-none-any.whl','parent':'bt_api_py-0.15.7.dev0+r4r3r3.67e54513-py3-none-any.whl'}
for role,name in wheel_names.items():
 a=archive/'build-a-wheels'/role/name; b=archive/'build-b-wheels'/role/name
 assert a.is_file() and b.is_file()
 ah=hashlib.sha256(a.read_bytes()).hexdigest(); bh=hashlib.sha256(b.read_bytes()).hexdigest()
 assert ah==bh,(role,ah,bh)
 dest=out/name; shutil.copyfile(a,dest)
 rows.append({'file':name,'build_a_sha256':ah,'build_b_sha256':bh,'copied_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'size_bytes':dest.stat().st_size,'source':'frozen archive build-a wheel; build-b byte equality independently confirmed'})
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_wheelhouse':str(wheelhouse),'copied_external_wheel_count':len(external),'candidate_build_wheels':2,'files':rows}
(qa/'wheelhouse-manifest.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'created_utc':report['created_utc'],'external_dependency_wheels':len(external),'candidate_wheels':2,'total_size_bytes':sum(x['size_bytes'] for x in rows),'all_source_and_copy_hashes_match':all(x.get('source_sha256',x.get('build_a_sha256'))==x['copied_sha256'] for x in rows),'dependency_filenames':[x['file'] for x in rows if 'source_sha256' in x]},indent=2))
