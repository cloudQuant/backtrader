import collections,hashlib,json,pathlib,shutil,zipfile,datetime,xml.etree.ElementTree as ET
qa=pathlib.Path(r'D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927').resolve()
raw=qa/'author-raw-evidence.zip'; source_manifest_path=qa/'author-source-manifest.json'; index_path=qa/'author-archive-index.json'
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read_json(p):return json.loads(p.read_text(encoding='utf-8-sig'))
source_manifest=read_json(source_manifest_path); index=read_json(index_path)
expected={'manifest':'01fa737d2a0f385dec8ce6187d95c4a104c13cce9dde6d693152df7dd94ef4b6','index':'0492df7ea055116c96519b8500d00b85f081da8d96c6dd69a1d88f2c05f0e569','zip':'9510abeffcf040bf4a7ea8b8e0524e93cfe1046a8b9498dbc7e26626adbb2c46'}
assert sha_file(source_manifest_path)==expected['manifest'] and sha_file(index_path)==expected['index'] and sha_file(raw)==expected['zip']
source_files=source_manifest['files']; assert len(source_files)==843
source_hashes=[]; live_extra={}
for root_name,meta in source_manifest['roots'].items():
 root=pathlib.Path(meta['absolute_path']); actual={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}; rows={r['path']:r for r in source_files if r['root']==root_name}
 assert not set(rows)-set(actual),(root_name,'missing')
 total=0
 for rel,row in rows.items():
  p=actual[rel]; assert p.stat().st_size==row['size_bytes'] and sha_file(p)==row['sha256'],(root_name,rel)
  total+=p.stat().st_size
 extras=sorted(set(actual)-set(rows)); live_extra[root_name]=len(extras)
 assert len(rows)==meta['file_count'] and total==meta['bytes']
 source_hashes.append({'root':root_name,'manifest_files_checked':len(rows),'bytes_checked':total,'all_match':True,'unmanifested_live_directory_extras':len(extras),'extra_samples':extras[:8]})
assert live_extra.get('main-overlay')==472,live_extra
# Revalidate raw archive bytes, every indexed payload, self-index, and the extracted manifest files.
idx={r['path']:r for r in index['files']}; assert len(idx)==1015 and index['entry_count']==1015
with zipfile.ZipFile(raw,'r') as z:
 assert z.testzip() is None
 names={x.filename for x in z.infolist() if not x.is_dir()}
 assert len(names)==1016 and names-set(idx)=={'ARCHIVE-INDEX.json'} and set(idx)-names==set()
 assert z.read('ARCHIVE-INDEX.json')==index_path.read_bytes()
 for name,row in idx.items():
  data=z.read(name); assert len(data)==row['size_bytes'] and sha_bytes(data)==row['sha256'],name
 # Confirm extracted declared source payloads still match after isolated tests ran.
 ex=qa/'extracted'/'candidate-v3'
 for row in source_files:
  p=ex/row['root']/pathlib.PurePosixPath(row['path'])
  assert p.is_file() and p.stat().st_size==row['size_bytes'] and sha_file(p)==row['sha256'],(row['root'],row['path'])
assert source_manifest['roots']['main-overlay']['file_count']==631
# Test totals from the four independent JUnit files and runner stdout.
runroot=qa/'independent-runs'
expected_tests={'main-bridge':73,'main-cancel-control':20,'main-artifact-set':6,'parent-issuer-control':44}
test_details=[]; node_ids=[]; suite_logs={}
for suite,count in expected_tests.items():
 stem=f'{suite}-independent-wheel-qa'; xml=runroot/(stem+'.xml'); log=runroot/(stem+'.log'); exitfile=runroot/(stem+'.exit.txt')
 assert exitfile.read_text().strip()=='0'
 text=log.read_text(encoding='utf-8',errors='replace')
 assert 'PYTEST_EXIT 0' in text and 'NATIVE_MODULES_LOADED []' in text and 'ORIGIN_ASSERTION_FAILED' not in text
 lines=[x for x in text.splitlines() if x.startswith('INSTALLED_ORIGINS_JSON ')]
 assert len(lines)==1,(suite,lines)
 origins=json.loads(lines[0].split(' ',1)[1])
 native_line=next(x for x in text.splitlines() if x.startswith('NATIVE_MODULES_LOADED '))
 native=json.loads(native_line.split(' ',1)[1]); assert native==[]
 root=ET.parse(xml).getroot(); cases=list(root.iter('testcase'))
 fails=sum(len(list(c.findall('failure'))) for c in cases); errors=sum(len(list(c.findall('error'))) for c in cases); skipped=sum(len(list(c.findall('skipped'))) for c in cases)
 assert (len(cases),fails,errors,skipped)==(count,0,0,0),(suite,len(cases),fails,errors,skipped)
 for c in cases: node_ids.append(f"{c.attrib.get('classname','')}::{c.attrib.get('name','')}")
 test_details.append({'suite':suite,'tests':len(cases),'failures':fails,'errors':errors,'skipped':skipped,'exit_code':0,'stdout_sha256':sha_file(log),'junit_sha256':sha_file(xml),'exit_file_sha256':sha_file(exitfile),'origins':origins,'native_modules_loaded':native})
 suite_logs[suite]={'log':log,'xml':xml,'exit':exitfile}
counts=collections.Counter(node_ids); duplicate_executions=sum(v-1 for v in counts.values()); unique_nodes=len(counts)
assert sum(expected_tests.values())==143
# Consolidate runtime guard files/events, hashes, origin roots, and blocking evidence.
guard_dirs=list(runroot.glob('*-guard')); guard_files=sorted(p for d in guard_dirs for p in d.glob('*.jsonl'))
event_counts=collections.Counter(); guard_hashes=[]; bad_events=[]; ctp_imports=[]; bad_origins=[]
roots=read_json(qa/'source-roots-independent.json')
module_names={'parent':'bt_api_py','base':'bt_api_base','ctp':'bt_api_ctp','execution':'bt_api_execution','risk':'bt_api_risk','monitor':'bt_api_monitor','gateway':'bt_api_gateway','transport_zmq':'bt_api_transport_zmq','agent':'backtrader_agent','skills':'backtrader_skills','mcp':'backtrader_mcp'}
module_root={v:pathlib.Path(roots[k]).resolve() for k,v in module_names.items()}
for p in guard_files:
 events=[json.loads(line) for line in p.read_text(encoding='utf-8').splitlines() if line.strip()]
 for e in events:
  kind=e['kind'];event_counts[kind]+=1
  if kind in {'network-blocked','native-import-blocked','private-config-blocked','origin-rejected'}: bad_events.append({'file':str(p),'event':e})
  if kind=='source-import':
   fullname=e.get('fullname',''); top=fullname.split('.',1)[0]
   if top=='bt_api_ctp': ctp_imports.append(e)
   origin=pathlib.Path(e.get('origin','')).resolve()
   root=module_root.get(top)
   if root is None or not (origin==root/top/'__init__.py' or origin==root/f'{top}.py' or (root/top in origin.parents)):
    bad_origins.append({'file':str(p),'event':e})
  if kind=='source-namespace':
   fullname=e.get('fullname','');top=fullname.split('.',1)[0];root=module_root.get(top)
   if root is None or any(not (root/top in pathlib.Path(x).resolve().parents) for x in e.get('locations',[])):
    bad_origins.append({'file':str(p),'event':e})
 guard_hashes.append({'path':str(p.relative_to(qa)),'size_bytes':p.stat().st_size,'sha256':sha_file(p),'event_count':len(events)})
assert not bad_events,bad_events[:5]
assert not bad_origins,bad_origins[:5]
assert not ctp_imports,ctp_imports
assert guard_files and event_counts['source-import']>0
blocked={'network-blocked':event_counts['network-blocked'],'native-import-blocked':event_counts['native-import-blocked'],'private-config-blocked':event_counts['private-config-blocked'],'origin-rejected':event_counts['origin-rejected']}
input_audit=read_json(qa/'input-audit.json');input_audit['status']='FROZEN INPUTS VERIFIED; all four isolated suites complete; declared source payloads reverified unchanged';input_audit['post_test_source_files_unchanged']=True;input_audit['archive_member_count_explanation']='1,015 externally indexed payload members plus one unindexed self-index ARCHIVE-INDEX.json whose bytes equal the external index';input_audit['live_candidate_extra_note']='The frozen live author candidate directory had 472 unmanifested main-overlay bytecode/pytest-cache files at input capture; these are excluded from its 843-file source manifest and not counted as frozen source.'
(qa/'input-audit.json').write_text(json.dumps(input_audit,indent=2),encoding='utf-8')
guard_summary={'schema':'independent-coordinated-probe-guard-summary-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'guard_log_count':len(guard_files),'event_counts':dict(sorted(event_counts.items())),'blocked_event_counts':blocked,'native_modules_imported_by_suite_runner':{x['suite']:x['native_modules_loaded'] for x in test_details},'bt_api_ctp_source_import_events':len(ctp_imports),'all_source_import_origins_under_mapped_roots':not bad_origins,'guard_log_hashes':guard_hashes,'interpretation':'Four fake-only suites ran under the copied origin guard. No non-loopback network or native/provider access was performed; Python-level guard logged zero blocked network/native/private-config/origin events. This is local QA evidence, not OS-level isolation or G1/G4/G5 acceptance.'}
(qa/'guard-summary.json').write_text(json.dumps(guard_summary,indent=2),encoding='utf-8')
test_summary={'schema':'independent-coordinated-probe-test-summary-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'suite_results':test_details,'total_executions':sum(x['tests'] for x in test_details),'total_failures':sum(x['failures'] for x in test_details),'total_errors':sum(x['errors'] for x in test_details),'total_skipped':sum(x['skipped'] for x in test_details),'unique_node_ids':unique_nodes,'duplicate_node_executions':duplicate_executions,'node_id_duplicates':{k:v for k,v in counts.items() if v>1}}
(qa/'test-summary.json').write_text(json.dumps(test_summary,indent=2),encoding='utf-8')
results={'schema':'independent-coordinated-release-probe-qa-results-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_author_inputs':{'source_manifest_sha256':expected['manifest'],'archive_index_sha256':expected['index'],'raw_archive_sha256':expected['zip'],'declared_source_files':843,'indexed_payload_members':1015,'total_raw_zip_members':1016,'unindexed_self_index_member':'ARCHIVE-INDEX.json','self_index_sha256':expected['index'],'source_manifest_paths_verified':source_hashes},'wheel_qa':read_json(qa/'installation-audit.json'),'tests':test_summary,'guards':guard_summary,'limitations':['Base remains SOURCE-ONLY in this QA: its runtime wheel was removed; only its source tree plus source-only distribution metadata were provided.','The author candidate live directory includes 472 unmanifested main-overlay cache/bytecode files; they are not part of the sealed 843-file source manifest.','External helper source roots were copied with source-only/sensitive/native filters and hash-bound in source-adjunct-manifest.json; those roots are QA adjuncts, not part of the author source manifest.','The final verification is offline fake-only evidence. No provider, credentials, CTP native module, remote endpoint or default pin was used or authorized. This is not G1/G4/G5 or release acceptance.']}
(qa/'qa-results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
# Build a reviewable raw evidence bundle. Large disposable venv and copied dependency wheelhouse remain outside; hashes are in the manifests.
stage=qa/'evidence-content'; assert not stage.exists(),f'evidence staging already exists: {stage}'; stage.mkdir()
def copy(src,rel):
 src=pathlib.Path(src); dst=stage/pathlib.PurePosixPath(rel); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
for f,rel in [(raw,'author/raw-evidence.zip'),(qa/'author-source-manifest.json','author/source-manifest.json'),(qa/'author-archive-index.json','author/archive-index.json'),(qa/'author-receipt.json','author/receipt.json'),(qa/'author-review.md','author/review.md'),(qa/'input-audit.json','qa/input-audit.json'),(qa/'installation-audit.json','qa/installation-audit.json'),(qa/'wheelhouse-manifest.json','qa/wheelhouse-manifest.json'),(qa/'source-adjunct-manifest.json','qa/source-adjunct-manifest.json'),(qa/'source-roots-independent.json','qa/source-roots-independent.json'),(qa/'guard-summary.json','qa/guard-summary.json'),(qa/'test-summary.json','qa/test-summary.json'),(qa/'qa-results.json','qa/results.json')]:copy(f,rel)
for f in [qa/'audit_inputs.py',qa/'prepare_wheelhouse.py',qa/'capture_source_adjuncts.py',qa/'verify_installation.py',qa/'run_independent_suite.ps1',qa/'finalize_qa.py']:
 if f.is_file(): copy(f,'qa/scripts/'+f.name)
for f in [qa/'venv-create.log',qa/'venv-create.exit.txt',qa/'pip-install.log',qa/'pip-install.exit.txt',qa/'pip-install-report.json',qa/'pip-uninstall-base.log',qa/'pip-uninstall-base.exit.txt',qa/'pip-check.log',qa/'pip-check.exit.txt',qa/'pip-uninstall-base-v2.log',qa/'pip-uninstall-base-v2.exit.txt',qa/'pip-check-v2.log',qa/'pip-check-v2.exit.txt']:
 if f.is_file():copy(f,'qa/install-logs/'+f.name)
for suite,paths in suite_logs.items():
 for typ,p in paths.items():copy(p,f'qa/test-runs/{suite}/{p.name}')
for p in guard_files:copy(p,'qa/guard-logs/'+p.name)
# Include all inert copied helper source roots; no native binary, config/YAML, credentials, or pyc was admitted by copier.
for p in sorted((qa/'source-adjuncts').rglob('*')):
 if p.is_file():copy(p,'qa/source-adjuncts/'+p.relative_to(qa/'source-adjuncts').as_posix())
readme=f'''# Independent V23/R4/R3r3 wheel QA (offline, fake-only)\n\nThis bundle independently checks the frozen coordinated probe at source-manifest SHA256 {expected['manifest']} and raw ZIP SHA256 {expected['zip']}. Two executions each of the V23 execution and R4/R3r3 parent wheel were byte-identical. Fresh isolated CPython 3.11.5 venv RECORD payloads, PEP 610 direct_url wheel digests, and offline pip check passed.\n\n## Results\n\nFour guarded fake test groups passed: 73 main bridge/L2, 20 cancellation control, 6 artifact-set, and 44 parent issuer/control; all had zero skips, failures, or errors. Combined: {test_summary['total_executions']} executions, {unique_nodes} unique node IDs, {duplicate_executions} repeated node executions. All four runners report `NATIVE_MODULES_LOADED []`. Guard totals are in `qa/guard-summary.json`; blocked network/native/private-config/origin events were zero.\n\nThe source archive contains 1,015 indexed payload members plus its extra `ARCHIVE-INDEX.json` self-index member, making 1,016 total. The self-index bytes equal the external index (SHA256 {expected['index']}). The author live candidate directory had 472 unmanifested main-overlay cache/bytecode files when captured; they are not counted in its 843-file frozen source manifest.\n\n`bt_api_base` remains SOURCE-ONLY for this QA: its runtime wheel was removed, and source plus source-only distribution metadata were mapped for tests and pip check. External helper roots were copied as inert files and hash-bound; they are QA adjuncts, not part of the author candidate manifest. No real provider, network, credential, CTP native module, or default pin was used. This is not G1/G4/G5 or release acceptance.\n\nDependency wheels copied from the local offline wheelhouse are hash-bound by `qa/wheelhouse-manifest.json`; to keep this bundle compact, the copied dependency-wheel binaries and disposable venv are not included. The two candidate wheels themselves are in the raw author ZIP.\n'''
(stage/'README.md').write_text(readme,encoding='utf-8')
# Internal checksum list covers all bundle content except itself.
checks=[]
for p in sorted(x for x in stage.rglob('*') if x.is_file()):checks.append(f'{sha_file(p)}  {p.relative_to(stage).as_posix()}')
(stage/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n',encoding='utf-8')
archive_path=qa/'independent-qa-evidence.zip'; assert not archive_path.exists(),f'archive already exists: {archive_path}'
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(x for x in stage.rglob('*') if x.is_file()): z.write(p,p.relative_to(stage).as_posix())
with zipfile.ZipFile(archive_path,'r') as z:
 assert z.testzip() is None
 archive_rows=[{'path':i.filename,'size_bytes':i.file_size,'sha256':sha_bytes(z.read(i))} for i in z.infolist() if not i.is_dir()]
archive_index={'schema':'independent-coordinated-release-probe-qa-archive-index-v1','archive_path':str(archive_path),'archive_sha256':sha_file(archive_path),'archive_size_bytes':archive_path.stat().st_size,'member_count':len(archive_rows),'files':archive_rows}
archive_index_path=qa/'independent-qa-archive-index.json';archive_index_path.write_text(json.dumps(archive_index,indent=2),encoding='utf-8')
review=f'''# Independent wheel probe QA review\n\n**Result:** All four independent offline fake suites pass, and the disposable execution/parent dual-wheel consumer checks pass. Scope remains local QA only; no production route or release is accepted.\n\n- Candidate source manifest: `{expected['manifest']}` (843 declared files; every declared file independently hashed and matched).\n- Raw author ZIP: `{expected['zip']}`. ZIP integrity check passed. Its index binds 1,015 payload members; total ZIP members are 1,016 because `ARCHIVE-INDEX.json` is the byte-identical self-index, SHA `{expected['index']}`.\n- Author live candidate directory had 472 unmanifested main-overlay cache/bytecode files at input capture. Those files are excluded from source manifest counts and were not treated as frozen source.\n- Wheel A/B hashes match exactly: execution `b2a74d5ec4bce72db66ed5698709a8f986de02b54d72fb5e08a181c2983b6217`; parent `5e6e846d26b5038c0916fa15d3ce3f7a1c1334fd0aa160cd263d2d0397c07b0f`. Fresh isolated venv verified every wheel payload against installed bytes and RECORD; PEP 610 direct_url SHA-256 matched both local wheels; source-only-base `pip check` was clean.\n- Independent fake suites: 73 + 20 + 6 + 44 passed; 0 failed, 0 errors, 0 skipped. Tests ran from extracted frozen sources and copied, hash-bound source adjunct roots.\n- Guard logs: {len(guard_files)} files, `{dict(sorted(event_counts.items()))}` events; blocked network/native/private-config/origin events all zero, native import lists empty, no `bt_api_ctp` source import.\n- `bt_api_base` remains SOURCE-ONLY: runtime distribution wheel removed; source-only metadata and copied source root used. No provider, credentials, native session, or remote endpoint was touched.\n\nLimit: this does not accept G1/G4/G5, authorize trading, change the default pin, or constitute release evidence. The Python-level guard provides local test evidence, not OS-enforced isolation.\n\nRaw QA archive: `{archive_path}` (SHA256 `{archive_index['archive_sha256']}`). External member index: `{archive_index_path}`.\n'''
review_path=qa/'independent-qa-review.md';review_path.write_text(review,encoding='utf-8')
receipt={'schema':'independent-coordinated-release-probe-qa-receipt-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_source_manifest_sha256':expected['manifest'],'author_raw_archive_sha256':expected['zip'],'author_archive_index_sha256':expected['index'],'independent_raw_qa_archive':{'path':str(archive_path),'sha256':archive_index['archive_sha256'],'size_bytes':archive_index['archive_size_bytes'],'member_count':len(archive_rows)},'independent_archive_index':{'path':str(archive_index_path),'sha256':sha_file(archive_index_path)},'review_page':{'path':str(review_path),'sha256':sha_file(review_path)},'test_summary':test_summary,'guard_summary_path':str(qa/'guard-summary.json'),'guard_summary_sha256':sha_file(qa/'guard-summary.json'),'input_audit_path':str(qa/'input-audit.json'),'input_audit_sha256':sha_file(qa/'input-audit.json'),'installation_audit_path':str(qa/'installation-audit.json'),'installation_audit_sha256':sha_file(qa/'installation-audit.json'),'result':'LOCAL_FAKE_ONLY_QA_PASSED; NO G1/G4/G5 OR RELEASE ACCEPTANCE'}
receipt_path=qa/'independent-qa-receipt.json';receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({'raw_qa_archive':str(archive_path),'raw_qa_archive_sha256':archive_index['archive_sha256'],'raw_qa_archive_bytes':archive_index['archive_size_bytes'],'archive_member_count':len(archive_rows),'archive_index':str(archive_index_path),'archive_index_sha256':sha_file(archive_index_path),'receipt':str(receipt_path),'receipt_sha256':sha_file(receipt_path),'review':str(review_path),'review_sha256':sha_file(review_path),'test_results':{x['suite']:x['tests'] for x in test_details},'total_tests':sum(x['tests'] for x in test_details),'unique_node_ids':unique_nodes,'duplicate_node_executions':duplicate_executions,'guard_events':dict(sorted(event_counts.items())),'blocked_events':blocked,'live_candidate_extras':live_extra},indent=2))
