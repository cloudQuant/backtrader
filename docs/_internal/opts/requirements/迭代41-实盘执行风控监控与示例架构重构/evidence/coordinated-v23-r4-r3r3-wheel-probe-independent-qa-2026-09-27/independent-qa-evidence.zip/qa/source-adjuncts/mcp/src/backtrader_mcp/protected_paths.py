"""Metadata-only guards for private Backtrader runtime and strategy paths."""

from __future__ import annotations

import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .errors import InvalidRequest

_PRIVATE_RUNTIME_NAMES = {
    "runtime-ctp-private",
    "runtime-production",
    "runtime-private",
    "private-runtime",
}
_PRIVATE_FILE_NAMES = {
    "config.yaml",
    "config.yml",
    "secrets.yaml",
    "secrets.yml",
    "secrets.json",
    "approval-receipt.json",
    "deployment-receipt.json",
}
_PRIVATE_RUNTIME_PAYLOAD_NAMES = _PRIVATE_FILE_NAMES | {".env"}
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
_MAX_SCANNED_ENTRIES = 100_000


@dataclass(frozen=True)
class TargetPathIdentity:
    """Path-component identities captured after a protected-tree check.

    This is a short-lived revalidation token for callers that must perform a
    later path-based operation. It detects a replaced target or ancestor, but
    does not pin a handle and therefore is not a substitute for handle-relative
    reads or renames when hostile concurrent writers are in scope.
    """

    path: Path
    components: tuple[tuple[str, int, int, int], ...]


@dataclass(frozen=True)
class RuntimePathIdentity:
    """Short-lived identity token for a candidate runtime path."""

    path: Path
    components: tuple[tuple[str, int, int, int], ...]


def _path_component_identities(path: Path) -> tuple[tuple[str, int, int, int], ...]:
    """Return no-follow identities for each existing component of ``path``."""

    absolute = path.expanduser().absolute()
    _reject_reparse_components(absolute)
    current = Path(absolute.anchor)
    identities: list[tuple[str, int, int, int]] = []
    missing = False
    for part in absolute.parts[1:]:
        current /= part
        try:
            metadata = current.lstat()
        except FileNotFoundError:
            missing = True
            identities.append((part, -1, -1, -1))
            continue
        except OSError as exc:
            raise InvalidRequest("path identity could not be safely inspected") from exc
        if missing or _is_reparse_point(metadata):
            raise InvalidRequest("path changed during protected path inspection")
        device = getattr(metadata, "st_dev", None)
        inode = getattr(metadata, "st_ino", None)
        if not isinstance(device, int) or not isinstance(inode, int) or inode < 1:
            raise InvalidRequest("path identity could not be safely inspected")
        identities.append((part, device, inode, stat.S_IFMT(metadata.st_mode)))
    return tuple(identities)


def capture_target_path_identity(
    target: Path,
    *,
    state_root: Path,
    runtime_roots: Iterable[Path],
) -> TargetPathIdentity:
    """Check a target tree and capture identities for immediate revalidation."""

    safe = assert_target_path_safe(
        target,
        state_root=state_root,
        runtime_roots=runtime_roots,
    )
    components = _path_component_identities(safe)
    # Re-scan after capture so a protected name or alias added during the first
    # scan cannot be silently bound to this identity token.
    assert_target_path_safe(safe, state_root=state_root, runtime_roots=runtime_roots)
    if _path_component_identities(safe) != components:
        raise InvalidRequest("target path identity changed during protected path inspection")
    return TargetPathIdentity(safe, components)


def revalidate_target_path_identity(
    identity: TargetPathIdentity,
    *,
    state_root: Path,
    runtime_roots: Iterable[Path],
) -> Path:
    """Fail closed if a checked target or any ancestor was replaced."""

    safe = assert_target_path_safe(
        identity.path,
        state_root=state_root,
        runtime_roots=runtime_roots,
    )
    if safe != identity.path or _path_component_identities(safe) != identity.components:
        raise InvalidRequest("target path identity changed after protected path inspection")
    return safe


def capture_runtime_path_identity(
    runtime: Path,
    *,
    state_root: Path,
    target_roots: Iterable[Path],
) -> RuntimePathIdentity:
    """Check a candidate runtime and capture path-component identities."""

    safe = assert_runtime_path_safe(
        runtime,
        state_root=state_root,
        target_roots=target_roots,
    )
    components = _path_component_identities(safe)
    assert_runtime_path_safe(safe, state_root=state_root, target_roots=target_roots)
    if _path_component_identities(safe) != components:
        raise InvalidRequest("runtime path identity changed during protected path inspection")
    return RuntimePathIdentity(safe, components)


def revalidate_runtime_path_identity(
    identity: RuntimePathIdentity,
    *,
    state_root: Path,
    target_roots: Iterable[Path],
) -> Path:
    """Re-scan a runtime for private payloads and reject path replacement."""

    safe = assert_runtime_path_safe(
        identity.path,
        state_root=state_root,
        target_roots=target_roots,
    )
    if safe != identity.path or _path_component_identities(safe) != identity.components:
        raise InvalidRequest("runtime path identity changed after protected path inspection")
    return safe


def paths_overlap(left: Path, right: Path) -> bool:
    """Whether either resolved path contains the other."""

    left = left.expanduser().resolve(strict=False)
    right = right.expanduser().resolve(strict=False)
    return left == right or left in right.parents or right in left.parents


def _private_component(path: Path) -> bool:
    return any(part.casefold() in _PRIVATE_RUNTIME_NAMES for part in path.parts)


def _private_name(name: str) -> bool:
    folded = name.casefold()
    return (
        folded in _PRIVATE_FILE_NAMES or folded.startswith(".env") or folded.startswith("secrets.")
    )


def _private_runtime_payload(name: str) -> bool:
    folded = name.casefold()
    return (
        folded in _PRIVATE_RUNTIME_PAYLOAD_NAMES
        or folded.startswith("secrets.")
        or folded.startswith(".env")
    )


def _is_reparse_point(metadata: os.stat_result) -> bool:
    attributes = getattr(metadata, "st_file_attributes", 0)
    return stat.S_ISLNK(metadata.st_mode) or bool(attributes & _REPARSE_POINT)


def _reject_hardlink(path: Path, metadata: os.stat_result) -> None:
    """Reject regular files whose contents may be aliased outside a guarded tree."""

    if not stat.S_ISREG(metadata.st_mode):
        return
    try:
        current = os.stat(path, follow_symlinks=False)
    except OSError as exc:
        raise InvalidRequest("path could not be safely inspected") from exc
    if _is_reparse_point(current) or not stat.S_ISREG(current.st_mode):
        raise InvalidRequest("path changed during protected tree inspection")
    link_count = getattr(current, "st_nlink", 0)
    if link_count < 1:
        raise InvalidRequest("file identity could not be safely inspected")
    if link_count > 1:
        raise InvalidRequest("hard-linked files are not allowed in protected path trees")


def _reject_reparse_components(path: Path) -> None:
    """Reject symlink/junction ancestors before resolving a caller path."""

    candidate = path.expanduser()
    if not candidate.is_absolute():
        candidate = Path.cwd() / candidate
    current = Path(candidate.anchor)
    for part in candidate.parts[1:]:
        current /= part
        try:
            metadata = current.lstat()
        except FileNotFoundError:
            return
        except OSError as exc:
            raise InvalidRequest("path could not be safely inspected") from exc
        if _is_reparse_point(metadata):
            raise InvalidRequest("protected paths cannot pass through symlinks or reparse points")


def _reject_scanned_reparse(
    path: Path,
    *,
    scan_root: Path,
    in_private_runtime: bool,
) -> None:
    """Reject aliases that could hide protected paths outside the scan."""

    if in_private_runtime or path.name.casefold() in _PRIVATE_RUNTIME_NAMES:
        raise InvalidRequest("protected runtime trees cannot contain aliases")
    try:
        target = path.resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        raise InvalidRequest("reparse-point target could not be safely inspected") from exc
    if _private_component(target):
        raise InvalidRequest("reparse point targets a protected runtime path")
    try:
        target.relative_to(scan_root)
    except ValueError as exc:
        raise InvalidRequest("external aliases in a runtime tree are not allowed") from exc
    if not target.exists():
        raise InvalidRequest("dangling aliases in a runtime tree are not allowed")


def _scan_tree(
    root: Path,
    *,
    reject_private_names: bool,
    private_runtime_only: bool = False,
    root_in_private_runtime: bool = False,
) -> None:
    pending: list[tuple[Path, bool]] = [(root, root_in_private_runtime)]
    scanned = 0
    while pending:
        directory, in_private_runtime = pending.pop()
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    scanned += 1
                    if scanned > _MAX_SCANNED_ENTRIES:
                        raise InvalidRequest(
                            "protected path scan exceeded its metadata entry limit"
                        )
                    try:
                        metadata = entry.stat(follow_symlinks=False)
                    except OSError as exc:
                        raise InvalidRequest("path could not be safely inspected") from exc
                    path = Path(entry.path)
                    name = entry.name.casefold()
                    _reject_hardlink(path, metadata)
                    is_private_runtime = name in _PRIVATE_RUNTIME_NAMES
                    in_private = in_private_runtime or is_private_runtime

                    if _is_reparse_point(metadata):
                        _reject_scanned_reparse(
                            path,
                            scan_root=root,
                            in_private_runtime=in_private,
                        )
                        # The real in-tree target is visited separately. Never
                        # recurse through an alias while walking metadata.
                        continue

                    if private_runtime_only:
                        if in_private and _private_runtime_payload(name):
                            raise InvalidRequest(
                                "candidate execution is disabled for runtimes containing private configuration"
                            )
                    elif reject_private_names and _private_name(name):
                        raise InvalidRequest(
                            "target overlaps a protected runtime or private configuration path"
                        )

                    if stat.S_ISDIR(metadata.st_mode):
                        pending.append((path, in_private))
        except InvalidRequest:
            raise
        except OSError as exc:
            raise InvalidRequest("path could not be safely inspected") from exc


def assert_private_runtime_tree_safe(root: Path, *, scan_self: bool = False) -> Path:
    """Reject a private Iteration 41 runtime or alias using names/metadata only.

    A clean tracked ``runtime-ctp-private`` directory containing only files such
    as README.md and .gitignore is allowed. Config/secrets filenames inside it
    reject without opening, hashing, copying, or returning file contents.
    """

    raw = Path(root).expanduser()
    if _private_component(raw) or _private_component(raw.absolute()):
        raise InvalidRequest("candidate execution is disabled for private runtime paths")
    _reject_reparse_components(raw)
    try:
        resolved = raw.resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        raise InvalidRequest("runtime path could not be safely inspected") from exc
    if _private_component(resolved):
        raise InvalidRequest("candidate execution is disabled for private runtime paths")
    if not resolved.exists():
        return resolved
    try:
        metadata = resolved.lstat()
    except OSError as exc:
        raise InvalidRequest("runtime path could not be safely inspected") from exc
    if _is_reparse_point(metadata):
        raise InvalidRequest("runtime root cannot be a symlink or reparse point")
    if not stat.S_ISDIR(metadata.st_mode):
        raise InvalidRequest("runtime root must be a directory")

    # Check root-level aliases too: an alias beside ``examples`` could point
    # into an otherwise unscanned protected runtime subtree.
    try:
        with os.scandir(resolved) as entries:
            for entry in entries:
                try:
                    child_metadata = entry.stat(follow_symlinks=False)
                except OSError as exc:
                    raise InvalidRequest("runtime path could not be safely inspected") from exc
                _reject_hardlink(Path(entry.path), child_metadata)
                if entry.name.casefold() in _PRIVATE_RUNTIME_NAMES:
                    if _is_reparse_point(child_metadata):
                        raise InvalidRequest("protected runtime paths cannot be aliases")
                    if stat.S_ISDIR(child_metadata.st_mode):
                        _scan_tree(
                            Path(entry.path),
                            reject_private_names=False,
                            private_runtime_only=True,
                            root_in_private_runtime=True,
                        )
                if _is_reparse_point(child_metadata):
                    _reject_scanned_reparse(
                        Path(entry.path), scan_root=resolved, in_private_runtime=False
                    )
    except InvalidRequest:
        raise
    except OSError as exc:
        raise InvalidRequest("runtime path could not be safely inspected") from exc

    examples = resolved / "examples"
    try:
        examples_metadata = examples.lstat()
    except FileNotFoundError:
        if not scan_self and resolved.name.casefold() != "examples":
            return resolved
        examples = resolved
        examples_metadata = metadata
    except OSError as exc:
        raise InvalidRequest("runtime examples path could not be safely inspected") from exc

    if _is_reparse_point(examples_metadata):
        raise InvalidRequest("runtime examples path cannot be a reparse point")
    if not stat.S_ISDIR(examples_metadata.st_mode):
        return resolved
    try:
        scan_root = examples.resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise InvalidRequest("runtime examples path could not be safely inspected") from exc
    _scan_tree(scan_root, reject_private_names=False, private_runtime_only=True)
    return resolved


def assert_target_path_safe(
    target: Path,
    *,
    state_root: Path,
    runtime_roots: Iterable[Path],
    inspect_contents: bool = True,
) -> Path:
    """Reject private/runtime destinations before reading or replacing their tree."""

    raw = target.expanduser()
    if _private_component(raw) or _private_component(raw.absolute()):
        raise InvalidRequest("target overlaps a protected runtime or private configuration path")
    _reject_reparse_components(raw)
    resolved = raw.resolve(strict=False)
    if _private_component(resolved):
        raise InvalidRequest("target overlaps a protected runtime or private configuration path")
    protected_roots = (state_root, *runtime_roots)
    if any(paths_overlap(resolved, root) for root in protected_roots):
        raise InvalidRequest("target overlaps a protected runtime or private configuration path")
    if not inspect_contents or not resolved.exists():
        return resolved
    try:
        metadata = resolved.lstat()
    except OSError as exc:
        raise InvalidRequest("target path could not be safely inspected") from exc
    if _is_reparse_point(metadata) or not stat.S_ISDIR(metadata.st_mode):
        raise InvalidRequest("target strategy path must be a regular directory or absent")
    _scan_tree(resolved, reject_private_names=True)
    return resolved


def assert_runtime_path_safe(
    runtime: Path,
    *,
    state_root: Path,
    target_roots: Iterable[Path],
) -> Path:
    """Reject private runtime targets before provenance reads or execution."""

    resolved = assert_private_runtime_tree_safe(runtime)
    # A standalone runtime may store its private contract beside the package.
    # Inspect only names here; do not open or hash these files.
    if resolved.exists():
        try:
            with os.scandir(resolved) as entries:
                for entry in entries:
                    entry_name = entry.name.casefold()
                    if entry_name in _PRIVATE_FILE_NAMES or entry_name.startswith("secrets."):
                        raise InvalidRequest(
                            "candidate execution is disabled for runtimes with private configuration"
                        )
                    try:
                        metadata = entry.stat(follow_symlinks=False)
                    except OSError as exc:
                        raise InvalidRequest("runtime path could not be safely inspected") from exc
                    if _is_reparse_point(metadata):
                        _reject_scanned_reparse(
                            Path(entry.path), scan_root=resolved, in_private_runtime=False
                        )
        except InvalidRequest:
            raise
        except OSError as exc:
            raise InvalidRequest("runtime path could not be safely inspected") from exc
    protected_roots = (state_root, *target_roots)
    if any(paths_overlap(resolved, root) for root in protected_roots):
        raise InvalidRequest("candidate runtime overlaps private strategy or state paths")
    return resolved
