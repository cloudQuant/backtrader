"""Package version metadata."""

from __future__ import annotations

__version__ = "0.15.4"
