"""Offline deployment-review evidence for Iteration 41.

This module creates a deliberately narrow, portable record describing a
strategy artifact and the effective configuration that produced it.  The
record is evidence for a human review queue only.  It has no provider client,
credential input, network operation, trading operation, or account-control
API.  In particular, ``review_required`` is the only accepted review status:
this product cannot attest that a review, promotion, or authorization occurred.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import math
import re
import time
import uuid
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Mapping, Union

DEPLOYMENT_EVIDENCE_SCHEMA_VERSION = "bt-api-deployment-evidence/v1"
REVIEW_REQUIRED = "review_required"

_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_WIRE_FIELDS = frozenset(
    {
        "artifact_sha256",
        "config_effective_digest",
        "created_at",
        "evidence_id",
        "expires_at",
        "metadata",
        "producer",
        "review_status",
        "schema_version",
        "strategy_id",
        "tenant_id",
    }
)
_PRODUCER_FIELDS = frozenset({"commit", "product", "version", "wheel_sha256"})

# Metadata is descriptive only.  These spellings are matched after stripping
# punctuation so api_key, api-key, apiKey, and APIKEY all fail closed.
_FORBIDDEN_METADATA_KEY_PARTS = (
    "accesskey",
    "admission",
    "apikey",
    "approval",
    "approved",
    "authorization",
    "authorize",
    "credential",
    "drain",
    "freeze",
    "passphrase",
    "password",
    "permission",
    "permit",
    "privatekey",
    "promotion",
    "reviewed",
    "reviewstatus",
    "resume",
    "riskpermit",
    "secret",
    "submitorder",
    "token",
)

SerializedEvidence = Union[str, bytes, bytearray]


class DeploymentEvidenceError(ValueError):
    """Raised when deployment-review evidence is malformed or unsafe."""


def _identifier(value: Any, field_name: str) -> str:
    if (
        not isinstance(value, str)
        or value != value.strip()
        or not _IDENTIFIER.fullmatch(value)
    ):
        raise DeploymentEvidenceError(f"invalid {field_name}")
    return value


def _sha256(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not _SHA256.fullmatch(value):
        raise DeploymentEvidenceError(f"invalid {field_name}")
    return value


def _timestamp(value: Any, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise DeploymentEvidenceError(f"invalid {field_name}")
    try:
        normalized = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise DeploymentEvidenceError(f"invalid {field_name}") from exc
    if not math.isfinite(normalized):
        raise DeploymentEvidenceError(f"invalid {field_name}")
    return 0.0 if normalized == 0.0 else normalized


def _normalized_key(key: str) -> str:
    return "".join(character for character in key.lower() if character.isalnum())


def _forbidden_metadata_key(key: str) -> bool:
    normalized = _normalized_key(key)
    return any(part in normalized for part in _FORBIDDEN_METADATA_KEY_PARTS)


def _validated_json_copy(
    value: Any,
    path: tuple[str, ...] = (),
    *,
    allow_root_review_status: bool = False,
) -> Any:
    """Copy a JSON value into the canonical representation.

    The canonical evidence wire has one schema-owned exception: only its root
    ``review_status`` key can resemble a forbidden review assertion.  Metadata
    and every nested object remain fail-closed for secret/control-shaped keys.
    """

    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise DeploymentEvidenceError("non-finite JSON value")
        return 0.0 if value == 0.0 else value
    if isinstance(value, str):
        # The shared v1 wire hashes the exact JSON value after deterministic
        # serialization.  Do not NFC-normalize here: the SDK, Skills, and MCP
        # validators intentionally bind the original Unicode code points.
        return value
    if isinstance(value, Mapping):
        normalized: dict[str, Any] = {}
        for key, nested in value.items():
            if not isinstance(key, str):
                raise DeploymentEvidenceError("JSON object keys must be strings")
            if key in normalized:
                raise DeploymentEvidenceError(
                    "duplicate JSON object key"
                )
            is_schema_review_status = (
                allow_root_review_status
                and not path
                and _normalized_key(key) == "reviewstatus"
            )
            if _forbidden_metadata_key(key) and not is_schema_review_status:
                raise DeploymentEvidenceError(
                    "secret or authority-shaped metadata field is forbidden"
                )
            if key.endswith("sha256") and (
                not isinstance(nested, str) or not _SHA256.fullmatch(nested)
            ):
                raise DeploymentEvidenceError("invalid metadata SHA-256 value")
            normalized[key] = _validated_json_copy(
                nested,
                path + (key,),
                allow_root_review_status=allow_root_review_status,
            )
        return normalized
    if isinstance(value, (list, tuple)):
        return [
            _validated_json_copy(
                nested,
                path,
                allow_root_review_status=allow_root_review_status,
            )
            for nested in value
        ]
    raise DeploymentEvidenceError("unsupported JSON type")


def _freeze_json(value: Any) -> Any:
    if isinstance(value, dict):
        return MappingProxyType(
            {key: _freeze_json(nested) for key, nested in value.items()}
        )
    if isinstance(value, list):
        return tuple(_freeze_json(nested) for nested in value)
    return value


def _mutable_json(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _mutable_json(nested) for key, nested in value.items()}
    if isinstance(value, tuple):
        return [_mutable_json(nested) for nested in value]
    return value


def canonical_json(value: Any) -> str:
    """Serialize a JSON value with stable key order and encoding."""

    allow_review_status = isinstance(value, Mapping) and set(value) == _WIRE_FIELDS
    normalized = _validated_json_copy(value, allow_root_review_status=allow_review_status)
    return json.dumps(
        normalized,
        allow_nan=False,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    )


def evidence_sha256(value: Any) -> str:
    """Return the SHA-256 digest of a canonical evidence payload."""

    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _require_unexpired(evidence: StrategyDeploymentEvidence, now: float | None) -> None:
    current = time.time() if now is None else _timestamp(now, "now")
    if current >= evidence.expires_at:
        raise DeploymentEvidenceError("deployment evidence is expired")


@dataclass(frozen=True)
class StrategyDeploymentEvidence:
    """Immutable evidence that can only request a deployment review.

    The object intentionally has no approval receipt, permission, control, or
    provider field.  Consumers must treat its metadata as non-authoritative.
    """

    evidence_id: str
    producer_product: str
    producer_version: str
    producer_commit: str
    producer_wheel_sha256: str
    tenant_id: str
    strategy_id: str
    artifact_sha256: str
    config_effective_digest: str
    created_at: float
    expires_at: float
    metadata: Mapping[str, Any]
    review_status: str = REVIEW_REQUIRED
    schema_version: str = DEPLOYMENT_EVIDENCE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if (
            not isinstance(self.schema_version, str)
            or self.schema_version != DEPLOYMENT_EVIDENCE_SCHEMA_VERSION
        ):
            raise DeploymentEvidenceError("unsupported evidence schema_version")
        for field_name in (
            "evidence_id",
            "producer_product",
            "producer_version",
            "producer_commit",
            "tenant_id",
            "strategy_id",
        ):
            object.__setattr__(
                self, field_name, _identifier(getattr(self, field_name), field_name)
            )
        for field_name in (
            "producer_wheel_sha256",
            "artifact_sha256",
            "config_effective_digest",
        ):
            object.__setattr__(
                self, field_name, _sha256(getattr(self, field_name), field_name)
            )
        if (
            not isinstance(self.review_status, str)
            or self.review_status != REVIEW_REQUIRED
        ):
            raise DeploymentEvidenceError("review_status must be review_required")
        created_at = _timestamp(self.created_at, "created_at")
        expires_at = _timestamp(self.expires_at, "expires_at")
        if expires_at <= created_at:
            raise DeploymentEvidenceError("expires_at must be after created_at")
        object.__setattr__(self, "created_at", created_at)
        object.__setattr__(self, "expires_at", expires_at)
        if not isinstance(self.metadata, Mapping):
            raise DeploymentEvidenceError("metadata must be an object")
        normalized_metadata = _validated_json_copy(self.metadata)
        if not isinstance(normalized_metadata, dict):
            raise DeploymentEvidenceError("metadata must be an object")
        object.__setattr__(self, "metadata", _freeze_json(normalized_metadata))

    @property
    def digest(self) -> str:
        """Digest of the exact canonical wire representation."""

        return evidence_sha256(self.to_dict())

    def to_dict(self) -> dict[str, Any]:
        """Return a new mutable copy of the exact v1 wire object."""

        return {
            "artifact_sha256": self.artifact_sha256,
            "config_effective_digest": self.config_effective_digest,
            "created_at": self.created_at,
            "evidence_id": self.evidence_id,
            "expires_at": self.expires_at,
            "metadata": _mutable_json(self.metadata),
            "producer": {
                "commit": self.producer_commit,
                "product": self.producer_product,
                "version": self.producer_version,
                "wheel_sha256": self.producer_wheel_sha256,
            },
            "review_status": self.review_status,
            "schema_version": self.schema_version,
            "strategy_id": self.strategy_id,
            "tenant_id": self.tenant_id,
        }

    def to_wire(self) -> dict[str, Any]:
        """Alias for :meth:`to_dict`, named for cross-product integration."""

        return self.to_dict()

    def to_json(self) -> str:
        """Return the canonical JSON wire serialization."""

        return canonical_json(self.to_dict())

    @classmethod
    def from_dict(
        cls, raw: Mapping[str, Any], *, now: float | None = None
    ) -> StrategyDeploymentEvidence:
        """Strictly parse the v1 mapping and reject an expired record."""

        if not isinstance(raw, Mapping) or set(raw) != _WIRE_FIELDS:
            raise DeploymentEvidenceError("invalid evidence wire fields")
        producer = raw.get("producer")
        if not isinstance(producer, Mapping) or set(producer) != _PRODUCER_FIELDS:
            raise DeploymentEvidenceError("invalid producer wire fields")
        evidence = cls(
            evidence_id=raw["evidence_id"],
            producer_product=producer["product"],
            producer_version=producer["version"],
            producer_commit=producer["commit"],
            producer_wheel_sha256=producer["wheel_sha256"],
            tenant_id=raw["tenant_id"],
            strategy_id=raw["strategy_id"],
            artifact_sha256=raw["artifact_sha256"],
            config_effective_digest=raw["config_effective_digest"],
            created_at=raw["created_at"],
            expires_at=raw["expires_at"],
            metadata=raw["metadata"],
            review_status=raw["review_status"],
            schema_version=raw["schema_version"],
        )
        _require_unexpired(evidence, now)
        return evidence

    @classmethod
    def from_wire(
        cls, raw: Mapping[str, Any], *, now: float | None = None
    ) -> StrategyDeploymentEvidence:
        """Alias for :meth:`from_dict`, named for cross-product integration."""

        return cls.from_dict(raw, now=now)


# The shorter name keeps the producer API readable while retaining the SDK
# class spelling as a stable import for integration code.
DeploymentEvidence = StrategyDeploymentEvidence


def create_deployment_evidence(
    *,
    artifact_sha256: str,
    config_effective_digest: str,
    producer_product: str,
    producer_version: str,
    producer_commit: str,
    producer_wheel_sha256: str,
    tenant_id: str,
    strategy_id: str,
    metadata: Mapping[str, Any] | None = None,
    evidence_id: str | None = None,
    created_at: float | None = None,
    expires_at: float | None = None,
    ttl_seconds: float = 3600.0,
) -> StrategyDeploymentEvidence:
    """Create fresh review-request evidence with no authority-bearing fields.

    ``review_status`` is deliberately absent from the inputs, so callers cannot
    use this producer to assert that a review happened.
    """

    created = (
        time.time() if created_at is None else _timestamp(created_at, "created_at")
    )
    if expires_at is None:
        ttl = _timestamp(ttl_seconds, "ttl_seconds")
        if ttl <= 0:
            raise DeploymentEvidenceError("ttl_seconds must be positive")
        expires = created + ttl
    else:
        expires = _timestamp(expires_at, "expires_at")
    evidence = StrategyDeploymentEvidence(
        evidence_id=evidence_id or f"evidence-{uuid.uuid4().hex}",
        producer_product=producer_product,
        producer_version=producer_version,
        producer_commit=producer_commit,
        producer_wheel_sha256=producer_wheel_sha256,
        tenant_id=tenant_id,
        strategy_id=strategy_id,
        artifact_sha256=artifact_sha256,
        config_effective_digest=config_effective_digest,
        created_at=created,
        expires_at=expires,
        metadata={} if metadata is None else metadata,
    )
    _require_unexpired(evidence, None)
    return evidence


def _reject_json_constant(value: str) -> None:
    raise DeploymentEvidenceError("non-finite JSON value")


def _reject_duplicate_fields(pairs: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise DeploymentEvidenceError("duplicate JSON object field")
        result[key] = value
    return result


def parse_deployment_evidence(
    wire: SerializedEvidence, *, now: float | None = None
) -> StrategyDeploymentEvidence:
    """Strictly load canonical-wire JSON without duplicate or non-finite values."""

    if isinstance(wire, bytearray):
        wire = bytes(wire)
    if isinstance(wire, bytes):
        try:
            wire = wire.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise DeploymentEvidenceError("evidence wire must be UTF-8 JSON") from exc
    if not isinstance(wire, str):
        raise DeploymentEvidenceError("evidence wire must be JSON text")
    try:
        raw = json.loads(
            wire,
            object_pairs_hook=_reject_duplicate_fields,
            parse_constant=_reject_json_constant,
        )
    except json.JSONDecodeError as exc:
        raise DeploymentEvidenceError("evidence wire is not valid JSON") from exc
    if not isinstance(raw, Mapping):
        raise DeploymentEvidenceError("evidence wire must be an object")
    return StrategyDeploymentEvidence.from_dict(raw, now=now)


def verify_deployment_evidence_digest(
    value: StrategyDeploymentEvidence | Mapping[str, Any] | SerializedEvidence,
    expected_digest: str,
    *,
    now: float | None = None,
) -> StrategyDeploymentEvidence:
    """Validate a non-expired wire record and its caller-supplied digest binding."""

    expected = _sha256(expected_digest, "expected_digest")
    if isinstance(value, StrategyDeploymentEvidence):
        evidence = value
        _require_unexpired(evidence, now)
    elif isinstance(value, Mapping):
        evidence = StrategyDeploymentEvidence.from_dict(value, now=now)
    else:
        evidence = parse_deployment_evidence(value, now=now)
    if not hmac.compare_digest(evidence.digest, expected):
        raise DeploymentEvidenceError("deployment evidence digest does not match")
    return evidence


__all__ = [
    "DEPLOYMENT_EVIDENCE_SCHEMA_VERSION",
    "REVIEW_REQUIRED",
    "DeploymentEvidence",
    "DeploymentEvidenceError",
    "StrategyDeploymentEvidence",
    "canonical_json",
    "create_deployment_evidence",
    "evidence_sha256",
    "parse_deployment_evidence",
    "verify_deployment_evidence_digest",
]
