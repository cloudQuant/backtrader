"""Small deterministic and filesystem-safe helpers."""

from __future__ import annotations

import hashlib
import json
import math
import os
import secrets
import tempfile
import unicodedata
from pathlib import Path
from typing import Any

MISSING_HASH = "__MISSING__"


def _normalize(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("canonical JSON rejects NaN and Infinity")
        return 0.0 if value == 0.0 else value
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, (list, tuple)):
        return [_normalize(item) for item in value]
    if isinstance(value, dict):
        normalized: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("canonical JSON object keys must be strings")
            normalized_key = unicodedata.normalize("NFC", key)
            if normalized_key in normalized:
                raise ValueError("canonical JSON keys collide after Unicode NFC normalization")
            normalized[normalized_key] = _normalize(item)
        return normalized
    if hasattr(value, "to_dict"):
        return _normalize(value.to_dict())
    raise TypeError(f"unsupported canonical JSON type: {type(value).__name__}")


def canonical_json(value: Any) -> str:
    return json.dumps(
        _normalize(value),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_bytes(canonical_json(value).encode("utf-8"))


def file_hash(path: Path) -> str:
    if not path.exists():
        return MISSING_HASH
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _windows_private_temp(path: Path, mode: int) -> tuple[int, Path]:
    """Create a mode-0600 temporary file with a protected Windows DACL.

    Windows does not implement POSIX mode bits. For the private-file mode used
    by this package, create the file with an explicit DACL at creation time so
    it is never briefly exposed through inherited directory permissions.
    """
    if mode != 0o600:
        raise ValueError("Windows atomic_write only supports owner-only mode 0o600")

    import ctypes
    import msvcrt
    from ctypes import wintypes

    class _SidAndAttributes(ctypes.Structure):
        _fields_ = [("Sid", wintypes.LPVOID), ("Attributes", wintypes.DWORD)]

    class _TokenUser(ctypes.Structure):
        _fields_ = [("User", _SidAndAttributes)]

    class _SecurityAttributes(ctypes.Structure):
        _fields_ = [
            ("nLength", wintypes.DWORD),
            ("lpSecurityDescriptor", wintypes.LPVOID),
            ("bInheritHandle", wintypes.BOOL),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    token = wintypes.HANDLE()
    sid_string = wintypes.LPWSTR()
    descriptor = wintypes.LPVOID()

    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    advapi32.OpenProcessToken.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.HANDLE),
    ]
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.GetTokenInformation.argtypes = [
        wintypes.HANDLE,
        ctypes.c_int,
        wintypes.LPVOID,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    advapi32.GetTokenInformation.restype = wintypes.BOOL
    advapi32.ConvertSidToStringSidW.argtypes = [
        wintypes.LPVOID,
        ctypes.POINTER(wintypes.LPWSTR),
    ]
    advapi32.ConvertSidToStringSidW.restype = wintypes.BOOL
    advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.LPVOID),
        ctypes.POINTER(wintypes.DWORD),
    ]
    advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW.restype = wintypes.BOOL
    kernel32.CreateFileW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.POINTER(_SecurityAttributes),
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
    ]
    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel32.LocalFree.restype = wintypes.HLOCAL

    if not advapi32.OpenProcessToken(kernel32.GetCurrentProcess(), 0x0008, ctypes.byref(token)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        required = wintypes.DWORD()
        advapi32.GetTokenInformation(token, 1, None, 0, ctypes.byref(required))
        if not required.value:
            raise ctypes.WinError(ctypes.get_last_error())
        token_buffer = ctypes.create_string_buffer(required.value)
        if not advapi32.GetTokenInformation(
            token, 1, token_buffer, required.value, ctypes.byref(required)
        ):
            raise ctypes.WinError(ctypes.get_last_error())
        user = ctypes.cast(token_buffer, ctypes.POINTER(_TokenUser)).contents
        if not advapi32.ConvertSidToStringSidW(user.User.Sid, ctypes.byref(sid_string)):
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            # Protect against inherited ACEs. The process user owns the file;
            # LocalSystem retains access for OS maintenance.
            sddl = f"D:P(A;;FA;;;{sid_string.value})(A;;FA;;;SY)"
            if not advapi32.ConvertStringSecurityDescriptorToSecurityDescriptorW(
                sddl, 1, ctypes.byref(descriptor), None
            ):
                raise ctypes.WinError(ctypes.get_last_error())
        finally:
            kernel32.LocalFree(sid_string)
    finally:
        kernel32.CloseHandle(token)

    attributes = _SecurityAttributes(ctypes.sizeof(_SecurityAttributes), descriptor, False)
    try:
        for _ in range(8):
            temporary_path = path.parent / f".btmcp-{secrets.token_hex(16)}.tmp"
            handle = kernel32.CreateFileW(
                str(temporary_path),
                0x40000000,  # GENERIC_WRITE
                0,  # Keep the not-yet-published temporary file exclusive.
                ctypes.byref(attributes),
                1,  # CREATE_NEW
                0x00000080,  # FILE_ATTRIBUTE_NORMAL
                None,
            )
            if handle == ctypes.c_void_p(-1).value:
                error = ctypes.get_last_error()
                if error in (80, 183):  # ERROR_FILE_EXISTS / ERROR_ALREADY_EXISTS
                    continue
                raise ctypes.WinError(error)
            try:
                flags = os.O_WRONLY | os.O_BINARY | getattr(os, "O_NOINHERIT", 0)
                file_descriptor = msvcrt.open_osfhandle(handle, flags)
            except BaseException:
                kernel32.CloseHandle(handle)
                temporary_path.unlink(missing_ok=True)
                raise
            return file_descriptor, temporary_path
        raise FileExistsError("could not allocate a unique atomic-write temporary file")
    finally:
        kernel32.LocalFree(descriptor)


def _windows_replace_write_through(source: Path, target: Path) -> None:
    import ctypes
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    move_file_ex = kernel32.MoveFileExW
    move_file_ex.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD]
    move_file_ex.restype = wintypes.BOOL
    # The temporary file is in the destination directory, so this stays on
    # one volume. WRITE_THROUGH requests that the completed move be flushed.
    if not move_file_ex(str(source), str(target), 0x00000001 | 0x00000008):
        raise ctypes.WinError(ctypes.get_last_error())


def fsync_directory(path: Path) -> None:
    """Sync directory metadata on POSIX; Windows has no Python equivalent.

    Windows callers use write-through MoveFileEx for replacement and rename
    operations. This helper deliberately does not claim POSIX directory-fsync
    semantics on Windows.
    """
    if os.name == "nt":
        return
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable_replace(source: Path, target: Path) -> None:
    """Replace a path and request the strongest portable metadata flush."""
    if os.name == "nt":
        _windows_replace_write_through(source, target)
        return
    os.replace(source, target)
    fsync_directory(target.parent)


def atomic_write(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        fd, temporary_path = _windows_private_temp(path, mode)
    else:
        fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        temporary_path = Path(temporary)
    try:
        if os.name != "nt":
            os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        durable_replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


def utc_now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


class FileHashCache:
    """Small (inode, mtime, size)-keyed digest cache for integrity echoes.

    Only for read-only preview/inspect surfaces: security-critical
    verification paths (worker, tokens, changes) keep using the uncached
    :func:`file_hash` so a deliberately replayed timestamp can never turn
    into a false content match there.
    """

    def __init__(self, max_entries: int = 256):
        self.max_entries = max_entries
        self._entries: dict[tuple[int, int, int], str] = {}

    def hash(self, path: Path) -> str:
        stat = path.stat()
        key = (stat.st_ino, stat.st_mtime_ns, stat.st_size)
        digest = self._entries.get(key)
        if digest is None:
            digest = file_hash(path)
            if len(self._entries) >= self.max_entries:
                self._entries.clear()
            self._entries[key] = digest
        return digest


def approver_identity() -> dict[str, Any]:
    """OS identity of the local approver for audit records (best-effort)."""
    import getpass

    identity: dict[str, Any] = {"username": getpass.getuser()}
    try:
        identity["uid"] = os.getuid()
    except AttributeError:  # non-POSIX
        pass
    return identity
