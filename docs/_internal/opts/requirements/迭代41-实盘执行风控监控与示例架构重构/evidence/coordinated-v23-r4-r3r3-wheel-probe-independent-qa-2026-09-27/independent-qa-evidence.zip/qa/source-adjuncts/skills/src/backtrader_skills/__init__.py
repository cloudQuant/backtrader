"""Deterministic Backtrader strategy authoring, review, and test tooling."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .canonical import canonical_bytes, canonical_hash

if TYPE_CHECKING:
    from .deployment_evidence import (
        DEPLOYMENT_EVIDENCE_SCHEMA_VERSION,
        StrategyDeploymentEvidence,
        load_deployment_evidence,
        validate_deployment_evidence,
    )

__all__ = [
    "DEPLOYMENT_EVIDENCE_SCHEMA_VERSION",
    "StrategyDeploymentEvidence",
    "canonical_bytes",
    "canonical_hash",
    "load_deployment_evidence",
    "validate_deployment_evidence",
]
__version__ = "0.2.0"


def __getattr__(name: str) -> object:
    """Lazily expose the standalone evidence API without affecting ``-m`` startup."""

    if name in {
        "DEPLOYMENT_EVIDENCE_SCHEMA_VERSION",
        "StrategyDeploymentEvidence",
        "load_deployment_evidence",
        "validate_deployment_evidence",
    }:
        from . import deployment_evidence

        return getattr(deployment_evidence, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
