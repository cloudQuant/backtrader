"""Durable monitor control-command ledger.

The ledger records a command before any account owner acts on it.  It has no
provider client and does not claim a command has executed merely because it
was accepted.  A supervisor, gateway, or Broker adapter must claim and then
acknowledge/reject its own command after performing its independently guarded
operation.
"""

from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable, Optional, Union


class ControlLedgerError(RuntimeError):
    """Base error for control-command validation and delivery."""


class ControlConflictError(ControlLedgerError):
    """A command id was reused with different content."""


class ControlClaimError(ControlLedgerError):
    """An executor attempted an invalid claim or outcome transition."""


class ControlAction(str, Enum):
    """The supported monitor-to-owner commands."""

    FREEZE = "freeze"
    DRAIN = "drain"
    RESUME = "resume"


class ControlStatus(str, Enum):
    """Persisted state of one command, never inferred from a client response."""

    PENDING = "pending"
    CLAIMED = "claimed"
    ACKNOWLEDGED = "acknowledged"
    REJECTED = "rejected"
    EXPIRED = "expired"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class ControlCommand:
    """A signed/authorized command envelope after authentication has happened."""

    command_id: str
    scope: str
    action: ControlAction
    issuer: str
    reason: str
    receipt_digest: str
    issued_at: float
    expires_at: float
    manual_resume_authorized: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.action, ControlAction):
            raise ValueError("action must be a ControlAction")
        if type(self.manual_resume_authorized) is not bool:
            raise ValueError("manual_resume_authorized must be a boolean")
        for name in ("command_id", "scope", "issuer", "reason", "receipt_digest"):
            if not str(getattr(self, name)).strip():
                raise ValueError(name + " is required")
        if any(
            isinstance(value, bool) or not math.isfinite(value)
            for value in (self.issued_at, self.expires_at)
        ):
            raise ValueError("command timestamps must be finite")
        if self.expires_at <= self.issued_at:
            raise ValueError("expires_at must be after issued_at")
        if self.action is ControlAction.RESUME and not self.manual_resume_authorized:
            raise ValueError("resume requires explicit manual authorization")

    @property
    def fingerprint(self) -> str:
        return _sha256(
            _canonical_json(
                {
                    "action": self.action.value,
                    "expires_at": self.expires_at,
                    "issued_at": self.issued_at,
                    "issuer": self.issuer,
                    "manual_resume_authorized": self.manual_resume_authorized,
                    "reason": self.reason,
                    "receipt_digest": self.receipt_digest,
                    "scope": self.scope,
                }
            )
        )


@dataclass(frozen=True)
class ClaimedControlCommand:
    """A command leased to exactly one account owner."""

    command: ControlCommand
    status: ControlStatus
    executor_id: Optional[str]  # noqa: UP045 -- Python 3.9 is supported.
    outcome: Optional[str] = None  # noqa: UP045 -- Python 3.9 is supported.


class DurableControlLedger:
    """SQLite command ledger with idempotent submit and one-executor claiming."""

    def __init__(
        self,
        database_path: Union[Path, str],  # noqa: UP007 -- Python 3.9 is supported.
        clock: Optional[Callable[[], float]] = None,  # noqa: UP045 -- Python 3.9 is supported.
        timeout_seconds: float = 5.0,
    ) -> None:
        self._database_path = Path(database_path)
        self._clock = clock or time.time
        self._timeout_seconds = timeout_seconds
        self._database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize_schema()

    def submit(self, command: ControlCommand) -> ClaimedControlCommand:
        """Persist a command before an owner can claim it; exact retry is idempotent."""
        with self._transaction() as connection:
            now = self._clock()
            self._expire_pending(connection, now)
            existing = connection.execute(
                "SELECT * FROM monitor_control_commands WHERE command_id = ?", (command.command_id,)
            ).fetchone()
            if existing is not None:
                if str(existing["fingerprint"]) != command.fingerprint:
                    raise ControlConflictError("command_id was reused with different content")
                return self._claimed_from_row(existing)
            status = ControlStatus.EXPIRED if command.expires_at <= now else ControlStatus.PENDING
            connection.execute(
                """
                INSERT INTO monitor_control_commands (
                    command_id, fingerprint, scope, action, issuer, reason, receipt_digest,
                    issued_at, expires_at, manual_resume_authorized, status, executor_id, outcome,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?)
                """,
                (
                    command.command_id,
                    command.fingerprint,
                    command.scope,
                    command.action.value,
                    command.issuer,
                    command.reason,
                    command.receipt_digest,
                    command.issued_at,
                    command.expires_at,
                    int(command.manual_resume_authorized),
                    status.value,
                    now,
                ),
            )
            return ClaimedControlCommand(command, status, None)

    def claim_next(self, scope: str, executor_id: str) -> Optional[ClaimedControlCommand]:  # noqa: UP045 -- Python 3.9 is supported.
        """Lease the oldest pending unexpired command in the requested scope."""
        if not scope.strip() or not executor_id.strip():
            raise ValueError("scope and executor_id are required")
        now = self._clock()
        with self._transaction() as connection:
            self._expire_pending(connection, now)
            row = connection.execute(
                """
                SELECT * FROM monitor_control_commands
                WHERE scope = ? AND status = ? AND issued_at <= ?
                ORDER BY issued_at ASC, command_id ASC LIMIT 1
                """,
                (scope, ControlStatus.PENDING.value, now),
            ).fetchone()
            if row is None:
                return None
            connection.execute(
                """
                UPDATE monitor_control_commands
                SET status = ?, executor_id = ?, updated_at = ? WHERE command_id = ?
                """,
                (ControlStatus.CLAIMED.value, executor_id, now, row["command_id"]),
            )
            claimed = dict(row)
            claimed["status"] = ControlStatus.CLAIMED.value
            claimed["executor_id"] = executor_id
            return self._claimed_from_mapping(claimed)

    def finish(self, command_id: str, executor_id: str, succeeded: bool, outcome: str) -> None:
        """Record a final owner outcome after the external action has actually completed."""
        if not command_id.strip() or not executor_id.strip() or not outcome.strip():
            raise ValueError("command_id, executor_id, and outcome are required")
        if type(succeeded) is not bool:
            raise ValueError("succeeded must be a boolean")
        now = self._clock()
        failure = None
        status = ControlStatus.ACKNOWLEDGED if succeeded else ControlStatus.REJECTED
        with self._transaction() as connection:
            self._expire_pending(connection, now)
            row = connection.execute(
                "SELECT * FROM monitor_control_commands WHERE command_id = ?", (command_id,)
            ).fetchone()
            if row is None:
                failure = ControlClaimError("command does not exist")
            elif row["executor_id"] != executor_id:
                failure = ControlClaimError("command is owned by another executor")
            elif row["status"] == status.value and row["outcome"] == outcome:
                return
            elif row["status"] != ControlStatus.CLAIMED.value:
                failure = ControlClaimError(
                    "command is not claimed; reconciliation may be required"
                )
            else:
                connection.execute(
                    """
                    UPDATE monitor_control_commands SET status = ?, outcome = ?, updated_at = ?
                    WHERE command_id = ?
                    """,
                    (status.value, outcome, now, command_id),
                )
        # Commit timeout/unknown facts even when the attempted ACK is rejected.
        if failure is not None:
            raise failure

    def get(self, command_id: str) -> Optional[ClaimedControlCommand]:  # noqa: UP045 -- Python 3.9 is supported.
        """Return the durable command state without changing it."""
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM monitor_control_commands WHERE command_id = ?", (command_id,)
            ).fetchone()
        return self._claimed_from_row(row) if row is not None else None

    def _expire_pending(self, connection: sqlite3.Connection, now: float) -> None:
        connection.execute(
            """
            UPDATE monitor_control_commands
            SET status = ?, outcome = ?, updated_at = ?
            WHERE status = ? AND expires_at <= ?
            """,
            (
                ControlStatus.EXPIRED.value,
                "command_ttl_elapsed",
                now,
                ControlStatus.PENDING.value,
                now,
            ),
        )
        connection.execute(
            """
            UPDATE monitor_control_commands SET status = ?, outcome = ?, updated_at = ?
            WHERE status = ? AND expires_at <= ?
            """,
            (
                ControlStatus.UNKNOWN.value,
                "claimed_command_reconciliation_required",
                now,
                ControlStatus.CLAIMED.value,
                now,
            ),
        )

    def _claimed_from_row(self, row: sqlite3.Row) -> ClaimedControlCommand:
        return self._claimed_from_mapping(dict(row))

    def _claimed_from_mapping(self, row: dict[str, object]) -> ClaimedControlCommand:
        command = ControlCommand(
            command_id=str(row["command_id"]),
            scope=str(row["scope"]),
            action=ControlAction(str(row["action"])),
            issuer=str(row["issuer"]),
            reason=str(row["reason"]),
            receipt_digest=str(row["receipt_digest"]),
            issued_at=float(row["issued_at"]),
            expires_at=float(row["expires_at"]),
            manual_resume_authorized=bool(row["manual_resume_authorized"]),
        )
        executor_id = row.get("executor_id")
        return ClaimedControlCommand(
            command=command,
            status=ControlStatus(str(row["status"])),
            executor_id=str(executor_id) if executor_id is not None else None,
            outcome=str(row["outcome"]) if row.get("outcome") is not None else None,
        )

    def _initialize_schema(self) -> None:
        with self._connection() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS monitor_control_commands (
                    command_id TEXT PRIMARY KEY,
                    fingerprint TEXT NOT NULL,
                    scope TEXT NOT NULL,
                    action TEXT NOT NULL,
                    issuer TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    receipt_digest TEXT NOT NULL,
                    issued_at REAL NOT NULL,
                    expires_at REAL NOT NULL,
                    manual_resume_authorized INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    executor_id TEXT,
                    outcome TEXT,
                    updated_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_monitor_control_scope_status
                    ON monitor_control_commands(scope, status, issued_at);
                """
            )

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(
            str(self._database_path), timeout=self._timeout_seconds, isolation_level=None
        )
        connection.row_factory = sqlite3.Row
        try:
            connection.execute("PRAGMA synchronous = FULL")
            yield connection
        finally:
            connection.close()

    @contextmanager
    def _transaction(self) -> Iterator[sqlite3.Connection]:
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield connection
            except BaseException:
                connection.execute("ROLLBACK")
                raise
            else:
                connection.execute("COMMIT")


def _canonical_json(value: object) -> str:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False
    )


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


__all__ = [
    "ClaimedControlCommand",
    "ControlAction",
    "ControlClaimError",
    "ControlCommand",
    "ControlConflictError",
    "ControlLedgerError",
    "ControlStatus",
    "DurableControlLedger",
]
