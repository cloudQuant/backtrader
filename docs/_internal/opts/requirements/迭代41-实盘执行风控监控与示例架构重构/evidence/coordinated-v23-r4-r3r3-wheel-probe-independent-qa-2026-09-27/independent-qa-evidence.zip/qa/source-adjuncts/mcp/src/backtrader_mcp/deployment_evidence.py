"""Read-only observation of the portable Iteration 41 evidence wire contract.

This module owns no deployment, execution, control or credential capability.
Expected bindings come from the caller's independent review context. Matching
them is an integrity check, never authentication or deployment authorization.
The wire canonicalization intentionally differs from this product's older
util.canonical_json: v1 uses ensure_ascii=True without Unicode normalization.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import math
import re
import time
from typing import Any, NoReturn

from .errors import ProductError

SCHEMA_VERSION = "bt-api-deployment-evidence/v1"
_FIELDS = frozenset(
    {
        "artifact_sha256",
        "config_effective_digest",
        "created_at",
        "evidence_id",
        "expires_at",
        "metadata",
        "producer",
        "review_status",
        "schema_version",
        "strategy_id",
        "tenant_id",
    }
)
_PRODUCER_FIELDS = frozenset({"commit", "product", "version", "wheel_sha256"})
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}\Z")
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_REVIEW_STATUSES = frozenset({"review_required", "mechanically_mapped", "human_reviewed"})
_SECRET_KEY_PARTS = (
    "api_key",
    "apikey",
    "authorization",
    "credential",
    "passphrase",
    "password",
    "private_key",
    "secret",
    "token",
)
_MAX_DEPTH = 32
_MAX_BYTES = 1024 * 1024


class DeploymentEvidenceError(ProductError):
    """A stable rejection whose message never echoes evidence or secret values."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def _reject(code: str, message: str) -> NoReturn:
    raise DeploymentEvidenceError(code, message)


def _identifier(value: Any) -> None:
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value):
        _reject(
            "EVIDENCE_SCHEMA_INVALID", "Evidence identifiers must use the v1 identifier syntax."
        )


def _digest(value: Any) -> None:
    if not isinstance(value, str) or not _SHA256.fullmatch(value):
        _reject(
            "EVIDENCE_SCHEMA_INVALID",
            "Evidence digests must be 64 lowercase hexadecimal characters.",
        )


def _timestamp(value: Any) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence timestamps must be finite numbers.")
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence timestamps must be finite numbers.")


def _validate_json(value: Any, depth: int = 0, ancestors: frozenset[int] = frozenset()) -> None:
    if depth > _MAX_DEPTH:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence JSON exceeds the supported nesting depth.")
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float:
        if not math.isfinite(value):
            _reject("EVIDENCE_SCHEMA_INVALID", "Evidence JSON must not contain NaN or Infinity.")
        return
    if type(value) not in (dict, list):
        _reject(
            "EVIDENCE_SCHEMA_INVALID",
            "Evidence must contain JSON objects, arrays and scalars only.",
        )
    if id(value) in ancestors:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence JSON must not contain cycles.")
    ancestors = ancestors | {id(value)}
    if isinstance(value, dict):
        for key, nested in value.items():
            if not isinstance(key, str):
                _reject("EVIDENCE_SCHEMA_INVALID", "Evidence object keys must be strings.")
            normalized = key.lower().replace("-", "_")
            if any(part in normalized for part in _SECRET_KEY_PARTS):
                _reject(
                    "EVIDENCE_SECRET_FORBIDDEN", "Secret-shaped fields are forbidden in evidence."
                )
            _validate_json(nested, depth + 1, ancestors)
    else:
        for nested in value:
            _validate_json(nested, depth + 1, ancestors)


def _canonical_wire(evidence: dict[str, Any]) -> bytes:
    _validate_json(evidence)
    try:
        encoded = json.dumps(
            evidence, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeError):
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence cannot be encoded as canonical v1 JSON.")
    if len(encoded) > _MAX_BYTES:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence exceeds the supported payload size.")
    return encoded


def validate_deployment_evidence(
    evidence: dict[str, Any],
    *,
    expected_evidence_sha256: str,
    expected_tenant_id: str,
    expected_strategy_id: str,
    expected_artifact_sha256: str,
    expected_config_effective_digest: str,
    now: float | None = None,
) -> dict[str, Any]:
    """Validate a full v1 wire record and return only a review recommendation.

    No input is executed, imported, read from disk or written to durable state.
    ``now`` is a trusted code/test seam; the MCP tool never accepts a client clock.
    A digest supplied alongside its own payload does not establish provenance.
    """
    if type(evidence) is not dict or set(evidence) != _FIELDS:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence must contain exactly the published v1 fields.")
    producer = evidence["producer"]
    if type(producer) is not dict or set(producer) != _PRODUCER_FIELDS:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence producer fields do not match the v1 contract.")
    if evidence["schema_version"] != SCHEMA_VERSION:
        _reject("EVIDENCE_SCHEMA_UNSUPPORTED", "Evidence schema version is not supported.")
    for name in ("evidence_id", "tenant_id", "strategy_id"):
        _identifier(evidence[name])
    for name in ("commit", "product", "version"):
        _identifier(producer[name])
    for value in (
        evidence["artifact_sha256"],
        evidence["config_effective_digest"],
        producer["wheel_sha256"],
        expected_evidence_sha256,
        expected_artifact_sha256,
        expected_config_effective_digest,
    ):
        _digest(value)
    _identifier(expected_tenant_id)
    _identifier(expected_strategy_id)
    if (
        not isinstance(evidence["review_status"], str)
        or evidence["review_status"] not in _REVIEW_STATUSES
    ):
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence review status is not supported.")
    if type(evidence["metadata"]) is not dict:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence metadata must be a JSON object.")
    _timestamp(evidence["created_at"])
    _timestamp(evidence["expires_at"])
    if evidence["expires_at"] <= evidence["created_at"]:
        _reject("EVIDENCE_SCHEMA_INVALID", "Evidence expiry must follow creation.")

    # Snapshot the exact full wire after validation. No caller-owned nested object
    # is retained, and no normalization changes which payload is hash-bound.
    canonical = _canonical_wire(evidence)
    snapshot = json.loads(canonical)
    digest = hashlib.sha256(canonical).hexdigest()
    if not hmac.compare_digest(digest, expected_evidence_sha256):
        _reject("EVIDENCE_TAMPERED", "Evidence does not match the independently supplied digest.")
    if (
        snapshot["tenant_id"] != expected_tenant_id
        or snapshot["strategy_id"] != expected_strategy_id
    ):
        _reject("EVIDENCE_SCOPE_MISMATCH", "Evidence belongs to a different tenant or strategy.")
    if not hmac.compare_digest(snapshot["artifact_sha256"], expected_artifact_sha256):
        _reject("EVIDENCE_BINDING_MISMATCH", "Evidence does not bind the expected artifact.")
    if not hmac.compare_digest(
        snapshot["config_effective_digest"], expected_config_effective_digest
    ):
        _reject(
            "EVIDENCE_BINDING_MISMATCH",
            "Evidence does not bind the expected effective configuration.",
        )
    observed_at = time.time() if now is None else now
    _timestamp(observed_at)
    if observed_at < snapshot["created_at"]:
        _reject("EVIDENCE_NOT_YET_VALID", "Evidence creation is in the future.")
    if observed_at >= snapshot["expires_at"]:
        _reject("EVIDENCE_EXPIRED", "Evidence has expired and requires renewed review.")
    review_required = snapshot["review_status"] == "review_required"
    return {
        "schema_version": "backtrader-mcp.deployment-evidence-observation/v1",
        "status": "REQUIRES_INDEPENDENT_REVIEW" if review_required else "EVIDENCE_VALID_FOR_REVIEW",
        "read_only": True,
        "evidence_sha256": digest,
        "evidence_id": snapshot["evidence_id"],
        "tenant_id": snapshot["tenant_id"],
        "strategy_id": snapshot["strategy_id"],
        "review_status": snapshot["review_status"],
        "deployment_authorized": False,
        "execution_authorized": False,
        "control_authorized": False,
        "recommendation": (
            "Obtain independent human review before requesting deployment approval."
            if review_required
            else "Verify independent deployment approval; this observation grants no authority."
        ),
    }
