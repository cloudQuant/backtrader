"""Independent deterministic runtime for the Backtrader authoring agent."""

from .contracts import DatasetManifest, StrategySpec
from .deployment_evidence import (
    DEPLOYMENT_EVIDENCE_SCHEMA_VERSION,
    REVIEW_REQUIRED,
    DeploymentEvidence,
    DeploymentEvidenceError,
    StrategyDeploymentEvidence,
    canonical_json,
    create_deployment_evidence,
    evidence_sha256,
    parse_deployment_evidence,
    verify_deployment_evidence_digest,
)
from .errors import AgentError

__all__ = [
    "DEPLOYMENT_EVIDENCE_SCHEMA_VERSION",
    "REVIEW_REQUIRED",
    "AgentError",
    "DatasetManifest",
    "DeploymentEvidence",
    "DeploymentEvidenceError",
    "StrategyDeploymentEvidence",
    "StrategySpec",
    "canonical_json",
    "create_deployment_evidence",
    "evidence_sha256",
    "parse_deployment_evidence",
    "verify_deployment_evidence_digest",
]
__version__ = "0.2.0"
