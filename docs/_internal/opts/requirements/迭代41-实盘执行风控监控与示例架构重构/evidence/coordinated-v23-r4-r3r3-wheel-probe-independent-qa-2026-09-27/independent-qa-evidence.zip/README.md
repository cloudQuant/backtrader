# Independent V23/R4/R3r3 wheel QA (offline, fake-only)

This bundle independently checks the frozen coordinated probe at source-manifest SHA256 01fa737d2a0f385dec8ce6187d95c4a104c13cce9dde6d693152df7dd94ef4b6 and raw ZIP SHA256 9510abeffcf040bf4a7ea8b8e0524e93cfe1046a8b9498dbc7e26626adbb2c46. Two executions each of the V23 execution and R4/R3r3 parent wheel were byte-identical. Fresh isolated CPython 3.11.5 venv RECORD payloads, PEP 610 direct_url wheel digests, and offline pip check passed.

## Results

Four guarded fake test groups passed: 73 main bridge/L2, 20 cancellation control, 6 artifact-set, and 44 parent issuer/control; all had zero skips, failures, or errors. Combined: 143 executions, 123 unique node IDs, 20 repeated node executions. All four runners report `NATIVE_MODULES_LOADED []`. Guard totals are in `qa/guard-summary.json`; blocked network/native/private-config/origin events were zero.

The source archive contains 1,015 indexed payload members plus its extra `ARCHIVE-INDEX.json` self-index member, making 1,016 total. The self-index bytes equal the external index (SHA256 0492df7ea055116c96519b8500d00b85f081da8d96c6dd69a1d88f2c05f0e569). The author live candidate directory had 472 unmanifested main-overlay cache/bytecode files when captured; they are not counted in its 843-file frozen source manifest.

`bt_api_base` remains SOURCE-ONLY for this QA: its runtime wheel was removed, and source plus source-only distribution metadata were mapped for tests and pip check. External helper roots were copied as inert files and hash-bound; they are QA adjuncts, not part of the author candidate manifest. No real provider, network, credential, CTP native module, or default pin was used. This is not G1/G4/G5 or release acceptance.

Dependency wheels copied from the local offline wheelhouse are hash-bound by `qa/wheelhouse-manifest.json`; to keep this bundle compact, the copied dependency-wheel binaries and disposable venv are not included. The two candidate wheels themselves are in the raw author ZIP.
