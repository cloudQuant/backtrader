import hashlib, json, pathlib, shutil, zipfile, datetime
frozen = pathlib.Path(r'D:\temp\iteration41-coordinated-release-probe-20260927-r1')
qa = pathlib.Path(r'D:\temp\iteration41-coordinated-release-probe-independent-qa-20260927')
manifest_path = frozen / 'coordinated-probe-source-manifest-final.json'
index_path = frozen / 'coordinated-probe-archive-index-v2.json'
zip_path = frozen / 'coordinated-probe-final-evidence-v2.zip'
expected = {'manifest':'01fa737d2a0f385dec8ce6187d95c4a104c13cce9dde6d693152df7dd94ef4b6','index':'0492df7ea055116c96519b8500d00b85f081da8d96c6dd69a1d88f2c05f0e569','zip':'9510abeffcf040bf4a7ea8b8e0524e93cfe1046a8b9498dbc7e26626adbb2c46'}
def sha(data): return hashlib.sha256(data).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
manifest_bytes=manifest_path.read_bytes(); index_bytes=index_path.read_bytes(); zip_bytes_sha=file_sha(zip_path)
assert sha(manifest_bytes)==expected['manifest'], ('manifest SHA',sha(manifest_bytes))
assert sha(index_bytes)==expected['index'], ('index SHA',sha(index_bytes))
assert zip_bytes_sha==expected['zip'], ('zip SHA',zip_bytes_sha)
manifest=json.loads(manifest_bytes.decode('utf-8')); index=json.loads(index_bytes.decode('utf-8'))
assert index['source_manifest_sha256']==expected['manifest']
assert len(manifest['files'])==843 and index['entry_count']==len(index['files'])==1015
source_checks=[]
for root_name, root_meta in manifest['roots'].items():
 root=frozen/'candidate-v3'/root_name
 actual={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
 expected_rows={r['path']:r for r in manifest['files'] if r['root']==root_name}
 missing=set(expected_rows)-set(actual)
 assert not missing,(root_name,'missing',sorted(missing)[:10])
 total=0
 for rel,row in expected_rows.items():
  p=actual[rel]; n=p.stat().st_size; h=file_sha(p)
  assert n==row['size_bytes'] and h==row['sha256'],(root_name,rel,n,h,row)
  total+=n
 extras=sorted(set(actual)-set(expected_rows)); extra_roots={}
 for rel in extras:
  top=rel.split('/',1)[0]; extra_roots[top]=extra_roots.get(top,0)+1
 source_checks.append({'root':root_name,'manifest_file_count':len(expected_rows),'manifest_bytes':total,'all_manifest_hashes_match':True,'unmanifested_file_count_in_live_candidate_dir':len(extras),'unmanifested_top_level_counts':extra_roots,'unmanifested_samples':extras[:12]})
 assert len(expected_rows)==root_meta['file_count'] and total==root_meta['bytes']
index_rows={r['path']:r for r in index['files']}; assert len(index_rows)==len(index['files'])
with zipfile.ZipFile(zip_path,'r') as z:
 assert z.testzip() is None
 members=[i for i in z.infolist() if not i.is_dir()]
 assert len(index_rows)==1015 and len(members)==1016,(len(members),len(index_rows))
 member_names={i.filename for i in members}
 assert member_names-set(index_rows)=={'ARCHIVE-INDEX.json'} and set(index_rows)-member_names==set(),(len(member_names),len(index_rows),sorted(member_names^set(index_rows))[:10])
 assert z.read('ARCHIVE-INDEX.json')==index_bytes and sha(z.read('ARCHIVE-INDEX.json'))==expected['index']
 for info in members:
  name=info.filename; pp=pathlib.PurePosixPath(name)
  assert '\\' not in name and not name.startswith('/') and all(x not in ('..','') for x in pp.parts),name
  data=z.read(info)
  if name=='ARCHIVE-INDEX.json':
   assert data==index_bytes and sha(data)==expected['index']
   continue
  row=index_rows[name]
  assert len(data)==row['size_bytes'] and sha(data)==row['sha256'],name
  if name=='candidate-v3/VERSIONED-SOURCE-MANIFEST.json':
   assert data==manifest_bytes and row['sha256']==expected['manifest'] and row['size_bytes']==len(manifest_bytes),name
  elif name.startswith('candidate-v3/'):
   relparts=pp.parts; root=relparts[1]; rel='/'.join(relparts[2:])
   if root in manifest['roots']:
    source_row=next((f for f in manifest['files'] if f['root']==root and f['path']==rel),None)
    assert source_row is not None and source_row['sha256']==row['sha256'] and source_row['size_bytes']==row['size_bytes'],name
shutil.copyfile(zip_path,qa/'author-raw-evidence.zip')
shutil.copyfile(manifest_path,qa/'author-source-manifest.json')
shutil.copyfile(index_path,qa/'author-archive-index.json')
shutil.copyfile(frozen/'coordinated-probe-final-receipt.json',qa/'author-receipt.json')
shutil.copyfile(frozen/'coordinated-probe-final-review.md',qa/'author-review.md')
with zipfile.ZipFile(zip_path,'r') as z: z.extractall(qa/'extracted')
result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_inputs':{'manifest_sha256':sha(manifest_bytes),'archive_index_sha256':sha(index_bytes),'zip_sha256':zip_bytes_sha},'source_checks':source_checks,'zip':{'indexed_member_count':len(index_rows),'total_member_count':len(members),'unindexed_self_index_member':'ARCHIVE-INDEX.json','self_index_sha256':expected['index'],'testzip':None,'all_indexed_hashes_match':True,'all_candidate_manifest_paths_match_source_manifest':True},'extracted_root':str(qa/'extracted'),'status':'FROZEN INPUTS VERIFIED; isolated extraction completed; no tests executed yet'}
(qa/'input-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
