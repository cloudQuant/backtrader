import threading
import time
import unittest

from prototype.g1_warmed_worker_custodian import SETUP_STAGES, FakePrewarmedCustodian


class WarmedCustodianTests(unittest.TestCase):
    def test_incomplete_prewarm_rejects_immediately_without_admitting_work(self):
        custodian = FakePrewarmedCustodian(worker_ready=False, controls_owned=True)
        try:
            started = time.monotonic()
            result = custodian.submit(block_stage="join")
            self.assertLess(time.monotonic() - started, 0.05)
            self.assertEqual(result["admission_status"], "rejected_worker_not_ready")
            self.assertFalse(result["single_use_consumed"])
            self.assertTrue(result["controls_owned"])
            self.assertEqual(result["job_members"], ("worker",))
        finally:
            custodian.close()

    def test_missing_preowned_job_controls_rejects_even_if_worker_is_claimed_ready(
        self,
    ):
        custodian = FakePrewarmedCustodian(worker_ready=True, controls_owned=False)
        try:
            custodian.worker_ready = (
                True  # readiness cannot substitute for missing owned controls
            )
            result = custodian.submit()
            self.assertEqual(
                result["admission_status"], "rejected_no_preowned_controls"
            )
            self.assertFalse(result["single_use_consumed"])
            self.assertIsNone(result["custody_token"])
        finally:
            custodian.close()

    def test_normal_request_returns_exact_exit_empty_and_release(self):
        custodian = FakePrewarmedCustodian()
        try:
            result = custodian.submit()
            self.assertEqual(result["response_status"], "SUCCEEDED")
            self.assertEqual(result["exit_code"], 0)
            self.assertTrue(result["exit_observed"])
            self.assertTrue(result["job_empty_observed"])
            self.assertEqual(result["job_members"], ())
            self.assertTrue(result["controls_released"])
            self.assertFalse(result["retained_controls"])
            self.assertEqual(set(result["stage_membership"]), set(SETUP_STAGES))
            self.assertTrue(
                all(
                    "worker" in members
                    for members in result["stage_membership"].values()
                )
            )
        finally:
            custodian.close()

    def test_every_setup_stage_is_inside_job_and_deadline_cleanup_is_exact(self):
        for stage in SETUP_STAGES:
            with self.subTest(stage=stage):
                gate = threading.Event()
                custodian = FakePrewarmedCustodian(
                    caller_timeout=0.35, cleanup_reserve=0.11
                )
                try:
                    holder = {}
                    caller = threading.Thread(
                        target=lambda h=holder, c=custodian, s=stage, g=gate: (
                            h.setdefault(
                                "result", c.submit(block_stage=s, stage_gate=g)
                            )
                        )
                    )
                    caller.start()
                    deadline = time.monotonic() + 0.15
                    req = custodian._active
                    while req is None and time.monotonic() < deadline:
                        time.sleep(0.001)
                        req = custodian._active
                    self.assertIsNotNone(req)
                    self.assertTrue(req.stage_entered.wait(timeout=0.25), stage)
                    caller.join(timeout=0.7)
                    self.assertFalse(
                        caller.is_alive(),
                        "request caller exceeded its absolute deadline",
                    )
                    result = holder["result"]
                    self.assertEqual(result["admission_status"], "accepted")
                    self.assertLessEqual(result["elapsed_seconds"], 0.45)
                    self.assertEqual(result["response_status"], "DEADLINE_EXCEEDED")
                    self.assertEqual(result["exit_code"], -9)
                    self.assertTrue(result["exit_observed"])
                    self.assertTrue(result["job_empty_observed"])
                    self.assertEqual(result["job_members"], ())
                    self.assertTrue(result["controls_released"])
                    self.assertFalse(result["retained_controls"])
                    self.assertEqual(result["cleanup_state"], "released_after_empty")
                    self.assertTrue(result["stage_membership"][stage])
                    self.assertIn("worker", result["stage_membership"][stage])
                    if stage != "create_process":
                        self.assertIn(
                            "provider-child", result["stage_membership"][stage]
                        )
                    self.assertEqual(
                        custodian.submit()["admission_status"],
                        "rejected_single_use_consumed",
                    )
                finally:
                    gate.set()
                    custodian.close()

    def test_custodian_terminate_stall_returns_unknown_and_retains_controls(self):
        release_terminate = threading.Event()
        custodian = FakePrewarmedCustodian(
            caller_timeout=0.30,
            cleanup_reserve=0.08,
            cleanup_grace=0.6,
            block_terminate=True,
        )
        try:
            # Set the preowned fake Job's synchronous terminate gate before admission.
            custodian.job.terminate_gate = release_terminate
            gate = threading.Event()
            holder = {}
            caller = threading.Thread(
                target=lambda: holder.setdefault(
                    "result", custodian.submit(block_stage="join", stage_gate=gate)
                )
            )
            caller.start()
            deadline = time.monotonic() + 0.15
            req = custodian._active
            while req is None and time.monotonic() < deadline:
                time.sleep(0.001)
                req = custodian._active
            self.assertIsNotNone(req)
            self.assertTrue(req.stage_entered.wait(timeout=0.20))
            self.assertTrue(custodian.job.terminate_entered.wait(timeout=0.4))
            caller.join(timeout=0.55)
            self.assertFalse(caller.is_alive(), "caller blocked on custodian cleanup")
            result = holder["result"]
            self.assertEqual(result["response_status"], "UNKNOWN")
            self.assertLessEqual(result["elapsed_seconds"], 0.40)
            self.assertEqual(result["request_status_at_return"], "UNKNOWN")
            self.assertFalse(result["controls_released"])
            self.assertTrue(result["retained_controls"])
            self.assertEqual(result["cleanup_state"], "terminate_started")
            self.assertTrue(result["custody_token"])
            self.assertTrue(result["single_use_consumed"])
            # The custodian owns the controls; after the simulated blocking call returns
            # it can kill, observe empty, and release. The already returned UNKNOWN stays UNKNOWN.
            release_terminate.set()
            gate.set()
            self.assertTrue(req.result_ready.wait(timeout=0.8))
            self.assertEqual(req.status, "DEADLINE_EXCEEDED")
            self.assertTrue(req.job_empty_observed)
            self.assertTrue(req.controls_released)
            self.assertEqual(
                custodian.submit()["admission_status"], "rejected_single_use_consumed"
            )
        finally:
            release_terminate.set()
            gate.set() if "gate" in locals() else None
            custodian.close()

    def test_synchronous_admission_enqueue_stall_defeats_caller_deadline(self):
        custodian = FakePrewarmedCustodian(
            caller_timeout=0.18,
            cleanup_reserve=0.04,
            cleanup_grace=0.35,
        )
        entered = threading.Event()
        release_enqueue = threading.Event()
        original_put = custodian._request_queue.put_nowait

        def blocked_put(item):
            entered.set()
            release_enqueue.wait()
            original_put(item)

        custodian._request_queue.put_nowait = blocked_put
        holder = {}
        caller = threading.Thread(
            target=lambda: holder.setdefault("result", custodian.submit())
        )
        try:
            caller.start()
            self.assertTrue(entered.wait(timeout=0.15))
            time.sleep(0.24)
            self.assertTrue(
                caller.is_alive(),
                "negative probe should show caller beyond its deadline",
            )
            self.assertNotIn("result", holder)
            self.assertTrue(custodian.controls_owned)
            self.assertTrue(custodian.snapshot()["retained_controls"])
        finally:
            release_enqueue.set()
            caller.join(timeout=0.5)
            custodian.close()
        self.assertFalse(caller.is_alive())
        self.assertEqual(holder["result"]["response_status"], "UNKNOWN")
        self.assertGreater(holder["result"]["elapsed_seconds"], 0.18)


if __name__ == "__main__":
    unittest.main()
