import json
import threading
import time
from pathlib import Path

from prototype.g1_warmed_worker_custodian import FakePrewarmedCustodian


def main():
    timeout = 0.18
    custodian = FakePrewarmedCustodian(
        caller_timeout=timeout,
        cleanup_reserve=0.04,
        cleanup_grace=0.35,
    )
    entered = threading.Event()
    release = threading.Event()
    original_put = custodian._request_queue.put_nowait

    def blocked_put(item):
        entered.set()
        release.wait()
        original_put(item)

    custodian._request_queue.put_nowait = blocked_put
    holder = {}
    caller = threading.Thread(target=lambda: holder.setdefault("result", custodian.submit()))
    caller.start()
    if not entered.wait(timeout=0.5):
        raise RuntimeError("probe failed to enter injected synchronous admission stall")
    req = custodian._active
    if req is None:
        raise RuntimeError("request was not registered before injected admission stall")
    time.sleep(timeout + 0.06)
    late_observation_seconds = time.monotonic()
    still_blocked_past_deadline = caller.is_alive()
    late_by = late_observation_seconds - req.caller_deadline
    release.set()
    caller.join(timeout=0.5)
    if caller.is_alive():
        raise RuntimeError("probe caller did not return after injected stall was released")
    result = holder["result"]
    record = {
        "probe": "injected_synchronous_admission_enqueue_stall",
        "model": "inert Python fake; no Win32 process, Job, service, provider, or credentials",
        "caller_timeout_seconds": timeout,
        "observed_after_deadline_seconds": round(late_by, 6),
        "caller_still_blocked_after_deadline": still_blocked_past_deadline,
        "response_after_stall_released": result["response_status"],
        "caller_elapsed_seconds_after_submit_started": round(result["elapsed_seconds"], 6),
        "controls_owned": result["controls_owned_at_admission"],
        "retained_controls_at_response": result["retained_controls"],
        "custody_token": result["custody_token"],
        "interpretation": "FAIL_CLOSED_COUNTEREXAMPLE: synchronous admission call has no outer return-deadline enforcement",
    }
    if not still_blocked_past_deadline or late_by <= 0 or result["response_status"] != "UNKNOWN":
        raise AssertionError(record)
    out = Path("evidence/prototype/admission-enqueue-negative.json")
    out.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2, sort_keys=True))
    custodian.close()


if __name__ == "__main__":
    main()
