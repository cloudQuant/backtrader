"""Inert state-machine model for a prewarmed Job + independent custodian.

This is not a Win32 backend and proves no Windows API timing or process semantics.
"""

from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass, field

SETUP_STAGES = ("create_process", "pipe", "token", "receipt", "join")


@dataclass
class Request:
    caller_deadline: float
    work_deadline: float
    cleanup_deadline: float
    block_stage: str | None = None
    stage_gate: threading.Event | None = None
    stage_entered: threading.Event = field(default_factory=threading.Event)
    result_ready: threading.Event = field(default_factory=threading.Event)
    work_done: threading.Event = field(default_factory=threading.Event)
    status: str = "accepted"
    cleanup_state: str = "not_started"
    exit_code: int | None = None
    exit_observed: bool = False
    job_empty_observed: bool = False
    controls_released: bool = False
    retained_controls: bool = True
    stage_membership: dict[str, tuple[str, ...]] = field(default_factory=dict)
    response_status: str | None = None


class FakeJob:
    """Fake Job membership and cancellation; no OS process is created."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.members = set()
        self.kill_requested = threading.Event()
        self.terminate_entered = threading.Event()
        self.terminate_gate: threading.Event | None = None
        self.terminated = False
        self.empty_observed = False

    def add(self, member: str) -> None:
        with self._lock:
            self.members.add(member)

    def remove(self, member: str) -> None:
        with self._lock:
            self.members.discard(member)

    def snapshot(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self.members))

    def terminate_job(self) -> None:
        self.terminate_entered.set()
        gate = self.terminate_gate
        if gate is not None:
            gate.wait()
        self.kill_requested.set()
        self.terminated = True


class FakePrewarmedCustodian:
    """Separate logical custodian actor with a persistent monitor thread."""

    def __init__(
        self,
        *,
        worker_ready: bool = True,
        controls_owned: bool = True,
        caller_timeout: float = 0.35,
        cleanup_reserve: float = 0.10,
        cleanup_grace: float = 0.5,
        block_terminate: bool = False,
    ) -> None:
        self.job = FakeJob()
        self.controls_owned = controls_owned
        self.control_names = (
            "job_handle",
            "worker_process_handle",
            "worker_thread_handle",
        )
        self.worker_ready = False
        self._stop = threading.Event()
        self._request_queue: queue.Queue[Request | None] = queue.Queue(maxsize=1)
        self._active_lock = threading.Lock()
        self._active: Request | None = None
        self._consumed = False
        self._admission_status = "not_ready"
        self._caller_timeout = caller_timeout
        self._cleanup_reserve = cleanup_reserve
        self._cleanup_grace = cleanup_grace
        self._worker: threading.Thread | None = None
        self._custodian: threading.Thread | None = None
        if block_terminate:
            self.job.terminate_gate = threading.Event()
        # Handle ownership is established before worker warming/admission.
        if controls_owned:
            self.job.add("worker")
        if worker_ready and controls_owned:
            self._worker = threading.Thread(
                target=self._worker_loop, name="fake-job-worker", daemon=True
            )
            self._worker.start()
            # Readiness is published by the running worker, never inferred from thread.start().
            deadline = time.monotonic() + 1.0
            while not self.worker_ready and time.monotonic() < deadline:
                time.sleep(0.001)
        self._custodian = threading.Thread(
            target=self._custodian_loop, name="fake-independent-custodian", daemon=True
        )
        self._custodian.start()

    def _worker_loop(self) -> None:
        self.worker_ready = True
        while not self._stop.is_set():
            try:
                req = self._request_queue.get(timeout=0.01)
            except queue.Empty:
                continue
            if req is None:
                return
            self._run_request(req)
            return  # the warmed execution session is single-use

    def _run_request(self, req: Request) -> None:
        child_present = False
        exit_code = 0
        try:
            for stage in SETUP_STAGES:
                if self.job.kill_requested.is_set():
                    raise RuntimeError("fake_job_terminated")
                members = self.job.snapshot()
                if "worker" not in members:
                    raise AssertionError(
                        "request work ran outside preowned Job membership"
                    )
                if stage != "create_process" and not child_present:
                    raise AssertionError(
                        "fake child must be in Job before downstream setup"
                    )
                if stage == "create_process":
                    # This models a synchronous CreateProcess call made by the in-Job worker.
                    # A blocked call has not returned a child handle yet; the custodian still
                    # has the worker's Job/process/thread controls.
                    pass
                else:
                    self.job.add("provider-child")
                    child_present = True
                req.stage_membership[stage] = self.job.snapshot()
                if stage == req.block_stage:
                    req.status = (
                        "worker_setup_blocked" if stage != "join" else "join_blocked"
                    )
                    req.stage_entered.set()
                    gate = req.stage_gate or threading.Event()
                    while not gate.wait(0.002):
                        if self.job.kill_requested.is_set():
                            raise RuntimeError("fake_job_terminated")
                if stage == "create_process":
                    if self.job.kill_requested.is_set():
                        raise RuntimeError("fake_job_terminated")
                    self.job.add("provider-child")
                    child_present = True
            if self.job.kill_requested.is_set():
                raise RuntimeError("fake_job_terminated")
        except RuntimeError as exc:
            if str(exc) == "fake_job_terminated":
                exit_code = -9
            else:
                exit_code = -1
        finally:
            self.job.remove("provider-child")
            self.job.remove("worker")
            req.exit_code = exit_code
            req.exit_observed = True
            req.work_done.set()

    def _custodian_loop(self) -> None:
        while not self._stop.is_set():
            with self._active_lock:
                req = self._active
            if req is None or req.result_ready.is_set():
                time.sleep(0.002)
                continue
            now = time.monotonic()
            if req.work_done.is_set():
                self._finalize(req, status="SUCCEEDED")
                continue
            if now < req.work_deadline:
                time.sleep(min(0.002, req.work_deadline - now))
                continue
            req.cleanup_state = "terminate_started"
            self.job.terminate_job()
            req.cleanup_state = "termination_requested"
            worker = self._worker
            remaining = max(0.0, req.cleanup_deadline - time.monotonic())
            if worker is not None:
                worker.join(timeout=remaining)
            members = self.job.snapshot()
            if req.exit_observed and not members:
                self.job.empty_observed = True
                req.job_empty_observed = True
                req.exit_code = -9
                req.controls_released = True
                req.retained_controls = False
                req.cleanup_state = "released_after_empty"
                req.status = "DEADLINE_EXCEEDED"
                req.result_ready.set()
            else:
                req.cleanup_state = "unknown_retained"
                req.status = "UNKNOWN"
                req.retained_controls = True
                req.result_ready.set()

    def _finalize(self, req: Request, *, status: str) -> None:
        if req.result_ready.is_set():
            return
        members = self.job.snapshot()
        if req.exit_observed and not members:
            self.job.empty_observed = True
            req.job_empty_observed = True
            req.controls_released = True
            req.retained_controls = False
            req.cleanup_state = "released_after_empty"
            req.status = status
        else:
            req.cleanup_state = "unknown_retained"
            req.status = "UNKNOWN"
            req.retained_controls = True
        req.result_ready.set()

    def submit(
        self,
        *,
        block_stage: str | None = None,
        stage_gate: threading.Event | None = None,
    ) -> dict:
        # Rejection is immediate if either precondition is absent.
        if not self.controls_owned:
            self._admission_status = "rejected_no_preowned_controls"
            return self.snapshot()
        if not self.worker_ready:
            self._admission_status = "rejected_worker_not_ready"
            return self.snapshot()
        if self._consumed:
            self._admission_status = "rejected_single_use_consumed"
            return self.snapshot()
        self._consumed = True
        started = time.monotonic()
        caller_deadline = started + self._caller_timeout
        req = Request(
            caller_deadline=caller_deadline,
            work_deadline=caller_deadline - self._cleanup_reserve,
            cleanup_deadline=caller_deadline + self._cleanup_grace,
            block_stage=block_stage,
            stage_gate=stage_gate,
        )
        with self._active_lock:
            self._active = req
        self._admission_status = "accepted"
        try:
            self._request_queue.put_nowait(req)
        except queue.Full:
            self._admission_status = "rejected_queue_full"
            return self.snapshot()
        signaled = req.result_ready.wait(
            timeout=max(0.0, caller_deadline - time.monotonic())
        )
        elapsed = time.monotonic() - started
        if signaled:
            response_status = req.status
        else:
            response_status = "UNKNOWN"
        req.response_status = response_status
        return {
            "admission_status": self._admission_status,
            "response_status": response_status,
            "elapsed_seconds": elapsed,
            "caller_deadline_seconds": self._caller_timeout,
            "worker_ready_at_admission": self.worker_ready,
            "controls_owned_at_admission": self.controls_owned,
            "single_use_consumed": self._consumed,
            "custody_token": "fake-custody-token-1" if self.controls_owned else None,
            "exit_code": req.exit_code,
            "exit_observed": req.exit_observed,
            "job_empty_observed": req.job_empty_observed,
            "job_members": self.job.snapshot(),
            "controls_released": req.controls_released,
            "retained_controls": req.retained_controls,
            "cleanup_state": req.cleanup_state,
            "stage_membership": dict(req.stage_membership),
            "request_status_at_return": req.status if signaled else "UNKNOWN",
        }

    def snapshot(self) -> dict:
        with self._active_lock:
            req = self._active
        return {
            "admission_status": self._admission_status,
            "worker_ready": self.worker_ready,
            "controls_owned": self.controls_owned,
            "custody_token": "fake-custody-token-1" if self.controls_owned else None,
            "single_use_consumed": self._consumed,
            "cleanup_state": req.cleanup_state if req else "not_started",
            "job_members": self.job.snapshot(),
            "controls_released": req.controls_released if req else False,
            "retained_controls": req.retained_controls if req else self.controls_owned,
        }

    def close(self) -> None:
        self._stop.set()
        try:
            self._request_queue.put_nowait(None)
        except queue.Full:
            pass
        if self._worker is not None:
            self._worker.join(timeout=1.0)
        if self._custodian is not None:
            self._custodian.join(timeout=1.0)
