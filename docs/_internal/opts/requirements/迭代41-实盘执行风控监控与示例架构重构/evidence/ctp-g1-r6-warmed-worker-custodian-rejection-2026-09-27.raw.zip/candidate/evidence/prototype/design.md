# G1 r6 fake architecture prototype

This is a deterministic Python state-machine model only. It creates no OS process, Windows Job, pipe, token, receipt, native SDK, CTP connection, credential access, or provider request. It is not a Windows implementation or an acceptance result.

## Proposed boundary

- A fake custodian owns the Job/process/thread control tuple before admission.
- The execution worker is started and publishes readiness before admission.
- Admission immediately rejects if readiness or preowned controls are missing; each warmed worker/session is single-use.
- A request caller only enqueues a request and waits until its absolute deadline.
- The already-running in-Job worker performs the synchronous CreateProcess/pipe/token/receipt/Join stages.
- A separate persistent custodian monitor starts termination at an earlier work deadline, leaving a cleanup reserve before the caller deadline.
- Exact DEADLINE_EXCEEDED is returned only after the fake worker exit is observed, fake Job membership is empty, and controls are released.
- A blocked custodian termination causes the caller to return UNKNOWN by its deadline while its custody token/controls remain retained. A later exact cleanup does not rewrite the caller's returned UNKNOWN.

## Hard limitations / rejection

The prototype models OS termination cooperatively with Python Events. It does not force-kill a Python thread and cannot establish Windows Job semantics, hard API return bounds, host isolation, handle transfer, or a real independent service. The worker and custodian are distinct threads in one process. It therefore demonstrates a fail-closed state machine and concrete negative cases, not a concrete backend. An injected synchronous enqueue stall leaves the request caller blocked past its deadline; the caller has no outer wrapper around that admission call. An unbounded blocking Win32 call in the custodian can also prevent exact empty/release evidence, although the caller returns UNKNOWN in the fake termination-stall case. G1 remains closed until a Windows-specific implementation and independent review prove the actual process/Job/handle path and every synchronous caller/custodian call boundary.

## Inert fake cases

- prewarm incomplete: rejected immediately; no request is admitted.
- controls absent: rejected immediately.
- worker CreateProcess/pipe/token/receipt/Join blocked: custodian termination returns in the fake, caller returns by deadline with DEADLINE_EXCEEDED, observed exit, empty Job, and released controls.
- custodian termination itself blocked: caller returns by deadline with UNKNOWN, retained controls and custody token; session is never reusable. Fake cleanup can finish later after the blocked call is released.
- injected synchronous admission enqueue stall: caller remains blocked beyond its deadline, a direct counterexample to claiming a hard caller-return bound for this in-process admission path.
