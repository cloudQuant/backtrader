import hashlib
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1]).resolve()
copy_root = pathlib.Path(sys.argv[2]).resolve()
manifest_rel = pathlib.Path('evidence/prototype/candidate-manifest-r6.json')
receipt_rel = pathlib.Path('evidence/prototype/freeze-receipt-r6.json')
expected_manifest = '3053ce67aea77fa7b1486837adbdd20d4de86343182e687d4c511ebcec1380e7'
expected_receipt = '646e4817126272f263f3681ffeb6c994497f633a255daf72196e41187f6ea017'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

manifest_path = root / manifest_rel
receipt_path = root / receipt_rel
manifest_hash = digest(manifest_path)
receipt_hash = digest(receipt_path)
assert manifest_hash == expected_manifest, (manifest_hash, expected_manifest)
assert receipt_hash == expected_receipt, (receipt_hash, expected_receipt)
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
assert receipt['manifest']['sha256'] == manifest_hash
assert receipt['manifest']['path'] == manifest_rel.as_posix()
payloads = manifest['source_and_test_payloads'] + manifest['evidence_payloads']
assert len(manifest['source_and_test_payloads']) == 6
assert len(manifest['evidence_payloads']) == 12
assert len(payloads) == 18
assert len({item['path'] for item in payloads}) == 18
results = []
for entry in payloads:
    rel = pathlib.PurePosixPath(entry['path'])
    assert not rel.is_absolute() and '..' not in rel.parts, entry['path']
    candidate_path = root.joinpath(*rel.parts)
    actual_hash = digest(candidate_path)
    actual_size = candidate_path.stat().st_size
    matches = actual_hash == entry['sha256'] and actual_size == entry['size_bytes']
    results.append({
        'path': entry['path'], 'expected_sha256': entry['sha256'],
        'actual_sha256': actual_hash, 'expected_size_bytes': entry['size_bytes'],
        'actual_size_bytes': actual_size, 'matches': matches,
    })
    assert matches, results[-1]
    copy_path = copy_root.joinpath(*rel.parts)
    if entry in manifest['source_and_test_payloads']:
        copy_matches = digest(copy_path) == entry['sha256'] and copy_path.stat().st_size == entry['size_bytes']
        results[-1]['independent_copy_matches'] = copy_matches
        assert copy_matches, results[-1]
base_path = root / 'candidate-manifest-r4.json'
base_hash = digest(base_path)
assert base_hash == manifest['base_manifest']['sha256']
base = json.loads(base_path.read_text(encoding='utf-8'))
base_results = []
for entry in base['candidate_files']:
    path_parts = pathlib.PureWindowsPath(entry['path']).parts
    root_name = 'iteration41-g1-outer-host-deadline-candidate-r4-20260927'
    idx = path_parts.index(root_name)
    rel = pathlib.PureWindowsPath(*path_parts[idx + 1:])
    local_path = root.joinpath(*rel.parts)
    actual_hash = digest(local_path)
    actual_size = local_path.stat().st_size
    assert actual_hash == entry['sha256'] and actual_size == entry['size'], entry
    base_results.append({'path': rel.as_posix(), 'sha256': actual_hash, 'size_bytes': actual_size, 'matches': True})
assert manifest['inherited_r4_files_unchanged'] is True
assert manifest['execution_scope']['fake_only'] is True
assert manifest['execution_scope']['real_win32'] is False
assert manifest['execution_scope']['real_job_object'] is False
assert manifest['acceptance_claim'] is False
assert receipt['boundaries']['g1_acceptance'] is False
out = {
    'candidate_root': str(root), 'manifest_path': str(manifest_path), 'manifest_sha256': manifest_hash,
    'receipt_path': str(receipt_path), 'receipt_sha256': receipt_hash,
    'payload_count': len(payloads), 'source_and_test_count': len(manifest['source_and_test_payloads']),
    'evidence_count': len(manifest['evidence_payloads']), 'payloads': results,
    'base_manifest_sha256': base_hash, 'base_candidate_files': base_results,
    'candidate_decision': manifest['decision'], 'receipt_decision': receipt['decision'],
    'fake_only_no_acceptance_claim': True,
}
print(json.dumps(out, indent=2, sort_keys=True))
