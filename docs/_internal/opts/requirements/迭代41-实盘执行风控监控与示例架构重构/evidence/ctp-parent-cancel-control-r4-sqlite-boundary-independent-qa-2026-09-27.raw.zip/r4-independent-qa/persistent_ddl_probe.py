from __future__ import annotations
from contextlib import closing
import importlib.util,json,pathlib,sqlite3,subprocess,sys
qa=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927')
copy=qa/'payload-copy'
sys.path.insert(0,str(copy))
spec=importlib.util.spec_from_file_location('r4_frozen_test_module',copy/'tests'/'test_cancellation_dispatch_resolution_control.py')
if spec is None or spec.loader is None: raise SystemExit('cannot load frozen test module')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
root=qa/'ddl-bypass-state'
if root.exists(): raise SystemExit(f'refusing to overwrite {root}')
root.mkdir()
f=mod._Fixture(root)
event_id='cancel-freeze-release:'+f.command.command_id
db=f.runtime.state_directory/'monitor.sqlite3'
release=mod._release(f)
audit=f.control.audit.get_command(f.command.command_id)
pre={'released':release.released,'audit_status':audit.status.value,'released_at':audit.released_at,'unknown_lock_active':f.unknown_cause in f.active(),'progress_lock_active':f.progress_cause in f.active(),'provider':f.runtime.scope.provider,'environment':f.runtime.scope.environment}
script=r'''import json,sqlite3,sys
c=sqlite3.connect(sys.argv[1],timeout=4.0,isolation_level=None)
try:
 c.execute("BEGIN IMMEDIATE")
 c.execute("DROP TRIGGER trg_cancel_release_prepared_immutable_delete")
 c.execute("DROP TRIGGER trg_cancel_release_prepared_immutable_update")
 c.execute("DELETE FROM monitor_outbox_events WHERE event_id=?",(sys.argv[2],))
 c.execute("COMMIT")
 print(json.dumps({"outcome":"DROPPED_TRIGGERS_AND_DELETED"}))
except Exception:
 if c.in_transaction: c.execute("ROLLBACK")
 raise
finally: c.close()
'''
p=subprocess.run([sys.executable,'-I','-S','-B','-c',script,str(db),event_id],capture_output=True,text=True,timeout=8)
if p.returncode!=0: raise SystemExit(f'DDL child failed: {p.stderr}')
child=json.loads(p.stdout.strip())
f.close()
with closing(sqlite3.connect(db,timeout=3)) as c:
 quick=c.execute('PRAGMA quick_check').fetchone()[0]
 event=c.execute('SELECT 1 FROM monitor_outbox_events WHERE event_id=?',(event_id,)).fetchone()
 triggers=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='monitor_outbox_events' ORDER BY name")]
with closing(sqlite3.connect(root/'control'/'cancellation_operator_control.sqlite3',timeout=3)) as c:
 control=c.execute('SELECT status,released_at FROM cancellation_control_commands WHERE command_id=?',(f.command.command_id,)).fetchone()
with closing(sqlite3.connect(root/'state'/'risk.sqlite3',timeout=3)) as c:
 locks=c.execute('SELECT cause_id,active FROM risk_freezes WHERE cause_id IN (?,?)',(f.unknown_cause,f.progress_cause)).fetchall()
result={'schema':'iteration41_cancel_control_r4_ddl_bypass_state.v1','pre_bypass':pre,'child':child,'monitor_event_present_after':event is not None,'remaining_monitor_triggers':triggers,'monitor_quick_check':quick,'control_row_after_close':control,'risk_freeze_rows_after_close':locks,'files':[{'path':p.relative_to(root).as_posix(),'size':p.stat().st_size} for p in sorted(root.rglob('*')) if p.is_file()]}
(root/'ddl-bypass-state.json').write_text(json.dumps(result,indent=2,default=str)+'\n',encoding='utf-8')
(qa/'ddl-bypass-state.json').write_text(json.dumps(result,indent=2,default=str)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2,default=str))
