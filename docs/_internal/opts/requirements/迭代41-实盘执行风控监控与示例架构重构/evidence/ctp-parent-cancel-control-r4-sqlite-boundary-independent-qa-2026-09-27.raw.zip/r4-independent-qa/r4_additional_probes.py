from __future__ import annotations
import hashlib
import importlib.util
import json
import os
import pathlib
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import traceback

from contextlib import closing

import psutil

qa = pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927')
copy_root = qa / 'payload-copy'
sys.path.insert(0, str(copy_root))
test_path = copy_root / 'tests' / 'test_cancellation_dispatch_resolution_control.py'
spec = importlib.util.spec_from_file_location('r4_frozen_test_module', test_path)
if spec is None or spec.loader is None:
    raise SystemExit('cannot load frozen test module')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

results = {'schema':'iteration41_cancel_control_r4_independent_negative_probes.v1','probes':{},'real_ctp_imported':False,'provider_or_network_calls':0}
def audit_and_latches(f):
    audit = f.control.audit.get_command(f.command.command_id)
    return {'audit_status': audit.status.value if audit else None,
            'released_at': audit.released_at if audit else None,
            'unknown_lock_active': f.unknown_cause in f.active(),
            'progress_lock_active': f.progress_cause in f.active()}
def monitor_row(db, event_id):
    with closing(sqlite3.connect(db, timeout=2.0)) as c:
        row=c.execute('SELECT event_type, data_json FROM monitor_outbox_events WHERE event_id=?',(event_id,)).fetchone()
        return row

def child_delete(db, event_id, ready=None):
    script=r'''import json,sqlite3,sys
p,e=sys.argv[1],sys.argv[2]
ready=sys.argv[3] if len(sys.argv)>3 else None
c=sqlite3.connect(p,timeout=5.0,isolation_level=None)
if ready:
 from pathlib import Path
 Path(ready).write_text("ready",encoding="utf-8")
try:
 c.execute("DELETE FROM monitor_outbox_events WHERE event_id=?",(e,))
 print(json.dumps({"outcome":"DELETED"}))
except sqlite3.IntegrityError as x:
 print(json.dumps({"outcome":"BLOCKED","kind":"IntegrityError","message":str(x)}))
except sqlite3.OperationalError as x:
 print(json.dumps({"outcome":"BLOCKED","kind":"OperationalError","message":str(x)}))
finally:
 c.close()
'''
    argv=[sys.executable,'-I','-S','-B','-c',script,str(db),event_id]
    if ready: argv.append(str(ready))
    p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    return p

def parsed_child(p, timeout=8):
    out,err=p.communicate(timeout=timeout)
    if p.returncode != 0 or err.strip(): raise RuntimeError(f'child rc={p.returncode} stderr={err} stdout={out}')
    return json.loads(out.strip())

# Probe 1: cross-process DELETE contends while the guard's BEGIN IMMEDIATE is live,
# then is rejected by the committed immutable trigger; after-commit DELETE is rejected too.
with tempfile.TemporaryDirectory(prefix='r4-cross-delete-',dir=qa) as tmp:
    root=pathlib.Path(tmp); f=mod._Fixture(root); child=None; marker=root/'delete-ready'
    event_id='cancel-freeze-release:'+f.command.command_id
    db=f.runtime.state_directory/'monitor.sqlite3'; original=f.runtime.risk_gate.resolve_freeze
    observed={}
    def gate(scope,cause):
        if cause == f.progress_cause:
            child=child_delete(db,event_id,marker)
            observed['child_started']=True
            end=time.monotonic()+4
            while not marker.exists() and time.monotonic()<end: time.sleep(.01)
            if not marker.exists(): raise RuntimeError('competing process did not reach DELETE')
            time.sleep(.2)
            observed['child_still_blocked_before_risk_clear_return']=child.poll() is None
            if not observed['child_still_blocked_before_risk_clear_return']:
                raise RuntimeError('competing DELETE completed before final lock cleared')
            observed['child']=child
        return original(scope,cause)
    f.runtime.risk_gate.resolve_freeze=gate
    try:
        released=mod._release(f)
        proc=observed['child']; during=parsed_child(proc)
        after_proc=child_delete(db,event_id); after=parsed_child(after_proc)
        status=audit_and_latches(f)
        row=monitor_row(db,event_id)
        assert released.released and during['outcome']=='BLOCKED' and 'immutable' in during['message'].lower()
        assert after['outcome']=='BLOCKED' and 'immutable' in after['message'].lower()
        assert status['audit_status']=='released' and not status['unknown_lock_active'] and not status['progress_lock_active']
        assert row is not None and row[0]=='cancellation_freeze_release_prepared'
        results['probes']['cross_process_ordinary_delete']={**{k:v for k,v in observed.items() if k!='child'},'while_guard_active_result_after_commit':during,'after_commit_result':after,'release':status,'event_still_present':True}
    finally:
        if observed.get('child') and observed['child'].poll() is None:
            observed['child'].kill(); observed['child'].communicate(timeout=5)
        f.close()

# Probe 2: same-user process with direct DB write/DDL access can remove the triggers and row.
with tempfile.TemporaryDirectory(prefix='r4-ddl-bypass-',dir=qa) as tmp:
    root=pathlib.Path(tmp); f=mod._Fixture(root)
    try:
        released=mod._release(f); event_id='cancel-freeze-release:'+f.command.command_id
        db=f.runtime.state_directory/'monitor.sqlite3'
        ddl=r'''import json,sqlite3,sys
c=sqlite3.connect(sys.argv[1],timeout=4.0,isolation_level=None)
try:
 c.execute("BEGIN IMMEDIATE")
 c.execute("DROP TRIGGER trg_cancel_release_prepared_immutable_delete")
 c.execute("DROP TRIGGER trg_cancel_release_prepared_immutable_update")
 c.execute("DELETE FROM monitor_outbox_events WHERE event_id=?",(sys.argv[2],))
 c.execute("COMMIT")
 print(json.dumps({"outcome":"DROPPED_TRIGGERS_AND_DELETED"}))
except Exception:
 if c.in_transaction: c.execute("ROLLBACK")
 raise
finally: c.close()
'''
        p=subprocess.run([sys.executable,'-I','-S','-B','-c',ddl,str(db),event_id],capture_output=True,text=True,timeout=8)
        if p.returncode!=0: raise RuntimeError(f'DDL child rc={p.returncode}: {p.stderr}')
        action=json.loads(p.stdout.strip()); status=audit_and_latches(f); row=monitor_row(db,event_id)
        with closing(sqlite3.connect(db)) as c: triggers=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='monitor_outbox_events'")]
        assert released.released and action['outcome']=='DROPPED_TRIGGERS_AND_DELETED' and row is None
        assert status['audit_status']=='released' and not status['unknown_lock_active'] and not status['progress_lock_active']
        assert not triggers
        results['probes']['same_user_postcommit_ddl_bypass']={'child':action,'event_present_after':False,'release':status,'remaining_monitor_triggers':triggers,'authority_scope':{'provider':f.runtime.scope.provider,'environment':f.runtime.scope.environment,'account_id':f.runtime.scope.account_key}}
    finally: f.close()

# Probe 3: normal and exceptional readback both close the explicit connection;
# psutil sees no leaked monitor handle and Windows permits full state directory removal.
def open_monitor_handles(db):
    target=os.path.normcase(os.path.realpath(db))
    return [x.path for x in psutil.Process().open_files() if os.path.normcase(os.path.realpath(x.path))==target]
def readback_close_case(label, fail):
    root=pathlib.Path(tempfile.mkdtemp(prefix='r4-readback-'+label+'-',dir=qa)); f=mod._Fixture(root)
    path=f.runtime.state_directory/'monitor.sqlite3'; opened=[]; real_connect=sqlite3.connect; closed_fixture=False
    try:
        assert mod._release(f).released
        audit=f.control.audit.get_command(f.command.command_id)
        evidence=f.control.audit.get_reconciliation(f.command.evidence_id)
        stored=f.control.audit.get_cancel_dispatch_proof(f.command.command_id)
        proof=mod.cancellation_control_module._restore_cancel_dispatch_proof(stored[0],stored[1],f.runtime.fake_dispatch_authority)
        baseline=len(open_monitor_handles(path))
        class Proxy:
            def __init__(self,c): self.c=c; self.closed=False; self.failed=False
            def execute(self,*a,**kw):
                if fail and not self.failed:
                    self.failed=True
                    raise sqlite3.OperationalError('synthetic readback query failure')
                return self.c.execute(*a,**kw)
            def close(self): self.closed=True; self.c.close()
        def tracked(*a,**kw):
            proxy=Proxy(real_connect(*a,**kw)); opened.append(proxy); return proxy
        mod.cancellation_control_module.sqlite3.connect=tracked
        if fail:
            try:
                f.control._verify_release_prepared_monitor_fact(f.command,evidence,proof,audit.release_applied_at)
            except mod.RuntimePluginError as e:
                error_code=e.code
            else: raise AssertionError('expected synthetic readback failure')
        else:
            f.control._verify_release_prepared_monitor_fact(f.command,evidence,proof,audit.release_applied_at)
            error_code=None
        mod.cancellation_control_module.sqlite3.connect=real_connect
        assert len(opened)==1 and opened[0].closed
        try: opened[0].execute('SELECT 1')
        except sqlite3.ProgrammingError: closed_sql_api=True
        else: closed_sql_api=False
        after=len(open_monitor_handles(path))
        assert closed_sql_api and after==baseline
        f.close(); closed_fixture=True
        handles_after_fixture_close=open_monitor_handles(path)
        if handles_after_fixture_close: raise AssertionError(f'open monitor file handles after runtime close: {handles_after_fixture_close}')
        shutil.rmtree(root)
        assert not root.exists()
        return {'case':label,'injected_query_failure':fail,'raised_code':error_code,'connection_explicitly_closed':opened[0].closed,'closed_connection_rejects_execute':closed_sql_api,'monitor_handles_before':baseline,'monitor_handles_after_readback':after,'monitor_handles_after_runtime_close':len(handles_after_fixture_close),'state_directory_removed':not root.exists()}
    finally:
        mod.cancellation_control_module.sqlite3.connect=real_connect
        if not closed_fixture:
            try: f.close()
            except Exception: pass
        if root.exists():
            try: shutil.rmtree(root)
            except Exception: pass
results['probes']['readback_connection_lifetime']={'normal':readback_close_case('normal',False),'exception':readback_close_case('exception',True),'psutil_version':psutil.__version__}

# Probe 4: terminate the worker after the risk final-latch transaction committed,
# before the outer monitor BEGIN IMMEDIATE context issues COMMIT.
crash_root=qa/'crash-cut-state'; crash_root.mkdir(exist_ok=False)
marker=qa/'crash-cut-marker.json'; worker=qa/'crash_cut_worker.py'
p=subprocess.Popen([sys.executable,'-B',str(worker),str(copy_root),str(crash_root),str(marker)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
end=time.monotonic()+20
while not marker.exists() and p.poll() is None and time.monotonic()<end: time.sleep(.02)
if not marker.exists():
    p.kill(); out,err=p.communicate(timeout=5); raise RuntimeError(f'crash worker missed cutpoint rc={p.returncode} out={out} err={err}')
info=json.loads(marker.read_text(encoding='utf-8'))
time.sleep(.1)
p.kill(); out,err=p.communicate(timeout=5)
if p.poll() is None: raise RuntimeError('worker process remained alive after TerminateProcess')
# New OS-level SQLite connections reopen the files after actual process death.
control_db=pathlib.Path(info['control_db']); monitor_db=pathlib.Path(info['monitor_db']); risk_db=pathlib.Path(info['risk_db'])
with closing(sqlite3.connect(control_db,timeout=3)) as c:
    control_row=c.execute('SELECT status,release_applied_at,released_at FROM cancellation_control_commands WHERE command_id=?',(info['command_id'],)).fetchone()
with closing(sqlite3.connect(risk_db,timeout=3)) as c:
    quick_risk=c.execute('PRAGMA quick_check').fetchone()[0]
    lock_rows=c.execute('SELECT cause_id,active FROM risk_freezes WHERE cause_id IN (?,?)',(info['unknown_cause'],info['progress_cause'])).fetchall()
with closing(sqlite3.connect(monitor_db,timeout=3)) as c:
    quick_monitor=c.execute('PRAGMA quick_check').fetchone()[0]
    event=c.execute('SELECT event_id,event_type,data_json FROM monitor_outbox_events WHERE event_id=?',(info['event_id'],)).fetchone()
    triggers=c.execute("SELECT name,sql FROM sqlite_master WHERE type='trigger' AND tbl_name='monitor_outbox_events' ORDER BY name").fetchall()
postkill=child_delete(monitor_db,info['event_id']); postkill_delete=parsed_child(postkill)
assert control_row and control_row[0]=='released' and control_row[1] is not None and control_row[2] is not None
assert set((x[0],int(x[1])) for x in lock_rows)=={(info['unknown_cause'],0),(info['progress_cause'],0)}
assert quick_risk=='ok' and quick_monitor=='ok'
assert event and event[1]=='cancellation_freeze_release_prepared'
assert {x[0] for x in triggers}=={'trg_cancel_release_prepared_immutable_delete','trg_cancel_release_prepared_immutable_update'}
assert postkill_delete['outcome']=='BLOCKED' and 'immutable' in postkill_delete['message'].lower()
results['probes']['process_death_after_risk_commit_before_monitor_commit']={'marker':info,'worker_exit_code_after_terminate':p.returncode,'worker_stdout':out,'worker_stderr':err,'control_command_row':control_row,'risk_freeze_rows':lock_rows,'monitor_event_present_after_reopen':True,'trigger_names_after_reopen':[x[0] for x in triggers],'risk_quick_check':quick_risk,'monitor_quick_check':quick_monitor,'ordinary_delete_after_worker_death':postkill_delete,'interpretation':'Risk final latch clear and RELEASED audit were committed; killed read-only BEGIN IMMEDIATE guard left the previously committed event and triggers intact. No monitor event was missing at this cutpoint.'}
(qa/'extra-probes.json').write_text(json.dumps(results,indent=2,default=str)+'\n',encoding='utf-8')
lines=['R4 independent extra negative probes','20-test focused suite was run separately and is logged in focused-tests-independent.log.','']
for k,v in results['probes'].items(): lines.append(k+': '+json.dumps(v,sort_keys=True,default=str))
(qa/'extra-probes.log').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2,default=str))
