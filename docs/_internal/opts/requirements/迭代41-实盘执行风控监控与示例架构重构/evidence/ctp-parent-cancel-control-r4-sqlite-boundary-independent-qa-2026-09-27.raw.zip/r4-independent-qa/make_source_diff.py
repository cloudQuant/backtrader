import difflib,pathlib
r3=pathlib.Path(r'D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927')
r4=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927\payload-copy')
out=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927\r3-r4-source.diff')
files=['bt_api_py/runtime_plugins/cancellation_control.py','tests/test_cancellation_dispatch_resolution_control.py']
lines=[]
for rel in files:
    a=(r3/rel).read_text(encoding='utf-8').splitlines(keepends=True)
    b=(r4/rel).read_text(encoding='utf-8').splitlines(keepends=True)
    lines.extend(difflib.unified_diff(a,b,fromfile='r3/'+rel,tofile='r4/'+rel))
out.write_text(''.join(lines),encoding='utf-8')
print(f'files={len(files)} diff_bytes={out.stat().st_size}')
