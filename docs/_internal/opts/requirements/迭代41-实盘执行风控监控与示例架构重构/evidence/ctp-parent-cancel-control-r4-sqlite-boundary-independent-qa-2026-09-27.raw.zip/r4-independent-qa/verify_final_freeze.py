from __future__ import annotations
import hashlib,json,pathlib
roots={'r4':pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-freeze-r1-20260927'),'r3':pathlib.Path(r'D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927'),'copy':pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927\payload-copy')}
expected={'r4':'60b020202ed89169e24afca30b1b1b16680151a11c6f52c518d0f5bbfa7fab0d','r3':'65af6f048a1148182b35a18b8998f738a306d83b5d33352bd469c809c3a8d28f'}
def H(b):return hashlib.sha256(b).hexdigest()
def load(root):
 b=(root/'payload-manifest.json').read_bytes(); entries=json.loads(b); return H(b),{x['path'].replace('\\','/'):x for x in entries}
loaded={k:load(v) for k,v in roots.items() if k!='copy'}
results={}
for k,(h,entries) in loaded.items():
 if h!=expected[k]:raise SystemExit(f'{k} manifest changed {h}')
 errors=[]
 for rel,e in entries.items():
  p=roots[k].joinpath(*rel.split('/')); b=p.read_bytes() if p.is_file() else b''
  if not p.is_file() or len(b)!=e['size'] or H(b)!=e['sha256'].lower():errors.append(rel)
 actual={p.relative_to(roots[k]).as_posix() for p in roots[k].rglob('*') if p.is_file() and p.name!='payload-manifest.json' and '.ruff_cache' not in p.parts}
 if errors or actual!=set(entries):raise SystemExit(f'{k} final mismatch: errors={errors}, extra={sorted(actual-set(entries))}, missing={sorted(set(entries)-actual)}')
 results[k]={'manifest_sha256':h,'entries':len(entries),'verified':len(entries),'extra_noncache_files':0}
changed=[r for r in sorted(loaded['r4'][1]) if loaded['r4'][1][r]['sha256']!=loaded['r3'][1][r]['sha256'] or loaded['r4'][1][r]['size']!=loaded['r3'][1][r]['size']]
if len(changed)!=2:raise SystemExit(f'changed count {len(changed)}')
copyroot=roots['copy']; copied={p.relative_to(copyroot).as_posix() for p in copyroot.rglob('*') if p.is_file() and p.name!='payload-manifest.json' and '.ruff_cache' not in p.parts}
if copied!=set(loaded['r4'][1]):raise SystemExit('independent copy file-set differs')
for rel,e in loaded['r4'][1].items():
 b=copyroot.joinpath(*rel.split('/')).read_bytes()
 if len(b)!=e['size'] or H(b)!=e['sha256'].lower():raise SystemExit(f'copy changed: {rel}')
report={'schema':'iteration41_cancel_control_r4_final_frozen_input_recheck.v1','roots':results,'changed_r3_to_r4':changed,'copy_files_verified':len(copied),'candidate_modified':False}
pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927\final-freeze-recheck.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
