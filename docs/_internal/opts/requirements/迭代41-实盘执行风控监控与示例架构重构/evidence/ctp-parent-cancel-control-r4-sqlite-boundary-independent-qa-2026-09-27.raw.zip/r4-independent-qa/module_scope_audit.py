import importlib.util,json,pathlib,sys
copy=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927\payload-copy')
sys.path.insert(0,str(copy))
p=copy/'tests'/'test_cancellation_dispatch_resolution_control.py'
spec=importlib.util.spec_from_file_location('r4_frozen_test_module',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
loaded=[]
for name,module in sorted(sys.modules.items()):
    low=name.lower()
    if any(token in low for token in ('thost','traderapi','mdapi','tdapi','bt_api_ctp','ctp_sdk','swsdk')):
        loaded.append({'module':name,'file':getattr(module,'__file__',None)})
report={'test_module_origin':str(p),'execution_origin':str(m.execution.__file__),'risk_origin':str(m.risk.__file__),'monitor_origin':str(m.monitor.__file__),'fake_authority_origin':str(sys.modules['bt_api_py.runtime_plugins.fake_dispatch_authority'].__file__),'native_or_ctp_sdk_name_matches':loaded,'scope':'test module import only; no provider/session/network calls'}
pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927\module-scope-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
