from __future__ import annotations
import hashlib, json, pathlib, shutil, sys
r4=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-freeze-r1-20260927')
r3=pathlib.Path(r'D:\temp\iteration41-cancel-control-r3-freeze-r1-20260927')
qa=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927')
expected_r4='60b020202ed89169e24afca30b1b1b16680151a11c6f52c518d0f5bbfa7fab0d'
expected_r3='65af6f048a1148182b35a18b8998f738a306d83b5d33352bd469c809c3a8d28f'
def sha(b): return hashlib.sha256(b).hexdigest()
def read_entries(root):
    p=root/'payload-manifest.json'; data=p.read_bytes(); entries=json.loads(data)
    result={e['path'].replace('\\','/'):e for e in entries}
    return sha(data), result
h4,e4=read_entries(r4); h3,e3=read_entries(r3)
if h4 != expected_r4: raise SystemExit(f'r4 manifest hash {h4}')
if h3 != expected_r3: raise SystemExit(f'r3 manifest hash {h3}')
def verify(root, entries):
    errors=[]
    for rel,e in entries.items():
        p=root.joinpath(*rel.split('/'))
        if not p.is_file(): errors.append({'path':rel,'error':'missing'}); continue
        data=p.read_bytes()
        if len(data)!=e['size'] or sha(data)!=e['sha256'].lower(): errors.append({'path':rel,'error':'size/hash mismatch'})
    listed=set(entries)
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='payload-manifest.json' and '.ruff_cache' not in p.parts}
    extras=sorted(actual-listed); missing=sorted(listed-actual)
    return errors,extras,missing
err4,extra4,miss4=verify(r4,e4); err3,extra3,miss3=verify(r3,e3)
if err4 or miss4 or err3 or miss3: raise SystemExit(json.dumps({'r4_errors':err4,'r4_missing':miss4,'r3_errors':err3,'r3_missing':miss3},indent=2))
changed=[]
for rel in sorted(set(e4)|set(e3)):
    if rel not in e4 or rel not in e3 or e4[rel]['sha256']!=e3[rel]['sha256'] or e4[rel]['size']!=e3[rel]['size']:
        changed.append({'path':rel,'r3_sha256':e3.get(rel,{}).get('sha256'),'r4_sha256':e4.get(rel,{}).get('sha256'),'r3_size':e3.get(rel,{}).get('size'),'r4_size':e4.get(rel,{}).get('size')})
if set(e3)!=set(e4): raise SystemExit('r3/r4 manifest file set differs')
if len(changed)!=2: raise SystemExit(f'expected two r3->r4 payload changes, found {len(changed)}: {changed}')
copy=qa/'payload-copy'
copy.mkdir()
for rel,e in e4.items():
    src=r4.joinpath(*rel.split('/')); dst=copy.joinpath(*rel.split('/')); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
shutil.copy2(r4/'payload-manifest.json',copy/'payload-manifest.json')
# Verify copied files independently.
ce=[]
for rel,e in e4.items():
    b=copy.joinpath(*rel.split('/')).read_bytes()
    if len(b)!=e['size'] or sha(b)!=e['sha256'].lower(): ce.append(rel)
if ce: raise SystemExit(f'copy hash mismatch: {ce}')
report={'schema':'iteration41_cancel_control_r4_independent_manifest_qa.v1','r4_manifest_sha256':h4,'r4_entries':len(e4),'r4_verified':len(e4)-len(err4),'r4_unlisted_files_excluding_cache':extra4,'r3_manifest_sha256':h3,'r3_entries':len(e3),'r3_verified':len(e3)-len(err3),'r3_unlisted_files_excluding_cache':extra3,'changed_from_r3':changed,'independent_copy_files_verified':len(e4),'candidate_modified':False}
(qa/'manifest-diff-verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(qa/'manifest-diff-verification.log').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
