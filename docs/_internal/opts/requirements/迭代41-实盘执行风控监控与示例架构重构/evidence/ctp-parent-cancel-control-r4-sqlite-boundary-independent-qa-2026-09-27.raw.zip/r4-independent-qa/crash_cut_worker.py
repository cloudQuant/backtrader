from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import time

copy_root = pathlib.Path(sys.argv[1])
state_root = pathlib.Path(sys.argv[2])
marker = pathlib.Path(sys.argv[3])
sys.path.insert(0, str(copy_root))
test_path = copy_root / 'tests' / 'test_cancellation_dispatch_resolution_control.py'
spec = importlib.util.spec_from_file_location('r4_frozen_test_module', test_path)
if spec is None or spec.loader is None:
    raise SystemExit('cannot load frozen test module')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
fixture = mod._Fixture(state_root)
original = fixture.runtime.risk_gate.resolve_freeze

def pause_after_final_risk_commit(scope, cause_id):
    original(scope, cause_id)
    if cause_id == fixture.progress_cause:
        payload = {
            'command_id': fixture.command.command_id,
            'event_id': 'cancel-freeze-release:' + fixture.command.command_id,
            'unknown_cause': fixture.unknown_cause,
            'progress_cause': fixture.progress_cause,
            'state_root': str(state_root),
            'control_db': str(state_root / 'control' / 'cancellation_operator_control.sqlite3'),
            'monitor_db': str(fixture.runtime.state_directory / 'monitor.sqlite3'),
            'risk_db': str(fixture.runtime.state_directory / 'risk.sqlite3'),
            'cutpoint': 'risk_gate.resolve_freeze committed and returned; before _hold_release_prepared_monitor_fact context COMMIT',
        }
        marker.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
        while True:
            time.sleep(0.1)

fixture.runtime.risk_gate.resolve_freeze = pause_after_final_risk_commit
mod._release(fixture)
raise SystemExit('unexpectedly passed crash cut without being killed')
