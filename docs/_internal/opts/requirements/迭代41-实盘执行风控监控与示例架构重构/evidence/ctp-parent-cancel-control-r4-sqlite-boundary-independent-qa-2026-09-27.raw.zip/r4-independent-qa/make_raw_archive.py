from __future__ import annotations
import hashlib,pathlib,sys,zipfile
qa=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927')
out=qa/'r4-independent-qa-2026-09-27.raw.zip'
if out.exists(): raise SystemExit(f'refusing to overwrite frozen archive: {out}')
root_names=[
'independent-qa-receipt.md','independent-qa-summary.json','r4-payload-manifest.json','r3-payload-manifest.json',
'manifest-diff-verification.json','manifest-diff-verification.log','final-freeze-recheck.json','final-freeze-recheck.log',
'focused-tests-independent.log','ctp-labeled-fake-scope-rejection.log',
'r4-author-receipt.md','r4-author-focused-tests.log','r4-author-ruff.json','r4-author-ruff-imports.log','r4-author-sqlite-writer-probes.log',
'ruff-comparison.json','ruff-comparison.log','ruff-r3-selected.json','ruff-r4-selected.json','r3-r4-source.diff',
'extra-probes-independent-run.log','extra-probes-independent-run2.log','extra-probes-independent-run3.log','extra-probes-independent-run4.log','extra-probes-independent-run5.log','extra-probes.json','extra-probes.log',
'crash-cut-marker.json','module-scope-audit.json','ddl-bypass-state.json','persistent-ddl-probe.log',
'verify_and_copy.py','verify_final_freeze.py','make_source_diff.py','r4_additional_probes.py','crash_cut_worker.py','persistent_ddl_probe.py','compare_ruff.py','module_scope_audit.py','make_raw_archive.py',
]
files=[]
for name in root_names:
    p=qa/name
    if not p.is_file(): raise SystemExit(f'missing archive input: {p}')
    files.append(p)
for dirname in ('crash-cut-state','ddl-bypass-state'):
    d=qa/dirname
    if not d.is_dir(): raise SystemExit(f'missing state directory: {d}')
    files.extend(sorted(p for p in d.rglob('*') if p.is_file()))
files=sorted(set(files),key=lambda p:p.relative_to(qa).as_posix())
external=[
pathlib.Path(r'D:\temp\iteration41_v20_r3_cancel_terminal_candidate_20260927\src\bt_api_execution\__init__.py'),
pathlib.Path(r'D:\temp\iteration41_risk_cancel_resolution_20260927\src\bt_api_risk\__init__.py'),
pathlib.Path(r'D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_base\src\bt_api_base\__init__.py'),
pathlib.Path(r'D:\temp\bt_api_i9_store_broker_src_20260926\bt_api_monitor\src\bt_api_monitor\__init__.py'),
]
hashlist=[]
internal={}
for p in files:
    rel=p.relative_to(qa).as_posix()
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    internal[rel]=digest
    hashlist.append(f'{digest}  {rel}')
for p in external:
    if not p.is_file(): raise SystemExit(f'missing source provenance file: {p}')
    hashlist.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p}')
sums=qa/'SHA256SUMS.txt'
sums.write_text('\n'.join(hashlist)+'\n',encoding='ascii')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
    for p in files:
        zf.write(p,'r4-independent-qa/'+p.relative_to(qa).as_posix())
    zf.write(sums,'r4-independent-qa/SHA256SUMS.txt')
with zipfile.ZipFile(out,'r') as zf:
    names=zf.namelist()
    if zf.testzip() is not None: raise SystemExit(f'CRC failure: {zf.testzip()}')
    if len(names)!=len(files)+1: raise SystemExit(f'member count mismatch: {len(names)} vs {len(files)+1}')
    if zf.read('r4-independent-qa/SHA256SUMS.txt')!=sums.read_bytes(): raise SystemExit('sum file member differs')
    checked=0
    for info in zf.infolist():
        rel=info.filename.split('/',1)[1]
        if rel=='SHA256SUMS.txt': continue
        actual=hashlib.sha256(zf.read(info.filename)).hexdigest()
        if actual!=internal.get(rel): raise SystemExit(f'member sha mismatch: {rel}')
        checked+=1
    if checked!=len(files): raise SystemExit(f'member hash count mismatch: {checked}')
print(f'zip_testzip=OK members={len(names)} content_members_sha_verified={checked}')
print(f'bytes={out.stat().st_size}')
print(f'sha256={hashlib.sha256(out.read_bytes()).hexdigest()}')
print(f'sha256s_entries={len(hashlist)}')
print(f'archived_files={len(files)}')
