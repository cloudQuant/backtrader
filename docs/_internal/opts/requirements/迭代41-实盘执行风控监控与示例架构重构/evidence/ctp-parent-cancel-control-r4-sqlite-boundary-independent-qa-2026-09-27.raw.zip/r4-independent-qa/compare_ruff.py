import json,pathlib,collections
qa=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-independent-qa-20260927')
freeze=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-freeze-r1-20260927')
author=pathlib.Path(r'D:\temp\iteration41-cancel-control-r4-evidence-20260927\frozen-r1-ruff.json')
def load(p):
 items=json.loads(p.read_text(encoding='utf-8-sig'))
 return collections.Counter((x['code'],x['location']['row'],x['location']['column'],x['message']) for x in items)
a=load(author); b=load(qa/'ruff-r4-selected.json'); r3=load(qa/'ruff-r3-selected.json')
assert a==b,(len(a),len(b),list((a-b).items())[:2],list((b-a).items())[:2])
report={'ruff_version':'0.16.2','author_r4_diagnostics':sum(a.values()),'independent_r4_diagnostics':sum(b.values()),'r3_diagnostics_same_selectors':sum(r3.values()),'r4_added_vs_r3':sum(b.values())-sum(r3.values()),'r4_diagnostics_match_author_json':True,'selectors':['TRY004','BLE001','S110','FURB157','RUF100','I001'],'added_diagnostic_counts':{code:sum(v for key,v in b.items() if key[0]==code)-sum(v for key,v in r3.items() if key[0]==code) for code in sorted(set(key[0] for key in b)|set(key[0] for key in r3)) if sum(v for key,v in b.items() if key[0]==code)!=sum(v for key,v in r3.items() if key[0]==code)}}
(qa/'ruff-comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(qa/'ruff-comparison.log').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
