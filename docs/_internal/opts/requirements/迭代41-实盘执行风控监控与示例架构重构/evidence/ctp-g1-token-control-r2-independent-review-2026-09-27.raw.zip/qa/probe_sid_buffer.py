from __future__ import annotations
import ctypes,gc,hashlib,importlib,os,sys
from pathlib import Path
from types import SimpleNamespace
qa=Path(r'D:\temp\iteration41-token-control-independent-r2-qa-20260927').resolve()
copy=qa/'source-copy'
sys.path.insert(0,str(copy))
from scripts import ctp_i13_i15_readonly_token_bootstrap as token
expected=copy/'scripts/ctp_i13_i15_readonly_token_bootstrap.py'
if Path(token.__file__).resolve()!=expected.resolve(): raise RuntimeError('token helper import escaped source copy')
if hashlib.sha256(expected.read_bytes()).hexdigest()!='56af3861ab8eb22cec9a96444a39e13b96f1180e8b6dfefafef1cc8a5b7c6054': raise RuntimeError('token helper hash mismatch')
sid=(bytes((1,4))+(5).to_bytes(6,'big')+b''.join(x.to_bytes(4,'little') for x in (21,77,88,1001)))
class FakeGetTokenInformation:
    def __init__(self,mode='inside',truncate=False): self.mode=mode; self.truncate=truncate; self.calls=0
    def __call__(self,handle,information_class,output,output_length,returned):
        self.calls+=1
        required=ctypes.sizeof(token._TOKEN_USER)+len(sid)
        returned_ptr=ctypes.cast(returned,ctypes.POINTER(token.wintypes.DWORD))
        if not output:
            returned_ptr.contents.value=required
            return 0
        base=ctypes.cast(output,ctypes.c_void_p).value
        offset=ctypes.sizeof(token._TOKEN_USER)
        user=ctypes.cast(base,ctypes.POINTER(token._TOKEN_USER)).contents
        if self.mode in ('inside','truncated'): pointer=base+offset
        elif self.mode=='outside': pointer=base+output_length+1024
        else: pointer=base+output_length-8
        user.User.Sid=ctypes.c_void_p(pointer)
        user.User.Attributes=0
        if self.mode=='inside': ctypes.memmove(pointer,sid,len(sid))
        elif self.mode=='truncated': ctypes.memmove(pointer,bytes((1,1,0,0,0,0,0,5)),8)
        used=offset+(len(sid) if not self.truncate else 8)
        returned_ptr.contents.value=used
        return 1
    argtypes=None
    restype=None

def api_for(fake):
    api=object.__new__(token.WindowsTokenSessionApi)
    api._advapi32=SimpleNamespace(GetTokenInformation=fake)
    return api
read_calls=[]
original=ctypes.string_at
def counted(address,size):
    read_calls.append((int(address),int(size)))
    return original(address,size)
ctypes.string_at=counted
try:
    fake=FakeGetTokenInformation('inside')
    api=api_for(fake)
    information=api._get_information(1234,token._TOKEN_INFORMATION['user'])
    pointer=ctypes.cast(information.address,ctypes.POINTER(token._TOKEN_USER)).contents.User.Sid
    pointer_value=int(pointer.value if hasattr(pointer,'value') else pointer)
    base=information.address
    if not isinstance(information.storage,ctypes.Array): raise AssertionError('backing allocation not retained')
    if pointer_value<base or pointer_value+len(sid)>information.end: raise AssertionError('valid SID not inside returned allocation')
    gc.collect()
    value=api._sid_string(pointer,information)
    if value!='S-1-5-21-77-88-1001': raise AssertionError(value)
    print('LIVE_BUFFER_POSITIVE',{'storage_type':type(information.storage).__name__,'buffer_kept_after_return_and_gc':True,'sid_inside_returned_bytes':True,'sid':value,'reads':len(read_calls)})
    for mode in ('outside','truncated'):
        invalid_api=api_for(FakeGetTokenInformation(mode,truncate=(mode=='truncated')))
        bad=invalid_api._get_information(1234,token._TOKEN_INFORMATION['user'])
        bad_pointer=ctypes.cast(bad.address,ctypes.POINTER(token._TOKEN_USER)).contents.User.Sid
        before=len(read_calls)
        try: invalid_api._sid_string(bad_pointer,bad)
        except token.TokenBootstrapError as exc:
            if str(exc)!='token_sid_invalid': raise
        else: raise AssertionError(mode+' SID was accepted')
        after=len(read_calls)
        delta=after-before
        expected_delta=0 if mode=='outside' else 1
        if delta!=expected_delta: raise AssertionError(f'{mode} dereference count {delta} != {expected_delta}')
        print('MALFORMED_POINTER_REJECTED',{'mode':mode,'error':'token_sid_invalid','reads_before_reject':delta,'no_out_of_bounds_read':True})
finally:
    ctypes.string_at=original

