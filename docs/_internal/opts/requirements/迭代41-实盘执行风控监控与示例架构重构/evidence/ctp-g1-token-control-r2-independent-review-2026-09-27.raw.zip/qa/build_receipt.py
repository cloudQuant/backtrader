from __future__ import annotations
import hashlib,json,platform,xml.etree.ElementTree as ET
from pathlib import Path,PurePosixPath
qa=Path(r'D:\temp\iteration41-token-control-independent-r2-qa-20260927').resolve()
freeze=Path(r'D:\temp\iteration41-token-control-repaired-r2-20260927').resolve()
expected='7aab3a9faad13f281c9003446f9f02f9aad928ee64655b4b10741d03eafeda30'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sha(freeze/'manifest.json')!=expected or sha(qa/'freeze-manifest-copy.json')!=expected: raise RuntimeError('freeze manifest hash mismatch')
manifest=json.loads((freeze/'manifest.json').read_text(encoding='utf-8'))
if manifest.get('schema')!='iteration41-token-control-evidence.v2': raise RuntimeError('unexpected freeze manifest schema')
files=manifest['files']
for rel,digest in files.items():
 p=freeze.joinpath(*PurePosixPath(rel).parts)
 if not p.is_file() or sha(p)!=digest: raise RuntimeError('freeze file changed: '+rel)
copy=qa/'source-copy'
source_hashes={}
for rel,digest in files.items():
 if rel.startswith(('scripts/','tests/')) and rel.endswith('.py'):
  p=copy.joinpath(*PurePosixPath(rel).parts)
  if not p.is_file() or sha(p)!=digest: raise RuntimeError('source copy changed: '+rel)
  source_hashes[rel]=digest
if len(source_hashes)!=15: raise RuntimeError('unexpected Python source/test count')
source_copy_paths={p.relative_to(copy).as_posix() for p in copy.rglob('*') if p.is_file()}
if source_copy_paths!=set(source_hashes): raise RuntimeError('source copy has unexpected files')

junit=qa/'results/junit.xml'
r=ET.parse(junit).getroot()
case_nodes=list(r.iter('testcase'))
skips=[]
failures=[]
for case in case_nodes:
 if case.find('skipped') is not None: skips.append(case.get('name'))
 if case.find('failure') is not None or case.find('error') is not None: failures.append(case.get('name'))
if len(case_nodes)!=60 or skips or failures: raise RuntimeError('independent focus JUnit not 60/0/0')
required={
 'test_windows_token_session_api_current_process_query_only_smoke',
 'test_token_control_pipe_reader_uses_real_server_pid_and_one_frame_eof',
 'test_token_sid_parser_rejects_forged_or_truncated_pointers_before_dereference',
}
if not required.issubset({x.get('name') for x in case_nodes}): raise RuntimeError('expected OS/SID cases not present')
for name in required:
 node=next(x for x in case_nodes if x.get('name')==name)
 if node.find('skipped') is not None or node.find('failure') is not None: raise RuntimeError('required test did not pass: '+name)

receipt={
 'schema':'iteration41.token_control_repaired_r2.independent_qa.v1',
 'conclusion':'TOKEN_CONTROL_SLICE_PASS_WHOLE_G1_NOT_PASS',
 'freeze':{'path':str(freeze),'manifest_sha256':expected,'manifested_files_verified':len(files),'extra_files':[],'withdrawn_prior_snapshot':'782a2f2303ade9600cebc6bec47ac66213cd57f48c0a0ce0748e7ffeea2c6de4'},
 'independent_source_copy':{'path':str(copy),'python_source_and_test_file_count':len(source_hashes),'files':source_hashes},
 'runtime':{'os_name':'nt','interpreter':r'C:\Users\yunji\AppData\Local\Temp\bt-pytest-asyncio-compat-20260926\Scripts\python.exe','python':'3.11.5','plugin_autoload_disabled':True,'dont_write_bytecode':True},
 'focus':{'runner':'run_focus.py','result':{'passed':60,'skipped':0,'failed':0},'junit':'results/junit.xml','stdout':'results/stdout.log','stderr':'results/stderr.log','process_result':'results/process-result.json','tests':[x.get('name') for x in case_nodes]},
 'windows_smokes':{
  'current_process_token_query_only':{'node':'test_windows_token_session_api_current_process_query_only_smoke','ran_not_skipped':True,'access':'TOKEN_QUERY (0x0008)','repeated_queries':64,'set_token_information_called':False,'se_tcb_privilege_enabled':False},
  'local_named_pipe_one_frame':{'node':'test_token_control_pipe_reader_uses_real_server_pid_and_one_frame_eof','ran_not_skipped':True,'server_pid_checked':True,'message_frame_synthetic':True,'eof_required':True},
 },
 'buffer_and_sid_review':{
  'source_helper_sha256':source_hashes['scripts/ctp_i13_i15_readonly_token_bootstrap.py'],
  'live_buffer_probe':'buffer-probe-results/stdout-stderr.log',
  'positive':'backing ctypes buffer retained through gc; embedded SID parsed from within ReturnLength range',
  'negative':'outside pointer rejected before any string_at read; truncated SID rejected after bounded header only',
  'native_token_forgery':'not performed; negative pointer inputs were synthetic fake-API buffers',
 },
 'token_rights_review':{
  'source':'scripts/ctp_i13_i15_windows_guardian_service.py',
  'source_sha256':source_hashes['scripts/ctp_i13_i15_windows_guardian_service.py'],
  'open_thread_token':'TOKEN_QUERY | TOKEN_DUPLICATE',
  'duplicate_token':'TOKEN_QUERY | TOKEN_ASSIGN_PRIMARY; TOKEN_ADJUST_SESSIONID only for explicit coordinator adjustment',
  'duplicate_access_test':'fake Win32 API test asserts exact masks and no TOKEN_DUPLICATE on child token',
  'real_duplicate_token_smoke':False,
 },
 'one_shot_and_fail_stop':{
  'reader_checks':'named-pipe server PID before/after, bounded single frame, EOF',
  'owner_control_server':'defined but no invocation/test in this slice; full token duplication-to-coordinator wiring unproven',
  'revert_failure':'tests inject fail-stop sentinel and assert no later service work; real TerminateProcess/os._exit not executed',
 },
 'scope_limits':[
  'Whole-command G1 remains NOT_PASS: frozen manifest states coordinator/worker/receipt-writer two-Job chain is unwired and setup/receipt lack proven whole-command deadline.',
  'No protected config, SCM operation, SDK/native CTP extension, provider, account, or trading request was used.',
  'The current-process test reads token facts with TOKEN_QUERY only; it does not change the current token.',
 ],
}
(qa/'qa-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
# Hash all source-copy Python files, independent scripts/receipts, and test outputs. Include test basetemp evidence.
selected=set()
for p in copy.rglob('*'):
 if p.is_file(): selected.add(p)
for p in qa.rglob('*'):
 if not p.is_file(): continue
 rel=p.relative_to(qa).as_posix()
 if rel in {'artifact-manifest.json'}: continue
 if rel.startswith(('results/','buffer-probe-results/')) or rel in {'verify_and_copy.py','run_focus.py','probe_sid_buffer.py','build_receipt.py','review_notes.md','source-audit.json','freeze-manifest-copy.json','qa-receipt.json'}:
  selected.add(p)
entries=[{'path':p.relative_to(qa).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(selected,key=lambda x:x.relative_to(qa).as_posix())]
artifact={'schema':'iteration41.token_control_repaired_r2.independent_qa.artifacts.v1','qa_receipt':'qa-receipt.json','artifact_count':len(entries),'artifacts':entries}
(qa/'artifact-manifest.json').write_text(json.dumps(artifact,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'qa_receipt_sha256':sha(qa/'qa-receipt.json'),'artifact_manifest_sha256':sha(qa/'artifact-manifest.json'),'artifact_count':len(entries),'focus':receipt['focus']['result'],'freeze_manifest':expected},sort_keys=True))

