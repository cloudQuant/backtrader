import json, os, sys, time
from pathlib import Path
sys.path.insert(0, 'D:\\temp\\iteration41-token-control-independent-r2-qa-20260927\\source-copy')
from scripts import ctp_i13_i15_windows_guardian_service as service_module
serve_one_inert_request = service_module.serve_one_inert_request
args = sys.argv[1:]
address, key_hex, executable, executable_hash, receipt_root, ready_path, status_path, response_path, release_path, mode, phase_path = args
def mark(phase):
    with Path(phase_path).open('a', encoding='ascii') as stream:
        stream.write(json.dumps({'phase': phase, 'monotonic_ns': time.monotonic_ns(), 'pid': os.getpid()}, separators=(',', ':')) + '\n')
        stream.flush()
mark('service_started')
original_accept = service_module._RestrictedPipeListener.accept
def traced_accept(listener):
    mark('pipe_accept_started')
    try: connection = original_accept(listener)
    except BaseException:
        mark('pipe_accept_failed')
        raise
    mark('pipe_accept_returned')
    return connection
service_module._RestrictedPipeListener.accept = traced_accept
original_decode = service_module._decode_request
def traced_decode(raw, *, now):
    mark('request_decode_started')
    try: value = original_decode(raw, now=now)
    except BaseException:
        mark('request_decode_failed')
        raise
    mark('request_decode_returned')
    return value
service_module._decode_request = traced_decode
def ready(address, pid):
    mark('service_ready_callback')
    Path(ready_path).write_text(json.dumps({'address': address, 'pid': pid}), encoding='ascii')
def before_response():
    mark('service_before_response')
    if mode not in ('response', 'deadline'): return
    Path(response_path).write_text('ready', encoding='ascii')
    end = time.monotonic() + 20.0
    while not Path(release_path).exists() and time.monotonic() < end:
        time.sleep(0.02)
mark('serve_call_started')
result = serve_one_inert_request(
    address=address, auth_key=bytes.fromhex(key_hex),
    python_executable=executable, python_sha256=executable_hash,
    receipt_root=receipt_root, ready=ready, before_response=before_response,
    accept_timeout_seconds=30.0,
)
mark('serve_call_returned')
Path(status_path).write_text(result, encoding='ascii')