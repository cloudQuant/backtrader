import json, os, platform, sys, time
from pathlib import Path
owner_phase_path = sys.argv[-1]
def mark(phase):
    with Path(owner_phase_path).open('a', encoding='ascii') as stream:
        stream.write(json.dumps({'phase': phase, 'monotonic_ns': time.monotonic_ns(), 'pid': os.getpid()}, separators=(',', ':')) + '\n')
        stream.flush()
mark('owner_started')
sys.path.insert(0, 'D:\\temp\\iteration41-token-control-independent-r2-qa-20260927\\source-copy')
from scripts import ctp_i13_i15_parent_launcher as launcher
from scripts.ctp_i13_i15_windows_guardian_service import request_over_pipe
mark('owner_modules_imported')
descriptor_path, descriptor_pin, auth_key_hex, service_pid, result_path, owner_phase_path = sys.argv[1:]
mark('descriptor_read_started')
raw = Path(descriptor_path).read_bytes()
mark('descriptor_read_completed')
trusted = launcher.ExternallyPinnedDescriptor(raw, descriptor_pin, 'fake-service-death-test')
now = time.monotonic()
mark('inert_guardian_request_started')
def requester(**kwargs):
    mark('ipc_request_started')
    try: return request_over_pipe(**kwargs)
    finally: mark('ipc_request_finished')
result = launcher.request_inert_guardian(
    trusted, captured_launcher_bytes=Path('D:\\temp\\iteration41-token-control-independent-r2-qa-20260927\\source-copy\\scripts\\ctp_i13_i15_parent_launcher.py').read_bytes(),
    actual_executable=sys.executable, actual_version=platform.python_version(),
    actual_architecture=platform.machine(), child_seconds=30.0,
    stop_deadline_monotonic=now + 5.0, deadline_monotonic=now + 8.0,
    service_pid=int(service_pid), service_auth_key=bytes.fromhex(auth_key_hex),
    request_id='fedcba9876543210fedcba9876543210', ipc_requester=requester,
    monotonic=time.monotonic,
)
mark('inert_guardian_request_finished')
Path(result_path).write_text(json.dumps({'state': result.state, 'reason': result.reason}), encoding='ascii')
mark('owner_result_written')