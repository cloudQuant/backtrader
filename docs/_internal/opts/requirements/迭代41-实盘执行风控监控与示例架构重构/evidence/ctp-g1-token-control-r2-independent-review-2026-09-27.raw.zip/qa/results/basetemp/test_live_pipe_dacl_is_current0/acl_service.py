import json, sys
from pathlib import Path
sys.path.insert(0, 'D:\\temp\\iteration41-token-control-independent-r2-qa-20260927\\source-copy')
from scripts.ctp_i13_i15_windows_guardian_service import serve_one_inert_request
address, key_hex, executable, executable_hash, receipt_root, ready_path, status_path, accept_error_path = sys.argv[1:]
import scripts.ctp_i13_i15_windows_guardian_service as service_module
original_accept = service_module._RestrictedPipeListener.accept
def record_accept_error(listener):
    try: return original_accept(listener)
    except BaseException as error:
        Path(accept_error_path).write_text(type(error).__name__ + ':' + str(getattr(error, 'winerror', '')), encoding='ascii')
        raise
service_module._RestrictedPipeListener.accept = record_accept_error
def ready(address, pid): Path(ready_path).write_text(json.dumps({'address': address, 'pid': pid}), encoding='ascii')
status = serve_one_inert_request(address=address, auth_key=bytes.fromhex(key_hex), python_executable=executable, python_sha256=executable_hash, receipt_root=receipt_root, ready=ready, accept_timeout_seconds=8.0)
Path(status_path).write_text(status, encoding='ascii')