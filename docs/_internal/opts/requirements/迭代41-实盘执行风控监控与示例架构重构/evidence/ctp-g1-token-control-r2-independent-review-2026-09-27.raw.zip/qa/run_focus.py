from __future__ import annotations
import hashlib, importlib, os, sys
from pathlib import Path
import pytest
qa=Path(r'D:\temp\iteration41-token-control-independent-r2-qa-20260927').resolve()
copy=qa/'source-copy'
out=Path(os.environ['TOKEN_QA_OUTPUT']).resolve()
out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(copy))
expected={
 'scripts.ctp_i13_i15_readonly_token_bootstrap':copy/'scripts/ctp_i13_i15_readonly_token_bootstrap.py',
 'scripts.ctp_i13_i15_windows_guardian_service':copy/'scripts/ctp_i13_i15_windows_guardian_service.py',
 'scripts.ctp_i13_i15_windows_guardian':copy/'scripts/ctp_i13_i15_windows_guardian.py',
 'scripts.ctp_i13_i15_windows_job_backend':copy/'scripts/ctp_i13_i15_windows_job_backend.py',
 'scripts.ctp_i13_i15_parent_launcher':copy/'scripts/ctp_i13_i15_parent_launcher.py',
 'scripts.ctp_i13_i15_readonly_receipt_writer':copy/'scripts/ctp_i13_i15_readonly_receipt_writer.py',
 'scripts.ctp_i13_i15_readonly_request_coordinator':copy/'scripts/ctp_i13_i15_readonly_request_coordinator.py',
 'scripts.ctp_i13_i15_outer_watchdog':copy/'scripts/ctp_i13_i15_outer_watchdog.py',
}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for name,path in expected.items():
 module=importlib.import_module(name)
 actual=Path(module.__file__).resolve()
 if actual!=path.resolve(): raise RuntimeError(f'origin mismatch {name}: {actual} != {path}')
 print('IMPORT_ORIGIN',name,actual,digest(actual))
if os.name!='nt': raise RuntimeError('query-only Windows smoke would not run on non-Windows host')
tests=[copy/'tests/unit/scripts/test_ctp_i13_i15_windows_guardian_service.py',copy/'tests/unit/scripts/test_ctp_i13_i15_readonly_roles.py']
res=pytest.main(['-q','--color=no','-p','no:cacheprovider','-o','markers=unit','--basetemp',str(out/'basetemp'),'--junitxml',str(out/'junit.xml'),*(str(t) for t in tests)])
if int(res)!=0: raise SystemExit(int(res))
for name,module in sorted(sys.modules.items()):
 if name.startswith('scripts.ctp_i13_i15_'):
  path=Path(module.__file__).resolve()
  if copy/'scripts' not in path.parents: raise RuntimeError(f'post-test origin escaped copy: {name}: {path}')
print('POST_TEST_ORIGINS_OK')
