from __future__ import annotations
import hashlib,json,shutil
from pathlib import Path,PurePosixPath
freeze=Path(r'D:\temp\iteration41-token-control-repaired-r2-20260927').resolve()
qa=Path(r'D:\temp\iteration41-token-control-independent-r2-qa-20260927').resolve()
expected='7aab3a9faad13f281c9003446f9f02f9aad928ee64655b4b10741d03eafeda30'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest_path=freeze/'manifest.json'
if sha(manifest_path)!=expected: raise SystemExit('manifest hash mismatch: '+sha(manifest_path))
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
files=manifest.get('files')
if not isinstance(files,dict): raise SystemExit('manifest files is not hash map')
errors=[]
for rel,digest in files.items():
 q=PurePosixPath(rel)
 if q.is_absolute() or '..' in q.parts: errors.append('unsafe path '+rel); continue
 p=freeze.joinpath(*q.parts)
 if not p.is_file() or sha(p)!=digest: errors.append('source hash mismatch '+rel)
if errors: raise SystemExit('\n'.join(errors))
actual={p.relative_to(freeze).as_posix() for p in freeze.rglob('*') if p.is_file() and p!=manifest_path}
extra=sorted(actual-set(files)); missing=sorted(set(files)-actual)
if missing: raise SystemExit('manifest missing '+repr(missing))
copy=qa/'source-copy'
for rel,digest in files.items():
 if not (rel.startswith('scripts/') or rel.startswith('tests/')) or not rel.endswith('.py'): continue
 src=freeze.joinpath(*PurePosixPath(rel).parts); dst=copy.joinpath(*PurePosixPath(rel).parts)
 dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
 if sha(dst)!=digest: raise SystemExit('copy hash mismatch '+rel)
report={'freeze':str(freeze),'manifest_sha256':sha(manifest_path),'manifest_file_count':len(files),'verified_file_count':len(files),'extra_files_not_manifested':extra,'missing_files':missing,'copied_python_files':sum(1 for _ in copy.rglob('*.py')),'source_copy':str(copy),'source_hashes':{rel:digest for rel,digest in files.items() if rel.endswith('.py')}}
(qa/'source-audit.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='source_hashes'},sort_keys=True))
