# G1 token/control slice independent QA (repaired r2)

## Freeze and source provenance

- Frozen snapshot: `D:\temp\iteration41-token-control-repaired-r2-20260927`
- Manifest SHA-256: `7aab3a9faad13f281c9003446f9f02f9aad928ee64655b4b10741d03eafeda30`
- All 73 manifest entries matched by byte length and SHA-256; there were no unmanifested files in the snapshot at audit time. The r1 snapshot (`782a...`) was withdrawn and is not part of this acceptance.
- Independent tests ran against a separate source copy containing only 15 manifest-listed Python files (13 `scripts` modules and 2 test modules). The import-origin guard checked the token helper, guardian service, guardian, Windows Job backend, parent launcher, receipt writer, request coordinator, and outer watchdog before tests, then confirmed imported `scripts.ctp_i13_i15_*` modules remained inside the copy afterward.

## Focused test run

Runner: `run_focus.py`; interpreter: `C:\Users\yunji\AppData\Local\Temp\bt-pytest-asyncio-compat-20260926\Scripts\python.exe` (Python 3.11.5); plugin autoload disabled; bytecode/cache disabled; JUnit and pytest basetemp were outside the freeze.

Result: **60 passed, 0 skipped, 0 failed**. Both real-Windows checks ran (not skipped):

- `test_windows_token_session_api_current_process_query_only_smoke` opened the current process token with `TOKEN_QUERY` only and repeated readback 64 times. It did not call `SetTokenInformation` or enable `SeTcbPrivilege`.
- `test_token_control_pipe_reader_uses_real_server_pid_and_one_frame_eof` used a temporary local named pipe, checked the OS server PID, read a synthetic bounded frame, and observed EOF.

JUnit, stdout/stderr, process metadata, and per-test temp files are under `results/`.

## Buffer lifetime / SID pointer checks

In the frozen helper, `_get_information` retains the original `ctypes.create_string_buffer` in `_TokenInformationBuffer`; parser methods consume the exact `ReturnLength`. `_sid_string` checks the pointer against that live allocation before reading the SID header, then checks the computed SID length before reading the full SID.

A separate source-copy-only probe supplied fake `GetTokenInformation` bytes with an embedded absolute SID pointer, forced garbage collection after `_get_information` returned, and parsed the SID successfully while the backing buffer stayed alive. An outside-allocation pointer rejected before any `ctypes.string_at` read. A truncated SID inside the allocation rejected after only the bounded 8-byte header read; it did not read beyond `ReturnLength`. These are fake API probes, not a forged real Windows token.

## Token rights, control pipe, and reversion

- The source asks `OpenThreadToken` for `TOKEN_QUERY | TOKEN_DUPLICATE`; `DuplicateTokenEx` receives only `TOKEN_QUERY | TOKEN_ASSIGN_PRIMARY`, plus `TOKEN_ADJUST_SESSIONID` only for the coordinator path. The tests assert these exact masks and primary-token/impersonation-level arguments. The ordinary readonly-service call uses the default without session-adjustment rights. These masks are fake-API tests; the real smoke is query-only and does not duplicate a token.
- The service-only control pipe code uses a protected DACL, one pipe instance, message mode, first-instance creation, and remote-client rejection. The token reader validates server PID before and after one bounded message and requires EOF. The local one-frame reader test passed.
- `RevertToSelf` is in a `finally` boundary. Failure calls process fail-stop (`TerminateProcess`, with `os._exit` fallback) before the caller can continue under an uncertain thread token. Tests inject a fail-stop sentinel to assert ordering/no later receipt or handle cleanup; they do not terminate the QA process or prove the OS termination syscall itself.
- The frozen source defines `_OwnerTokenControlServer`, but no module/test in this slice constructs it. The passing local pipe smoke exercises the reader with a synthetic frame, not the full authenticated owner-token duplication and suspended-coordinator transfer path.

## Acceptance boundary

This accepts only the frozen token-helper/control sub-slice and its stated local Windows read-only/pipe smoke. **Whole-command G1 remains NOT_PASS.** The freeze itself states that the coordinator/worker/receipt-writer two-Job chain is not wired and synchronous setup/receipt paths do not yet have a proven whole-command deadline. No protected config, SCM service operation, SDK/native CTP extension, provider, account, or trading request was used.
