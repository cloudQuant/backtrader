import ctypes, json, os, sys, time
from ctypes import wintypes
from pathlib import Path
sys.path.insert(0, 'D:\\temp\\iteration41-token-control-repaired-r2-20260927')
from scripts import ctp_i13_i15_windows_guardian_service as service_module
serve_one_inert_request = service_module.serve_one_inert_request
from scripts.ctp_i13_i15_windows_job_backend import WindowsJobBackend
address, key_hex, executable, executable_hash, receipt_root, ready_path, status_path, child_active_path, phase_path = sys.argv[1:]
def mark(phase):
    with Path(phase_path).open('a', encoding='ascii') as stream:
        stream.write(json.dumps({'phase': phase, 'monotonic_ns': time.monotonic_ns(), 'pid': os.getpid()}, separators=(',', ':')) + '\n')
        stream.flush()
mark('service_started')
original_accept = service_module._RestrictedPipeListener.accept
def traced_accept(listener):
    mark('pipe_accept_started')
    try: connection = original_accept(listener)
    except BaseException:
        mark('pipe_accept_failed')
        raise
    mark('pipe_accept_returned')
    return connection
service_module._RestrictedPipeListener.accept = traced_accept
original_decode = service_module._decode_request
def traced_decode(raw, *, now):
    mark('request_decode_started')
    try: value = original_decode(raw, now=now)
    except BaseException:
        mark('request_decode_failed')
        raise
    mark('request_decode_returned')
    return value
service_module._decode_request = traced_decode
def ready(address, pid):
    mark('service_ready_callback')
    Path(ready_path).write_text(json.dumps({'address': address, 'pid': pid}), encoding='ascii')
def backend_factory():
    mark('backend_factory_called')
    backend = WindowsJobBackend()
    create = backend.create_suspended_in_job
    def create_blocked(command, *, deadline_monotonic):
        mark('job_create_started')
        session = create(command, deadline_monotonic=deadline_monotonic)
        mark('job_create_returned')
        resume = session.resume_launcher
        def resume_then_block():
            mark('launcher_resume_started')
            resumed = resume()
            mark('launcher_resume_returned')
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            get_process_id = kernel32.GetProcessId
            get_process_id.argtypes = [wintypes.HANDLE]
            get_process_id.restype = wintypes.DWORD
            child_pid = int(get_process_id(wintypes.HANDLE(session._process_handle)))
            Path(child_active_path).write_text(json.dumps({'service_pid': os.getpid(), 'child_pid': child_pid}), encoding='ascii')
            mark('child_active_marker_written')
            end = time.monotonic() + 120.0
            mark('backend_block_started')
            while time.monotonic() < end:
                time.sleep(0.02)
            return resumed
        session.resume_launcher = resume_then_block
        return session
    backend.create_suspended_in_job = create_blocked
    return backend
mark('serve_call_started')
result = serve_one_inert_request(
    address=address, auth_key=bytes.fromhex(key_hex),
    python_executable=executable, python_sha256=executable_hash,
    receipt_root=receipt_root, ready=ready, backend_factory=backend_factory,
    accept_timeout_seconds=30.0,
)
mark('serve_call_returned')
Path(status_path).write_text(result, encoding='ascii')