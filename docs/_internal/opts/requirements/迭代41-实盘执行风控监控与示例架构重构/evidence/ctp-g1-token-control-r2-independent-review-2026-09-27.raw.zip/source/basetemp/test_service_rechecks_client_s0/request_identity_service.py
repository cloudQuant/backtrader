import json, sys
from pathlib import Path
sys.path.insert(0, 'D:\\temp\\iteration41-token-control-repaired-r2-20260927')
import scripts.ctp_i13_i15_windows_guardian_service as service_module
from scripts.ctp_i13_i15_windows_guardian_service import serve_one_inert_request
address, key_hex, executable, executable_hash, receipt_root, ready_path, status_path = sys.argv[1:]
identities = iter((service_module._current_user_sid(), 'S-1-5-18'))
service_module._impersonated_pipe_client_sid = lambda handle: next(identities)
def ready(address, pid): Path(ready_path).write_text(json.dumps({'address': address, 'pid': pid}), encoding='ascii')
result = serve_one_inert_request(address=address, auth_key=bytes.fromhex(key_hex), python_executable=executable, python_sha256=executable_hash, receipt_root=receipt_root, ready=ready, accept_timeout_seconds=8.0)
Path(status_path).write_text(result, encoding='ascii')