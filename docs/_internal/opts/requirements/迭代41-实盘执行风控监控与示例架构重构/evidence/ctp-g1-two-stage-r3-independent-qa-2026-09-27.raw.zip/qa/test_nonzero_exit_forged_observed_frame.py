from __future__ import annotations

import sys
from pathlib import Path

SOURCE = Path(r"D:\temp\iteration41-g1-two-stage-r3-independent-qa-20260927\source")
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, str(SOURCE / "tests" / "unit" / "scripts"))

import scripts.ctp_i13_i15_readonly_receipt_writer as receipt_writer
import scripts.ctp_i13_i15_windows_guardian_service as guardian_service
from test_ctp_i13_i15_windows_guardian_service import _make_two_stage_result_harness


def test_nonzero_coordinator_exit_downgrades_observed_frame_before_writer(monkeypatch):
    run, events, _channels = _make_two_stage_result_harness(monkeypatch)
    delegate = guardian_service._run_fixed_service_role_stage

    def nonzero_coordinator_stage(*, channel, **kwargs):
        result, frame, error = delegate(channel=channel, **kwargs)
        if channel.stage == "coordinator":
            result.evidence.launcher_exit_code = 2
        else:
            frame = receipt_writer.encode_receipt_writer_frame(
                {
                    "schema": receipt_writer.RECEIPT_OUTPUT_SCHEMA,
                    "request_id": "c" * 32,
                    "state": "unknown",
                    "reason": "worker_failed",
                    "receipt_created": True,
                    "receipt_sha256": "f" * 64,
                },
                request_id="c" * 32,
                nonce="2" * 32,
            )
        return result, frame, error

    monkeypatch.setattr(
        guardian_service,
        "_run_fixed_service_role_stage",
        nonzero_coordinator_stage,
    )
    outcome = run()
    assert "coordinator_stage_started" in events
    assert "writer_stage_started" in events
    assert outcome.state == "unknown"
    assert outcome.reason == "worker_failed"
    assert outcome.receipt_sha256 == "f" * 64



