# G1 two-stage r3 inert candidate evidence

This is a new isolated r3 snapshot based on frozen r2; the r2 directory was not edited. The test change separates application success from clean outer Job exit: coordinator output is accepted as OBSERVED only when its own launcher exit code is exactly zero and the outer Job cleanup evidence is clean. Exit code 2 with either an UNKNOWN frame or a forged OBSERVED frame is required to reach the writer only as UNKNOWN. A clean outer Job/exit does not promote an UNKNOWN application frame.

Validation used CPython 3.11.5 (C:\anaconda3\python.exe) with PYTEST_DISABLE_PLUGIN_AUTOLOAD=1. Full focused set: 83 passed in 32.81s across readonly roles, bootstrap receipt runtime, two-stage process, and guardian service tests. Targeted exit-code/frame matrix plus nested accounting test: 4 passed. py_compile passed. Ruff passed for the changed two-stage process test; the service test retains 18 lint findings also present in frozen r2 (see evidence/r3-static-checks.txt).

The first full run failed five Windows integration tests because this copy omitted scripts/__init__.py; all five failed while constructing the synthetic descriptor, before the tested service path. The original repository scripts/__init__.py was then copied into r3 (SHA-256 recorded in the manifest) and the full run passed. Both run logs are retained.

The original r2 root-QA counterexample and its single-node rerun are retained under evidence/r2-root-qa-*. They are historical evidence, not replaced by r3.

Limitations: all two-stage composition facts are inert/fake Job evidence. No SCM service, protected ProgramData deployment, ACL changes, private config, SDK/native/provider, network, or real token session mutation was used. The pre-anchor/prewarm and synchronous watchdog process/Job-creation hard-deadline gap remains unresolved. This is not G1 acceptance and does not enable the ordinary preflight route.
