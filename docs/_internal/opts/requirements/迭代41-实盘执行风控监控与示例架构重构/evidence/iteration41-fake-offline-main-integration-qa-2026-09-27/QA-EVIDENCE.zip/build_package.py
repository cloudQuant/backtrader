import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parent
excluded = {'payload-manifest.json', 'QA-EVIDENCE.zip', 'QA-PACKAGE.SHA256.txt'}
ignored_dirs = {'basetemp', 'pytest-cache', '__pycache__'}
files = []
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.name in excluded:
        continue
    if any(part in ignored_dirs for part in path.relative_to(root).parts):
        continue
    rel = path.relative_to(root).as_posix()
    data = path.read_bytes()
    files.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {
    'format': 'iteration41-integration-regression-qa-payload-v1',
    'scope': 'fake/offline-only; current main-tree source hashes are separately recorded',
    'payload_file_count': len(files),
    'files': files,
}
manifest_path = root / 'payload-manifest.json'
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode('utf-8')
manifest_path.write_bytes(manifest_bytes)
archive_path = root / 'QA-EVIDENCE.zip'
with ZipFile(archive_path, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for entry in files:
        source = root / entry['path']
        archive.write(source, entry['path'])
    archive.writestr('payload-manifest.json', manifest_bytes)
with ZipFile(archive_path, 'r') as archive:
    bad = archive.testzip()
    if bad is not None:
        raise SystemExit(f'ZIP CRC failure: {bad}')
    member_count = len(archive.namelist())
checks = {
    'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'receipt_sha256': hashlib.sha256((root / 'qa-receipt.md').read_bytes()).hexdigest(),
    'source_hashes_sha256': hashlib.sha256((root / 'source-hashes.json').read_bytes()).hexdigest(),
}
lines = [f'{key} {value}' for key, value in checks.items()]
lines.extend([f'zip_testzip None', f'zip_member_count {member_count}', f'payload_file_count {len(files)}'])
(root / 'QA-PACKAGE.SHA256.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({**checks, 'zip_testzip': bad, 'zip_member_count': member_count, 'payload_file_count': len(files)}, indent=2))
