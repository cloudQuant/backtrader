import builtins
import os
import socket
import sys

_LOG = os.environ.get('I41_QA_GUARD_LOG')
_BLOCKED = {'bt_api_ctp', 'bt_api_py', 'bt_api_execution', 'bt_api_risk', 'bt_api_monitor', 'bt_api_gateway', 'bt_api_transport_zmq'}
_REAL_IMPORT = builtins.__import__
_REAL_CREATE_CONNECTION = socket.create_connection
_REAL_GETADDRINFO = socket.getaddrinfo
_REAL_CONNECT = socket.socket.connect
_REAL_CONNECT_EX = socket.socket.connect_ex

def _record(kind, detail):
    if _LOG:
        with open(_LOG, 'a', encoding='utf-8') as stream:
            stream.write(f'{kind}: {detail}\n')

def _root(name):
    return name.split('.', 1)[0]

def _guard_import(name, globals=None, locals=None, fromlist=(), level=0):
    root = _root(name)
    if root in _BLOCKED and name not in sys.modules and root not in sys.modules:
        _record('blocked-import', name)
        raise ImportError(f'Iteration 41 QA blocked optional SDK import: {name}')
    return _REAL_IMPORT(name, globals, locals, fromlist, level)

builtins.__import__ = _guard_import

def _loopback(host):
    if isinstance(host, bytes):
        host = host.decode('ascii', 'ignore')
    if host in ('localhost', 'localhost.localdomain'):
        return True
    try:
        import ipaddress
        return ipaddress.ip_address(host).is_loopback
    except (ValueError, TypeError):
        return False

def _address_host(address):
    if isinstance(address, tuple) and address:
        return address[0]
    return address

def _guarded_create_connection(address, *args, **kwargs):
    host = _address_host(address)
    if _loopback(host):
        _record('allowed-loopback', repr(address))
        return _REAL_CREATE_CONNECTION(address, *args, **kwargs)
    _record('blocked-network', repr(address))
    raise RuntimeError('Iteration 41 QA blocked non-loopback network access')

def _guarded_getaddrinfo(host, *args, **kwargs):
    if host is None or _loopback(host):
        if host is not None:
            _record('allowed-loopback-dns', repr(host))
        return _REAL_GETADDRINFO(host, *args, **kwargs)
    _record('blocked-network-dns', repr(host))
    raise RuntimeError('Iteration 41 QA blocked non-loopback name resolution')

def _guarded_connect(sock, address):
    host = _address_host(address)
    if _loopback(host):
        _record('allowed-loopback', repr(address))
        return _REAL_CONNECT(sock, address)
    _record('blocked-network', repr(address))
    raise RuntimeError('Iteration 41 QA blocked non-loopback socket connect')

def _guarded_connect_ex(sock, address):
    host = _address_host(address)
    if _loopback(host):
        _record('allowed-loopback', repr(address))
        return _REAL_CONNECT_EX(sock, address)
    _record('blocked-network', repr(address))
    raise RuntimeError('Iteration 41 QA blocked non-loopback socket connect_ex')

socket.create_connection = _guarded_create_connection
socket.getaddrinfo = _guarded_getaddrinfo
socket.socket.connect = _guarded_connect
socket.socket.connect_ex = _guarded_connect_ex
