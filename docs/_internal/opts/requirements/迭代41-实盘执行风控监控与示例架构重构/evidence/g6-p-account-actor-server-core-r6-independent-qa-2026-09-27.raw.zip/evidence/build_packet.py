from __future__ import annotations
import hashlib, json, zipfile
from pathlib import Path

root = Path(r"D:\temp\iteration41-g6-account-actor-server-core-r6-independent-qa-20260927")
candidate = root / "candidate"
evidence = root / "evidence"
manifest_path = candidate / "manifest.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

source_entries = []
for item in manifest["files"]:
    path = candidate.joinpath(*item["path"].split("/"))
    source_entries.append({"path": item["path"], "size_bytes": path.stat().st_size, "sha256": digest(path)})
    assert path.stat().st_size == item["size_bytes"]
    assert digest(path) == item["sha256"]
assert len(source_entries) == 42

excluded = {"qa-manifest.json", "raw-qa.zip", "raw-qa.zip.index.json"}
evidence_entries = []
for path in sorted(evidence.rglob("*")):
    if not path.is_file() or path.name in excluded:
        continue
    evidence_entries.append({"path": path.relative_to(root).as_posix(), "size_bytes": path.stat().st_size, "sha256": digest(path)})

qa_manifest = {
    "record": "iteration41-g6-p-account-actor-server-core-r6-independent-qa",
    "status": "G6-P BLOCKED",
    "date": "2026-09-27",
    "frozen_source": {
        "path": str(candidate),
        "manifest_sha256": digest(manifest_path),
        "manifest_entries_verified": len(source_entries),
        "manifest_entries_expected": 42,
        "base_r5_manifest_sha256": manifest["base_r5_manifest_sha256"],
        "source_files": source_entries,
    },
    "independent_tests": {
        "python": "3.11.5",
        "full_command": "PYTHONDONTWRITEBYTECODE=1 python -B -m unittest discover -s tests -v",
        "full_passed": 56,
        "full_failed": 0,
        "full_exit_code": 0,
        "lifecycle_focus_passed": 7,
        "lifecycle_focus_failed": 0,
        "lifecycle_focus_exit_code": 0,
        "module_origins": {
            "account_actor_port": str(candidate / "account_actor_port.py"),
            "account_actor_server_core": str(candidate / "account_actor_server_core.py"),
        },
    },
    "probe_results": {
        "v77_to_v78_authorization_replay": "dispatch_authorization_stale; lifecycle REVOKED; command BLOCKED",
        "old_v77_claim_after_v78": "dispatch_authorization_not_available",
        "v1_authorization_migration": "schema v2; old command BLOCKED; lifecycle REVOKED; stale replay and claim rejected; simulated v1 fixture, not production historical DB",
        "claimed_snapshot_and_writer_fence": "publish and revoke rejected dispatch_claim_in_flight; CLAIMED persisted after reopen",
        "fake_hmac": "fabricated four-domain v77 snapshot with synthetic high funds obtained local authorization and DispatchClaimV1",
        "same_permission_sqlite_tamper": "direct CLAIMED-to-AVAILABLE update allowed second DispatchClaimV1 for same dispatch id; no provider call",
    },
    "limitations": [
        "no release/completion/recovery; crash after CLAIMED permanently freezes local account",
        "same-local-principal SQLite write access can tamper with lifecycle state",
        "fake HMAC key is caller-injected and is not an external snapshot/account authority",
        "no authenticated external actor identity, common provider snapshot, cross-host fence, or provider dispatcher",
        "no real SDK/provider/native API/network/credentials/account accessed",
        "no main production source changed",
    ],
    "evidence_files": evidence_entries,
}
manifest_out = evidence / "qa-manifest.json"
manifest_out.write_text(json.dumps(qa_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")

zip_path = evidence / "raw-qa.zip"
if zip_path.exists():
    raise SystemExit("refusing to overwrite raw QA archive")
with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(candidate.rglob("*")):
        if path.is_file():
            archive.write(path, "candidate/" + path.relative_to(candidate).as_posix())
    for path in sorted(evidence.rglob("*")):
        if not path.is_file() or path in {zip_path, evidence / "raw-qa.zip.index.json"}:
            continue
        archive.write(path, "evidence/" + path.relative_to(evidence).as_posix())

with zipfile.ZipFile(zip_path, "r") as archive:
    entries = []
    for info in archive.infolist():
        raw = archive.read(info.filename)
        entries.append({"path": info.filename, "size_bytes": info.file_size, "sha256": hashlib.sha256(raw).hexdigest()})
index = {
    "archive": "raw-qa.zip",
    "archive_sha256": digest(zip_path),
    "entry_count": len(entries),
    "entries": entries,
}
index_path = evidence / "raw-qa.zip.index.json"
index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({
    "manifest_sha256": digest(manifest_out),
    "zip_sha256": digest(zip_path),
    "index_sha256": digest(index_path),
    "zip_entries": len(entries),
    "qa_manifest_source_entries": len(source_entries),
    "qa_manifest_evidence_entries": len(evidence_entries),
}, indent=2, sort_keys=True))
