from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import tempfile
from contextlib import closing
from pathlib import Path

candidate = Path(os.environ["QA_CANDIDATE_ROOT"]).resolve()
sys.path.insert(0, str(candidate))
import account_actor_port
import account_actor_server_core as core_module
from account_actor_port import ActorCommandContextV1
from account_actor_server_core import (
    AccountActorIntentV1, AccountActorServerCoreV1, AccountSnapshotBundleV1,
    ActorServerError, FakeSnapshotAuthorityV1, SnapshotDomainFactV1, WriterEpochV1,
)

assert Path(account_actor_port.__file__).resolve().parent == candidate
assert Path(core_module.__file__).resolve().parent == candidate
ACCOUNT = "ctp-account-ref.v1:" + hashlib.sha256(b"r6-independent-qa-only").hexdigest()
SOURCE = "r6-fake-source"
AUTHORITY = "r6-fake-authority"
KEY = b"r6-test-only-fake-hmac-key-not-a-credential-012345"

def authority():
    return FakeSnapshotAuthorityV1(authority_id=AUTHORITY, source_id=SOURCE, key=KEY)

def context(epoch=1):
    return ActorCommandContextV1(
        account_ref=ACCOUNT, runtime_id="r6-qa", mode="simulation",
        config_digest=hashlib.sha256(b"r6-qa-config").hexdigest(),
        session_id="fake-session", front_id=71, native_session_id=81,
        session_generation=1, actor_epoch=epoch,
    )

def bundle(version, available="1000000.00"):
    payloads = {
        "funds": {"available": available, "currency": "CNY"},
        "orders": {"open_order_count": 0},
        "trades": {"trade_count": 0},
        "positions": {"position_count": 0},
    }
    facts = tuple(SnapshotDomainFactV1.from_payload(
        account_ref=ACCOUNT, snapshot_version=version, source_id=SOURCE,
        domain=name, payload=payloads[name]
    ) for name in ("funds", "orders", "trades", "positions"))
    return AccountSnapshotBundleV1(ACCOUNT, version, SOURCE, facts)

def intent(ident, epoch=1):
    return AccountActorIntentV1.from_payload(
        operation="SUBMIT", intent_id=ident, context=context(epoch),
        payload={"instrument": "IF2612", "side": "BUY", "offset": "OPEN",
                 "quantity": 1, "limit_price": "1.0"},
    )

def setup(db, version=77, available="1000000.00"):
    core = AccountActorServerCoreV1(db, snapshot_authority=authority())
    writer = core.claim_writer(ACCOUNT, "r6-writer")
    core.bind_session(writer, context(writer.epoch))
    core.publish_snapshot(writer, bundle(version, available))
    return core, writer

def err(call):
    try:
        call()
    except ActorServerError as exc:
        return exc.code
    return "NO_ERROR"

results = {"module_origins": {
    "account_actor_port": str(Path(account_actor_port.__file__).resolve()),
    "account_actor_server_core": str(Path(core_module.__file__).resolve()),
}}

# New snapshot revokes old available outbox; re-authorization and old claim reject.
with tempfile.TemporaryDirectory(prefix="r6-stale-auth-") as td:
    db = str(Path(td) / "actor.sqlite3")
    core, writer = setup(db)
    core.reserve_intent(writer, intent("stale-v77", writer.epoch), expected_snapshot_version=77)
    old_auth = core.authorize_dispatch(writer, operation="SUBMIT", intent_id="stale-v77")
    core.publish_snapshot(writer, bundle(78, "0.00"))
    replay_error = err(lambda: core.authorize_dispatch(writer, operation="SUBMIT", intent_id="stale-v77"))
    state_after_replay = core.read_dispatch_state(ACCOUNT, "SUBMIT", "stale-v77")
    old_claim_error = err(lambda: core.claim_for_dispatch(writer, old_auth))
    with closing(sqlite3.connect(db)) as connection:
        command_state = connection.execute(
            "SELECT state FROM actor_commands WHERE intent_id='stale-v77'"
        ).fetchone()[0]
    results["v77_to_v78_replay_and_old_claim"] = {
        "replay_error": replay_error,
        "lifecycle_after_replay": state_after_replay,
        "old_claim_error": old_claim_error,
        "command_state": command_state,
        "outbox_rows": core.count_dispatch_rows(ACCOUNT),
    }
    assert replay_error == "dispatch_authorization_stale"
    assert state_after_replay == "REVOKED"
    assert old_claim_error == "dispatch_authorization_not_available"
    assert results["v77_to_v78_replay_and_old_claim"]["command_state"] == "BLOCKED"
    core.close()

# Current four-domain snapshot/HMAC can be fabricated by the explicit test signer.
with tempfile.TemporaryDirectory(prefix="r6-fake-hmac-") as td:
    db = str(Path(td) / "actor.sqlite3")
    core, writer = setup(db, version=77, available="999999999999999999.99")
    proof = authority().attest(bundle(77, "999999999999999999.99"))
    core.reserve_intent(writer, intent("fake-hmac", writer.epoch), expected_snapshot_version=77)
    authorization = core.authorize_dispatch(writer, operation="SUBMIT", intent_id="fake-hmac")
    claim = core.claim_for_dispatch(writer, authorization)
    results["fake_hmac_synthetic_snapshot_claim"] = {
        "proof_type": type(proof).__name__, "proof_bytes": len(proof.proof_hex) // 2,
        "authorization_state": authorization.state, "claim_type": type(claim).__name__,
        "snapshot_version": claim.snapshot_version,
        "local_lifecycle": core.read_dispatch_state(ACCOUNT, "SUBMIT", "fake-hmac"),
    }
    assert claim.snapshot_version == 77 and core.read_dispatch_state(ACCOUNT, "SUBMIT", "fake-hmac") == "CLAIMED"
    core.close()

# Claim pins snapshot/writer in cooperative API and remains permanently fenced after reopen.
with tempfile.TemporaryDirectory(prefix="r6-claimed-fence-") as td:
    db = str(Path(td) / "actor.sqlite3")
    core, writer = setup(db, version=1)
    core.reserve_intent(writer, intent("claimed", writer.epoch), expected_snapshot_version=1)
    authorization = core.authorize_dispatch(writer, operation="SUBMIT", intent_id="claimed")
    claim = core.claim_for_dispatch(writer, authorization)
    publish_error = err(lambda: core.publish_snapshot(writer, bundle(2)))
    revoke_error = err(lambda: core.revoke_writer(writer))
    core.close()
    reopened = AccountActorServerCoreV1(db, snapshot_authority=authority())
    reopened_state = reopened.read_dispatch_state(ACCOUNT, "SUBMIT", "claimed")
    republish_after_reopen_error = err(lambda: reopened.publish_snapshot(writer, bundle(2)))
    results["claimed_snapshot_writer_fence_and_reopen"] = {
        "claim_type": type(claim).__name__, "state_after_reopen": reopened_state,
        "publish_error_before_close": publish_error, "revoke_error_before_close": revoke_error,
        "publish_error_after_reopen": republish_after_reopen_error,
        "outbox_rows": reopened.count_dispatch_rows(ACCOUNT),
    }
    assert reopened_state == "CLAIMED"
    assert publish_error == "dispatch_claim_in_flight"
    assert revoke_error != "NO_ERROR"
    assert republish_after_reopen_error == "dispatch_claim_in_flight"
    reopened.close()

# Same-privilege direct DB writer can undo the local CLAIMED marker and replay claim.
with tempfile.TemporaryDirectory(prefix="r6-same-user-db-tamper-") as td:
    db = str(Path(td) / "actor.sqlite3")
    core, writer = setup(db, version=1)
    core.reserve_intent(writer, intent("tamper-claim", writer.epoch), expected_snapshot_version=1)
    authorization = core.authorize_dispatch(writer, operation="SUBMIT", intent_id="tamper-claim")
    first = core.claim_for_dispatch(writer, authorization)
    with closing(sqlite3.connect(db)) as connection:
        connection.execute("UPDATE actor_dispatch_lifecycle SET state='AVAILABLE' WHERE dispatch_id=?", (first.dispatch_id,))
        connection.commit()
    replay = core.claim_for_dispatch(writer, authorization)
    results["same_privilege_db_writer_resets_claim"] = {
        "first": type(first).__name__, "direct_update": "CLAIMED->AVAILABLE",
        "second": type(replay).__name__, "same_dispatch_id": first.dispatch_id == replay.dispatch_id,
        "final_state": core.read_dispatch_state(ACCOUNT, "SUBMIT", "tamper-claim"),
    }
    assert first.dispatch_id == replay.dispatch_id
    core.close()

# The compatibility migration can be driven by a v1-shaped file and leaves old receipt revoked.
with tempfile.TemporaryDirectory(prefix="r6-v1-migration-") as td:
    db = str(Path(td) / "actor.sqlite3")
    core, writer = setup(db, version=1)
    core.reserve_intent(writer, intent("v1-row", writer.epoch), expected_snapshot_version=1)
    old_auth = core.authorize_dispatch(writer, operation="SUBMIT", intent_id="v1-row")
    core.close()
    with closing(sqlite3.connect(db)) as connection:
        connection.execute("DROP TABLE actor_dispatch_lifecycle")
        connection.execute("PRAGMA user_version=1")
        connection.commit()
    migrated = AccountActorServerCoreV1(db, snapshot_authority=authority())
    with closing(sqlite3.connect(db)) as connection:
        schema_version = connection.execute("PRAGMA user_version").fetchone()[0]
        command_state = connection.execute("SELECT state FROM actor_commands WHERE intent_id='v1-row'").fetchone()[0]
    migrated_lifecycle = migrated.read_dispatch_state(ACCOUNT, "SUBMIT", "v1-row")
    claim_error = err(lambda: migrated.claim_for_dispatch(writer, old_auth))
    replay_error = err(lambda: migrated.authorize_dispatch(writer, operation="SUBMIT", intent_id="v1-row"))
    results["v1_authorization_migrates_revoked"] = {
        "schema_version": schema_version, "command_state": command_state,
        "lifecycle": migrated_lifecycle, "claim_error": claim_error,
        "replay_error": replay_error,
    }
    assert schema_version == 2 and command_state == "BLOCKED" and migrated_lifecycle == "REVOKED"
    assert claim_error == "dispatch_authorization_not_available"
    assert replay_error == "dispatch_authorization_stale"
    migrated.close()

print(json.dumps(results, indent=2, sort_keys=True))

