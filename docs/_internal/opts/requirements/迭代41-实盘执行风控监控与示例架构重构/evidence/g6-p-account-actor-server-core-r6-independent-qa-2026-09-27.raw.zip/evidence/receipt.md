# G6-P Account Actor server core r6 — independent QA

Date: 2026-09-27. Review target is the immutable r6 fake/local candidate only. This is not a deployable account actor or provider integration.

## Source integrity and tests

- Frozen source: `D:\temp\iteration41-g6-account-actor-server-core-freeze-20260927-r6`
- Frozen `manifest.json` SHA-256: `9bc5f75a23db4870123c89c9d8a160c1389495c8fe63a7adb2d4ea6c8b23ac61`
- Independent copy: `D:\temp\iteration41-g6-account-actor-server-core-r6-independent-qa-20260927\candidate`
- Independently verified all **42/42** manifest payload entries for byte length and SHA-256 before tests. `account_actor_port` and `account_actor_server_core` imported from the independent copy.
- Python 3.11.5.
- Full frozen focus: `PYTHONDONTWRITEBYTECODE=1 python -B -m unittest discover -s tests -v` — **56 passed, 0 failed, exit 0**.
- Lifecycle focus: **7 passed, 0 failed, exit 0**, covering snapshot invalidation, v1 migration, multi-process rejection, claim fencing, and post-crash reopen.
- Raw stdout/stderr and exit markers for both runs are archived with the source copy. The r5 counterexample source and original output are retained byte-for-byte in `candidate/r5-counterexample/` as historical evidence.

The full tests include two-process writer-claim contention (one winner), process death with writer ACTIVE, exact intent reservation replay across processes, stale authorization rejection after another process/reopen, a claim that remains CLAIMED after `os._exit` and reopen, v1 authorization migration, and the snapshot/writer freeze while CLAIMED.

## Independent probes

The QA-only probe used fake SQLite files and the explicitly test-only HMAC signer; it called no provider, SDK, native API, network, credential, or account.

| Probe | Observed result |
|---|---|
| Authorize on v77, publish v78, call `authorize_dispatch` again | Rejected `dispatch_authorization_stale`; lifecycle became `REVOKED`, command `BLOCKED`, outbox remained one row. |
| Claim the old v77 authorization after v78 | Rejected `dispatch_authorization_not_available`. |
| Convert a synthetic v2 fixture into the v1 schema shape and reopen | Migrated to schema 2; old command `BLOCKED`, lifecycle `REVOKED`; old claim rejected and authorization replay stale. This exercises the migration path, not a production historical database. |
| After a successful local claim, try publishing a newer snapshot or revoking writer | Both rejected `dispatch_claim_in_flight`. After close/reopen, row remained `CLAIMED`; publishing remained blocked. |
| Fabricate a valid-shape v77 four-domain snapshot with fake HMAC and synthetic funds `999999999999999999.99` CNY | Local authorization and `DispatchClaimV1` both succeeded. The injected fake signer is not an external trust root. |
| Same-permission SQLite update from lifecycle `CLAIMED` to `AVAILABLE`, then reuse the same authorization | A second `DispatchClaimV1` for the same dispatch id succeeded. This demonstrates that a process able to write the local DB can defeat the one-shot lifecycle gate. No provider send was attempted. |

## Boundary and conclusion

The r6 lifecycle closes the r5 stale-authorization replay in the cooperative API: a newer snapshot revokes available outbox rows, replay authorization rechecks the current snapshot, and the local claim is single-use under ordinary API use. It also preserves v1 authorizations as revoked audit history. A CLAIMED row freezes snapshot publication and writer revoke/reclaim across reopen.

The claim cannot be released or recovered. A crash therefore permanently freezes the account in this candidate. The SQLite file remains writable by the same local security principal; the probe above reset CLAIMED and repeated the local claim. The injected HMAC signer can attest fabricated balances. There is no provider dispatch method, authenticated service identity, external account/snapshot authority, or cross-host writer fence. These are material blockers, not passing conditions.

**G6-P remains BLOCKED.** This 56-test r6 local/fake result does not establish an operational actor service, provider truth, cross-host exclusion, or real CTP dispatch. No main production source was changed. No real SDK, provider, credentials, account, or network was touched. This r6 packet does not include or certify any later r6 work-in-progress beyond the exact frozen manifest above.
