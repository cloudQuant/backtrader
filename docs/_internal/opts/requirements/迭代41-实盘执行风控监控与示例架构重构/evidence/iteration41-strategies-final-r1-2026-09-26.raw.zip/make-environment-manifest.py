import hashlib, importlib.metadata as md, importlib.util, json, os, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
repo = Path(r'D:\source_code\backtrader')
run = Path(r'D:\temp\iteration41-main-source-qa-20260926\strategy-final-r1')
map_path = run / 'source-roots-final.json'
source_map = json.loads(map_path.read_text(encoding='utf-8-sig'))
metadata_root = Path(r'D:\temp\iteration41-main-source-qa-20260926\source-only-metadata-r3')
for value in source_map.values():
    p = Path(value)
    if not p.is_absolute() or not p.is_dir(): raise SystemExit(f'invalid source root: {value}')
    sys.path.insert(0, str(p))
source_modules = {
    'parent':'bt_api_py','base':'bt_api_base','ctp':'bt_api_ctp','execution':'bt_api_execution',
    'risk':'bt_api_risk','monitor':'bt_api_monitor','gateway':'bt_api_gateway',
    'transport_zmq':'bt_api_transport_zmq','agent':'backtrader_agent','skills':'backtrader_skills','mcp':'backtrader_mcp'
}
origins = {}
for key, module in source_modules.items():
    spec = importlib.util.find_spec(module)
    origins[key] = None if spec is None else {'origin':spec.origin,'locations':list(spec.submodule_search_locations or [])}
versions = {}
for dist in ['pytest','pytest-xdist','pytest-asyncio','torch','seaborn']:
    try: versions[dist] = md.version(dist)
    except md.PackageNotFoundError: versions[dist] = None
meta = {}
for directory in sorted(metadata_root.glob('*.dist-info')):
    entries={}
    for name in ['METADATA','SOURCE-ONLY.txt']:
        p=directory/name
        if p.is_file(): entries[name]=hashlib.sha256(p.read_bytes()).hexdigest()
    meta[directory.name]=entries
head=subprocess.run(['git','rev-parse','HEAD'],cwd=repo,check=True,capture_output=True,text=True).stdout.strip()
source_status=subprocess.run(['git','status','--short','--untracked-files=all','--','backtrader','tests/functional','tests/datas','tests/fixtures','tests/test_utils','conftest.py','pytest.ini','pyproject.toml','tests/conftest.py'],cwd=repo,check=True,capture_output=True,text=True).stdout.splitlines()
result={
 'created_utc':datetime.now(timezone.utc).isoformat(), 'python_executable':sys.executable,
 'python_version':sys.version, 'platform':platform.platform(), 'pytest_versions':versions,
 'git_head':head,'scoped_git_status':source_status,
 'source_map_path':str(map_path),'source_map_sha256':hashlib.sha256(map_path.read_bytes()).hexdigest(),
 'source_roots':source_map,'top_level_find_spec_origins':origins,
 'source_only_metadata_root':str(metadata_root),'source_only_metadata_files':meta,
 'pytest_sitecustomize_guard':str(run.parent/'origin-guard-r4'/'sitecustomize.py'),
 'guard_sha256':hashlib.sha256((run.parent/'origin-guard-r4'/'sitecustomize.py').read_bytes()).hexdigest(),
 'runner_py_path':'guard-root plus main repo; child integration processes construct ordered roots from the explicit source map',
 'BT_API_PY_LIGHT_IMPORT':'1', 'network_policy':'temporary guard permits literal loopback only; rejects non-loopback/DNS',
 'native_policy':'temporary guard blocks import leaves _ctp and ctp_wrap',
 'provider_policy':'strategy suite does not configure provider clients',
 'private_config_policy':'temporary guard blocks protected runtime-ctp-private/config.yaml reads',
}
out=Path(sys.argv[1]);out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'output':str(out),'created_utc':result['created_utc'],'git_head':head,'python':sys.version.split()[0],'versions':versions,'source_map_sha256':result['source_map_sha256'],'guard_sha256':result['guard_sha256'],'status_count':len(source_status)},sort_keys=True))

