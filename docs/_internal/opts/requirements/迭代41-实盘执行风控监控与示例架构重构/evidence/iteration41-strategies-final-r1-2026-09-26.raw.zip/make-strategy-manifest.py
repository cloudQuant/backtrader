import hashlib, json, subprocess, sys
from pathlib import Path
repo = Path(r'D:\source_code\backtrader')
roots = [
    'backtrader', 'tests/functional', 'tests/datas',
    'tests/fixtures', 'tests/test_utils', 'conftest.py', 'pytest.ini',
    'pyproject.toml', 'tests/conftest.py',
]
files = {}
for root in roots:
    path = repo / root
    if path.is_file():
        candidates = [path]
    elif path.is_dir():
        candidates = [p for p in path.rglob('*') if p.is_file()]
    else:
        continue
    for candidate in candidates:
        rel = candidate.relative_to(repo).as_posix()
        if any(part in {'__pycache__', '.pytest_cache', '.ruff_cache'} for part in candidate.relative_to(repo).parts):
            continue
        if candidate.suffix == '.pyc':
            continue
        files[rel] = hashlib.sha256(candidate.read_bytes()).hexdigest()
head = subprocess.run(['git','rev-parse','HEAD'], cwd=repo, check=True, capture_output=True, text=True).stdout.strip()
status = subprocess.run(['git','status','--short','--untracked-files=all','--',*roots], cwd=repo, check=True, capture_output=True, text=True).stdout.splitlines()
canonical = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
result = {'git_head': head, 'scope_roots': roots, 'file_count': len(files), 'file_sha256': files, 'manifest_sha256': hashlib.sha256(canonical).hexdigest(), 'scoped_git_status': status}
out = Path(sys.argv[1]); out.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
print(json.dumps({'output': str(out), 'git_head': head, 'file_count': len(files), 'manifest_sha256': result['manifest_sha256'], 'scoped_status_count': len(status)}, sort_keys=True))

