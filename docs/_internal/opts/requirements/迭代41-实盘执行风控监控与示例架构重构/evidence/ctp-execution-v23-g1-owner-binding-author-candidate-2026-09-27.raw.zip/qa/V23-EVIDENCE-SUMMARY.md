# V23 G1 owner-binding QA evidence

Status: **local source-candidate pass; independent final review pending**.

- Frozen copy: `D:\temp\iteration41_v23_g1_owner_binding_freeze_20260927-r3`
- Manifest SHA-256: `f94b924e1e20fba6ccfe5bc028d88a0ad541022afb8e9c7a5f66a597687ab330`
- Direct V22 candidate-manifest SHA-256: `8244038ab975f30de6c0ba56c140f033ddd5b5ce5fb3cabc9e60abb7bf24066d`
- Underlying R3r3 + V21 composite SHA-256: `00577665667a33c9a7d62d331c0cad99b0b660790d0b475d0bd8c1b6caa6e2dd`
- Payload integrity: **44/44 hashes match**, all files read-only.

## Test results

- Focused ownership/dispatch/migration/callback/handoff set: **186 passed, 2 skipped, 0 failed** (14.59 s).
- Full `bt_api_execution` package: **322 passed, 2 skipped, 0 failed** (20.97 s).
- The 2 skips are SDK integration tests requiring the absent `bt_api_ctp` package; they are not passes. Both runs logged one existing pytest-asyncio fixture-loop-scope deprecation warning.
- Ruff check on changed files and `compileall` passed. `ruff format --check` reports 11 files would be reformatted; no whole-file formatting changes were applied.

V23 regression coverage includes immutable owner/process binding and exact claim match; no-attestor default closure; wrong/type-confused proof fields; binding rollback; missing-binding claim rejection; generic zero-inflight claim cannot call sender; V22 in-flight claim migration to UNKNOWN/POISONED with no replay; empty database versus malformed/partial schema handling; and owner epoch/restart fencing.

## Scope and limits

The V23 package contains no native request sender. Generic local Store claim can persist `CLAIMED` with `native_call_inflight=0`, but its only candidate sender consumer never invokes the injected sender. A queued READY V2 dispatch without the process-owner adapter is atomically changed to UNKNOWN and poisons the account owner/family before the sender boundary; a failed transaction rolls back, and a committed fence survives reopen.

Main-repo paths remain outside this package candidate: the opt-in account-session candidate calls the session-bound claim at `backtrader_runtime/ctp_i9_account_session_candidate.py:589`, while raw `ReqOrderInsert`/`ReqOrderAction` methods remain at `backtrader/stores/btapistore.py:1941` and `:1949`. No whole-repository G5 closure is claimed.

The process attestor and process-exit verifier are absent by default. Tests use an injected fake; Python-private objects are not an OS trust boundary. No wheel, CTP SDK, provider, credentials/private config, network, or real account was used. **This is not G5 acceptance.** Full commands, skip names and log/JUnit hashes are in `V23-QA-RECEIPT.json`.
