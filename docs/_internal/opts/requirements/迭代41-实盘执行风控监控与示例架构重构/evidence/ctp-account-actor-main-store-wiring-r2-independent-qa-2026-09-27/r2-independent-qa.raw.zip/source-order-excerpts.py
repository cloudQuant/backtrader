import pathlib
root=pathlib.Path(r'D:\temp\iteration41-store-actor-r2-independent-qa-20260927b\candidate')
specs=[('backtrader/stores/btapistore.py',3678,3682),('backtrader/stores/btapistore.py',3740,3755),('backtrader/stores/ctp_account_actor_port.py',442,460)]
lines=[]
for rel,start,end in specs:
 p=root/rel; rows=p.read_text(encoding='utf-8').splitlines()
 lines.append(f'FILE {rel} SHA256 source frozen in candidate manifest; lines {start}-{end}')
 for n in range(start,end+1): lines.append(f'{n}: {rows[n-1]}')
 lines.append('')
out='\n'.join(lines)+'\n'
(root.parent/'source-order-excerpts.txt').write_text(out,encoding='utf-8')
print(out)
