import os, pathlib, sys, unittest.mock
from backtrader.stores.btapistore import BtApiStore, BtApiStoreError

target={'BT_STORE_PROVIDER','BT_GATEWAY_EXCHANGE_TYPE','BT_CTP_EXECUTION_AUTHORIZATION_SECRET'}
reads=[]
orig_get=os.environ.get
class Trap:
    def __getattr__(self,name): raise AssertionError('caller object attribute read: '+name)
    def __str__(self): raise AssertionError('secret string conversion')
    def __bool__(self): raise AssertionError('secret bool conversion')
class ActorTrap(Trap):
    def submit_order(self,*a,**kw): raise AssertionError('actor invoked')
    def cancel_order(self,*a,**kw): raise AssertionError('actor invoked')

def run(label, values):
    reads.clear()
    def get(key, default=None):
        if key in target:
            reads.append(key)
            return values.get(key, default)
        return orig_get(key, default)
    try:
        with unittest.mock.patch.object(os.environ,'get',side_effect=get):
            BtApiStore(provider='ctp', api=Trap(), api_cls=Trap(), backend='direct',
                       config={'execution_authorization_secret':Trap()},
                       account_actor_port=ActorTrap(), account_actor_context=Trap(),
                       account_actor_test_ledger=Trap())
    except BtApiStoreError as exc:
        result=str(exc)
    else:
        result='UNEXPECTED_CONSTRUCTION_SUCCESS'
    loaded=sorted(name for name in sys.modules if name=='bt_api_py' or name.startswith('bt_api_py.') or name in {'_ctp','ctp_wrap'})
    print(label,'error=',result,'environment_reads=',reads,'sdk_modules=',loaded)
    if label=='unset':
        assert result=='external account actor unavailable'
        assert reads==['BT_STORE_PROVIDER','BT_GATEWAY_EXCHANGE_TYPE','BT_STORE_PROVIDER','BT_GATEWAY_EXCHANGE_TYPE']
    if label=='mismatched-provider':
        assert result=='store route ambiguous for account actor handoff'
        assert reads==['BT_STORE_PROVIDER','BT_GATEWAY_EXCHANGE_TYPE','BT_STORE_PROVIDER']
    assert not loaded
run('unset',{})
run('mismatched-provider',{'BT_STORE_PROVIDER':'okx'})
print('ENV_GATE_PROBE_COMPLETE')
