import hashlib,json,pathlib
qa=pathlib.Path(r'D:\temp\iteration41-store-actor-r2-independent-qa-20260927b'); root=qa/'candidate'; manifest=json.loads(pathlib.Path(r'D:\\source_code\\backtrader\\docs\\_internal\\opts\\requirements\\迭代41-实盘执行风控监控与示例架构重构\\evidence\\ctp-account-actor-main-store-wiring-r2-2026-09-27\\candidate-manifest.json').read_text(encoding='utf-8')); files=['backtrader/stores/btapistore.py','backtrader/stores/ctp_account_actor_port.py','tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py','tests/unit/stores/test_managed_execution_store_adapter.py','tests/unit/stores/test_managed_ctp_store_adapter.py','tests/unit/runtime/test_runtime_live_dispatch_guard.py','input-sources/btapistore.py']
rec={x['path']:x for x in manifest['files']}
lines=[]
for rel in files:
 p=root/rel; got=hashlib.sha256(p.read_bytes()).hexdigest(); expected=rec[rel]['sha256'] if rel in rec else None
 ok=expected is None or got==expected
 line=f'{rel} {got} manifest={expected or "not-in-payload-manifest"} match={ok}'
 print(line); lines.append(line)
 if not ok: raise SystemExit(2)
(qa/'source-post-run-hashes.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

