import importlib, importlib.util, pathlib, platform, sys
import pytest
import backtrader
from backtrader.stores import btapistore, ctp_account_actor_port
expected=pathlib.Path.cwd().resolve()
origins={
 'backtrader':pathlib.Path(backtrader.__file__).resolve(),
 'btapistore':pathlib.Path(btapistore.__file__).resolve(),
 'ctp_account_actor_port':pathlib.Path(ctp_account_actor_port.__file__).resolve(),
}
print('python',sys.executable)
print('python_version',sys.version.replace('\n',' '))
print('platform',platform.platform())
print('pytest',pytest.__version__)
for name,path in origins.items():
 print('origin',name,path)
 if not path.is_relative_to(expected): raise SystemExit(f'origin escaped candidate: {name}={path}')
loaded=sorted(name for name in sys.modules if name=='bt_api_py' or name.startswith('bt_api_py.') or name in {'_ctp','ctp_wrap'})
print('native_sdk_modules_loaded',loaded)
if loaded: raise SystemExit('SDK/native import found')
print('SOURCE_ORIGIN_AND_NO_SDK_OK')
