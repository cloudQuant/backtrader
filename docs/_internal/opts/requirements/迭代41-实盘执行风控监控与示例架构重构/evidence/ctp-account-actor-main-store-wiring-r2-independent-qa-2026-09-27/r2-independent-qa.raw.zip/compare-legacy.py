import pathlib, re, xml.etree.ElementTree as ET, json
qa=pathlib.Path(r'D:\temp\iteration41-store-actor-r2-independent-qa-20260927b')
review=pathlib.Path(r'D:\source_code\backtrader\docs\_internal\opts\requirements\迭代41-实盘执行风控监控与示例架构重构\evidence\ctp-account-actor-main-store-wiring-r1-legacy-delta-audit-2026-09-27\r1-test-delta-migration-review.md')
xmlp=qa/'candidate/evidence/r2-independent-legacy-delta.junit.xml'
root=ET.parse(xmlp).getroot()
fail_nodes=[]
for tc in root.iter('testcase'):
    if tc.find('failure') is not None or tc.find('error') is not None:
        fail_nodes.append((tc.get('classname'),tc.get('name')))
text=review.read_text(encoding='utf-8')
rows={}
for line in text.splitlines():
    m=re.match(r'\| `([^`]+)` \| `(FAIL_CLOSED_ASSERTION|EXTERNAL_ACTOR_MIGRATION)` \|',line)
    if m: rows[m.group(1)]=m.group(2)
results=[]; unclassified=[]
for cls,name in fail_nodes:
    base=name.split('[',1)[0]
    disp=rows.get(name) or rows.get(base)
    if disp is None: unclassified.append((cls,name)); continue
    results.append((f'{cls}::{name}',disp))
print('failure_nodes',len(fail_nodes),'table_rows',len(rows),'unclassified',unclassified)
print('disposition_counts', {k:sum(1 for _,v in results if v==k) for k in ('FAIL_CLOSED_ASSERTION','EXTERNAL_ACTOR_MIGRATION')})
for n,d in results: print(d,n)
if len(fail_nodes)!=21 or unclassified or len(rows)!=21: raise SystemExit(2)
counts={k:sum(1 for _,v in results if v==k) for k in ('FAIL_CLOSED_ASSERTION','EXTERNAL_ACTOR_MIGRATION')}
if counts!={'FAIL_CLOSED_ASSERTION':8,'EXTERNAL_ACTOR_MIGRATION':13}: raise SystemExit(3)
(qa/'legacy-disposition-comparison.txt').write_text('\n'.join([f'failure_nodes={len(fail_nodes)} table_rows={len(rows)} unclassified={len(unclassified)}',f'counts={counts}']+[f'{d} {n}' for n,d in results])+'\n',encoding='utf-8')

