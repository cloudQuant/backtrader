import hashlib, json, pathlib, shutil, subprocess, zipfile, sys
repo=pathlib.Path(r'D:\source_code\backtrader')
root=repo/'docs/_internal/opts/requirements/迭代41-实盘执行风控监控与示例架构重构/evidence/ctp-account-actor-main-store-wiring-r2-2026-09-27'
out=pathlib.Path(r'D:\temp\iteration41-store-actor-r2-independent-qa-20260927b')
zip_path=root/'r2-author-candidate.raw.zip'
manifest=json.loads((root/'candidate-manifest.json').read_text(encoding='utf-8'))
index=json.loads((root/'archive-index.json').read_text(encoding='utf-8'))
expected={'archive-index.json':'27da48132a1beb2b3e93b2a711114760abbd1f6d5ed000cde5b35ad9d7916051','candidate-manifest.json':'5b68f9ed2a457e51941bbd60052a100d2e045907b9b2e3bb454482304badd27a','COPY-RECEIPT.json':'e99cfd95d078b15769697bd82ca953af24c61d4b02dec2a994f57316310e238d','r2-author-candidate.raw.zip':'1b6c0a9d03295d9c96548ee63342a6931d7ab7a23e214161c2cde8661739f98a'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for name,want in expected.items():
 actual=sha(root/name)
 if actual.lower()!=want.lower(): raise SystemExit(f'{name} hash mismatch {actual} != {want}')
 print(f'OK SHA {name} {actual}')
with zipfile.ZipFile(zip_path) as z:
 if z.testzip() is not None: raise SystemExit('ZIP CRC test failed')
 names=z.namelist()
 if len(names)!=651 or len(manifest['files'])!=649: raise SystemExit(f'unexpected counts: zip={len(names)} payload={len(manifest["files"])}')
 if index.get('zip_sha256')!=sha(zip_path) or index.get('candidate_manifest_sha256')!=sha(root/'candidate-manifest.json'): raise SystemExit('index digest mismatch')
 members=set(names)
 if set(['candidate-manifest.json','candidate-manifest.sha256'])-members: raise SystemExit('archive manifest members missing')
 for rec in manifest['files']:
  rel=rec['path'].replace('\\','/')
  member='payload/'+rel
  if member not in members: raise SystemExit(f'missing archive payload {member}')
  data=z.read(member)
  if hashlib.sha256(data).hexdigest()!=rec['sha256'] or len(data)!=rec['size_bytes']:
   raise SystemExit(f'payload hash/size mismatch {rel}')
 print(f'OK ZIP testzip; {len(names)} members; all {len(manifest["files"])} payload hashes/sizes match')
 candidate=out/'candidate'
 candidate.mkdir()
 for rec in manifest['files']:
  rel=pathlib.PurePosixPath(rec['path'])
  if rel.is_absolute() or '..' in rel.parts: raise SystemExit(f'unsafe path {rel}')
  dst=candidate.joinpath(*rel.parts)
  dst.parent.mkdir(parents=True,exist_ok=True)
  dst.write_bytes(z.read('payload/'+rec['path'].replace('\\','/')))
print('candidate root',candidate)
base_src=candidate/'input-sources/btapistore.py'
print('exact base Store',sha(base_src), 'expected',manifest['base_store_sha256'])
if sha(base_src)!=manifest['base_store_sha256']: raise SystemExit('base Store digest mismatch')
# Exact-base patch replay in a distinct disposable work directory.
replay=out/'patch-replay'
(replay/'backtrader/stores').mkdir(parents=True)
shutil.copyfile(base_src,replay/'backtrader/stores/btapistore.py')
subprocess.run(['git','init','-q'],cwd=replay,check=True)
patch=candidate/'r2-apply.patch'
print('patch SHA',sha(patch),'expected',manifest['r2_apply_patch_sha256'])
if sha(patch)!=manifest['r2_apply_patch_sha256']: raise SystemExit('patch digest mismatch')
for action in ('--check',''):
 args=['git','-c','core.autocrlf=false','apply']
 if action: args.append(action)
 args.append(str(patch))
 p=subprocess.run(args,cwd=replay,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print('patch replay',action or 'apply','exit',p.returncode,p.stdout.strip())
 if p.returncode: raise SystemExit('patch replay failed')
for rel,want in [('backtrader/stores/btapistore.py',manifest['candidate_store_sha256']),('backtrader/stores/ctp_account_actor_port.py',manifest['candidate_actor_module_sha256']),('tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py',manifest['candidate_test_sha256'])]:
 got=sha(replay/rel)
 print('replayed',rel,got,'match',got==want)
 if got!=want: raise SystemExit(f'patch output mismatch: {rel}')
print('VALIDATION_OK')


