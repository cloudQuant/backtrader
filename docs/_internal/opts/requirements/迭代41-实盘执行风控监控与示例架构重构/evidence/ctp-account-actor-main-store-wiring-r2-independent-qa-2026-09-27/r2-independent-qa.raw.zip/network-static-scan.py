import pathlib,re
root=pathlib.Path(r'D:\temp\iteration41-store-actor-r2-independent-qa-20260927b\candidate')
files=[root/'tests/unit/stores/test_ctp_account_actor_store_wiring_candidate.py',root/'tests/unit/stores/test_managed_execution_store_adapter.py',root/'tests/unit/runtime/test_runtime_live_dispatch_guard.py']
patterns=[re.compile(x,re.I) for x in [r'^\s*(?:import|from)\s+(?:socket|requests|httpx|urllib\.request)',r'\b(?:socket\.socket|create_connection|urlopen)\b',r'\brequests\.(?:get|post|put|delete)\b',r'\bhttpx\.(?:get|post|put|delete)\b']]
lines=[]
for p in files:
 for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
  if any(rx.search(line) for rx in patterns): lines.append(f'{p.relative_to(root)}:{i}:{line.strip()}')
print('scanned_files',len(files))
print('direct_network_entrypoint_hits',len(lines))
for line in lines: print(line)
if lines: raise SystemExit(1)
print('STATIC_NO_NETWORK_ENTRYPOINTS_FOUND')
