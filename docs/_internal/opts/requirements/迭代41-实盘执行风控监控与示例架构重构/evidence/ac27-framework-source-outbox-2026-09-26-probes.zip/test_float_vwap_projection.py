from __future__ import annotations
import importlib.util, sys, uuid
from decimal import Decimal
from pathlib import Path

ROOT = Path.cwd(); sys.path.insert(0, str(ROOT))
support_path = ROOT / 'tests' / 'unit' / 'brokers' / 'test_btapibroker_managed_execution_projection.py'
spec = importlib.util.spec_from_file_location('ac27_projection_support', support_path)
assert spec and spec.loader
s = importlib.util.module_from_spec(spec); sys.modules[spec.name] = s; spec.loader.exec_module(s)
base = Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-qa\float-vwap-runs'); base.mkdir(parents=True, exist_ok=True)
runtime = s._ProjectionEventRuntime(base)
provider = s._ResponseProvider([{'status':'accepted','id':'provider.float-fixture'}])
bridge = s.ManagedExecutionBridge(runtime, provider_observation_from_update=s._cumulative_provider_observation)
store, data, broker = s._make_started_stack(runtime, provider, managed_execution_adapter=bridge)
try:
    order = broker.buy(owner=None, data=data, size=4, price=0.2, exectype=s.bt.Order.Limit, **s._managed_info('intent.float-vwap'))
    first = runtime._record_provider_event(s._CumulativeProviderObservation(
        intent_id='intent.float-vwap', state=s._ExecutionState.PARTIALLY_FILLED,
        provider_order_id='provider.float-fixture', filled_quantity=Decimal('1'),
        average_price=Decimal('0.1'), cumulative_commission=Decimal('0.01')))
    broker._drain_store_updates()
    print('after q1', order.executed.size, repr(order.executed.price), repr(order.executed.comm), order.info.get('execution_unknown'))
    second = runtime._record_provider_event(s._CumulativeProviderObservation(
        intent_id='intent.float-vwap', state=s._ExecutionState.PARTIALLY_FILLED,
        provider_order_id='provider.float-fixture', filled_quantity=Decimal('3'),
        average_price=Decimal('0.2'), cumulative_commission=Decimal('0.03')))
    broker._drain_store_updates()
    print('after q3', order.executed.size, repr(order.executed.price), repr(order.executed.comm), order.info.get('execution_unknown'), order.info.get('ledger_mismatch'), broker._managed_provider_projection_failed)
    print('expected exact', 'qty=3 avg=0.2 fee=0.03', 'incremental avg=', (3*0.2-1*0.1)/2, 'event seq=', first.sequence, second.sequence)
finally:
    broker.stop(); bridge.close()
