from __future__ import annotations
import importlib.util, sys, uuid
from decimal import Decimal
from pathlib import Path
ROOT = Path.cwd(); sys.path.insert(0, str(ROOT))
support_path = ROOT / 'tests' / 'unit' / 'brokers' / 'test_btapibroker_managed_execution_projection.py'
spec = importlib.util.spec_from_file_location('ac27_projection_support', support_path)
assert spec and spec.loader
s = importlib.util.module_from_spec(spec); sys.modules[spec.name] = s; spec.loader.exec_module(s)
base = Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-qa\float-vwap-detailed-2'); base.mkdir(parents=True, exist_ok=True)
runtime = s._ProjectionEventRuntime(base)
provider = s._ResponseProvider([{'status':'accepted','id':'provider.float-fixture'}, {'status':'accepted','id':'provider.next-fixture'}])
bridge = s.ManagedExecutionBridge(runtime, provider_observation_from_update=s._cumulative_provider_observation)
store, data, broker = s._make_started_stack(runtime, provider, managed_execution_adapter=bridge)
try:
    order = broker.buy(owner=None, data=data, size=4, price=0.2, exectype=s.bt.Order.Limit, **s._managed_info('intent.float-vwap'))
    for quantity, average, fee in ((1, '0.1', '0.01'), (3, '0.2', '0.03')):
        runtime._record_provider_event(s._CumulativeProviderObservation(
            intent_id='intent.float-vwap', state=s._ExecutionState.PARTIALLY_FILLED,
            provider_order_id='provider.float-fixture', filled_quantity=Decimal(str(quantity)),
            average_price=Decimal(average), cumulative_commission=Decimal(fee)))
        broker._drain_store_updates()
    journal = bridge._framework_projection_journal
    stream = journal._connection.execute(
        'SELECT high_water_sequence, blocked, block_reason FROM framework_projection_source_streams WHERE scope_key=? AND journal_incarnation_id=? AND session_id=?',
        (runtime.scope.key, runtime.journal_generation, runtime.framework_projection_session_id),
    ).fetchone()
    claims = journal._connection.execute(
        'SELECT sequence, event_id, status FROM framework_projection_source_events WHERE scope_key=? AND journal_incarnation_id=? AND session_id=? ORDER BY sequence',
        (runtime.scope.key, runtime.journal_generation, runtime.framework_projection_session_id),
    ).fetchall()
    position = broker.positions[s.DEFAULT_SYMBOL]
    result = {
        'order_status': order.getstatusname(),
        'executed_qty': order.executed.size,
        'executed_avg_repr': repr(order.executed.price),
        'executed_fee_repr': repr(order.executed.comm),
        'exbits': [{'size': bit.size, 'price': bit.price, 'comm': bit.comm} for bit in order.executed.exbits],
        'position_size': position.size,
        'position_price': position.price,
        'execution_unknown': order.info.get('execution_unknown'),
        'ledger_mismatch': order.info.get('ledger_mismatch'),
        'broker_session_failed': getattr(broker, "_managed_provider_projection_failed", False),
        'source_stream': dict(stream) if stream is not None else None,
        'source_receipts': [dict(row) for row in claims],
        'provider_submissions_before_next': len(provider.submitted_orders),
    }
    next_order = s._submit(broker, data, 'intent.float-next')
    result.update({'next_order_status': next_order.getstatusname(), 'next_order_error': next_order.info.get('error_code'), 'provider_submissions_after_next': len(provider.submitted_orders)})
    print(result)
finally:
    broker.stop(); bridge.close()
