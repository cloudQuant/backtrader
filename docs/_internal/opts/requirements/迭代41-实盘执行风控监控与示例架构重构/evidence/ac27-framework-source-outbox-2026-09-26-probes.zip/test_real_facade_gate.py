from __future__ import annotations
import importlib, importlib.util, sys, uuid
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
support_path = ROOT / 'tests' / 'unit' / 'brokers' / 'test_btapibroker_managed_execution_projection.py'
spec = importlib.util.spec_from_file_location('ac27_projection_support', support_path)
assert spec and spec.loader
support = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = support
spec.loader.exec_module(support)
execution = importlib.import_module('bt_api_execution')
base = Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-qa\real-facade-runs')
base.mkdir(parents=True, exist_ok=True)

for mode in ('reject', 'block'):
    case = base / mode
    case.mkdir(exist_ok=True)
    scope = execution.ExecutionScope('fixture', 'offline', 'account.ac27.' + mode, 'strategy.ac27.' + mode, '20260926')
    execution_store = execution.SqliteExecutionStore(case / 'execution.sqlite3')
    provider = support._ResponseProvider([])
    class Gate:
        def reserve(self, _intent):
            if mode == 'reject':
                raise execution.AdmissionDenied()
            return None
    facade = execution.ManagedExecutionFacade(execution_store, scope, writer_id='writer.ac27.' + mode, admission_gate=Gate())
    runtime = support.SimpleNamespace(
        execution=execution,
        scope=scope,
        state_directory=case,
        framework_projection_session_id=uuid.uuid4().hex,
        execution_store=execution_store,
        facade=facade,
        submit=lambda intent, dispatcher: facade.submit(intent, dispatcher),
    )
    bridge = support.ManagedExecutionBridge(runtime, provider_observation_from_update=support._cumulative_provider_observation)
    _store, data, broker = support._make_started_stack(runtime, provider, managed_execution_adapter=bridge)
    try:
        intent_id = 'intent.actual-gate-' + mode
        order = support._submit(broker, data, intent_id)
        record = execution_store.get(intent_id, scope=scope)
        assert record.state is (execution.ExecutionState.REJECTED if mode == 'reject' else execution.ExecutionState.BLOCKED)
        assert record.dispatch_attempts == 0
        assert record.provider_order_id is None and record.filled_quantity == 0
        assert provider.submitted_orders == []
        assert order.executed.size == 0
        broker._drain_store_updates()
        events = execution_store.read_outbox(scope=scope)
        expected = 'intent_rejected' if mode == 'reject' else 'intent_blocked'
        assert [event.event_type for event in events][-1] == expected
        assert bridge._source_projection_blocked is False
        assert bridge._framework_projection_journal.source_high_water(
            scope_key=scope.key,
            journal_incarnation_id=execution_store.journal_source_identity()['generation'],
            session_id=runtime.framework_projection_session_id,
        ) == events[-1].sequence
        print(f'{mode}: PASS; event={expected}; provider_calls={len(provider.submitted_orders)}; cursor={events[-1].sequence}', flush=True)
    finally:
        broker.stop()
        bridge.close()
        facade.close()
        execution_store.close()
print('actual facade risk rejection/block lifecycle checks: 2/2 passed', flush=True)
