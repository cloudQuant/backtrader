from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
MODULE_PATH = ROOT / "tests" / "unit" / "brokers" / "test_btapibroker_managed_execution_projection.py"
spec = importlib.util.spec_from_file_location("ac27_projection_test_support", MODULE_PATH)
assert spec is not None and spec.loader is not None
support = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = support
spec.loader.exec_module(support)


def _update(order, *, quantity="1", average="100", commission="0.05"):
    return {
        "kind": "order",
        "bt_order_ref": order.ref,
        "data_name": support.DEFAULT_SYMBOL,
        "side": "buy",
        "status": "partial",
        "id": "provider.event-fixture",
        "filled": quantity,
        "avg_price": average,
        "cumulative_commission": commission,
    }


def _assert_unknown_and_unbooked(broker, order):
    assert order.executed.size == pytest.approx(0.0)
    assert order.executed.comm == pytest.approx(0.0)
    assert order.info["execution_unknown"] is True
    assert order.status != order.Rejected
    assert broker._managed_provider_projection_failed is True


def test_read_outbox_failure_fences_before_booking(tmp_path):
    runtime, _provider, _store, _data, broker, order = support._make_provider_event_stack(tmp_path)
    try:
        def fail_read(**_kwargs):
            raise OSError("injected local journal read failure")

        runtime.execution_store.read_outbox = fail_read
        broker._drain_store_updates()
        _assert_unknown_and_unbooked(broker, order)
        assert runtime._source_sequence == 0
    finally:
        broker.stop()


def test_claim_failure_fences_before_broker_mutation(tmp_path):
    runtime, provider, _store, _data, broker, order = support._make_provider_event_stack(tmp_path)
    bridge = broker.store._managed_execution_adapter
    try:
        journal = bridge._framework_projection_journal

        def fail_claim(**_kwargs):
            raise support.FrameworkProjectionRecoveryError("injected claim transaction failure")

        journal.claim_source_event = fail_claim
        support._push_cumulative_update(
            provider, order, quantity="1", average="100", commission="0.05"
        )
        broker._drain_store_updates()
        _assert_unknown_and_unbooked(broker, order)
        assert runtime._source_sequence == 1
        assert bridge._source_projection_blocked is True
    finally:
        broker.stop()


def test_completion_failure_after_apply_keeps_fill_unknown_and_fences(tmp_path):
    runtime, _provider, _store, _data, broker, order = support._make_provider_event_stack(tmp_path)
    bridge = broker.store._managed_execution_adapter
    try:
        assert bridge.prepare_managed_provider_projection(_update(order), order) is None
        journal = bridge._framework_projection_journal

        def fail_complete(_claim):
            raise support.FrameworkProjectionRecoveryError("injected receipt commit failure")

        journal.complete_source_event = fail_complete
        broker._drain_store_updates()
        assert order.executed.size == pytest.approx(1.0)
        assert order.executed.price == pytest.approx(100.0)
        assert order.executed.comm == pytest.approx(0.05)
        assert order.info["execution_unknown"] is True
        assert order.info["ledger_mismatch"] is True
        assert order.status != order.Rejected
        assert broker._managed_provider_projection_failed is True
        assert bridge._source_projection_blocked is True
    finally:
        broker.stop()


def test_active_event_identity_collision_fences_without_booking(tmp_path):
    runtime, _provider, _store, _data, broker, order = support._make_provider_event_stack(tmp_path)
    bridge = broker.store._managed_execution_adapter
    try:
        assert bridge.prepare_managed_provider_projection(_update(order), order) is None
        claimed_update = bridge.poll_managed_provider_outbox_update()
        assert claimed_update is not None
        assert order.executed.size == pytest.approx(0.0)
        original = runtime._outbox[0]
        changed = SimpleNamespace(
            sequence=original.sequence,
            event_id=original.event_id,
            intent_id=original.intent_id,
            scope_key=original.scope_key,
            event_type=original.event_type,
            state=original.state,
            created_at_ns=original.created_at_ns,
            journal_incarnation_id=original.journal_incarnation_id,
            payload={**original.payload, "average_price": "101"},
        )
        intent = bridge.intent_from_order(order, runtime)
        with pytest.raises(support.ManagedExecutionBindingError, match="could not be claimed"):
            bridge._claim_provider_event(changed, claimed_update, order, intent)
        assert bridge._source_projection_blocked is True
        assert order.executed.size == pytest.approx(0.0)
    finally:
        broker.stop()
