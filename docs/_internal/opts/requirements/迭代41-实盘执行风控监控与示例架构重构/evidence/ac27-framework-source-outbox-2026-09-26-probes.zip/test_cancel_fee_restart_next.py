from __future__ import annotations
import importlib.util, sys, uuid
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
support_path=ROOT/'tests'/'unit'/'brokers'/'test_btapibroker_managed_execution_projection.py'
spec=importlib.util.spec_from_file_location('ac27_projection_support',support_path);assert spec and spec.loader
s=importlib.util.module_from_spec(spec);sys.modules[spec.name]=s;spec.loader.exec_module(s)
base=Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-qa\cancel-restart-next');base.mkdir(parents=True,exist_ok=True)
runtime, first_provider, _store, data, first_broker, order=s._make_provider_event_stack(
    base,responses=[{'status':'accepted','id':'provider.event-fixture'},{'status':'accepted','id':'provider.next-fixture'}])
first_bridge=first_broker.store._managed_execution_adapter
try:
    first=runtime._record_provider_event(s._CumulativeProviderObservation(
        intent_id='intent.provider-events',state=s._ExecutionState.PARTIALLY_FILLED,provider_order_id='provider.event-fixture',
        filled_quantity=Decimal('0.75'),average_price=Decimal('50001.25'),cumulative_commission=Decimal('-0.125')))
    first_broker._drain_store_updates()
    assert first.sequence==1 and order.executed.size==0.75 and order.executed.comm==-0.125
    runtime._record_provider_event(s._CumulativeProviderObservation(
        intent_id='intent.provider-events',state=s._ExecutionState.PARTIALLY_FILLED,provider_order_id='provider.event-fixture',
        filled_quantity=Decimal('1.25'),average_price=Decimal('50002.50'),cumulative_commission=None))
    runtime._source_sequence += 1
    runtime._outbox.append(SimpleNamespace(
        sequence=runtime._source_sequence,event_id='source-event.cancelled-with-unknown-fee',intent_id='intent.provider-events',
        scope_key=runtime.scope.key,event_type='cancelled_by_cancel_intent',state=s._ExecutionState.CANCELLED,
        created_at_ns=1_900_000_000_000_000_000+runtime._source_sequence,journal_incarnation_id=runtime.journal_generation,
        payload={'cancel_id':'cancel.fixture','provider_order_id':'provider.event-fixture','source':'provider',
                 'filled_quantity':'1.25','average_price':'50002.50','cumulative_commission':None}))
    first_broker._drain_store_updates()
    assert order.executed.size==0.75 and order.executed.comm==-0.125
    assert order.status==s.bt.Order.Partial
    first_cursor=first_bridge._framework_projection_journal.source_high_water(
        scope_key=runtime.scope.key,journal_incarnation_id=runtime.journal_generation,session_id=runtime.framework_projection_session_id)
    assert first_cursor==1
finally:
    first_broker.stop();first_bridge.close()

# SDK current row deliberately disagrees with the immutable event history.
runtime.records['intent.provider-events']=SimpleNamespace(
    state=s._ExecutionState.FILLED,provider_order_id='provider.event-fixture',filled_quantity=Decimal('2'),
    average_price=Decimal('999'),cumulative_commission=Decimal('9.99'),unknown_reason=None)
fee=runtime._record_provider_event(s._CumulativeProviderObservation(
    intent_id='intent.provider-events',state=s._ExecutionState.CANCELLED,provider_order_id='provider.event-fixture',
    filled_quantity=Decimal('1.25'),average_price=Decimal('50002.50'),cumulative_commission=Decimal('-0.185')))
assert fee.sequence==4 and fee.event_type=='provider_commission_evidence'
runtime.framework_projection_session_id=uuid.uuid4().hex
restarted_bridge=s.ManagedExecutionBridge(runtime,provider_observation_from_update=s._cumulative_provider_observation)
next_provider=s._ResponseProvider([{'status':'accepted','id':'provider.next-fixture'}])
_store, restarted_data, restarted_broker=s._make_started_stack(runtime,next_provider,managed_execution_adapter=restarted_bridge)
try:
    recovered=s._submit(restarted_broker,restarted_data,'intent.provider-events')
    assert recovered.executed.size==0.0
    assert next_provider.submitted_orders==[]
    restarted_broker._drain_store_updates()
    assert recovered.status==s.bt.Order.Canceled
    assert recovered.executed.size==1.25
    assert recovered.executed.price==s.pytest.approx(50002.50)
    assert recovered.executed.comm==s.pytest.approx(-0.185)
    assert [bit.size for bit in recovered.executed.exbits]==s.pytest.approx([0.75,0.5])
    assert [bit.price for bit in recovered.executed.exbits]==s.pytest.approx([50001.25,50004.375])
    assert [bit.comm for bit in recovered.executed.exbits]==s.pytest.approx([-0.125,-0.06])
    assert getattr(restarted_broker,'_managed_provider_projection_failed',False) is False
    cursor=restarted_bridge._framework_projection_journal.source_high_water(
        scope_key=runtime.scope.key,journal_incarnation_id=runtime.journal_generation,session_id=runtime.framework_projection_session_id)
    assert cursor==4
    next_order=s._submit(restarted_broker,restarted_data,'intent.next-after-restart')
    runtime._record_provider_event(s._CumulativeProviderObservation(
        intent_id='intent.next-after-restart',state=s._ExecutionState.ACKED,provider_order_id='provider.next-fixture',
        filled_quantity=Decimal('0'),average_price=None,cumulative_commission=Decimal('0')))
    restarted_broker._drain_store_updates()
    assert next_order.status==s.bt.Order.Accepted and next_order.executed.size==0
    assert restarted_bridge._framework_projection_journal.source_high_water(
        scope_key=runtime.scope.key,journal_incarnation_id=runtime.journal_generation,session_id=runtime.framework_projection_session_id)==5
    assert next_provider.submitted_orders and len(next_provider.submitted_orders)==1
    print({'first_session_cursor_before_crash':first_cursor,'restart_recovered_status':recovered.getstatusname(),
           'recovered_qty':recovered.executed.size,'recovered_avg':recovered.executed.price,
           'recovered_fee':recovered.executed.comm,'recovered_exbits':[(b.size,b.price,b.comm) for b in recovered.executed.exbits],
           'latest_record_was_mismatched':True,'fresh_provider_calls_for_recovered_intent':0,
           'next_order_status':next_order.getstatusname(),'restart_cursor_after_next_ack':5})
finally:
    restarted_broker.stop();restarted_bridge.close()
