from __future__ import annotations
import importlib.util, sys
from decimal import Decimal
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
support_path=ROOT/'tests'/'unit'/'brokers'/'test_btapibroker_managed_execution_projection.py'
spec=importlib.util.spec_from_file_location('ac27_projection_support',support_path);assert spec and spec.loader
s=importlib.util.module_from_spec(spec);sys.modules[spec.name]=s;spec.loader.exec_module(s)
base=Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-qa\large-quantity-price-resolution');base.mkdir(parents=True,exist_ok=True)
runtime=s._ProjectionEventRuntime(base)
provider=s._ResponseProvider([{'status':'accepted','id':'provider.large-fixture'}])
bridge=s.ManagedExecutionBridge(runtime,provider_observation_from_update=s._cumulative_provider_observation)
_store,data,broker=s._make_started_stack(runtime,provider,managed_execution_adapter=bridge)
try:
    order=broker.buy(owner=None,data=data,size=1000000000000002,price=1.0,exectype=s.bt.Order.Limit,**s._managed_info('intent.large-resolution'))
    for quantity,average,commission in (
        ('1000000000000000','1','0.1'),
        ('1000000000000001','1.0000000000000001','0.2'),
    ):
        runtime._record_provider_event(s._CumulativeProviderObservation(
            intent_id='intent.large-resolution',state=s._ExecutionState.PARTIALLY_FILLED,
            provider_order_id='provider.large-fixture',filled_quantity=Decimal(quantity),
            average_price=Decimal(average),cumulative_commission=Decimal(commission)))
        broker._drain_store_updates()
    actual_notional=sum(Decimal(str(abs(bit.size)))*Decimal(str(bit.price)) for bit in order.executed.exbits)
    source_notional=Decimal('1000000000000000')*Decimal('1') + Decimal('1')*Decimal('1.1')
    print({
        'status':order.getstatusname(),'executed_qty':order.executed.size,'avg_repr':repr(order.executed.price),
        'fee_repr':repr(order.executed.comm),'exbits':[{'size':b.size,'price':b.price,'comm':b.comm} for b in order.executed.exbits],
        'source_average_q2':'1.0000000000000001','source_implied_incremental_price':'1.1000000000000001',
        'actual_incremental_price':order.executed.exbits[-1].price,'actual_notional_decimal_from_exbits':str(actual_notional),
        'source_notional_decimal':str(source_notional),'execution_unknown':order.info.get('execution_unknown'),
        'ledger_mismatch':order.info.get('ledger_mismatch'),'session_failed':getattr(broker,'_managed_provider_projection_failed',False),
        'source_high_water':bridge._framework_projection_journal._connection.execute('SELECT high_water_sequence FROM framework_projection_source_streams WHERE scope_key=? AND journal_incarnation_id=? AND session_id=?',(runtime.scope.key,runtime.journal_generation,runtime.framework_projection_session_id)).fetchone()['high_water_sequence']
    })
finally:
    broker.stop();bridge.close()
