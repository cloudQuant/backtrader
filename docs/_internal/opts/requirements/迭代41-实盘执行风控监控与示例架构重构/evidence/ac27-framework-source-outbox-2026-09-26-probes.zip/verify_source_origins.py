import importlib.util
import os
import platform
import sys

print('python', sys.version.replace('\n', ' '))
print('platform', platform.platform())
print('PYTHONPATH', os.environ.get('PYTHONPATH'))
print('BT_API_PY_LIGHT_IMPORT', os.environ.get('BT_API_PY_LIGHT_IMPORT'))
for name in ('bt_api_execution', 'bt_api_base'):
    spec = importlib.util.find_spec(name)
    print('spec', name, None if spec is None else spec.origin)
    print('locations', name, None if spec is None else list(spec.submodule_search_locations or ()))
print('already_loaded_sdk_modules', sorted(n for n in sys.modules if n == 'bt_api_execution' or n == 'bt_api_base' or n == '_ctp' or n == 'ctp_wrap' or n.startswith('bt_api_execution.') or n.startswith('bt_api_base.')))
print('native_extension_attempted', any(n == '_ctp' or n == 'ctp_wrap' for n in sys.modules))
