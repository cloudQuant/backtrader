# Fraction projection review — AC27

Read-only review performed against the source identified in `README.md`; no repository changes made.

## Arithmetic and side handling

`ManagedExecutionBridge._source_projection_pre_apply_facts` in `backtrader_runtime/managed_execution.py` computes exact source deltas from immutable cumulative Decimal snapshots using `Fraction`: the new cumulative notional (`filled * average`) minus the prior cumulative notional, divided by the exact positive quantity delta. The first fill uses the event average directly. Cumulative commission is differenced as a signed Fraction. Each increment is converted to binary64 once, with non-finite and nonzero-underflow values rejected before claim. The source cumulative average/commission stay hidden claim-bound fields; only the exact incremental `price` and normalized incremental `commission` reach Broker.

The source quantity is absolute/cumulative; order side is separately canonicalized from the actual Backtrader order. `_provider_event_broker_update` carries the submitted side into the projection. Broker applies the execution size with sign based on side. This makes the same positive exact price calculation valid for BUY and SELL, while commission deltas retain their source sign.

## Existing tests and intended fee-only behavior

The 64-test focus includes:

- `test_same_quantity_commission_rebate_is_applied_as_signed_cumulative_delta` — negative signed fee delta on a quantity-growing fill.
- `test_missing_fee_stays_unknown_until_later_same_quantity_fee_event` — does not book a fill while fee is unknown; event-time fee evidence at the same cumulative quantity then books it once.
- `test_changed_fee_after_quantity_was_booked_fences_without_adjustment` — same-quantity fee mutation after booking is explicitly rejected/fenced because this projection does not support an unbooked commission-only adjustment.
- `test_missing_fee_growth_and_cancel_wait_for_event_time_fee_evidence` — missing fee does not reuse the previous fee or let cancellation overtake the unresolved immutable fill facts.

The implementation rejects changed average/commission at an already-booked same quantity. That is fail-closed and consistent with the tested policy. It does not silently discard a newly changed fee or fabricate a correction.

## Side / close evidence

The preexisting AC27 focus tests use `broker.buy` for cumulative precision cases and do not themselves prove the SELL-side signed execution or reverse-position-close behavior. The supplemental temp-only `sell-close-fraction-probe.py` provides this missing narrow evidence:

- Buy-open long, Sell-close-long, Sell-open-short, Buy-close-short.
- Cumulative SELL fills pass positive quantities into Fraction arithmetic, but Broker exbits and order execution are signed negative.
- Both directions close the position to zero; SELL cumulative fee deltas include negative increments and are preserved on the matching execution bits.
- All immutable source events apply through sequence 7 without UNKNOWN, ledger mismatch, or session fence.

## Result and limit

No Fraction-specific regression was found in negative-side/sell or opposite-side position closing. Fee-only updates are supported only to resolve a fee-unknown fill that has not yet been booked; post-booking same-quantity fee changes intentionally fence. The supplemental side/close test is an independent temp QA probe, not a committed regression test. The main AC27 focus remains **64 passed**; this evidence does not claim an execution package-wide acceptance.

## Source/test references
- Exact Decimal→Fraction quantity/notional/fee deltas and one-time float conversion: `backtrader_runtime/managed_execution.py:2008-2048`.
- Separate side propagation from immutable outbox event into Broker update: `backtrader_runtime/managed_execution.py:2492-2516`; Broker signed fill uses order side at `backtrader/brokers/btapibroker.py:7893` and `_trade_update_is_buy` at `8482`.
- Existing signed-rebate and same-quantity fee evidence tests: `tests/unit/brokers/test_btapibroker_managed_execution_projection.py:1576`, `1604`, `1635`, and event-time fee/cancel evidence at `2284`.
