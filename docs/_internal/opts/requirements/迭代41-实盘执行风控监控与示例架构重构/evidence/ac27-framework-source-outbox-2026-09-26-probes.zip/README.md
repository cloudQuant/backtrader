# AC27 QA evidence bundle

Captured 2026-09-26 local time. This bundle was assembled outside the repository at `C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-evidence-20260926`.

## Reproducible target run

- Interpreter: Python 3.11.5 from `C:\Users\yunji\AppData\Local\Temp\bt-pytest-asyncio-compat-20260926\Scripts\python.exe`.
- `PYTHONPATH` order: execution `src`, pinned base `src`, then main repository.
- `BT_API_PY_LIGHT_IMPORT=1`.
- Command: see `ac27-focus-retry.stdout.txt`; it runs the three frozen target modules with `-q` and writes JUnit XML to `ac27-focus.junit.xml`.
- Result: **64 passed in 4.69s, exit code 0**.
- The first capture attempt is preserved as `ac27-focus.stdout.txt`. It failed before collection (pytest received a malformed `--junitxml=(Join-Path...)` argument; 0 tests, exit 4). The successful retry corrected PowerShell argument construction. This was a capture-command issue, not a test failure.

## Supplemental local fake probes

The source scripts copied from `C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-qa` are included. These scripts use the repository’s fake runtime/provider fixtures and local SQLite only. Their original stdout was not redirected when first run, so the recorded values below are transcribed from the QA tool output; `sell-close-fraction-probe.stdout.txt` is the directly captured output for the added side/close probe.

- `test_float_vwap_detailed.py`: order Partial, qty 3, exbits `(1, 0.1, 0.01)` and `(2, 0.25, 0.02)`; source receipts 1 and 2 are APPLIED, high-water 2, no UNKNOWN/ledger mismatch/fence; next order Accepted, fake submissions 1→2.
- `test_float_fee_detailed.py`: cumulative fee `.1 → -.3` projected as exbit deltas `.1, -.4`; total `-.30000000000000004`; both receipts APPLIED/high-water 2, no UNKNOWN/ledger mismatch/fence; next order Accepted.
- `test_large_quantity_price_resolution.py`: source `1e15 @ 1` then cumulative `1e15+1 @ 1.0000000000000001`; second exbit `(qty=1, price=1.1)`. Exbit-derived notional `1000000000000001.10` equals source notional `1000000000000001.1`; high-water 2, no UNKNOWN/mismatch/fence.
- `test_large_cumulative_fee_delta.py`: cumulative fee `1e12 → 1e12.0001`; second exbit commission `.0001`, total `1000000000000.0001`; both receipts APPLIED/high-water 2, next order Accepted.
- `test_real_facade_gate.py`: actual facade reject and block cases both PASS; respective immutable event types `intent_rejected` / `intent_blocked`, provider calls 0, cursor 2.
- `test_cancel_fee_restart_next.py`: after fee becomes unknown, no additional fill booked until later same-quantity commission evidence. Fresh session ignores deliberately mismatched latest record; recovers Canceled, qty `1.25`, avg `50002.5`, fee `-.185`, exbits `(0.75, 50001.25, -.125)` and `(0.5, 50004.375, -.06)`. Provider calls for replayed intent 0; cursor 4, next order Accepted and cursor 5.
- `test_ac27_fault_injection.py`: **4 passed, 1 existing pytest-asyncio config warning** using `--rootdir`, `--confcutdir`, and `--noconftest` set to the temp QA directory. Covers outbox-read and claim errors before booking, completion error after booking (UNKNOWN + ledger mismatch, not Rejected), and active event identity/payload collision before booking. An initial invocation without those root options hit a Windows `C:\Documents and Settings` collection permission error; the corrected bounded invocation ran the four tests successfully.

## Source-only side/Fraction probe

`sell-close-fraction-probe.py` submits fake local Buy-open, Sell-close-long, Sell-open-short, and Buy-close-short orders through the real Broker projection bridge. Each sell/buy close projection includes two cumulative quantity observations, exercising Fraction-derived incremental notional and signed fee deltas.

Result (full directly captured output is in `sell-close-fraction-probe.stdout.txt`):

- Buy-open produced position `+2`.
- Sell-close-long produced signed execution `-2`, exbits `(-1,100,.02)` and `(-1,101,-.01)`, position `0`.
- Sell-open-short produced signed execution `-2`, exbits `(-1,102,.03)` and `(-1,101,-.01)`, position `-2`.
- Buy-close-short produced execution `+2`, exbits `(1,99,.01)` and `(1,97,-.005)`, position `0`.
- All orders Completed, final source high-water 7, projection remained unblocked, Broker session did not fail.

The existing 64-test focus has fee-only evidence coverage: missing-fee growth waits for an event-time fee snapshot; a same-quantity later evidence event can resolve the still-unbooked fill; changing a fee after that quantity was already booked fences without an unsupported adjustment. Existing cases also cover a negative signed cumulative fee/rebate. These contracts are not generalized into arbitrary same-quantity economic mutation.

## Source identity

`environment-manifest.txt`, `source-origins.stdout.txt`, and `dependency-source-sha256.txt` record interpreter/platform, source `find_spec` origins, exact source-only dependency Python-file SHA-256 hashes, and dependency checkout state. The execution source checkout was dirty at capture time, so its package-source hashes, rather than HEAD alone, identify imported code. The pinned `bt_api_base` checkout was clean at commit `3de0fa4f6cfe8d1973e9f4b9b47b01254259524f`.

Supplemental script values transcribed from the captured QA tool output are also tabulated in `supplemental-probe-output.txt`; the sell/close probe has direct stdout capture.
