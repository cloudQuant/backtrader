from __future__ import annotations
import importlib.util
import sys
from decimal import Decimal
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
support_path = ROOT / 'tests' / 'unit' / 'brokers' / 'test_btapibroker_managed_execution_projection.py'
spec = importlib.util.spec_from_file_location('ac27_projection_support', support_path)
assert spec and spec.loader
s = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = s
spec.loader.exec_module(s)
base = Path(r'C:\Users\yunji\AppData\Local\Temp\iteration41-ac27-evidence-20260926\sell-close-fraction-probe')
base.mkdir(parents=True, exist_ok=True)
runtime = s._ProjectionEventRuntime(base)
provider = s._ResponseProvider([{'status': 'accepted', 'id': f'provider.sellprobe.{i}'} for i in range(1, 5)])
bridge = s.ManagedExecutionBridge(runtime, provider_observation_from_update=s._cumulative_provider_observation)
_store, data, broker = s._make_started_stack(runtime, provider, managed_execution_adapter=bridge)

def submit(side, size, intent, effect):
    info = s._managed_info(intent)
    info['managed_position_effect'] = effect
    info['offset'] = 'open' if effect == 'OPEN' else 'close'
    info['reduce_only'] = effect != 'OPEN'
    method = broker.buy if side == 'BUY' else broker.sell
    return method(owner=None, data=data, size=size, price=110.0, exectype=s.bt.Order.Limit, **info)

def project(order, intent, provider_id, facts):
    for state, quantity, average, fee in facts:
        runtime._record_provider_event(s._CumulativeProviderObservation(
            intent_id=intent, state=state, provider_order_id=provider_id,
            filled_quantity=Decimal(quantity), average_price=Decimal(average),
            cumulative_commission=Decimal(fee)))
        broker._drain_store_updates()
        assert order.info.get('execution_unknown') is not True
    return order

try:
    buy_open = submit('BUY', 2, 'intent.sellprobe.buy-open', 'OPEN')
    project(buy_open, 'intent.sellprobe.buy-open', 'provider.sellprobe.1', [
        (s._ExecutionState.FILLED, '2', '100', '0.03')])
    assert broker.positions[s.DEFAULT_SYMBOL].size == 2

    sell_close = submit('SELL', 2, 'intent.sellprobe.sell-close', 'CLOSE')
    project(sell_close, 'intent.sellprobe.sell-close', 'provider.sellprobe.2', [
        (s._ExecutionState.PARTIALLY_FILLED, '1', '100', '0.02'),
        (s._ExecutionState.FILLED, '2', '100.5', '0.01')])
    assert broker.positions[s.DEFAULT_SYMBOL].size == 0
    assert sell_close.executed.size == -2
    assert [bit.price for bit in sell_close.executed.exbits] == [100.0, 101.0]
    assert [bit.comm for bit in sell_close.executed.exbits] == [0.02, -0.01]

    sell_open = submit('SELL', 2, 'intent.sellprobe.sell-open', 'OPEN')
    project(sell_open, 'intent.sellprobe.sell-open', 'provider.sellprobe.3', [
        (s._ExecutionState.PARTIALLY_FILLED, '1', '102', '0.03'),
        (s._ExecutionState.FILLED, '2', '101.5', '0.02')])
    assert broker.positions[s.DEFAULT_SYMBOL].size == -2
    assert sell_open.executed.size == -2
    assert [bit.price for bit in sell_open.executed.exbits] == [102.0, 101.0]
    assert [bit.comm for bit in sell_open.executed.exbits] == [0.03, -0.01]

    buy_close = submit('BUY', 2, 'intent.sellprobe.buy-close', 'CLOSE')
    project(buy_close, 'intent.sellprobe.buy-close', 'provider.sellprobe.4', [
        (s._ExecutionState.PARTIALLY_FILLED, '1', '99', '0.01'),
        (s._ExecutionState.FILLED, '2', '98', '0.005')])
    assert broker.positions[s.DEFAULT_SYMBOL].size == 0
    assert buy_close.executed.size == 2
    assert [bit.price for bit in buy_close.executed.exbits] == [99.0, 97.0]
    assert [bit.comm for bit in buy_close.executed.exbits] == [0.01, -0.005]

    journal = bridge._framework_projection_journal
    cursor = journal.source_high_water(
        scope_key=runtime.scope.key,
        journal_incarnation_id=runtime.journal_generation,
        session_id=runtime.framework_projection_session_id,
    )
    assert cursor == 7
    assert bridge._source_projection_blocked is False
    assert getattr(broker, '_managed_provider_projection_failed', False) is False
    print({
        'buy_open': (buy_open.getstatusname(), buy_open.executed.size, buy_open.executed.comm),
        'sell_close': (sell_close.getstatusname(), sell_close.executed.size, sell_close.executed.comm,
                       [(b.size, b.price, b.comm) for b in sell_close.executed.exbits]),
        'sell_open': (sell_open.getstatusname(), sell_open.executed.size, sell_open.executed.comm,
                      [(b.size, b.price, b.comm) for b in sell_open.executed.exbits]),
        'buy_close': (buy_close.getstatusname(), buy_close.executed.size, buy_close.executed.comm,
                      [(b.size, b.price, b.comm) for b in buy_close.executed.exbits]),
        'final_position': broker.positions[s.DEFAULT_SYMBOL].size,
        'source_high_water': cursor,
        'projection_blocked': bridge._source_projection_blocked,
        'broker_session_failed': getattr(broker, '_managed_provider_projection_failed', False),
    })
finally:
    broker.stop()
    bridge.close()
