"""One-off pinned subprocess runner for the Iteration 50 Alpha101 matrix."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

import psutil

ROOT = Path(__file__).resolve().parents[1]
TEST = "tests/integration/test_live_alpha101_matrix.py"
MATRIX_IMPORTS = (
    "backtrader",
    "tests.integration.test_live_alpha101_matrix",
    "tests.test_utils.alpha101_full_reference",
    "tests.test_utils.alpha101_native_harness",
    "tests.test_utils.alpha101_live_cohort_harness",
    "tests.test_utils.alpha101_trace_validation",
    "tests.unit.test_factor_research_representatives",
)
BATCHES = ("promoted_20", "a", "b", "c", "d", "e")
LENGTHS = (320, 640, 1280)
LANES = (
    "batch-native-runnext",
    "batch-native-runonce",
    "batch-build-runnext",
    "batch-build-runonce",
    "live-native-runnext",
    "live-build-runnext",
)
RESERVE = 2 * 1024**3
WORKER_OVERHEAD = 128 * 1024**2
RSS_FACTOR = 1.5
SELECTORS = (
    "BT_ALPHA101_NATIVE_BATCHES",
    "BT_ALPHA101_NATIVE_IDS",
    "BT_LIVE_ALPHA101_LENGTHS",
)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(value, stream, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def source_paths():
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    for module_name in MATRIX_IMPORTS:
        importlib.import_module(module_name)
    found = set()
    for module in tuple(sys.modules.values()):
        module_file = getattr(module, "__file__", None)
        if not module_file:
            continue
        try:
            path = Path(module_file).resolve()
            path.relative_to(ROOT)
        except (OSError, ValueError):
            continue
        if path.is_file() and path.suffix == ".py":
            found.add(path)
    for name in (
        TEST,
        "tests/fixtures/research/alpha101_dependencies.json",
        "tests/unit/test_factor_research_representatives.py",
        "conftest.py",
        "pyproject.toml",
        "pytest.ini",
    ):
        path = ROOT / name
        if path.is_file():
            found.add(path)
    return sorted(found, key=lambda p: p.relative_to(ROOT).as_posix())


def pins():
    return {
        p.relative_to(ROOT).as_posix(): {
            "bytes": len(content := p.read_bytes()),
            "sha256": hashlib.sha256(content).hexdigest(),
        }
        for p in source_paths()
    }


def tree_rss(pid):
    try:
        process = psutil.Process(pid)
        result = process.memory_info().rss
        for child in process.children(recursive=True):
            try:
                result += child.memory_info().rss
            except psutil.Error:
                pass
        return result
    except psutil.Error:
        return 0


def paths_for(out, length, batch):
    stem = "T%d_%s" % (length, batch)
    return out / (stem + ".log"), out / (stem + ".xml"), out / (stem + ".json")


def gate_memory(out):
    available = psutil.virtual_memory().available
    decision_path = out / "memory_decision.json"
    if not decision_path.is_file():
        # The first isolated segment establishes the real RSS sample. Until
        # that measurement exists, allow only one child and reserve 1 GiB for
        # it in addition to the fixed system reserve and worker overhead.
        required = RESERVE + WORKER_OVERHEAD + 1024**3
        return available >= required, available, required
    decision = json.loads(decision_path.read_text(encoding="utf-8"))
    required = RESERVE + WORKER_OVERHEAD * decision["safe_concurrency"] + decision["estimated_child_bytes"]
    return available >= required, available, required


def run_segment(out, baseline, length, batch):
    log_path, xml_path, result_path = paths_for(out, length, batch)
    before = pins()
    record = {
        "length": length,
        "batch": batch,
        "lanes": list(LANES),
        "source_pins_before": before,
    }
    if before != baseline:
        record.update(status="SOURCE_PIN_MISMATCH_BEFORE", return_code=None)
        write_json(result_path, record)
        return record

    while True:
        enough, available, required = gate_memory(out)
        if enough:
            break
        print(json.dumps({
            "event": "waiting_for_memory", "length": length, "batch": batch,
            "available_mib": round(available / 1024**2, 1),
            "required_mib": round(required / 1024**2, 1),
        }, sort_keys=True), flush=True)
        time.sleep(30)

    env = os.environ.copy()
    for key in SELECTORS:
        env.pop(key, None)
    env["BT_ALPHA101_NATIVE_BATCHES"] = batch
    env["BT_LIVE_ALPHA101_LENGTHS"] = str(length)
    command = [
        sys.executable, "-u", "-m", "pytest", "-p", "no:asyncio", TEST,
        "-q", "--tb=short", "--durations=0", "--junitxml=" + str(xml_path),
    ]
    started = time.monotonic()
    record["started_utc"] = datetime.now(timezone.utc).isoformat()
    peak = 0
    heartbeat = started
    with log_path.open("wb") as log:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        record["pid"] = process.pid
        print(json.dumps({
            "event": "segment_started", "pid": process.pid, "length": length, "batch": batch,
        }, sort_keys=True), flush=True)
        while process.poll() is None:
            peak = max(peak, tree_rss(process.pid))
            now = time.monotonic()
            if now - heartbeat >= 60:
                print(json.dumps({
                    "event": "segment_progress", "pid": process.pid, "length": length,
                    "batch": batch, "elapsed_seconds": round(now - started, 1),
                    "peak_rss_mib": round(peak / 1024**2, 1),
                    "available_mib": round(psutil.virtual_memory().available / 1024**2, 1),
                }, sort_keys=True), flush=True)
                heartbeat = now
            time.sleep(2)
        rc = process.returncode
        peak = max(peak, tree_rss(process.pid))

    after = pins()
    match = after == baseline
    record.update(
        status="PASS" if rc == 0 and match else "FAIL",
        return_code=rc,
        elapsed_seconds=round(time.monotonic() - started, 3),
        peak_rss_bytes=peak,
        peak_rss_mib=round(peak / 1024**2, 3),
        source_pins_after=after,
        source_pins_match=match,
        log_path=str(log_path.relative_to(ROOT)),
        log_sha256=hashlib.sha256(log_path.read_bytes()).hexdigest(),
        xml_path=str(xml_path.relative_to(ROOT)) if xml_path.is_file() else None,
        xml_sha256=hashlib.sha256(xml_path.read_bytes()).hexdigest() if xml_path.is_file() else None,
    )
    write_json(result_path, record)
    print(json.dumps({
        "event": "segment_finished", "length": length, "batch": batch,
        "status": record["status"], "return_code": rc,
        "elapsed_seconds": record["elapsed_seconds"], "peak_rss_mib": record["peak_rss_mib"],
        "source_pins_match": match,
    }, sort_keys=True), flush=True)
    return record


def measure(args):
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=False)
    baseline = pins()
    write_json(out / "source_pins_start.json", baseline)
    write_json(out / "run_metadata.json", {
        "root_supplied_dev_head": "99f1b3d265ba5cfa9cddaffc6e3cee55ec25f65c",
        "binding_commit": "1425e3401",
        "operators_commit": "99f1b3d26",
        "batches": list(BATCHES), "lengths": list(LENGTHS),
        "lanes_per_formula_length": list(LANES), "planned_segments": 18,
        "system_memory_reserve_bytes": RESERVE, "source_pin_count": len(baseline),
        "created_utc": datetime.now(timezone.utc).isoformat(),
    })
    print(json.dumps({
        "event": "matrix_start", "out_dir": str(out), "source_pin_count": len(baseline),
        "available_mib": round(psutil.virtual_memory().available / 1024**2, 1),
        "first_segment": "T1280/promoted_20",
    }, sort_keys=True), flush=True)
    result = run_segment(out, baseline, 1280, "promoted_20")
    available = psutil.virtual_memory().available
    measured = max(1, int(result.get("peak_rss_bytes", 0) * RSS_FACTOR))
    budget = max(0, available - RESERVE - WORKER_OVERHEAD * 3)
    safe = min(3, budget // measured)
    decision = {
        "isolated_segment_status": result["status"],
        "isolated_peak_rss_bytes": result.get("peak_rss_bytes", 0),
        "rss_safety_factor": RSS_FACTOR,
        "estimated_child_bytes": measured,
        "available_after_segment_bytes": available,
        "available_after_segment_mib": round(available / 1024**2, 1),
        "reserve_bytes": RESERVE,
        "worker_overhead_reserve_bytes": WORKER_OVERHEAD * 3,
        "safe_concurrency": int(safe),
    }
    write_json(out / "memory_decision.json", decision)
    print(json.dumps({"event": "memory_decision", **decision}, sort_keys=True), flush=True)
    return 0 if result["status"] == "PASS" and safe >= 1 else 2


def worker(args):
    out = Path(args.out_dir).resolve()
    baseline = json.loads((out / "source_pins_start.json").read_text(encoding="utf-8"))
    pending = [batch for batch in BATCHES if not (args.length == 1280 and batch == "promoted_20")]
    results = [run_segment(out, baseline, args.length, batch) for batch in pending]
    return 0 if all(item["status"] == "PASS" for item in results) else 1


def aggregate(args):
    out = Path(args.out_dir).resolve()
    baseline = json.loads((out / "source_pins_start.json").read_text(encoding="utf-8"))
    from tests.test_utils.alpha101_full_reference import formula_ids
    from tests.test_utils.alpha101_native_harness import ALPHA_BATCHES

    expected_ids = set(formula_ids())
    expected = {(length, batch) for length in LENGTHS for batch in BATCHES}
    records = {}
    for length, batch in sorted(expected):
        _, xml_path, result_path = paths_for(out, length, batch)
        if result_path.is_file():
            records[(length, batch)] = json.loads(result_path.read_text(encoding="utf-8"))
            if xml_path.is_file():
                try:
                    root = ET.parse(xml_path).getroot()
                    suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
                    records[(length, batch)]["junit"] = {
                        "tests": sum(int(x.attrib.get("tests", 0)) for x in suites),
                        "failures": sum(int(x.attrib.get("failures", 0)) for x in suites),
                        "errors": sum(int(x.attrib.get("errors", 0)) for x in suites),
                        "skipped": sum(int(x.attrib.get("skipped", 0)) for x in suites),
                    }
                except (OSError, ET.ParseError):
                    records[(length, batch)]["junit"] = {"parse_error": True}
    coverage = {}
    for length in LENGTHS:
        ids = [item for batch in BATCHES for item in ALPHA_BATCHES[batch]]
        duplicates = sorted({item for item in ids if ids.count(item) > 1})
        coverage[str(length)] = {
            "formula_ids": sorted(ids), "unique_count": len(set(ids)),
            "missing_ids": sorted(expected_ids - set(ids)),
            "unexpected_ids": sorted(set(ids) - expected_ids),
            "duplicate_ids": duplicates,
            "coverage_complete": set(ids) == expected_ids and not duplicates,
            "segment_statuses": {
                batch: records.get((length, batch), {}).get("status", "MISSING")
                for batch in BATCHES
            },
        }
    end_pins = pins()
    segments_present = set(records) == expected
    segments_pass = segments_present and all(
        r.get("status") == "PASS" and r.get("source_pins_match")
        and r.get("junit", {}).get("tests") == 1
        and r.get("junit", {}).get("failures") == 0
        and r.get("junit", {}).get("errors") == 0
        and r.get("junit", {}).get("skipped") == 0
        for r in records.values()
    )
    complete = segments_pass and end_pins == baseline and all(
        item["coverage_complete"] for item in coverage.values()
    )
    result = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "full_matrix_complete": complete,
        "expected_formula_count": len(expected_ids),
        "expected_lengths": list(LENGTHS),
        "expected_batches": list(BATCHES),
        "expected_lanes_per_formula_length": list(LANES),
        "expected_segment_count": 18,
        "recorded_segment_count": len(records),
        "all_segments_present": segments_present,
        "all_segments_pass": segments_pass,
        "source_pins_match_start": end_pins == baseline,
        "source_pins_start": baseline,
        "source_pins_end": end_pins,
        "coverage_by_length": coverage,
        "segments": {"%d/%s" % key: value for key, value in sorted(records.items())},
    }
    write_json(out / "aggregate.json", result)
    print(json.dumps({
        "event": "aggregate_finished", "full_matrix_complete": complete,
        "recorded_segment_count": len(records), "all_segments_pass": segments_pass,
        "source_pins_match_start": end_pins == baseline,
        "aggregate_path": str((out / "aggregate.json").relative_to(ROOT)),
    }, sort_keys=True), flush=True)
    return 0 if complete else 1


def main():
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    initial = commands.add_parser("measure")
    initial.add_argument("--out-dir", required=True)
    run = commands.add_parser("worker")
    run.add_argument("--out-dir", required=True)
    run.add_argument("--length", type=int, choices=LENGTHS, required=True)
    finish = commands.add_parser("aggregate")
    finish.add_argument("--out-dir", required=True)
    args = parser.parse_args()
    if args.command == "measure":
        return measure(args)
    if args.command == "worker":
        return worker(args)
    return aggregate(args)


if __name__ == "__main__":
    raise SystemExit(main())
