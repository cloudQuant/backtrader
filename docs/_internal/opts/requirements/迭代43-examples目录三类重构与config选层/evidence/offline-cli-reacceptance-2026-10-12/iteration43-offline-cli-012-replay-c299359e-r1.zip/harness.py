from __future__ import annotations
import ast, datetime as dt, hashlib, json, os, subprocess, sys, tarfile, time, zipfile
from pathlib import Path, PurePosixPath

REPO=Path(r"D:\source_code\backtrader")
BASE=Path(r"D:\temp\iteration43-offline-cli-012-replay-c299359e")
MIRROR=BASE/"mirror"
LOGS=BASE/"logs"
EVIDENCE=BASE/"evidence"
COMMIT="c299359e133452135221b8ad53d11b4e9a0121bb"
ENTRIES=["012_1_midfreq_cross_exchange","012_2_event_driven_cross_exchange"]
CONFIGS={f"examples/unified/{x}/config.yaml" for x in ENTRIES}
STRATEGY_MODULES={"012_1_midfreq_cross_exchange":"cross_exchange_strategy.py","012_2_event_driven_cross_exchange":"event_driven_strategy.py"}
FILTERED_PUBLIC_SOURCES=CONFIGS | {"examples/strategy-candidate-manifest.json"} | {f"examples/unified/{x}/{name}" for x in ENTRIES for name in ("run.py","strategy-candidate-manifest.json","qualification-v3.json",STRATEGY_MODULES[x])}
EXCLUDED={".env",".env.example"}
SAFE_REPLAY={"LOCAL_REPLAY_PASS","FORMULA_CHECK_PASS"}
FORBIDDEN_PREFIXES=("CTP_","SIMNOW_","BINANCE_","OKX_","BT_API_")
RESULT=BASE/"result.json"
MANIFEST=BASE/"source_manifest.json"
ARCHIVE=BASE/"offline-cli-012-replay-c299359e.zip"
ARCHIVE_MANIFEST=BASE/"offline-cli-012-replay-c299359e.json"


def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def git(args:list[str],binary:bool=False)->bytes|str:
    cp=subprocess.run(["git",*args],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False)
    if cp.returncode:raise RuntimeError(f"git {args[0]} exited {cp.returncode}: {cp.stderr.decode('utf-8','replace')[:500]}")
    return cp.stdout if binary else cp.stdout.decode("utf-8","strict")
def current_head()->str:return str(git(["rev-parse","HEAD"])).strip()
def git_cat_filtered(path:str)->bytes:
    return git(["cat-file","--filters",f"{COMMIT}:{path}"],binary=True)

def source_setup()->tuple[dict[str,dict],str]:
    if BASE.exists():raise RuntimeError(f"output path already exists: {BASE}")
    BASE.mkdir(parents=True)
    MIRROR.mkdir()
    LOGS.mkdir()
    EVIDENCE.mkdir()
    git(["cat-file","-e",f"{COMMIT}^{{commit}}"])
    tar_bytes=git(["archive","--format=tar",COMMIT,"backtrader","backtrader_runtime","examples/strategy-candidate-manifest.json",*[f"examples/unified/{x}" for x in ENTRIES]],binary=True)
    expected=set()
    with tarfile.open(fileobj=__import__("io").BytesIO(tar_bytes),mode="r:") as tf:
        for member in tf.getmembers():
            rel=member.name.replace("\\","/")
            path=PurePosixPath(rel)
            if path.is_absolute() or ".." in path.parts:raise RuntimeError(f"unsafe archive path: {rel}")
            if path.name in EXCLUDED or rel in CONFIGS:continue
            if member.isdir():continue
            if not member.isfile():raise RuntimeError(f"unsupported archive member type: {rel}")
            f=tf.extractfile(member)
            if f is None:raise RuntimeError(f"missing archive bytes: {rel}")
            data=f.read()
            if rel in FILTERED_PUBLIC_SOURCES:
                data=git_cat_filtered(rel)
            target=MIRROR.joinpath(*path.parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
            expected.add(rel)
    # Enumerate tracked paths at the frozen commit; never consult checkout config/.env.
    for entry in ENTRIES:
        prefix=f"examples/unified/{entry}"
        raw=git(["ls-tree","-r","--name-only","-z",COMMIT,"--",prefix],binary=True)
        paths=[p.decode("utf-8","strict") for p in raw.split(b"\0") if p]
        if not paths:raise RuntimeError(f"no tracked paths at snapshot for {entry}")
        for rel in paths:
            name=PurePosixPath(rel).name
            if name in EXCLUDED:continue
            if rel in FILTERED_PUBLIC_SOURCES:
                data=git_cat_filtered(rel)
                origin="git-cat-file--filters-frozen-commit"
                target=MIRROR.joinpath(*rel.split("/"))
                target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(data)
            else:
                # git archive already materialized this commit's public source.
                target=MIRROR.joinpath(*rel.split("/"))
                if not target.is_file():raise RuntimeError(f"public archive source missing: {rel}")
                data=target.read_bytes()
                origin="git-archive-frozen-commit"
            expected.add(rel)
    actual_paths={p.relative_to(MIRROR).as_posix() for p in MIRROR.rglob("*") if p.is_file()}
    if actual_paths!=expected:
        raise RuntimeError(f"mirror inventory mismatch extra={len(actual_paths-expected)} missing={len(expected-actual_paths)}")
    manifest={}
    for rel in sorted(expected):
        path=MIRROR.joinpath(*rel.split("/"))
        data=path.read_bytes()
        origin="git-cat-file--filters-frozen-commit" if rel in FILTERED_PUBLIC_SOURCES else "git-archive-frozen-commit"
        manifest[rel]={"origin":origin,"size_bytes":len(data),"sha256":sha(data)}
    summary={"snapshot_commit":COMMIT,"tar_archive_sha256":sha(tar_bytes),"source_file_count":len(manifest),"files":manifest,"configs_loaded_from_checkout":False,"filtered_public_source_commands":[f"git cat-file --filters {COMMIT}:{p}" for p in sorted(manifest) if p in FILTERED_PUBLIC_SOURCES]}
    MANIFEST.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return manifest,sha(tar_bytes)

def mirror_pins(manifest:dict[str,dict])->bool:
    actual={}
    for p in MIRROR.rglob("*"):
        if p.is_file():
            rel=p.relative_to(MIRROR).as_posix(); data=p.read_bytes()
            actual[rel]={"size_bytes":len(data),"sha256":sha(data)}
    if set(actual)!=set(manifest):return False
    return all(actual[k]["size_bytes"]==v["size_bytes"] and actual[k]["sha256"]==v["sha256"] for k,v in manifest.items())

def preflight()->dict:
    records={}
    for entry in ENTRIES:
        run=MIRROR/"examples"/"unified"/entry/"run.py"
        src=run.read_text(encoding="utf-8")
        tree=ast.parse(src,filename=str(run))
        imports=[]
        for node in tree.body:
            if isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
            elif isinstance(node,ast.ImportFrom) and node.module:imports.append(node.module)
        funcs={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
        if not {"main","run_dry","run_replay"}.issubset(funcs):raise RuntimeError(f"preflight missing CLI functions: {entry}")
        provider=[x for x in imports if x=="bt_api_ctp" or x.startswith("bt_api_ctp.") or x=="bt_api_py" or x.startswith("bt_api_py.")]
        offline={}
        for fn in ("run_dry","run_replay"):
            calls=[c.func.id for c in ast.walk(funcs[fn]) if isinstance(c,ast.Call) and isinstance(c.func,ast.Name)]
            offline[fn]={"calls_load_env":"_load_env" in calls,"calls_live_runner":any(x in calls for x in ("run_live","run_live_observe","run_live_account"))}
        if provider or any(x["calls_load_env"] or x["calls_live_runner"] for x in offline.values()):raise RuntimeError(f"offline preflight failed: {entry}")
        records[entry]={"run_py_sha256":sha(run.read_bytes()),"top_level_provider_imports":provider,"offline_functions":offline}
    return records

def env_for_child()->dict[str,str]:
    allowed={"PATH","SYSTEMROOT","WINDIR","TEMP","TMP","LANG","LC_ALL","LC_CTYPE","COMSPEC","USERPROFILE","APPDATA","LOCALAPPDATA","HOMEDRIVE","HOMEPATH","PROCESSOR_ARCHITECTURE","PROCESSOR_IDENTIFIER","PROCESSOR_LEVEL","PROCESSOR_REVISION","NUMBER_OF_PROCESSORS"}
    env={}
    for k,v in os.environ.items():
        u=k.upper()
        if u in allowed or u.startswith("CONDA") or u.startswith("_CONDA"):env[k]=v
    env.update({"PYTHONPATH":str(MIRROR),"PYTHONIOENCODING":"utf-8","PYTHONDONTWRITEBYTECODE":"1","MPLBACKEND":"Agg"})
    return env

def payload_from(raw:bytes)->dict|None:
    for line in reversed(raw.decode("utf-8","replace").splitlines()):
        try:v=json.loads(line.strip())
        except Exception:continue
        if isinstance(v,dict):return v
    return None
def counter_projection(payload:dict|None)->dict:
    keys={"network","provider_sessions","sdk_write_requests","orders","order_write","external_request_counts","provider_requests","provider_calls","sessions"}
    return {k:payload[k] for k in keys if isinstance(payload,dict) and k in payload}

def finite_candidate_diagnostic(entry:str)->dict:
    # Public-only comparison: never read checkout config, private files, or external inputs.
    folder=MIRROR/"examples"/"unified"/entry
    config=folder/"config.yaml"
    manifest_path=folder/"strategy-candidate-manifest.json"
    out={"config_path":str(config),"config_sha256":sha(config.read_bytes()),"manifest_path":str(manifest_path),"manifest_sha256":sha(manifest_path.read_bytes()) if manifest_path.is_file() else None}
    if not manifest_path.is_file():return out
    try:obj=json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        out["manifest_json_parse_error"]=type(exc).__name__;return out
    rows=[]
    def walk(x):
        if isinstance(x,dict):
            if any(k in x for k in ("config_sha256","runner_sha256","strategy_sha256","candidate_sha256")):
                rows.append(x)
            for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    walk(obj)
    unique=[];seen=set()
    for row in rows:
        marker=(row.get("candidate_id"),row.get("candidate_sha256"),row.get("config_sha256"),row.get("runner_sha256"),row.get("strategy_sha256"))
        if marker not in seen:seen.add(marker);unique.append(row)
    out["manifest_candidate_rows_found"]=len(unique)
    out["candidate_config_sha256_matches"]=[row.get("config_sha256")==out["config_sha256"] for row in unique if "config_sha256" in row]
    out["candidate_runner_sha256_matches"]=[row.get("runner_sha256")==sha((folder/str(row.get("entrypoint","run.py"))).read_bytes()) for row in unique if row.get("runner_sha256") and (folder/str(row.get("entrypoint","run.py"))).is_file()]
    out["candidate_strategy_sha256_matches"]=[row.get("strategy_sha256")==sha((folder/str(row.get("strategy_module",STRATEGY_MODULES[entry]))).read_bytes()) for row in unique if row.get("strategy_sha256") and (folder/str(row.get("strategy_module",STRATEGY_MODULES[entry]))).is_file()]
    out["candidate_strategy_binding"]=[{"strategy_module":row.get("strategy_module",STRATEGY_MODULES[entry]),"candidate_sha256":row.get("candidate_sha256"),"candidate_strategy_sha256":row.get("strategy_sha256"),"mirror_strategy_sha256":sha((folder/str(row.get("strategy_module",STRATEGY_MODULES[entry]))).read_bytes()),"candidate_config_sha256":row.get("config_sha256"),"mirror_config_sha256":sha((folder/"config.yaml").read_bytes()),"candidate_runner_sha256":row.get("runner_sha256"),"mirror_runner_sha256":sha((folder/str(row.get("entrypoint","run.py"))).read_bytes())} for row in unique if row.get("strategy_sha256")]
    q=folder/"qualification-v3.json"
    out["qualification_v3"]={"present":q.is_file(),"sha256":sha(q.read_bytes()) if q.is_file() else None}
    return out

def run_one(entry:str,env:dict[str,str])->dict:
    cwd=MIRROR/"examples"/"unified"/entry
    evidence=EVIDENCE/entry/"replay"
    if evidence.exists():raise RuntimeError(f"evidence path already exists: {evidence}")
    evidence.parent.mkdir(parents=True,exist_ok=True)
    args=[sys.executable,"run.py","--replay","--evidence-dir",str(evidence)]
    if "--live" in args or "--allow-write" in args:raise RuntimeError("unsafe argument")
    stdout_path=LOGS/f"{entry}--replay.stdout.txt";stderr_path=LOGS/f"{entry}--replay.stderr.txt"
    start=time.monotonic();started=dt.datetime.now(dt.timezone.utc).isoformat();timed_out=False;pid=None;rc=None
    with stdout_path.open("wb") as stdout,stderr_path.open("wb") as stderr:
        proc=subprocess.Popen(args,cwd=cwd,env=env,stdout=stdout,stderr=stderr,shell=False)
        pid=proc.pid
        try:rc=proc.wait(timeout=180)
        except subprocess.TimeoutExpired:timed_out=True
    out=stdout_path.read_bytes();err=stderr_path.read_bytes();payload=payload_from(out)
    tier=payload.get("entry_tier") if payload else None
    pass_status=isinstance(payload,dict) and payload.get("mode")=="replay" and payload.get("status") in SAFE_REPLAY
    tier_ok=isinstance(tier,dict) and tier.get("cli_tier")=="replay" and tier.get("effective_tier")=="replay"
    grant_ok=isinstance(payload,dict) and payload.get("write_grant_result")=="not_applicable_offline_tier"
    return {"entry":entry,"mode":"replay","command":args,"cwd":str(cwd),"evidence_dir":str(evidence),"started_utc":started,"elapsed_seconds":round(time.monotonic()-start,3),"pid":pid,"returncode":rc,"timed_out":timed_out,"timeout_seconds":180,"process_terminated_by_harness":False,"status":payload.get("status") if payload else None,"payload_mode":payload.get("mode") if payload else None,"error":payload.get("error") if payload else None,"reason":payload.get("reason") if payload else None,"entry_tier":tier,"write_grant_result":payload.get("write_grant_result") if payload else None,"pass_status_check":bool(pass_status),"tier_check":bool(tier_ok),"write_grant_check":bool(grant_ok),"counters":counter_projection(payload),"counter_keys_present":sorted(counter_projection(payload)),"stdout_file":str(stdout_path),"stdout_size_bytes":len(out),"stdout_sha256":sha(out),"stdout_tail":out.decode("utf-8","replace").splitlines()[-5:],"stderr_file":str(stderr_path),"stderr_size_bytes":len(err),"stderr_sha256":sha(err),"stderr_tail":err.decode("utf-8","replace").splitlines()[-5:],"live_flag_present":False,"allow_write_flag_present":False,"offline_replay_passed":bool(not timed_out and rc==0 and pass_status and tier_ok and grant_ok),"finite_candidate_source_diagnostic":finite_candidate_diagnostic(entry) if payload is None or not pass_status else None}

def main()->int:
    snapshot_head=current_head()
    git(["cat-file","-e",f"{COMMIT}^{{commit}}"])
    manifest,archive_sha=source_setup()
    if not mirror_pins(manifest):raise RuntimeError("prelaunch mirror pin check failed")
    static=preflight()
    env=env_for_child()
    if env.get("PYTHONPATH")!=str(MIRROR):raise RuntimeError("PYTHONPATH not bound to fresh mirror")
    if "CONDA_SHLVL" in os.environ and env.get("CONDA_SHLVL")!=os.environ["CONDA_SHLVL"]:raise RuntimeError("active CONDA_SHLVL was overridden")
    if any(k.upper().startswith(FORBIDDEN_PREFIXES) for k in env):raise RuntimeError("account/operator environment included")
    runs=[]
    for entry in ENTRIES:
        row=run_one(entry,env);runs.append(row)
        print(json.dumps({"entry":entry,"returncode":row["returncode"],"status":row["status"],"error":row["error"],"offline_replay_passed":row["offline_replay_passed"],"timed_out":row["timed_out"]},ensure_ascii=False),flush=True)
        if row["timed_out"]:break
        time.sleep(1)
    mirror_stable=mirror_pins(manifest)
    head_after=current_head()
    summary={"schema":"iteration43_offline_cli_012_replay_after_c299359e_r1","evidence_boundary":"EXTERNAL_PUBLIC_MIRROR_OFFLINE_REPLAY_ONLY","snapshot_commit":COMMIT,"head_at_start":snapshot_head,"head_after":head_after,"head_changed_during_run":head_after!=snapshot_head,"mirror":str(MIRROR),"mirror_manifest_path":str(MANIFEST),"mirror_manifest_sha256":sha(MANIFEST.read_bytes()),"mirror_manifest":manifest,"git_archive_sha256":archive_sha,"mirror_pins_match_after_runs":mirror_stable,"static_preflight":static,"python_executable":sys.executable,"child_environment_names":sorted(env),"active_conda_variables_preserved":all(env.get(k)==v for k,v in os.environ.items() if k.upper().startswith("CONDA") or k.upper().startswith("_CONDA")),"conda_shlvl_overridden":False,"ambient_pythonpath_inherited":False,"account_operator_values_recorded":False,"live_flag_used":False,"allow_write_flag_used":False,"provider_constructor_requested_by_harness":False,"timeout_seconds_per_child":180,"process_cleanup_policy":"No taskkill or terminate; report a timeout and stop later modes.","runs":runs,"counts":{"requested":2,"launched":len(runs),"offline_replay_passed":sum(r["offline_replay_passed"] for r in runs),"returncode_zero":sum(r["returncode"]==0 for r in runs),"nontrading_research_rejections":sum(r["returncode"]==0 and r["status"] in {"RESEARCH_REJECTED","NOT_APPROVED"} for r in runs)},"limitations":["Only the two 012 --replay commands ran against the frozen public mirror.","Counter keys are listed only when emitted; absent fields are not interpreted as zero.","No live/provider/account/SDK constructor was requested by this harness."]}
    RESULT.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"result":str(RESULT),"counts":summary["counts"],"mirror_pins_match_after_runs":mirror_stable,"head_after":head_after},ensure_ascii=False),flush=True)
    return 0 if len(runs)==2 and mirror_stable else 2

if __name__=="__main__":
    try:raise SystemExit(main())
    except Exception as exc:
        BASE.mkdir(parents=True,exist_ok=True)
        failure={"schema":"iteration43_offline_cli_012_replay_harness_failure_v1","exception_type":type(exc).__name__,"exception":str(exc)[:1000],"current_head":current_head()}
        (BASE/"harness_failure.json").write_text(json.dumps(failure,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        print(json.dumps(failure,ensure_ascii=False),file=sys.stderr,flush=True)
        raise
