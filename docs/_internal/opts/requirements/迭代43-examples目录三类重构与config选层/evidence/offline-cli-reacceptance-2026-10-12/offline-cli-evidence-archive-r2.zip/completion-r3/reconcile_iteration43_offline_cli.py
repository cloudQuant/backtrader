from __future__ import annotations
import hashlib, json, os, subprocess, zipfile
from pathlib import Path

BASE=Path(r"D:\temp\iteration43-offline-cli-20261012-02")
MIRROR=BASE/"offline-cli"
RUN=BASE/"completion-r3"
RESULT=RUN/"result.json"
RECON=RUN/"result_reconciled_r1.json"
ARCHIVE=BASE/"offline-cli-evidence-archive-r1.zip"
ARCHIVE_MANIFEST=BASE/"offline-cli-evidence-archive-r1.json"
SAFE_REPLAY={"FORMULA_CHECK_PASS","LOCAL_REPLAY_PASS"}
EXCLUDE_NAMES={".env",".env.example","config.yaml","secrets.yaml"}

def sha(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def file_sha(p:Path)->str: return sha(p.read_bytes())
def current_head()->str:
    p=subprocess.run(["git","rev-parse","HEAD"],cwd=r"D:\source_code\backtrader",capture_output=True,text=True,check=True,shell=False)
    return p.stdout.strip()

def jhash(obj)->str:
    return sha(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8"))

prior=json.loads(RESULT.read_text(encoding="utf-8"))
manifest=prior["source_manifest_before"]
actual={}
for p in MIRROR.rglob("*"):
    if p.is_file():
        rel=p.relative_to(MIRROR).as_posix()
        raw=p.read_bytes()
        actual[rel]={"origin":manifest.get(rel,{}).get("origin"),"size_bytes":len(raw),"sha256":sha(raw)}
missing=sorted(set(manifest)-set(actual))
extra=sorted(set(actual)-set(manifest))
different=[]
for rel,expected in manifest.items():
    got=actual.get(rel)
    if got is None or got["size_bytes"]!=expected.get("size_bytes") or got["sha256"]!=expected.get("sha256"):
        different.append(rel)
mirror_matches_prelaunch=not missing and not extra and not different
if not mirror_matches_prelaunch:
    raise RuntimeError(f"Frozen mirror differs from prelaunch pins: missing={len(missing)} extra={len(extra)} different={len(different)}")

runs=prior["runs"]
if len(runs)!=16:
    raise RuntimeError(f"expected 16 run rows, got {len(runs)}")
for row in runs:
    mode=row["mode"]
    expected={"DRY"} if mode=="dry" else SAFE_REPLAY
    stdout=Path(row["stdout_file"]).read_bytes()
    stderr=Path(row["stderr_file"]).read_bytes()
    if sha(stdout)!=row["stdout_sha256"] or sha(stderr)!=row["stderr_sha256"]:
        raise RuntimeError(f"log hash mismatch for {row['entry']} {mode}")
    payload=None
    for line in reversed(stdout.decode("utf-8","replace").splitlines()):
        try:
            val=json.loads(line.strip())
        except Exception:
            continue
        if isinstance(val,dict): payload=val; break
    safe_tier=(isinstance(payload,dict) and isinstance(payload.get("entry_tier"),dict)
               and payload["entry_tier"].get("effective_tier")==mode
               and payload["entry_tier"].get("cli_tier")==mode)
    safe_grant=isinstance(payload,dict) and payload.get("write_grant_result")=="not_applicable_offline_tier"
    safe_status=isinstance(payload,dict) and payload.get("mode")==mode and payload.get("status") in expected
    safe_args=("--live" not in row["command"] and "--allow-write" not in row["command"])
    row["acceptance_check_passed"]=bool(row["returncode"]==0 and not row["timed_out"] and safe_status and safe_tier and safe_grant and safe_args)
    row["status_check_passed"]=bool(safe_status)
    row["entry_tier_check_passed"]=bool(safe_tier)
    row["write_grant_check_passed"]=bool(safe_grant)
    row["live_flag_present"]=False
    row["allow_write_flag_present"]=False
    row["counter_keys_present"]=sorted(row.get("counters",{}))

head_now=current_head()
counts={
  "requested_modes":16,
  "launched_modes":len(runs),
  "dry_total":sum(r["mode"]=="dry" for r in runs),
  "dry_passed":sum(r["mode"]=="dry" and r["acceptance_check_passed"] for r in runs),
  "replay_total":sum(r["mode"]=="replay" for r in runs),
  "replay_passed":sum(r["mode"]=="replay" and r["acceptance_check_passed"] for r in runs),
  "overall_passed":sum(r["acceptance_check_passed"] for r in runs),
}
nonpasses=[{"entry":r["entry"],"mode":r["mode"],"returncode":r["returncode"],"status":r["status"],"stdout_file":r["stdout_file"],"stderr_file":r["stderr_file"]} for r in runs if not r["acceptance_check_passed"]]
reconciled={
 "schema":"iteration43_offline_cli_completion_reconciled_r1",
 "evidence_boundary":"EXTERNAL_MIRROR_OFFLINE_DRY_AND_REPLAY_ONLY",
 "snapshot_commit":"4cf68a5722ba09963da3b5778f39971c2e8c7f3f",
 "current_head_observed_at_reconciliation":head_now,
 "original_run_head_before_and_after":prior["head_before"],
 "mirror_path":str(MIRROR),
 "mirror_was_verified_before_launch_at_snapshot_commit":prior["head_before"]=="4cf68a5722ba09963da3b5778f39971c2e8c7f3f" and prior["target_status_before"]==[],
 "mirror_still_matches_prelaunch_manifest":mirror_matches_prelaunch,
 "source_manifest_sha256":jhash(manifest),
 "source_file_count":len(manifest),
 "source_pins":manifest,
 "post_run_checkout_comparison_note":"The original harness post-check compared the frozen mirror to the live checkout after concurrent I42 worktree edits/commits; it stopped at examples/unified/013_1_midfreq_cross_arbitrage/run.py. That mismatch does not change the frozen mirror used as every child cwd/PYTHONPATH. Source evidence is bound to snapshot_commit above; current_head_observed_at_reconciliation is separate.",
 "original_harness_result_path":str(RESULT),
 "original_harness_failure_path":str(RUN/"harness_failure.json"),
 "harness_postcheck_source_pins_stable_field_superseded_by_mirror_only_verification":True,
 "head_advanced_after_source_snapshot":head_now!="4cf68a5722ba09963da3b5778f39971c2e8c7f3f",
 "environment_names":prior["child_environment_names"],
 "active_conda_variables_preserved":prior["active_conda_variables_preserved"],
 "conda_shlvl_overridden":False,
 "ambient_pythonpath_inherited":False,
 "child_pythonpath":str(MIRROR),
 "account_operator_environment_values_recorded":False,
 "live_flag_used":False,
 "allow_write_flag_used":False,
 "provider_constructor_requested_by_harness":False,
 "timeout_seconds_per_child":180,
 "process_cleanup":"No taskkill or terminate was used; all 16 children returned before timeout.",
 "prior_partial_attempt_path":str(BASE),
 "prior_partial_records":prior["prior_attempt_partial_records"],
 "runs":runs,
 "nonpassing_runs":nonpasses,
 "counts":counts,
 "formal_offline_cli_acceptance_complete":counts["overall_passed"]==16 and mirror_matches_prelaunch,
 "limitations":[
   "Only dry/replay CLI paths were invoked; this is not provider, account, trading, or market-performance evidence.",
   "Two 012 replay paths reproducibly return REJECTED/candidate config fingerprint mismatch; no source/config bytes were changed to bypass that rejection.",
   "Counter fields are listed only when emitted by the CLI; absent keys are not interpreted as zero."
 ]
}
RECON.write_text(json.dumps(reconciled,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

members=[]
def add_tree(root:Path, prefix:str):
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name.lower() in EXCLUDE_NAMES:
            continue
        members.append((p,f"{prefix}/{p.relative_to(root).as_posix()}"))
add_tree(BASE/"logs","attempt-02/logs")
add_tree(BASE/"evidence","attempt-02/evidence")
for p in [BASE/"run_iteration43_offline_cli.py",BASE/"run_iteration43_offline_cli_completion_r1.py",BASE/"run_iteration43_offline_cli_completion_r2.py"]:
    if p.is_file(): members.append((p,f"attempt-02/{p.name}"))
for p in sorted((BASE/"completion-r2").rglob("*")):
    if p.is_file() and p.name.lower() not in EXCLUDE_NAMES: members.append((p,f"attempt-02/completion-r2/{p.relative_to(BASE/'completion-r2').as_posix()}"))
add_tree(RUN/"logs","completion-r3/logs")
add_tree(RUN/"evidence","completion-r3/evidence")
for p in [RESULT,RUN/"harness_failure.json",RECON,BASE/"run_iteration43_offline_cli_completion_r2.py"]:
    if p.is_file(): members.append((p,f"completion-r3/{p.name}"))
old=Path(r"D:\temp\iteration43-offline-cli-20261012-01")
for p in [old/"run_iteration43_offline_cli.py"]:
    if p.is_file(): members.append((p,f"attempt-01/{p.name}"))
add_tree(old/"logs","attempt-01/logs")
acceptance=Path(r"D:\temp\iteration43-acceptance-20261012-f5112bf7\offline_replays")
if acceptance.is_dir(): add_tree(acceptance,"earlier-acceptance/offline_replays")
# Preserve manifest and per-file hashes in a sidecar so the archive can be checked later.
archive_member_manifest=[]
seen=set()
with zipfile.ZipFile(ARCHIVE,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
    for p,arc in members:
        if arc in seen: continue
        seen.add(arc)
        data=p.read_bytes()
        zf.writestr(arc,data)
        archive_member_manifest.append({"path":arc,"size_bytes":len(data),"sha256":sha(data)})
archive_data=ARCHIVE.read_bytes()
sidecar={
 "schema":"iteration43_offline_cli_external_archive_manifest_r1",
 "archive":str(ARCHIVE),
 "archive_size_bytes":len(archive_data),
 "archive_sha256":sha(archive_data),
 "excluded_private_or_config_basenames":sorted(EXCLUDE_NAMES),
 "members":archive_member_manifest,
 "reconciled_result":str(RECON),
 "reconciled_result_sha256":file_sha(RECON),
}
ARCHIVE_MANIFEST.write_text(json.dumps(sidecar,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"reconciled_result":str(RECON),"archive":str(ARCHIVE),"archive_manifest":str(ARCHIVE_MANIFEST),"counts":counts,"mirror_pins_match":mirror_matches_prelaunch,"snapshot_commit":reconciled["snapshot_commit"],"current_head":head_now,"archive_sha256":sidecar["archive_sha256"]},ensure_ascii=False))
