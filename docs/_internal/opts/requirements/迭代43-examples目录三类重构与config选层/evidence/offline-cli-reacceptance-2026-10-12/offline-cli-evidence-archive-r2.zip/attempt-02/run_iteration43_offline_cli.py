from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time
from typing import Any

REPO = Path(r"D:\source_code\backtrader")
BASE = Path(r"D:\temp\iteration43-offline-cli-20261012-02")
MIRROR = BASE / "offline-cli"
EVIDENCE = BASE / "evidence"
LOGS = BASE / "logs"
RESULT = BASE / "result.json"
ENTRIES = [
    "012_1_midfreq_cross_exchange",
    "012_2_event_driven_cross_exchange",
    "013_1_midfreq_cross_arbitrage",
    "013_2_highfreq_calendar_arbitrage",
    "013_3_sa_midfreq_simnow",
    "014_1_ctp_options_lowfreq",
    "014_2_ctp_options_midfreq",
    "015_ctp_options_highfreq",
]
SAFE_CONFIG_PATHS = {
    f"examples/unified/{name}/config.yaml" for name in ENTRIES
}
ALLOWED_ENV_NAMES = (
    "PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP",
    "COMSPEC", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "HOMEDRIVE", "HOMEPATH",
    "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER", "PROCESSOR_LEVEL",
    "PROCESSOR_REVISION", "NUMBER_OF_PROCESSORS",
    "CONDA_PREFIX", "CONDA_DEFAULT_ENV", "CONDA_EXE", "CONDA_PYTHON_EXE",
    "CONDA_SHLVL", "_CONDA_ROOT", "_CONDA_EXE", "CONDA_PROMPT_MODIFIER", "SHLVL",
)
SAFE_REPLAY_STATUSES = {"FORMULA_CHECK_PASS", "LOCAL_REPLAY_PASS"}


def run_git(args: list[str], *, binary: bool = False) -> bytes | str:
    completed = subprocess.run(
        ["git", *args],
        cwd=REPO,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if completed.returncode:
        raise RuntimeError(
            f"git {args[0]} failed with exit {completed.returncode}: "
            f"{completed.stderr.decode('utf-8', errors='replace')[:500]}"
        )
    return completed.stdout if binary else completed.stdout.decode("utf-8", errors="strict")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_config_shape(raw: bytes) -> dict[str, Any]:
    import yaml

    obj = yaml.safe_load(raw)
    if not isinstance(obj, dict):
        raise RuntimeError("public tracked config root is not a mapping")
    return {
        "root_keys": sorted(str(key) for key in obj),
        "entry_keys": sorted(str(key) for key in obj.get("entry", {}))
        if isinstance(obj.get("entry"), dict)
        else [],
        "mode_keys": sorted(str(key) for key in obj.get("mode", {}))
        if isinstance(obj.get("mode"), dict)
        else [],
        "replay_keys": sorted(str(key) for key in obj.get("replay", {}))
        if isinstance(obj.get("replay"), dict)
        else [],
    }


def preflight_source(path: Path) -> dict[str, Any]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    top_imports = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            top_imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            top_imports.append(node.module)
    functions = {
        node.name: node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    main = functions.get("main")
    if main is None:
        raise RuntimeError(f"{path}: no top-level main()")
    main_src = ast.get_source_segment(source, main) or ""
    for flag in ("--dry", "--replay", "--live"):
        if flag not in main_src and flag not in source[: min(len(source), 5000)]:
            raise RuntimeError(f"{path}: expected mode flag {flag} not found")
    for fn_name in ("run_dry", "run_replay"):
        if fn_name not in functions:
            raise RuntimeError(f"{path}: no top-level {fn_name}()")
    offline_sources = {}
    for name in ("run_dry", "run_replay"):
        node = functions[name]
        calls = [
            child.func.id
            for child in ast.walk(node)
            if isinstance(child, ast.Call) and isinstance(child.func, ast.Name)
        ]
        offline_sources[name] = {
            "has_load_env_call": "_load_env" in calls,
            "has_live_runner_call": any(
                value in calls
                for value in ("run_live", "run_live_observe", "run_live_account")
            ),
        }
        if offline_sources[name]["has_load_env_call"]:
            raise RuntimeError(f"{path}: {name} calls _load_env")
        if offline_sources[name]["has_live_runner_call"]:
            raise RuntimeError(f"{path}: {name} calls live runner")
    provider_imports = [
        name
        for name in top_imports
        if name == "bt_api_ctp"
        or name.startswith("bt_api_ctp.")
        or name == "bt_api_py"
        or name.startswith("bt_api_py.")
    ]
    if provider_imports:
        raise RuntimeError(f"{path}: provider import at module load: {provider_imports}")
    return {
        "top_level_provider_imports": provider_imports,
        "offline_functions": offline_sources,
        "explicit_modes": ["--dry", "--replay"],
        "live_mode_not_requested": True,
    }


def source_env() -> dict[str, str]:
    env: dict[str, str] = {}
    for wanted in ALLOWED_ENV_NAMES:
        if wanted == "CONDA_SHLVL":
            env[wanted] = "0"
            continue
        found = next((key for key in os.environ if key.upper() == wanted), None)
        if found is not None:
            env[wanted] = os.environ[found]
    env["PYTHONPATH"] = str(MIRROR)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["MPLBACKEND"] = "Agg"
    return env

def copy_sources_and_build_mirror() -> dict[str, Any]:
    if MIRROR.exists():
        raise RuntimeError(f"Mirror path already exists; refusing to overwrite: {MIRROR}")
    MIRROR.mkdir(parents=True)
    EVIDENCE.mkdir(parents=True)
    LOGS.mkdir(parents=True)

    archive = run_git(["archive", "--format=tar", "HEAD", "backtrader", "backtrader_runtime"], binary=True)
    package_tar = tarfile.open(fileobj=__import__("io").BytesIO(archive), mode="r:")
    package_tar.extractall(MIRROR)
    package_tar.close()

    copied = []
    excluded = []
    config_records = []
    for entry in ENTRIES:
        prefix = f"examples/unified/{entry}"
        paths = run_git(["ls-files", prefix]).splitlines()
        if not paths:
            raise RuntimeError(f"No tracked paths for {entry}")
        for rel in paths:
            if rel in {".", ""}:
                continue
            rel_path = Path(rel)
            if rel_path.name in {".env", ".env.example"}:
                excluded.append(rel)
                continue
            dest = MIRROR / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            if rel in SAFE_CONFIG_PATHS:
                blob = run_git(["cat-file", "--filters", f"HEAD:{rel}"], binary=True)
                dest.write_bytes(blob)
                config_records.append(
                    {
                        "path": rel,
                        "origin": "git-filtered-public-HEAD-blob",
                        "sha256": sha256(blob),
                        "size_bytes": len(blob),
                        "shape": safe_config_shape(blob),
                    }
                )
            else:
                src = REPO / rel_path
                if not src.is_file():
                    raise RuntimeError(f"Tracked public source missing from checkout: {rel}")
                data = src.read_bytes()
                dest.write_bytes(data)
                copied.append({"path": rel, "sha256": sha256(data), "size_bytes": len(data)})
    if (MIRROR / ".env").exists():
        raise RuntimeError("Unexpected .env in fresh mirror")
    for entry in ENTRIES:
        folder = MIRROR / "examples" / "unified" / entry
        if not (folder / "config.yaml").is_file():
            raise RuntimeError(f"Public synthetic config missing in mirror: {entry}")
        if (folder / ".env").exists():
            raise RuntimeError(f"Unexpected local .env in mirror entry: {entry}")
    return {
        "framework_archive": "git archive HEAD backtrader backtrader_runtime",
        "framework_archive_sha256": sha256(archive),
        "copied_checkout_sources": copied,
        "excluded_env_examples": excluded,
        "public_configs": config_records,
    }


def parse_payload(stdout: str) -> dict[str, Any] | None:
    for line in reversed(stdout.splitlines()):
        stripped = line.strip()
        if not stripped:
            continue
        try:
            candidate = json.loads(stripped)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            return candidate
    return None


def counter_projection(payload: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    wanted = {
        "network",
        "provider_sessions",
        "sdk_write_requests",
        "orders",
        "order_write",
        "external_request_counts",
        "provider_requests",
        "provider_calls",
        "sessions",
    }
    return {key: payload[key] for key in wanted if key in payload}


def run_one(entry: str, mode: str, env: dict[str, str]) -> dict[str, Any]:
    folder = MIRROR / "examples" / "unified" / entry
    evidence_dir = EVIDENCE / entry / mode
    evidence_dir.parent.mkdir(parents=True, exist_ok=True)
    if evidence_dir.exists():
        raise RuntimeError(f"Evidence directory already exists: {evidence_dir}")
    args = [sys.executable, "run.py", "--dry" if mode == "dry" else "--replay", "--evidence-dir", str(evidence_dir)]
    if "--live" in args or "--allow-write" in args:
        raise RuntimeError(f"Unsafe argument in command: {args}")
    stdout_path = LOGS / f"{entry}--{mode}.stdout.txt"
    stderr_path = LOGS / f"{entry}--{mode}.stderr.txt"
    started = time.monotonic()
    timed_out = False
    timeout_cleanup: dict[str, Any] | None = None
    proc = subprocess.Popen(
        args,
        cwd=folder,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
    )
    try:
        out_bytes, err_bytes = proc.communicate(timeout=180)
        exit_code = proc.returncode
    except subprocess.TimeoutExpired:
        timed_out = True
        cleanup = subprocess.run(
            ["taskkill.exe", "/PID", str(proc.pid), "/T", "/F"],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
            check=False,
            shell=False,
        )
        timeout_cleanup = {
            "pid": proc.pid,
            "taskkill_shell": False,
            "taskkill_returncode": cleanup.returncode,
            "taskkill_stdout": cleanup.stdout.decode("utf-8", errors="replace"),
            "taskkill_stderr": cleanup.stderr.decode("utf-8", errors="replace"),
        }
        try:
            out_bytes, err_bytes = proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            out_bytes, err_bytes = proc.communicate(timeout=10)
            timeout_cleanup["direct_process_kill_used"] = True
        else:
            timeout_cleanup["direct_process_kill_used"] = False
        exit_code = proc.returncode
    stdout = out_bytes.decode("utf-8", errors="replace")
    stderr = err_bytes.decode("utf-8", errors="replace")
    stdout_path.write_text(stdout, encoding="utf-8")
    stderr_path.write_text(stderr, encoding="utf-8")
    payload = parse_payload(stdout)
    expected_status = {"DRY"} if mode == "dry" else SAFE_REPLAY_STATUSES
    valid = (
        not timed_out
        and exit_code == 0
        and isinstance(payload, dict)
        and payload.get("mode") == mode
        and payload.get("status") in expected_status
        and isinstance(payload.get("entry_tier"), dict)
        and bool(payload.get("entry_tier"))
    )
    return {
        "entry": entry,
        "mode": mode,
        "command": args,
        "cwd": str(folder),
        "exit_code": exit_code,
        "timed_out": timed_out,
        "timeout_cleanup": timeout_cleanup,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "status": payload.get("status") if payload else None,
        "entry_tier": payload.get("entry_tier") if payload else None,
        "write_grant_result": payload.get("write_grant_result") if payload else None,
        "counters": counter_projection(payload),
        "route_evidence": {
            "requested_mode": mode,
            "live_flag_present": False,
            "allow_write_flag_present": False,
            "environment_names": sorted(env),
        },
        "payload_parse_ok": payload is not None,
        "acceptance_check_passed": valid,
        "stdout_file": str(stdout_path),
        "stderr_file": str(stderr_path),
        "evidence_dir": str(evidence_dir),
        "stdout_sha256": sha256(stdout.encode("utf-8")),
        "stderr_sha256": sha256(stderr.encode("utf-8")),
        "stdout_tail": stdout.splitlines()[-8:],
        "stderr_tail": stderr.splitlines()[-8:],
    }

def main() -> int:
    if not REPO.is_dir():
        raise RuntimeError(f"Repository not found: {REPO}")
    BASE.mkdir(parents=True, exist_ok=True)
    head = run_git(["rev-parse", "HEAD"]).strip()
    status_before = run_git(["status", "--porcelain=v1", "-uall"])
    raw_sources = {}
    for entry in ENTRIES:
        path = REPO / "examples" / "unified" / entry / "run.py"
        raw_sources[entry] = preflight_source(path)
        config_path = f"examples/unified/{entry}/config.yaml"
        if config_path not in SAFE_CONFIG_PATHS:
            raise RuntimeError(f"Config is not an allowlisted public tracked path: {config_path}")
        tracked = run_git(["ls-files", "--error-unmatch", config_path]).strip()
        if tracked != config_path:
            raise RuntimeError(f"Public config is not tracked as expected: {config_path}")
    build = copy_sources_and_build_mirror()
    env = source_env()
    runs = []
    for entry in ENTRIES:
        for mode in ("dry", "replay"):
            runs.append(run_one(entry, mode, env))
    dry_success = sum(row["mode"] == "dry" and row["acceptance_check_passed"] for row in runs)
    replay_success = sum(row["mode"] == "replay" and row["acceptance_check_passed"] for row in runs)
    status_after = run_git(["status", "--porcelain=v1", "-uall"])
    repo_target_status_after = run_git(["status", "--porcelain=v1", "-uall", "--", "examples/unified/012_1_midfreq_cross_exchange", "examples/unified/012_2_event_driven_cross_exchange", "examples/unified/013_1_midfreq_cross_arbitrage", "examples/unified/013_2_highfreq_calendar_arbitrage", "examples/unified/013_3_sa_midfreq_simnow", "examples/unified/014_1_ctp_options_lowfreq", "examples/unified/014_2_ctp_options_midfreq", "examples/unified/015_ctp_options_highfreq"])
    report = {
        "schema": "iteration43_offline_cli_rerun_v1",
        "evidence_boundary": "EXTERNAL_MIRROR_OFFLINE_DRY_AND_REPLAY_ONLY",
        "repository": str(REPO),
        "branch_head": head,
        "mirror": str(MIRROR),
        "harness": str(Path(__file__).resolve()),
        "prior_failed_attempt": r"D:\temp\iteration43-offline-cli-20261012-01",
        "python_executable": sys.executable,
        "framework_archive_head_only": True,
        "framework_archive_sha256": build["framework_archive_sha256"],
        "source_preflight": raw_sources,
        "copy_and_config_provenance": build,
        "child_environment_names_only": sorted(env),
        "child_environment_whitelist": list(ALLOWED_ENV_NAMES)
        + ["PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "MPLBACKEND"],
        "operator_environment_values_inherited": False,
        "live_flag_used": False,
        "allow_write_flag_used": False,
        "runs": runs,
        "counts": {
            "dry_total": sum(row["mode"] == "dry" for row in runs),
            "dry_passed": dry_success,
            "replay_total": sum(row["mode"] == "replay" for row in runs),
            "replay_passed": replay_success,
            "overall_passed": sum(row["acceptance_check_passed"] for row in runs),
        },
        "repo_status_before_sha256": sha256(status_before.encode("utf-8")),
        "repo_status_after_sha256": sha256(status_after.encode("utf-8")),
        "repo_status_unchanged": status_before == status_after,
        "target_entry_status_after": repo_target_status_after.splitlines(),
    }
    RESULT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"result": str(RESULT), "counts": report["counts"], "head": head}, ensure_ascii=False))
    return 0 if dry_success == len(ENTRIES) and replay_success == len(ENTRIES) and status_before == status_after else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BaseException as exc:
        failure = {
            "schema": "iteration43_offline_cli_rerun_harness_failure_v1",
            "evidence_boundary": "EXTERNAL_MIRROR_OFFLINE_DRY_AND_REPLAY_ONLY",
            "exception_type": type(exc).__name__,
            "exception": str(exc)[:1000],
        }
        try:
            BASE.mkdir(parents=True, exist_ok=True)
            (BASE / "harness_failure.json").write_text(
                json.dumps(failure, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
        except Exception:
            pass
        print(json.dumps(failure, ensure_ascii=False), file=sys.stderr)
        raise
