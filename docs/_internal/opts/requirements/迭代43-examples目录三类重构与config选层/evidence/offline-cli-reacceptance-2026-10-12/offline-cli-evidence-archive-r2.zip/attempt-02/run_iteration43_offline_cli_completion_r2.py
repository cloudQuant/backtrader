from __future__ import annotations
import ast, datetime as dt, hashlib, json, os, subprocess, sys, tarfile, time
from pathlib import Path

REPO = Path(r"D:\source_code\backtrader")
BASE = Path(r"D:\temp\iteration43-offline-cli-20261012-02")
MIRROR = BASE / "offline-cli"
OUT = BASE / "completion-r3"
LOGS = OUT / "logs"
EVIDENCE = OUT / "evidence"
RESULT = OUT / "result.json"
EXPECTED_HEAD = "4cf68a5722ba09963da3b5778f39971c2e8c7f3f"
ENTRIES = [
    "012_1_midfreq_cross_exchange",
    "012_2_event_driven_cross_exchange",
    "013_1_midfreq_cross_arbitrage",
    "013_2_highfreq_calendar_arbitrage",
    "013_3_sa_midfreq_simnow",
    "014_1_ctp_options_lowfreq",
    "014_2_ctp_options_midfreq",
    "015_ctp_options_highfreq",
]
EXCLUDED = {".env", ".env.example"}
SAFE_REPLAY_STATUSES = {"FORMULA_CHECK_PASS", "LOCAL_REPLAY_PASS"}
FORBIDDEN_ENV_PREFIXES = ("CTP_", "SIMNOW_", "BINANCE_", "OKX_", "BT_API_")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(args: list[str], binary: bool = False) -> bytes | str:
    cp = subprocess.run(["git", *args], cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
    if cp.returncode:
        raise RuntimeError(f"git {args[0]} failed with exit {cp.returncode}: {cp.stderr.decode('utf-8', 'replace')[:500]}")
    return cp.stdout if binary else cp.stdout.decode("utf-8", "strict")


def head() -> str:
    return str(git(["rev-parse", "HEAD"])).strip()


def source_manifest() -> dict[str, dict[str, object]]:
    """Verify the frozen external mirror against public Git/checkout inputs."""
    manifest: dict[str, dict[str, object]] = {}
    archive = git(["archive", "--format=tar", "HEAD", "backtrader", "backtrader_runtime"], binary=True)
    with tarfile.open(fileobj=__import__("io").BytesIO(archive), mode="r:") as tf:
        for member in tf.getmembers():
            if not member.isfile():
                continue
            f = tf.extractfile(member)
            assert f is not None
            data = f.read()
            rel = member.name.replace("\\", "/")
            target = MIRROR.joinpath(*rel.split("/"))
            if not target.is_file() or target.read_bytes() != data:
                raise RuntimeError(f"framework mirror differs from Git archive: {rel}")
            manifest[rel] = {"origin": "git-archive-HEAD", "size_bytes": len(data), "sha256": sha(data)}
    expected = set(manifest)
    for entry in ENTRIES:
        prefix = f"examples/unified/{entry}"
        paths = str(git(["ls-files", prefix])).splitlines()
        if not paths:
            raise RuntimeError(f"no tracked source paths for {entry}")
        for rel in paths:
            if not rel or Path(rel).name in EXCLUDED:
                continue
            if rel.endswith("/config.yaml") or rel in {f"{prefix}/config.yaml"}:
                data = git(["cat-file", "--filters", f"HEAD:{rel}"], binary=True)
                origin = "git-cat-file-filters-HEAD-public-config"
            else:
                source = REPO.joinpath(*rel.split("/"))
                if not source.is_file():
                    raise RuntimeError(f"public tracked source missing from checkout: {rel}")
                data = source.read_bytes()
                origin = "public-checkout-source"
            target = MIRROR.joinpath(*rel.split("/"))
            if not target.is_file() or target.read_bytes() != data:
                raise RuntimeError(f"entry mirror differs from expected bytes: {rel}")
            expected.add(rel)
            manifest[rel] = {"origin": origin, "size_bytes": len(data), "sha256": sha(data)}
    actual = {p.relative_to(MIRROR).as_posix() for p in MIRROR.rglob("*") if p.is_file()}
    extras = sorted(actual - expected)
    missing = sorted(expected - actual)
    if extras or missing:
        raise RuntimeError(f"mirror inventory differs: extra_count={len(extras)} missing_count={len(missing)}")
    return dict(sorted(manifest.items()))


def preflight() -> dict[str, dict[str, object]]:
    records = {}
    for entry in ENTRIES:
        path = MIRROR / "examples" / "unified" / entry / "run.py"
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        top_imports: list[str] = []
        for node in tree.body:
            if isinstance(node, ast.Import):
                top_imports.extend(a.name for a in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                top_imports.append(node.module)
        functions = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        if not {"main", "run_dry", "run_replay"}.issubset(functions):
            raise RuntimeError(f"{entry}: expected main/run_dry/run_replay functions absent")
        provider_imports = [x for x in top_imports if x == "bt_api_ctp" or x.startswith("bt_api_ctp.") or x == "bt_api_py" or x.startswith("bt_api_py.")]
        offline = {}
        for name in ("run_dry", "run_replay"):
            calls = [c.func.id for c in ast.walk(functions[name]) if isinstance(c, ast.Call) and isinstance(c.func, ast.Name)]
            offline[name] = {
                "calls_load_env": "_load_env" in calls,
                "calls_live_runner": any(x in calls for x in ("run_live", "run_live_observe", "run_live_account")),
            }
            if offline[name]["calls_load_env"] or offline[name]["calls_live_runner"]:
                raise RuntimeError(f"{entry}: offline function has live/env-loader call")
        if provider_imports:
            raise RuntimeError(f"{entry}: top-level provider imports present: {provider_imports}")
        records[entry] = {
            "run_py_sha256": sha(path.read_bytes()),
            "top_level_provider_imports": provider_imports,
            "offline_functions": offline,
            "modes": ["--dry", "--replay"],
        }
    return records


def child_env() -> dict[str, str]:
    # Match the repository copy-run environment: process/profile variables and every
    # active Conda variable are preserved, while account/operator env and ambient
    # PYTHONPATH are excluded. CONDA_SHLVL is passed through when present.
    allowed = {
        "PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "LANG", "LC_ALL", "LC_CTYPE",
        "COMSPEC", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "HOMEDRIVE", "HOMEPATH",
        "PROCESSOR_ARCHITECTURE", "PROCESSOR_IDENTIFIER", "PROCESSOR_LEVEL",
        "PROCESSOR_REVISION", "NUMBER_OF_PROCESSORS",
    }
    env: dict[str, str] = {}
    for name, value in os.environ.items():
        upper = name.upper()
        if upper in allowed or upper.startswith("CONDA") or upper.startswith("_CONDA"):
            env[name] = value
    env["PYTHONPATH"] = str(MIRROR)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["MPLBACKEND"] = "Agg"
    return env


def parse_payload(path: Path) -> dict | None:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return None
    for line in reversed(lines):
        try:
            value = json.loads(line.strip())
        except Exception:
            continue
        if isinstance(value, dict):
            return value
    return None


def counters(payload: dict | None) -> dict:
    wanted = {"network", "provider_sessions", "sdk_write_requests", "orders", "order_write", "external_request_counts", "provider_requests", "provider_calls", "sessions"}
    return {k: payload[k] for k in wanted if isinstance(payload, dict) and k in payload}


def run_one(entry: str, mode: str, env: dict[str, str]) -> dict:
    folder = MIRROR / "examples" / "unified" / entry
    evidence = EVIDENCE / entry / mode
    evidence.parent.mkdir(parents=True, exist_ok=True)
    if evidence.exists():
        raise RuntimeError(f"fresh evidence path already exists: {evidence}")
    args = [sys.executable, "run.py", "--dry" if mode == "dry" else "--replay", "--evidence-dir", str(evidence)]
    if any(x in args for x in ("--live", "--allow-write")):
        raise RuntimeError("unsafe CLI argument appeared")
    stdout_path = LOGS / f"{entry}--{mode}.stdout.txt"
    stderr_path = LOGS / f"{entry}--{mode}.stderr.txt"
    start = time.monotonic()
    started_utc = dt.datetime.now(dt.timezone.utc).isoformat()
    timed_out = False
    pid = None
    returncode = None
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        proc = subprocess.Popen(args, cwd=folder, env=env, stdout=stdout, stderr=stderr, shell=False)
        pid = proc.pid
        try:
            returncode = proc.wait(timeout=180)
        except subprocess.TimeoutExpired:
            timed_out = True
            # Preserve the child and report the blocked state; do not taskkill or terminate it.
    stdout_raw = stdout_path.read_bytes()
    stderr_raw = stderr_path.read_bytes()
    payload = parse_payload(stdout_path)
    expected_status = {"DRY"} if mode == "dry" else SAFE_REPLAY_STATUSES
    tier = payload.get("entry_tier") if payload else None
    status_ok = isinstance(payload, dict) and payload.get("status") in expected_status and payload.get("mode") == mode
    tier_ok = isinstance(tier, dict) and tier.get("effective_tier") == mode and tier.get("cli_tier") == mode
    grant_ok = isinstance(payload, dict) and payload.get("write_grant_result") == "not_applicable_offline_tier"
    accepted = (not timed_out and returncode == 0 and status_ok and tier_ok and grant_ok)
    env_names = sorted(env)
    forbidden_names = [n for n in env_names if n.upper().startswith(FORBIDDEN_ENV_PREFIXES)]
    return {
        "entry": entry,
        "mode": mode,
        "command": args,
        "cwd": str(folder),
        "evidence_dir": str(evidence),
        "started_utc": started_utc,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "pid": pid,
        "returncode": returncode,
        "timed_out": timed_out,
        "timeout_seconds": 180,
        "timeout_process_terminated": False,
        "status": payload.get("status") if payload else None,
        "payload_mode": payload.get("mode") if payload else None,
        "entry_tier": tier,
        "write_grant_result": payload.get("write_grant_result") if payload else None,
        "status_check_passed": status_ok,
        "entry_tier_check_passed": tier_ok,
        "write_grant_check_passed": grant_ok,
        "counters": counters(payload),
        "counter_keys_present": sorted(counters(payload)),
        "live_flag_present": False,
        "allow_write_flag_present": False,
        "child_environment_names": env_names,
        "forbidden_account_operator_environment_names_present": forbidden_names,
        "ambient_pythonpath_inherited": False,
        "stdout_file": str(stdout_path),
        "stdout_sha256": sha(stdout_raw),
        "stdout_size_bytes": len(stdout_raw),
        "stderr_file": str(stderr_path),
        "stderr_sha256": sha(stderr_raw),
        "stderr_size_bytes": len(stderr_raw),
        "stdout_tail": stdout_raw.decode("utf-8", "replace").splitlines()[-3:],
        "stderr_tail": stderr_raw.decode("utf-8", "replace").splitlines()[-3:],
        "acceptance_check_passed": accepted,
    }


def prior_partial() -> list[dict]:
    old_logs = BASE / "logs"
    rows = []
    if not old_logs.is_dir():
        return rows
    for path in sorted(old_logs.glob("*.stdout.txt")):
        stem = path.name.removesuffix(".stdout.txt")
        if "--" not in stem:
            continue
        entry, mode = stem.rsplit("--", 1)
        payload = parse_payload(path)
        stderr = old_logs / f"{entry}--{mode}.stderr.txt"
        rows.append({
            "entry": entry,
            "mode": mode,
            "status": payload.get("status") if payload else None,
            "entry_tier": payload.get("entry_tier") if payload else None,
            "write_grant_result": payload.get("write_grant_result") if payload else None,
            "counters": counters(payload),
            "stdout_file": str(path),
            "stderr_file": str(stderr),
            "stdout_sha256": sha(path.read_bytes()),
            "stderr_sha256": sha(stderr.read_bytes()) if stderr.is_file() else None,
            "returncode": None,
            "acceptance_check_passed": None,
            "disposition": "preserved_partial_only_returncode_not_recorded",
        })
    return rows


def main() -> int:
    if OUT.exists():
        raise RuntimeError(f"completion output directory already exists: {OUT}")
    OUT.mkdir(parents=True)
    LOGS.mkdir()
    EVIDENCE.mkdir()
    h0 = head()
    if h0 != EXPECTED_HEAD:
        raise RuntimeError(f"unexpected start HEAD: {h0}")
    status0 = str(git(["status", "--porcelain=v1", "-uall", "--", *[f"examples/unified/{x}" for x in ENTRIES]]))
    mirror0 = source_manifest()
    preflight_records = preflight()
    env = child_env()
    if any(n.upper().startswith(FORBIDDEN_ENV_PREFIXES) for n in env):
        raise RuntimeError("account/operator environment variable entered child allowlist")
    if env.get("PYTHONPATH") != str(MIRROR):
        raise RuntimeError("child PYTHONPATH is not the frozen mirror")
    if "CONDA_SHLVL" in os.environ and env.get("CONDA_SHLVL") != os.environ["CONDA_SHLVL"]:
        raise RuntimeError("active CONDA_SHLVL was not preserved")
    partial = prior_partial()
    runs = []
    for entry in ENTRIES:
        for mode in ("dry", "replay"):
            row = run_one(entry, mode, env)
            runs.append(row)
            print(json.dumps({"entry": entry, "mode": mode, "returncode": row["returncode"], "status": row["status"], "passed": row["acceptance_check_passed"], "timed_out": row["timed_out"]}, ensure_ascii=False), flush=True)
            if row["timed_out"]:
                break
            time.sleep(1)
        if runs and runs[-1]["timed_out"]:
            break
    h1 = head()
    status1 = str(git(["status", "--porcelain=v1", "-uall", "--", *[f"examples/unified/{x}" for x in ENTRIES]]))
    try:
        mirror1 = source_manifest()
        source_stable = mirror0 == mirror1
        source_error = None
    except Exception as exc:
        mirror1 = None
        source_stable = False
        source_error = f"{type(exc).__name__}: {str(exc)[:500]}"
    counts = {
        "requested_modes": 16,
        "launched_modes": len(runs),
        "dry_total": sum(r["mode"] == "dry" for r in runs),
        "dry_passed": sum(r["mode"] == "dry" and r["acceptance_check_passed"] for r in runs),
        "replay_total": sum(r["mode"] == "replay" for r in runs),
        "replay_passed": sum(r["mode"] == "replay" and r["acceptance_check_passed"] for r in runs),
        "overall_passed": sum(r["acceptance_check_passed"] for r in runs),
    }
    report = {
        "schema": "iteration43_offline_cli_completion_r1",
        "evidence_boundary": "EXTERNAL_MIRROR_OFFLINE_DRY_AND_REPLAY_ONLY",
        "repository": str(REPO),
        "expected_start_head": EXPECTED_HEAD,
        "head_before": h0,
        "head_after": h1,
        "head_changed_during_run": h0 != h1,
        "mirror": str(MIRROR),
        "completion_harness": str(Path(__file__).resolve()),
        "original_harness": str(BASE / "run_iteration43_offline_cli.py"),
        "python_executable": sys.executable,
        "framework_archive_sha256_before": sha(git(["archive", "--format=tar", "HEAD", "backtrader", "backtrader_runtime"], binary=True)),
        "source_manifest_before": mirror0,
        "source_manifest_after": mirror1,
        "source_pins_stable": source_stable,
        "source_pin_error": source_error,
        "source_preflight": preflight_records,
        "child_environment_names": sorted(env),
        "active_conda_variables_preserved": all(env.get(k) == v for k, v in os.environ.items() if k.upper().startswith("CONDA") or k.upper().startswith("_CONDA")),
        "conda_shlvl_overridden": False,
        "ambient_pythonpath_inherited": False,
        "child_pythonpath": str(MIRROR),
        "account_operator_environment_values_recorded": False,
        "live_flag_used": False,
        "allow_write_flag_used": False,
        "prior_attempt_partial_records": partial,
        "runs": runs,
        "counts": counts,
        "target_status_before": status0.splitlines(),
        "target_status_after": status1.splitlines(),
        "target_status_unchanged": status0 == status1,
        "process_cleanup_policy": "no_taskkill_or_terminate; each child receives wait(timeout=180); timed-out child is reported and later modes stop",
    }
    RESULT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"result": str(RESULT), "counts": counts, "source_pins_stable": source_stable, "head_before": h0, "head_after": h1}, ensure_ascii=False), flush=True)
    return 0 if counts["launched_modes"] == 16 and counts["overall_passed"] == 16 and source_stable else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BaseException as exc:
        OUT.mkdir(parents=True, exist_ok=True)
        failure = {
            "schema": "iteration43_offline_cli_completion_harness_failure_v1",
            "evidence_boundary": "EXTERNAL_MIRROR_OFFLINE_DRY_AND_REPLAY_ONLY",
            "exception_type": type(exc).__name__,
            "exception": str(exc)[:1000],
            "head": head() if REPO.is_dir() else None,
        }
        (OUT / "harness_failure.json").write_text(json.dumps(failure, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(failure, ensure_ascii=False), file=sys.stderr, flush=True)
        raise

