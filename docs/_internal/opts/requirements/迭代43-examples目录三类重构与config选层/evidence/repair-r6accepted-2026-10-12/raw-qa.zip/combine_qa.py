"""Combine unchanged successful cases with only the contaminated cases' rerun."""
import copy
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

OUT = Path(__file__).resolve().parent
old = json.loads((OUT / 'r6b.json').read_text(encoding='utf-8'))
new = json.loads((OUT / 'r6d.json').read_text(encoding='utf-8'))
assert old['source_pins'] == new['source_pins']
assert old['head'] == new['head']
assert new['exit_code'] == 0
assert old['environment_flags'] == new['environment_flags']
key = lambda case: (case.attrib['classname'], case.attrib['name'])
failed = lambda case: case.find('failure') is not None or case.find('error') is not None
original = {key(case): case for case in ET.parse(OUT / 'r6b.xml').iter('testcase')}
retry = {key(case): case for case in ET.parse(OUT / 'r6d.xml').iter('testcase')}
assert len(original) == 109 and len(retry) == 12
assert {name for name, case in original.items() if failed(case)} == set(retry)
assert all(not failed(case) and case.find('skipped') is None for case in retry.values())
suite = ET.Element('testsuite', name='unchanged-source-composite', tests='109', failures='0', errors='0', skipped='0')
for name, case in original.items():
    chosen = copy.deepcopy(retry.get(name, case))
    ET.SubElement(chosen, 'properties').append(ET.Element('property', name='evidence_attempt', value='r6d' if name in retry else 'r6b'))
    suite.append(chosen)
ET.ElementTree(suite).write(OUT / 'r6accepted.xml', encoding='utf-8', xml_declaration=True)
pin = lambda raw: {'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
note = ('Composite acceptance: 97 unchanged successful r6b cases plus 12 r6d reruns. '
        'The original r6b exit 1 and its 12 process-cleanup-contaminated failures remain frozen. '
        'This is not a claim that r6b exited zero or that 109 cases ran in one invocation.\n')
(OUT / 'r6accepted.log').write_text(note, encoding='utf-8')
result = {**new, 'name': 'r6accepted', 'command': ['python', str(Path(__file__).resolve())],
          'exit_code': 0, 'evidence_level': 'COMPOSITE_SOURCE_FAKE_AND_OFFLINE_ONLY',
          'composition': [{'attempt': 'r6b', 'accepted_cases': 97, 'pytest_exit_code': 1},
                          {'attempt': 'r6d', 'accepted_cases': 12, 'pytest_exit_code': 0}],
          'composition_note': note.strip(), 'combiner': pin(Path(__file__).read_bytes()),
          'log': pin((OUT / 'r6accepted.log').read_bytes()),
          'xml': pin((OUT / 'r6accepted.xml').read_bytes())}
(OUT / 'r6accepted.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(note.strip())
