import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/source_code/backtrader')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
root_manifest = json.loads((root / 'examples/strategy-candidate-manifest.json').read_text(encoding='utf-8'))
rows = []
for name, strategy in [('012_1_midfreq_cross_exchange', 'cross_exchange_strategy.py'), ('012_2_event_driven_cross_exchange', 'event_driven_strategy.py')]:
    folder = root / 'examples/unified' / name
    local = json.loads((folder / 'strategy-candidate-manifest.json').read_text(encoding='utf-8'))
    canonical_row = next(row for row in root_manifest['candidates'] if row['strategy_id'] == name)
    local_row = next(row for row in local['candidates'] if row['strategy_id'] == name)
    for filename, field in [('run.py', 'runner_sha256'), (strategy, 'strategy_sha256'), ('config.yaml', 'config_sha256')]:
        rel = f'examples/unified/{name}/{filename}'
        filtered = git('cat-file', '--filters', 'HEAD:' + rel)
        # These are fixed tracked public source/template paths only.
        checkout = (root / rel).read_bytes()
        rows.append({'path': rel, 'attributes': git('check-attr', 'text', 'eol', '--', rel).decode().splitlines(), 'filtered_sha256': hashlib.sha256(filtered).hexdigest(), 'checkout_sha256': hashlib.sha256(checkout).hexdigest(), 'checkout_eq_filtered': checkout == filtered, 'root_matches_filtered': canonical_row[field] == hashlib.sha256(filtered).hexdigest(), 'local_matches_filtered': local_row[field] == hashlib.sha256(filtered).hexdigest(), 'filtered_crlf': filtered.count(b'\r\n'), 'checkout_crlf': checkout.count(b'\r\n')})
out = Path(__file__).with_name('public-012-all-binding-audit.json')
out.write_text(json.dumps({'head': git('rev-parse', 'HEAD').decode().strip(), 'rows': rows}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(rows, ensure_ascii=False))
