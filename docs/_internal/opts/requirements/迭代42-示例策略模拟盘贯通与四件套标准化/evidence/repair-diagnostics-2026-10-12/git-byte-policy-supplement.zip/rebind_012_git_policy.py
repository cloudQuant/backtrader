"""Align all six fixed public source pins to their existing Git LF policy."""
import copy
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/source_code/backtrader')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
sources = {}
for name, strategy in [('012_1_midfreq_cross_exchange', 'cross_exchange_strategy.py'), ('012_2_event_driven_cross_exchange', 'event_driven_strategy.py')]:
    source = {}
    for filename, field in [('run.py', 'runner_sha256'), (strategy, 'strategy_sha256'), ('config.yaml', 'config_sha256')]:
        rel = f'examples/unified/{name}/{filename}'
        git('diff', '--quiet', 'HEAD', '--', rel)
        raw = git('cat-file', '--filters', 'HEAD:' + rel)
        attrs = git('check-attr', 'text', 'eol', '--', rel).decode()
        if ': text: set' not in attrs or ': eol: lf' not in attrs or b'\r' in raw:
            raise ValueError('Unexpected fixed public source policy: ' + rel)
        source[field] = hashlib.sha256(raw).hexdigest()
        if filename.endswith('_strategy.py'):
            checkout = (root / rel).read_bytes()
            if checkout.replace(b'\r\n', b'\n') != raw:
                raise ValueError('Public strategy has semantic changes: ' + rel)
            (root / rel).write_bytes(raw)
    sources[name] = source

manifest_paths = [root / 'examples/strategy-candidate-manifest.json'] + [root / 'examples/unified' / name / 'strategy-candidate-manifest.json' for name in sources]
changed = []
for path in manifest_paths:
    manifest = json.loads(path.read_text(encoding='utf-8'))
    before = copy.deepcopy(manifest)
    for row in manifest['candidates']:
        if row['strategy_id'] not in sources:
            raise ValueError('Unexpected manifest candidate')
        row.update(sources[row['strategy_id']])
        payload = {k:v for k,v in row.items() if k not in {'candidate_sha256', 'demo_approval'}}
        row['candidate_sha256'] = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    mutable = {'runner_sha256', 'strategy_sha256', 'config_sha256', 'candidate_sha256'}
    if {k:v for k,v in before.items() if k != 'candidates'} != {k:v for k,v in manifest.items() if k != 'candidates'}:
        raise ValueError('Unexpected manifest top-level change')
    for old, new in zip(before['candidates'], manifest['candidates']):
        if {k:v for k,v in old.items() if k not in mutable} != {k:v for k,v in new.items() if k not in mutable}:
            raise ValueError('Unexpected admission or path change')
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    changed.append(path.relative_to(root).as_posix())
print(json.dumps({'head': git('rev-parse', 'HEAD').decode().strip(), 'manifests': changed, 'source_pins': sources}, ensure_ascii=False))
