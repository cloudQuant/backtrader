"""Restore only two tracked public templates to their existing eol=lf policy."""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/source_code/backtrader')
records = []
for name in ('012_1_midfreq_cross_exchange', '012_2_event_driven_cross_exchange'):
    relative = f'examples/unified/{name}/config.yaml'
    if subprocess.check_output(['git', 'status', '--porcelain', '--', relative], cwd=root):
        raise ValueError('Template has uncommitted content: ' + relative)
    attrs = subprocess.check_output(['git', 'check-attr', 'text', 'eol', '--', relative], cwd=root).decode()
    if ': text: set' not in attrs or ': eol: lf' not in attrs:
        raise ValueError('Unexpected template attributes: ' + relative)
    raw = subprocess.check_output(['git', 'cat-file', '--filters', 'HEAD:' + relative], cwd=root)
    if b'\r' in raw:
        raise ValueError('Expected LF public Git template: ' + relative)
    (root / relative).write_bytes(raw)
    records.append({'path': relative, 'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw), 'source': 'tracked filtered HEAD; existing text eol=lf'})
out = Path(__file__).with_name('public-012-template-normalization.json')
out.write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print('Restored two public tracked templates to the existing LF checkout policy; no configuration content change.')
