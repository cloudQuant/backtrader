import copy
import hashlib
import json
import subprocess
from pathlib import Path
ROOT = Path("D:/source_code/backtrader")
path = ROOT / "examples/strategy-candidate-manifest.json"
manifest = json.loads(path.read_text(encoding="utf-8"))
before = copy.deepcopy(manifest)
keys = {"resolved_example_path", "runner_sha256", "strategy_sha256", "config_sha256", "candidate_sha256"}
for row in manifest["candidates"]:
    folder = ROOT / "examples/unified" / row["strategy_id"]
    assert row["strategy_id"] in {"012_1_midfreq_cross_exchange", "012_2_event_driven_cross_exchange"}
    row["resolved_example_path"] = "unified/" + row["strategy_id"]
    for field, name in (("runner_sha256", row["entrypoint"]), ("strategy_sha256", row["strategy_module"]), ("config_sha256", "config.yaml")):
        relative = (folder / name).relative_to(ROOT).as_posix()
        if name == "config.yaml":
            assert not subprocess.check_output(["git", "status", "--porcelain", "--", relative], cwd=ROOT)
            raw = subprocess.check_output(["git", "cat-file", "--filters", "HEAD:" + relative], cwd=ROOT)
        else:
            raw = (folder / name).read_bytes()
        row[field] = hashlib.sha256(raw).hexdigest()
    payload = {key: value for key, value in row.items() if key not in {"candidate_sha256", "demo_approval"}}
    row["candidate_sha256"] = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
for old, new in zip(before["candidates"], manifest["candidates"]):
    assert {k:v for k,v in old.items() if k not in keys} == {k:v for k,v in new.items() if k not in keys}
assert {k:v for k,v in before.items() if k != "candidates"} == {k:v for k,v in manifest.items() if k != "candidates"}
path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Only the two candidate path/source bindings were rebound; admission fields preserved")
