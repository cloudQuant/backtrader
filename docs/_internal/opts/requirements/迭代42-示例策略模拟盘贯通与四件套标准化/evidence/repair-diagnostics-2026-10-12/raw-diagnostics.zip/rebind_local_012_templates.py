import copy
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('D:/source_code/backtrader')
changed = []
for name in ('012_1_midfreq_cross_exchange', '012_2_event_driven_cross_exchange'):
    path = root / 'examples/unified' / name / 'strategy-candidate-manifest.json'
    manifest = json.loads(path.read_text(encoding='utf-8'))
    before = copy.deepcopy(manifest)
    relative = f'examples/unified/{name}/config.yaml'
    raw = subprocess.check_output(['git', 'cat-file', '--filters', 'HEAD:' + relative], cwd=root)
    matches = [row for row in manifest['candidates'] if row['strategy_id'] == name]
    if len(matches) != 1:
        raise ValueError('Expected one local candidate')
    row = matches[0]
    row['config_sha256'] = hashlib.sha256(raw).hexdigest()
    payload = {k: v for k, v in row.items() if k not in {'candidate_sha256', 'demo_approval'}}
    row['candidate_sha256'] = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    for old, new in zip(before['candidates'], manifest['candidates']):
        if {k:v for k,v in old.items() if k not in {'config_sha256', 'candidate_sha256'}} != {k:v for k,v in new.items() if k not in {'config_sha256', 'candidate_sha256'}}:
            raise ValueError('Unexpected admission or source change')
    if {k:v for k,v in before.items() if k != 'candidates'} != {k:v for k,v in manifest.items() if k != 'candidates'}:
        raise ValueError('Unexpected top-level change')
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    changed.append(path.relative_to(root).as_posix())
print(json.dumps(changed))
