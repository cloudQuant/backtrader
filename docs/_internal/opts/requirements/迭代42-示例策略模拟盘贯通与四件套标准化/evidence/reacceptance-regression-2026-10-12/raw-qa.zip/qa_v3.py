"""Focused repair QA with external artifacts; no private/provider operations."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('D:/source_code/backtrader')
OUT = Path(__file__).resolve().parent
ENV = {**os.environ, 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONIOENCODING': 'utf-8', 'MPLBACKEND': 'Agg', 'GIT_OPTIONAL_LOCKS': '0', 'PYTHONPATH': str(ROOT)}
UNRELATED = ['0', 'backtrader_runtime/ctp_configured_front_check.py', 'backtrader_runtime/ctp_simnow_operator.py', 'tests/unit/runtime/test_ctp_simnow_config_operator_route.py']

def pin(raw):
    return {'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.quotePath=false', *args], cwd=ROOT, env=ENV)

def preserved():
    return {name: pin((ROOT / name).read_bytes()) if (ROOT / name).is_file() else None for name in UNRELATED}

if sys.argv[1] == 'baseline':
    data = {'head': git('rev-parse', 'HEAD').decode().strip(), 'branch': git('branch', '--show-current').decode().strip(), 'unrelated': preserved(), 'unrelated_diff': pin(git('diff', '--binary', '--', *UNRELATED)), 'status': git('status', '--porcelain=v1', '-uall').decode('utf-8')}
    assert git('diff', '--cached', '--binary') == b''
    (OUT / 'baseline.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'head': data['head'], 'branch': data['branch'], 'unrelated_paths': len(data['unrelated'])}))
else:
    name, *tests = sys.argv[1:]
    source_names = set(git('diff', '--name-only', '-z').decode('utf-8').split('\0')) - set(UNRELATED) - {''}
    source_names.update(json.loads(os.environ.get('BT_QA_EXTRA_PUBLIC', '[]')))
    source_names.update(test.split('::')[0] for test in tests if (ROOT / test.split('::')[0]).is_file())
    source_pins = {name: pin((ROOT / name).read_bytes()) for name in sorted(source_names) if (ROOT / name).is_file()}
    (OUT / (name + '.pre-pins.json')).write_text(json.dumps(source_pins, ensure_ascii=False, indent=2), encoding='utf-8')
    start = time.monotonic()
    command = [sys.executable, '-B', '-m', 'pytest', *tests, '--noconftest', '-q', '-ra', '--tb=short', '-p', 'no:cacheprovider', '--basetemp=' + str(OUT / ('tmp_' + name)), '--junitxml=' + str(OUT / (name + '.xml'))]
    with (OUT / (name + '.log')).open('w', encoding='utf-8', newline='') as log:
        completed = subprocess.run(command, cwd=ROOT, env=ENV, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    assert {name: pin((ROOT / name).read_bytes()) for name in source_pins} == source_pins
    baseline = json.loads((OUT / 'baseline.json').read_text(encoding='utf-8'))
    assert preserved() == baseline['unrelated']
    assert pin(git('diff', '--binary', '--', *UNRELATED)) == baseline['unrelated_diff']
    data = {'name': name, 'head': git('rev-parse', 'HEAD').decode().strip(), 'command': command, 'cwd': str(ROOT), 'exit_code': completed.returncode, 'elapsed_seconds': round(time.monotonic() - start, 3), 'unrelated_changes_preserved': True, 'source_pins': source_pins, 'log': pin((OUT / (name + '.log')).read_bytes()), 'xml': pin((OUT / (name + '.xml')).read_bytes()), 'environment_flags': {key: ENV.get(key) for key in ('BT_I43_COPY_STRICT', 'MPLBACKEND', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD')}, 'harness': pin(Path(__file__).read_bytes()), 'evidence_level': 'SOURCE_FAKE_AND_OFFLINE_ONLY'}
    (OUT / (name + '.json')).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(data, ensure_ascii=False))
    print((OUT / (name + '.log')).read_text(encoding='utf-8')[-6500:])
